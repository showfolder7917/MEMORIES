-- 自定义CRM客户类型；不改变客户/供应商角色，不回填现有客户。
CREATE TABLE IF NOT EXISTS CrmCustomerType (
    id BIGINT NOT NULL CHECK(id>0),
    code VARCHAR(100) NOT NULL UNIQUE,
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    typeName VARCHAR(100) NOT NULL CHECK(LENGTH(TRIM(typeName))>0),
    typeNameKey VARCHAR(100) NOT NULL,
    enabledFlag BOOLEAN NOT NULL DEFAULT TRUE,
    creationRequestKey VARCHAR(64) NOT NULL,
    creationHash VARCHAR(64) NOT NULL,
    changeHistoryJson TEXT NOT NULL,
    versionNo BIGINT NOT NULL CHECK(versionNo>=0),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    UNIQUE(tenantId,businessOrgId,typeNameKey),
    UNIQUE(tenantId,businessOrgId,creationRequestKey)
);
COMMENT ON TABLE CrmCustomerType IS '经营组织可维护的客户类型；停用保留历史引用';
COMMENT ON COLUMN CrmCustomerType.id IS '公共CrmCustomerTypeId号段主键';
COMMENT ON COLUMN CrmCustomerType.code IS '服务端生成的不可变业务编码';
COMMENT ON COLUMN CrmCustomerType.tenantId IS '实际当前租户';
COMMENT ON COLUMN CrmCustomerType.businessOrgId IS '原CRM范围核验的经营组织';
COMMENT ON COLUMN CrmCustomerType.lastOperateUserId IS '真实最后操作账号';
COMMENT ON COLUMN CrmCustomerType.typeName IS '用户自定义的显示名称';
COMMENT ON COLUMN CrmCustomerType.typeNameKey IS '规范小写名称，用于组织内唯一约束';
COMMENT ON COLUMN CrmCustomerType.enabledFlag IS '可供新客户选择；关闭不删除既有关系';
COMMENT ON COLUMN CrmCustomerType.creationRequestKey IS '组织范围内创建请求键，重试不新建类型';
COMMENT ON COLUMN CrmCustomerType.creationHash IS '首次规范正文摘要，拒绝同键异内容';
COMMENT ON COLUMN CrmCustomerType.changeHistoryJson IS '追加保存请求、前后值、真实操作者及版本，支持原版本重试';
COMMENT ON COLUMN CrmCustomerType.versionNo IS '本表乐观版本';
COMMENT ON COLUMN CrmCustomerType.labelZh IS '中文显示名';
COMMENT ON COLUMN CrmCustomerType.labelJa IS '日文显示名';
COMMENT ON COLUMN CrmCustomerType.labelEn IS '英文显示名';
COMMENT ON COLUMN CrmCustomerType.status IS '有效记录标志，停用使用enabledFlag';
COMMENT ON COLUMN CrmCustomerType.sortnum IS '显示顺序';
COMMENT ON COLUMN CrmCustomerType.createdAt IS '首次建立时间';
COMMENT ON COLUMN CrmCustomerType.updatedAt IS '最后修改时间';
