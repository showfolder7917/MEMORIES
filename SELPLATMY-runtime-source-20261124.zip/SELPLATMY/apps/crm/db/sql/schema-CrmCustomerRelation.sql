-- 客户之间的稳定编号关系；说明由经营组织自行维护，不建立权限。
CREATE TABLE IF NOT EXISTS CrmCustomerRelation (
    id BIGINT NOT NULL CHECK(id>0),
    code VARCHAR(100) NOT NULL UNIQUE,
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    partnerId BIGINT NOT NULL CHECK(partnerId>0),
    relatedPartnerId BIGINT NOT NULL CHECK(relatedPartnerId>0),
    relationName VARCHAR(100) NOT NULL CHECK(LENGTH(TRIM(relationName))>0),
    enabledFlag BOOLEAN NOT NULL,
    changeHistoryJson TEXT NOT NULL,
    versionNo BIGINT NOT NULL CHECK(versionNo>0),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    UNIQUE(tenantId,businessOrgId,partnerId,relatedPartnerId),
    CHECK(partnerId<>relatedPartnerId),
    FOREIGN KEY(tenantId,businessOrgId,partnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id),
    FOREIGN KEY(tenantId,businessOrgId,relatedPartnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id)
);
COMMENT ON TABLE CrmCustomerRelation IS '同一经营组织中一对明确客户的独立关系及历史';
COMMENT ON COLUMN CrmCustomerRelation.id IS '公共CrmCustomerRelationId号段主键';
COMMENT ON COLUMN CrmCustomerRelation.code IS '服务端生成的不可变编码';
COMMENT ON COLUMN CrmCustomerRelation.tenantId IS '实际租户';
COMMENT ON COLUMN CrmCustomerRelation.lastOperateUserId IS '实际操作账号';
COMMENT ON COLUMN CrmCustomerRelation.businessOrgId IS '实际CRM经营组织';
COMMENT ON COLUMN CrmCustomerRelation.partnerId IS '发起方原客户稳定编号';
COMMENT ON COLUMN CrmCustomerRelation.relatedPartnerId IS '被关联方原客户稳定编号';
COMMENT ON COLUMN CrmCustomerRelation.relationName IS '用户明确填写的关系说明，不产生监护权或权限';
COMMENT ON COLUMN CrmCustomerRelation.enabledFlag IS '本关系是否启用，解除仍保留原记录';
COMMENT ON COLUMN CrmCustomerRelation.changeHistoryJson IS '追加真实操作人、原请求摘要、前后内容及首次结果版本';
COMMENT ON COLUMN CrmCustomerRelation.versionNo IS '独立关系版本，不修改客户版本';
COMMENT ON COLUMN CrmCustomerRelation.labelZh IS '中文显示名';
COMMENT ON COLUMN CrmCustomerRelation.labelJa IS '日文显示名';
COMMENT ON COLUMN CrmCustomerRelation.labelEn IS '英文显示名';
COMMENT ON COLUMN CrmCustomerRelation.status IS '原有效记录标志，不用于解除关系';
COMMENT ON COLUMN CrmCustomerRelation.sortnum IS '显示顺序';
COMMENT ON COLUMN CrmCustomerRelation.createdAt IS '首次建立时间';
COMMENT ON COLUMN CrmCustomerRelation.updatedAt IS '最后变更时间';
