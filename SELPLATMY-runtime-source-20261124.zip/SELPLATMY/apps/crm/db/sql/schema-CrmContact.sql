-- 本域客户维护首步；仅显式内存测试初始化，不执行目标整包DDL或旧SQL。
CREATE TABLE IF NOT EXISTS CrmContact (
    id BIGINT NOT NULL CHECK(id>0),
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN (0,1)),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    partnerId BIGINT NOT NULL,contactName VARCHAR(100) NOT NULL CHECK(LENGTH(TRIM(contactName))>0),
    mobile VARCHAR(50),organizationText VARCHAR(200),
    businessState VARCHAR(30) NOT NULL CHECK(businessState IN ('ACTIVE','INACTIVE','MIGRATION_PENDING')),
    versionNo BIGINT NOT NULL CHECK(versionNo>=0),
    FOREIGN KEY(tenantId,businessOrgId,partnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id)
);
