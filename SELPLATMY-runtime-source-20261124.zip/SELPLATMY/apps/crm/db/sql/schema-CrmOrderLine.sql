-- 本域订单小步schema，仅显式双mem测试初始化；不是全库DDL或历史迁移。
CREATE TABLE IF NOT EXISTS CrmOrderLine(
id BIGINT NOT NULL CHECK(id>0),tenantId BIGINT NOT NULL CHECK(tenantId>0),businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(tenantId,businessOrgId,id),
orderId BIGINT NOT NULL,currencyScale INTEGER NOT NULL CHECK(currencyScale IN(0,2)),lineNo INTEGER NOT NULL CHECK(lineNo>0),productId BIGINT NOT NULL,productNameSnapshot VARCHAR(200) NOT NULL,unitCode VARCHAR(10) NOT NULL CHECK(unitCode='EA'),quantity BIGINT NOT NULL CHECK(quantity>0),unitPriceMinor DECIMAL(38,0) NOT NULL CHECK(unitPriceMinor>=0),discountBps INTEGER NOT NULL CHECK(discountBps BETWEEN 0 AND 10000),isGift BOOLEAN NOT NULL,
grossMinor DECIMAL(38,0) NOT NULL CHECK(grossMinor>=0),lineDiscountMinor DECIMAL(38,0) NOT NULL CHECK(lineDiscountMinor>=0),lineNetMinor DECIMAL(38,0) NOT NULL CHECK(lineNetMinor>=0),feeAllocatedMinor DECIMAL(38,0) NOT NULL CHECK(feeAllocatedMinor>=0),approvedDueMinor DECIMAL(38,0) NOT NULL CHECK(approvedDueMinor>=0),refundableGoodsMinor DECIMAL(38,0) NOT NULL CHECK(refundableGoodsMinor>=0),refundableFeeMinor DECIMAL(38,0) NOT NULL CHECK(refundableFeeMinor=0),refundPolicyVersion VARCHAR(30) NOT NULL CHECK(refundPolicyVersion='GOODS_ONLY_V1'),
UNIQUE(tenantId,businessOrgId,orderId,lineNo),UNIQUE(tenantId,businessOrgId,orderId,id),
FOREIGN KEY(tenantId,businessOrgId,orderId) REFERENCES CrmOrder(tenantId,businessOrgId,id),FOREIGN KEY(tenantId,businessOrgId,productId) REFERENCES CrmProduct(tenantId,businessOrgId,id),
CHECK(grossMinor=quantity*unitPriceMinor AND lineNetMinor=grossMinor-lineDiscountMinor AND approvedDueMinor=lineNetMinor+feeAllocatedMinor AND refundableGoodsMinor=lineNetMinor),CHECK((isGift=TRUE AND unitPriceMinor=0 AND discountBps=0) OR (isGift=FALSE AND unitPriceMinor>0))
);
