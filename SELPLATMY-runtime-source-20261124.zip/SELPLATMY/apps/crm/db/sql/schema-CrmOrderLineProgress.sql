-- 单一销售出库隔离结构；不承载历史迁移/资金/退货/冲销；仅专用双mem初始化。
CREATE TABLE IF NOT EXISTS CrmOrderLineProgress (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    businessOrgId BIGINT NOT NULL,
    createdByUserId BIGINT NOT NULL CHECK (createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK (updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK (lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    orderLineId BIGINT NOT NULL,
    authorizedQuantity BIGINT NOT NULL CHECK (authorizedQuantity BETWEEN 0 AND 999999999),
    authorizedMinor DECIMAL(38,0) NOT NULL CHECK (authorizedMinor>=0),
    refundableGoodsMinor DECIMAL(38,0) NOT NULL CHECK (refundableGoodsMinor BETWEEN 0 AND authorizedMinor),
    refundPolicyVersion VARCHAR(40) NOT NULL CHECK (refundPolicyVersion IN ('GOODS_ONLY_V1','CONTINUATION_NO_REFUND_V1')),
    stockPostedQuantity BIGINT NOT NULL CHECK (stockPostedQuantity>=0),
    stockReturnedQuantity BIGINT NOT NULL CHECK (stockReturnedQuantity>=0),
    cashSettledMinor DECIMAL(38,0) NOT NULL CHECK (cashSettledMinor>=0),
    cashRefundedMinor DECIMAL(38,0) NOT NULL CHECK (cashRefundedMinor>=0),
    courseRefundedMinor DECIMAL(38,0) NOT NULL DEFAULT 0,
    lastReturnDetailId BIGINT,
    versionNo BIGINT NOT NULL CHECK (versionNo>=0),
    PRIMARY KEY (tenantId,businessOrgId,id),
    CHECK (tenantId>0 AND businessOrgId>0 AND id>0),
    FOREIGN KEY (tenantId,businessOrgId,orderLineId) REFERENCES CrmOrderLine(tenantId,businessOrgId,id),
    FOREIGN KEY (tenantId,businessOrgId,lastReturnDetailId) REFERENCES CrmPostingDetail(tenantId,businessOrgId,id),
    UNIQUE (tenantId,businessOrgId,orderLineId),
    CHECK (stockReturnedQuantity<=stockPostedQuantity AND stockPostedQuantity<=authorizedQuantity),
    CHECK (cashRefundedMinor<=cashSettledMinor AND cashSettledMinor<=authorizedMinor),
    CHECK (refundPolicyVersion<>'CONTINUATION_NO_REFUND_V1' OR (refundableGoodsMinor=0 AND cashRefundedMinor=0)),
    CHECK ((authorizedQuantity>0 AND CAST(cashRefundedMinor AS DECIMAL(48,0))*authorizedQuantity<=CAST(refundableGoodsMinor AS DECIMAL(48,0))*stockReturnedQuantity) OR (authorizedQuantity=0 AND stockReturnedQuantity=0 AND cashRefundedMinor=0))
);

-- 课程退款累计归属原资金进度；旧行补零保留原商品退款、实收、版本与游标。
ALTER TABLE CrmOrderLineProgress ADD COLUMN IF NOT EXISTS courseRefundedMinor DECIMAL(38,0) NOT NULL DEFAULT 0;
-- 商品与课程合计不得超过原实收；课程只用原商品净额且不能与库存退货混算。
ALTER TABLE CrmOrderLineProgress ADD CONSTRAINT IF NOT EXISTS ck_crm_progress_course_refund
CHECK(courseRefundedMinor>=0 AND cashRefundedMinor+courseRefundedMinor<=cashSettledMinor
 AND courseRefundedMinor<=refundableGoodsMinor
 AND (courseRefundedMinor=0 OR (refundPolicyVersion='GOODS_ONLY_V1' AND stockReturnedQuantity=0 AND cashRefundedMinor=0)));
COMMENT ON COLUMN CrmOrderLineProgress.courseRefundedMinor IS '原课程退款累计最小币种单位，与商品退款分别记数且合计不超过原实收';
