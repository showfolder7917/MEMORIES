-- 本域客户维护首步；仅显式内存测试初始化，不执行目标整包DDL或旧SQL。
CREATE TABLE IF NOT EXISTS CrmPartner (
    id BIGINT NOT NULL CHECK(id>0),
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN (0,1)),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    partnerKind VARCHAR(10) NOT NULL CHECK(partnerKind IN ('ORG','PERSON')),
    partnerName VARCHAR(200) NOT NULL CHECK(LENGTH(TRIM(partnerName))>0),
    customerRole BOOLEAN NOT NULL,supplierRole BOOLEAN NOT NULL,
    receiverName VARCHAR(100),mobile VARCHAR(50),address VARCHAR(1000),email VARCHAR(200),
    businessState VARCHAR(30) NOT NULL CHECK(businessState IN ('ACTIVE','INACTIVE','MIGRATION_PENDING')),
    versionNo BIGINT NOT NULL CHECK(versionNo>=0),
    CHECK(customerRole OR supplierRole)
);

-- 归档独立于原业务启停；兼容新增，原客户均保持未归档，不重写原业务字段。
ALTER TABLE CrmPartner ADD COLUMN IF NOT EXISTS archivedFlag BOOLEAN DEFAULT FALSE NOT NULL;
ALTER TABLE CrmPartner ADD COLUMN IF NOT EXISTS archiveReasonText VARCHAR(200);
ALTER TABLE CrmPartner ADD COLUMN IF NOT EXISTS archivedByUserId BIGINT;
ALTER TABLE CrmPartner ADD COLUMN IF NOT EXISTS archivedAt TIMESTAMP WITH TIME ZONE;
ALTER TABLE CrmPartner ADD CONSTRAINT IF NOT EXISTS CK_CRM_PARTNER_ARCHIVE_DETAILS
    CHECK (archivedFlag=FALSE OR (archiveReasonText IS NOT NULL AND LENGTH(TRIM(archiveReasonText))>0
        AND archivedByUserId IS NOT NULL AND archivedByUserId>0 AND archivedAt IS NOT NULL));
COMMENT ON COLUMN CrmPartner.archivedFlag IS '是否归档；独立于原客户业务启停状态';
COMMENT ON COLUMN CrmPartner.archiveReasonText IS '最近一次明确确认的归档原因；恢复不抹除历史';
COMMENT ON COLUMN CrmPartner.archivedByUserId IS '最近一次归档的真实统一账号编号';
COMMENT ON COLUMN CrmPartner.archivedAt IS '最近一次归档的服务器提交时间';
