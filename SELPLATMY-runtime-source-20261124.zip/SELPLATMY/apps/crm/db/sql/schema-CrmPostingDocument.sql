-- CRM 新开发隔离过账结构；不是旧 SQL 或生产迁移。
CREATE TABLE IF NOT EXISTS CrmPostingDocument (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200), labelJa VARCHAR(200), labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    kind VARCHAR(24) NOT NULL CHECK (kind IN ('SALES_ORDER','PURCHASE_ORDER','SALES_RETURN','STOCK_ISSUE','STOCK_RECEIPT','FUNDS_RECEIPT','FUNDS_PAYMENT')),
    documentState VARCHAR(20) NOT NULL CHECK (documentState IN ('DRAFT','SUBMITTED','APPROVED','REJECTED','CANCELLED','POSTED','REVERSED')),
    versionNo BIGINT NOT NULL DEFAULT 0 CHECK (versionNo >= 0),
    origin VARCHAR(20) NOT NULL CHECK (origin IN ('NEW','HISTORICAL')),
    customerId BIGINT, sourceDocumentId BIGINT,
    warehouseId BIGINT, productId BIGINT, quantity BIGINT, quantityUnit VARCHAR(10),
    accountId BIGINT, accountKind VARCHAR(20), amount DECIMAL(38,8), currency VARCHAR(3), amountUnit VARCHAR(10),
    PRIMARY KEY (tenantId,ownerUserId,id),
    FOREIGN KEY (tenantId,ownerUserId,customerId) REFERENCES CrmCustomerDraft(tenantId,ownerUserId,id),
    FOREIGN KEY (tenantId,ownerUserId,sourceDocumentId) REFERENCES CrmPostingDocument(tenantId,ownerUserId,id),
    CHECK ((kind IN ('SALES_ORDER','PURCHASE_ORDER','SALES_RETURN') AND sourceDocumentId IS NULL)
        OR (kind IN ('STOCK_ISSUE','STOCK_RECEIPT','FUNDS_RECEIPT','FUNDS_PAYMENT') AND sourceDocumentId IS NOT NULL)),
    CHECK (kind NOT IN ('STOCK_ISSUE','STOCK_RECEIPT') OR (warehouseId IS NOT NULL AND productId IS NOT NULL AND quantity IS NOT NULL AND quantityUnit IS NOT NULL AND warehouseId > 0 AND productId > 0 AND quantity BETWEEN 1 AND 999999999 AND quantityUnit='EA' AND accountId IS NULL AND amount IS NULL)),
    CHECK (kind NOT IN ('FUNDS_RECEIPT','FUNDS_PAYMENT') OR (accountKind IS NOT NULL AND accountKind='CASH' AND accountId IS NOT NULL AND amount IS NOT NULL AND amountUnit IS NOT NULL AND accountId > 0 AND amount > 0 AND currency IS NOT NULL AND amountUnit IN ('MAJOR','MINOR') AND warehouseId IS NULL AND quantity IS NULL))
);
