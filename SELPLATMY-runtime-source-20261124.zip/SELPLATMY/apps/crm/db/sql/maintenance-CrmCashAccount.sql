-- 账务账户维护的幂等与追加审计元数据；不修改账户、币种、余额或历史单据。
ALTER TABLE CrmCashAccount ADD COLUMN IF NOT EXISTS creationRequestKey VARCHAR(64);
ALTER TABLE CrmCashAccount ADD COLUMN IF NOT EXISTS creationHash VARCHAR(64);
ALTER TABLE CrmCashAccount ADD COLUMN IF NOT EXISTS changeHistoryJson TEXT DEFAULT '[]' NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS crm_cash_account_creation_request ON CrmCashAccount(tenantId,businessOrgId,creationRequestKey);
COMMENT ON COLUMN CrmCashAccount.creationRequestKey IS '原组织内创建请求；旧账户保持空，不伪造历史';
COMMENT ON COLUMN CrmCashAccount.creationHash IS '服务端首次正文和实际操作者摘要；不接受客户端覆盖';
COMMENT ON COLUMN CrmCashAccount.changeHistoryJson IS '追加保存账户名称与启停前后值、原因、实际操作者、资格依据和原版本回执';
