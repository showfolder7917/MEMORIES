-- 本表只在专用新隔离附件测试结构创建（双file另需实际源标记）；正文归文件服务，不复制旧数据或迁移既有数据库。
CREATE TABLE IF NOT EXISTS CrmOrderAttachment (
    id BIGINT NOT NULL CHECK(id>0), -- 由CrmOrderAttachmentId号段生成
    tenantId BIGINT NOT NULL CHECK(tenantId>0), -- 实际Session租户
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0), -- 实际订单动作范围
    ownerUserId BIGINT NOT NULL CHECK(ownerUserId>0), -- 当前上传者，不接受客户端归属
    orderId BIGINT NOT NULL CHECK(orderId>0), -- owning订单精确范围主键
    orderVersion BIGINT NOT NULL CHECK(orderVersion>=0), -- 本次引用核验时的真实订单版本
    fileId VARCHAR(32) NOT NULL CHECK(REGEXP_LIKE(fileId,'^[0-9a-f]{32}$')), -- 文件服务不可变ID
    sha256 VARCHAR(64) NOT NULL CHECK(REGEXP_LIKE(sha256,'^[0-9a-f]{64}$')), -- 已由同Host概要精确核验的正文摘要
    byteSize BIGINT NOT NULL CHECK(byteSize>0), -- 精确正文长度，不允许浮点
    versionNo BIGINT NOT NULL CHECK(versionNo>0), -- 附件独立CAS版本，首次为1
    commandRequestId BIGINT NOT NULL, -- 最后成功命令；完整历史保留在请求/业务审计
    createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0), -- 实际创建账号
    updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0), -- 实际本次账号
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0), -- 公共审计字段
    status INTEGER NOT NULL DEFAULT 1 CHECK(status=1), -- 当前不开放删除/失效命令
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0, -- 公共分页稳定排序
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 首次关联时间
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP, -- 最后CAS成功时间
    PRIMARY KEY(tenantId,businessOrgId,id), -- 业务精确范围身份
    FOREIGN KEY(tenantId,businessOrgId,orderId) REFERENCES CrmOrder(tenantId,businessOrgId,id), -- 不允许孤立订单引用
    FOREIGN KEY(tenantId,businessOrgId,commandRequestId) REFERENCES CrmCommandRequest(tenantId,businessOrgId,id), -- 与真实命令同事务
    UNIQUE(tenantId,businessOrgId,orderId,ownerUserId,fileId) -- 同一上传者在订单中不重复关联同一文件
);
COMMENT ON TABLE CrmOrderAttachment IS '当前上传者的订单附件引用；正文归独立文件服务，独立CAS不修改订单冻结正文';
COMMENT ON COLUMN CrmOrderAttachment.id IS '公共号段生成的附件引用主键';
COMMENT ON COLUMN CrmOrderAttachment.tenantId IS '当前真实Session租户';
COMMENT ON COLUMN CrmOrderAttachment.businessOrgId IS '订单动作实际经营组织';
COMMENT ON COLUMN CrmOrderAttachment.ownerUserId IS '文件当前上传者账号';
COMMENT ON COLUMN CrmOrderAttachment.orderId IS '同租户同组织实际订单主键';
COMMENT ON COLUMN CrmOrderAttachment.orderVersion IS '本次引用核验的真实订单版本';
COMMENT ON COLUMN CrmOrderAttachment.fileId IS '文件服务不可变32位ID';
COMMENT ON COLUMN CrmOrderAttachment.sha256 IS '同Host实际metadata核对的正文SHA256';
COMMENT ON COLUMN CrmOrderAttachment.byteSize IS '已核对的精确正整数正文长度';
COMMENT ON COLUMN CrmOrderAttachment.versionNo IS '独立附件CAS版本，首次1';
COMMENT ON COLUMN CrmOrderAttachment.commandRequestId IS '最后成功命令主键，历史由请求与审计永久保存';
COMMENT ON COLUMN CrmOrderAttachment.createdByUserId IS '实际创建账号';
COMMENT ON COLUMN CrmOrderAttachment.updatedByUserId IS '实际本次修改账号';
COMMENT ON COLUMN CrmOrderAttachment.lastOperateUserId IS '公共操作账号';
COMMENT ON COLUMN CrmOrderAttachment.status IS '有效状态，当前不开放删除';
COMMENT ON COLUMN CrmOrderAttachment.sortnum IS '公共分页排序';
COMMENT ON COLUMN CrmOrderAttachment.createdAt IS '首次关联时间';
COMMENT ON COLUMN CrmOrderAttachment.updatedAt IS '最后CAS成功时间';
