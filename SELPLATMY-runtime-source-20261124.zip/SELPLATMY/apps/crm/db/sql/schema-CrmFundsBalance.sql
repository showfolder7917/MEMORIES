-- CRM 新开发隔离过账结构；不是旧 SQL 或生产迁移。
CREATE TABLE IF NOT EXISTS CrmFundsBalance (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200), labelJa VARCHAR(200), labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    accountId BIGINT NOT NULL CHECK (accountId > 0),
    accountKind VARCHAR(20) NOT NULL CHECK (accountKind='CASH'),
    currency VARCHAR(3) NOT NULL,
    amountUnit VARCHAR(10) NOT NULL CHECK (amountUnit IN ('MAJOR','MINOR')),
    openingAmount DECIMAL(38,8) NOT NULL CHECK (openingAmount >= 0),
    amount DECIMAL(38,8) NOT NULL CHECK (amount >= 0),
    versionNo BIGINT NOT NULL DEFAULT 0 CHECK (versionNo >= 0),
    PRIMARY KEY (tenantId,ownerUserId,id),
    UNIQUE (tenantId,ownerUserId,accountId,currency,amountUnit)
);
