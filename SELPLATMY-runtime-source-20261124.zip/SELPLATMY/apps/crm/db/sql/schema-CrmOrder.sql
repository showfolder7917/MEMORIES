-- 本域订单小步schema，仅显式双mem测试初始化；不是全库DDL或历史迁移。
CREATE TABLE IF NOT EXISTS CrmOrder(
id BIGINT NOT NULL CHECK(id>0),tenantId BIGINT NOT NULL CHECK(tenantId>0),businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(tenantId,businessOrgId,id),
UNIQUE(tenantId,businessOrgId,id,orderKind),UNIQUE(tenantId,businessOrgId,id,currency),
orderKind VARCHAR(20) NOT NULL CHECK(orderKind IN('SALES','PURCHASE')),partnerId BIGINT NOT NULL,
orderState VARCHAR(20) NOT NULL CHECK(orderState IN('DRAFT','SUBMITTED','APPROVED')),versionNo BIGINT NOT NULL CHECK(versionNo>=0),
currency VARCHAR(3) NOT NULL CHECK(currency IN('CNY','USD','JPY')),currencyScale INTEGER NOT NULL CHECK(currencyScale IN(0,2)),pricingPolicyVersion VARCHAR(30) NOT NULL CHECK(pricingPolicyVersion='MONEY_V1'),refundPolicyVersion VARCHAR(30) NOT NULL CHECK(refundPolicyVersion='GOODS_ONLY_V1'),
subtotalMinor DECIMAL(38,0) NOT NULL CHECK(subtotalMinor>=0),discountMinor DECIMAL(38,0) NOT NULL CHECK(discountMinor>=0),feeMinor DECIMAL(38,0) NOT NULL CHECK(feeMinor>=0),totalMinor DECIMAL(38,0) NOT NULL CHECK(totalMinor>=0),refundableGoodsMinor DECIMAL(38,0) NOT NULL CHECK(refundableGoodsMinor>=0),refundableFeeMinor DECIMAL(38,0) NOT NULL CHECK(refundableFeeMinor=0),
submittedByUserId BIGINT,approvedByUserId BIGINT,submittedAt TIMESTAMP WITH TIME ZONE,approvedAt TIMESTAMP WITH TIME ZONE,snapshotHash VARCHAR(64),frozenSnapshot CLOB,
FOREIGN KEY(tenantId,businessOrgId,partnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id),
CHECK(totalMinor=subtotalMinor-discountMinor+feeMinor AND refundableGoodsMinor=subtotalMinor-discountMinor),
CHECK((orderState='DRAFT' AND submittedByUserId IS NULL AND approvedByUserId IS NULL AND submittedAt IS NULL AND approvedAt IS NULL AND snapshotHash IS NULL AND frozenSnapshot IS NULL)
 OR (orderState='SUBMITTED' AND submittedByUserId IS NOT NULL AND submittedByUserId>0 AND submittedAt IS NOT NULL AND approvedByUserId IS NULL AND approvedAt IS NULL AND snapshotHash IS NULL AND frozenSnapshot IS NULL)
 OR (orderState='APPROVED' AND submittedByUserId IS NOT NULL AND approvedByUserId IS NOT NULL AND submittedByUserId>0 AND approvedByUserId>0 AND submittedByUserId<>approvedByUserId AND submittedAt IS NOT NULL AND approvedAt IS NOT NULL AND snapshotHash IS NOT NULL AND frozenSnapshot IS NOT NULL))
);
