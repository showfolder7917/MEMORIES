-- CRM 新开发隔离过账结构；不是旧 SQL 或生产迁移。
CREATE TABLE IF NOT EXISTS CrmStockBalance (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200), labelJa VARCHAR(200), labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    warehouseId BIGINT NOT NULL CHECK (warehouseId > 0),
    productId BIGINT NOT NULL CHECK (productId > 0),
    quantityUnit VARCHAR(10) NOT NULL CHECK (quantityUnit='EA'),
    openingQuantity BIGINT NOT NULL CHECK (openingQuantity >= 0),
    quantity BIGINT NOT NULL CHECK (quantity >= 0),
    versionNo BIGINT NOT NULL DEFAULT 0 CHECK (versionNo >= 0),
    PRIMARY KEY (tenantId,ownerUserId,id),
    UNIQUE (tenantId,ownerUserId,warehouseId,productId,quantityUnit)
);
