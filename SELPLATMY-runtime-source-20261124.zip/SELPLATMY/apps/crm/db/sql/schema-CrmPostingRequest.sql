-- CRM 新开发隔离过账结构；不是旧 SQL 或生产迁移。
CREATE TABLE IF NOT EXISTS CrmPostingRequest (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200), labelJa VARCHAR(200), labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    documentId BIGINT NOT NULL,
    action VARCHAR(10) NOT NULL,
    requestKey VARCHAR(64) NOT NULL,
    payloadHash VARCHAR(64) NOT NULL,
    requestState VARCHAR(16) NOT NULL CHECK (requestState IN ('OPEN','COMPLETED')),
    resultEntryId BIGINT, resultState VARCHAR(20),
    PRIMARY KEY (tenantId,ownerUserId,id),
    UNIQUE (tenantId,ownerUserId,action,requestKey),
    FOREIGN KEY (tenantId,ownerUserId,documentId) REFERENCES CrmPostingDocument(tenantId,ownerUserId,id),
    FOREIGN KEY (tenantId,ownerUserId,resultEntryId) REFERENCES CrmPostingEntry(tenantId,ownerUserId,id),
    CHECK (requestState='OPEN' OR resultState IS NOT NULL)
);
