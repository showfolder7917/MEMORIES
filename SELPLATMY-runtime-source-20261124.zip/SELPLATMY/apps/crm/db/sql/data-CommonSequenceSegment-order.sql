-- 仅隔离订单技术号段，无商品/订单业务种子。
INSERT INTO CommonSequenceSegment(tenantId,lastOperateUserId,seqCode,seqName,nextStartId,stepSize,versionNo,status) SELECT 0,0,'CrmProductId','CrmProductId',700000,20,0,1 WHERE NOT EXISTS(SELECT 1 FROM CommonSequenceSegment WHERE seqCode='CrmProductId');
INSERT INTO CommonSequenceSegment(tenantId,lastOperateUserId,seqCode,seqName,nextStartId,stepSize,versionNo,status) SELECT 0,0,'CrmOrderId','CrmOrderId',600000,20,0,1 WHERE NOT EXISTS(SELECT 1 FROM CommonSequenceSegment WHERE seqCode='CrmOrderId');
INSERT INTO CommonSequenceSegment(tenantId,lastOperateUserId,seqCode,seqName,nextStartId,stepSize,versionNo,status) SELECT 0,0,'CrmOrderLineId','CrmOrderLineId',600000,20,0,1 WHERE NOT EXISTS(SELECT 1 FROM CommonSequenceSegment WHERE seqCode='CrmOrderLineId');
