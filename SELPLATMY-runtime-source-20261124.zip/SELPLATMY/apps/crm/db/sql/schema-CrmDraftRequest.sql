-- 本域新建私人草稿结构；不含旧源数据，不是生产迁移。
CREATE TABLE IF NOT EXISTS CrmDraftRequest (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    operation VARCHAR(32) NOT NULL,
    requestKey VARCHAR(64) NOT NULL,
    payloadHash CHAR(64) NOT NULL,
    resultId BIGINT,
    requestState VARCHAR(20) NOT NULL DEFAULT 'OPEN' CHECK (requestState IN ('OPEN','COMPLETED')),
    PRIMARY KEY (tenantId, ownerUserId, id),
    UNIQUE (tenantId, ownerUserId, operation, requestKey)
);
