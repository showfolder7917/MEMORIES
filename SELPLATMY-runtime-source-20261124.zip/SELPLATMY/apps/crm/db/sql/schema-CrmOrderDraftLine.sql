-- 本域新建私人草稿结构；不含旧源数据，不是生产迁移。
CREATE TABLE IF NOT EXISTS CrmOrderDraftLine (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    orderId BIGINT NOT NULL,
    productName VARCHAR(200) NOT NULL,
    quantity BIGINT NOT NULL CHECK (quantity BETWEEN 1 AND 999999999),
    priceNote VARCHAR(500),
    PRIMARY KEY (tenantId, ownerUserId, id),
    FOREIGN KEY (tenantId, ownerUserId, orderId) REFERENCES CrmOrderDraft (tenantId, ownerUserId, id)
);
