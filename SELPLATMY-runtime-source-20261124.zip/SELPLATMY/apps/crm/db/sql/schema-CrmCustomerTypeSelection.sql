-- 客户多类型选择附加表；不回填旧客户，不建立权限。
CREATE TABLE IF NOT EXISTS CrmCustomerTypeSelection (
    id BIGINT NOT NULL CHECK(id>0),
    code VARCHAR(100) NOT NULL UNIQUE,
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    partnerId BIGINT NOT NULL CHECK(partnerId>0),
    typeIdsJson VARCHAR(2000) NOT NULL,
    changeHistoryJson TEXT NOT NULL,
    versionNo BIGINT NOT NULL CHECK(versionNo>0),
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    UNIQUE(tenantId,businessOrgId,partnerId),
    FOREIGN KEY(tenantId,businessOrgId,partnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id)
);
COMMENT ON TABLE CrmCustomerTypeSelection IS '客户独立多类型集合与变更历史，不覆盖原客户资料';
COMMENT ON COLUMN CrmCustomerTypeSelection.id IS '公共CrmCustomerTypeSelectionId号段主键';
COMMENT ON COLUMN CrmCustomerTypeSelection.code IS '服务端生成的不可变编码';
COMMENT ON COLUMN CrmCustomerTypeSelection.tenantId IS '实际租户';
COMMENT ON COLUMN CrmCustomerTypeSelection.lastOperateUserId IS '实际最后操作账号';
COMMENT ON COLUMN CrmCustomerTypeSelection.businessOrgId IS '实际CRM经营组织';
COMMENT ON COLUMN CrmCustomerTypeSelection.partnerId IS '原客户稳定主键，不使用姓名关联';
COMMENT ON COLUMN CrmCustomerTypeSelection.typeIdsJson IS '有界升序类型主键集合，停用可保留原引用';
COMMENT ON COLUMN CrmCustomerTypeSelection.changeHistoryJson IS '追加请求摘要、前后集合、原结果版本和真实操作人';
COMMENT ON COLUMN CrmCustomerTypeSelection.versionNo IS '独立分类版本，不修改原客户版本';
COMMENT ON COLUMN CrmCustomerTypeSelection.labelZh IS '中文显示名';
COMMENT ON COLUMN CrmCustomerTypeSelection.labelJa IS '日文显示名';
COMMENT ON COLUMN CrmCustomerTypeSelection.labelEn IS '英文显示名';
COMMENT ON COLUMN CrmCustomerTypeSelection.status IS '有效记录标志';
COMMENT ON COLUMN CrmCustomerTypeSelection.sortnum IS '显示顺序';
COMMENT ON COLUMN CrmCustomerTypeSelection.createdAt IS '首次选择时间';
COMMENT ON COLUMN CrmCustomerTypeSelection.updatedAt IS '最后修改时间';
