-- 本域客户及订单维护小步；仅显式双mem测试初始化，不执行目标整包DDL或旧SQL。
CREATE TABLE IF NOT EXISTS CrmCommandRequest (
    id BIGINT NOT NULL CHECK(id>0),
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN (0,1)),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    commandName VARCHAR(80) NOT NULL CHECK(commandName IN ('PRODUCT_SAVE','PARTNER_SAVE','CONTACT_SAVE','ORDER_SAVE','ORDER_SUBMIT','ORDER_APPROVE','DOCUMENT_SAVE','DOCUMENT_SUBMIT','DOCUMENT_APPROVE','FUNDS_DOCUMENT_SAVE','FUNDS_DOCUMENT_SUBMIT','FUNDS_DOCUMENT_APPROVE')),
    requestKey VARCHAR(64) NOT NULL,payloadHash VARCHAR(64) NOT NULL,
    requestState VARCHAR(20) NOT NULL CHECK(requestState IN ('OPEN','COMPLETED')),
    resultProductId BIGINT,resultPartnerId BIGINT,resultContactId BIGINT,resultOrderId BIGINT,resultDocumentId BIGINT,resultVersionNo BIGINT,responseSnapshot CLOB,
    UNIQUE(tenantId,businessOrgId,commandName,requestKey),
    FOREIGN KEY(tenantId,businessOrgId,resultProductId) REFERENCES CrmProduct(tenantId,businessOrgId,id),
    FOREIGN KEY(tenantId,businessOrgId,resultPartnerId) REFERENCES CrmPartner(tenantId,businessOrgId,id),
    FOREIGN KEY(tenantId,businessOrgId,resultContactId) REFERENCES CrmContact(tenantId,businessOrgId,id),
    FOREIGN KEY(tenantId,businessOrgId,resultOrderId) REFERENCES CrmOrder(tenantId,businessOrgId,id),
    FOREIGN KEY(tenantId,businessOrgId,resultDocumentId) REFERENCES CrmDocument(tenantId,businessOrgId,id),
    CHECK((requestState='OPEN' AND resultProductId IS NULL AND resultPartnerId IS NULL AND resultContactId IS NULL AND resultOrderId IS NULL AND resultDocumentId IS NULL AND resultVersionNo IS NULL AND responseSnapshot IS NULL)
       OR (requestState='COMPLETED' AND resultVersionNo IS NOT NULL AND resultVersionNo>=0 AND responseSnapshot IS NOT NULL AND
          ((commandName='PRODUCT_SAVE' AND resultProductId IS NOT NULL AND resultPartnerId IS NULL AND resultContactId IS NULL AND resultOrderId IS NULL AND resultDocumentId IS NULL) OR (commandName='PARTNER_SAVE' AND resultProductId IS NULL AND resultPartnerId IS NOT NULL AND resultContactId IS NULL AND resultOrderId IS NULL AND resultDocumentId IS NULL)
           OR (commandName='CONTACT_SAVE' AND resultProductId IS NULL AND resultContactId IS NOT NULL AND resultPartnerId IS NULL AND resultOrderId IS NULL AND resultDocumentId IS NULL)
           OR (commandName IN('ORDER_SAVE','ORDER_SUBMIT','ORDER_APPROVE') AND resultProductId IS NULL AND resultOrderId IS NOT NULL AND resultPartnerId IS NULL AND resultContactId IS NULL AND resultDocumentId IS NULL)
           OR (commandName IN('DOCUMENT_SAVE','DOCUMENT_SUBMIT','DOCUMENT_APPROVE','FUNDS_DOCUMENT_SAVE','FUNDS_DOCUMENT_SUBMIT','FUNDS_DOCUMENT_APPROVE') AND resultProductId IS NULL AND resultDocumentId IS NOT NULL AND resultOrderId IS NULL AND resultPartnerId IS NULL AND resultContactId IS NULL))))
);
