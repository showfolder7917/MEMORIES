-- 本域订单小步schema，仅显式双mem测试初始化；不是全库DDL或历史迁移。
CREATE TABLE IF NOT EXISTS CrmProduct(
id BIGINT NOT NULL CHECK(id>0),tenantId BIGINT NOT NULL CHECK(tenantId>0),businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY(tenantId,businessOrgId,id),
productCode VARCHAR(64),specification VARCHAR(200),
productKind VARCHAR(10) NOT NULL DEFAULT 'GOODS' CHECK(productKind IN('GOODS','SERVICE')),
purchasePriceMinor BIGINT NOT NULL DEFAULT 0 CHECK(purchasePriceMinor BETWEEN 0 AND 999999999999),
salePriceMinor BIGINT NOT NULL DEFAULT 0 CHECK(salePriceMinor BETWEEN 0 AND 999999999999),
activationSystemCode VARCHAR(64),
termUnit VARCHAR(10) NOT NULL DEFAULT 'NONE' CHECK(termUnit IN('NONE','DAY','MONTH','YEAR')),
termCount INTEGER NOT NULL DEFAULT 0 CHECK(termCount BETWEEN 0 AND 120),
renewalMode VARCHAR(10) NOT NULL DEFAULT 'NONE' CHECK(renewalMode IN('NONE','MANUAL','AUTO')),
CHECK((termUnit='NONE' AND termCount=0 AND renewalMode='NONE') OR (productKind='SERVICE' AND termUnit<>'NONE' AND termCount>0 AND renewalMode IN('MANUAL','AUTO'))),
versionNo BIGINT NOT NULL DEFAULT 0 CHECK(versionNo>=0),
UNIQUE(tenantId,businessOrgId,productCode),
productName VARCHAR(200) NOT NULL CHECK(LENGTH(TRIM(productName))>0),unitCode VARCHAR(10) NOT NULL CHECK(unitCode='EA'),businessState VARCHAR(20) NOT NULL CHECK(businessState IN('ACTIVE','INACTIVE'))
);
