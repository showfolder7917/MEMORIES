-- 本域新建私人草稿结构；不含旧源数据，不是生产迁移。
CREATE TABLE IF NOT EXISTS CrmCustomerDraft (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    ownerUserId BIGINT NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    status INTEGER NOT NULL DEFAULT 1,
    createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    customerName VARCHAR(200) NOT NULL,
    contactName VARCHAR(100),
    mobile VARCHAR(50),
    organization VARCHAR(200),
    notes VARCHAR(4000),
    PRIMARY KEY (tenantId, ownerUserId, id)
);
