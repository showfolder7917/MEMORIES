-- 单一销售出库隔离结构；不承载历史迁移/资金/退货/冲销；仅专用双mem初始化。
CREATE TABLE IF NOT EXISTS CrmWarehouse (
    id BIGINT NOT NULL,
    tenantId BIGINT NOT NULL,
    businessOrgId BIGINT NOT NULL,
    createdByUserId BIGINT NOT NULL CHECK (createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK (updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK (lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK (status IN (0,1)),
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    warehouseCode VARCHAR(80) NOT NULL,
    warehouseName VARCHAR(200) NOT NULL,
    businessState VARCHAR(10) NOT NULL CHECK (businessState IN ('ACTIVE','INACTIVE')),
    versionNo BIGINT NOT NULL CHECK (versionNo>=0),
    PRIMARY KEY (tenantId,businessOrgId,id),
    CHECK (tenantId>0 AND businessOrgId>0 AND id>0),
    UNIQUE (tenantId,businessOrgId,warehouseCode)
);
