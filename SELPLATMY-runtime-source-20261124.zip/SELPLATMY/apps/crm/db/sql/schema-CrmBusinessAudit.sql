-- 本域客户维护首步；仅显式内存测试初始化，不执行目标整包DDL或旧SQL。
CREATE TABLE IF NOT EXISTS CrmBusinessAudit (
    id BIGINT NOT NULL CHECK(id>0),
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    businessOrgId BIGINT NOT NULL CHECK(businessOrgId>0),
    createdByUserId BIGINT NOT NULL CHECK(createdByUserId>0),
    updatedByUserId BIGINT NOT NULL CHECK(updatedByUserId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN (0,1)),
    labelZh VARCHAR(200),labelJa VARCHAR(200),labelEn VARCHAR(200),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(tenantId,businessOrgId,id),
    commandRequestId BIGINT NOT NULL,action VARCHAR(80) NOT NULL,
    actorUserId BIGINT NOT NULL CHECK(actorUserId>0),decisionId VARCHAR(200) NOT NULL,
    resourceId BIGINT NOT NULL,previousVersion BIGINT,newVersion BIGINT NOT NULL CHECK(newVersion>=0),
    synthetic BOOLEAN NOT NULL,
    FOREIGN KEY(tenantId,businessOrgId,commandRequestId) REFERENCES CrmCommandRequest(tenantId,businessOrgId,id),
    UNIQUE(tenantId,businessOrgId,commandRequestId)
);

-- 仅附加明确业务原因；原审计行和原库存、资金约束均保持。
ALTER TABLE CrmBusinessAudit ADD COLUMN IF NOT EXISTS reasonText VARCHAR(200);
COMMENT ON COLUMN CrmBusinessAudit.reasonText IS '具名客户归档、恢复或订单驳回原因；与原请求、真实操作者及前后版本同事务保存';
