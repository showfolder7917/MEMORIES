-- 原期初表附加资金维护来源、请求回执和不可变历史，不初始化业务记录或放宽异人审核。
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsAccountId BIGINT;
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsCurrency VARCHAR(3);
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsAmountMinor DECIMAL(38,0);
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsCreationKey VARCHAR(64);
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsCreationHash VARCHAR(64);
ALTER TABLE CrmOpeningBatch ADD COLUMN IF NOT EXISTS fundsHistoryJson TEXT DEFAULT '[]' NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS crm_opening_funds_creation ON CrmOpeningBatch(tenantId,businessOrgId,fundsCreationKey);
