/**
 * CrmDraftRequestDaoImpl.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.draftrequest.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import org.springframework.stereotype.Repository;

/** 私人请求重放记录持久化复用本域上下文及公共 DAO，归属在真实主键中。 */
@Repository
public class CrmDraftRequestDaoImpl extends CrmBaseDao implements CrmDraftRequestDao {
}
