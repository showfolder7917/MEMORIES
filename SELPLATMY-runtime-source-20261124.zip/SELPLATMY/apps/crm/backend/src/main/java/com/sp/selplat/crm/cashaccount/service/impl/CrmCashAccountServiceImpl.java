/** 单一销售收款隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
/* 修改记录：2026-10-09，Codex；缺请求先沿原真实身份与组织候选拒绝，避免空指针，不扩大许可。 */
package com.sp.selplat.crm.cashaccount.service.impl;

import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.text;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.version;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.cashaccount.dao.CrmCashAccountDao;
import com.sp.selplat.crm.cashaccount.service.CrmCashAccountService;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmCashAccountServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmCashAccountDao>
    implements CrmCashAccountService {

  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  // 原账户与追加审计同属CRM事务，不产生余额或过账。
  private final org.springframework.transaction.support.TransactionTemplate maintenance;

  /**
   * 注入真实范围入口；构造不授予权限。
   *
   * @param access 实际统一Session范围入口CrmAccessService；例如由服务核验组织901，不授予许可。
   * @param manager 原crmTransactionManager，例如同一CRM池，构造只建立模板
   */
  public CrmCashAccountServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access,
      @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
          org.springframework.transaction.PlatformTransactionManager manager) {
    this.access = access;
    maintenance = new org.springframework.transaction.support.TransactionTemplate(manager);
    maintenance.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    maintenance.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
    var scope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    // 原账户排序值相同时追加稳定主键，避免相邻页重叠或遗漏账户。
    var scoped = CrmPartnerValueSupport.page(input, scope, null);
    var page =
        getDao()
            .getPageList(
                scoped.getParamMap(),
                "sortnum desc id asc",
                scoped.getPageNo(),
                scoped.getPageSize());
    page.setRecords(page.getRecords().stream().map(row -> projection(row, false)).toList());
    return page;
  }

  /**
   * 公共真实范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 本组织有效记录；不存在统一拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
    var scope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return CrmPartnerValueSupport.result(projection(row, true));
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
    var scope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 方法作用：只凭原资金写资格维护账务账户；实际账户、请求回执和审计同一事务保存。
   *
   * @param input 原JSON候选，例如org901/codeSCHOOL-CNY/name学校现金/currencyCNY/keyaccount-1/reason建立
   * @return 真实返回示例：data.id="1600000"/versionNo="0"/replay=false。
   *     异常或副作用示例：同键异正文、重编码、旧版本、改币种或撤权拒绝；零现金变动。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult saveAccount(CommonParam input) {
    var initial =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.write");
    var normalized = normalizeAccount(input);
    // 摘要包含实际操作者，其他账号不能借猜测原请求键取得其回执。
    normalized.putParam("actorUserId", initial.get("actorUserId"));
    String hash = CrmPartnerValueSupport.hash(normalized);
    try {
      return access.executeTransaction(
          normalized.getParam("organizationCandidateId"),
          "crm.funds.write",
          maintenance,
          state -> storeAccount(normalized, hash));
    } catch (org.springframework.dao.DuplicateKeyException conflict) {
      // 唯一冲突退出失败事务后再读取真正已提交创建；不能重用失败连接。
      var scope =
          access.requireFundsScope(
              normalized.getParam("organizationCandidateId"), "crm.funds.write");
      if (normalized.getParam("id") == null) {
        var first = getDao().creation(accountScope(scope, normalized.getParam("requestKey")));
        if (first != null) {
          return accountReplay(first, hash);
        }
      }
      throw failure("CRM_ACCOUNT_CODE_EXISTS");
    }
  }

  /**
   * 方法作用：锁账户、检查原版本及不可变币种编码，追加实际变化与同请求回执。
   *
   * @param input 规范正文，例如org901/id1600000/expectedVersion0/name学校现金/stateINACTIVE
   * @param hash 服务端实际操作者和正文SHA256，例如64位十六进制
   * @return 真实返回示例：data.id="1600000"/versionNo="1"/replay=false；重试返回原版本。
   *     异常或副作用示例：审计容量或SQL失败整笔回滚，不覆盖原来源和历史。
   */
  private CommonResult storeAccount(CommonParam input, String hash) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.write");
    if (!scope.get("actorUserId").toString().equals(input.getParam("actorUserId").toString())) {
      throw failure("CRM_ACTION_FORBIDDEN");
    }
    var row = accountScope(scope, input.getParam("requestKey"));
    for (String field :
        java.util.List.of("accountCode", "accountName", "currency", "businessState")) {
      row.putParam(field, input.getParam(field));
    }
    row.putParam("actorUserId", scope.get("actorUserId"));
    row.putParam("currencyScale", "JPY".equals(input.getParam("currency")) ? 0 : 2);
    java.util.List<Map<String, Object>> history = new java.util.ArrayList<>();
    Map<String, Object> before = Map.of();
    long id;
    long next;
    boolean create = input.getParam("id") == null;
    if (create) {
      var first = getDao().creation(row);
      if (first != null) {
        return accountReplay(first, hash);
      }
      id = getSequence().get("id");
      next = 0;
      row.putParam("creationHash", hash);
    } else {
      id = positive(input.getParam("id"));
      row.putParam("id", id);
      var current = getDao().lockScoped(row);
      if (current == null) {
        throw failure("CRM_RECORD_NOT_FOUND");
      }
      history = accountHistory(current.get("changeHistoryJson"));
      for (var event : history) {
        if (input.getParam("requestKey").equals(event.get("requestKey"))) {
          if (!hash.equals(event.get("payloadHash"))) {
            throw failure("CRM_COMMAND_CONFLICT");
          }
          return accountReceipt(id, version(event.get("versionNo")), true);
        }
      }
      long previous = version(current.get("versionNo"));
      if (previous != version(input.getParam("expectedVersion")) || previous == Long.MAX_VALUE) {
        throw failure("STALE_CRM_VERSION");
      }
      if (!current.get("accountCode").equals(input.getParam("accountCode"))
          || !current.get("currency").equals(input.getParam("currency"))) {
        throw failure("CRM_ACCOUNT_SOURCE_IMMUTABLE");
      }
      before = accountValues(current);
      next = previous + 1;
      row.putParam("expectedVersion", previous);
    }
    if (history.size() >= 2000) {
      throw failure("CRM_ACCOUNT_HISTORY_LIMIT");
    }
    row.putParam("id", id);
    // 审计和原账户保存同一行、同一CAS；失败不会留下成功回执或独立半份审计。
    var event = new java.util.LinkedHashMap<String, Object>();
    event.put("requestKey", input.getParam("requestKey"));
    event.put("payloadHash", hash);
    event.put("versionNo", Long.toString(next));
    event.put("actorUserId", scope.get("actorUserId").toString());
    event.put("decisionId", scope.get("decisionId"));
    event.put("recordedAt", java.time.Instant.now().toString());
    event.put("reasonText", input.getParam("reasonText"));
    event.put("before", before);
    event.put("after", accountValues(input.getParamMap()));
    history.add(event);
    row.putParam(
        "changeHistoryJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(history));
    if (getDao().saveMaintenance(row, create) != 1) {
      throw failure("STALE_CRM_VERSION");
    }
    access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.write");
    return accountReceipt(id, next, false);
  }

  /**
   * 方法作用：规范完整维护输入，客户端余额、身份、审核依据及审计正文均不接收。
   *
   * @param input 原HTTP候选，例如org901/codeSCHOOL-CNY/currencyCNY/stateACTIVE/keyaccount-1
   * @return 真实返回示例：CommonParam含规范组织901、名称学校现金、原因建立及请求键。 异常或副作用示例：未知字段、控制字符、非法币种、旧版本或超长原因拒绝。
   */
  private static CommonParam normalizeAccount(CommonParam input) {
    if (input == null
        || !java.util.Set.of(
                "organizationCandidateId",
                "id",
                "expectedVersion",
                "requestKey",
                "accountCode",
                "accountName",
                "currency",
                "businessState",
                "reasonText")
            .containsAll(input.getParamMap().keySet())) {
      throw failure("INVALID_CRM_INPUT");
    }
    var result = new CommonParam();
    result.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
    for (String field :
        java.util.List.of(
            "accountCode",
            "accountName",
            "currency",
            "businessState",
            "requestKey",
            "reasonText")) {
      String value =
          text(
              input.getParam(field),
              field.equals("accountName") || field.equals("reasonText")
                  ? 200
                  : field.equals("accountCode") ? 80 : 64,
              true);
      if (value.chars().anyMatch(Character::isISOControl)) {
        throw failure("INVALID_CRM_INPUT");
      }
      result.putParam(field, value);
    }
    if (!result.getParam("accountCode").toString().matches("[A-Za-z0-9][A-Za-z0-9_.-]{0,79}")
        || !result.getParam("requestKey").toString().matches("[A-Za-z0-9_.:-]+")
        || !java.util.Set.of("CNY", "USD", "JPY").contains(result.getParam("currency"))
        || !java.util.Set.of("ACTIVE", "INACTIVE").contains(result.getParam("businessState"))) {
      throw failure("INVALID_CRM_INPUT");
    }
    if (input.getParam("id") != null) {
      result.putParam("id", positive(input.getParam("id")));
      result.putParam("expectedVersion", version(input.getParam("expectedVersion")));
    } else if (input.getParam("expectedVersion") != null) {
      throw failure("INVALID_CRM_VERSION");
    }
    return result;
  }

  /**
   * 方法作用：固定范围及创建键由原准入提供，不查询跨租户账户。
   *
   * @param scope 原实际范围，例如tenant92/businessOrgId901/actor9211
   * @param key 本对象原请求，例如account-1
   * @return 真实返回示例：CommonParam tenantId92/businessOrgId901/creationRequestKeyaccount-1。
   *     异常或副作用示例：纯组装，不读取客户端tenantId。
   */
  private static CommonParam accountScope(Map<String, Object> scope, Object key) {
    var row = new CommonParam();
    row.putParam("tenantId", scope.get("tenantId"));
    row.putParam("businessOrgId", scope.get("businessOrgId"));
    row.putParam("creationRequestKey", key);
    return row;
  }

  /**
   * 方法作用：同一创建键只返回首次精确版本，后续改名不重写原回执。
   *
   * @param first 原实际账户，例如id1600000/creationHash服务端64位摘要
   * @param hash 本次规范摘要，例如相同操作者与正文
   * @return 真实返回示例：data.id="1600000"/versionNo="0"/replay=true。
   *     异常或副作用示例：同键异内容或其他操作者抛CRM_COMMAND_CONFLICT。
   */
  private CommonResult accountReplay(Map<String, Object> first, String hash) {
    if (!hash.equals(first.get("creationHash"))) {
      throw failure("CRM_COMMAND_CONFLICT");
    }
    return accountReceipt(positive(first.get("id")), 0, true);
  }

  /**
   * 方法作用：只公开准确主键和首次版本结果，浏览器另读当前详情。
   *
   * @param id 原实际账户主键，例如1600000
   * @param revision 本次首次结果版本，例如0
   * @param replay 原请求回放，例如true
   * @return 真实返回示例：success=true/data={id:"1600000",versionNo:"0",replay:true}。
   *     异常或副作用示例：不标记未提交记录为成功，不改变余额。
   */
  private CommonResult accountReceipt(long id, long revision, boolean replay) {
    return CrmPartnerValueSupport.result(
        Map.of("id", Long.toString(id), "versionNo", Long.toString(revision), "replay", replay));
  }

  /**
   * 方法作用：只选账户维护事实，不把余额或内部请求复制进审计前后值。
   *
   * @param row 原实际行或规范输入，例如accountName学校现金/currencyCNY
   * @return 真实返回示例：{accountCode:SCHOOL-CNY,accountName:学校现金,currency:CNY,businessState:ACTIVE}。
   *     异常或副作用示例：纯投影，不修改原Map。
   */
  private static Map<String, Object> accountValues(Map<String, Object> row) {
    return Map.of(
        "accountCode",
        row.get("accountCode"),
        "accountName",
        row.get("accountName"),
        "currency",
        row.get("currency"),
        "businessState",
        row.get("businessState"));
  }

  /**
   * 方法作用：读取追加历史；旧账户无维护历史为空，损坏内容必须失败而非覆盖。
   *
   * @param value 原保存JSON，例如包含account-1/versionNo0的数组；旧列不存在时null
   * @return 真实返回示例：独立可追加事件列表，一条建立记录。 异常或副作用示例：无效JSON抛异常，原记录和审计不修改。
   */
  @SuppressWarnings("unchecked")
  private static java.util.List<Map<String, Object>> accountHistory(Object value) {
    if (value == null) {
      return new java.util.ArrayList<>();
    }
    return new java.util.ArrayList<>(
        (java.util.List<Map<String, Object>>)
            (java.util.List<?>)
                com.sp.selplat.common.util.JsonUtils.fromJson(
                    value.toString(), java.util.List.class));
  }

  /**
   * 方法作用：保留原账户公开字段，但剔除内部幂等摘要及请求键；详情仅返回可读审计。
   *
   * @param row 原账户行，例如id1600000及changeHistoryJson建立记录
   * @param detail true包含安全history，false为原列表不含历史
   * @return 真实返回示例：id="1600000"/accountName学校现金；详情history一条含原因及前后值。
   *     异常或副作用示例：纯映射，不返回creationHash或历史payloadHash/requestKey。
   */
  private static Map<String, Object> projection(Map<String, Object> row, boolean detail) {
    var result = new java.util.LinkedHashMap<>(CrmStockValueSupport.browser(row));
    for (String field :
        java.util.List.of("creationRequestKey", "creationHash", "changeHistoryJson")) {
      result.remove(field);
    }
    if (detail) {
      result.put(
          "history",
          accountHistory(row.get("changeHistoryJson")).stream()
              .map(
                  event -> {
                    var safe = new java.util.LinkedHashMap<>(event);
                    safe.remove("requestKey");
                    safe.remove("payloadHash");
                    safe.remove("decisionId");
                    return safe;
                  })
              .toList());
    }
    return result;
  }
}
