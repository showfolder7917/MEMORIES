/** CrmContactDaoImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
package com.sp.selplat.crm.contact.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/** 本表固定参数化SQL，CRUD/号段复用公共DAO，数据库约束保护同组织关系。 */
@Repository
public class CrmContactDaoImpl extends CrmBaseDao implements CrmContactDao {
    /**
     * 保留默认sortnum主排序，以组织内唯一id稳定读取同值页，不改变客户角色或关联范围。
     *
     * @param conditions 原服务可信条件，例如tenantId=92/businessOrgId=901/status=1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 公共真实页，例如totalCount=2/pageNo=2/records含第二条本组织记录
     *     异常或副作用示例：公共查询异常沿用原合同；不写客户、联系人或号段。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    // 与公共模板共用CRM池及真实事务，不打开独立连接。
    private final JdbcTemplate jdbc;

    /**
     * 绑定模板；参数例如crmJdbcTemplate；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmContactDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 锁本表；参数例如tenant92/org901/id200000；返回真实行或null；无实际CRM事务拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam p) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmContact WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        p.getParam("tenantId"),
                        p.getParam("businessOrgId"),
                        p.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * CAS更新；参数含id200000/version0和已校验业务字段；返回影响行数；0行不覆盖其他版本。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     *     业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     * @return 实际影响行数，例如1；0代表未覆盖任何版本
     */
    @Override
    public int updateVersion(CommonParam p) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmContact SET partnerId=?,contactName=?,mobile=?,"
                        + "organizationText=?,businessState=?,updatedByUserId=?,lastOperateUserId=?,"
                        + "updatedAt=CURRENT_TIMESTAMP,versionNo=versionNo+1 WHERE tenantId=? AND "
                        + "businessOrgId=? AND id=? AND status=1 AND versionNo=?",
                p.getParam("partnerId"),
                p.getParam("contactName"),
                p.getParam("mobile"),
                p.getParam("organizationText"),
                p.getParam("businessState"),
                p.getParam("actorUserId"),
                p.getParam("actorUserId"),
                p.getParam("tenantId"),
                p.getParam("businessOrgId"),
                p.getParam("id"),
                p.getParam("expectedVersion"));
    }
}
