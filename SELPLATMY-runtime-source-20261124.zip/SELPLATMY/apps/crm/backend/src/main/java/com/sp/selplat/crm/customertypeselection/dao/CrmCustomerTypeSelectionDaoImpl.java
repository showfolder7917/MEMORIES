/* 客户分类集合的版本化持久化；2026-10-26。 */
package com.sp.selplat.crm.customertypeselection.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 只操作本选择表；原客户及类型由各自拥有方Service检查。 */
@Repository
public class CrmCustomerTypeSelectionDaoImpl extends CrmBaseDao implements CrmCustomerTypeSelectionDao {
    // 与CRM公共CRUD使用同一数据源及事务连接。
    private final JdbcTemplate jdbc;

    /**
     * 方法作用：绑定具名CRM模板，不创建连接池。
     * @param jdbc 实际crmJdbcTemplate，例如本域隔离内存库模板
     * 异常或副作用示例：构造只绑定依赖，不写数据。
     */
    public CrmCustomerTypeSelectionDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 方法作用：CAS保存类型集合和完整追加历史。
     * @param input 本表字段，例如id100000/org901/partnerId200000/typeIdsJson[100000]/expectedVersion1
     * @return 真实返回示例：1；原版本不符为0。
     * 异常或副作用示例：无事务拒绝；不改客户姓名、订单或权限。
     */
    @Override
    public int updateVersion(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update("UPDATE CrmCustomerTypeSelection SET typeIdsJson=?,changeHistoryJson=?,"
                + "lastOperateUserId=?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP "
                + "WHERE tenantId=? AND businessOrgId=? AND partnerId=? AND id=? AND status=1 AND versionNo=?",
                input.getParam("typeIdsJson"), input.getParam("changeHistoryJson"),
                input.getParam("lastOperateUserId"), input.getParam("tenantId"), input.getParam("businessOrgId"),
                input.getParam("partnerId"), input.getParam("id"), input.getParam("expectedVersion"));
    }
}
