/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.openingbatch.service.impl;

import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.text;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.version;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.openingbatch.dao.CrmOpeningBatchDao;
import com.sp.selplat.crm.openingbatch.service.CrmOpeningBatchService;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmOpeningBatchServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmOpeningBatchDao>
    implements CrmOpeningBatchService {

  // 真实Session和组织动作准入，不能从请求绑定可信身份。
  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  /**
   * 绑定真实身份及本域范围入口；构造不授予任何角色或许可。
   *
   * @param access Spring提供的真实CrmAccessService，例如Session核tenant92/actor9211后再核org901动作
   */
  public CrmOpeningBatchServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
    this.access = access;
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
    page.setRecords(page.getRecords().stream().map(row -> fundsProjection(row, false)).toList());
    return page;
  }

  /**
   * 公共真实范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 本组织有效记录；不存在统一拒绝
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return CrmPartnerValueSupport.result(fundsProjection(row, true));
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 已审核期初只读参考；本步无期初写入口，避免在余额锁后增加无必要锁维度。
   *
   * @param input 例如org901/id9901，范围由真实Session和stock.post许可给出
   * @return 实际APPROVED期初；缺记录CRM_RECORD_NOT_FOUND、未审核CRM_OPENING_NOT_APPROVED
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.MANDATORY,
      readOnly = true)
  public Map<String, Object> requireApprovedForPost(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    if (!"APPROVED".equals(row.get("openingState"))) {
      throw CrmPartnerValueSupport.failure("CRM_OPENING_NOT_APPROVED");
    }
    return row;
  }

  /**
   * 已审核期初只读参考；本步无期初写入口，避免在余额锁后增加无必要锁维度。
   *
   * @param input 例如org901/id9901，范围由真实Session和stock.post许可给出
   * @return 实际APPROVED期初；缺记录CRM_RECORD_NOT_FOUND、未审核CRM_OPENING_NOT_APPROVED
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.MANDATORY,
      readOnly = true)
  public Map<String, Object> requireApprovedForFundsPost(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    if (!"APPROVED".equals(row.get("openingState"))) {
      throw CrmPartnerValueSupport.failure("CRM_OPENING_NOT_APPROVED");
    }
    return row;
  }

  // 原期初工作流只组合原账户和余额拥有方，不能直接写其他表。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.cashaccount.service.CrmCashAccountService fundsAccounts;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.fundsbalance.service.CrmFundsBalanceService fundsBalances;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
  private org.springframework.transaction.PlatformTransactionManager fundsManager;

  /**
   * 方法作用：原资金动作许可下维护期初；保留数据库异人审核条件，不建立隐式余额。
   *
   * @param input
   *     原JSON候选，例如org901/operationSAVE/accountId90101/amountMinor0/cutoff2026-10-28T00:00:00Z/requestKeyopening-1
   * @return 真实示例：success=true/data.id900000/versionNo0/openingStateDRAFT/replayfalse。
   *     异常或副作用示例：自审、越组织、旧版本拒绝；审核批准与原余额建立同CRM事务。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult maintainFunds(CommonParam input) {
    var operation = input == null ? null : input.getParam("operation");
    var action = fundsAction(operation);
    var actor =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), action);
    var normalized = normalizeFunds(input);
    normalized.putParam("actorUserId", actor.get("actorUserId"));
    String payloadHash = hash(normalized);
    var transaction = new org.springframework.transaction.support.TransactionTemplate(fundsManager);
    transaction.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    transaction.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    try {
      return access.executeTransaction(
          normalized.getParam("organizationCandidateId"),
          action,
          transaction,
          scope -> saveFundsCommand(normalized, payloadHash, action));
    } catch (org.springframework.dao.DuplicateKeyException conflict) {
      // 创建冲突须离开失败事务，再读取真正提交的原请求；其余SQL异常不转换为业务成功。
      if (normalized.getParam("id") == null) {
        var current =
            access.requireFundsScope(normalized.getParam("organizationCandidateId"), action);
        var key = fundsScope(normalized, current);
        var first = getDao().fundsCreation(key);
        if (first != null) {
          return fundsReplay(first, payloadHash);
        }
      }
      throw conflict;
    }
  }

  /**
   * 方法作用：对精确原期初执行一个状态转换，追加不可伪造的实际操作者历史。
   *
   * @param command 已规范正文，例如operationAPPROVE/id900000/expectedVersion1
   * @param payloadHash 含当前actor的真实摘要，例如64位SHA256
   * @param action 服务器固定动作，例如crm.funds.approve
   * @return 真实示例：data.id900000/versionNo2/openingStateAPPROVED/replayfalse。
   *     异常或副作用示例：已有余额或后续SQL失败，审批和历史整笔回滚。
   */
  private CommonResult saveFundsCommand(CommonParam command, String payloadHash, String action) {
    var scope = access.requireFundsScope(command.getParam("organizationCandidateId"), action);
    if (!scope.get("actorUserId").toString().equals(command.getParam("actorUserId").toString())) {
      throw failure("CRM_ACTION_FORBIDDEN");
    }
    var candidate = fundsScope(command, scope);
    boolean create = command.getParam("id") == null;
    Map<String, Object> before = Map.of();
    var history = new java.util.ArrayList<Map<String, Object>>();
    long selected;
    long next = 0;
    String operation = command.getParam("operation").toString();
    if (create) {
      var first = getDao().fundsCreation(candidate);
      if (first != null) {
        return fundsReplay(first, payloadHash);
      }
      selected = getSequence().get("id");
      candidate.putParam("openingState", "DRAFT");
    } else {
      selected = positive(command.getParam("id"));
      candidate.putParam("id", selected);
      before = getDao().lockScoped(candidate);
      if (before == null || before.get("fundsAccountId") == null) {
        throw failure("CRM_RECORD_NOT_FOUND");
      }
      history = fundsHistory(before.get("fundsHistoryJson"));
      for (var event : history) {
        if (command.getParam("requestKey").equals(event.get("requestKey"))) {
          if (!payloadHash.equals(event.get("payloadHash"))) {
            throw failure("CRM_COMMAND_CONFLICT");
          }
          return fundsReceipt(
              selected,
              version(event.get("versionNo")),
              event.get("openingState").toString(),
              true);
        }
      }
      long previous = version(before.get("versionNo"));
      if (previous == Long.MAX_VALUE || previous != version(command.getParam("expectedVersion"))) {
        throw failure("STALE_CRM_VERSION");
      }
      next = previous + 1;
      candidate.putParam("expectedVersion", previous);
      candidate.putParam("previousState", before.get("openingState"));
      // 已提交正文冻结；只有驳回后重新保存草稿才允许修改期初来源。
      for (String field :
          java.util.List.of(
              "cutoff",
              "evidenceHash",
              "labelZh",
              "fundsAccountId",
              "fundsCurrency",
              "fundsAmountMinor",
              "submittedByUserId",
              "approvedByUserId")) {
        candidate.putParam(field, before.get(field));
      }
      String state = before.get("openingState").toString();
      String target =
          switch (operation) {
            case "SAVE" -> {
              if (!java.util.Set.of("DRAFT", "REJECTED").contains(state)) {
                throw failure("CRM_OPENING_STATE_INVALID");
              }
              yield "DRAFT";
            }
            case "SUBMIT" -> {
              if (!"DRAFT".equals(state)) {
                throw failure("CRM_OPENING_STATE_INVALID");
              }
              candidate.putParam("submittedByUserId", scope.get("actorUserId"));
              yield "SUBMITTED";
            }
            case "APPROVE", "REJECT" -> {
              if (!"SUBMITTED".equals(state)) {
                throw failure("CRM_OPENING_STATE_INVALID");
              }
              if (scope
                  .get("actorUserId")
                  .toString()
                  .equals(String.valueOf(before.get("submittedByUserId")))) {
                throw failure("CRM_OPENING_REVIEWER_MUST_DIFFER");
              }
              if ("APPROVE".equals(operation)) {
                candidate.putParam("approvedByUserId", scope.get("actorUserId"));
                yield "APPROVED";
              }
              yield "REJECTED";
            }
            default -> throw failure("INVALID_CRM_INPUT");
          };
      candidate.putParam("openingState", target);
    }
    candidate.putParam("id", selected);
    candidate.putParam("payloadHash", payloadHash);
    if ("SAVE".equals(operation)) {
      candidate.putParam("fundsAccountId", command.getParam("accountId"));
      candidate.putParam("cutoff", command.getParam("cutoff"));
      candidate.putParam("fundsAmountMinor", command.getParam("amountMinor"));
      candidate.putParam("labelZh", command.getParam("labelZh"));
      candidate.putParam("submittedByUserId", null);
      candidate.putParam("approvedByUserId", null);
    }
    // 账户始终由原拥有方按真实当前动作锁定，停用、跨组织和币种变化不能审批。
    var accountInput = new CommonParam();
    accountInput.putParam("organizationCandidateId", command.getParam("organizationCandidateId"));
    accountInput.putParam("id", candidate.getParam("fundsAccountId"));
    var account = fundsAccounts.lockScoped(accountInput, action);
    if (!"ACTIVE".equals(account.get("businessState"))) {
      throw failure("CRM_ACCOUNT_INACTIVE");
    }
    if (!"SAVE".equals(operation)
        && !account.get("currency").equals(candidate.getParam("fundsCurrency"))) {
      throw failure("CRM_OPENING_SOURCE_CHANGED");
    }
    candidate.putParam("fundsCurrency", account.get("currency"));
    if ("SAVE".equals(operation)) {
      var frozen = new CommonParam();
      frozen.setParamMap(fundsSnapshot(candidate.getParamMap()));
      candidate.putParam("evidenceHash", hash(frozen));
    }
    if (history.size() >= 2000) {
      throw failure("CRM_OPENING_HISTORY_LIMIT");
    }
    var event = new java.util.LinkedHashMap<String, Object>();
    event.put("requestKey", command.getParam("requestKey"));
    event.put("payloadHash", payloadHash);
    event.put("versionNo", Long.toString(next));
    event.put("openingState", candidate.getParam("openingState"));
    event.put("operation", operation);
    event.put("actorUserId", scope.get("actorUserId").toString());
    event.put("decisionId", scope.get("decisionId"));
    event.put("recordedAt", java.time.Instant.now().toString());
    event.put("reasonText", command.getParam("reasonText"));
    event.put("before", fundsSnapshot(before));
    event.put("after", fundsSnapshot(candidate.getParamMap()));
    history.add(event);
    candidate.putParam(
        "fundsHistoryJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(history));
    if (getDao().saveFunds(candidate, create) != 1) {
      throw failure("STALE_CRM_VERSION");
    }
    if ("APPROVE".equals(operation)) {
      // 余额服务重新回查本次真实批准行；批准与余额同一事务，不接受传入金额或伪造已审标记。
      var reference = new CommonParam();
      reference.putParam("organizationCandidateId", command.getParam("organizationCandidateId"));
      reference.putParam("id", selected);
      fundsBalances.initializeApprovedOpening(reference);
    }
    access.requireFundsScope(command.getParam("organizationCandidateId"), action);
    return fundsReceipt(selected, next, candidate.getParam("openingState").toString(), false);
  }

  /**
   * 方法作用：按原审核资格回查真实批准的资金期初，仅供同库余额拥有方使用。
   *
   * @param input 原引用，例如org901/id900000
   * @return 真实示例：APPROVED、fundsAccountId90101及fundsAmountMinor0的原行。
   *     异常或副作用示例：无真实审核许可、缺资金来源或非批准状态拒绝，不构造余额。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.MANDATORY,
      readOnly = true)
  public Map<String, Object> approvedFundsSource(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.approve");
    var row = getDao().getById(detail(input, scope));
    if (row == null
        || !Integer.valueOf(1).equals(row.get("status"))
        || row.get("fundsAccountId") == null
        || !"APPROVED".equals(row.get("openingState"))) {
      throw failure("CRM_OPENING_NOT_APPROVED");
    }
    return row;
  }

  /**
   * 方法作用：严格白名单规范期初候选，金额用精确最小单位，0合法但不制造余额。
   *
   * @param input 原候选，例如SAVE/account90101/amountMinor0/cutoff2026-10-28T00:00:00Z
   * @return 真实示例：CommonParam含Long account90101、BigDecimal0及OffsetDateTime cutoff。
   *     异常或副作用示例：身份覆盖、未知字段、未来截止、小数负数或38位溢出拒绝。
   */
  private static CommonParam normalizeFunds(CommonParam input) {
    String operation = String.valueOf(input.getParam("operation"));
    boolean save = "SAVE".equals(operation);
    var allowed =
        new java.util.HashSet<>(
            java.util.Set.of(
                "organizationCandidateId",
                "operation",
                "id",
                "expectedVersion",
                "requestKey",
                "reasonText"));
    if (save) {
      allowed.addAll(java.util.Set.of("accountId", "amountMinor", "cutoff", "labelZh"));
    }
    if (!allowed.containsAll(input.getParamMap().keySet())) {
      throw failure("INVALID_CRM_INPUT");
    }
    var p = new CommonParam();
    p.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
    p.putParam("operation", operation);
    String key = text(input.getParam("requestKey"), 64, true);
    if (!key.matches("[A-Za-z0-9_.:-]{1,64}")) {
      throw failure("INVALID_CRM_INPUT");
    }
    p.putParam("requestKey", key);
    String reason = text(input.getParam("reasonText"), 200, true);
    if (reason.chars().anyMatch(Character::isISOControl)) {
      throw failure("INVALID_CRM_INPUT");
    }
    p.putParam("reasonText", reason);
    if (input.getParam("id") != null) {
      p.putParam("id", positive(input.getParam("id")));
      p.putParam("expectedVersion", version(input.getParam("expectedVersion")));
    } else if (!save || input.getParam("expectedVersion") != null) {
      throw failure("INVALID_CRM_INPUT");
    }
    if (save) {
      p.putParam("accountId", positive(input.getParam("accountId")));
      Object amount = input.getParam("amountMinor");
      if (!(amount instanceof String raw) || !raw.matches("0|[1-9][0-9]{0,37}")) {
        throw failure("INVALID_CRM_AMOUNT_MINOR");
      }
      p.putParam("amountMinor", new java.math.BigDecimal(raw));
      String label = text(input.getParam("labelZh"), 200, true);
      if (label.chars().anyMatch(Character::isISOControl)) {
        throw failure("INVALID_CRM_INPUT");
      }
      p.putParam("labelZh", label);
      try {
        var date =
            java.time.OffsetDateTime.parse(String.valueOf(input.getParam("cutoff")))
                .withOffsetSameInstant(java.time.ZoneOffset.UTC);
        if (date.toInstant().isAfter(java.time.Instant.now()) || date.getYear() < 1900) {
          throw failure("INVALID_CRM_OPENING_CUTOFF");
        }
        p.putParam("cutoff", date);
      } catch (java.time.format.DateTimeParseException invalid) {
        throw failure("INVALID_CRM_OPENING_CUTOFF");
      }
    }
    return p;
  }

  /**
   * 方法作用：固定期初操作映射到原资金许可，客户端不能传动作名。
   *
   * @param operation 候选，例如APPROVE
   * @return 真实返回示例：APPROVE返回crm.funds.approve，SAVE返回crm.funds.write。
   *     异常或副作用示例：未知操作拒绝INVALID_CRM_INPUT，无写入。
   */
  private static String fundsAction(Object operation) {
    return switch (String.valueOf(operation)) {
      case "SAVE" -> "crm.funds.write";
      case "SUBMIT" -> "crm.funds.submit";
      case "APPROVE", "REJECT" -> "crm.funds.approve";
      default -> throw failure("INVALID_CRM_INPUT");
    };
  }

  /**
   * 方法作用：可信组织坐标与原请求键合并，不接受客户端租户和操作人。
   *
   * @param input 已规范候选，例如org901/requestKeyopening-1
   * @param scope 原真实准入，例如tenant92/org901/actor9211
   * @return 真实示例：CommonParam含tenant92/businessOrg901/actor9211和requestKeyopening-1。
   *     异常或副作用示例：只映射固定键，未写库。
   */
  private static CommonParam fundsScope(CommonParam input, Map<String, Object> scope) {
    var p = new CommonParam();
    for (String f : java.util.List.of("tenantId", "businessOrgId", "actorUserId")) {
      p.putParam(f, scope.get(f));
    }
    p.putParam("requestKey", input.getParam("requestKey"));
    return p;
  }

  /**
   * 方法作用：取期初实际资金来源快照，避免审计泄漏内部请求键和权限证据。
   *
   * @param row 原行，例如id900000/account90101/CNY/amountMinor0
   * @return 真实示例：fundsAccountId90101、fundsCurrencyCNY及fundsAmountMinor0等固定键Map。
   *     异常或副作用示例：只映射存在的固定字段，空旧值返回空Map。
   */
  private static Map<String, Object> fundsSnapshot(Map<String, Object> row) {
    var result = new java.util.LinkedHashMap<String, Object>();
    for (String field :
        java.util.List.of(
            "fundsAccountId",
            "fundsCurrency",
            "fundsAmountMinor",
            "cutoff",
            "labelZh",
            "openingState",
            "submittedByUserId",
            "approvedByUserId")) {
      if (row.get(field) != null) {
        result.put(field, row.get(field));
      }
    }
    return result;
  }

  /**
   * 方法作用：读取原期初同一行历史，SQL损坏或不合法JSON不能当作空历史。
   *
   * @param value 实际JSON，例如包含SAVE及SUBMIT两个事件的数组
   * @return 真实示例：按提交顺序的两个历史Map。 异常或副作用示例：JSON损坏直接失败，不覆盖历史。
   */
  @SuppressWarnings("unchecked")
  private static java.util.ArrayList<Map<String, Object>> fundsHistory(Object value) {
    return new java.util.ArrayList<>(
        (java.util.List<Map<String, Object>>)
            com.sp.selplat.common.util.JsonUtils.fromJson(
                String.valueOf(value), java.util.List.class));
  }

  /**
   * 方法作用：同创建键只返回原操作版本，不能借当前状态伪造原成功结果。
   *
   * @param row 原创建行，例如id900000/fundsCreationHash实际SHA
   * @param payloadHash 当前实际actor与正文SHA
   * @return 真实示例：data.id900000/versionNo0/openingStateDRAFT/replaytrue。 异常或副作用示例：同键不同正文或操作者拒绝，不写余额。
   */
  private static CommonResult fundsReplay(Map<String, Object> row, String payloadHash) {
    if (!payloadHash.equals(row.get("fundsCreationHash"))) {
      throw failure("CRM_COMMAND_CONFLICT");
    }
    return fundsReceipt(positive(row.get("id")), 0, "DRAFT", true);
  }

  /**
   * 方法作用：把原期初一次实际结果变为统一回执，不暴露内部摘要。
   *
   * @param id 原期初，例如900000
   * @param version 当前操作版本，例如2
   * @param state 本次操作真实状态，例如APPROVED
   * @param replay true表示原请求重试
   * @return 真实示例：success=true/data.id900000/versionNo2/openingStateAPPROVED/replayfalse。
   *     异常或副作用示例：只读结果映射，不建立余额。
   */
  private static CommonResult fundsReceipt(long id, long version, String state, boolean replay) {
    return result(
        Map.of(
            "id",
            Long.toString(id),
            "versionNo",
            Long.toString(version),
            "openingState",
            state,
            "replay",
            replay));
  }

  /**
   * 方法作用：资金读许可下读取本组织资金期初真实分页，不把库存期初混入页面。
   *
   * @param input org901/pageNo1/pageSize20
   * @return 真实示例：records一条资金期初900000、totalCount1/pageNo1/pageSize20。 异常或副作用示例：无原资金读许可拒绝，不初始化期初。
   */
  @Override
  @OperationLog
  public CommonPageResult fundsStore(CommonPageParam input) {
    var scope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    var page = getDao().fundsPage(CrmPartnerValueSupport.page(input, scope, null));
    page.setRecords(page.getRecords().stream().map(row -> fundsProjection(row, false)).toList());
    return page;
  }

  /**
   * 方法作用：资金读许可下回读期初正文与可读历史，不泄漏请求键和内部权限证据。
   *
   * @param input org901/id900000
   * @return 真实示例：data.openingStateSUBMITTED及history含SAVE和SUBMIT两项。 异常或副作用示例：无资金来源或跨组织拒绝，不更改状态。
   */
  @Override
  @OperationLog
  public CommonResult readFunds(CommonParam input) {
    var scope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    var row = getDao().getById(detail(input, scope));
    if (row == null
        || !Integer.valueOf(1).equals(row.get("status"))
        || row.get("fundsAccountId") == null) {
      throw failure("CRM_RECORD_NOT_FOUND");
    }
    return result(fundsProjection(row, true));
  }

  /**
   * 方法作用：公开投影移除原请求键、正文摘要和原始审计JSON，详情仅展示安全变化记录。
   *
   * @param row 实际期初，例如900000及内部资金维护元数据
   * @param detail true包含可读历史，例如SAVE操作人9211
   * @return 真实示例：id900000、fundsAmountMinor0及去除requestKey的history。
   *     异常或副作用示例：仅字段映射，不向浏览器回传内部decisionId。
   */
  private static Map<String, Object> fundsProjection(Map<String, Object> row, boolean detail) {
    var result = new java.util.LinkedHashMap<>(CrmStockValueSupport.browser(row));
    for (String key :
        java.util.List.of("fundsCreationKey", "fundsCreationHash", "fundsHistoryJson")) {
      result.remove(key);
    }
    if (detail && row.get("fundsAccountId") != null) {
      result.put(
          "history",
          fundsHistory(row.get("fundsHistoryJson")).stream()
              .map(
                  event -> {
                    var safe = new java.util.LinkedHashMap<>(event);
                    safe.remove("requestKey");
                    safe.remove("payloadHash");
                    safe.remove("decisionId");
                    return safe;
                  })
              .toList());
    }
    return result;
  }
}
