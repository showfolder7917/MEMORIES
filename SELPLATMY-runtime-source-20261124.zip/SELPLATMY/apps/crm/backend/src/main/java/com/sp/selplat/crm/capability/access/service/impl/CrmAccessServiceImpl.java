/**
 * CrmAccessServiceImpl.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
/* 修改记录：2026-10-09，客户/订单/库存/资金缺动作沿用原拒绝契约，不放宽身份或组织门禁。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
/* 2026-10-28：审计目录仅复用既有crm.audit.read，不授予新动作。 */
package com.sp.selplat.crm.capability.access.service.impl;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import org.springframework.stereotype.Service;

/**
 * 通过真实 Uniauth 会话回查账号；旧业务规则未验收时不宣告 CRM 可写或上线就绪。
 */
@Service
public class CrmAccessServiceImpl implements CrmAccessService {

  // 显式接入开关默认关闭；启用也必须拥有真实组织、成员及逐动作许可，不初始化生产业务表。
  @org.springframework.beans.factory.annotation.Value("${crm.authorization.enabled:false}")
  private boolean authorizationEnabled;

  // CRM适配现有统一owner服务，缺失时拒绝；不能把test-only谓词当正式资格。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.capability.access.service.CrmOrganizationAuthorization>
      authorization;

  // 只读实际部署结构；旧owner模型和未安装的新表不能凭正式授权开关开放。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration
              .CrmBusinessStructureInspector>
      structures;

  /**
   * 方法作用：区分实际安装和动作授权，供附件/冲正等内部入口复用安装判断。
   * @param capability 本域固定能力，例如orderAttachment
   * @return 真实返回示例：正式模式且已安装对应结构为true；默认false。
   * 异常或副作用示例：只读元数据，不创建表、不赋予权限。
   */
  @Override
  public boolean formalCapabilityAvailable(String capability) {
    if (!authorizationEnabled) {
      return false;
    }
    var installed = structures.getIfAvailable();
    return installed != null && installed.available().contains(capability);
  }

  /**
   * 方法作用：按真实账号和候选组织构造固定CRM组织资源要求，不接受客户端身份。
   * @param candidate 经营组织候选，例如901
   * @param action 本域固定动作，例如crm.order.write
   * @return 真实返回示例：actor含tenant92/user9211，resource为crm/CRM_ORGANIZATION901。
   * @throws CommonBusinessException 非法主键或未开放的资金冲正动作拒绝，无许可写入。
   */
  private com.sp.selplat.common.util.CommonParam requirement(Object candidate, String action) {
    if (action == null
        || !com.sp.selplat.crm.common.util.authorization.CrmOrganizationActionPolicy.ACTIONS
            .contains(action)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前CRM动作尚未接入正式授权。");
    }
    var actor = requireDraftActor();
    long org = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(candidate);
    var input = new com.sp.selplat.common.util.CommonParam();
    input.putParam(
        "actor", Map.of("tenantId", actor.get("tenantId"), "userId", actor.get("ownerUserId")));
    input.putParam("scope", Map.of("operatingOrganizationId", org));
    input.putParam("action", action);
    input.putParam("resource", Map.of("application", "crm", "type", "CRM_ORGANIZATION", "id", org));
    return input;
  }

  /**
   * 方法作用：从统一owner读取当前精确资格证据，不把登录或组织候选当作允许。
   * @param candidate 明确组织候选，例如901
   * @param action 独立动作，例如crm.partner.read
   * @return 真实返回示例：tenant92/businessOrgId901/actorUserId9211/synthetic=false及decisionId。
   * @throws CommonBusinessException 未确认、撤销、到期或旧成员修订返回CRM_ACTION_FORBIDDEN。
   */
  private Map<String, Object> formalScope(Object candidate, String action) {
    var owner = authorization.getIfAvailable();
    if (owner == null) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "统一组织授权尚未装配。");
    }
    var input = requirement(candidate, action);
    try {
      var result = owner.evidence(input);
      if (!result.isSuccess()
          || !(result.getData() instanceof Map<?, ?> evidence)
          || !Boolean.TRUE.equals(evidence.get("allow"))) {
        throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前账号未获该经营组织动作许可。");
      }
      var installed = structures.getIfAvailable();
      if (installed == null) {
        throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "CRM结构检查尚未装配。");
      }
      // 先核当前动作许可，再识别已安装结构；不对未授权调用者泄露部署细节。
      installed.require(action);
      var scope = new LinkedHashMap<String, Object>();
      scope.put("tenantId", evidence.get("tenantId"));
      scope.put("businessOrgId", evidence.get("scopeId"));
      scope.put("actorUserId", evidence.get("actorUserId"));
      scope.put("action", action);
      scope.put("synthetic", false);
      scope.put("decisionId", evidence.get("decisionId"));
      return scope;
    } catch (CommonBusinessException failure) {
      if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
        throw failure;
      }
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前账号未获该经营组织动作许可。");
    }
  }

  /**
   * 方法作用：用统一owner保护正式事务的实际提交；隔离测试仍执行原模板。
   * @param candidate 经营组织候选，例如901
   * @param action 独立动作，例如crm.order.submit
   * @param template owning服务现有具名模板，例如crmTransactionManager
   * @param operation 完整事务回调，例如订单、行、回执与审计一起保存
   * @return 真实返回示例：原结果data.id=600000；真实提交前身份和资格复核失败则回滚。
   * 异常或副作用示例：外层事务、未知动作或缺真实容器保护拒绝，不写认证库。
   */
  @Override
  public CommonResult executeTransaction(
      Object candidate,
      String action,
      org.springframework.transaction.support.TransactionTemplate template,
      org.springframework.transaction.support.TransactionCallback<CommonResult> operation) {
    if (!authorizationEnabled) {
      return template.execute(operation);
    }
    formalScope(candidate, action);
    var owner = authorization.getIfAvailable();
    try {
      // 适配器调用统一身份及资格owner持锁，覆盖CRM模板实际提交；回调不能另开独立事务。
      return owner.execute(requirement(candidate, action), template, operation);
    } catch (CommonBusinessException failure) {
      if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
        throw failure;
      }
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前账号的经营组织许可已失效。");
    }
  }

  // 本域临时测试钩子不是平台resolver；生产默认false且测试许可Bean仅位于test源码。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmPartnerIsolatedEnabled")
  private Boolean partnerIsolatedEnabled;

  // 订单额外显式测试开关，不能借已登录或客户只读打开订单写入。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmOrderIsolatedEnabled")
  private Boolean orderIsolatedEnabled;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmStockIsolatedEnabled")
  private Boolean stockIsolatedEnabled;

  // 测试profile由真实合成许可表逐动作查询；无Bean也拒绝，不能根据登录者推组织。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmSyntheticPartnerPermission")
  private org.springframework.beans.factory.ObjectProvider<
          java.util.function.Predicate<Map<String, Object>>>
      syntheticPermission;

  private final CurrentSessionAccess sessionService;

  private final org.springframework.transaction.support.TransactionTemplate identityRead;

  private static final String VERIFIED_ACTOR_ATTRIBUTE = "com.sp.selplat.crm.verifiedRequestActor";

  /**
   * 注入统一宿主装配的会话服务。
   *
   * @param sessionService 真实身份服务，例如 {@code UniauthSessionServiceImpl}
   * @param transactionManager CRM具名事务，例如crmTransactionManager；只用于暂停当前CRM同步范围
   *     执行结果示例：后续查询使用同一身份入口，不建立新的登录协议。
   */
  public CrmAccessServiceImpl(
      @org.springframework.beans.factory.annotation.Qualifier("crmCurrentSessionAccess")
          CurrentSessionAccess sessionService,
      @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
          org.springframework.transaction.PlatformTransactionManager transactionManager) {
    this.sessionService = sessionService;
    identityRead =
        new org.springframework.transaction.support.TransactionTemplate(transactionManager);
    identityRead.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_NOT_SUPPORTED);
  }

  /**
   * 方法作用：暂停CRM事务的同步资源，再通过既有统一身份服务回查最新已提交账号。 真实传参示例：无参数；旧库存请求在tenant92余额锁等待后，账号已独立提交到tenant93。
   * 真实返回示例：统一current结果的tenantId=93，而不是旧事务绑定会话缓存中的92。
   * 异常或副作用示例：账号无效沿用UNIAUTH_IDENTITY_REQUIRED；不查询Uniauth表、不提交CRM事务、不提供跨库ACID。
   *
   * @return 最新安全身份CommonResult，例如data.userId=9211、data.tenantId=93
   */
  private CommonResult currentIdentity() {
    // 原请求快照不代表锁等待后的当前账号，沿已有公开刷新合同读取。
    return identityRead.execute(status -> sessionService.revalidateCurrent());
  }

  /**
   * 方法作用：正式模式从统一目录过滤真实CRM读取许可；关闭时不提供合成组织选择。
   * @param query 字面名称，例如青禾；空串允许有界查询
   * @return 真实返回示例：success=true/data含actor和organizations；无许可organizations为空List。
   * @throws CommonBusinessException 身份失效或正式授权适配缺失拒绝，不查询CRM业务表
   */
  @Override
  public CommonResult organizationChoices(String query) {
    var actor = requireDraftActor();
    CommonResult result = new CommonResult();
    result.setSuccess(true);
    var descriptor =
        Map.of(
            "tenantId",
            actor.get("tenantId").toString(),
            "userId",
            actor.get("ownerUserId").toString());
    result.setData(Map.of("actor", descriptor, "organizations", java.util.List.of()));
    if (!authorizationEnabled) {
      return result;
    }
    var owner = authorization.getIfAvailable();
    if (owner == null) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "统一组织授权尚未装配。");
    }
    var installed = structures.getIfAvailable();
    var capabilities = installed == null ? java.util.Set.<String>of() : installed.available();
    var choices = new java.util.ArrayList<Map<String, Object>>();
    for (var choice : owner.organizationChoices(query)) {
      @SuppressWarnings("unchecked")
      var actions = (java.util.List<String>) choice.get("readActions");
      var availableActions =
          actions.stream()
              .filter(
                  action ->
                      capabilities.contains(
                          action.startsWith("crm.product.")
                              ? "product"
                              : action.startsWith("crm.partner.") || action.equals("crm.audit.read")
                                  ? "partner"
                                  : action.startsWith("crm.order.") ? "order" : "stock"))
              .toList();
      if (!availableActions.isEmpty()) {
        choices.add(
            Map.of(
                "id",
                choice.get("id"),
                "displayName",
                choice.get("displayName"),
                "readActions",
                availableActions,
                "tenantId",
                actor.get("tenantId").toString(),
                "actorUserId",
                actor.get("ownerUserId").toString()));
      }
    }
    result.setData(Map.of("actor", descriptor, "organizations", java.util.List.copyOf(choices)));
    requireDraftActor();
    return result;
  }

  /**
   * 方法作用：独立财务消费原资金资格与结构，只返回原真实机构候选。
   * @param query 字面名称，例如新思度；沿原拥有方显式目录上限
   * @return 真实示例：data.actor={tenantId:"9",userId:"9101"}及organizations=[{id:"901",displayName:新思度,readActions:[crm.funds.read]}]。
   * 异常或副作用示例：普通CRM读取不获得资金目录；缺结构为空，SQL和身份故障传播，零写入。
   */
  @Override
  public CommonResult fundsOrganizationChoices(String query) {
    var actor = requireDraftActor();
    var choices = new java.util.ArrayList<Map<String, Object>>();
    if (formalCapabilityAvailable("funds")) {
      var owner = authorization.getIfAvailable();
      if (owner == null) {
        throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "统一组织授权尚未装配。");
      }
      for (var row : owner.fundsOrganizationChoices(query)) {
        // 候选仍核原正式资金动作和安装状态，不从其他CRM许可推导。
        requireFundsScope(row.get("id"), "crm.funds.read");
        choices.add(row);
      }
    }
    if (!actor.equals(requireDraftActor())) {
      throw new CommonBusinessException("CRM_DIRECTORY_IDENTITY_CHANGED", "当前机构选择身份已变化。");
    }
    var result = new CommonResult();
    result.setSuccess(true);
    result.setData(
        Map.of(
            "actor",
            Map.of(
                "tenantId",
                actor.get("tenantId").toString(),
                "userId",
                actor.get("ownerUserId").toString()),
            "organizations",
            java.util.List.copyOf(choices)));
    return result;
  }

  /**
   * 每次请求都回查当前有效账号，再返回未开放的业务状态。
   *
   * @return 安全身份与开放状态，例如 {@code
   *     {"success":true,"data":{"moduleId":"crm","businessReady":false,"identity":{"tenantId":9}}}}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 未登录或账号失效时沿用统一身份错误
   */
  @Override
  public CommonResult readiness() {
    // 服务端 Session → 统一身份服务 → 真实账号校验；失败直接终止，不构造成功身份。
    CommonResult current = currentIdentity();
    Map<String, Object> data = new LinkedHashMap<>();
    data.put("moduleId", "crm");
    data.put("identity", current.getData());
    // 此标志只反映已交付代码；安全源可读并不代表权限、库存及余额链路已验收。
    data.put("businessReady", false);
    data.put("businessState", "REVIEW_REQUIRED");
    // 明确区分接入未启用与无可读组织；登录成功不代表CRM业务已经安装或获准。
    var installed = authorizationEnabled ? structures.getIfAvailable() : null;
    var available = installed == null ? java.util.Set.<String>of() : installed.available();
    data.put(
        "organizationDirectoryState",
        !authorizationEnabled
            ? "CONFIG_DISABLED"
            : available.stream().anyMatch(Set.of("partner", "product", "order", "stock")::contains)
                ? "READY"
                : "STRUCTURE_UNAVAILABLE");
    // 界面文字随真实账号语言在单次响应中聚合，前端不请求业务配置碎片。
    @SuppressWarnings("unchecked")
    Map<String, Object> profile = (Map<String, Object>) current.getData();
    String requestedLocale = String.valueOf(profile.get("locale"));
    String locale =
        Set.of("zh-CN", "ja-JP", "en").contains(requestedLocale) ? requestedLocale : "zh-CN";
    ResourceBundle bundle =
        ResourceBundle.getBundle(
            "crm-workspace",
            Locale.forLanguageTag(locale),
            ResourceBundle.Control.getNoFallbackControl(ResourceBundle.Control.FORMAT_PROPERTIES));
    Map<String, String> labels = new LinkedHashMap<>();
    bundle.keySet().stream().sorted().forEach(key -> labels.put(key, bundle.getString(key)));
    data.put("locale", locale);
    data.put("labels", labels);
    CommonResult result = new CommonResult();
    result.setSuccess(true);
    result.setData(data);
    result.setMsg("身份核验完成，CRM 业务尚未开放。");
    return result;
  }

  /**
   * 从真实服务端会话取得正数账号和租户，不读取请求字段。
   *
   * @return 本人归属，例如 {@code {"tenantId":92,"ownerUserId":9211}}
   * @throws CommonBusinessException
   *     身份无效或归属为空时抛出UNIAUTH_IDENTITY_REQUIRED；本请求归属92变为93时CRM_ACTION_FORBIDDEN，外层业务事务回滚
   */
  @Override
  public Map<String, Long> requireDraftActor() {
    // 统一当前身份查询已经回查真实账号；返回类型来自同一稳定契约。
    @SuppressWarnings("unchecked")
    Map<String, Object> profile = (Map<String, Object>) currentIdentity().getData();
    // 账号及租户都必须明确为正数，才可进入私人记录的复合主键。
    Object userValue = profile.get("userId");
    Object tenantValue = profile.get("tenantId");
    if (!(userValue instanceof Number userId)
        || userId.longValue() <= 0
        || !(tenantValue instanceof Number tenantId)
        || tenantId.longValue() <= 0) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "当前账号没有有效的草稿归属。");
    }
    Map<String, Long> actor =
        Map.of("tenantId", tenantId.longValue(), "ownerUserId", userId.longValue());
    // 服务端request属性只保存本次请求首次回查的归属；不写Session，也不接受客户端scope字段。
    var request =
        org.springframework.web.context.request.RequestContextHolder.currentRequestAttributes();
    Object first =
        request.getAttribute(
            VERIFIED_ACTOR_ATTRIBUTE,
            org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST);
    if (first == null) {
      request.setAttribute(
          VERIFIED_ACTOR_ATTRIBUTE,
          actor,
          org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST);
    } else if (!actor.equals(first)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "本次请求期间账号归属已变更，请重新加载后重试。");
    }
    // 新HTTP请求重新取真实归属；旧请求任何后续scope核验都不能跨租户继续。
    return actor;
  }

  /**
   * 回查真实账号并验证明确组织候选及动作，生产未接resolver保持拒绝。
   *
   * @param candidate 请求组织候选，例如"901"；不读取客户端tenant或actor
   * @param action 本域固定动作，例如crm.partner.read；null按原CRM_ACTION_FORBIDDEN拒绝
   * @return
   *     合成测试scope，例如{tenantId:92,businessOrgId:901,actorUserId:9211,synthetic:true,decisionId:SYNTHETIC_TEST_ONLY}
   * @throws CommonBusinessException 匿名、生产未接resolver、非法候选或缺合成许可时拒绝，不写库
   */
  @Override
  public Map<String, Object> requirePartnerScope(Object candidate, String action) {
    Map<String, Long> actor = requireDraftActor();
    // 正式模式只依赖统一owner的已确认关系，不回落合成许可。
    if (authorizationEnabled) {
      return formalScope(candidate, action);
    }
    // 三重隔离门禁及test源码许可缺一不可；未来正式resolver由唯一公共owner提供后另行接入。
    var checker = syntheticPermission.getIfAvailable();
    if (!Boolean.TRUE.equals(partnerIsolatedEnabled) || checker == null) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "经营组织授权尚未接通，客户维护未开放。");
    }
    long org = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(candidate);
    Map<String, Object> scope = new LinkedHashMap<>();
    scope.put("tenantId", actor.get("tenantId"));
    scope.put("businessOrgId", org);
    scope.put("actorUserId", actor.get("ownerUserId"));
    scope.put("action", action);
    scope.put("synthetic", true);
    scope.put("decisionId", "SYNTHETIC_TEST_ONLY");
    // 缺动作与未知动作都按原业务拒绝；不可变集合不能接收null。
    if (action == null
        || !Set.of(
                "crm.product.read",
                "crm.product.write",
                "crm.partner.read",
                "crm.partner.write",
                "crm.audit.read",
                "crm.order.read",
                "crm.order.write",
                "crm.order.submit",
                "crm.order.approve",
                "crm.stock.read",
                "crm.stock.write",
                "crm.stock.submit",
                "crm.stock.approve",
                "crm.stock.post",
                "crm.stock.reverse",
                "crm.funds.read",
                "crm.funds.write",
                "crm.funds.submit",
                "crm.funds.approve",
                "crm.funds.post",
                "crm.funds.reverse")
            .contains(action)
        || !checker.test(scope)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前账号未获该经营组织动作许可。");
    }
    return scope;
  }

  /**
   * 显式隔离订单动作的真实身份和逐动作裁决。
   *
   * @param candidate 经营组织候选，例如901
   * @param action 固定订单动作，例如crm.order.approve；null按原CRM_ACTION_FORBIDDEN拒绝
   * @return 实际Session及合成许可表确认的范围；synthetic=true，不是生产凭证
   * @throws CommonBusinessException 缺订单开关或无订单动作许可时拒绝，正式resolver仍缺
   */
  @Override
  public Map<String, Object> requireOrderScope(Object candidate, String action) {
    requireDraftActor();
    if (!authorizationEnabled && !Boolean.TRUE.equals(orderIsolatedEnabled)) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "订单经营组织授权尚未接通。");
    }
    // 缺动作与未知动作都按原业务拒绝；不可变集合不能接收null。
    if (action == null
        || !Set.of("crm.order.read", "crm.order.write", "crm.order.submit", "crm.order.approve")
            .contains(action)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "未知订单动作。");
    }
    return requirePartnerScope(candidate, action);
  }

  /**
   * 逐次真实身份和库存许可检查；无正式resolver保持关闭。
   *
   * @param candidate 组织候选，例如901
   * @param action 固定库存动作，例如crm.stock.post；null按原CRM_ACTION_FORBIDDEN拒绝
   * @return 真实actor/org及合成decision；没有默认仓库或管理员
   * @throws CommonBusinessException 缺明确结构/动作/许可时拒绝
   */
  @Override
  public Map<String, Object> requireStockScope(Object candidate, String action) {
    requireDraftActor();
    if (!authorizationEnabled
        && "crm.stock.reverse".equals(action)
        && !Boolean.TRUE.equals(stockReversalEnabled)) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "库存冲正测试门禁未开放。");
    }
    if (!authorizationEnabled && !Boolean.TRUE.equals(stockIsolatedEnabled)) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "库存组织授权尚未接通。");
    }
    // 缺动作与未知动作都按原业务拒绝；不可变集合不能接收null。
    if (action == null
        || !Set.of(
                "crm.stock.read",
                "crm.stock.write",
                "crm.stock.submit",
                "crm.stock.approve",
                "crm.stock.post",
                "crm.stock.reverse")
            .contains(action)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "未知库存动作。");
    }
    return requirePartnerScope(candidate, action);
  }

  /**
   * owning服务的固定动作分派，不根据登录推断组织。
   *
   * @param candidate org候选，例如901
   * @param action order.approve或stock.post等固定动作
   * @return 按对应额外门禁核验的范围；未知动作拒绝
   */
  @Override
  public Map<String, Object> requireBusinessScope(Object candidate, String action) {
    if (action != null && action.startsWith("crm.funds.")) {
      return requireFundsScope(candidate, action);
    }
    if (action != null && action.startsWith("crm.stock.")) {
      return requireStockScope(candidate, action);
    }
    if (action != null && action.startsWith("crm.order.")) {
      return requireOrderScope(candidate, action);
    }
    return requirePartnerScope(candidate, action);
  }

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmStockReversalIsolatedEnabled")
  private Boolean stockReversalEnabled;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmFundsIsolatedEnabled")
  private Boolean fundsIsolatedEnabled;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmFundsReversalIsolatedEnabled")
  private Boolean reversalEnabled;

  /**
   * 方法作用：原资金五动作可沿正式组织拥有方核实际许可和已安装结构；隔离模式保留原门禁。
   * @param candidate 请求提供的组织候选，例如901；真实租户和账号仍从当前Session读取
   * @param action 原拥有方固定动作，例如crm.funds.post；资金冲正仍不进入正式合同
   * @return 真实示例：tenantId92/businessOrgId901/actorUserId9211/synthetic=false及真实decisionId。
   * 异常或副作用示例：结构未安装、未许可或身份失效拒绝；不会补建结构或授予权限。
   */
  @Override
  public Map<String, Object> requireFundsScope(Object candidate, String action) {
    requireDraftActor();
    if (authorizationEnabled) {
      // 资金入口只接受自身五动作；其他域已有许可也不能借此入口取得资金资格。
      if (action == null
          || !Set.of(
                  "crm.funds.read",
                  "crm.funds.write",
                  "crm.funds.submit",
                  "crm.funds.approve",
                  "crm.funds.post")
              .contains(action)) {
        throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "未知资金动作。");
      }
      return formalScope(candidate, action);
    }
    if ("crm.funds.reverse".equals(action) && !Boolean.TRUE.equals(reversalEnabled)) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "冲正测试门禁未开放。");
    }
    if (!Boolean.TRUE.equals(fundsIsolatedEnabled)) {
      throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "资金组织授权尚未接通。");
    }
    if (action == null
        || !Set.of(
                "crm.funds.read",
                "crm.funds.write",
                "crm.funds.submit",
                "crm.funds.approve",
                "crm.funds.post",
                "crm.funds.reverse")
            .contains(action)) {
      throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "未知资金动作。");
    }
    return requirePartnerScope(candidate, action);
  }
}
