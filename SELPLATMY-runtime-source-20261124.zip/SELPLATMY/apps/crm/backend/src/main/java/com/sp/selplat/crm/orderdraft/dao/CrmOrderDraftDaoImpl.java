/**
 * CrmOrderDraftDaoImpl.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.orderdraft.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import org.springframework.stereotype.Repository;

/** 本人订单草稿持久化复用本域上下文及公共 DAO，归属在真实主键中。 */
@Repository
public class CrmOrderDraftDaoImpl extends CrmBaseDao implements CrmOrderDraftDao {
}
