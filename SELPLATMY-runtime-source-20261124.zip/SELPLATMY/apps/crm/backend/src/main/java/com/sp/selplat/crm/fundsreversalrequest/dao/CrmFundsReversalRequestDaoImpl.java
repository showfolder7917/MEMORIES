/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.fundsreversalrequest.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmFundsReversalRequestDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmFundsReversalRequestDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmFundsReversalRequestDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmFundsReversalRequest WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：按原批次读取唯一冲正申请。
     *
     * @param input tenant92/org901/originalBatch1200000
     * @return 真实申请或null，无新增 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public Map<String, Object> forOriginal(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmFundsReversalRequest WHERE tenantId=? AND businessOrgId=? AND originalBatchId=? FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("originalBatchId"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：独立申请审批/已执行状态CAS，不影响原收款审批。
     *
     * @param input 申请1700000/expected0/SUBMITTED→APPROVED/真实actor9212
     * @return 1或0；约束或零行外层回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public int transition(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmFundsReversalRequest SET requestState=?,versionNo=versionNo+1,"
                        + "approvedByUserId=CASE WHEN ?='APPROVED' THEN ? ELSE approvedByUserId END,"
                        + "executedByUserId=CASE WHEN ?='POSTED' THEN ? ELSE executedByUserId END,"
                        + "resultBatchId=?,resultAction=?,updatedByUserId=?,lastOperateUserId=?,"
                        + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? AND id=? "
                        + "AND requestState=? AND versionNo=? AND versionNo<9223372036854775807 AND "
                        + "status=1",
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("resultBatchId"),
                input.getParam("resultAction"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("previousState"),
                input.getParam("expectedVersion"));
    }
}
