/* 客户多类型选择；2026-10-26，独立分类版本不改变原客户资料。 */
/* 修改记录：2026-10-27，首次客户分类与原客户创建同事务提交；教学按稳定分类编号调用，已有分类独立维护。 */
package com.sp.selplat.crm.customertypeselection.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 客户可选多个自定义类型；分类不是账号角色或许可来源。 */
public interface CrmCustomerTypeSelectionService extends BaseService {
    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    CommonResult history(CommonParam input);

    /**
     * 方法作用：读取实际客户的已选类型及当前组织类型目录。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId200000
     * @return 真实返回示例：data={partnerId:"200000",versionNo:"0",typeIds:[],types:[]}。
     * 异常或副作用示例：跨租户、跨组织或无读取资格拒绝；零写入。
     */
    CommonResult read(CommonParam input);

    /**
     * 方法作用：原子替换本客户类型集合，保留原结果重放和历史。
     * @param input 候选，例如org901/partnerId200000/expectedVersion0/expectedPartnerVersion0/typeIdsJson[]/requestKeypick-1
     * @return 真实返回示例：data={partnerId:"200000",versionNo:"1",replay:false}。
     * 异常或副作用示例：新选停用类型、旧版本或同键异内容拒绝；不改客户主档案。
     */
    CommonResult save(CommonParam input);

    /**
     * 方法作用：客户拥有方在其创建事务内初始化分类，失败连同客户创建回滚，不开放HTTP入口。
     * @param input 服务间创建候选，例如organizationCandidateId901/partnerId200001/typeIdsJson[100000]/requestKeycreate-1
     * @return 真实返回示例：data={partnerId:"200001",versionNo:"1",replay:false}。
     * 异常或副作用示例：必须处于CRM事务；客户不是首次版本或已有分类拒绝，不替换原集合。
     */
    CommonResult initializeForPartner(CommonParam input);

}
