/** 完整库存冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.stockreversalrequest.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmStockReversalRequestDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 方法作用：按原批次读取唯一冲正申请。
     *
     * @param input tenant92/org901/originalBatch1200000
     * @return 真实申请或null，无新增 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Map<String, Object> forOriginal(CommonParam input);

    /**
     * 方法作用：独立申请审批/已执行状态CAS，不影响原库存审批。
     *
     * @param input 申请1700000/expected0/SUBMITTED→APPROVED/真实actor9212
     * @return 1或0；约束或零行外层回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    int transition(CommonParam input);
}
