/* 客户类型本表锁与CAS；2026-10-26。 */
package com.sp.selplat.crm.customertype.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 类型唯一名称及创建请求由数据库约束保护；不跨表读取客户或学生。 */
@Repository
public class CrmCustomerTypeDaoImpl extends CrmBaseDao implements CrmCustomerTypeDao {
    // 与公共CRUD共用本域池和CRM事务。
    private final JdbcTemplate jdbc;

    /**
     * 方法作用：装配本域具名模板，不创建连接池。
     * @param jdbc 实际crmJdbcTemplate，例如独立CRM内存测试库模板
     * 异常或副作用示例：仅保留依赖，不执行SQL。
     */
    public CrmCustomerTypeDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 方法作用：按可信组织复合键锁定类型，不过滤enabledFlag。
     * @param input 已核范围，例如tenantId92/businessOrgId901/id100000
     * @return 真实返回示例：本表Map包含versionNo0；未命中null。
     * 异常或副作用示例：无CRM事务抛错，零业务写入。
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows = jdbc.queryForList("SELECT * FROM CrmCustomerType WHERE tenantId=? "
                + "AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                input.getParam("tenantId"), input.getParam("businessOrgId"), input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：CAS更新名称、启用状态、排序和完整变更历史。
     * @param input 本表可信更新字段，例如tenantId92/org901/id100000/expectedVersion0
     * @return 真实返回示例：1；0不覆盖新版本。
     * 异常或副作用示例：重名触发约束并回滚；原编码及创建请求不变。
     */
    @Override
    public int updateVersion(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update("UPDATE CrmCustomerType SET typeName=?,typeNameKey=?,enabledFlag=?,"
                + "sortnum=?,changeHistoryJson=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP,"
                + "versionNo=versionNo+1 WHERE tenantId=? AND businessOrgId=? AND id=? "
                + "AND status=1 AND versionNo=?",
                input.getParam("typeName"), input.getParam("typeNameKey"), input.getParam("enabledFlag"),
                input.getParam("sortnum"), input.getParam("changeHistoryJson"), input.getParam("lastOperateUserId"),
                input.getParam("tenantId"), input.getParam("businessOrgId"), input.getParam("id"),
                input.getParam("expectedVersion"));
    }
}
