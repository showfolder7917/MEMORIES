/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdetail.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmPostingDetailDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 稳定全量父行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     */
    List<Map<String, Object>> readAll(CommonParam input);

    /**
     * 方法作用：读取不可变完整账本历史，不提前锁原明细、不按人工status隐藏行。
     *
     * @param input 例如tenant92/org901/batch1200000
     * @return 实际全部明细按id升序；无写入，缺CRM事务拒绝，执行在Progress后另外逐行锁与比较。
     */
    List<Map<String, Object>> readHistory(CommonParam input);

    /**
     * 在真实来源锁内读取本来源行完整原POST候选，无跨表SQL或人工有效标志。
     *
     * @param input tenant92/org901/sourceOrderLineId600001
     * @return 本表原POST列表例如[{id:1300000,quantityDelta:-3}]；有效性由owning单据/批次另核
     */
    List<Map<String, Object>> findForSource(CommonParam input);
}
