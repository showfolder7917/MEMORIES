/** CRM客户表单和列表聚合；2026-10-03，Codex，配置只由后端给出。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.common.util.partner;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 无状态展示定义，不查询SQL或授予许可。 */
public final class CrmPartnerWorkspaceSupport {
    /** 静态值规范或实际页面配置工具，构造不连接数据库、创建业务记录或授予权限。 */
    private CrmPartnerWorkspaceSupport() {
        // 只提供静态工具，禁止持有会话或业务状态。
    }

    /**
     * 仅浏览器业务主键和版本转为精确文本，避免Javascript整数精度损失。
     *
     * @param row 数据库行，例如id=9223372036854775807、versionNo=0
     * @return 新映射，id/partnerId/versionNo为精确十进制文本；不修改DAO记录
     */
    public static Map<String, Object> browserRecord(Map<String, Object> row) {
        Map<String, Object> copy = new LinkedHashMap<>(row);
        for (String key : List.of("id", "partnerId", "versionNo", "archivedByUserId")) {
            if (copy.get(key) instanceof Number) {
                copy.put(key, copy.get(key).toString());
            }
        }
        return copy;
    }

    /**
     * 组装真实分页及SELUI定义，缺写许可仅显示只读，不把客户端候选当裁决。
     *
     * @param page 实际组织分页结果，例如第1页的真实客户记录
     * @param contact 是否为联系人维护，例如true时要求partnerId=200000
     * @param writable 实际写动作裁决，例如false展示只读；不是客户端授权
     * @param requested 请求语言候选，例如zh-CN；只允许三种定义语言 业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonResult build(
            CommonPageResult page, boolean contact, boolean writable, Object requested) {
        String lang =
                Set.of("zh-CN", "en-US", "ja-JP").contains(String.valueOf(requested))
                        ? String.valueOf(requested)
                        : "zh-CN";
        int locale = lang.equals("en-US") ? 1 : lang.equals("ja-JP") ? 2 : 0;
        Map<String, String[]> words = new LinkedHashMap<>();
        words.put("partnerName", new String[] {"客户名称", "Customer name", "顧客名"});
        words.put("contactName", new String[] {"联系人姓名", "Contact name", "連絡先名"});
        words.put("partnerKind", new String[] {"主体类型", "Partner type", "主体種別"});
        words.put("customerRole", new String[] {"客户角色", "Customer role", "顧客役割"});
        words.put("supplierRole", new String[] {"供应商角色", "Supplier role", "仕入先役割"});
        words.put("businessState", new String[] {"业务状态", "Business state", "業務状態"});
        words.put("mobile", new String[] {"电话", "Phone", "電話"});
        words.put("receiverName", new String[] {"收件人", "Receiver", "受取人"});
        words.put("address", new String[] {"地址", "Address", "住所"});
        words.put("email", new String[] {"邮箱", "Email", "メール"});
        words.put("organizationText", new String[] {"联系人单位", "Contact organization", "連絡先所属"});
        List<Map<String, Object>> fields = new ArrayList<>(),
                columns = new ArrayList<>(),
                actions = new ArrayList<>();
        String name = contact ? "contactName" : "partnerName";
        for (String id :
                contact
                        ? List.of(name, "mobile", "organizationText", "businessState")
                        : List.of(
                                name,
                                "partnerKind",
                                "customerRole",
                                "supplierRole",
                                "mobile",
                                "receiverName",
                                "address",
                                "email",
                                "businessState")) {
            boolean toggle =
                    Set.of("partnerKind", "customerRole", "supplierRole", "businessState")
                            .contains(id);
            Map<String, String> valueLabels =
                    id.equals("partnerKind")
                            ? Map.of(
                                    "ORG",
                                    new String[] {"企业", "Organization", "企業"}[locale],
                                    "PERSON",
                                    new String[] {"个人", "Person", "個人"}[locale])
                            : id.equals("businessState")
                                    ? Map.of(
                                            "ACTIVE",
                                            new String[] {"启用", "Active", "有効"}[locale],
                                            "INACTIVE",
                                            new String[] {"停用", "Inactive", "無効"}[locale])
                                    : Set.of("customerRole", "supplierRole").contains(id)
                                            ? Map.of(
                                                    "true",
                                                    new String[] {"是", "Yes", "はい"}[locale],
                                                    "false",
                                                    new String[] {"否", "No", "いいえ"}[locale])
                                            : Map.of();
            fields.add(
                    Map.of(
                            "valueLabels",
                            valueLabels,
                            "id",
                            id,
                            "label",
                            words.get(id)[locale],
                            "readOnly",
                            toggle || !writable,
                            "maxLength",
                            id.equals("address")
                                    ? 1000
                                    : id.equals("mobile")
                                            ? 50
                                            : Set.of("contactName", "receiverName").contains(id)
                                                    ? 100
                                                    : 200));
            if (List.of(name, "mobile", "businessState").contains(id)) {
                columns.add(Map.of("id", id, "field", id, "label", words.get(id)[locale]));
            }
            if (toggle) {
                actions.add(
                        Map.of(
                                "id",
                                "toggle-" + id,
                                "label",
                                new String[] {"切换", "Toggle", "切替"}[locale]
                                        + " "
                                        + words.get(id)[locale],
                                "toggleField",
                                id,
                                "values",
                                (id.equals("partnerKind")
                                                ? List.of("ORG", "PERSON")
                                                : id.equals("businessState")
                                                        ? List.of("ACTIVE", "INACTIVE")
                                                        : List.of("true", "false"))
                                        .stream().map(valueLabels::get).toList()));
            }
        }
        actions.add(Map.of("id", "new", "label", new String[] {"新建", "New", "新規"}[locale]));
        actions.add(
                Map.of(
                        "id",
                        "reload",
                        "label",
                        new String[] {"重载详情", "Reload detail", "再読み込み"}[locale]));
        actions.add(
                Map.of(
                        "id",
                        "save",
                        "label",
                        new String[] {"保存", "Save", "保存"}[locale],
                        "tone",
                        "primary"));
        String title =
                new String[] {
                            contact ? "联系人维护" : "客户主体维护",
                            contact ? "Contact maintenance" : "Customer maintenance",
                            contact ? "連絡先管理" : "顧客管理"
                        }
                        [locale];
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("synthetic", true);
        data.put("writeEnabled", writable);
        data.put("locale", lang);
        data.put("title", title);
        data.put(
                "notice",
                new String[] {
                            "隔离测试环境 · 仅合成账号、许可和数据 · 生产写入未开放",
                            "Isolated test · synthetic identity, permission and data · production"
                                    + " writes disabled",
                            "隔離テスト · 合成アカウント・権限・データのみ · 本番書込み未開放"
                        }
                        [locale]);
        data.put(
                "form",
                Map.of(
                        "id",
                        contact ? "crm-contact-editor" : "crm-partner-editor",
                        "title",
                        title,
                        "fields",
                        fields,
                        "actions",
                        actions));
        data.put(
                "defaults",
                contact
                        ? Map.of(
                                "contactName",
                                "",
                                "mobile",
                                "",
                                "organizationText",
                                "",
                                "businessState",
                                "ACTIVE")
                        : Map.of(
                                "partnerName",
                                "",
                                "partnerKind",
                                "ORG",
                                "customerRole",
                                "true",
                                "supplierRole",
                                "false",
                                "mobile",
                                "",
                                "receiverName",
                                "",
                                "address",
                                "",
                                "email",
                                "",
                                "businessState",
                                "ACTIVE"));
        data.put(
                "messages",
                Map.of(
                        "dirty",
                        new String[] {
                                    "有未保存修改，请先保存或重载详情。",
                                    "Unsaved changes. Save or reload detail first.",
                                    "未保存の変更があります。保存または再読込みしてください。"
                                }
                                [locale],
                        "saved",
                        new String[] {
                                    "已保存；列表与详情来自数据库。",
                                    "Saved; list and detail are from the database.",
                                    "保存済み。リストと詳細はデータベースから取得しました。"
                                }
                                [locale]));
        data.put(
                "grid",
                Map.of(
                        "grid",
                        Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id"),
                        "data",
                        Map.of(
                                "items",
                                page.getRecords().stream()
                                        .map(CrmPartnerWorkspaceSupport::browserRecord)
                                        .toList(),
                                "selectedIds",
                                List.of()),
                        "column",
                        Map.of("items", columns),
                        "select",
                        Map.of(
                                "pageSize",
                                Map.of(
                                        "ariaLabel",
                                        new String[] {"每页显示行数", "Rows per page", "ページあたり行数"}
                                                [locale],
                                        "options",
                                        List.of(10, 20, 50, 100).stream()
                                                .map(
                                                        size ->
                                                                Map.of(
                                                                        "value",
                                                                        size.toString(),
                                                                        "label",
                                                                        size
                                                                                + new String[] {
                                                                                            " 行/页",
                                                                                            " rows/page",
                                                                                            " 行/ページ"
                                                                                        }
                                                                                        [locale]))
                                                .toList())),
                        "title",
                        Map.of("messages", Map.of("selectProject", title)),
                        "pagination",
                        Map.of(
                                "mode",
                                "REMOTE",
                                "totalCount",
                                page.getTotalCount(),
                                "currentPage",
                                page.getPageNo(),
                                "pageSize",
                                page.getPageSize(),
                                "previousLabel",
                                new String[] {"上一页", "Previous", "前へ"}[locale],
                                "nextLabel",
                                new String[] {"下一页", "Next", "次へ"}[locale],
                                "summaryAll",
                                new String[] {"共 {total} 条", "{total} records", "合計 {total} 件"}
                                        [locale])));
        return CrmPartnerValueSupport.result(data);
    }
}
