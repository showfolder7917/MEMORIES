/**
 * CrmDraftRequestService.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.draftrequest.service;

import com.sp.selplat.common.service.BaseService;

/** 私人请求重放记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmDraftRequestService extends BaseService {
}
