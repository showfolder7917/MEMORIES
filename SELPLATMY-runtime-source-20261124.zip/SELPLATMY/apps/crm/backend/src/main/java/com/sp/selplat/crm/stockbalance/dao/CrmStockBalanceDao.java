/** CrmStockBalanceDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.stockbalance.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

/** 本人隔离过账记录 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmStockBalanceDao extends BaseDao {
    /**
     * 本表固定 SQL 扩展 lockScoped；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表固定 SQL 扩展 applyDeltaIfVersion；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    int applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input);

    /**
     * 组织V2出库，旧owner入口保留。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    java.util.Map<String, Object> lockOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查
     * @return 本表实际结果或无返回；零CAS、缺许可或约束异常整笔回滚
     */
    int issueOrganization(CommonParam input);

    /**
     * 采购入库固定正数量CAS，余额上限和版本均在SQL重核。
     *
     * @param input tenant92/org901/id880001/version0/quantity2/actor9211
     * @return 实际影响行数1；旧版本、数量溢出或范围不符为0，服务必须回滚
     */
    int receiveOrganization(CommonParam input);
}
