/** CrmProduct本表参数化DAO；2026-10-03，Codex。 */
package com.sp.selplat.crm.product.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/** 只执行本表固定SQL，与公共DAO共享同一CRM池和事务。 */
@Repository
public class CrmProductDaoImpl extends CrmBaseDao implements CrmProductDao {
    private final JdbcTemplate jdbc;

    /**
     * 装配本表CRM模板；示例crmJdbcTemplate；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmProductDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 保留sortnum主排序，以范围内唯一ID稳定商品参考分页。
     *
     * @param conditions 服务核验的范围及启用条件，例如tenant92/org901/ACTIVE
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 真实分页，例如records含商品702、totalCount2；只读且不扩大范围
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 相同sortnum不能让第二页重复首条；COUNT及参数化分页仍交给公共DAO。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 锁本表范围行；scope92/901/id600000；返回真实行或null，要求CRM事务。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmProduct WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }
    /**
     * 本表精确CAS维护，仅规范商品资料和服务器审计人可写。
     * @param p 可信tenant92/org901/id700000/expectedVersion0及编码BOOK-001
     * @return 实际影响行数，例如1；旧版本0行
     * 副作用示例：成功versionNo变1，不改商品类型、单位、库存或订单。
     */
    @Override
    public int updateVersion(CommonParam p) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmProduct SET productCode=?,productName=?,specification=?,purchasePriceMinor=?,salePriceMinor=?,"
                        + "businessState=?,termUnit=?,termCount=?,renewalMode=?,activationSystemCode=?,updatedByUserId=?,"
                        + "lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP,versionNo=versionNo+1"
                        + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?",
                p.getParam("productCode"), p.getParam("productName"), p.getParam("specification"),
                p.getParam("purchasePriceMinor"), p.getParam("salePriceMinor"), p.getParam("businessState"),
                p.getParam("termUnit"), p.getParam("termCount"), p.getParam("renewalMode"), p.getParam("activationSystemCode"),
                p.getParam("actorUserId"), p.getParam("actorUserId"), p.getParam("tenantId"), p.getParam("businessOrgId"),
                p.getParam("id"), p.getParam("expectedVersion"));
    }

}
