/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.document.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

/** HTTP只调用本表owning服务，通用写没有路由。 */
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/crm/document")
public class CrmDocumentController {
    private final com.sp.selplat.crm.document.service.CrmDocumentService service;

    /**
     * 注入本表服务；构造不执行SQL。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmDocumentController(com.sp.selplat.crm.document.service.CrmDocumentService service) {
        this.service = service;
    }

    /**
     * 公共范围分页。
     *
     * @param input 例如org901/page1
     * @return 实际公共分页JSON；缺许可拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 公共范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 实际公共结果JSON；跨组织拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }

    /**
     * 实际saveDraft具名命令，审核不扣库存。
     *
     * @param input 例如org901/id1000000/version0/keyk1
     * @return 公共JSON实际状态；整笔失败回滚
     */
    @org.springframework.web.bind.annotation.PostMapping("saveDraft.htm")
    public String saveDraft(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.saveDraft(input));
    }

    /**
     * 实际submit具名命令，审核不扣库存。
     *
     * @param input 例如org901/id1000000/version0/keyk1
     * @return 公共JSON实际状态；整笔失败回滚
     */
    @org.springframework.web.bind.annotation.PostMapping("submit.htm")
    public String submit(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.submit(input));
    }

    /**
     * 实际approve具名命令，审核不扣库存。
     *
     * @param input 例如org901/id1000000/version0/keyk1
     * @return 公共JSON实际状态；整笔失败回滚
     */
    @org.springframework.web.bind.annotation.PostMapping("approve.htm")
    public String approve(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.approve(input));
    }

    /**
     * 真实审核销售来源选择。
     *
     * @param input 例如org901/orderId600000
     * @return 实际全部冻结行JSON，跨组织拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("source.htm")
    public String source(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.source(input));
    }
}
