/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingbatch.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmPostingBatchDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 方法作用：按真实单据查询不可变批次历史，不用status隐藏冲正关系。
     *
     * @param input tenant92/org901/documentId1000000
     * @return 实际POST与REVERSE批次或空列表 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    List<Map<String, Object>> findForDocument(CommonParam input);
}
