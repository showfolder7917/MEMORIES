/** CrmProduct：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.product.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

import java.util.Map;

/** 本表owning接口，不暴露通用无版本业务写。 */
public interface CrmProductService extends BaseService {
    /**
     * 商品具名保存，业务、回执和审计同事务。
     * @param input 商品编码BOOK-001/requestKeyp1；编辑含id700000/version0
     * @return 实际回执data.id=700000、versionNo=0、replay=false；失败整笔回滚
     */
    CommonResult save(CommonParam input);
    /**
     * 现有订单读范围内仅预览c_product原词法候选，不写产品或迁入批次。
     *
     * @param input 声明值，例如{organizationCandidateId=901,mode=DRY_RUN,sourceSystem=ERP,records=[]}
     * @return 公共待审报告，例如{success=true,data={writeEnabled=false,typedImportBlocked=true,pendingReview=[]}}
     *     异常或副作用示例：现有范围未获准仍拒绝；原状态/单位不推导为ACTIVE/EA。
     */
    CommonResult migrationPreflight(CommonParam input);

    /**
     * 同事务锁真实商品；org901/id701/actioncrm.order.write；返回实际ACTIVE/EA商品，缺记录拒绝。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：同事务锁真实商品；org901/id701/actioncrm.order.write；返回实际ACTIVE/EA商品，缺记录拒绝。
     * @param action 服务内部选择的固定动作，例如crm.order.write；不得据客户端动作补授权限。
     * @return 实际ACTIVE/EA商品，缺记录拒绝
     */
    Map<String, Object> lockForOrder(CommonParam input, String action);
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 商品维护候选org901/page1
     * @return 实际公共分页totalCount1；缺许可拒绝
     */
    com.sp.selplat.common.util.CommonPageResult managementStore(com.sp.selplat.common.util.CommonPageParam input);
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 商品候选org901/id700000
     * @return 实际详情data.id字符串；跨组织拒绝
     */
    CommonResult detail(CommonParam input);
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 工作区候选org901/page1
     * @return 实际公共配置data.grid；缺读取许可拒绝
     */
    CommonResult workspace(com.sp.selplat.common.util.CommonPageParam input);

}
