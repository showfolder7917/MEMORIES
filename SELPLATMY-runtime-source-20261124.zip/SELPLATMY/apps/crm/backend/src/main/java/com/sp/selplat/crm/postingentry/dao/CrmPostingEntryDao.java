/** CrmPostingEntryDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingentry.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** 本人隔离过账记录 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmPostingEntryDao extends BaseDao {
    /**
     * 本表固定 SQL 扩展 findOriginal；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    java.util.Map<String, Object> findOriginal(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表固定 SQL 扩展 appendEntry；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    int appendEntry(com.sp.selplat.common.util.CommonParam input);

    /**
     * 统计已存在原流水；输入例如sourceDocumentId101；返回数量；须CRM事务，不删除历史。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：统计已存在原流水；输入例如sourceDocumentId101；返回数量；须CRM事务，不删除历史。
     * @return 数量
     */
    Long countSourcePosts(com.sp.selplat.common.util.CommonParam input);
}
