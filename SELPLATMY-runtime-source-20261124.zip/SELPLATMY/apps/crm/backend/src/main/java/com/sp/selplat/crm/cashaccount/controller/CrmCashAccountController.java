/** 单一销售收款隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.cashaccount.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

/** HTTP只调用本表owning服务，通用写没有路由。 */
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/crm/cashaccount")
public class CrmCashAccountController {
    private final com.sp.selplat.crm.cashaccount.service.CrmCashAccountService service;

    /**
     * 注入本表服务；构造不执行SQL。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmCashAccountController(
            com.sp.selplat.crm.cashaccount.service.CrmCashAccountService service) {
        this.service = service;
    }

    /**
     * 公共范围分页。
     *
     * @param input 例如org901/page1
     * @return 实际公共分页JSON；缺许可拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 公共范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 实际公共结果JSON；跨组织拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }
    /**
     * 方法作用：公开账户维护只委托原账户拥有方，客户端不能传入可信权限或余额。
     * @param input 原JSON候选，例如org901/accountCodeSCHOOL-CNY/requestKeyaccount-1
     * @return 真实返回示例：success=true/data.id="1600000"/versionNo="0"。
     * 异常或副作用示例：缺原资金写资格拒绝，正常保存仅改变当前组织账务账户。
     */
    @org.springframework.web.bind.annotation.PostMapping("save.htm")
    public String save(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.saveAccount(input));
    }
}
