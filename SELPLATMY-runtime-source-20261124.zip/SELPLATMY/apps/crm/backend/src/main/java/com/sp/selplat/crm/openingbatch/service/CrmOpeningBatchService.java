/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.openingbatch.service;

import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmOpeningBatchService extends com.sp.selplat.common.service.BaseService {

  /**
   * 精确本组织内部锁；缺实际许可或事务拒绝。
   *
   * @param input org901/id1000000
   * @param action 固定stock.post等动作
   * @return 真实范围行；不存在统一拒绝
   */
  Map<String, Object> lockScoped(CommonParam input, String action);

  /**
   * 已审核期初在本步只读不可变，无需在余额锁组后再加期初写锁。
   *
   * @param input 例如org901/id9901，真实post scope由Session核验
   * @return 本组织实际APPROVED期初；不存在/未审核拒绝
   */
  Map<String, Object> requireApprovedForPost(CommonParam input);

  /**
   * Actual immutable approved opening basis for a receipt balance.
   *
   * @param input org901/id9901
   * @return scoped approved opening or rejection; no opening writes
   */
  Map<String, Object> requireApprovedForFundsPost(CommonParam input);

  /**
   * 方法作用：原资金许可下维护期初草稿、提交、异人审核或驳回；审批与余额建立同库原子完成。
   *
   * @param input
   *     例如org901/operationSAVE/account90101/amountMinor0/cutoff2026-10-28T00:00:00Z/keyopening-1
   * @return 真实返回示例：data.id900000/versionNo0/openingStateDRAFT；重试replay=true。
   *     异常或副作用示例：自审、越租户、旧版本和同键异正文拒绝，不改原审核政策。
   */
  com.sp.selplat.common.util.CommonResult maintainFunds(CommonParam input);

  /**
   * 方法作用：为原余额拥有方读取同一事务内真实已批准资金期初，不接受客户端批准证据。
   *
   * @param input org901/id900000，动作固定原funds.approve
   * @return 真实示例：APPROVED/account90101/currencyCNY/fundsAmountMinor0的原行。
   *     异常或副作用示例：非本功能期初、非批准状态或无真实审核许可拒绝。
   */
  Map<String, Object> approvedFundsSource(CommonParam input);

  /**
   * 方法作用：只读本组织资金期初的实际分页。
   *
   * @param input org901/pageNo1/pageSize20
   * @return 真实示例：records含资金期初900000、totalCount1。 异常或副作用示例：缺funds.read拒绝，不混入库存期初。
   */
  com.sp.selplat.common.util.CommonPageResult fundsStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：回读指定资金期初及脱敏后的历史。
   *
   * @param input org901/id900000
   * @return 真实示例：data.openingStateDRAFT及history一条SAVE。 异常或副作用示例：无原资金读资格或跨组织拒绝。
   */
  com.sp.selplat.common.util.CommonResult readFunds(CommonParam input);
}
