/** 一期原明细容量DAO实现；2026-10-04，Codex；只访问CrmPostingCapacity。 */
package com.sp.selplat.crm.postingcapacity.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/** CRM同连接条件CAS，DB CHECK再防数量或金额双占用。 */
@Repository
public class CrmPostingCapacityDaoImpl extends CrmBaseDao implements CrmPostingCapacityDao {
    // 固定本域模板与当前真实CRM事务共享连接，不借独立写连接。
    private final JdbcTemplate jdbc;

    /**
     * 绑定固定CRM SQL模板；构造不创建容量或改动原流水。
     *
     * @param jdbc Spring具名crmJdbcTemplate，例如合成tenant92容量库模板
     */
    public CrmPostingCapacityDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 获取真实范围内原明细容量锁。
     *
     * @param input tenant92/org901/original1300000/kind ISSUE_RETURN
     * @return 实际Map，例如{capacityQuantity:3,usedQuantity:1,versionNo:1}；不存在null
     */
    @Override
    public Map<String, Object> lockForOriginal(CommonParam input) {
        requireCrmTransaction();
        // 复合范围和类型唯一键 -> 同组织同原明细所有actor共享一份容量。
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingCapacity WHERE tenantId=? AND businessOrgId=? AND"
                                + " originalDetailId=? AND capacityKind=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("originalDetailId"),
                        input.getParam("capacityKind"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 按范围、原锁版本和DB容量边界执行一次占用或逆向释放。 实际写入示例：数量占用从0增加到1，版本从0增加到1；旧版本影响0行。
     *
     * @param input id100000/version0，quantityDelta1或minorDelta67，可信actor9211
     * @return 影响1或0行；数量或金额越界与旧版本拒绝，没有部分写
     */
    @Override
    public int adjust(CommonParam input) {
        requireCrmTransaction();
        // 两种固定SQL分支，不把客户端字段插进SQL；上限条件与CAS同一语句。
        if (input.getParam("quantityDelta") != null) {
            return jdbc.update(
                    "UPDATE CrmPostingCapacity SET usedQuantity=usedQuantity+?, "
                            + "versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?, "
                            + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? "
                            + "AND id=? AND versionNo=? AND versionNo<9223372036854775807 "
                            + "AND status=1 AND capacityKind='ISSUE_RETURN' "
                            + "AND usedQuantity+? BETWEEN 0 AND capacityQuantity",
                    input.getParam("quantityDelta"),
                    input.getParam("actorUserId"),
                    input.getParam("actorUserId"),
                    input.getParam("tenantId"),
                    input.getParam("businessOrgId"),
                    input.getParam("id"),
                    input.getParam("versionNo"),
                    input.getParam("quantityDelta"));
        }
        return jdbc.update(
                "UPDATE CrmPostingCapacity SET usedMinor=usedMinor+?, "
                        + "versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?, "
                        + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? "
                        + "AND id=? AND versionNo=? AND versionNo<9223372036854775807 "
                        + "AND status=1 AND capacityKind IN ('RECEIPT_REFUND','RETURN_REFUND') "
                        + "AND usedMinor+? BETWEEN 0 AND capacityMinor",
                input.getParam("minorDelta"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("versionNo"),
                input.getParam("minorDelta"));
    }
}
