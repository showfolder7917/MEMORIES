/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.documentline.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.documentline.dao.CrmDocumentLineDao;
import com.sp.selplat.crm.documentline.service.CrmDocumentLineService;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。
 */
@org.springframework.stereotype.Service
public class CrmDocumentLineServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmDocumentLineDao>
    implements CrmDocumentLineService {

  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  /**
   * 绑定实际范围校验，不授予库存或资金许可。
   *
   * @param access 实际CrmAccessService，例如核验tenant92/org901的服务
   */
  public CrmDocumentLineServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
    this.access = access;
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var p = CrmPartnerValueSupport.page(input, scope, null);
    String documentKind = CrmStockValueSupport.pageKind(input.getParam("documentKind"));
    p.putParam("documentKind", documentKind);
    p.putParam(
        "reason",
        CrmStockValueSupport.pageReason(
            documentKind, input.getParam("reason"), returnsAvailable()));
    var page = super.getStore(p);
    page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
    return page;
  }

  /**
   * 公共真实范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 本组织有效记录；不存在统一拒绝
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null
        || !CrmStockValueSupport.isStockDocument(
            row.get("documentKind"), row.get("reason"), returnsAvailable())
        || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null
        || (action.startsWith("crm.funds.")
            && !com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.isFundsDocument(
                row.get("documentKind"), row.get("reason"), returnsAvailable()))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    if (!action.startsWith("crm.funds.")
        && !CrmStockValueSupport.isStockDocument(
            row.get("documentKind"), row.get("reason"), returnsAvailable())) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 全量父行；固定本表事务扩展。
   *
   * @param input 例如org901/id1000000及实际服务器字段
   * @param action 固定库存动作，例如crm.stock.post，必须对应真实许可
   * @return 实际本表结果；缺范围/事务拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public List<Map<String, Object>> readAll(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("documentId", CrmPartnerValueSupport.positive(input.getParam("documentId")));
    return getDao().readAll(p);
  }

  /**
   * 插入本表有效行；固定本表事务扩展。
   *
   * @param input 例如org901/id1000000及实际服务器字段
   * @param action 固定库存动作，例如crm.stock.post，必须对应真实许可
   * @return 实际本表结果；缺范围/事务拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Long append(CommonParam input, String action) {
    documents.getObject().requireDraftLines(input);
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = CrmPartnerValueSupport.entity(input, scope);
    row.getParamMap().remove("versionNo");
    row.getParamMap().remove("headerVersion");
    row.putParam("id", getSequence().get("id"));
    try {
      CrmPartnerValueSupport.changed(getDao().insert(row));
    } catch (org.springframework.dao.DuplicateKeyException failure) {
      String message =
          String.valueOf(failure.getMostSpecificCause().getMessage())
              .toLowerCase(java.util.Locale.ROOT);
      if (input.getParam("courseReservationId") != null
          && message.contains("uq_crm_document_line_course_reservation")) {
        throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_ALREADY_LINKED");
      }
      throw failure;
    }
    return (Long) row.getParam("id");
  }

  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.document.service.CrmDocumentService>
      documents;

  /**
   * 真实DRAFT全量行替换前重新校验父单状态与版本。
   *
   * @param input org901/documentId1000000/headerVersion0；资金入口明确documentKind
   *     异常或副作用示例：删除实际草稿行；非DRAFT、旧版本或缺许可整笔回滚，不修改冻结单据。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void clearDraft(CommonParam input) {
    documents.getObject().requireDraftLines(input);
    var scope =
        access.requireBusinessScope(
            input.getParam("organizationCandidateId"),
            ("FUNDS_RECEIPT".equals(input.getParam("documentKind"))
                    || "FUNDS_PAYMENT".equals(input.getParam("documentKind")))
                ? "crm.funds.write"
                : "crm.stock.write");
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("documentId", input.getParam("documentId"));
    getDao().deleteAll(p);
  }

  /**
   * 方法作用：owning行服务按真实冲正范围查下游引用。
   *
   * @param input org901/parent1300000
   * @return 实际行，不信人工依赖布尔值 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public List<Map<String, Object>> receiptChildren(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.reverse");
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("parentDetailId", CrmPartnerValueSupport.positive(input.getParam("parentDetailId")));
    return getDao().receiptChildren(p);
  }

  // 本域新增退货引用只在显式结构中允许，不扩动作许可。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
  private Boolean returnsEnabled;

  /**
   * 方法作用：隔离测试沿用原开关，正式模式只在真实退货结构已安装时使用退货合同。
   * @return 真实返回示例：已安装容量与依赖表的正式模式true，默认或旧结构false。
   * 异常或副作用示例：只读结构；不授予库存动作或打开资金权限。
   */
  private boolean returnsAvailable() {
    return Boolean.TRUE.equals(returnsEnabled) || access.formalCapabilityAvailable("salesReturn");
  }
}
