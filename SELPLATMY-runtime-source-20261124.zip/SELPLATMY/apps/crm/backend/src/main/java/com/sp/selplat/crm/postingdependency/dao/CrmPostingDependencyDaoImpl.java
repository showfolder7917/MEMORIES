/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdependency.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmPostingDependencyDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmPostingDependencyDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 实际crmJdbcTemplate，不授权或更改连接归属
     */
    public CrmPostingDependencyDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingDependency WHERE tenantId=? AND businessOrgId=?"
                                + " AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：读取真实FK依赖，不按status屏蔽已记账子明细。
     *
     * @param input tenant92/org901/parent1300000
     * @return 实际依赖行，是否有效由真实账本派生 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public List<Map<String, Object>> parentEdges(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingDependency WHERE tenantId=? AND businessOrgId=? AND"
                        + " parentDetailId=? ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("parentDetailId"));
    }

    /**
     * 只查询本表真实child边；例如1300002返回两种不可变边，不锁跨表对象。
     *
     * @param input tenant92/org901/childDetailId1300002
     * @return 本表真实边列表，不写入
     */
    @Override
    public List<Map<String, Object>> childEdges(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingDependency WHERE tenantId=? AND businessOrgId=? AND"
                        + " childDetailId=? ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("childDetailId"));
    }
}
