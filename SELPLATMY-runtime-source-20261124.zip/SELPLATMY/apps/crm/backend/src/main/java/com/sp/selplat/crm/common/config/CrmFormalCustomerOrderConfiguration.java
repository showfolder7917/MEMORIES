/* 2026-10-27：正式客户商品订单安装入口；只附加明确的本域结构，不重建旧表。 */
package com.sp.selplat.crm.common.config;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

/** 正式安装与隔离测试分别启用；保留旧私人草稿、库存余额和全部业务行。 */
@Configuration(proxyBeanMethods = false)
public class CrmFormalCustomerOrderConfiguration {
  // 复用拥有方原SQL及依赖顺序；客户端不能增加表或提供SQL。
  private static final List<String> TABLES =
      List.of(
          "CrmPartner",
          "CrmContact",
          "CrmProduct",
          "CrmOrder",
          "CrmOrderLine",
          "CrmCommandRequest",
          "CrmBusinessAudit");

  // 安装成功必须由原元数据检查器证明三项实际能力，不凭配置宣告可操作。
  private static final Set<String> CAPABILITIES = Set.of("partner", "product", "order");

  /**
   * 方法作用：显式部署时安装全新七表；已有完整结构只读核验，未知同名结构在DDL前拒绝。
   * @param source 拥有方实际CRM源，例如生产文件库crm；不连接认证或教学库
   * @param install 明确部署开关，例如crm.formal.customer-order-install-enabled=true
   * @param authorized 正式接入开关，例如crm.authorization.enabled=true；不是任何操作员授权
   * @return 真实返回示例：未请求安装false；原检查器证明客户商品订单结构完整为true。
   * @throws IllegalStateException 已有不完整同名表、活动事务或未启正式接入时拒绝；不覆盖业务行
   * @throws SQLException 实际元数据读取失败时传播，不能伪装成空库继续安装
   */
  @Bean("crmFormalCustomerOrderInitialized")
  @DependsOn("crmPartnerMaintenanceInitialized")
  public Boolean initialize(
      @Qualifier("crmDataSource") DataSource source,
      @Value("${crm.formal.customer-order-install-enabled:false}") boolean install,
      @Value("${crm.authorization.enabled:false}") boolean authorized)
      throws SQLException {
    if (!install) {
      return false;
    }
    // DDL可能隐式提交，不能嵌入业务事务，也不能用安装开关代替正式接入配置。
    if (!authorized || TransactionSynchronizationManager.isActualTransactionActive()) {
      throw new IllegalStateException("CRM_FORMAL_INSTALL_CONFIGURATION_INVALID");
    }
    var inspector = new CrmBusinessStructureInspector(source);
    if (inspector.available().containsAll(CAPABILITIES)) {
      return true;
    }
    // 不对未知已有表执行CREATE IF NOT EXISTS后冒充升级成功；更不删除原表或重置游标。
    try (var connection = source.getConnection()) {
      for (String table : TABLES) {
        try (var rows =
            connection
                .getMetaData()
                .getTables(connection.getCatalog(), connection.getSchema(), table, null)) {
          if (rows.next()) {
            throw new IllegalStateException("CRM_FORMAL_INSTALL_STRUCTURE_CONFLICT");
          }
        }
      }
    }
    ResourceDatabasePopulator scripts = new ResourceDatabasePopulator();
    for (String table : TABLES) {
      scripts.addScript(new ClassPathResource("db/crm/sql/schema-" + table + ".sql"));
    }
    scripts.execute(source);
    // 原号段脚本仅补缺；既有nextStartId、版本及任何业务记录都保持原值。
    new TransactionTemplate(new DataSourceTransactionManager(source))
        .executeWithoutResult(
            state ->
                new ResourceDatabasePopulator(
                        new ClassPathResource("db/crm/sql/data-CommonSequenceSegment.sql"))
                    .execute(source));
    if (!inspector.available().containsAll(CAPABILITIES)) {
      throw new IllegalStateException("CRM_FORMAL_INSTALL_VERIFICATION_FAILED");
    }
    return true;
  }
}
