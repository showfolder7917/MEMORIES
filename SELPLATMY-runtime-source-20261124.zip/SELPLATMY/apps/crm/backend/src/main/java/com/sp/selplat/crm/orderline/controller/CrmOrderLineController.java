/** CrmOrderLine：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.orderline.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.orderline.service.CrmOrderLineService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表Controller只消费owning Service和公共结果。 */
@RestController
@RequestMapping("/api/crm/orderline")
public class CrmOrderLineController {
    private final CrmOrderLineService service;

    /**
     * 装配owning服务，不读写数据库；示例为真实CrmOrderLineServiceImpl。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmOrderLineController(CrmOrderLineService service) {
        this.service = service;
    }

    /**
     * 实际范围分页；org901/page1；返回公共分页，无许可拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，限定本组织/status1；商品选择另限定ACTIVE
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 实际范围详情；org901/id600000；返回公共data，无记录或跨组织拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/全部行或product701；拒绝不存在/越范围
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }
}
