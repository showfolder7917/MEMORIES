/** 完整库存冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.stockreversalrequest.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

/** HTTP只调用本表owning服务，通用写没有路由。 */
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/crm/stockreversalrequest")
public class CrmStockReversalRequestController {
    private final com.sp.selplat.crm.stockreversalrequest.service.CrmStockReversalRequestService
            service;

    /**
     * 注入本表只读服务，通用写路由不存在。
     *
     * @param service 实际CrmStockReversalRequestServiceImpl
     */
    public CrmStockReversalRequestController(
            com.sp.selplat.crm.stockreversalrequest.service.CrmStockReversalRequestService
                    service) {
        this.service = service;
    }

    /**
     * 公共范围分页。
     *
     * @param input 例如org901/page1
     * @return 实际公共分页JSON；缺许可拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 公共范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 实际公共结果JSON；跨组织拒绝
     */
    @org.springframework.web.bind.annotation.GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }
}
