/* 客户稳定编号关系本表SQL；2026-10-28。 */
package com.sp.selplat.crm.customerrelation.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 两个方向共用一条原关系，不复制反向事实，不访问客户表。 */
@Repository
public class CrmCustomerRelationDaoImpl extends CrmBaseDao implements CrmCustomerRelationDao {
    // 复用原CRM模板、池及事务。
    private final JdbcTemplate jdbc;

    /**
     * 方法作用：绑定原具名模板，不创建新数据源。
     * @param jdbc 实际crmJdbcTemplate，例如本例私有内存CRM池
     * 异常或副作用示例：构造不执行SQL。
     */
    public CrmCustomerRelationDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 方法作用：用固定双向条件分页关系，页容量和范围由Service校验。
     * @param input 可信坐标，例如tenant92/org901/partner200000
     * @param page 实际页码，例如2
     * @param size 实际页长，例如20
     * @return 真实返回示例：totalCount21/pageNo2/pageSize20/records1条。
     * 异常或副作用示例：只读关系表，不按JSON或姓名猜测关联。
     */
    @Override
    public CommonPageResult page(CommonParam input, int page, int size) {
        String where = " FROM CrmCustomerRelation WHERE tenantId=? AND businessOrgId=? AND status=1"
                + " AND (partnerId=? OR relatedPartnerId=?)";
        Object tenant = input.getParam("tenantId"), org = input.getParam("businessOrgId"), partner = input.getParam("partnerId");
        CommonPageResult result = new CommonPageResult();
        result.setTotalCount(jdbc.queryForObject("SELECT COUNT(*)" + where, Long.class, tenant, org, partner, partner));
        result.setRecords(jdbc.queryForList("SELECT *" + where + " ORDER BY id ASC LIMIT ? OFFSET ?",
                tenant, org, partner, partner, size, ((long) page - 1) * size));
        result.setPageNo(page);
        result.setPageSize(size);
        return result;
    }

    /**
     * 方法作用：按精确两端主键和版本保存本关系，不允许移动到另一个客户。
     * @param input 本表更新，例如tenant92/org901/partner200000/related200001/expectedVersion1
     * @return 真实返回示例：1，版本不符为0。
     * 异常或副作用示例：没有原CRM事务拒绝；不删除原历史。
     */
    @Override
    public int updateVersion(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update("UPDATE CrmCustomerRelation SET relationName=?,enabledFlag=?,changeHistoryJson=?,"
                + "lastOperateUserId=?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP "
                + "WHERE tenantId=? AND businessOrgId=? AND partnerId=? AND relatedPartnerId=? AND status=1 AND versionNo=?",
                input.getParam("relationName"), input.getParam("enabledFlag"), input.getParam("changeHistoryJson"),
                input.getParam("lastOperateUserId"), input.getParam("tenantId"), input.getParam("businessOrgId"),
                input.getParam("partnerId"), input.getParam("relatedPartnerId"), input.getParam("expectedVersion"));
    }
}
