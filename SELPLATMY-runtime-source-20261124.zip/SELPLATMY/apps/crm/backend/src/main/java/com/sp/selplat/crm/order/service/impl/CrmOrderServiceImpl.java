/** CrmOrder：本域订单隔离小步；2026-10-08，Codex；订单号精确查询，不开放生产授权。
 * 修改记录：2026-10-10，采购owning锁缺动作在身份和数据库读取前明确拒绝。 */
/* 修改记录：2026-10-28，原资金来源分页支持精确来源编号，销售与采购范围继续独立。 */
package com.sp.selplat.crm.order.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.order.dao.CrmOrderDao;
import com.sp.selplat.crm.order.service.CrmOrderService;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** 本表直接复用公共CRUD、公共号段；只有具名命令可写，默认生产拒绝。 */
@Service
public class CrmOrderServiceImpl extends BaseServiceImpl<CrmOrderDao> implements CrmOrderService {
    // 每次从真实Session和隔离许可表核范围，不消费客户端tenant/actor。
    private final CrmAccessService access;
  // 可选只读端口由Host组合教学拥有方；独立CRM不依赖教学工程。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmOrderBeneficiaries")
  private org.springframework.beans.factory.ObjectProvider<
          java.util.function.BiFunction<Map<String, Object>, CommonParam, Map<String, Object>>>
      beneficiaryOwner;
    // 所有跨表事实经owning服务读取，禁止跨表DAO或自建数据库上下文。
    private final com.sp.selplat.crm.partner.service.CrmPartnerService partners;
    private final com.sp.selplat.crm.product.service.CrmProductService products;
    private final com.sp.selplat.crm.orderline.service.CrmOrderLineService lines;
    private final com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests;
    private final com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;
    private final org.springframework.transaction.support.TransactionTemplate transaction;

    /**
     * 装配本域owning服务和具名事务模板，不直接访问其他表DAO。
     *
     * @param access 实际Session/业务范围入口，例如tenant92/org901
     * @param partners 真实客户供应商owning服务，例如锁定供应商501
     * @param products 真实商品owning服务，例如锁定商品701
     * @param lines 真实订单行owning服务，保存完整两行
     * @param requests 真实命令请求owning服务，保证首次结果回放
     * @param audit 真实业务审计owning服务，末尾失败回滚
     * @param manager crmTransactionManager；构造模板不提交业务事务
     */
    public CrmOrderServiceImpl(
            CrmAccessService access,
            com.sp.selplat.crm.partner.service.CrmPartnerService partners,
            com.sp.selplat.crm.product.service.CrmProductService products,
            com.sp.selplat.crm.orderline.service.CrmOrderLineService lines,
            com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests,
            com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit,
            @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
                    org.springframework.transaction.PlatformTransactionManager manager) {
        this.access = access;
        this.partners = partners;
        this.products = products;
        this.lines = lines;
        this.requests = requests;
        this.audit = audit;
        transaction = new org.springframework.transaction.support.TransactionTemplate(manager);
        transaction.setPropagationBehavior(
                org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(
                org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 标准范围订单分页；org901/page1/orderId600000；委托公共DAO精确过滤，缺范围拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，例如orderState=SUBMITTED时records=[id600000]/totalCount1；限定本组织/status1，非法订单号或未知状态拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
    // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var page = CrmPartnerValueSupport.page(input, scope, null);
        // 复用CommonPageParam的缺省/正数规范；本域只补原int偏移量合同的安全上界。
        requireSafePageOffset(page.getPageNo(), page.getPageSize());
        // 订单号只接受精确正整数；真实范围仍由当前身份裁决，READ与COUNT共用原DAO条件。
        if (input.getParam("orderId") != null) {
            page.putParam("id", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        }
        // 仅接收原三种生命周期状态；查询与COUNT沿同一组织及租户范围，不让未知值静默回到全部。
        if (input.getParam("orderState") != null) {
            var requestedState = input.getParam("orderState");
            if (!(requestedState instanceof String value)
                    || !java.util.Set.of("DRAFT", "SUBMITTED", "APPROVED").contains(value)) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
            }
            page.putParam("orderState", requestedState);
        }
        var result = super.getStore(page);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        return result;
    }

    /**
     * 范围详情；org901/id600000；无记录统一拒绝，避免跨组织探测。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/customerDisplay为当前客户名称/全部行；已归档客户名称仍按原拥有方读取，拒绝订单不存在或越范围
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.REQUIRES_NEW,
            readOnly = true)
    public CommonResult getById(CommonParam input) {
    // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var details =
                new java.util.LinkedHashMap<>(
                        com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.browser(row));
        // 当前客户名称按原订单读取资格向拥有方读取，不依赖可选客户第一页或额外客户详情权限。
        var customerNames = partners.orderListNames(input.getParam("organizationCandidateId"),
                List.of(CrmPartnerValueSupport.positive(row.get("partnerId"))));
        details.put("rejection", audit.latestOrderRejection(input));
        details.put("customerDisplay", customerNames.isEmpty() ? "#" + row.get("partnerId")
                : String.valueOf(customerNames.getFirst().get("partnerName")));
        var relation = new CommonParam();
        relation.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        relation.putParam("orderId", row.get("id"));
        details.put(
                "canApprove",
                "SUBMITTED".equals(row.get("orderState"))
                        && ((Number) scope.get("actorUserId")).longValue()
                                != ((Number) row.get("submittedByUserId")).longValue());
        // 是否本人提交由真实会话判定，页面仍须同时取得原订单写许可。
        details.put("canWithdraw", "SUBMITTED".equals(row.get("orderState"))
                && ((Number) scope.get("actorUserId")).longValue()
                    == ((Number) row.get("submittedByUserId")).longValue());
        details.put(
                "lines",
                lines.readForOrder(relation, "crm.order.read").stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browserLine)
                        .toList());
        details.put(
                "fee",
                new java.math.BigDecimal(row.get("feeMinor").toString())
                        .movePointLeft(((Number) row.get("currencyScale")).intValue())
                        .toPlainString());
        return CrmPartnerValueSupport.result(details);
    }

    /**
     * 批量未开放；空items也拒绝，不退化为全库。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 实际操作员，例如9211；无身份拒绝。
     *
     * @return 真实账号Long，例如9211；无身份拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 实际租户，例如92；无默认1。
     *
     * @return 真实租户Long，例如92；无默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 不隐式扩权；始终false。 业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     *
     * @return false；不隐式扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写拒绝；id600000；只能具名事务命令。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 新单完整保存：先范围裁决，claim与头行/首次结果/审计在一个CRM事务。
     *
     * @param input org901/keyk1/真实客户和全部行；编辑含id600000/expectedVersion0
     * @return 保存后的精确头行首次结果；重放返回原版本而非后来状态
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可、引用、旧版本或第N行失败整笔回滚
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult saveDraft(CommonParam input) {
        access.requireOrderScope(
                input == null ? null : input.getParam("organizationCandidateId"),
                "crm.order.write");
        var normalized = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.draft(input);
        return execute(
                normalized,
                "ORDER_SAVE",
                (scope, requestId) -> {
                    Long previous = null;
                    long id;
                    long version;
                    if (normalized.getParam("id") != null) {
                        id = (Long) normalized.getParam("id");
                        var current = locked(normalized, scope);
                        previous = ((Number) current.get("versionNo")).longValue();
                        checkVersion(current, normalized);
                        if (!"DRAFT".equals(current.get("orderState"))) {
                            throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
                        }
                        version = previous + 1;
                        var relation = relation(normalized, id);
                        lines.readForOrder(relation, "crm.order.write");
                    } else {
                        id = getSequence().get("id");
                        version = 0;
                    }
                    @SuppressWarnings("unchecked")
                    Map<String, Object> pricing =
                            (Map<String, Object>) normalized.getParam("pricing");
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> computed =
                            (List<Map<String, Object>>) pricing.get("lines");
                    List<Map<String, Object>> priced = new ArrayList<>();
                    for (var line : computed) {
                        var copy = new LinkedHashMap<>(line);
                        copy.put("currencyScale", pricing.get("currencyScale"));
                        priced.add(copy);
                    }
                    validateReferences(normalized, priced, "crm.order.write", true);
                    var header =
                            com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.header(
                                    normalized, scope);
                    header.putParam("id", id);
                    if (previous == null) {
                        CrmPartnerValueSupport.changed(getDao().insert(header));
                    } else {
                        header.putParam("expectedVersion", previous);
                        header.putParam("actorUserId", scope.get("actorUserId"));
                        CrmPartnerValueSupport.changed(getDao().updateDraft(header));
                    }
                    var relation = relation(normalized, id);
                    relation.putParam("lines", priced);
                    relation.putParam("headerVersion", version);
                    var saved = lines.replaceDraft(relation);
                    header.putParam("versionNo", version);
                    return finish(
                            normalized,
                            scope,
                            requestId,
                            id,
                            previous,
                            version,
                            "ORDER_SAVE",
                            header.getParamMap(),
                            saved);
                });
    }

    /**
     * 提交真实DRAFT，重新核引用和持久化头行；不写库存资金。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult submit(CommonParam input) {
        return change(input, false);
    }

    /**
     * 独立授权人审核真实SUBMITTED；冻结精确快照与源版本；提交人自审拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult approve(CommonParam input) {
        return change(input, true);
    }

    /**
     * 方法作用：仅原提交人将未审核订单撤回草稿；沿原保存请求事务追加独立撤回审计。
     * @param input 原页面版本正文，例如organizationCandidateId901/id600000/expectedVersion1/requestKeywithdraw1
     * @return 真实示例：data.id600000/orderStateDRAFT/versionNo2；原键重放replaytrue。
     * 异常或副作用示例：他人提交、APPROVED、旧版本、失权或审计失败全部回滚，不改头行金额和外域记录。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.NOT_SUPPORTED)
    public CommonResult withdraw(CommonParam input) {
        var candidateScope = access.requireOrderScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.order.write");
        var normalized = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(input, true);
        // 使用原保存请求拥有方及约束；服务器固定子操作进入摘要，不能与保存草稿同键混用。
        normalized.putParam("orderOperation", "WITHDRAW");
        // 撤回请求绑定实际操作者；他人即使知道原UUID也不能取得本人撤回的成功回执。
        normalized.putParam("withdrawActorUserId", candidateScope.get("actorUserId"));
        return execute(normalized, "ORDER_SAVE", (scope, requestId) -> {
            var current = locked(normalized, scope);
            checkVersion(current, normalized);
            long previous = ((Number) current.get("versionNo")).longValue();
            long id = ((Number) current.get("id")).longValue();
            // 先锁订单再校本人及未审核状态；与独立审核竞争时只允许一个版本成功。
            if (!"SUBMITTED".equals(current.get("orderState"))
                    || !scope.get("actorUserId").equals(normalized.getParam("withdrawActorUserId"))
                    || ((Number) scope.get("actorUserId")).longValue()
                        != ((Number) current.get("submittedByUserId")).longValue()) {
                throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
            }
            var rows = lines.readForOrder(relation(normalized, id), "crm.order.write");
            var update = CrmPartnerValueSupport.detail(normalized, scope);
            update.putParam("expectedVersion", previous);
            update.putParam("previousState", "SUBMITTED");
            update.putParam("nextState", "DRAFT");
            update.putParam("actorUserId", scope.get("actorUserId"));
            CrmPartnerValueSupport.changed(getDao().transition(update));
            current.put("orderState", "DRAFT");
            current.remove("submittedByUserId");
            current.remove("submittedAt");
            current.put("versionNo", previous + 1);
            return finish(normalized, scope, requestId, id, previous, previous + 1,
                    "ORDER_SAVE", current, rows);
        });
    }


    /**
     * 方法作用：异人审核人将待审订单退回草稿，规范原因、账号与子操作进入原命令摘要。
     * @param input 真实示例：org901/id600000/expectedVersion1/requestKeyreject1/reasonText核对订购数量
     * @return 真实示例：data.orderStateDRAFT/versionNo2；原原因相同原键replaytrue。
     * 异常或副作用示例：同人自审、旧版本、缺权、无原因或审计失败整笔回滚，明细和资金不变。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.NOT_SUPPORTED)
    public CommonResult reject(CommonParam input) {
        var candidateScope = access.requireOrderScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.order.approve");
        if (input == null || !input.getParamMap().keySet().equals(java.util.Set.of(
                "organizationCandidateId", "id", "expectedVersion", "requestKey", "reasonText"))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
        }
        var commandInput = new CommonParam();
        for (String field : List.of("organizationCandidateId", "id", "expectedVersion", "requestKey")) {
            commandInput.putParam(field, input.getParam(field));
        }
        var normalized = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(commandInput, true);
        normalized.putParam("reasonText", CrmPartnerValueSupport.text(input.getParam("reasonText"), 200, true));
        normalized.putParam("orderOperation", "REJECT");
        normalized.putParam("reviewerUserId", candidateScope.get("actorUserId"));
        return execute(normalized, "ORDER_APPROVE", (scope, requestId) -> {
            var current = locked(normalized, scope);
            checkVersion(current, normalized);
            if (!"SUBMITTED".equals(current.get("orderState"))
                    || !scope.get("actorUserId").equals(normalized.getParam("reviewerUserId"))) {
                throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
            }
            if (((Number) current.get("submittedByUserId")).longValue()
                    == ((Number) scope.get("actorUserId")).longValue()) {
                throw CrmPartnerValueSupport.failure("CRM_APPROVER_EQUALS_SUBMITTER");
            }
            long previous = ((Number) current.get("versionNo")).longValue();
            long id = ((Number) current.get("id")).longValue();
            var rows = lines.readForOrder(relation(normalized, id), "crm.order.approve");
            var update = CrmPartnerValueSupport.detail(normalized, scope);
            update.putParam("expectedVersion", previous);
            update.putParam("previousState", "SUBMITTED");
            update.putParam("nextState", "DRAFT");
            update.putParam("actorUserId", scope.get("actorUserId"));
            CrmPartnerValueSupport.changed(getDao().transition(update));
            current.put("orderState", "DRAFT");
            current.remove("submittedByUserId");
            current.remove("submittedAt");
            current.put("versionNo", previous + 1);
            return finish(normalized, scope, requestId, id, previous, previous + 1,
                    "ORDER_APPROVE", current, rows);
        });
    }

    /**
     * 按真实角色和状态提交或独立审核全量订单。
     *
     * @param input org901/id600000/expectedVersion1/requestKeya1
     * @param approval true审核SUBMITTED；false提交DRAFT
     * @return true返回APPROVED/version2，false返回SUBMITTED/version1；自审/冻结错整笔回滚
     */
    private CommonResult change(CommonParam input, boolean approval) {
        String command = approval ? "ORDER_APPROVE" : "ORDER_SUBMIT",
                action = CrmPartnerValueSupport.commandAction(command);
        access.requireOrderScope(
                input == null ? null : input.getParam("organizationCandidateId"), action);
        var normalized =
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(input, true);
        return execute(
                normalized,
                command,
                (scope, requestId) -> {
                    var current = locked(normalized, scope);
                    checkVersion(current, normalized);
                    long previous = ((Number) current.get("versionNo")).longValue(),
                            id = ((Number) current.get("id")).longValue();
                    if (!(approval ? "SUBMITTED" : "DRAFT").equals(current.get("orderState"))) {
                        throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
                    }
                    if (approval
                            && ((Number) current.get("submittedByUserId")).longValue()
                                    == ((Number) scope.get("actorUserId")).longValue()) {
                        throw CrmPartnerValueSupport.failure("CRM_APPROVER_EQUALS_SUBMITTER");
                    }
                    var rows = lines.readForOrder(relation(normalized, id), action);
                    var reference = new CommonParam();
                    reference.putParam(
                            "organizationCandidateId",
                            normalized.getParam("organizationCandidateId"));
                    reference.putParam("partnerId", current.get("partnerId"));
                    reference.putParam("orderKind", current.get("orderKind"));
                    validateReferences(reference, rows, action, false);
                    com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.verify(current, rows);
                    var p = CrmPartnerValueSupport.detail(normalized, scope);
                    p.putParam("expectedVersion", previous);
                    p.putParam("previousState", current.get("orderState"));
                    p.putParam("nextState", approval ? "APPROVED" : "SUBMITTED");
                    p.putParam("actorUserId", scope.get("actorUserId"));
                    if (approval) {
                        var snapshot =
                                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.snapshot(
                                        current, rows);
                        p.putParam("approvedByUserId", scope.get("actorUserId"));
                        p.putParam(
                                "snapshotHash",
                                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(
                                        snapshot));
                        p.putParam("frozenSnapshot", JsonUtils.toJsonIgnoreNull(snapshot));
                    }
                    CrmPartnerValueSupport.changed(getDao().transition(p));
                    current.put("orderState", p.getParam("nextState"));
                    current.put("versionNo", previous + 1);
                    if (approval) {
                        current.put("snapshotHash", p.getParam("snapshotHash"));
                        current.put("frozenSnapshot", p.getParam("frozenSnapshot"));
                        current.put("approvedByUserId", scope.get("actorUserId"));
                    } else {
                        current.put("submittedByUserId", scope.get("actorUserId"));
                    }
                    return finish(
                            normalized,
                            scope,
                            requestId,
                            id,
                            previous,
                            previous + 1,
                            command,
                            current,
                            rows);
                });
    }

    /**
     * 在实际租户组织范围内锁定订单头，不按全局id补权限。
     *
     * @param input org901/id600000
     * @param scope 服务实际回查的tenant92/businessOrg901/actor9211
     * @return 实际订单头Map，例如DRAFT/version0；不存在抛CRM_RECORD_NOT_FOUND
     */
    private Map<String, Object> locked(CommonParam input, Map<String, Object> scope) {
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }

    /**
     * 比较实际订单版本，防止并发覆盖和最大版本溢出。
     *
     * @param row 实际头，例如versionNo0
     * @param input 规范命令，例如expectedVersion0
     *     异常或副作用示例：相等继续；expectedVersion1或最大版本抛STALE_CRM_VERSION，不写库。
     */
    private void checkVersion(Map<String, Object> row, CommonParam input) {
        long version = ((Number) row.get("versionNo")).longValue();
        if (version == Long.MAX_VALUE || version != (Long) input.getParam("expectedVersion")) {
            throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
        }
    }

    /**
     * 仅复制候选组织和服务器订单关联主键。
     *
     * @param input org901的规范参数
     * @param id 真实订单主键，例如600000
     * @return 新参数{organizationCandidateId:901,orderId:600000}，无客户端可信身份
     */
    private CommonParam relation(CommonParam input, long id) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam("orderId", id);
        return p;
    }

    /**
     * 锁定真实客户或供应商角色及排序商品，保存时填充实际商品快照。
     *
     * @param input org901/PURCHASE/partner501
     * @param values 完整实际商品行，例如product701/quantity2
     * @param action 固定crm.order.write或crm.order.approve等真实许可
     * @param populate true按商品主数据填名称/单位；false仅校验
     *     异常或副作用示例：采购缺supplierRole抛CRM_PARTNER_ROLE_MISMATCH；商品越组织拒绝并回滚。
     */
    private void validateReferences(
            CommonParam input, List<Map<String, Object>> values, String action, boolean populate) {
        var reference = new CommonParam();
        reference.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        reference.putParam("id", input.getParam("partnerId"));
        var partner = partners.lockForOrder(reference, action);
        if (!Boolean.TRUE.equals(
                partner.get(
                        "SALES".equals(input.getParam("orderKind"))
                                ? "customerRole"
                                : "supplierRole"))) {
            throw CrmPartnerValueSupport.failure("CRM_PARTNER_ROLE_MISMATCH");
        }
        var masters = new TreeMap<Long, Map<String, Object>>();
        for (var line : values) {
            masters.put(CrmPartnerValueSupport.positive(line.get("productId")), null);
        }
        for (long id : new ArrayList<>(masters.keySet())) {
            reference.putParam("id", id);
            masters.put(id, products.lockForOrder(reference, action));
        }
        if (populate) {
            for (var line : values) {
                var master = masters.get(CrmPartnerValueSupport.positive(line.get("productId")));
                line.put("productNameSnapshot", master.get("productName"));
                line.put("unitCode", master.get("unitCode"));
            }
        }
    }

    /**
     * 完成类型化首次结果及末尾单一审计，失败均回滚。
     *
     * @param input org901/requestKeyp1
     * @param scope 实际tenant92/businessOrg901/actor9211
     * @param requestId 已认领真实命令请求主键，例如100001
     * @param id 真实订单主键，例如600000
     * @param previous 新建为null，状态更新例如1
     * @param version 新版本，例如2
     * @param command 固定ORDER_APPROVE等命令
     * @param header 已成功CAS的真实订单头，例如APPROVED
     * @param rows 全部实际订单行，例如两行dueMinor68/67
     * @return 真实CommonResult，id和版本精确文本，首次replay=false；审计失败无半状态
     */
    private CommonResult finish(
            CommonParam input,
            Map<String, Object> scope,
            long requestId,
            long id,
            Long previous,
            long version,
            String command,
            Map<String, Object> header,
            List<Map<String, Object>> rows) {
        access.requireOrderScope(
                input.getParam("organizationCandidateId"),
                CrmPartnerValueSupport.commandAction(command));
        var data =
                new LinkedHashMap<>(
                        com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.browser(header));
        data.put("id", Long.toString(id));
        data.put("orderId", Long.toString(id));
        data.put("versionNo", Long.toString(version));
        data.put(
                "lines",
                rows.stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browserLine)
                        .toList());
        data.put("replay", false);
        data.put("synthetic", scope.get("synthetic"));
        var request = request(input, command);
        request.putParam("id", requestId);
        request.putParam("resultOrderId", id);
        request.putParam("resultVersionNo", version);
        request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
        requests.complete(request);
        var event = new CommonParam();
        event.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        event.putParam("commandRequestId", requestId);
        // 撤回复用原保存请求通道，但审计明确区分撤回，不伪称普通头行保存。
        event.putParam("action", "WITHDRAW".equals(input.getParam("orderOperation"))
                ? "ORDER_WITHDRAW" : "REJECT".equals(input.getParam("orderOperation")) ? "ORDER_REJECT" : command);
        if ("REJECT".equals(input.getParam("orderOperation"))) {
            event.putParam("reasonText", input.getParam("reasonText"));
        }
        event.putParam("resourceId", id);
        event.putParam("previousVersion", previous);
        event.putParam("newVersion", version);
        audit.append(event);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 按规范参数计算请求摘要，不接受客户端hash。
     *
     * @param input org901/requestKeyp1及规范业务内容
     * @param command 固定ORDER_SAVE等命令
     * @return 新参数含组织、命令、请求键和服务器payloadHash；无写入
     */
    private CommonParam request(CommonParam input, String command) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam("commandName", command);
        p.putParam("requestKey", input.getParam("requestKey"));
        p.putParam(
                "payloadHash",
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(
                        input.getParamMap()));
        return p;
    }

    /**
     * 由公共Spring模板执行实际CRM事务，唯一请求失败后独立读取首次结果。
     *
     * @param input org901/requestKeyp1及规范头行
     * @param command 固定ORDER_SAVE或ORDER_APPROVE
     * @param operation 实际owning业务回调，接收真实scope和已认领requestId
     * @return 首次真实结果或相同内容replay=true；相同键不同内容CRM_COMMAND_CONFLICT，失败无部分提交
     */
    private CommonResult execute(
            CommonParam input,
            String command,
            java.util.function.BiFunction<Map<String, Object>, Long, CommonResult> operation) {
        var request = request(input, command);
        String action = CrmPartnerValueSupport.commandAction(command);
        try {
      return access.executeTransaction(
          input.getParam("organizationCandidateId"),
          action,
          transaction,
          status -> {
            var scope = access.requireOrderScope(input.getParam("organizationCandidateId"), action);
            long requestId = requests.claim(request);
            return operation.apply(scope, requestId);
          });
        } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            var stored = requests.committed(request);
            if (stored == null
                    || !request.getParam("payloadHash").equals(stored.get("payloadHash"))) {
                throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
            }
            if (!"COMPLETED".equals(stored.get("requestState"))) {
                throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> data =
                    JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
            data.put("replay", true);
            return CrmPartnerValueSupport.result(data);
        }
    }

    /**
     * 聚合实际订单分页及客户/商品选择，不用客户端候选伪造参考记录。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共data，聚合本组织真实订单/客户/商品及三语SELUI定义，明确synthetic=true
     */
    @Override
    @OperationLog
    public CommonResult workspace(CommonPageParam input) {
      var listScope =
          access.requireOrderScope(
              input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
      var page = getStore(input);
    // 本页客户与商品摘要由各自拥有方批量读取，不用20条参考候选猜测名称。
    var customerIds =
        page.getRecords().stream()
            .map(row -> CrmPartnerValueSupport.positive(row.get("partnerId")))
            .distinct()
            .toList();
    var orderIds =
        page.getRecords().stream()
            .map(row -> CrmPartnerValueSupport.positive(row.get("id")))
            .toList();
    var customerNames = new java.util.HashMap<Long, String>();
    for (var row :
        partners.orderListNames(input.getParam("organizationCandidateId"), customerIds)) {
      customerNames.put(
          CrmPartnerValueSupport.positive(row.get("id")), String.valueOf(row.get("partnerName")));
    }
    var orderItems = new java.util.HashMap<Long, java.util.List<Map<String, Object>>>();
    for (var row : lines.orderListItems(input.getParam("organizationCandidateId"), orderIds)) {
      orderItems
          .computeIfAbsent(
              CrmPartnerValueSupport.positive(row.get("orderId")), ignored -> new ArrayList<>())
          .add(
              Map.of(
                  "productNameSnapshot",
                  row.get("productNameSnapshot"),
                  "quantity",
                  new java.math.BigDecimal(row.get("quantity").toString())
                      .stripTrailingZeros()
                      .toPlainString()));
    }
      var salesIds =
          page.getRecords().stream()
              .filter(row -> "SALES".equals(row.get("orderKind")))
              .map(row -> CrmPartnerValueSupport.positive(row.get("id")))
              .toList();
      var beneficiaries =
          readOrderBeneficiaries(listScope, input.getParam("organizationCandidateId"), salesIds);
      @SuppressWarnings("unchecked")
      var beneficiaryRecords = (Map<Long, List<Map<String, Object>>>) beneficiaries.get("orders");
      for (var row : page.getRecords()) {
        long customer = CrmPartnerValueSupport.positive(row.get("partnerId")),
            order = CrmPartnerValueSupport.positive(row.get("id"));
        row.put("customerDisplay", customerNames.getOrDefault(customer, "#" + customer));
        row.put("orderItems", orderItems.getOrDefault(order, List.of()));
        row.put(
            "beneficiaryState",
            "SALES".equals(row.get("orderKind")) ? beneficiaries.get("state") : "NOT_APPLICABLE");
        row.put("beneficiaryStudents", beneficiaryRecords.getOrDefault(order, List.of()));
      }
    var partnerPage = new CommonPageParam();
        partnerPage.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        partnerPage.setPageNo(referencePage(input.getParam("partnerPageNo")));
        partnerPage.setPageSize(20);
        var productPage = new CommonPageParam();
        productPage.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        productPage.setPageNo(referencePage(input.getParam("productPageNo")));
        productPage.setPageSize(20);
        var partnerChoices = partners.orderChoices(partnerPage);
        var productChoices = products.getStore(productPage);
        Map<String, Boolean> permits = new LinkedHashMap<>();
        for (String action : List.of("crm.order.write", "crm.order.submit", "crm.order.approve")) {
            try {
                access.requireOrderScope(input.getParam("organizationCandidateId"), action);
                permits.put(action, true);
            } catch (com.sp.selplat.common.exception.CommonBusinessException denied) {
                if (!"CRM_ACTION_FORBIDDEN".equals(denied.getErrorCode())) {
                    throw denied;
                }
                permits.put(action, false);
            }
        }
      if (!listScope.equals(
          access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read"))) {
        throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
      }
    return com.sp.selplat.crm.common.util.authorization.CrmWorkspaceEvidence.decorate(
        com.sp.selplat.crm.common.util.order.CrmOrderWorkspaceSupport.build(
            page, partnerChoices, productChoices, permits, input.getParam("lang")),
        access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read"),
        input.getParam("lang"));
    }

    /**
     * 校验原参考页码的正整数边界；超大候选按业务参数拒绝，不泄漏系统转换异常。
     *
     * @param candidate 原partnerPageNo或productPageNo，例如"2"；未提供为null
     * @return 原合同整数页码，例如2；缺省1，不更改固定参考页长20
     * @throws com.sp.selplat.common.exception.CommonBusinessException 非正整数或固定20行页长下偏移量溢出时抛INVALID_CRM_ID
     */
    private static int referencePage(Object candidate) {
        // 缺省保留第一页；输入正整数再检查整数页码上界，不能截断或环绕。
        long page = candidate == null ? 1L : CrmPartnerValueSupport.positive(candidate);
        requireSafePageOffset(page, 20);
        return (int) page;
    }

    /**
     * 校验本订单查询在原公共int偏移量合同中的上界，不截断页码或改共享查询器。
     *
     * @param page 实际整数页码，例如107374184
     * @param size 已规范的实际页长，例如20；调用方保证1至100
     * @throws com.sp.selplat.common.exception.CommonBusinessException 偏移量超过2147483647时抛INVALID_CRM_ID；无数据库副作用
     */
    private static void requireSafePageOffset(long page, int size) {
        // 先以除法推导安全上界，避免检查表达式本身乘法溢出；非正数仍由原正整数门禁处理。
        if (page > 1L + Integer.MAX_VALUE / size) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
        }
    }

    /**
     * 内部行维护也必须在实际CRM事务核真实DRAFT状态，不能只信外层调用约定。
     *
     * @param input 组织候选、orderId及服务器头CAS后版本，例如org901/order600000/headerVersion1
     * @return 本组织已锁定DRAFT头；version必须相符，否则拒绝且当前事务回滚
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺范围、非DRAFT或版本不符时阻断行写
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> requireDraftForLines(CommonParam input) {
        var scope =
                access.requireOrderScope(
                        input.getParam("organizationCandidateId"), "crm.order.write");
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam("id", input.getParam("orderId"));
        var row = locked(p, scope);
        if (!"DRAFT".equals(row.get("orderState"))) {
            throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
        }
        if (((Number) row.get("versionNo")).longValue()
                != CrmPartnerValueSupport.version(input.getParam("headerVersion"))) {
            throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
        }
        return row;
    }

    /**
     * 固定来源锁序从Order到OrderLine，验证真实冻结内容，不用客户端快照。
     *
     * @param input 组织候选及来源id，例如org901/id600000
     * @param action 明确库存动作，例如crm.stock.post
     * @return 本组织APPROVED SALES头和全部lines；不改订单审核状态/库存
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     未审核、错误销售来源、畸形冻结正文、自报批准版本或正文/真实行重算哈希不符返回CRM_PRICING_SNAPSHOT_MISMATCH并回滚
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockApprovedForStock(CommonParam input, String action) {
        return lockApprovedForKind(input, action, "SALES");
    }

    /**
     * 锁定已审核采购来源，不接受资金动作或未审核订单。
     *
     * @param input 例如org901/id600000
     * @param action 固定库存许可键，例如crm.stock.post
     * @return 示例orderKind=PURCHASE/orderState=APPROVED及真实全部lines；冻结或范围不符拒绝，无余额副作用
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺动作或未知动作抛CRM_ACTION_FORBIDDEN，不读取业务行
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockApprovedPurchaseForStock(CommonParam input, String action) {
        // 缺动作不能访问采购来源，也不能退化成空动作调用startsWith的系统错误。
        if (action == null || !action.startsWith("crm.stock.")) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        return lockApprovedForKind(input, action, "PURCHASE");
    }

    /**
     * 锁定实际审核采购头行供付款核验，禁止退款和库存动作。
     *
     * @param input org901/id600000
     * @param action 固定资金动作，例如crm.funds.post
     * @return 实际APPROVED PURCHASE全量冻结头行；缺许可或冻结不符拒绝，无余额副作用
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺动作或未知动作抛CRM_ACTION_FORBIDDEN，不读取业务行
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockApprovedPurchaseForFunds(CommonParam input, String action) {
        // 缺动作与未登记动作均拒绝；不可变集合不接受null查询。
        if (action == null || !java.util.Set.of(
                        "crm.funds.read",
                        "crm.funds.write",
                        "crm.funds.submit",
                        "crm.funds.approve",
                        "crm.funds.post")
                .contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        return lockApprovedForKind(input, action, "PURCHASE");
    }

    /**
     * 复用原审核正文/实际全量行验证，类型由服务器owning入口给出。
     *
     * @param input org901/id600000
     * @param action 实际库存或销售收款许可键
     * @param expectedKind 固定SALES或PURCHASE，例如PURCHASE
     * @return 对应类型的真实审核头行；错误类型/冻结哈希不符拒绝
     */
    private Map<String, Object> lockApprovedForKind(
            CommonParam input, String action, String expectedKind) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var header = locked(input, scope);
        if (!"APPROVED".equals(header.get("orderState"))
                || !expectedKind.equals(header.get("orderKind"))) {
            throw CrmPartnerValueSupport.failure("CRM_ORDER_STATE_CONFLICT");
        }
        var rows =
                lines.readForOrder(
                        relation(input, ((Number) header.get("id")).longValue()), action);
        com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.verify(header, rows);
        Map<String, Object> frozen;
        Long approvedFromVersion;
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> parsed =
                    JsonUtils.fromJson(
                            (String)
                                    com.sp.selplat.crm.common.util.order.CrmOrderValueSupport
                                            .browser(header)
                                            .get("frozenSnapshot"),
                            Map.class);
            if (parsed == null) {
                throw new IllegalArgumentException("Frozen order object required");
            }
            frozen = parsed;
            approvedFromVersion =
                    Math.subtractExact(CrmPartnerValueSupport.version(header.get("versionNo")), 1);
            if (approvedFromVersion < 0
                    || !approvedFromVersion.equals(
                            CrmPartnerValueSupport.version(frozen.get("versionNo")))) {
                throw new IllegalArgumentException("Frozen order approval version changed");
            }
        } catch (RuntimeException malformed) {
            throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
        }
        var source = new LinkedHashMap<>(header);
        source.put("versionNo", approvedFromVersion);
        if (!header.get("snapshotHash")
                        .equals(
                                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(
                                        frozen))
                || !header.get("snapshotHash")
                        .equals(
                                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(
                                        com.sp.selplat.crm.common.util.order.CrmOrderValueSupport
                                                .snapshot(source, rows)))) {
            throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
        }
        var result = new LinkedHashMap<>(header);
        result.put("lines", rows);
        return result;
    }

    /**
     * 同组织实际审核销售选择，保持订单APPROVED与履约派生状态独立。
     *
     * @param input 例如org901/page1
     * @return 精确文本APPROVED SALES分页，未审核订单不进入选择
     */
    @Override
    @OperationLog
    public CommonPageResult approvedSalesForStock(CommonPageParam input) {
        var scope =
                access.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        p.putParam("orderState", "APPROVED");
        p.putParam("orderKind", "SALES");
        var result = super.getStore(p);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        return result;
    }

    /**
     * 同组织实际审核销售选择，保持订单APPROVED与履约派生状态独立。
     *
     * @param input 例如org901/page1
     * @return 精确文本APPROVED SALES分页，未审核订单不进入选择
     */
    @Override
    @OperationLog
    public CommonPageResult approvedSalesForFunds(CommonPageParam input) {
        var scope =
                access.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        // 资金查询只精确选择原已审核订单；仍由当前资金资格和本表范围限制。
        if (input.getParam("sourceOrderId") != null) {
            p.putParam("id", CrmPartnerValueSupport.positive(input.getParam("sourceOrderId")));
        }
        p.putParam("orderState", "APPROVED");
        p.putParam("orderKind", "SALES");
        var result = super.getStore(p);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        fundsSourceSummary(input, result);
        return result;
    }

    /**
     * 本组织付款选择器仅展示真实审核采购订单。
     *
     * @param input org901/page1
     * @return 示例records=[{id:600000,orderKind:PURCHASE,totalMinor:135}]；缺funds.read拒绝，无写入
     */
    @Override
    @OperationLog
    public CommonPageResult approvedPurchaseForFunds(CommonPageParam input) {
        var scope =
                access.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        // 资金查询只精确选择原已审核订单；仍由当前资金资格和本表范围限制。
        if (input.getParam("sourceOrderId") != null) {
            p.putParam("id", CrmPartnerValueSupport.positive(input.getParam("sourceOrderId")));
        }
        p.putParam("orderState", "APPROVED");
        p.putParam("orderKind", "PURCHASE");
        var result = super.getStore(p);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        fundsSourceSummary(input, result);
        return result;
    }

    /**
     * 方法作用：给已核资金资格的原订单页补往来方与冻结商品摘要，不改变分页和审核状态。
     *
     * @param input 原资金组织候选，例如organizationCandidateId901
     * @param page 本页实际已审核订单，例如600043/partner501
     * 真实返回示例：无返回值；原行增加counterpartyName及sourceItems名称数量，不含客户联系方式。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失往来方或冻结快照无效拒绝，无订单、资金或权限写入
     */
    private void fundsSourceSummary(CommonParam input, CommonPageResult page) {
        var ids = page.getRecords().stream()
                .map(row -> CrmPartnerValueSupport.positive(row.get("partnerId"))).distinct().toList();
        var names = new java.util.HashMap<Long, String>();
        for (var row : partners.fundsListNames(input.getParam("organizationCandidateId"), ids)) {
            names.put(CrmPartnerValueSupport.positive(row.get("id")),
                    CrmPartnerValueSupport.text(row.get("partnerName"), 200, true));
        }
        for (var row : page.getRecords()) {
            var name = names.get(CrmPartnerValueSupport.positive(row.get("partnerId")));
            if (name == null) {
                throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
            }
            row.put("counterpartyName", name);
            row.put("sourceItems", com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.sourceItems(row));
        }
    }

    /**
     * 库存选择器读取真实审核采购来源，不借销售或订单写许可。
     *
     * @param input 例如org901/page1
     * @return 实际APPROVED PURCHASE分页，例如records=[{id:600000,orderKind:PURCHASE}]；缺stock.read拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult approvedPurchaseForStock(CommonPageParam input) {
        var scope =
                access.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        p.putParam("orderState", "APPROVED");
        p.putParam("orderKind", "PURCHASE");
        var result = super.getStore(p);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        return result;
    }

    /**
     * 方法作用：为独立附件事务锁定本表范围与当前版本，不执行订单状态或冻结正文修改。
     *
     * @param input 实际org901/id600000/expectedVersion2；客户端不声明tenant或actor
     * @return 实际头例如APPROVED/version2；仅持锁读，资金和库存不变 异常或副作用示例：旧版本、无真实order.write或无CRM事务拒绝。
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockForAttachment(CommonParam input) {
        var scope =
                access.requireOrderScope(
                        input.getParam("organizationCandidateId"), "crm.order.write");
        var row = locked(input, scope);
        checkVersion(row, input);
        return row;
    }

      /**
   * 方法作用：消费本页原教学受益来源，明确区分未开通、未接入、无权与不可用。
   *
   * @param scope 原CRM实际范围，例如tenantId9/actorUserId9101/businessOrgId901
   * @param organization 原组织候选，例如901
   * @param orderIds 本页已准销售订单，例如[600000]，最多100项
   * @return 真实示例：state=AVAILABLE/orders={600000:[{id:"50",displayName:"小禾"}]}；未接入保留独立状态
   * @throws com.sp.selplat.common.exception.CommonBusinessException 拥有方正文不符或含本页外编号时拒绝，不猜受益学生
   */
  private Map<String, Object> readOrderBeneficiaries(
      Map<String, Object> scope, Object organization, List<Long> orderIds) {
    var owner = beneficiaryOwner.getIfAvailable();
    if (owner == null) {
      return Map.of("state", "NOT_CONNECTED", "orders", Map.of());
    }
    var actor =
        Map.<String, Object>of(
            "tenantId", scope.get("tenantId"), "userId", scope.get("actorUserId"));
    var request = new CommonParam();
    request.putParam("organizationId", scope.get("businessOrgId"));
    request.putParam("orderIds", orderIds);
    var result = owner.apply(actor, request);
    if (result == null
        || !(result.get("state") instanceof String state)
        || !java.util.Set.of("AVAILABLE", "FORBIDDEN", "UNAVAILABLE").contains(state)
        || !(result.get("records") instanceof List<?> records)) {
      throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
    }
    var rows = new LinkedHashMap<Long, List<Map<String, Object>>>();
    for (var value : records) {
      if (!(value instanceof Map<?, ?> row) || !(row.get("students") instanceof List<?> students)) {
        throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
      }
      long order = CrmPartnerValueSupport.positive(row.get("orderId"));
      if (!orderIds.contains(order) || rows.containsKey(order)) {
        throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
      }
      var safe = new ArrayList<Map<String, Object>>();
      var seen = new java.util.HashSet<Long>();
      for (var student : students) {
        if (!(student instanceof Map<?, ?> actual)) {
          throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
        }
        long id = CrmPartnerValueSupport.positive(actual.get("id"));
        if (!seen.add(id)) {
          throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
        }
        safe.add(
            Map.of(
                "id",
                Long.toString(id),
                "displayName",
                CrmPartnerValueSupport.text(actual.get("displayName"), 200, true)));
      }
      rows.put(order, safe);
    }
    if ("AVAILABLE".equals(result.get("state"))
        ? !rows.keySet().equals(new java.util.HashSet<>(orderIds))
        : !rows.isEmpty()) {
      throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
    }
    return Map.of("state", result.get("state"), "orders", rows);
  }
}
