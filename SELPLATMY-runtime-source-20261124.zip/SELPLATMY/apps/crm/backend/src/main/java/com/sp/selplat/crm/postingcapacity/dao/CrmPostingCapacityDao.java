/** 一期原明细容量DAO；2026-10-04，Codex；仅本表固定SQL。 */
package com.sp.selplat.crm.postingcapacity.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 数量或MINOR容量本表访问；禁止跨表SQL和自动提交占用。 */
public interface CrmPostingCapacityDao extends BaseDao {
    /**
     * 锁定同范围原明细的一种容量。
     *
     * @param input 可信tenant92/org901、originalDetailId1300000及capacityKind ISSUE_RETURN
     * @return 实际容量，例如capacityQuantity3/usedQuantity0/version0；不存在null
     */
    Map<String, Object> lockForOriginal(CommonParam input);

    /**
     * 按锁前版本条件占用或释放容量，不能超过上限或成为负数。
     *
     * @param input 可信id1900000/version0、quantityDelta1或minorDelta67及actor9211
     * @return 实际影响1行；旧版本、越额、版本最大或越范围返回0，不部分成功
     */
    int adjust(CommonParam input);
}
