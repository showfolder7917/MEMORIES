/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdependency.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmPostingDependencyDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 方法作用：读取真实FK依赖，不按status屏蔽已记账子明细。
     *
     * @param input tenant92/org901/parent1300000
     * @return 实际依赖行，是否有效由真实账本派生 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    List<Map<String, Object>> parentEdges(CommonParam input);

    /**
     * 只读真实不可变child边；例如child1300002返回RETURN_FOR_ISSUE和批前SERIAL边，不按人工status隐藏。
     *
     * @param input tenant92/org901/childDetailId1300002
     * @return 实际同组织边列表，无写入
     */
    List<Map<String, Object>> childEdges(CommonParam input);
}
