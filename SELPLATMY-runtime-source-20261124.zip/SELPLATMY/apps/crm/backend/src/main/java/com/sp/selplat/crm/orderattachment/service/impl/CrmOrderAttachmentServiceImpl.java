/** CRM当前上传者订单附件的持久CAS、请求重放与事务审计；2026-10-04，Codex。 */
package com.sp.selplat.crm.orderattachment.service.impl;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.capability.orderfile.service.CrmOrderFileService;
import com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService;
import com.sp.selplat.crm.common.util.file.CrmFileMetadataSupport;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.order.service.CrmOrderService;
import com.sp.selplat.crm.orderattachment.dao.CrmOrderAttachmentDao;
import com.sp.selplat.crm.orderattachment.service.CrmOrderAttachmentService;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 远端概要先真实核验，独立附件CAS/请求/审计后在一个CRM事务提交；不宣称跨HTTP的ACID。 */
@Service
public class CrmOrderAttachmentServiceImpl extends BaseServiceImpl<CrmOrderAttachmentDao>
        implements CrmOrderAttachmentService {
    // 默认关闭，仅专用新隔离结构可打开；双file另需实际源标记，不等于动作授权。
    private final Boolean enabled;
    // 真实Session和逐动作组织裁决，不用客户端owner。
    private final CrmAccessService access;
    // 锁订单只通过owning服务，不跨DAO。
    private final CrmOrderService orders;
    // 文件真实性只来自实际固定同Host HTTP消费者。
    private final CrmOrderFileService files;
    // 已有首次命令与成功审计框架，均要求同一CRM事务。
    private final CrmCommandRequestService requests;
    private final CrmBusinessAuditService audit;
    // 固定具名、READ_COMMITTED事务，锁等待后读当前版本。
    private final TransactionTemplate transaction;

    /**
     * 方法作用：装配本域真实owning服务及具名事务，构造不写业务事实。
     *
     * @param enabled 实际专用结构门禁，例如crmOrderAttachmentEnabled=false
     * @param access 实际Session范围入口，例如org901/actor9211
     * @param orders 实际订单服务，例如锁定订单600000/version2
     * @param files 实际HTTP文件概要消费者，例如CrmOrderFileServiceImpl
     * @param requests 实际命令请求owning服务，例如CrmCommandRequestServiceImpl
     * @param audit 实际成功审计服务，例如CrmBusinessAuditServiceImpl
     * @param manager 具名crmTransactionManager，与本表公共DAO同池 副作用示例：只创建事务模板，不创建Session、权限或文件。
     */
    public CrmOrderAttachmentServiceImpl(
            @Qualifier("crmOrderAttachmentEnabled") Boolean enabled,
            CrmAccessService access,
            CrmOrderService orders,
            CrmOrderFileService files,
            CrmCommandRequestService requests,
            CrmBusinessAuditService audit,
            @Qualifier("crmTransactionManager") PlatformTransactionManager manager) {
        this.enabled = enabled;
        this.access = access;
        this.orders = orders;
        this.files = files;
        this.requests = requests;
        this.audit = audit;
        transaction = new TransactionTemplate(manager);
        transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 方法作用：先实际范围、资源和metadata核验，再原子写引用CAS、请求首次结果与审计。
     *
     * @param input
     *     org901/id600000/expectedVersion2、真实fileId/sha256/byteSize3、UUID请求键/expectedAttachmentVersion0
     * @return
     *     公共结果例如bindingWritten=true/attachmentId100000/versionNo1/replay=false；相同请求返回首次replay=true
     *     异常或副作用示例：失效身份、错误摘要、旧版本、唯一约束或末尾审计失败使CRM业务事实全部回滚。
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult bind(CommonParam input) {
        var scope = scope(input, "crm.order.write");
        CommonParam normalized = normalize(input, scope);
        CommonParam request = request(normalized, scope);
        // 已提交请求先判同键同内容；重放也必须真实核验当前订单范围和本人文件可读性。
        var stored = requests.committed(request);
        if (stored != null) {
            requireReplay(stored, request);
            verifyFile(normalized, true);
            return replay(stored);
        }
        verifyFile(normalized, false);
        try {
            return access.executeTransaction(normalized.getParam("organizationCandidateId"),
                    "crm.order.write", transaction, status -> persist(normalized, request, scope));
        } catch (CommonBusinessException failure) {
            // 唯一请求冲突的失败事务已退出，不能在回滚事务中继续插入或读取首次结果。
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            stored = requests.committed(request);
            requireReplay(stored, request);
            verifyFile(normalized, true);
            return replay(stored);
        } catch (org.springframework.dao.DataIntegrityViolationException failure) {
            throw CrmPartnerValueSupport.failure("CRM_ATTACHMENT_CONFLICT");
        }
    }

    /**
     * 方法作用：实际CRM事务内锁订单、核独立版本、写引用并完成请求和审计。
     *
     * @param input 服务端规范候选，例如order600000/attachmentId100000/expectedAttachmentVersion1
     * @param request 已计算演员隔离键和payloadHash的命令候选
     * @param original 文件核验前实际范围，例如tenant92/org901/actor9211
     * @return 实际首次结果例如attachmentId100000/versionNo2/bindingWritten=true/replay=false
     *     异常或副作用示例：CAS0或审计约束失败则整笔回滚，不撤销文件服务上传。
     */
    private CommonResult persist(
            CommonParam input, CommonParam request, Map<String, Object> original) {
        var scope = scope(input, "crm.order.write");
        requireSameActor(original, scope);
        // owning订单持锁并重新检查实际版本；只读，不改已审核正文和账本。
        orders.lockForAttachment(order(input));
        long requestId = requests.claim(request);
        long previous = (Long) input.getParam("expectedAttachmentVersion");
        long id;
        var row = new CommonParam();
        for (String field : Set.of("fileId", "sha256", "byteSize")) {
            row.putParam(field, input.getParam(field));
        }
        row.putParam("orderId", input.getParam("id"));
        row.putParam("orderVersion", input.getParam("expectedVersion"));
        row.putParam("ownerUserId", scope.get("actorUserId"));
        row.putParam("commandRequestId", requestId);
        row = CrmPartnerValueSupport.entity(row, scope);
        if (input.getParam("attachmentId") == null) {
            id = getSequence().get("id");
            row.putParam("id", id);
            row.putParam("versionNo", 1L);
            CrmPartnerValueSupport.changed(getDao().insert(row));
        } else {
            id = (Long) input.getParam("attachmentId");
            row.putParam("id", id);
            var current = getDao().lockOwned(row);
            if (current == null) {
                throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
            }
            if (CrmPartnerValueSupport.version(current.get("versionNo")) != previous) {
                throw CrmPartnerValueSupport.failure("CRM_ATTACHMENT_VERSION_CONFLICT");
            }
            row.putParam("expectedAttachmentVersion", previous);
            CrmPartnerValueSupport.changed(getDao().compareAndSet(row));
        }
        // 末尾再次回查真实当前身份和动作，避免等待锁期间撤权或租户变化后仍提交。
        requireSameActor(original, scope(input, "crm.order.write"));
        long version = previous + 1;
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("attachmentId", Long.toString(id));
        data.put("orderId", input.getParam("id").toString());
        data.put("orderVersion", input.getParam("expectedVersion").toString());
        data.put("versionNo", Long.toString(version));
        for (String field : Set.of("fileId", "sha256", "byteSize")) {
            data.put(field, input.getParam(field));
        }
        data.put("bindingWritten", true);
        data.put("replay", false);
        request.putParam("id", requestId);
        request.putParam("resultOrderId", input.getParam("id"));
        request.putParam("resultVersionNo", version);
        request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
        requests.complete(request);
        var event = new CommonParam();
        event.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        event.putParam("commandRequestId", requestId);
        event.putParam("action", "ORDER_FILE_BIND");
        event.putParam("resourceId", id);
        event.putParam("previousVersion", previous);
        event.putParam("newVersion", version);
        audit.append(event);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：每次入口重新核真实订单动作及默认结构门禁。
     *
     * @param input 业务候选例如organizationCandidateId901，身份不来自输入
     * @param action 内部固定order.write或order.read
     * @return 真实范围例如tenant92/org901/actor9211/decisionId 异常或副作用示例：production缺scope或默认结构关闭拒绝，不访问附件表。
     */
    private Map<String, Object> scope(CommonParam input, String action) {
        var scope =
                access.requireOrderScope(
                        input == null ? null : input.getParam("organizationCandidateId"), action);
        if (!enabled && !access.formalCapabilityAvailable("orderAttachment")) {
            throw CrmPartnerValueSupport.failure("CRM_ORDER_ATTACHMENT_UNAVAILABLE");
        }
        return scope;
    }

    /**
     * 方法作用：规范候选和演员隔离请求内容，禁止客户端身份、URL和凭据。
     *
     * @param input 例如org901/order600000/fileId32位/sha25664位/byteSize3/UUID键
     * @param scope 实际当前tenant92/org901/actor9211
     * @return 规范参数例如正数long订单与非负独立版本；不携带可信identity字段 异常或副作用示例：未知字段、替换缺版本、版本溢出或键长度不符拒绝，不写SQL。
     */
    private CommonParam normalize(CommonParam input, Map<String, Object> scope) {
        if (!Set.of(
                        "organizationCandidateId",
                        "id",
                        "expectedVersion",
                        "fileId",
                        "sha256",
                        "byteSize",
                        "requestKey",
                        "expectedAttachmentVersion",
                        "attachmentId")
                .containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE");
        }
        var normalized = new CommonParam();
        normalized.putParam("organizationCandidateId", scope.get("businessOrgId"));
        normalized.putParam("id", CrmPartnerValueSupport.positive(input.getParam("id")));
        normalized.putParam(
                "expectedVersion",
                CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        String file = CrmPartnerValueSupport.text(input.getParam("fileId"), 32, true);
        String sha = CrmPartnerValueSupport.text(input.getParam("sha256"), 64, true);
        long bytes = CrmPartnerValueSupport.positive(input.getParam("byteSize"));
        CrmFileMetadataSupport.requireCandidate(file, sha, bytes);
        normalized.putParam("fileId", file);
        normalized.putParam("sha256", sha);
        normalized.putParam("byteSize", bytes);
        String key = CrmPartnerValueSupport.text(input.getParam("requestKey"), 40, true);
        if (!key.matches("[A-Za-z0-9_-]{16,40}")) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE");
        }
        normalized.putParam("requestKey", key);
        long version = CrmPartnerValueSupport.version(input.getParam("expectedAttachmentVersion"));
        if (version == Long.MAX_VALUE
                || (input.getParam("attachmentId") == null ? version != 0 : version == 0)) {
            throw CrmPartnerValueSupport.failure("CRM_ATTACHMENT_VERSION_CONFLICT");
        }
        normalized.putParam("expectedAttachmentVersion", version);
        if (input.getParam("attachmentId") != null) {
            normalized.putParam(
                    "attachmentId",
                    CrmPartnerValueSupport.positive(input.getParam("attachmentId")));
        }
        return normalized;
    }

    /**
     * 方法作用：只把固定文件三元组和实际订单候选交给真实HTTP消费者。
     *
     * @param input 规范候选例如order600000/expectedVersion2/fileId与正文摘要
     * @param replay 是否重放首次结果，例如true时实际当前订单版本不替代原首次结果 异常或副作用示例：他人文件或摘要错误拒绝；不使用先前核验输出作为信任票据。
     */
    private void verifyFile(CommonParam input, boolean replay) {
        var file = order(input);
        for (String field : Set.of("fileId", "sha256", "byteSize")) {
            file.putParam(field, input.getParam(field));
        }
        if (replay) {
            var current = (Map<?, ?>) orders.getById(order(input)).getData();
            file.putParam(
                    "expectedVersion", CrmPartnerValueSupport.version(current.get("versionNo")));
        }
        files.verify(file);
    }

    /**
     * 方法作用：构造固定owning订单候选，不转发附件字段或可信identity。
     *
     * @param input 例如org901/id600000/expectedVersion2
     * @return CommonParam仅包含organizationCandidateId/id/expectedVersion 副作用示例：只构造内存参数，不锁或修改订单。
     */
    private CommonParam order(CommonParam input) {
        var order = new CommonParam();
        for (String field : Set.of("organizationCandidateId", "id", "expectedVersion")) {
            order.putParam(field, input.getParam(field));
        }
        return order;
    }

    /**
     * 方法作用：复用现有请求表，以当前演员前缀隔离组织内相同客户端键。
     *
     * @param input 规范候选，例如UUID键和完整文件三元组/订单与附件版本
     * @param scope 真实tenant92/org901/actor9211
     * @return 命令参数例如ORDER_FILE_BIND、u9211_UUID、规范payloadHash 副作用示例：不占键或发许可；同键不同内容由持久首次hash裁决。
     */
    private CommonParam request(CommonParam input, Map<String, Object> scope) {
        var request = new CommonParam();
        request.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        request.putParam("commandName", "ORDER_FILE_BIND");
        request.putParam(
                "requestKey", "u" + scope.get("actorUserId") + "_" + input.getParam("requestKey"));
        var hash = new LinkedHashMap<>(input.getParamMap());
        hash.put("tenantId", scope.get("tenantId"));
        hash.put("actorUserId", scope.get("actorUserId"));
        request.putParam("payloadHash", CrmOrderValueSupport.hash(hash));
        return request;
    }

    /**
     * 方法作用：核同键实际已提交请求内容与完成状态，不修改原首次结果。
     *
     * @param stored 实际已提交行例如COMPLETED/payloadHash/responseSnapshot
     * @param request 本次规范候选hash 异常或副作用示例：不存在、不同内容或OPEN状态拒绝，不重复写引用和审计。
     */
    private void requireReplay(Map<String, Object> stored, CommonParam request) {
        if (stored == null || !request.getParam("payloadHash").equals(stored.get("payloadHash"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
        }
        if (!"COMPLETED".equals(stored.get("requestState"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
        }
    }

    /**
     * 方法作用：返回已提交首次JSON，不能用当前最新附件覆盖原幂等回执。
     *
     * @param stored 实际完成行例如responseSnapshot中attachmentId100000/versionNo1
     * @return 原首次data加replay=true，不新增请求或审计 异常或副作用示例：损坏首次JSON不会默默构造成功，失败保留实际已提交记录。
     */
    @SuppressWarnings("unchecked")
    private CommonResult replay(Map<String, Object> stored) {
        Map<String, Object> data =
                JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
        data.put("replay", true);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：验证文件查询前后及事务锁等待后真实身份范围未改变。
     *
     * @param before 例如tenant92/org901/actor9211
     * @param after 实际fresh scope，例如仍为tenant92/org901/actor9211 异常或副作用示例：变成另一演员或租户即拒绝，整个当前CRM事务回滚。
     */
    private void requireSameActor(Map<String, Object> before, Map<String, Object> after) {
        for (String field : Set.of("tenantId", "businessOrgId", "actorUserId")) {
            if (!before.get(field).equals(after.get(field))) {
                throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
            }
        }
    }

    /**
     * 方法作用：分页准确订单内当前上传者引用，复用公共分页SQL。
     *
     * @param input 例如org901/orderId600000/pageNo1/pageSize20
     * @return 真实公共分页例如records含本人附件100000/totalCount1 异常或副作用示例：无order.read或资源不存在拒绝，不返回其他用户引用。
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        var scope = scope(input, "crm.order.read");
        var order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        orders.getById(order);
        var page = CrmPartnerValueSupport.page(input, scope, null);
        page.putParam("orderId", order.getParam("id"));
        page.putParam("ownerUserId", scope.get("actorUserId"));
        return super.getStore(page);
    }

    /**
     * 方法作用：只读取真实订单范围内本上传者的准确引用。
     *
     * @param input 例如org901/orderId600000/id100000
     * @return 实际CommonResult例如fileId为32位ID/versionNo1
     *     异常或副作用示例：不存在、其他上传者或订单统一CRM_RECORD_NOT_FOUND，不泄露存在性。
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        var scope = scope(input, "crm.order.read");
        var order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        orders.getById(order);
        // owning DAO先返回实际行，缺失与他人引用统一由本域检查拒绝，避免基础错误码泄露存在性。
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null
                || !scope.get("actorUserId").equals(row.get("ownerUserId"))
                || !order.getParam("id").equals(row.get("orderId"))
                || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        // 范围、本人、订单和状态均通过后，保留基础详情成功消息与响应结构。
        return buildSuccessResult(row, "详情查询完成。");
    }

    /**
     * 方法作用：准确订单内已存他人引用与文件共享许可取交集，不修改本人查询或写入合同。
     * @param input 例如organizationCandidateId901/orderId600000/id100000，禁止owner和URL覆盖
     * @return 真实返回示例：已核对的引用行及shared=true；VIEW_METADATA不授予READ_BODY。
     * 异常或副作用示例：不存在与无共享许可统一CRM_RECORD_NOT_FOUND；不创建或替换引用。
     */
    @Override
    @OperationLog
    public CommonResult getSharedById(CommonParam input) {
        var scope = scope(input, "crm.order.read");
        if (!Set.of("organizationCandidateId", "orderId", "id", "lang").containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT");
        }
        var order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        var parent = (Map<?, ?>) orders.getById(order).getData();
        var query = CrmPartnerValueSupport.detail(input, scope);
        var row = getDao().getById(query);
        if (row == null || !order.getParam("id").equals(row.get("orderId"))
                || !Integer.valueOf(1).equals(row.get("status")) || scope.get("actorUserId").equals(row.get("ownerUserId"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var reference = new CommonParam();
        reference.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        reference.putParam("id", order.getParam("id"));
        reference.putParam("expectedVersion", parent.get("versionNo"));
        for (String field : Set.of("ownerUserId", "fileId", "sha256", "byteSize")) {
            reference.putParam(field, row.get(field));
        }
        try {
            files.readSharedReference(reference);
        } catch (CommonBusinessException denied) {
            // 缺文件许可不得泄露引用是否存在；身份/订单资格失败仍使用原统一错误便于恢复。
            if (Set.of("UNIAUTH_IDENTITY_REQUIRED", "CRM_ACTION_FORBIDDEN", "CRM_SCOPE_UNAVAILABLE")
                    .contains(denied.getErrorCode())) { throw denied; }
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        requireSameActor(scope, scope(input, "crm.order.read"));
        var current = getDao().getById(query);
        if (current == null || !Integer.valueOf(1).equals(current.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        for (String field : Set.of("orderId", "ownerUserId", "fileId", "sha256", "byteSize", "versionNo")) {
            if (!row.get(field).equals(current.get(field))) { throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND"); }
        }
        var data = new LinkedHashMap<>(current);
        data.put("shared", true);
        return buildSuccessResult(data, "共享附件详情查询完成。");
    }

    /**
     * 方法作用：准确订单内定位共享文件候选，再通过已存引用及真实文件系统共享许可返回详情。
     * @param input 例如org901/orderId600000/ownerUserId9212/fileId为共享收件箱ID；没有客户端tenant/actor
     * @return 真实返回示例：已获准引用data.id100000/shared=true，不返回其他订单引用。
     * 异常或副作用示例：不存在与无文件共享许可均CRM_RECORD_NOT_FOUND；不写入或转移引用。
     */
    @Override
    @OperationLog
    public CommonResult getSharedByFile(CommonParam input) {
        var scope = scope(input, "crm.order.read");
        if (!Set.of("organizationCandidateId", "orderId", "ownerUserId", "fileId", "lang")
                .containsAll(input.getParamMap().keySet())) { throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT"); }
        long owner = CrmPartnerValueSupport.positive(input.getParam("ownerUserId"));
        String fileId = CrmPartnerValueSupport.text(input.getParam("fileId"), 32, true);
        if (!fileId.matches("[a-f0-9]{32}")) { throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE"); }
        var order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        orders.getById(order);
        var query = new CommonParam();
        query.putParam("tenantId", scope.get("tenantId"));
        query.putParam("businessOrgId", scope.get("businessOrgId"));
        query.putParam("orderId", order.getParam("id"));
        query.putParam("ownerUserId", owner);
        query.putParam("fileId", fileId);
        var row = getDao().findByFileReference(query);
        if (row == null) { throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND"); }
        // 候选owner只用于资源定位；已存引用的实际所有者及独立共享许可仍由详情路径重新核验。
        var detail = new CommonParam();
        detail.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        detail.putParam("orderId", order.getParam("id"));
        detail.putParam("id", row.get("id"));
        var result = getSharedById(detail);
        var data = (Map<?, ?>) result.getData();
        // 定位后引用可能被替换；独立共享核验完成也不能把另一个文件作为原候选返回。
        if (!row.get("id").equals(data.get("id")) || !order.getParam("id").equals(data.get("orderId"))
                || !Long.valueOf(owner).equals(data.get("ownerUserId")) || !fileId.equals(data.get("fileId"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return result;
    }

    /**
     * 方法作用：关闭未经准确订单/上传者检查的通用批量读。
     *
     * @param input 例如items为空或含附件100000，不能推断owner
     * @return 不返回记录，固定抛CRM_GENERIC_ACCESS_DISABLED 异常或副作用示例：始终拒绝，不把空批次变成全库查询。
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 方法作用：关闭通用无版本写，仅bind命令可经过实际metadata与事务。
     *
     * @param input 例如通用insert/update/delete候选附件100000
     *     异常或副作用示例：始终CRM_GENERIC_WRITE_DISABLED，不使用默认管理员/演员写库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 方法作用：公共操作记录使用实际Session账号，不能回落默认1。
     *
     * @return 真实账号例如9211L；失效身份拒绝 异常或副作用示例：没有Session则UNIAUTH_IDENTITY_REQUIRED，不授予写许可。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 方法作用：公共范围使用实际Session租户，不使用客户端或默认租户。
     *
     * @return 真实租户例如92L；缺实际归属拒绝 异常或副作用示例：账号失效不访问附件表，也不回落租户1。
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 方法作用：本域不提供隐式管理员绕过当前上传者范围。
     *
     * @return 恒false，不授予任何跨用户权限 副作用示例：已登录账号9211仍必须逐动作与精确资源检查。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }
}
