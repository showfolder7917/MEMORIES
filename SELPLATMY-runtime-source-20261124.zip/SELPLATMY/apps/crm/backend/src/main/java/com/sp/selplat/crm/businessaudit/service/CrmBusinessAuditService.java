/** CrmBusinessAuditService.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 2026-10-28：审计目录仅复用既有crm.audit.read，不授予新动作。 */
package com.sp.selplat.crm.businessaudit.service;

import com.sp.selplat.common.util.CommonParam;

/** 仅本表追加/读取，事务由 owning业务Service协调。 */
public interface CrmBusinessAuditService extends com.sp.selplat.common.service.BaseService {
    /**
     * 方法作用：读取原组织审计的公共只读工作区，不提供修改或删除审计入口。
     * @param input 原组织与分页候选，例如organizationCandidateId901/pageNo2/resourceId503
     * @return 真实示例：CommonResult.data.readOnlytrue及原审计26条中的第2页6条。
     * 异常或副作用示例：缺crm.audit.read拒绝；不新增审计或业务事实。
     */
    com.sp.selplat.common.util.CommonResult workspace(com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 追加成功审计；输入例如request200000/actor9211/actionPARTNER_SAVE；返回审计id；失败回滚业务。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：追加成功审计；输入例如request200000/actor9211/actionPARTNER_SAVE；返回审计id；失败回滚业务。
     * @return 审计id
     */
    Long append(CommonParam input);

    /**
     * 方法作用：按原订单读取资格返回同订单最近驳回及对应提交记录，不开放泛审计读取。
     * @param input 真实示例：organizationCandidateId901/id600000，由订单服务核验当前头后调用
     * @return 真实示例：reasonText核对数量/reviewerUserId9212/previousVersion1/newVersion2；未驳回返回空Map。
     * 异常或副作用示例：缺原订单read或跨组织拒绝，不读取其他动作或修改历史。
     */
    java.util.Map<String, Object> latestOrderRejection(CommonParam input);

    /**
     * 方法作用：沿原资金读取范围返回本单最近驳回与对应原提交，不开放其他审计。
     * @param input 真实示例：organizationCandidateId901/id1000000，由原单据服务核对后调用
     * @return 真实示例：reasonText核对金额/reviewerUserId9212/previousVersion1/newVersion2；无驳回为空Map。
     * 异常或副作用示例：缺crm.funds.read或错组织拒绝，不改原因或状态。
     */
    java.util.Map<String, Object> latestFundsRejection(CommonParam input);


}
