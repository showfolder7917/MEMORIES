/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdetail.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.postingdetail.dao.CrmPostingDetailDao;
import com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmPostingDetailServiceImpl
        extends com.sp.selplat.common.service.BaseServiceImpl<CrmPostingDetailDao>
        implements CrmPostingDetailService {
    protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 绑定实际范围入口，不创建流水或授权。
     *
     * @param access 实际CrmAccessService，例如核验tenant92/org901的服务
     */
    public CrmPostingDetailServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

    /**
     * 公共真实范围分页。
     *
     * @param input 例如org901/page1；可信身份由Session给出
     * @return 本组织精确文本记录；缺库存读许可拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        p.putParam("effectKind", "STOCK");
        var page = super.getStore(p);
        page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
        return page;
    }

    /**
     * 公共真实范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 本组织有效记录；不存在统一拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
    }

    /**
     * 批读不开放。
     *
     * @param input 例如空items
     * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 真实操作员，无默认账号。
     *
     * @return 例如9211；失效Session拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 真实租户，无默认租户。
     *
     * @return 例如92；失效Session拒绝
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 无隐式管理员。
     *
     * @return 返回示例：false；不扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用写关闭。
     *
     * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * owning精确锁，只由具名真实CRM事务消费。
     *
     * @param input 例如org901/id1000000
     * @param action 固定stock.post动作
     * @return 本组织真实行；没有实际记录/许可拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockScoped(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }

    /**
     * 全量父行；固定本表事务扩展。
     *
     * @param input 例如org901/id1000000及实际服务器字段
     * @param action 固定库存动作，例如crm.stock.post，必须对应真实许可
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> readAll(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("batchId", CrmPartnerValueSupport.positive(input.getParam("batchId")));
        return getDao().readAll(p);
    }

    /**
     * 插入本表有效行；固定本表事务扩展。
     *
     * @param input 例如org901/id1000000及实际服务器字段
     * @param action 固定库存动作，例如crm.stock.post，必须对应真实许可
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Long append(CommonParam input, String action) {
        boolean funds = "crm.funds.post".equals(action);
        if ((!funds && !"crm.stock.post".equals(action))
                || !"POST".equals(input.getParam("action"))
                || !(funds ? "CASH" : "STOCK").equals(input.getParam("effectKind"))) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var query = new CommonParam();
        query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        query.putParam("id", input.getParam("batchId"));
        var batch = batches.lockScoped(query, action);
        query.putParam("id", input.getParam("documentLineId"));
        var line = documentLines.lockScoped(query, action);
        if (!batch.get("documentId").toString().equals(input.getParam("documentId").toString())
                || !line.get("documentId").equals(batch.get("documentId"))) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        if (funds) {
            // 实际冻结单据决定现金方向，客户端不能选择退款或任意符号。
            var expected = new java.math.BigDecimal(line.get("amountMinor").toString());
            if ("FUNDS_PAYMENT".equals(line.get("documentKind"))) {
                expected = expected.negate();
            }
            if (!com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.isFundsDocument(
                            line.get("documentKind"),
                            line.get("reason"),
                            Boolean.TRUE.equals(returnsEnabled))
                    || expected.compareTo(
                                    new java.math.BigDecimal(
                                            input.getParam("amountDeltaMinor").toString()))
                            != 0) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
        } else {
            // 来源实际类型决定唯一数量方向；采购只能正向入库，销售只能负向出库。
            boolean purchase =
                    "PURCHASE"
                            .equals(
                                    CrmStockValueSupport.orderKind(
                                            line.get("documentKind"),
                                            line.get("reason"),
                                            Boolean.TRUE.equals(returnsEnabled)));
            long expected =
                    ((Number) line.get("quantity")).longValue()
                            * ((purchase || "SALES_RETURN".equals(line.get("reason"))) ? 1 : -1);
            if (expected != ((Number) input.getParam("quantityDelta")).longValue()) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
        }
        for (String f :
                funds
                        ? List.of("sourceOrderLineId", "accountId", "currency", "lineNo")
                        : List.of("sourceOrderLineId", "warehouseId", "productId", "lineNo")) {
            if (!line.get(f).toString().equals(input.getParam(f).toString())) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
        }
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var row = CrmPartnerValueSupport.entity(input, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("id", getSequence().get("id"));
        CrmPartnerValueSupport.changed(getDao().insert(row));
        return (Long) row.getParam("id");
    }

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService batches;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.documentline.service.CrmDocumentLineService documentLines;

    /**
     * 方法作用及真实业务示例：读取真实资金资源分页；org901/page1；返回真实FUNDS_RECEIPT单据或CASH效果及精确最小单位文本；缺funds.read拒绝，不混库存记录。
     * Actual receipt cash effects page, no stock records mixed into it.
     *
     * @param input org901/page1
     * @return real minor-unit text rows; missing funds.read rejects
     */
    @Override
    @OperationLog
    public CommonPageResult fundsStore(CommonPageParam input) {
        var scope =
                access.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.read");
        var p = CrmPartnerValueSupport.page(input, scope, null);
        p.putParam("effectKind", "CASH");
        var page = super.getStore(p);
        page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
        return page;
    }

    /**
     * 方法作用：服务器从不可变原明细派生唯一严格相反金额，不接受客户端反向金额。
     *
     * @param input org901/batch1200001/originalDetail1300000
     * @return 新明细id及相反金额，原行不改且不复用id 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long appendFundsReverse(CommonParam input) {
        var query = new CommonParam();
        query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        query.putParam("id", input.getParam("originalDetailId"));
        var original = lockScoped(query, "crm.funds.reverse");
        query.putParam("id", input.getParam("batchId"));
        var batch = batches.lockScoped(query, "crm.funds.reverse");
        if (!"CASH".equals(original.get("effectKind"))
                || !"POST".equals(original.get("action"))
                || !"REVERSE".equals(batch.get("action"))
                || !batch.get("originalBatchId").equals(original.get("batchId"))
                || !batch.get("documentId").equals(original.get("documentId"))) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        var scope =
                access.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var row = new CommonParam();
        for (String f :
                List.of(
                        "documentId",
                        "documentLineId",
                        "sourceOrderLineId",
                        "lineNo",
                        "effectKind",
                        "fundsBalanceId",
                        "accountId",
                        "currency")) {
            row.putParam(f, original.get(f));
        }
        row.putParam("batchId", batch.get("id"));
        row.putParam("action", "REVERSE");
        row.putParam("originalAction", "POST");
        row.putParam("originalDetailId", original.get("id"));
        row.putParam(
                "amountDeltaMinor",
                new java.math.BigDecimal(original.get("amountDeltaMinor").toString()).negate());
        row = CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        long id = getSequence().get("id");
        row.putParam("id", id);
        CrmPartnerValueSupport.changed(getDao().insert(row));
        return id;
    }

    /**
     * 方法作用：owning服务在来源锁内读不可变历史，执行锁原明细须位于Progress之后。
     *
     * @param input 例如org901/batch1200000
     * @param action 例如crm.funds.reverse或crm.funds.read
     * @return 真实本组织完整明细，不截断、不使用人工status有效标志；缺许可/事务拒绝，无写入。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> readHistory(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("batchId", CrmPartnerValueSupport.positive(input.getParam("batchId")));
        return getDao().readHistory(p);
    }

    /**
     * 只读真实范围效果，原明细不可变；调用方先持同来源Order/Line锁再校验父单。
     *
     * @param input org901/id1300000
     * @param action 当前stock.write/post或funds.write/post
     * @return 实际原明细Map，例如{sourceOrderLineId:600001,quantityDelta:-3,action:POST}；不存在拒绝
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> readAllocation(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }

    // 新退货结构门禁来自服务端，不能由客户金额方向开启。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
    private Boolean returnsEnabled;

    /**
     * 真实来源锁内只读原POST候选，不把余额或客户端候选当有效原单。
     *
     * @param input org901/sourceOrderLineId600001
     * @param action 当前真实stock.read或funds.read
     * @return 完整原POST列表例如[{id:1300000,sourceOrderLineId:600001,quantityDelta:-3}]
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> findForSource(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam(
                "sourceOrderLineId",
                CrmPartnerValueSupport.positive(input.getParam("sourceOrderLineId")));
        return getDao().findForSource(p);
    }

    /**
     * 方法作用：服务器从不可变原明细派生唯一严格相反金额，不接受客户端反向金额。
     *
     * @param input org901/batch1200001/originalDetail1300000
     * @return 新明细id及相反金额，原行不改且不复用id 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long appendStockReverse(CommonParam input) {
        var query = new CommonParam();
        query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        query.putParam("id", input.getParam("originalDetailId"));
        var original = lockScoped(query, "crm.stock.reverse");
        query.putParam("id", input.getParam("batchId"));
        var batch = batches.lockScoped(query, "crm.stock.reverse");
        if (!"STOCK".equals(original.get("effectKind"))
                || !"POST".equals(original.get("action"))
                || !"REVERSE".equals(batch.get("action"))
                || !batch.get("originalBatchId").equals(original.get("batchId"))
                || !batch.get("documentId").equals(original.get("documentId"))) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        var scope =
                access.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var row = new CommonParam();
        for (String f :
                List.of(
                        "documentId",
                        "documentLineId",
                        "sourceOrderLineId",
                        "lineNo",
                        "effectKind",
                        "stockBalanceId",
                        "warehouseId",
                        "productId")) {
            row.putParam(f, original.get(f));
        }
        row.putParam("batchId", batch.get("id"));
        row.putParam("action", "REVERSE");
        row.putParam("originalAction", "POST");
        row.putParam("originalDetailId", original.get("id"));
        row.putParam(
                "quantityDelta",
                Math.negateExact(((Number) original.get("quantityDelta")).longValue()));
        row = CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        long id = getSequence().get("id");
        row.putParam("id", id);
        CrmPartnerValueSupport.changed(getDao().insert(row));
        return id;
    }
}
