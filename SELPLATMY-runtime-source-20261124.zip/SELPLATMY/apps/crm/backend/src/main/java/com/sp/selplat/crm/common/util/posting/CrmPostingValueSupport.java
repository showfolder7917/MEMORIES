/** CrmPostingValueSupport.java：无状态请求值校验；不访问服务、SQL或权限。 */
package com.sp.selplat.crm.common.util.posting;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Map;
import java.util.Set;

/** 严格单据动作协议及精确版本，不接收客户端数据库事实或忽略批次。 */
public final class CrmPostingValueSupport {
    /** 私有工具构造，不创建状态或持久化对象。 */
    private CrmPostingValueSupport() {
        // 静态工具不创建实例状态。
    }

    /**
     * 校验单动作全部输入；批次必须显式拒绝，不截取首项。
     *
     * @param input 例如 {id:101,action:POST,requestKey:r1,expectedVersion:0}
     * @return 复制的四字段公共参数；数字主键与版本规范化为字符串 异常示例：额外/缺失字段、浮点、溢出、批次拒绝，不读库。
     */
    public static CommonParam request(CommonParam input) {
        Set<String> fields = Set.of("id", "action", "requestKey", "expectedVersion");
        if (input == null || !input.getParamMap().keySet().equals(fields)) {
            throw failure("INVALID_POSTING_REQUEST");
        }
        String id = String.valueOf(input.getParam("id"));
        String version = String.valueOf(input.getParam("expectedVersion"));
        if (!id.matches("[1-9][0-9]{0,18}") || !version.matches("[0-9]{1,18}")) {
            throw failure("INVALID_POSTING_VERSION");
        }
        try {
            Long.parseLong(id);
            Long.parseLong(version);
        } catch (NumberFormatException e) {
            throw failure("INVALID_POSTING_VERSION");
        }
        String action = String.valueOf(input.getParam("action"));
        String key = String.valueOf(input.getParam("requestKey"));
        if (!Set.of("POST", "REVERSE", "SUBMIT", "APPROVE", "REJECT", "REVISE", "CANCEL")
                        .contains(action)
                || !key.matches("[A-Za-z0-9_.:-]{1,64}")) {
            throw failure("INVALID_POSTING_REQUEST");
        }
        return param(
                Map.of(
                        "id",
                        Long.toString(Long.parseLong(id)),
                        "action",
                        action,
                        "requestKey",
                        key,
                        "expectedVersion",
                        Long.toString(Long.parseLong(version))));
    }

    /**
     * 从规范请求生成服务端摘要，覆盖单据ID、动作、版本。
     *
     * @param input 已校验参数，例如 id=101/action=POST/expectedVersion=0
     * @return 64位SHA256；不采用客户端摘要，不依赖可变数据库状态 异常示例：JDK无SHA256时阻断，不写请求记录。
     * @throws IllegalStateException 实际状态不满足正文条件时拒绝；不继续SQL或构造默认记录
     */
    public static String hash(CommonParam input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            for (String field : new String[] {"id", "action", "expectedVersion"}) {
                byte[] value =
                        String.valueOf(input.getParam(field)).getBytes(StandardCharsets.UTF_8);
                digest.update((field + ":" + value.length + ":").getBytes(StandardCharsets.UTF_8));
                digest.update(value);
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA256 unavailable", e);
        }
    }

    /**
     * 复制公共参数；输入例如{id:101}；返回独立容器；不修改原Map或写库。
     *
     * @param values 实际参数Map，例如{id:101}；复制时不写入原容器。
     * @return 独立容器
     */
    public static CommonParam param(Map<String, ?> values) {
        CommonParam result = new CommonParam();
        values.forEach(result::putParam);
        return result;
    }

    /**
     * 验证本次仅更新一行；输入例如0；返回void；0或多行抛异常回滚调用事务。
     *
     * @param count 本次SQL影响行数，例如1；0或多行表示并发变更失败。
     */
    public static void changed(int count) {
        if (count != 1) {
            throw failure("POSTING_CONCURRENT_CHANGE");
        }
    }

    /**
     * 验证隔离写门禁；输入例如false；返回void；禁止生产/文件库写入。
     *
     * @param enabled 已核验的隔离写门禁，例如false时拒绝，不改变生产许可。
     */
    public static void enabled(Boolean enabled) {
        if (!Boolean.TRUE.equals(enabled)) {
            throw failure("POSTING_WRITE_DISABLED");
        }
    }

    /**
     * 返回实际必需行；输入例如null；返回原行；缺失时拒绝，不伪造初始余额。
     *
     * @param row 真实查询结果，例如{id:101}或null；缺失时拒绝。
     * @return 实际必需行
     */
    public static Map<String, Object> row(Map<String, Object> row) {
        if (row == null) {
            throw failure("POSTING_RECORD_NOT_FOUND");
        }
        return row;
    }

    /**
     * 创建稳定失败；输入例如POSTING_WRITE_DISABLED；返回异常；无副作用。
     *
     * @param code 固定业务错误码，例如POSTING_WRITE_DISABLED，不含用户凭据。
     * @return 指定错误码的CommonBusinessException实例；仅构造，不执行SQL
     */
    public static CommonBusinessException failure(String code) {
        return new CommonBusinessException(code, "单据动作未执行，请核对状态、版本或隔离写入条件。");
    }
}
