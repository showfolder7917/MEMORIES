/* 客户归档兼容附加结构；2026-10-28，不覆盖原客户、业务启停、审计或号段。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 仅对原经营组织客户结构增加归档列；不开放许可、建新客户或删除任何历史。 */
@Configuration(proxyBeanMethods = false)
public class CrmPartnerArchivePersistenceConfiguration {
  // 当前归档元数据属于原客户表；历史原因属于原业务审计表，不创建第二套客户真相。
  private static final Map<String, Integer> PARTNER_COLUMNS =
      Map.of(
          "archivedFlag", Types.BOOLEAN,
          "archiveReasonText", Types.VARCHAR,
          "archivedByUserId", Types.BIGINT,
          "archivedAt", Types.TIMESTAMP_WITH_TIMEZONE);

  /**
   * 方法作用：先核原结构和所有已存在附加列，再执行同一拥有方SQL的兼容附加声明。
   *
   * @param source 固定crmDataSource，例如本例独立CRM文件库，不连接认证或教学库
   * @param inspector 原只读结构检查器，例如partner已实际安装
   * @return 真实返回示例：原partner缺失返回false；五个附加列经实际元数据核验后返回true。
   * @throws SQLException 元数据或DDL失败时阻止启动，不伪报已安装
   * @throws IllegalStateException 活动事务、未知不兼容列或声明后列缺失时拒绝，不重建或改写业务行
   */
  @Bean("crmPartnerArchiveInitialized")
  @DependsOn("crmBusinessStructureInspector")
  public Boolean initialize(
      @Qualifier("crmDataSource") DataSource source,
      @Qualifier("crmBusinessStructureInspector") CrmBusinessStructureInspector inspector)
      throws SQLException {
    if (!inspector.available().contains("partner")) {
      return false;
    }
    if (TransactionSynchronizationManager.isActualTransactionActive()) {
      throw new IllegalStateException("CRM_PARTNER_ARCHIVE_ACTIVE_TRANSACTION");
    }
    // 所有旧列先核验，避免先加客户列后才发现原审计列不是本版本声明的结构。
    verifyColumns(source, "CrmPartner", PARTNER_COLUMNS, false);
    verifyColumns(source, "CrmBusinessAudit", Map.of("reasonText", Types.VARCHAR), false);
    new ResourceDatabasePopulator(
            new ClassPathResource("db/crm/sql/schema-CrmPartner.sql"),
            new ClassPathResource("db/crm/sql/schema-CrmBusinessAudit.sql"))
        .execute(source);
    verifyColumns(source, "CrmPartner", PARTNER_COLUMNS, true);
    verifyColumns(source, "CrmBusinessAudit", Map.of("reasonText", Types.VARCHAR), true);
    return true;
  }

  /**
   * 方法作用：核本版本已知附加列的真实类型、必要长度、归档标志非空和DDL注释，不复制DAO元数据模型。
   *
   * @param source 实际拥有方CRM源，例如本例独立crm数据源
   * @param table 固定拥有方表名，例如CrmPartner
   * @param expected 固定字段类型，例如archivedFlag=BOOLEAN，不能由客户端传入
   * @param required true要求全部列及注释存在；false允许尚未附加的列
   * @throws SQLException 实际元数据不可读时传播，零业务写入
   * @throws IllegalStateException 已有同名异类型、短原因字段、可空归档标志或最终缺列时拒绝
   */
  private void verifyColumns(
      DataSource source, String table, Map<String, Integer> expected, boolean required)
      throws SQLException {
    try (var connection = source.getConnection()) {
      var metadata = connection.getMetaData();
      for (var field : expected.entrySet()) {
        try (var rows =
            metadata.getColumns(
                connection.getCatalog(), connection.getSchema(), table, field.getKey())) {
          if (!rows.next()) {
            if (required) {
              throw new IllegalStateException("CRM_PARTNER_ARCHIVE_COLUMN_MISSING");
            }
            continue;
          }
          if (rows.getInt("DATA_TYPE") != field.getValue()
              || (field.getValue() == Types.VARCHAR && rows.getInt("COLUMN_SIZE") != 200)
              || (field.getKey().equals("archivedFlag")
                  && rows.getInt("NULLABLE") != java.sql.DatabaseMetaData.columnNoNulls)
              || (required
                  && (rows.getString("REMARKS") == null || rows.getString("REMARKS").isBlank()))) {
            throw new IllegalStateException("CRM_PARTNER_ARCHIVE_STRUCTURE_CONFLICT");
          }
        }
      }
    }
  }
}
