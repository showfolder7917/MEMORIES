/**
 * CrmBusinessAuditDaoImpl.java：CRM经营组织客户维护本表组件。
 * 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
package com.sp.selplat.crm.businessaudit.dao;
/** 本表强类型公共DAO；审计/请求不对外开放通用更新。 */
@org.springframework.stereotype.Repository
public class CrmBusinessAuditDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao implements CrmBusinessAuditDao {

    /**
     * 保留请求审计列表默认主排序，同值记录以组织范围内唯一ID确定位置。
     *
     * @param conditions owning Service已核验条件，例如tenant92/org901/status1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际每页条数，例如2
     * @return 公共真实分页，例如三条同sortnum记录第2页返回唯一剩余记录、totalCount3
     *     异常或副作用示例：条件、SQL或方言错误沿公共链传播，不修改请求、审计或业务事实。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            java.util.Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }
}
