/* 客户类型本表持久化；2026-10-26。 */
package com.sp.selplat.crm.customertype.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** CRUD和元数据继承公共DAO；仅增加本表事务锁与CAS。 */
public interface CrmCustomerTypeDao extends BaseDao {
    /**
     * 方法作用：在本域事务内锁定本组织类型，包含已停用类型。
     * @param input 可信范围，例如tenantId92/businessOrgId901/id100000
     * @return 真实返回示例：id=100000/versionNo=0/enabledFlag=false；未命中null
     * 异常或副作用示例：无CRM事务拒绝，不锁其他表。
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 方法作用：按原版本更新类型和追加历史，不更新创建请求或编码。
     * @param input 可信字段，例如id100000/expectedVersion0/typeName校友/versionNo1
     * @return 真实返回示例：1；0表示原版本已变化。
     * 异常或副作用示例：唯一名称冲突由数据库拒绝，调用Service整体回滚。
     */
    int updateVersion(CommonParam input);
}
