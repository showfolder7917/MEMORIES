/** CRM 文件不可变概要校验；2026-10-11，Codex；显式识别本地旧概要与R2云概要，不授予访问权限或持久化关联。 */
package com.sp.selplat.crm.common.util.file;

import com.fasterxml.jackson.databind.JsonNode;
import com.sp.selplat.common.exception.CommonBusinessException;

import java.util.Map;

/** 只校验真实文件服务响应的固定字段，不根据客户端声明构造 owner、租户或 ready 状态。 */
public final class CrmFileMetadataSupport {
    /** 静态校验工具；构造不创建文件、Session 或业务记录。 */
    private CrmFileMetadataSupport() {
        // 只提供静态三元组校验，不持有HTTP或身份状态。
    }

    /**
     * 方法作用：检查候选值能直接用于固定 metadata 路径及精确摘要比较。
     *
     * @param fileId 文件服务返回的不可变标识，例如0123456789abcdef0123456789abcdef
     * @param sha256
     *     已上传正文的小写摘要，例如abc的ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad
     * @param byteSize 已上传正文的实际长度，例如3L 异常或副作用示例：路径文本、大小0、非小写摘要拒绝；不发HTTP、不修改业务事实。
     * @throws CommonBusinessException 例如大小0或路径输入时拒绝，不产生可访问URL
     */
    public static void requireCandidate(String fileId, String sha256, long byteSize) {
        // 固定32/64位十六进制，避免把路径、URL或其他身份塞进路由。
        if (fileId == null
                || !fileId.matches("[0-9a-f]{32}")
                || sha256 == null
                || !sha256.matches("[0-9a-f]{64}")
                || byteSize <= 0) {
            throw new CommonBusinessException("INVALID_CRM_FILE_REFERENCE", "文件引用不合法。");
        }
    }

    /**
     * 方法作用：只接受 owner 契约中真实成功的完整不可变三元组，拒绝类型转换和舍入。
     *
     * @param response 实际HTTP JSON，例如success=true/data.fileId为候选ID、byteSize=3、sha256为abc摘要、formatVersion=2、storageType=r2
     * @param fileId 当前待验证ID，例如0123456789abcdef0123456789abcdef
     * @param sha256 当前待验证SHA256，例如abc的小写64位摘要
     * @param byteSize 当前待验证字节数，例如3L
     * @return 精确概要，例如{fileId=0123456789abcdef0123456789abcdef,sha256=abc的64位摘要,byteSize=3}
     *     异常或副作用示例：metadata错误ID、不同摘要、浮点长度或缺字段拒绝；不标记业务绑定成功。
     * @throws CommonBusinessException 例如真实metadata字节数4与候选3不符时拒绝
     */
    public static Map<String, Object> verified(
            JsonNode response, String fileId, String sha256, long byteSize) {
        requireCandidate(fileId, sha256, byteSize);
        // 概要版本1保留旧记录合同；版本2只接受实际文件域公开的R2类型，未知版本/类型仍拒绝。
        // owner没有身份字段；授权来自实际同Host Session，不能靠伪造owner字段替代。
        JsonNode data = response == null ? null : response.get("data");
        if (response == null
                || !response.path("success").isBoolean()
                || !response.path("success").booleanValue()
                || data == null
                || !data.isObject()
                || !data.path("fileId").isTextual()
                || !fileId.equals(data.path("fileId").textValue())
                || !data.path("sha256").isTextual()
                || !sha256.equals(data.path("sha256").textValue())
                || !data.path("byteSize").isIntegralNumber()
                || !data.path("byteSize").canConvertToLong()
                || data.path("byteSize").longValue() != byteSize
                || !data.path("formatVersion").isIntegralNumber()
                || !data.path("formatVersion").canConvertToInt()
                || !(data.path("formatVersion").intValue() == 1
                        || data.path("formatVersion").intValue() == 2
                                && data.path("storageType").isTextual()
                                && "r2".equals(data.path("storageType").textValue()))) {
            throw new CommonBusinessException("CRM_FILE_METADATA_MISMATCH", "文件概要未通过核验。");
        }
        // 只返回已精确核对的三元组，不复制远端未知字段、存储路径或访问凭据。
        return Map.of("fileId", fileId, "sha256", sha256, "byteSize", byteSize);
    }
    /**
     * 方法作用：核对文件系统独立共享概要的所有者及不可变正文，不能套用本人formatVersion合同。
     * @param response 实际共享路由JSON，例如success=true/data含ownerUserId=9211、storageType=r2、revision=1
     * @param ownerUserId CRM已存引用的真实所有者，例如9211L；不是当前操作员身份
     * @param fileId CRM引用标识，例如0123456789abcdef0123456789abcdef
     * @param sha256 CRM引用摘要，例如abc正文的64位小写摘要
     * @param byteSize CRM引用长度，例如3L
     * @return 真实返回示例：仅fileId、sha256、byteSize=3及ownerUserId=9211的已核对标量。
     * 异常或副作用示例：错误所有者、浮点字段、非R2或不匹配摘要拒绝，不赋予共享或下载许可。
     * @throws CommonBusinessException 共享概要不满足实际公开合同时拒绝
     */
    public static Map<String, Object> verifiedShared(JsonNode response, long ownerUserId,
            String fileId, String sha256, long byteSize) {
        requireCandidate(fileId, sha256, byteSize);
        JsonNode data = response == null ? null : response.get("data");
        if (ownerUserId <= 0 || response == null || !response.path("success").isBoolean()
                || !response.path("success").booleanValue() || data == null || !data.isObject()
                || !data.path("ownerUserId").isIntegralNumber() || !data.path("ownerUserId").canConvertToLong()
                || data.path("ownerUserId").longValue() != ownerUserId
                || !data.path("fileId").isTextual() || !fileId.equals(data.path("fileId").textValue())
                || !data.path("sha256").isTextual() || !sha256.equals(data.path("sha256").textValue())
                || !data.path("byteSize").isIntegralNumber() || !data.path("byteSize").canConvertToLong()
                || data.path("byteSize").longValue() != byteSize
                || !data.path("revision").isIntegralNumber() || !data.path("revision").canConvertToLong()
                || data.path("revision").longValue() < 1
                || !data.path("storageType").isTextual() || !"r2".equals(data.path("storageType").textValue())) {
            throw new CommonBusinessException("CRM_FILE_METADATA_MISMATCH", "共享文件概要未通过核验。");
        }
        // 许可由实际共享API裁决；此返回只保存核对坐标，不复制名称、签名URL或控制根。
        return Map.of("fileId", fileId, "sha256", sha256, "byteSize", byteSize, "ownerUserId", ownerUserId);
    }

}
