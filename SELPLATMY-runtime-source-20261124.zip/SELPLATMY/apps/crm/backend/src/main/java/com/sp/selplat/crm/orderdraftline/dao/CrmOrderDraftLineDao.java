/**
 * CrmOrderDraftLineDao.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.orderdraftline.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** 私人订单明细 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmOrderDraftLineDao extends BaseDao {
}
