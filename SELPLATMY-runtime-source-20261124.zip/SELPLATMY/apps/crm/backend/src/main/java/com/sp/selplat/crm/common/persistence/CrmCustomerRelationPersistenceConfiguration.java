/* 客户关系附加结构装配；2026-10-28。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionTemplate;

/** 仅对原客户结构实际可用的CRM池附加独立关系表，不改变原客户及联系人。 */
@Configuration(proxyBeanMethods = false)
public class CrmCustomerRelationPersistenceConfiguration {
    /**
     * 方法作用：幂等创建本关系表并补独立号段，已有业务及游标保持。
     * @param source 原具名CRM池，例如隔离CRM内存库
     * @param inspector 原结构检查器，例如partner实际已安装
     * @return 真实返回示例：原客户未安装为false；本关系结构安装成功为true。
     * 异常或副作用示例：DDL失败沿启动失败传播，不创建默认客户关系。
     */
    @Bean("crmCustomerRelationsInitialized")
    @DependsOn("crmBusinessStructureInspector")
    public Boolean initialize(@Qualifier("crmDataSource") DataSource source,
            @Qualifier("crmBusinessStructureInspector") CrmBusinessStructureInspector inspector) {
        if (!inspector.available().contains("partner")) { return false; }
        new ResourceDatabasePopulator(new ClassPathResource("db/crm/sql/schema-CrmCustomerRelation.sql")).execute(source);
        new TransactionTemplate(new DataSourceTransactionManager(source)).executeWithoutResult(state ->
                new ResourceDatabasePopulator(new ClassPathResource("db/crm/sql/data-CommonSequenceSegment.sql")).execute(source));
        return true;
    }
}
