/**
 * CrmIsolatedPersistentSourcePolicy.java：CRM显式持久测试源边界，不开放生产业务。 修改记录：2026-10-03，Codex
 * 按委托补真实重启验收，禁止默认文件库回落。
 */
package com.sp.selplat.crm.common.config;

import org.springframework.core.env.Environment;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/** 只认可系统临时目录内带准确合成测试标识的专用双文件库，无默认路径或权限授予。 */
public final class CrmIsolatedPersistentSourcePolicy {
    /** 静态测试源边界工具，不构建实例状态。 副作用示例：构造不读取目录、不建立连接或创建数据。 */
    private CrmIsolatedPersistentSourcePolicy() {
        // 静态边界工具不建立实例状态。
    }

    /**
     * 判断是否请求持久测试，profile或显式开关任一出现即必须完整验证。
     *
     * @param environment 真实配置，例如profile=crm-isolated-persistence-test、enabled=true
     * @return 示例true表示必须检查；未出现两项时false，不改变既有mem/生产行为 副作用示例：只读配置，不创建目录、连接或业务数据。
     */
    public static boolean requested(Environment environment) {
        return Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-isolated-persistence-test")
                || environment.getProperty(
                        "crm.isolated.persistence-enabled", Boolean.class, false);
    }

    /**
     * 在连接池创建前核验绝对真实路径、专用标识、所有URL和双库职责。
     *
     * @param environment 例如目录/tmp/crm-isolated-abcdef12，id=abcdef12及明确crm/uniauth文件URL
     * @return 示例true表示验证成功；未请求持久测试false
     * @throws IllegalStateException 不完整配置、符号路径、错误标识或任一URL不符时CRM_ISOLATED_SOURCE_MISMATCH
     *     副作用示例：只读取既有测试标识文件；不创建或覆盖文件，不执行DDL。
     */
    public static boolean validate(Environment environment) {
        if (!requested(environment)) {
            return false;
        }
        try {
            var profiles = Arrays.asList(environment.getActiveProfiles());
            String id = environment.getProperty("crm.isolated.persistence-id", "");
            String configured = environment.getProperty("crm.isolated.persistence-directory", "");
            if (!profiles.contains("crm-isolated-persistence-test")
                    || !profiles.contains("crm-partner-maintenance-test")
                    || !environment.getProperty(
                            "crm.isolated.persistence-enabled", Boolean.class, false)
                    || !id.matches("[a-z0-9]{8,40}")
                    || configured.isBlank()) {
                throw new IOException("Incomplete persistent test configuration");
            }
            Path directory = Path.of(configured);
            Path temp = Path.of(System.getProperty("java.io.tmpdir")).toRealPath();
            // 无路径正规化回落：必须由消费者明确创建、完整写出并核对当前专用目录。
            if (!directory.isAbsolute()
                    || !directory.equals(directory.normalize())
                    || !directory.equals(directory.toRealPath())
                    || !directory.getParent().equals(temp)
                    || !directory.getFileName().toString().equals("crm-isolated-" + id)) {
                throw new IOException("Persistent directory identity mismatch");
            }
            Path marker = directory.resolve(".crm-isolated-test-owner");
            if (!Files.isRegularFile(marker, java.nio.file.LinkOption.NOFOLLOW_LINKS)
                    || !Files.readString(marker).equals("CRM_ISOLATED_TEST_ONLY\n" + id + "\n")) {
                throw new IOException("Persistent marker mismatch");
            }
            for (String module : java.util.List.of("crm", "uniauth")) {
                String expected =
                        "jdbc:h2:file:"
                                + directory.resolve(module)
                                + ";MODE=MySQL;DATABASE_TO_UPPER=false;DB_CLOSE_ON_EXIT=FALSE";
                if (!expected.equals(environment.getProperty(module + ".datasource.jdbc-url"))
                        || !expected.equals(
                                environment.getProperty(
                                        "crm.isolated.expected-" + module + "-url"))) {
                    throw new IOException("Explicit persistent URL mismatch: " + module);
                }
                // 不跟随既有数据库符号链接，避免正确目录标识掩盖对历史文件的重定向。
                for (String suffix : java.util.List.of(".mv.db", ".lock.db", ".trace.db")) {
                    if (Files.isSymbolicLink(directory.resolve(module + suffix))) {
                        throw new IOException("Linked database file");
                    }
                }
            }
            return true;
        } catch (IOException | IllegalArgumentException failure) {
            throw new IllegalStateException(
                    "CRM_ISOLATED_SOURCE_MISMATCH: dedicated marked persistent test sources required before initialization",
                    failure);
        }
    }

    /**
     * 核对实际CRM池URL，持久门禁不能只依赖环境中的期望文本。
     *
     * @param environment 例如已核对专用目录和两个准确URL的真实配置
     * @param actualUrl
     *     例如jdbc:h2:file:/tmp/crm-isolated-abcdef12/crm;MODE=MySQL;DATABASE_TO_UPPER=false;DB_CLOSE_ON_EXIT=FALSE
     * @return 示例true表示显式持久CRM源；未请求或actualUrl不符false，业务拒绝 副作用示例：再次只读验证测试标识，不授予用户/组织许可。
     */
    public static boolean matches(Environment environment, String actualUrl) {
        return validate(environment)
                && actualUrl.equals(environment.getProperty("crm.isolated.expected-crm-url"));
    }
}
