/** CRM附件引用owning DAO；2026-10-04，Codex；所有SQL限本表。 */
package com.sp.selplat.crm.orderattachment.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** CRUD复用公共DAO，独立版本比较及范围锁使用本表固定SQL。 */
public interface CrmOrderAttachmentDao extends BaseDao {
    /**
     * 方法作用：锁定本订单当前上传者的准确附件引用。
     *
     * @param input 服务端范围tenant92/org901/owner9211/order600000/id100000
     * @return 实际行例如versionNo1或不存在时null；无跨用户回落 异常或副作用示例：没有真实CRM事务时拒绝，不锁其他表。
     */
    Map<String, Object> lockOwned(CommonParam input);

    /**
     * 方法作用：仅在本上传者/订单/版本全部匹配时替换不可变fileId引用。
     *
     * @param input 例如id100000/expectedAttachmentVersion1/新fileId，身份由服务端回查
     * @return 0或1实际影响行数，0由业务事务拒绝，不覆盖新版本 异常或副作用示例：唯一约束失败使整个CRM事务回滚，不删除远端正文。
     */
    int compareAndSet(CommonParam input);
    /**
     * 方法作用：按明确文件资源定位同一订单唯一引用；此查询不代替独立文件许可。
     * @param input 服务端tenant92/org901/order600000及候选owner9212/fileId为32位ID
     * @return 真实返回示例：准确引用行id100000；不存在为null，调用方仍须核共享许可。
     * 异常或副作用示例：不跨组织或其他订单回落，不修改业务行。
     */
    Map<String, Object> findByFileReference(CommonParam input);

}
