/**
 * CrmOrderPricingSupport.java：新订单 MONEY_V1 精确定价计算。
 * 修改记录：2026-10-03，Codex 按受限 V2.1 基线实现，不写库或处理历史接续。
 */
package com.sp.selplat.crm.common.util.pricing;

import com.sp.selplat.common.exception.CommonBusinessException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 无状态服务辅助算法；只算显式新订单输入，不查主数据、不冻结审批、不授予组织权限。 */
public final class CrmOrderPricingSupport {
    // 目标 DECIMAL(38,0) 的非负最大值；所有持久化候选金额均受此界限约束。
    private static final BigInteger MAX_MINOR = BigInteger.TEN.pow(38).subtract(BigInteger.ONE);
    // 折减万分率分母，用整数商余数实现 HALF_UP，避免二进制浮点。
    private static final BigInteger BASIS = BigInteger.valueOf(10000);
    // 计算请求不接受身份、状态、历史定价策略或客户端已经算出的金额。
    private static final Set<String> HEAD_FIELDS = Set.of("currency", "fee", "lines");
    // 稳定行号和业务输入白名单，不允许客户端指定退款权益或行应付。
    private static final Set<String> LINE_FIELDS = Set.of("lineNo", "productId", "quantity", "unitPrice", "discountBps", "isGift");

    /**
     * 禁止实例化纯计算工具。
     * 副作用示例：无实例状态或数据库连接。
     */
    private CrmOrderPricingSupport() {
    }

    /**
     * 对新订单全部行执行 MONEY_V1 并返回文本 MINOR 值；不修改输入。
     * @param input 服务收到的显式值，例如 currency=CNY、fee=0.01、两行单价1.01/1.00、数量1、discountBps=3333
     * @return 例如 totalMinor=135、refundableGoodsMinor=134、两行approvedDueMinor=68/67，writeEnabled=false
     * @throws CommonBusinessException 超行数、未知字段、币种/输入精度非法、赠品非零价或金额超过38位时拒绝
     */
    public static Map<String, Object> calculate(Map<String, Object> input) {
        // 只有明确币种、费用、完整行输入才能计算，未知字段不能绕过规则。
        if (input == null || !input.keySet().equals(HEAD_FIELDS)) {
            throw failure("INVALID_PRICING_REQUEST");
        }
        String currency = String.valueOf(input.get("currency"));
        int scale = switch (currency) {
            case "CNY", "USD" -> 2;
            case "JPY" -> 0;
            default -> throw failure("PRICING_POLICY_UNSUPPORTED");
        };
        BigInteger fee = minor(input.get("fee"), scale);
        if (!(input.get("lines") instanceof List<?> rawLines) || rawLines.isEmpty() || rawLines.size() > 1000) {
            throw failure("DOCUMENT_LINE_LIMIT");
        }
        List<Map<String, Object>> lines = new ArrayList<>();
        Set<Integer> lineNumbers = new HashSet<>();
        BigInteger grossTotal = BigInteger.ZERO;
        BigInteger netTotal = BigInteger.ZERO;
        for (Object item : rawLines) {
            // 每行完整白名单防止客户端注入已审批金额、策略或可信归属。
            if (!(item instanceof Map<?, ?> raw) || !raw.keySet().equals(LINE_FIELDS)) {
                throw failure("INVALID_PRICING_REQUEST");
            }
            int lineNo = integer(raw.get("lineNo"), Integer.MAX_VALUE).intValueExact();
            if (lineNo == 0 || !lineNumbers.add(lineNo)) {
                throw failure("INVALID_PRICING_REQUEST");
            }
            BigInteger product = integer(raw.get("productId"), Long.MAX_VALUE);
            BigInteger quantity = integer(raw.get("quantity"), Long.MAX_VALUE);
            int discount = integer(raw.get("discountBps"), 10000).intValueExact();
            if (product.signum() == 0 || quantity.signum() == 0 || !(raw.get("isGift") instanceof Boolean gift)) {
                throw failure("INVALID_PRICING_REQUEST");
            }
            BigInteger price = minor(raw.get("unitPrice"), scale);
            if ((gift && (price.signum() != 0 || discount != 0)) || (!gift && price.signum() == 0)) {
                throw failure("INVALID_PRICING_REQUEST");
            }
            BigInteger gross = bounded(quantity.multiply(price));
            BigInteger[] quotient = gross.multiply(BigInteger.valueOf(10000 - discount)).divideAndRemainder(BASIS);
            // 每行独立 HALF_UP；头只求和，不能把两行合并后折扣舍入。
            BigInteger net = quotient[0].add(quotient[1].compareTo(BigInteger.valueOf(5000)) >= 0 ? BigInteger.ONE : BigInteger.ZERO);
            Map<String, Object> line = new LinkedHashMap<>();
            line.put("lineNo", Integer.toString(lineNo));
            line.put("productId", product.toString());
            line.put("quantity", quantity.toString());
            line.put("unitPriceMinor", price.toString());
            line.put("discountBps", Integer.toString(discount));
            line.put("isGift", gift);
            line.put("grossMinor", gross.toString());
            line.put("lineDiscountMinor", gross.subtract(net).toString());
            line.put("lineNetMinor", net.toString());
            lines.add(line);
            grossTotal = bounded(grossTotal.add(gross));
            netTotal = bounded(netTotal.add(net));
        }
        // 输入行顺序不影响结果；权重相同的费用余数按稳定行号分配。
        lines.sort(Comparator.comparingInt(line -> Integer.parseInt((String) line.get("lineNo"))));
        if (netTotal.signum() == 0 && fee.signum() > 0) {
            throw failure("INVALID_PRICING_REQUEST");
        }
        BigInteger allocated = BigInteger.ZERO;
        Map<String, BigInteger> remainders = new LinkedHashMap<>();
        for (Map<String, Object> line : lines) {
            BigInteger weight = new BigInteger((String) line.get("lineNetMinor"));
            BigInteger[] share = netTotal.signum() == 0 ? new BigInteger[] {BigInteger.ZERO, BigInteger.ZERO}
                    : fee.multiply(weight).divideAndRemainder(netTotal);
            line.put("feeAllocatedMinor", share[0].toString());
            remainders.put((String) line.get("lineNo"), share[1]);
            allocated = allocated.add(share[0]);
        }
        List<Map<String, Object>> ranked = new ArrayList<>(lines);
        ranked.sort(Comparator.<Map<String, Object>, BigInteger>comparing(line -> remainders.get(line.get("lineNo")))
                .reversed().thenComparingInt(line -> Integer.parseInt((String) line.get("lineNo"))));
        // 最大余数法剩余单位严格少于行数，不逐单位循环巨额费用。
        int remaining = fee.subtract(allocated).intValueExact();
        for (int i = 0; i < remaining; i++) {
            Map<String, Object> line = ranked.get(i);
            line.put("feeAllocatedMinor", new BigInteger((String) line.get("feeAllocatedMinor")).add(BigInteger.ONE).toString());
        }
        for (Map<String, Object> line : lines) {
            BigInteger net = new BigInteger((String) line.get("lineNetMinor"));
            line.put("approvedDueMinor", bounded(net.add(new BigInteger((String) line.get("feeAllocatedMinor")))).toString());
            // GOODS_ONLY_V1 只给商品净额退款权利，费用0退款额与收款上限明确分开。
            line.put("refundableGoodsMinor", net.toString());
            line.put("refundableFeeMinor", "0");
            line.put("refundPolicyVersion", "GOODS_ONLY_V1");
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("currency", currency);
        result.put("currencyScale", scale);
        result.put("pricingPolicyVersion", "MONEY_V1");
        result.put("refundPolicyVersion", "GOODS_ONLY_V1");
        result.put("subtotalMinor", grossTotal.toString());
        result.put("discountMinor", grossTotal.subtract(netTotal).toString());
        result.put("feeMinor", fee.toString());
        result.put("totalMinor", bounded(netTotal.add(fee)).toString());
        result.put("refundableGoodsMinor", netTotal.toString());
        result.put("refundableFeeMinor", "0");
        result.put("lines", lines);
        result.put("writeEnabled", false);
        result.put("factsVerified", false);
        result.put("approved", false);
        return result;
    }

    /**
     * 将字符串主币单位精确转为 MINOR，不接受浮点或隐式舍入。
     * @param value 请求字符串，例如CNY的"1.01"，不是JSON double
     * @param scale 白名单币种精度，例如CNY=2
     * @return 精确整数，例如101
     * @throws CommonBusinessException "0.001"、指数、负数、空值、超过38位或非字符串拒绝
     */
    private static BigInteger minor(Object value, int scale) {
        if (!(value instanceof String text) || text.length() > 42 || !text.matches("[0-9]+(?:\\.[0-9]+)?")) {
            throw failure("AMOUNT_SCALE_INVALID");
        }
        BigDecimal decimal = new BigDecimal(text);
        if (decimal.scale() > scale) {
            throw failure("AMOUNT_SCALE_INVALID");
        }
        return bounded(decimal.movePointRight(scale).toBigIntegerExact());
    }

    /**
     * 解析非负整数文本；标识、数量和折扣不得经浮点转换。
     * @param value 原值，例如quantity="2"
     * @param maximum 目标整数存储上界，例如数量Long.MAX_VALUE、折减10000
     * @return 精确整数，例如2
     * @throws CommonBusinessException 小数、负数、空值、数字对象或超过上界拒绝
     */
    private static BigInteger integer(Object value, long maximum) {
        if (!(value instanceof String text) || text.length() > 19 || !text.matches("[0-9]+")) {
            throw failure("INVALID_PRICING_REQUEST");
        }
        BigInteger integer = new BigInteger(text);
        if (integer.compareTo(BigInteger.valueOf(maximum)) > 0) {
            throw failure("INVALID_PRICING_REQUEST");
        }
        return integer;
    }

    /**
     * 检查目标金额存储边界。
     * @param amount 精确非负候选，例如101
     * @return 原整数，例如101
     * @throws CommonBusinessException 超过DECIMAL(38,0)界限时拒绝整个计算
     */
    private static BigInteger bounded(BigInteger amount) {
        if (amount.compareTo(MAX_MINOR) > 0) {
            throw failure("AMOUNT_OVERFLOW");
        }
        return amount;
    }

    /**
     * 创建公共安全业务错误，不泄露原始输入。
     * @param code 稳定原因，例如AMOUNT_SCALE_INVALID
     * @return 公共异常，例如errorCode=AMOUNT_SCALE_INVALID
     * 副作用示例：只构造异常，不写日志或数据库。
     */
    private static CommonBusinessException failure(String code) {
        return new CommonBusinessException(code, "订单定价输入不符合首版规则。");
    }
}
