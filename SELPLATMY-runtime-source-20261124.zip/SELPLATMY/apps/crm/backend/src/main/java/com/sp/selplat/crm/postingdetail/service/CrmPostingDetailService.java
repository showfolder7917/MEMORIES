/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdetail.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmPostingDetailService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定stock.post等动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);

    /**
     * 全量父行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @param action 当前固定stock/funds动作，例如crm.stock.post；真实许可重新核验
     * @return 实际本表结果；缺范围/事务拒绝
     */
    List<Map<String, Object>> readAll(CommonParam input, String action);

    /**
     * 同一CRM事务插入效果/行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @param action 当前固定stock/funds动作，例如crm.stock.post；真实许可重新核验
     * @return 实际本表结果；缺范围/事务拒绝
     */
    Long append(CommonParam input, String action);

    /**
     * Actual cash effects page.
     *
     * @param input org901/page1
     * @return scoped exact amountDeltaMinor text records, funds.read required
     */
    CommonPageResult fundsStore(CommonPageParam input);

    /**
     * 方法作用：服务器从不可变原明细派生唯一严格相反金额，不接受客户端反向金额。
     *
     * @param input org901/batch1200001/originalDetail1300000
     * @return 新明细id及相反金额，原行不改且不复用id 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Long appendFundsReverse(CommonParam input);

    /**
     * 方法作用：owning服务在来源锁内读不可变历史，执行锁原明细须位于Progress之后。
     *
     * @param input 例如org901/batch1200000
     * @param action 例如crm.funds.reverse或crm.funds.read
     * @return 真实本组织完整明细，不截断、不使用人工status有效标志；缺许可/事务拒绝，无写入。
     */
    List<Map<String, Object>> readHistory(CommonParam input, String action);

    /**
     * 在真实来源锁内读原明细事实，不提前占用进度后才获取的容量锁。
     *
     * @param input org901/id1300000
     * @param action 当前真实stock.write/post或funds.write/post
     * @return 实际原Map例如{sourceOrderLineId:600001,quantityDelta:-3,action:POST}；不存在统一拒绝
     */
    Map<String, Object> readAllocation(CommonParam input, String action);

    /**
     * 按已核范围读取真实来源的原POST候选，实际有效性由引用聚合器重核。
     *
     * @param input org901/sourceOrderLineId600001
     * @param action 实际stock.read或funds.read
     * @return 原POST列表例如[{id:1300000,sourceOrderLineId:600001,quantityDelta:-3}]，不创建流水
     */
    List<Map<String, Object>> findForSource(CommonParam input, String action);

    /**
     * 新增唯一完整库存反向明细；例如原POST1200000返回新REVERSE1200001，原流水保留。
     *
     * @param input org901/实际原批次或明细及新反向批次
     * @return 新真实主键，重复或错范围全事务回滚
     */
    Long appendStockReverse(CommonParam input);
}
