/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.warehouse.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmWarehouseService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定stock.post等动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);
}
