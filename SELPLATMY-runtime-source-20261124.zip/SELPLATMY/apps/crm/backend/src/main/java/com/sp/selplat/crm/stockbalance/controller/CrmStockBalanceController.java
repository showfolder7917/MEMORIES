/**
 * CrmStockBalanceController.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.stockbalance.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.stockbalance.service.CrmStockBalanceService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表只读控制器；参数解析、身份校验和持久化分别由平台/本表 Service 承担。 */
@RestController
@RequestMapping("/api/crm/stockbalance")
public class CrmStockBalanceController {
    // 仅依赖本表服务，不跨表读取 DAO 或建立私有返回协议。
    private final CrmStockBalanceService service;

    /**
     * 绑定真实表服务。
     * @param service Spring 泛型 DAO 已装配的本表服务
     * 副作用示例：构造不查询数据库，不建立 Session。
     */
    public CrmStockBalanceController(CrmStockBalanceService service) {
        this.service = service;
    }

    /**
     * 序列化本人有效记录的标准分页。
     * @param queryIn 平台解析器提供，例如 {pageNo:1,pageSize:20}
     * @return JSON 公共页，例如 {records:[],totalCount:0,pageNo:1,pageSize:20}
     * 异常示例：未登录或归属失效沿用统一拒绝；不写入记录。
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam queryIn) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(queryIn));
    }

    /**
     * 序列化真实精确主键详情。
     * @param queryIn 平台解析器提供，例如 {id:100001}
     * @return JSON 公共结果，例如 {success:true,data:{id:100001}}
     * 异常示例：非法主键、其他归属或删除记录拒绝，不进行范围读取。
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam queryIn) {
        return JsonUtils.toJsonIgnoreNull(service.getById(queryIn));
    }
}
