/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.warehouse.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.warehouse.dao.CrmWarehouseDao;
import com.sp.selplat.crm.warehouse.service.CrmWarehouseService;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmWarehouseServiceImpl
        extends com.sp.selplat.common.service.BaseServiceImpl<CrmWarehouseDao>
        implements CrmWarehouseService {
    protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 注入真实范围入口；构造不授予权限。
     *
     * @param access 实际统一Session范围入口CrmAccessService；例如由服务核验组织901，不授予许可。
     */
    public CrmWarehouseServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

    /**
     * 公共真实范围分页。
     *
     * @param input 例如org901/page1；可信身份由Session给出
     * @return 本组织精确文本记录；缺库存读许可拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
        page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
        return page;
    }

    /**
     * 公共真实范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 本组织有效记录；不存在统一拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
    }

    /**
     * 批读不开放。
     *
     * @param input 例如空items
     * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 真实操作员，无默认账号。
     *
     * @return 例如9211；失效Session拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 真实租户，无默认租户。
     *
     * @return 例如92；失效Session拒绝
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 无隐式管理员。
     *
     * @return 返回示例：false；不扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用写关闭。
     *
     * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * owning精确锁，只由具名真实CRM事务消费。
     *
     * @param input 例如org901/id1000000
     * @param action 固定stock.post动作
     * @return 本组织真实行；没有实际记录/许可拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockScoped(CommonParam input, String action) {
        var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }
}
