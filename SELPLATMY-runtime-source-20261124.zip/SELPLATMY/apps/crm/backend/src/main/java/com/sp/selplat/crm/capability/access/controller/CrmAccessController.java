/**
 * CrmAccessController.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.capability.access.controller;

import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * CRM 准入控制器只序列化服务结果，不读取账号表或拼装业务状态。
 */
@RestController
@RequestMapping("/api/crm/access")
public class CrmAccessController {

  private final CrmAccessService service;

  /**
   * 绑定本域准入服务。
   *
   * @param service Spring 注入的准入实现，例如 {@code CrmAccessServiceImpl}
   * 执行结果示例：后续 HTTP 请求复用服务实例，不创建额外身份上下文。
   */
  public CrmAccessController(CrmAccessService service) {
    this.service = service;
  }

  /**
   * 方法作用：只返回实际获准读取的组织选择项，组织名称用字面查询。
   * @param input 公共请求参数，例如query=青禾；不得提交tenant或actor
   * @return 真实返回示例：success=true/data含组织901及其独立只读动作。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 非法额外字段或身份失效拒绝
   */
  @GetMapping("organizations.htm")
  public String organizations(com.sp.selplat.common.util.CommonParam input) {
    if (input == null || !java.util.Set.of("query").containsAll(input.getParamMap().keySet())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "INVALID_CRM_INPUT", "组织查询参数无效。");
    }
    Object query = input.getParam("query");
    if (query != null && !(query instanceof String)) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "INVALID_CRM_INPUT", "组织名称必须是文本。");
    }
    return JsonUtils.toJsonIgnoreNull(
        service.organizationChoices(query == null ? "" : (String) query));
  }

  /**
   * 方法作用：序列化财务原资金读取资格的真实机构候选。
   * @param input 字面查询，例如query新思度，不接受租户、账号或动作覆盖
   * @return 真实示例：success=true/data.organizations含原901，或无资格时空列表。
   * 异常或副作用示例：未知参数或非文本拒绝，不创建授权或读取跨租户业务。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原查询参数未知或不是文本时拒绝，例如资金机构查询参数含tenantId。
   */
  @GetMapping("funds-organizations.htm")
  public String fundsOrganizations(com.sp.selplat.common.util.CommonParam input) {
    if (input == null
        || !java.util.Set.of("query").containsAll(input.getParamMap().keySet())
        || (input.getParam("query") != null && !(input.getParam("query") instanceof String))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "INVALID_CRM_INPUT", "资金机构查询参数无效。");
    }
    return JsonUtils.toJsonIgnoreNull(
        service.fundsOrganizationChoices(
            input.getParam("query") == null ? "" : (String) input.getParam("query")));
  }

  /**
   * 读取 CRM 准入状态，匿名请求由统一异常响应拒绝。
   *
   * @return 统一 JSON，例如 {@code {"success":true,"data":{"moduleId":"crm","businessReady":false}}}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 身份不存在或失效时抛出统一身份错误
   */
  @GetMapping("readiness.htm")
  public String readiness() {
    return JsonUtils.toJsonIgnoreNull(service.readiness());
  }
}
