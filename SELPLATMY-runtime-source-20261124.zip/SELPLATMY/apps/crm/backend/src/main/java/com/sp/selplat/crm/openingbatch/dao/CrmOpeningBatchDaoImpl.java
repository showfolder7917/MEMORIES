/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.openingbatch.dao;

import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmOpeningBatchDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
    implements CrmOpeningBatchDao {

  private final org.springframework.jdbc.core.JdbcTemplate jdbc;

  /**
   * 注入本域固定模板；构造不执行SQL。
   *
   * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
   */
  public CrmOpeningBatchDaoImpl(
      @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
          org.springframework.jdbc.core.JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * 本表范围锁，不从客户端读取可信org。
   *
   * @param input 例如tenant92/org901/id1000000
   * @return 实际有效行或null；事务缺失时拒绝
   */
  @Override
  public Map<String, Object> lockScoped(CommonParam input) {
    requireCrmTransaction();
    var rows =
        jdbc.queryForList(
            "SELECT * FROM CrmOpeningBatch WHERE tenantId=? AND businessOrgId=? AND id=? AND"
                + " status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("id"));
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 方法作用：精确本组织创建请求查询，只访问原期初表。
   *
   * @param input 真实tenant92/org901/requestKey opening-1
   * @return 真实返回示例：id900000及原创建摘要；未找到null。 异常或副作用示例：SQL失败传播，无写入。
   */
  @Override
  public Map<String, Object> fundsCreation(CommonParam input) {
    var rows =
        jdbc.queryForList(
            "SELECT * FROM CrmOpeningBatch WHERE tenantId=? AND businessOrgId=? AND"
                + " fundsCreationKey=? AND status=1",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("requestKey"));
    if (rows.size() > 1) {
      throw new IllegalStateException("CRM_OPENING_DUPLICATE_REQUEST");
    }
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 方法作用：期初正文、状态和原请求历史同一SQL保存；不跨表。
   *
   * @param input 已核真实正文，例如id900000/account90101/amountMinor0/stateDRAFT
   * @param create true只创建草稿，false沿当前状态和版本CAS
   * @return 真实返回示例：1；旧版本或状态改变0。 异常或副作用示例：缺事务拒绝，数据库异常交外层整体回滚。
   */
  @Override
  public int saveFunds(CommonParam input, boolean create) {
    requireCrmTransaction();
    if (create) {
      return jdbc.update(
          "INSERT INTO CrmOpeningBatch"
              + " (id,tenantId,businessOrgId,createdByUserId,updatedByUserId,lastOperateUserId,cutoff,evidenceHash,"
              + "openingState,versionNo,labelZh,fundsAccountId,fundsCurrency,fundsAmountMinor,fundsCreationKey,"
              + "fundsCreationHash,fundsHistoryJson)"
              + " VALUES (?,?,?,?,?,?,?,?, 'DRAFT',0,?,?,?,?,?,?,?)",
          input.getParam("id"),
          input.getParam("tenantId"),
          input.getParam("businessOrgId"),
          input.getParam("actorUserId"),
          input.getParam("actorUserId"),
          input.getParam("actorUserId"),
          input.getParam("cutoff"),
          input.getParam("evidenceHash"),
          input.getParam("labelZh"),
          input.getParam("fundsAccountId"),
          input.getParam("fundsCurrency"),
          input.getParam("fundsAmountMinor"),
          input.getParam("requestKey"),
          input.getParam("payloadHash"),
          input.getParam("fundsHistoryJson"));
    }
    return jdbc.update(
        "UPDATE CrmOpeningBatch SET"
            + " cutoff=?,evidenceHash=?,openingState=?,labelZh=?,fundsAccountId=?,fundsCurrency=?,"
            + "fundsAmountMinor=?,submittedByUserId=?,approvedByUserId=?,updatedByUserId=?,lastOperateUserId=?,"
            + "fundsHistoryJson=?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND fundsAccountId IS"
            + " NOT NULL AND versionNo=? AND openingState=?",
        input.getParam("cutoff"),
        input.getParam("evidenceHash"),
        input.getParam("openingState"),
        input.getParam("labelZh"),
        input.getParam("fundsAccountId"),
        input.getParam("fundsCurrency"),
        input.getParam("fundsAmountMinor"),
        input.getParam("submittedByUserId"),
        input.getParam("approvedByUserId"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("fundsHistoryJson"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("expectedVersion"),
        input.getParam("previousState"));
  }

  /**
   * 方法作用：本表资金期初真实计数及稳定分页，不拉全表在内存裁切。
   *
   * @param input 已核tenant92/org901/pageNo2/pageSize20
   * @return 真实示例：第二页1行、totalCount21/pageNo2/pageSize20。 异常或副作用示例：固定参数化SQL，不连接库存或余额表。
   */
  @Override
  public com.sp.selplat.common.util.CommonPageResult fundsPage(
      com.sp.selplat.common.util.CommonPageParam input) {
    var result = new com.sp.selplat.common.util.CommonPageResult();
    result.setTotalCount(
        jdbc.queryForObject(
            "SELECT COUNT(*) FROM CrmOpeningBatch WHERE tenantId=? AND businessOrgId=? AND status=1"
                + " AND fundsAccountId IS NOT NULL",
            Long.class,
            input.getParam("tenantId"),
            input.getParam("businessOrgId")));
    result.setRecords(
        jdbc.queryForList(
            "SELECT * FROM CrmOpeningBatch WHERE tenantId=? AND businessOrgId=? AND status=1 AND"
                + " fundsAccountId IS NOT NULL ORDER BY id DESC LIMIT ? OFFSET ?",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getPageSize(),
            (input.getPageNo() - 1L) * input.getPageSize()));
    result.setPageNo(input.getPageNo());
    result.setPageSize(input.getPageSize());
    return result;
  }
}
