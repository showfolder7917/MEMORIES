/** CrmFundsBalanceDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.fundsbalance.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** 本人隔离过账记录 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmFundsBalanceDao extends BaseDao {
    /**
     * 本表固定 SQL 扩展 lockScoped；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表固定 SQL 扩展 applyDeltaIfVersion；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    int applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input);

    /**
     * Fixed organization/account/currency lock.
     *
     * @param input verified tenant92/org901/account90101/CNY
     * @return actual row or null, transaction mandatory
     */
    java.util.Map<String, Object> lockOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * Exact minor receipt CAS.
     *
     * @param input actual id/version and positive amountMinor e.g. 68
     * @return 1 or 0; zero must roll back the complete receipt
     */
    int receiveOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * 方法作用：同账户聚合减额CAS保证不负余额。
     *
     * @param input 余额980001/version1/amount135/actor9211
     * @return 影响1或0；0行外层回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    int reverseOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * 方法作用：只向原组织余额表建立已批准期初对应的初始金额。
     * @param input 真实来源，例如opening900000/account90101/CNY/amountMinor0
     * @return 真实返回示例：影响1；唯一冲突由真实数据库拒绝。
     * 异常或副作用示例：缺事务拒绝，不覆盖已有余额或流水。
     */
    int initializeOpening(com.sp.selplat.common.util.CommonParam input);

}
