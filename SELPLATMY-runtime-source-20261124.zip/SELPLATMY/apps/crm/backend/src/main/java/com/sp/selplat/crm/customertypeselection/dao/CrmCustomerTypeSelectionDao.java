/* 客户多类型选择本表CAS；2026-10-26。 */
package com.sp.selplat.crm.customertypeselection.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

/** 客户锁由原客户Service持有；本表增加版本更新，其他CRUD继承公共DAO。 */
public interface CrmCustomerTypeSelectionDao extends BaseDao {
    /**
     * 方法作用：按租户、组织、客户和原版本更新选择及审计。
     * @param input 可信字段，例如id100000/tenantId92/businessOrgId901/partnerId200000/expectedVersion1
     * @return 真实返回示例：1；0表示未覆盖任何新版本。
     * 异常或副作用示例：无CRM事务拒绝，不读取其他表。
     */
    int updateVersion(CommonParam input);
}
