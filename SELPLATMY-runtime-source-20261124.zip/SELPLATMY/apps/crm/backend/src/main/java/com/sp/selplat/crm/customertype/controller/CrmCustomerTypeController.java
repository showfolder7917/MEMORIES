/* 客户类型HTTP入口；2026-10-26，仅调用本表Service，不接管权限。 */
package com.sp.selplat.crm.customertype.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.customertype.service.CrmCustomerTypeService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 可定制客户分类目录与具名保存入口；客户和供应商原角色保持独立。 */
@RestController
@RequestMapping("/api/crm/customer-type")
public class CrmCustomerTypeController {
    // 真实组织范围、版本、幂等与审计由本表Service核验。
    private final CrmCustomerTypeService service;

    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/id100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    @GetMapping("history.htm")
    public String history(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.history(input)); }

    /**
     * 方法作用：装配本表业务服务，不读写分类。
     * @param service 实际分类Service，例如CrmCustomerTypeServiceImpl
     * 异常或副作用示例：仅绑定依赖，不初始化家长或孩子等固定分类。
     */
    public CrmCustomerTypeController(CrmCustomerTypeService service) {
        this.service = service;
    }

    /**
     * 方法作用：序列化实际组织分类目录。
     * @param input HTTP候选，例如organizationCandidateId=901/includeDisabled=true
     * @return 真实返回示例：success=true/data.types=[{id:"100000",typeName:"家长",versionNo:"0"}]
     * 异常或副作用示例：跨组织无读取资格时由Service拒绝；零写入。
     */
    @GetMapping("directory.htm")
    public String directory(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.directory(input));
    }

    /**
     * 方法作用：序列化分类新增、改名、排序及停用结果。
     * @param input 业务候选，例如org901/requestKey=type-1/typeName=家长/enabledFlag=true
     * @return 真实返回示例：success=true/data={id:"100000",versionNo:"0",replay:false}
     * 异常或副作用示例：旧版本或同请求异内容由Service拒绝，不直接删除历史类型。
     */
    @PostMapping("save.htm")
    public String save(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.save(input));
    }
}
