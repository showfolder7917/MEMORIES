/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 * 修改记录：2026-10-10，缺依赖动作明确业务拒绝，避免不可变集合查询null导致空指针。 */
package com.sp.selplat.crm.postingdependency.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.postingdependency.dao.CrmPostingDependencyDao;
import com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmPostingDependencyServiceImpl
        extends com.sp.selplat.common.service.BaseServiceImpl<CrmPostingDependencyDao>
        implements CrmPostingDependencyService {
    // 真实Session和组织动作准入，不能从请求绑定可信身份。
    protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 绑定真实身份及本域范围入口；构造不授予任何角色或许可。
     *
     * @param access Spring提供的真实CrmAccessService，例如Session核tenant92/actor9211后再核org901动作
     */
    public CrmPostingDependencyServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

    /**
     * 公共真实范围分页。
     *
     * @param input 例如org901/page1；可信身份由Session给出
     * @return 本组织精确文本记录；缺资金读许可拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        requireReversalStructure();
        // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
        var scope =
                access.requireFundsScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
        var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
        page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
        return page;
    }

    /**
     * 公共真实范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 本组织有效记录；不存在统一拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        requireReversalStructure();
        // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
        var scope =
                access.requireFundsScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
    }

    /**
     * 批读不开放。
     *
     * @param input 例如空items
     * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 真实操作员，无默认账号。
     *
     * @return 例如9211；失效Session拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 真实租户，无默认租户。
     *
     * @return 例如92；失效Session拒绝
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 无隐式管理员。
     *
     * @return 返回示例：false；不扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用写关闭。
     *
     * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * owning精确锁，只由具名真实CRM事务消费。
     *
     * @param input 例如org901/id1000000
     * @param action 固定资金读取、冲正或审核动作
     * @return 本组织真实行；没有实际记录/许可拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockScoped(CommonParam input, String action) {
        requireReversalStructure();
        var scope = access.requireFundsScope(input.getParam("organizationCandidateId"), action);
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }

    /**
     * 方法作用：owning依赖服务只查询已存在的同组织记录。
     *
     * @param input org901/parent1300000
     * @return 真实依赖，无人工置为无效接口 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public List<Map<String, Object>> parentEdges(CommonParam input) {
        requireReversalStructure();
        var scope =
                access.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam(
                "parentDetailId",
                CrmPartnerValueSupport.positive(input.getParam("parentDetailId")));
        return getDao().parentEdges(p);
    }

    // 新增冲正结构读取前显式准入，不扩生产权限。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmFundsReversalIsolatedEnabled")
    private Boolean reversalEnabled;

    /** 方法作用：在新表读取或写入前检查额外显式冲正测试结构。 副作用示例：旧profile或生产默认CRM_SCOPE_UNAVAILABLE；不查询不存在的新表、不扩权。 */
    private void requireReversalStructure() {
        if (!Boolean.TRUE.equals(reversalEnabled)) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
    }

    // 新边只由显式一期退货结构创建，不由通用CRUD或人工status赋予有效性。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
    private Boolean returnsEnabled;

    // 只调用实际明细owning服务，不注入跨表DAO。
    @org.springframework.beans.factory.annotation.Autowired
    private org.springframework.beans.factory.ObjectProvider<
                    com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService>
            allocationDetails;

    // 单据owning服务提供父子真实类型和状态。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.document.service.CrmDocumentService allocationDocuments;

    // 批次owning服务提供真实有效父POST历史。
    @org.springframework.beans.factory.annotation.Autowired
    private org.springframework.beans.factory.ObjectProvider<
                    com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService>
            allocationBatches;

    /**
     * 生成候选组织与一个真实关联主键，不携带客户端可信身份。
     *
     * @param input org901
     * @param key 固定id或documentId
     * @param value 实际关联id例如1300000
     * @return 新参数例如{organizationCandidateId:901,id:1300000}
     */
    private CommonParam relation(CommonParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 当前真实子效果绑定先前有效父效果形成不可变DAG，不修改或屏蔽原流水。
     *
     * @param input org901/child1300002/parent1300000/dependencyKind RETURN_FOR_ISSUE
     * @param action 当前真实stock.post或funds.post
     * @return 新边例如1800000；同批、自环、跨来源、父失效或方向类型错误整批回滚
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺动作或未知动作抛CRM_ACTION_FORBIDDEN，不读取业务行
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Long appendAllocation(CommonParam input, String action) {
        if (!Boolean.TRUE.equals(returnsEnabled)) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
        // 缺动作也属于明确拒绝，不能让ImmutableSet.contains(null)产生系统空指针。
        if (action == null || !java.util.Set.of("crm.stock.post", "crm.funds.post").contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var child =
                allocationDetails
                        .getObject()
                        .readAllocation(
                                relation(input, "id", input.getParam("childDetailId")), action);
        var parent =
                allocationDetails
                        .getObject()
                        .readAllocation(
                                relation(input, "id", input.getParam("parentDetailId")), action);
        var childDoc =
                allocationDocuments.lockScoped(
                        relation(input, "id", child.get("documentId")), action);
        var parentDoc =
                allocationDocuments.lockScoped(
                        relation(input, "id", parent.get("documentId")), action);
        var parentHistory =
                allocationBatches
                        .getObject()
                        .findForDocument(
                                relation(input, "documentId", parent.get("documentId")), action);
        if (!"POST".equals(child.get("action"))
                || !"POST".equals(parent.get("action"))
                || child.get("id").equals(parent.get("id"))
                || child.get("batchId").equals(parent.get("batchId"))
                || !child.get("sourceOrderLineId").equals(parent.get("sourceOrderLineId"))
                || !childDoc.get("orderId").equals(parentDoc.get("orderId"))
                || !"POSTED".equals(parentDoc.get("documentState"))
                || parentHistory.size() != 1
                || !"POST".equals(parentHistory.get(0).get("action"))
                || !parent.get("batchId").equals(parentHistory.get(0).get("id"))) {
            throw CrmPartnerValueSupport.failure("POSTING_PARENT_INACTIVE");
        }
        boolean childReturn =
                "STOCK_RECEIPT".equals(childDoc.get("documentKind"))
                        && "SALES_RETURN".equals(childDoc.get("reason"))
                        && child.get("refundCapacityMinor") != null;
        boolean childRefund =
                "FUNDS_PAYMENT".equals(childDoc.get("documentKind"))
                        && "SALES_RETURN".equals(childDoc.get("reason"));
        String kind = String.valueOf(input.getParam("dependencyKind"));
        boolean valid =
                switch (kind) {
                    case "RETURN_FOR_ISSUE" ->
                            childReturn
                                    && "crm.stock.post".equals(action)
                                    && "STOCK_ISSUE".equals(parentDoc.get("documentKind"))
                                    && "SALE".equals(parentDoc.get("reason"));
                    case "SERIAL_RETURN_ENTITLEMENT" ->
                            childReturn
                                    && "crm.stock.post".equals(action)
                                    && "STOCK_RECEIPT".equals(parentDoc.get("documentKind"))
                                    && "SALES_RETURN".equals(parentDoc.get("reason"));
                    case "REFUND_FOR_RECEIPT" ->
                            childRefund
                                    && "crm.funds.post".equals(action)
                                    && "FUNDS_RECEIPT".equals(parentDoc.get("documentKind"))
                                    && "SALE".equals(parentDoc.get("reason"));
                    case "REFUND_FOR_RETURN" ->
                            childRefund
                                    && "crm.funds.post".equals(action)
                                    && "STOCK_RECEIPT".equals(parentDoc.get("documentKind"))
                                    && "SALES_RETURN".equals(parentDoc.get("reason"));
                    default -> false;
                };
        if (!valid) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
        }
        var entity = new CommonParam();
        entity.putParam("childDetailId", child.get("id"));
        entity.putParam("parentDetailId", parent.get("id"));
        entity.putParam("dependencyKind", kind);
        entity = CrmPartnerValueSupport.entity(entity, scope);
        entity.getParamMap().remove("versionNo");
        long id = getSequence().get("id");
        entity.putParam("id", id);
        CrmPartnerValueSupport.changed(getDao().insert(entity));
        return id;
    }

    /**
     * 明确冲正动作下读取不可变依赖父边；例如org901/parent1300000/stock.reverse返回RETURN子边。
     *
     * @param input org901/parentDetailId1300000
     * @param action 精确stock.reverse或funds.reverse，现有真实Session/许可重核
     * @return 同组织真实边；未知动作拒绝，无业务写入
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺动作或未知动作抛CRM_ACTION_FORBIDDEN，不读取业务行
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> parentEdges(CommonParam input, String action) {
        requireReversalStructure();
        // 缺动作也属于明确拒绝，不能让ImmutableSet.contains(null)产生系统空指针。
        if (action == null || !java.util.Set.of("crm.stock.reverse", "crm.funds.reverse").contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam(
                "parentDetailId",
                CrmPartnerValueSupport.positive(input.getParam("parentDetailId")));
        return getDao().parentEdges(p);
    }

    /**
     * 在进度锁前读取真实序列前驱，供稳定Document锁组使用；例如child1300002返回父1300001。
     *
     * @param input org901/childDetailId1300002
     * @param action 精确stock.reverse或funds.reverse
     * @return 本表真实child边，未知动作拒绝，不修改边
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺动作或未知动作抛CRM_ACTION_FORBIDDEN，不读取业务行
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> childEdges(CommonParam input, String action) {
        requireReversalStructure();
        // 缺动作也属于明确拒绝，不能让ImmutableSet.contains(null)产生系统空指针。
        if (action == null || !java.util.Set.of("crm.stock.reverse", "crm.funds.reverse").contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam(
                "childDetailId", CrmPartnerValueSupport.positive(input.getParam("childDetailId")));
        return getDao().childEdges(p);
    }
}
