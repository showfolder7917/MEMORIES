/** CRM 同Host订单文件核验；2026-10-04，Codex；默认关闭，不创建附件账本。 */
package com.sp.selplat.crm.capability.orderfile.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.capability.orderfile.service.CrmOrderFileService;
import com.sp.selplat.crm.common.util.file.CrmFileMetadataSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.order.service.CrmOrderService;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 只访问服务器固定同Host metadata路由；转发当前实际Session的一枚Cookie，不授予访问权限。 */
@Service
public class CrmOrderFileServiceImpl implements CrmOrderFileService {
    // 当前身份及真实经营组织动作均由已交付CRM准入入口重新回查。
    private final CrmAccessService access;
    // 订单数据只能通过 owning Service 读取，不跨DAO或推断组织。
    private final CrmOrderService orders;
    // 可信origin与Cookie名只能来自服务器配置，缺配置保持关闭。
    private final Environment environment;
    // 使用宿主正式Jackson，不引入第三方客户端或JSON兼容替身。
    private final ObjectMapper json;

    /**
     * 方法作用：装配真实 owning 服务和宿主配置，不创建共享HTTP客户端或Session。
     *
     * @param access 实际CRM准入，例如CrmAccessServiceImpl
     * @param orders 实际订单 owning 服务，例如CrmOrderServiceImpl
     * @param environment 服务器配置，例如crm.file-service.enabled=false
     * @param json 宿主Jackson，例如已配置ObjectMapper 副作用示例：构造不查询文件服务或创建业务记录。
     */
    public CrmOrderFileServiceImpl(
            CrmAccessService access,
            CrmOrderService orders,
            Environment environment,
            ObjectMapper json) {
        this.access = access;
        this.orders = orders;
        this.environment = environment;
        this.json = json;
    }

    /**
     * 方法作用：范围和真实订单先检查，metadata完成后再复核范围与版本；此接口不保存附件关联。
     *
     * @param input
     *     例如organizationCandidateId=901/id=600000/expectedVersion=0/fileId为上传结果/sha256为正文摘要/byteSize=3
     * @return 公共结果，例如success=true/data.bindingWritten=false、orderId=600000/orderVersion=0及核对后三元组
     *     异常或副作用示例：production默认CRM_SCOPE_UNAVAILABLE；关闭或非同Host配置拒绝，不写审计、金额或库存。
     */
    @Override
    public CommonResult verify(CommonParam input) {
        // 输入严格限候选字段；owner、tenant、URL、Cookie不能成为业务输入。
        if (input == null
                || !Set.of(
                                "organizationCandidateId",
                                "id",
                                "expectedVersion",
                                "fileId",
                                "sha256",
                                "byteSize")
                        .containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE");
        }
        var scope =
                access.requireOrderScope(
                        input.getParam("organizationCandidateId"), "crm.order.write");
        CommonParam order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("id")));
        long expected = CrmPartnerValueSupport.version(input.getParam("expectedVersion"));
        requireOrderVersion(order, expected);
        // 默认关闭优先于文件HTTP；开启也不能绕过订单范围与真实资源存在检查。
        if (!environment.getProperty("crm.file-service.enabled", Boolean.class, false)) {
            throw CrmPartnerValueSupport.failure("CRM_FILE_SERVICE_UNAVAILABLE");
        }
        String fileId = CrmPartnerValueSupport.text(input.getParam("fileId"), 32, true);
        String sha = CrmPartnerValueSupport.text(input.getParam("sha256"), 64, true);
        long bytes = CrmPartnerValueSupport.positive(input.getParam("byteSize"));
        CrmFileMetadataSupport.requireCandidate(fileId, sha, bytes);
        HttpServletRequest request =
                ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                        .getRequest();
        URI origin = trustedOrigin(request);
        String cookie = currentCookie(request);
        var metadata =
                read(
                        origin.resolve("/api/file-service/files/" + fileId + "/metadata"),
                        cookie,
                        fileId,
                        sha,
                        bytes);
        // 远端查询期间失效、撤权或订单变化必须拒绝；核验结果不是可复用授权凭证。
        var after =
                access.requireOrderScope(
                        input.getParam("organizationCandidateId"), "crm.order.write");
        if (!scope.get("tenantId").equals(after.get("tenantId"))
                || !scope.get("actorUserId").equals(after.get("actorUserId"))
                || !scope.get("businessOrgId").equals(after.get("businessOrgId"))
                || !cookie.equals(currentCookie(request))) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        requireOrderVersion(order, expected);
        Map<String, Object> data = new LinkedHashMap<>(metadata);
        data.put("orderId", order.getParam("id").toString());
        data.put("orderVersion", Long.toString(expected));
        data.put("bindingWritten", false);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：只从当前Session读取指定所有者的共享概要，并复核订单版本及当前身份。
     * @param input owning附件提供的org901/id600000/expectedVersion0/ownerUserId9211及已存文件三元组
     * @return 真实返回示例：ownerUserId=9211、fileId、sha256、byteSize=3；不创建绑定或下载票据。
     * 异常或副作用示例：缺独立共享许可、换号、错误所有者或版本变化均拒绝；不借用所有者Cookie。
     */
    @Override
    public CommonResult readSharedReference(CommonParam input) {
        if (input == null || !Set.of("organizationCandidateId", "id", "expectedVersion", "ownerUserId",
                "fileId", "sha256", "byteSize").containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE");
        }
        var scope = access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read");
        long owner = CrmPartnerValueSupport.positive(input.getParam("ownerUserId"));
        if (Long.valueOf(owner).equals(scope.get("actorUserId"))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_FILE_REFERENCE");
        }
        var order = new CommonParam();
        order.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        order.putParam("id", CrmPartnerValueSupport.positive(input.getParam("id")));
        long version = CrmPartnerValueSupport.version(input.getParam("expectedVersion"));
        requireOrderVersion(order, version);
        if (!environment.getProperty("crm.file-service.enabled", Boolean.class, false)) {
            throw CrmPartnerValueSupport.failure("CRM_FILE_SERVICE_UNAVAILABLE");
        }
        String fileId = CrmPartnerValueSupport.text(input.getParam("fileId"), 32, true);
        String sha = CrmPartnerValueSupport.text(input.getParam("sha256"), 64, true);
        long bytes = CrmPartnerValueSupport.positive(input.getParam("byteSize"));
        CrmFileMetadataSupport.requireCandidate(fileId, sha, bytes);
        var request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String cookie = currentCookie(request);
        var data = CrmFileMetadataSupport.verifiedShared(readJson(trustedOrigin(request).resolve(
                "/api/file-service/files/" + fileId + "/shared/" + owner), cookie), owner, fileId, sha, bytes);
        // owner始终是资源坐标；读取身份和租户仍由本次Session及文件系统自己的共享资格裁决。
        var after = access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read");
        for (String field : Set.of("tenantId", "actorUserId", "businessOrgId")) {
            if (!scope.get(field).equals(after.get(field))) { throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN"); }
        }
        if (!cookie.equals(currentCookie(request))) { throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN"); }
        requireOrderVersion(order, version);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：通过 owning Service 查询真实有范围订单，检查一次核验的候选版本。
     *
     * @param order 例如org901/id600000；身份不来自客户端
     * @param expected 页面读取的实际版本，例如0L 异常或副作用示例：版本已到1则CRM_VERSION_CONFLICT；不更新或冻结订单正文。
     */
    private void requireOrderVersion(CommonParam order, long expected) {
        Map<?, ?> row = (Map<?, ?>) orders.getById(order).getData();
        if (CrmPartnerValueSupport.version(row.get("versionNo")) != expected) {
            throw CrmPartnerValueSupport.failure("CRM_VERSION_CONFLICT");
        }
    }

    /**
     * 方法作用：只接受明确服务器配置且直接指向当前Servlet监听地址/端口的origin。
     *
     * @param request 当前真实请求，例如localhost监听127.0.0.1:随机测试端口
     * @return 固定origin，例如http://127.0.0.1:实际端口；客户端Host不参与构造
     *     异常或副作用示例：空配置、路径、远端主机或其他端口拒绝；不接受重定向或回落URL。
     */
    private URI trustedOrigin(HttpServletRequest request) {
        try {
            URI uri = URI.create(environment.getProperty("crm.file-service.trusted-origin", ""));
            String host = uri.getHost();
            int port =
                    uri.getPort() < 0
                            ? ("https".equals(uri.getScheme()) ? 443 : 80)
                            : uri.getPort();
            if (!Set.of("http", "https").contains(String.valueOf(uri.getScheme()))
                    || host == null
                    || uri.getRawUserInfo() != null
                    || uri.getRawQuery() != null
                    || uri.getRawFragment() != null
                    || !(uri.getRawPath().isEmpty() || "/".equals(uri.getRawPath()))
                    || !host.equals(request.getLocalAddr())
                    || port != request.getLocalPort()
                    || !uri.getScheme().equals(request.getScheme())) {
                throw new IllegalArgumentException("Current Host origin required");
            }
            return uri;
        } catch (IllegalArgumentException error) {
            throw CrmPartnerValueSupport.failure("CRM_FILE_SERVICE_UNAVAILABLE");
        }
    }

    /**
     * 方法作用：转发当前请求已有、且由Servlet实际解析为当前Session的配置Cookie，绝不建立新Session。
     *
     * @param request 实际请求，例如携带当前JSESSIONID且getSession(false)非空
     * @return 仅服务器配置名称的一枚Cookie头，例如JSESSIONID=当前实际Session标识；不得记录该值
     *     异常或副作用示例：无Session、非Cookie会话或名字非法拒绝；不转发其他Cookie及Authorization。
     */
    private String currentCookie(HttpServletRequest request) {
        var session = request.getSession(false);
        String name =
                environment.getProperty(
                        "crm.file-service.session-cookie-name",
                        environment.getProperty(
                                "server.servlet.session.cookie.name", "JSESSIONID"));
        if (session == null
                || !name.matches("[A-Za-z][A-Za-z0-9_-]{0,63}")
                || !request.isRequestedSessionIdFromCookie()
                || !request.isRequestedSessionIdValid()
                || !session.getId().equals(request.getRequestedSessionId())
                || !session.getId().matches("[A-Za-z0-9._:-]{1,200}")) {
            throw CrmPartnerValueSupport.failure("UNIAUTH_IDENTITY_REQUIRED");
        }
        return name + "=" + session.getId();
    }

    /**
     * 方法作用：使用无重定向JDK客户端读取固定metadata路由，限定响应字节数及连接/响应头/正文等待时间。
     *
     * @param uri 固定服务路由，例如http://127.0.0.1:实际端口/api/file-service/files/32位ID/metadata
     * @param cookie 当前实际Session的一枚Cookie；仅传输，不落日志或持久化
     * @param fileId 候选上传ID，例如0123456789abcdef0123456789abcdef
     * @param sha 候选正文小写SHA256，例如abc的64位摘要
     * @param bytes 候选精确正文大小，例如3L
     * @return 核对后的不可变三元组，例如fileId/sha256/byteSize=3 异常或副作用示例：非200、超时或概要损坏拒绝；不重传文件、删除文件或创建CRM关联。
     * @throws CommonBusinessException 例如连接中断、线程中断或概要不匹配时安全拒绝
     */
    private Map<String, Object> read(
            URI uri, String cookie, String fileId, String sha, long bytes) {
        return CrmFileMetadataSupport.verified(readJson(uri, cookie), fileId, sha, bytes);
    }

    /**
     * 方法作用：有界读取服务器固定同Host JSON，两个公开概要合同共用传输保护。
     * @param uri 固定实际路由，例如/api/file-service/files/32位ID/shared/9211
     * @param cookie 当前实际Session单一Cookie，不记录或复制其他用户身份
     * @return 真实返回示例：success=true/data为实际文件服务JSON，尚需调用方校验其固定合同。
     * 异常或副作用示例：非200、重定向、超时或损坏JSON拒绝，不创建文件或业务引用。
     * @throws CommonBusinessException 当前文件服务无法返回完整概要时拒绝
     */
    private com.fasterxml.jackson.databind.JsonNode readJson(URI uri, String cookie) {
        // 每次实际请求独立关闭客户端，避免持有跨用户Cookie或泄漏线程。
        try (HttpClient client =
                HttpClient.newBuilder()
                        .connectTimeout(Duration.ofSeconds(3))
                        .followRedirects(HttpClient.Redirect.NEVER)
                        .build()) {
            var request =
                    HttpRequest.newBuilder(uri)
                            .timeout(Duration.ofSeconds(5))
                            .header("Accept", "application/json")
                            .header("Cookie", cookie)
                            .GET()
                            .build();
            var response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
            // 正文也使用明确截止时间；关闭正文先于关闭reader，超时不能留下阻塞网络读线程。
            try (var readers = java.util.concurrent.Executors.newVirtualThreadPerTaskExecutor();
                    var body = response.body()) {
                var pending = readers.submit(() -> body.readNBytes(16385));
                byte[] raw;
                try {
                    raw = pending.get(5, java.util.concurrent.TimeUnit.SECONDS);
                } catch (java.util.concurrent.ExecutionException
                        | java.util.concurrent.TimeoutException error) {
                    pending.cancel(true);
                    throw CrmPartnerValueSupport.failure("CRM_FILE_REFERENCE_UNAVAILABLE");
                }
                if (response.statusCode() != 200 || raw.length > 16384) {
                    throw CrmPartnerValueSupport.failure("CRM_FILE_REFERENCE_UNAVAILABLE");
                }
                return json.readTree(raw);
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new CommonBusinessException("CRM_FILE_REFERENCE_UNAVAILABLE", "文件概要查询未完成。");
        } catch (IOException unavailable) {
            throw new CommonBusinessException("CRM_FILE_REFERENCE_UNAVAILABLE", "文件概要查询未完成。");
        }
    }
}
