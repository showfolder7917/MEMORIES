/** CrmOrder：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.order.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.order.service.CrmOrderService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表Controller只消费owning Service和公共结果。 */
@RestController
@RequestMapping("/api/crm/order")
public class CrmOrderController {
    private final CrmOrderService service;

    /**
     * 装配owning服务，不读写数据库；示例为真实CrmOrderServiceImpl。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmOrderController(CrmOrderService service) {
        this.service = service;
    }

    /**
     * 实际范围分页；org901/page1；返回公共分页，无许可拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，限定本组织/status1；商品选择另限定ACTIVE
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 实际范围详情；org901/id600000；返回公共data，无记录或跨组织拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/全部行或product701；拒绝不存在/越范围
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }

    /**
     * workspace只委托owning服务；org901/keyk1/version0；返回实际状态与精确头行，缺许可或旧版本拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共data，聚合本组织真实订单/客户/商品及三语SELUI定义，明确synthetic=true
     */
    @GetMapping("workspace.htm")
    public String workspace(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.workspace(input));
    }

    /**
     * saveDraft只委托owning服务；org901/keyk1/version0；返回实际状态与精确头行，缺许可或旧版本拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @PostMapping("saveDraft.htm")
    public String saveDraft(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.saveDraft(input));
    }

    /**
     * submit只委托owning服务；org901/keyk1/version0；返回实际状态与精确头行，缺许可或旧版本拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @PostMapping("submit.htm")
    public String submit(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.submit(input));
    }

    /**
     * approve只委托owning服务；org901/keyk1/version0；返回实际状态与精确头行，缺许可或旧版本拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @PostMapping("approve.htm")
    public String approve(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.approve(input));
    }
    /**
     * 方法作用：原页面撤回命令只委托订单拥有方，不能从客户端指定操作者或目标状态。
     * @param input 原页面正文，例如organizationCandidateId901/id600000/expectedVersion1/requestKeywithdraw1
     * @return 真实示例：success=true/data.orderState=DRAFT/data.versionNo=2；未审核订单可继续编辑。
     * 异常或副作用示例：已审核或他人提交订单拒绝，无资金、库存或课时变更。
     */
    @PostMapping("withdraw.htm")
    public String withdraw(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.withdraw(input));
    }

    /**
     * 方法作用：将具名订单驳回请求委托原订单拥有方，身份不由页面指定。
     * @param input 真实示例：organizationCandidateId901/id600000/expectedVersion1/requestKeyreject1/reasonText核对订购数量
     * @return 真实示例：success=true/data.orderStateDRAFT/versionNo2的JSON。
     * 异常或副作用示例：无原因或无原审核资格拒绝，Controller不直接更新状态。
     */
    @PostMapping("reject.htm")
    public String reject(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.reject(input));
    }


}
