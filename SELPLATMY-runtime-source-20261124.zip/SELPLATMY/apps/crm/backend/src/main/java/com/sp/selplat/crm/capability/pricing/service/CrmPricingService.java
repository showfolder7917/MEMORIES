/**
 * CrmPricingService.java：新订单无写入计算能力。
 * 修改记录：2026-10-03，Codex 按 V2.1 定价合同提供计算入口。
 */
package com.sp.selplat.crm.capability.pricing.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 登录仅允许计算显式输入；不读取组织资产、不授予订单维护或审批权限。 */
public interface CrmPricingService {
    /**
     * 回查真实账号后计算新订单金额，不确认商品存在或审核事实。
     * @param input 公共参数，例如currency=CNY、fee=0、lines中quantity=1/unitPrice=1.00
     * @return 公共结果，例如success=true、data.totalMinor=100、data.writeEnabled=false
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名、账号失效、输入非法时拒绝
     */
    CommonResult preview(CommonParam input);
}
