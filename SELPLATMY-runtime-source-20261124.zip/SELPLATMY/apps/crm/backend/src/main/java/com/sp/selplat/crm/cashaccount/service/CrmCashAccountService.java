/** 单一销售收款隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.cashaccount.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmCashAccountService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定stock.post等动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);
    /**
     * 方法作用：按原crm.funds.write维护账务账户，金额及币种历史不被修改。
     * @param input 原组织候选，例如org901/requestKeyaccount-1/codeSCHOOL-CNY/name学校现金/currencyCNY/reasonText建立
     * @return 真实返回示例：success=true/data.id="1600000"/versionNo="0"/replay=false。
     * 异常或副作用示例：普通读取许可不可写、旧版本、同键异正文或改币种拒绝；不开户转账。
     */
    com.sp.selplat.common.util.CommonResult saveAccount(CommonParam input);
}
