/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingbatch.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmPostingBatchDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmPostingBatchDao {
    /**
     * 保留默认sortnum主排序，以本组织唯一id稳定读取同值分页，不改变业务范围或写入。
     *
     * @param conditions 服务回查的实际条件，例如tenantId=92/businessOrgId=901/status=1
     * @param pageNo 原页码，例如2
     * @param pageSize 原页长，例如1
     * @return 公共实际页，例如totalCount=12/pageNo=2/records为第二个真实ID
     *     异常或副作用示例：公共查询异常沿原合同抛出；不修改履约、账本或号段。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmPostingBatchDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingBatch WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：按真实单据查询不可变批次历史，不用status隐藏冲正关系。
     *
     * @param input tenant92/org901/documentId1000000
     * @return 实际POST与REVERSE批次或空列表 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public List<Map<String, Object>> findForDocument(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingBatch WHERE tenantId=? AND businessOrgId=? AND documentId=? ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("documentId"));
    }
}
