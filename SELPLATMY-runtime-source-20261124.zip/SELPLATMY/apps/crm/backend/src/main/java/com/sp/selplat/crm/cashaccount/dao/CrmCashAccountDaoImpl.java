/** 单一销售收款隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.cashaccount.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmCashAccountDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmCashAccountDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmCashAccountDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmCashAccount WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }
    /**
     * 方法作用：在可信组织内读取账户首次请求；调用方处理并发提交后的回放。
     * @param input 真实tenant92/businessOrgId901/creationRequestKeyaccount-1
     * @return 真实返回示例：原账户Map含id1600000；未命中null。
     * 异常或副作用示例：固定参数化只读SQL，不按显示名称猜测。
     */
    @Override
    public Map<String, Object> creation(CommonParam input) {
        var rows = jdbc.queryForList("SELECT * FROM CrmCashAccount WHERE tenantId=? AND businessOrgId=? "
                + "AND creationRequestKey=? AND status=1", input.getParam("tenantId"),
                input.getParam("businessOrgId"), input.getParam("creationRequestKey"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：同一原CRM事务内保存本表维护与历史；不接触资金、订单或认证表。
     * @param input 可信归属及完整维护字段，例如accountCodeSCHOOL-CNY/currencyCNY/history数组
     * @param create true创建版本0，false按expectedVersion0递增为1
     * @return 真实返回示例：插入或CAS影响1行；旧版本为0。
     * 异常或副作用示例：唯一约束或SQL错误整体回滚，不写另一份现金账。
     */
    @Override
    public int saveMaintenance(CommonParam input, boolean create) {
        requireCrmTransaction();
        if (create) {
            return jdbc.update("INSERT INTO CrmCashAccount(id,tenantId,businessOrgId,createdByUserId,"
                    + "updatedByUserId,lastOperateUserId,accountCode,accountName,accountKind,currency,"
                    + "currencyScale,businessState,versionNo,creationRequestKey,creationHash,changeHistoryJson) "
                    + "VALUES(?,?,?,?,?,?,?,?,'CASH',?,?,?,0,?,?,?)", input.getParam("id"),
                    input.getParam("tenantId"), input.getParam("businessOrgId"), input.getParam("actorUserId"),
                    input.getParam("actorUserId"), input.getParam("actorUserId"), input.getParam("accountCode"),
                    input.getParam("accountName"), input.getParam("currency"), input.getParam("currencyScale"),
                    input.getParam("businessState"), input.getParam("creationRequestKey"),
                    input.getParam("creationHash"), input.getParam("changeHistoryJson"));
        }
        return jdbc.update("UPDATE CrmCashAccount SET accountName=?,businessState=?,changeHistoryJson=?,"
                + "updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP,versionNo=versionNo+1 "
                + "WHERE tenantId=? AND businessOrgId=? AND id=? AND versionNo=? AND status=1",
                input.getParam("accountName"), input.getParam("businessState"), input.getParam("changeHistoryJson"),
                input.getParam("actorUserId"), input.getParam("actorUserId"), input.getParam("tenantId"),
                input.getParam("businessOrgId"), input.getParam("id"), input.getParam("expectedVersion"));
    }
}
