/** 库存单完整冲正业务契约；2026-10-03，Codex。 */
package com.sp.selplat.crm.capability.stockreversal.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 原批次完整反向登记，申请与原单审批独立。 */
public interface CrmStockReversalService {
    /**
     * 方法作用：读取实际完整冲正数量和账户效果。
     *
     * @param input org901/id1000000
     * @return 原批次数量3、库存变化-3EA及实际申请；无记账副作用，越组织拒绝。
     */
    CommonResult preview(CommonParam input);

    /**
     * 方法作用：提交原库存单的完整冲正申请。
     *
     * @param input org901/id1000000/originalBatch1200000/expected3/reasonText/key
     * @return SUBMITTED/version0；不改原审批、进度或库存，失败整笔回滚。
     */
    CommonResult request(CommonParam input);

    /**
     * 方法作用：由另一真实用户审核冻结的完整冲正申请。
     *
     * @param input
     *     org901/id1000000/originalBatch1200000/reversalRequest1700000/expected3/expectedReversal0/key
     * @return APPROVED/version1；自审或原始事实变更拒绝，库存无副作用。
     */
    CommonResult approve(CommonParam input);

    /**
     * 方法作用：按独立已审核申请明确执行整批反向记账。
     *
     * @param input 与审核引用一致、expectedReversal1/actionREVERSE/key
     * @return 新反向批次和所有新明细、原状态REVERSED/version4；任何依赖/余额/权限/审计失败全部回滚。
     */
    CommonResult execute(CommonParam input);
}
