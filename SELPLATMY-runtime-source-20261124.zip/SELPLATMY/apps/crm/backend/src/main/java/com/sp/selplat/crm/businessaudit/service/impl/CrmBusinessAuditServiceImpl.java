/**
 * CrmBusinessAuditServiceImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
/* 2026-10-28：补原业务审计只读页面合同，复用原范围和动作，不新增写入。 */
package com.sp.selplat.crm.businessaudit.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.businessaudit.dao.CrmBusinessAuditDao;
import com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** 本表直接复用公共CRUD/号段，HTTP只开放明确范围和版本命令；不自建权限系统。 */
@Service
public class CrmBusinessAuditServiceImpl extends BaseServiceImpl<CrmBusinessAuditDao>
        implements CrmBusinessAuditService {
    // 真实Session和显式合成许可统一由本域准入检查，生产缺公共resolver时拒绝。
    private final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 装配真实身份；参数access例如CrmAccessServiceImpl；构造不查询SQL或授权。
     *
     * @param access 实际统一Session范围入口CrmAccessService；例如由服务核验组织901，不授予许可。
     */
    public CrmBusinessAuditServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

  /**
   * 分页本组织记录；参数例如org901/page1；返回公共分页；无真实read许可拒绝。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   * @return 公共真实分页，例如records包含本组织客户；不会退化为全库
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    var scope =
        access.requirePartnerScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.audit.read");
    var query =
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page(input, scope, null);
    // 对象筛选沿本表SQL COUNT与分页，不接受客户端租户或其他查询字段覆盖范围。
    if (input.getParam("resourceId") != null) {
      query.putParam(
          "resourceId",
          com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(
              input.getParam("resourceId")));
    }
    return super.getStore(query);
  }

  /**
   * 方法作用：复用原审计读取资格和本表分页，聚合公开SelUI只读定义及精确编号。
   *
   * @param input 原组织与页码候选，例如organizationCandidateId901/pageNo2/resourceId503/langzh-CN
   * @return 真实示例：data.readOnlytrue，data.grid.pagination.totalCount26及当前6条审计。
   *     异常或副作用示例：缺原crm.audit.read或跨组织拒绝，原资料和审计零写入。
   */
  @Override
  @OperationLog
  public CommonResult workspace(CommonPageParam input) {
    return com.sp.selplat.crm.common.util.businessaudit.CrmBusinessAuditWorkspaceSupport.build(
        getStore(input), input.getParam("lang"));
  }

    /**
     * 本组织详情；参数例如org901/id200000；返回公共data；不存在或越组织同样拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.audit.read");
        var row =
                getDao().getById(
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "CRM_RECORD_NOT_FOUND");
        }
        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(row);
    }

    /**
     * 未开放通用批量读取；参数例如空items；无成功返回；拒绝避免绕过组织许可。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 服务端审计人；无参数；返回真实账号例如9211；失效身份拒绝，不使用默认1。
     *
     * @return 真实当前操作员，例如9211；失效身份抛错
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 服务端租户；无参数；返回真实租户例如92；不使用客户端或默认租户。
     *
     * @return 真实当前租户，例如92；不使用默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 没有默认管理员；无参数；返回false；不增加任何权限。 业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     *
     * @return false；本域不隐式赋予管理员
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写入口关闭；参数例如id200000；无成功返回；维护只能经过具名保存事务。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_WRITE_DISABLED");
    }


    /**
     * 方法作用：沿订单范围读取最近具名驳回，并补对应原提交的真实账号与时间。
     * @param input 真实示例：organizationCandidateId901/id600000；仅此订单resourceId
     * @return 真实示例：reasonText核对数量/reviewerUserId9212/rejectedAt及版本1到2，未驳回为空Map。
     * 异常或副作用示例：缺crm.order.read拒绝；固定动作与排序，不提供其他审计或客户端筛选覆盖。
     */
    @Override
    @OperationLog
    public java.util.Map<String, Object> latestOrderRejection(CommonParam input) {
        var scope = access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read");
        var conditions = new java.util.LinkedHashMap<String, Object>();
        conditions.put("tenantId", scope.get("tenantId"));
        conditions.put("businessOrgId", scope.get("businessOrgId"));
        conditions.put("resourceId", com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(input.getParam("id")));
        conditions.put("status", 1);
        conditions.put("action", "ORDER_REJECT");
        var rows = getDao().getPageList(conditions, "newVersion desc id desc", 1, 1).getRecords();
        if (rows.isEmpty()) {
            return java.util.Map.of();
        }
        var row = rows.getFirst();
        var result = new java.util.LinkedHashMap<String, Object>();
        result.put("reasonText", row.get("reasonText"));
        result.put("reviewerUserId", String.valueOf(row.get("actorUserId")));
        result.put("rejectedAt", row.get("createdAt"));
        result.put("previousVersion", String.valueOf(row.get("previousVersion")));
        result.put("newVersion", String.valueOf(row.get("newVersion")));
        conditions.put("action", "ORDER_SUBMIT");
        conditions.put("newVersion", row.get("previousVersion"));
        var submitted = getDao().getPageList(conditions, "id desc", 1, 1).getRecords();
        if (!submitted.isEmpty()) {
            result.put("submittedByUserId", String.valueOf(submitted.getFirst().get("actorUserId")));
            result.put("submittedAt", submitted.getFirst().get("createdAt"));
        }
        access.requireOrderScope(input.getParam("organizationCandidateId"), "crm.order.read");
        return result;
    }


    /**
     * 方法作用：原资金读取权限下只查本单具名驳回，附同版本的原提交事实。
     * @param input 真实示例：organizationCandidateId901/id1000000，单据已由拥有方确认归属
     * @return 真实示例：reasonText核对金额/reviewerUserId9212/previousVersion1/newVersion2及原提交9211；无记录为空Map。
     * 异常或副作用示例：缺原资金read或跨组织拒绝，不查询其他动作或改写审计。
     */
    @Override
    @OperationLog
    public java.util.Map<String, Object> latestFundsRejection(CommonParam input) {
        var scope = access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
        var conditions = new java.util.LinkedHashMap<String, Object>();
        conditions.put("tenantId", scope.get("tenantId"));
        conditions.put("businessOrgId", scope.get("businessOrgId"));
        conditions.put("resourceId", com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(input.getParam("id")));
        conditions.put("status", 1);
        conditions.put("action", "FUNDS_DOCUMENT_REJECT");
        var rows = getDao().getPageList(conditions, "newVersion desc id desc", 1, 1).getRecords();
        if (rows.isEmpty()) {
            return java.util.Map.of();
        }
        // 操作者和时间只取原审计；不从当前登录人或单据更新时间推造。
        var row = rows.getFirst();
        var result = new java.util.LinkedHashMap<String, Object>();
        result.put("reasonText", row.get("reasonText"));
        result.put("reviewerUserId", String.valueOf(row.get("actorUserId")));
        result.put("rejectedAt", row.get("createdAt"));
        result.put("previousVersion", String.valueOf(row.get("previousVersion")));
        result.put("newVersion", String.valueOf(row.get("newVersion")));
        conditions.put("action", "FUNDS_DOCUMENT_SUBMIT");
        conditions.put("newVersion", row.get("previousVersion"));
        var submitted = getDao().getPageList(conditions, "id desc", 1, 1).getRecords();
        if (!submitted.isEmpty()) {
            result.put("submittedByUserId", String.valueOf(submitted.getFirst().get("actorUserId")));
            result.put("submittedAt", submitted.getFirst().get("createdAt"));
        }
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
        return result;
    }

    /**
     * 追加成功业务审计；参数例如request200000/资源200000/version0；返回审计id；失败与主体/请求同回滚。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Long append(CommonParam input) {
        var scope =
                access.requireBusinessScope(
                        input.getParam("organizationCandidateId"),
                        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.commandAction(
                                input.getParam("action")));
        CommonParam row = new CommonParam();
        for (String field :
                List.of(
                        "commandRequestId",
                        "action",
                        "resourceId",
                        "previousVersion",
                        "newVersion")) {
            row.putParam(field, input.getParam(field));
        }
        for (String field : List.of("postingRequestId", "batchId")) {
            if (input.getParam(field) != null) {
                row.putParam(field, input.getParam(field));
            }
        }
        // 具名归档、恢复或订单驳回原因与原请求同事务保留，不为其他动作补造原因。
        if (java.util.Set.of("PARTNER_ARCHIVE", "PARTNER_RESTORE", "ORDER_REJECT", "FUNDS_DOCUMENT_REJECT").contains(input.getParam("action"))) {
            row.putParam("reasonText", com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                    .text(input.getParam("reasonText"), 200, true));
        }
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        Long id = getSequence().get("id");
        row.putParam("id", id);
        row.putParam("actorUserId", scope.get("actorUserId"));
        row.putParam("decisionId", scope.get("decisionId"));
        row.putParam("synthetic", scope.get("synthetic"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(getDao().insert(row));
        return id;
    }
}
