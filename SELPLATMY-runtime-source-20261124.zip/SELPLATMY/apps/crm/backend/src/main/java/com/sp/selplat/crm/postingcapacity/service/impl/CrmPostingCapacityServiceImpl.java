/** 一期销售退货退款原明细容量实现；2026-10-04，Codex；真实范围与CRM事务。 */
/* 修改记录：2026-10-09，统一本表通用读取固定拒绝；缺动作沿用原拒绝契约，不改变容量业务或权限。 */
package com.sp.selplat.crm.postingcapacity.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.document.service.CrmDocumentService;
import com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService;
import com.sp.selplat.crm.postingcapacity.dao.CrmPostingCapacityDao;
import com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService;
import com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Set;

/** 本表只存不可变原上限与CAS已用量；跨表事实由owning服务提供，缺历史拒绝。 */
@Service
public class CrmPostingCapacityServiceImpl extends BaseServiceImpl<CrmPostingCapacityDao>
        implements CrmPostingCapacityService {
    // 准入来自真实Session与原组织动作，不创建退货角色或默认操作者。
    private final CrmAccessService access;
    // 原流水owning服务只读真实明细，不能从客户端推导额度。
    private final CrmPostingDetailService details;
    // 原批次owning服务以不可变POST/REVERSE历史确定实际有效性。
    private final CrmPostingBatchService batches;
    // 原单据owning服务提供实际类型与状态，不修改原销售出库或收款。
    private final CrmDocumentService documents;
    // 新结构只在显式退货隔离环境启用；生产默认不开放。
    private final Boolean enabled;

    /**
     * 绑定本域owning事实与显式门禁，不授予权限或创建流水。
     *
     * @param access 真实身份范围服务，例如tenant92/org901/actor9211
     * @param details 原流水本表服务，例如锁detail1300000
     * @param batches 批次本表服务，例如读POST1200000及真实冲正历史
     * @param documents 单据本表服务，例如读取POSTED销售出库1000000
     * @param enabled 显式crmSalesReturnIsolatedEnabled，例如专用合成环境true
     */
    @Autowired
    public CrmPostingCapacityServiceImpl(
            CrmAccessService access,
            CrmPostingDetailService details,
            CrmPostingBatchService batches,
            CrmDocumentService documents,
            @Qualifier("crmSalesReturnIsolatedEnabled") Boolean enabled) {
        this.access = access;
        this.details = details;
        this.batches = batches;
        this.documents = documents;
        this.enabled = enabled;
    }

    /**
     * 新结构与动作双重检查，旧profile不能访问不存在的容量表。
     *
     * @param input org901及实际容量候选
     * @param action 真实stock.post或funds.post
     * @return 真实scope，例如{tenantId:92,businessOrgId:901,actorUserId:9211}；不写库
     */
    private Map<String, Object> scope(CommonParam input, String action) {
        // 仅正向库存或资金过账可占用容量 -> 不把POST权限复用为整批冲正。
        if (!Boolean.TRUE.equals(enabled)) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
        // 缺动作不可取得任何组织范围，也不能退化成空指针异常。
        if (action == null || !Set.of(
                        "crm.stock.post",
                        "crm.funds.post",
                        "crm.stock.read",
                        "crm.funds.read",
                        "crm.funds.reverse",
                        "crm.stock.reverse")
                .contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        return access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    }

    /**
     * 只复制候选组织和一项服务器关联键，可信身份仍由owning服务重新回查。
     *
     * @param input org901
     * @param key 固定id或documentId字段
     * @param value 实际关联id，例如1300000
     * @return 新公共参数，例如{organizationCandidateId:901,id:1300000}
     */
    private CommonParam relation(CommonParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 锁原真实效果并核其实际单据、来源及无REVERSE的POST；不改原行。
     *
     * @param input org901/originalDetailId1300000/source600001/capacityKind ISSUE_RETURN
     * @param action 实际stock.post或funds.post
     * @return 真实原明细例如quantityDelta=-3；类型、来源、状态或历史不符拒绝
     */
    private Map<String, Object> original(CommonParam input, String action) {
        var original =
                details.lockScoped(
                        relation(
                                input,
                                "id",
                                CrmPartnerValueSupport.positive(
                                        input.getParam("originalDetailId"))),
                        action);
        if (!"POST".equals(original.get("action"))
                || !original.get("sourceOrderLineId")
                        .toString()
                        .equals(input.getParam("sourceOrderLineId").toString())) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
        }
        var parent =
                documents.lockScoped(relation(input, "id", original.get("documentId")), action);
        var history =
                batches.findForDocument(
                        relation(input, "documentId", original.get("documentId")), action);
        boolean active =
                "POSTED".equals(parent.get("documentState"))
                        && history.stream().filter(b -> "POST".equals(b.get("action"))).count() == 1
                        && history.stream()
                                .anyMatch(
                                        b ->
                                                original.get("batchId").equals(b.get("id"))
                                                        && "POST".equals(b.get("action")))
                        && history.stream().noneMatch(b -> "REVERSE".equals(b.get("action")));
        if (!active) {
            throw CrmPartnerValueSupport.failure("POSTING_PARENT_INACTIVE");
        }
        String kind = String.valueOf(input.getParam("capacityKind"));
        boolean valid =
                switch (kind) {
                    case "ISSUE_RETURN" ->
                            "STOCK_ISSUE".equals(parent.get("documentKind"))
                                    && "SALE".equals(parent.get("reason"))
                                    && "STOCK".equals(original.get("effectKind"))
                                    && ((Number) original.get("quantityDelta")).longValue() < 0;
                    case "RECEIPT_REFUND" ->
                            "FUNDS_RECEIPT".equals(parent.get("documentKind"))
                                    && "SALE".equals(parent.get("reason"))
                                    && "CASH".equals(original.get("effectKind"))
                                    && new BigDecimal(original.get("amountDeltaMinor").toString())
                                                    .signum()
                                            > 0;
                    case "RETURN_REFUND" ->
                            "STOCK_RECEIPT".equals(parent.get("documentKind"))
                                    && "SALES_RETURN".equals(parent.get("reason"))
                                    && "STOCK".equals(original.get("effectKind"))
                                    && ((Number) original.get("quantityDelta")).longValue() > 0
                                    && original.get("refundCapacityMinor") != null;
                    default -> false;
                };
        if (!valid) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
        }
        return original;
    }

    /**
     * 只由真实原明细推导本容量上限并验证原上限没有被篡改。
     *
     * @param row 实际容量，例如ISSUE_RETURN/3EA或RETURN_REFUND/0MINOR
     * @param original 实际不可变原明细，例如quantityDelta=-3
     *     副作用示例：无写入；上限与原效果不一致抛CRM_CAPACITY_SOURCE_MISMATCH，不信余额或客户端。
     */
    private void verifyLimit(Map<String, Object> row, Map<String, Object> original) {
        boolean quantity = "ISSUE_RETURN".equals(row.get("capacityKind"));
        var actual =
                quantity
                        ? BigDecimal.valueOf(
                                Math.negateExact(
                                        ((Number) original.get("quantityDelta")).longValue()))
                        : new BigDecimal(
                                original.get(
                                                "RETURN_REFUND".equals(row.get("capacityKind"))
                                                        ? "refundCapacityMinor"
                                                        : "amountDeltaMinor")
                                        .toString());
        if (actual.compareTo(
                        new BigDecimal(
                                row.get(quantity ? "capacityQuantity" : "capacityMinor")
                                        .toString()))
                != 0) {
            throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
        }
    }

    /**
     * 真实原POST完成后建立独立容量；原上限取不可变效果，不由请求传入。
     *
     * @param input org901/originalDetailId1300000/source600001/kind ISSUE_RETURN
     * @param action 真实stock.post或funds.post，null或未登记值抛CRM_ACTION_FORBIDDEN
     * @return 实际容量，例如{capacityQuantity:3,usedQuantity:0,versionNo:0}；已有行不重置
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> registerOriginal(CommonParam input, String action) {
        // 未声明动作与未知动作均拒绝；ImmutableSet不能对null执行contains。
        if (action == null || !Set.of("crm.stock.post", "crm.funds.post").contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var scope = scope(input, action);
        var original = original(input, action);
        var query = new CommonParam();
        query.putParam("tenantId", scope.get("tenantId"));
        query.putParam("businessOrgId", scope.get("businessOrgId"));
        query.putParam("originalDetailId", original.get("id"));
        query.putParam("capacityKind", input.getParam("capacityKind"));
        var row = getDao().lockForOriginal(query);
        if (row == null) {
            var entity = CrmPartnerValueSupport.entity(query, scope);
            entity.putParam("id", getSequence().get("id"));
            if ("ISSUE_RETURN".equals(input.getParam("capacityKind"))) {
                entity.putParam(
                        "capacityQuantity",
                        Math.negateExact(((Number) original.get("quantityDelta")).longValue()));
                entity.putParam("usedQuantity", 0L);
            } else {
                entity.putParam(
                        "capacityMinor",
                        original.get(
                                "RETURN_REFUND".equals(input.getParam("capacityKind"))
                                        ? "refundCapacityMinor"
                                        : "amountDeltaMinor"));
                entity.putParam("usedMinor", BigDecimal.ZERO);
            }
            // 本事务真实父POST首次生成容量 -> 不懒迁旧历史，也不重置已经占用的容量。
            CrmPartnerValueSupport.changed(getDao().insert(entity));
            row = getDao().lockForOriginal(query);
        }
        verifyLimit(row, original);
        return row;
    }

    /**
     * 锁实际已存在且有效的原明细容量，缺行拒绝而不是假定未占用。
     *
     * @param input org901/originalDetailId1300000/source600001/kind ISSUE_RETURN
     * @param action 真实stock.post或funds.post，null或未登记值抛CRM_ACTION_FORBIDDEN
     * @return 容量Map例如{capacityQuantity:3,usedQuantity:1,versionNo:1}；父已冲正或无容量拒绝
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockAllocation(CommonParam input, String action) {
        var scope = scope(input, action);
        var original = original(input, action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("originalDetailId", original.get("id"));
        p.putParam("capacityKind", input.getParam("capacityKind"));
        var row = getDao().lockForOriginal(p);
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_CAPACITY_HISTORY_MISSING");
        }
        verifyLimit(row, original);
        return row;
    }

    /**
     * 聚合后只按原容量版本占用一次，权限与真实原上限重新核验。
     *
     * @param input org901/original1300000/source600001/kind
     *     ISSUE_RETURN/id1900000/version0/quantity1
     * @param action 真实stock.post或funds.post，null抛CRM_ACTION_FORBIDDEN；副作用示例：usedQuantity0→1/version1；旧版本、跨来源或超额整笔回滚。
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public void consume(CommonParam input, String action) {
        // 未声明动作与未知动作均拒绝；ImmutableSet不能对null执行contains。
        if (action == null || !Set.of("crm.stock.post", "crm.funds.post").contains(action)) {
            throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
        }
        var scope = scope(input, action);
        var actual = lockAllocation(input, action);
        if (!actual.get("id").toString().equals(input.getParam("id").toString())) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var p = CrmPartnerValueSupport.detail(input, scope);
        p.putParam("versionNo", CrmPartnerValueSupport.version(input.getParam("versionNo")));
        p.putParam("actorUserId", scope.get("actorUserId"));
        if ("ISSUE_RETURN".equals(actual.get("capacityKind"))) {
            long quantity = CrmStockValueSupport.quantity(input.getParam("quantity"));
            if (quantity
                    > ((Number) actual.get("capacityQuantity")).longValue()
                            - ((Number) actual.get("usedQuantity")).longValue()) {
                throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
            }
            p.putParam("quantityDelta", quantity);
        } else {
            var amount = CrmFundsValueSupport.minor(input.getParam("amountMinor"));
            var remaining =
                    new BigDecimal(actual.get("capacityMinor").toString())
                            .subtract(new BigDecimal(actual.get("usedMinor").toString()));
            if (amount.compareTo(remaining) > 0) {
                throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
            }
            p.putParam("minorDelta", amount);
        }
        // DAO的上限、非负与版本条件同一语句 -> 第二分摊失败时首分摊仍由外层事务回滚。
        CrmPartnerValueSupport.changed(getDao().adjust(p));
    }

    /**
     * 本表通用读取固定关闭；构造原错误交给调用层抛出，不访问容量数据。
     *
     * @return 原CRM_GENERIC_ACCESS_DISABLED异常，例如控制器抛出后HTTP400
     *     异常或副作用示例：只返回安全异常对象，不读写数据库或授予许可。
     */
    @Override
    public com.sp.selplat.common.exception.CommonBusinessException genericReadRejection() {
        return CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 容量没有公共分页入口，避免绕开原业务读取权限。
     *
     * @param input 例如org901/page1
     * @return 无成功结果；固定CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonPageResult getStore(CommonPageParam input) {
        throw genericReadRejection();
    }

    /**
     * 容量没有公共单条读取入口。
     *
     * @param input 例如org901/id1900000
     * @return 无成功结果；固定CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getById(CommonParam input) {
        throw genericReadRejection();
    }

    /**
     * 容量没有公共批读入口。
     *
     * @param input 例如ids1900000
     * @return 无成功结果；固定CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw genericReadRejection();
    }

    /**
     * 通用写关闭，不能由客户端设置或清空已用容量。
     *
     * @param input 例如id1900000/usedQuantity0 副作用示例：固定CRM_GENERIC_WRITE_DISABLED，不修改数据库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 当前真实操作者只从统一身份读取。
     *
     * @return 合成Session例如9211，无Session拒绝；不提供默认用户
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 当前真实租户只从统一身份读取。
     *
     * @return 合成Session例如92，无Session拒绝；不提供默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 本域容量服务不存在隐式管理员。 实际调用示例：当前操作人9211得到false，不创建管理员旁路。
     *
     * @return 固定false，构造或占用容量不扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 完整退款执行持锁核账后CAS释放金额占用，数量容量不可经资金许可释放。
     *
     * @param input
     *     例如org901/id100000/version3/originalDetail1300001/source600000/kindRECEIPT_REFUND/amountMinor2；副作用示例：usedMinor2→0，上限保留，旧版本或不足全事务回滚。
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public void releaseRefund(CommonParam input) {
        var scope = scope(input, "crm.funds.reverse");
        var actual = lockAllocation(input, "crm.funds.reverse");
        if (!Set.of("RECEIPT_REFUND", "RETURN_REFUND").contains(actual.get("capacityKind"))
                || !actual.get("id").toString().equals(input.getParam("id").toString())) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var amount = CrmFundsValueSupport.minor(input.getParam("amountMinor"));
        if (amount.compareTo(new BigDecimal(actual.get("usedMinor").toString())) > 0) {
            throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
        }
        var p = CrmPartnerValueSupport.detail(input, scope);
        p.putParam("versionNo", CrmPartnerValueSupport.version(input.getParam("versionNo")));
        p.putParam("minorDelta", amount.negate());
        p.putParam("actorUserId", scope.get("actorUserId"));
        CrmPartnerValueSupport.changed(getDao().adjust(p));
    }

    /**
     * 只在stock.reverse且完整有效分配已核账后释放原ISSUE容量；例如used3→0，上限3保留。
     *
     * @param input
     *     org901/id100000/version3/originalDetail1300000/source600000/kindISSUE_RETURN/quantity3；副作用示例：旧版本、错容量或used不足整笔回滚。
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public void releaseReturn(CommonParam input) {
        var scope = scope(input, "crm.stock.reverse");
        var actual = lockAllocation(input, "crm.stock.reverse");
        long quantity = CrmStockValueSupport.quantity(input.getParam("quantity"));
        if (!"ISSUE_RETURN".equals(actual.get("capacityKind"))
                || !actual.get("id").toString().equals(input.getParam("id").toString())
                || quantity > ((Number) actual.get("usedQuantity")).longValue()) {
            throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
        }
        var p = CrmPartnerValueSupport.detail(input, scope);
        p.putParam("versionNo", input.getParam("versionNo"));
        p.putParam("quantityDelta", -quantity);
        p.putParam("actorUserId", scope.get("actorUserId"));
        CrmPartnerValueSupport.changed(getDao().adjust(p));
    }
}
