/** CrmOrder本表参数化DAO；2026-10-03，Codex。 */
package com.sp.selplat.crm.order.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/** 只执行本表固定SQL，与公共DAO共享同一CRM池和事务。 */
@Repository
public class CrmOrderDaoImpl extends CrmBaseDao implements CrmOrderDao {
    /**
     * 保留默认sortnum主排序，追加本组织唯一id稳定主订单分页，不改变筛选和COUNT。
     *
     * @param conditions 原服务范围及精确订单条件，例如tenantId=92/businessOrgId=901/status=1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 真实公共页，例如totalCount=2/pageNo=2/records含第二笔实际订单
     *     异常或副作用示例：查询异常沿用公共合同；不改变订单状态、金额、行或号段。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    private final JdbcTemplate jdbc;

    /**
     * 装配本表CRM模板；示例crmJdbcTemplate；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmOrderDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 锁本表范围行；scope92/901/id600000；返回真实行或null，要求CRM事务。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmOrder WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * DRAFT整头版本CAS；id600000/expected0/规范精确金额；返回0或1，不覆盖提交审核。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 实际DRAFT头CAS影响行数0/1；0不覆盖其他版本
     */
    @Override
    public int updateDraft(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmOrder SET orderKind=?,partnerId=?,currency=?,currencyScale=?,"
                        + "pricingPolicyVersion=?,refundPolicyVersion=?,subtotalMinor=?,"
                        + "discountMinor=?,feeMinor=?,totalMinor=?,refundableGoodsMinor=?,"
                        + "refundableFeeMinor=?,updatedByUserId=?,lastOperateUserId=?,"
                        + "updatedAt=CURRENT_TIMESTAMP,versionNo=versionNo+1 WHERE tenantId=? AND "
                        + "businessOrgId=? AND id=? AND orderState='DRAFT' AND status=1 AND "
                        + "versionNo=?",
                input.getParam("orderKind"),
                input.getParam("partnerId"),
                input.getParam("currency"),
                input.getParam("currencyScale"),
                input.getParam("pricingPolicyVersion"),
                input.getParam("refundPolicyVersion"),
                input.getParam("subtotalMinor"),
                input.getParam("discountMinor"),
                input.getParam("feeMinor"),
                input.getParam("totalMinor"),
                input.getParam("refundableGoodsMinor"),
                input.getParam("refundableFeeMinor"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("expectedVersion"));
    }

    /**
     * 固定提交/审核版本CAS；id600000/expected1；返回0/1，自审及快照在服务层核对。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 实际固定SQL影响行数0/1；0由服务拒绝，不伪造成功
     */
    @Override
    public int transition(CommonParam input) {
        requireCrmTransaction();
        // 撤回草稿清空当前提交标记以符合原状态约束，提交人/时间保留在原提交及撤回审计。
        return jdbc.update(
                "UPDATE CrmOrder SET orderState=?,versionNo=versionNo+1,"
                        + "submittedByUserId=CASE WHEN ?='DRAFT' THEN NULL WHEN ?='SUBMITTED' THEN ? ELSE submittedByUserId "
                        + "END,submittedAt=CASE WHEN ?='DRAFT' THEN NULL WHEN ?='SUBMITTED' THEN CURRENT_TIMESTAMP ELSE "
                        + "submittedAt END,approvedByUserId=?,approvedAt=CASE WHEN ?='APPROVED' THEN "
                        + "CURRENT_TIMESTAMP ELSE NULL END,snapshotHash=?,frozenSnapshot=?,"
                        + "updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP WHERE "
                        + "tenantId=? AND businessOrgId=? AND id=? AND versionNo=? AND orderState=? "
                        + "AND status=1",
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("approvedByUserId"),
                input.getParam("nextState"),
                input.getParam("snapshotHash"),
                input.getParam("frozenSnapshot"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("expectedVersion"),
                input.getParam("previousState"));
    }
}
