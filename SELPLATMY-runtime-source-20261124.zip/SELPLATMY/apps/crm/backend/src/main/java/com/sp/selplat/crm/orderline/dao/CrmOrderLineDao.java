/** CrmOrderLine：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.orderline.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.List;
import java.util.Map;

/** 本表强类型DAO，只固定参数化本表SQL。 */
public interface CrmOrderLineDao extends BaseDao {
    /**
     * 锁同订单全部行，按ID升序；org901/order600000；返回真实集合。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：锁同订单全部行，按ID升序；org901/order600000；返回真实集合。
     * @return 真实集合
     */
    List<Map<String, Object>> lockOrderLines(CommonParam input);

    /**
     * 删除已从DRAFT全量输入移除的行；scope/订单/id；返回0/1，未来下游FK失败整笔回滚。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：删除已从DRAFT全量输入移除的行；scope/订单/id；返回0/1，未来下游FK失败整笔回滚。
     * @return 0/1，未来下游FK失败整笔回滚
     */
    int deleteLine(CommonParam input);

  /**
   * 方法作用：只读本表当前页所需订单商品快照与数量，不跨表查询或取得写锁。
   *
   * @param tenant 服务端真实租户，例如9
   * @param organization 服务端真实经营组织，例如901
   * @param ids 已校验当前页主键集合，例如[600000]，最多100个
   * @return 真实示例：本表安全字段集合；空主键返回空集合，不退化为全表
   * @throws IllegalArgumentException 主键超过100项时拒绝，无写入副作用
   */
  java.util.List<java.util.Map<String, Object>> orderListItems(
      long tenant, long organization, java.util.List<Long> ids);
}
