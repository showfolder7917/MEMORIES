/**
 * CrmPostingPreflightSupport.java：无状态单据预检，不授予写权限或模拟数据库。 修改记录：2026-10-03，Codex
 * 按委托落实保守状态、重放、冲销和精确对账规则。
 */
package com.sp.selplat.crm.common.util.posting;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.exception.CommonSystemException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Currency;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 仅计算给定快照的预检结果；可信事实、权限、锁和原子持久化必须由实际业务链补充。 */
public final class CrmPostingPreflightSupport {
    // 订单审核与库存/资金单据分开，禁止订单审批直接扣库存或收款。
    private static final Set<String> ORDER_KINDS =
            Set.of("SALES_ORDER", "PURCHASE_ORDER", "SALES_RETURN");
    // 流水只能来自可追溯业务单据；不能用产品库存字段的直接覆盖充当过账。
    private static final Set<String> ENTRY_KINDS =
            Set.of("STOCK_ISSUE", "STOCK_RECEIPT", "FUNDS_RECEIPT", "FUNDS_PAYMENT");
    // 未知或历史树节点编号不自动转成当前业务状态。
    private static final Set<String> STATES =
            Set.of("DRAFT", "SUBMITTED", "APPROVED", "REJECTED", "CANCELLED", "POSTED", "REVERSED");
    // 摘要仅包含实际动作内容及期望版本；当前库存、状态和已存请求事实不属于重放请求内容。
    private static final Set<String> CONTENT_FIELDS =
            Set.of(
                    "kind",
                    "action",
                    "sourceDocumentId",
                    "sourceDocumentKind",
                    "origin",
                    "warehouseId",
                    "productId",
                    "quantity",
                    "quantityUnit",
                    "amount",
                    "currency",
                    "amountUnit",
                    "originalEntryId",
                    "expectedVersion");

    /** 静态预检无需实例；构造不读取会话、不建立数据库或业务缓存。 */
    private CrmPostingPreflightSupport() {
        // 静态工具不创建实例状态。
    }

    /**
     * 检查显式快照和动作，返回不可执行的转换/差额预览。
     *
     * @param input 服务传入的预览字段，例如 {kind:SALES_ORDER,state:DRAFT,action:SUBMIT}
     * @return 例如
     *     {kind:SALES_ORDER,from:DRAFT,to:SUBMITTED,replay:false,writeEnabled:false,stockDelta:0,fundsDelta:0}
     * @throws CommonBusinessException 未知状态、跨阶段、重放冲突、未授权来源或非法金额返回稳定业务码；不写库
     */
    public static Map<String, Object> preview(Map<String, Object> input) {
        // 每次只创建本次结果，不保留客户端快照为后续请求的权威状态。
        if (input == null) {
            throw failure("INVALID_POSTING_PREVIEW", "预检参数不能为空。");
        }
        String kind = required(input, "kind");
        String state = required(input, "state");
        String action = required(input, "action");
        if ((!ORDER_KINDS.contains(kind) && !ENTRY_KINDS.contains(kind))
                || !STATES.contains(state)) {
            throw failure("UNKNOWN_POSTING_STATE", "单据类型或状态未识别。");
        }
        // 订单不能进入独立流水单据的过账状态，避免无效模型也被重放分支放行。
        if (ORDER_KINDS.contains(kind) && Set.of("POSTED", "REVERSED").contains(state)) {
            throw failure("INVALID_POSTING_TRANSITION", "订单审核状态不能替代流水状态。");
        }
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("kind", kind);
        result.put("from", state);
        result.put("writeEnabled", false);
        result.put("factsVerified", false);
        result.put("stockDelta", "0");
        result.put("fundsDelta", "0");
        result.put("replay", false);
        // 只有流水动作涉及重放预检；查询结果始终不是数据库幂等成功证明。
        if (ENTRY_KINDS.contains(kind) && Set.of("POST", "REVERSE").contains(action)) {
            String version = required(input, "expectedVersion");
            if (!version.matches("[0-9]{1,18}")) {
                throw failure("INVALID_POSTING_VERSION", "必须指定非负整数期望版本。");
            }
            result.put("payloadHash", payloadHash(input));
            if (replay(input)) {
                result.put("to", state);
                result.put("replay", true);
                return result;
            }
            // 新请求必须对比提交后的当前版本；实际业务仍须在持锁后的真实事务内重新取得此值。
            String currentVersion = required(input, "currentVersion");
            if (!currentVersion.matches("[0-9]{1,18}")) {
                throw failure("INVALID_POSTING_VERSION", "当前版本未识别。");
            }
            if (Long.parseLong(version) != Long.parseLong(currentVersion)) {
                throw failure("STALE_POSTING_VERSION", "单据已经变化，不能使用旧版本过账。");
            }
        }
        // 明确列出允许边，未命中即拒绝；取消不覆盖已过账或已冲销记录。
        String target =
                switch (action) {
                    case "SUBMIT" -> state.equals("DRAFT") ? "SUBMITTED" : null;
                    case "APPROVE" -> state.equals("SUBMITTED") ? "APPROVED" : null;
                    case "REJECT" -> state.equals("SUBMITTED") ? "REJECTED" : null;
                    case "REVISE" -> state.equals("REJECTED") ? "DRAFT" : null;
                    case "CANCEL" ->
                            Set.of("DRAFT", "SUBMITTED", "APPROVED", "REJECTED").contains(state)
                                    ? "CANCELLED"
                                    : null;
                    case "POST" ->
                            ENTRY_KINDS.contains(kind) && state.equals("APPROVED")
                                    ? "POSTED"
                                    : null;
                    case "REVERSE" ->
                            ENTRY_KINDS.contains(kind) && state.equals("POSTED")
                                    ? "REVERSED"
                                    : null;
                    default -> null;
                };
        if (target == null) {
            throw failure("INVALID_POSTING_TRANSITION", "该状态不允许此动作。");
        }
        result.put("to", target);
        if (action.equals("CANCEL")
                && state.equals("APPROVED")
                && !required(input, "postedEntryCount").equals("0")) {
            throw failure("POSTED_DOCUMENT_CANCEL_DISABLED", "已有流水的单据不能直接取消，须通过冲销处理。");
        }
        // 草稿/审核转换没有库存或金额副作用；仅在合法流水动作检查其来源和值。
        if (Set.of("POST", "REVERSE").contains(action)) {
            inspectEntry(input, kind, action.equals("REVERSE"), result);
        }
        return result;
    }

    /**
     * 精确核对期初＋流入－流出与期末，不猜币种、方向或舍入。
     *
     * @param opening 显式同单位期初，例如 "10.00"
     * @param incoming 已确认方向的非负流入，例如 "2.50"
     * @param outgoing 已确认方向的非负流出，例如 "1.00"
     * @param closing 同截点/单位的期末，例如 "11.50"
     * @return 例如 {expectedClosing:11.50,delta:0.00,balanced:true}；所有数值为精确十进制字符串
     * @throws CommonBusinessException 非十进制或负的流入/流出拒绝；不查询真实余额
     */
    public static Map<String, Object> reconcile(
            String opening, String incoming, String outgoing, String closing) {
        // 不采用 double，不舍入；输入范围由同一严格十进制校验限定。
        BigDecimal initial = decimal(opening);
        BigDecimal in = decimal(incoming);
        BigDecimal out = decimal(outgoing);
        BigDecimal end = decimal(closing);
        if (in.signum() < 0 || out.signum() < 0) {
            throw failure("INVALID_POSTING_VALUE", "流入和流出必须分别以非负值表达。");
        }
        BigDecimal expected = initial.add(in).subtract(out);
        BigDecimal delta = end.subtract(expected);
        return Map.of(
                "expectedClosing",
                expected.toPlainString(),
                "delta",
                delta.toPlainString(),
                "balanced",
                delta.signum() == 0);
    }

    /**
     * 核对同动作已取得的请求快照，不自行缓存或认为客户端快照可信。
     *
     * @param input 例如 {requestKey:req-1,expectedVersion:0,requestState:NONE}
     * @return COMPLETED 且内容一致返回 true；NONE 返回 false
     * @throws CommonBusinessException OPEN 拒绝等待、摘要/动作冲突拒绝；不修改请求记录
     */
    private static boolean replay(Map<String, Object> input) {
        // 请求键及摘要是未来数据库唯一记录的必需参数，空值不会降为无保护写入。
        String key = required(input, "requestKey");
        String hash = payloadHash(input);
        if (!key.matches("[A-Za-z0-9_.:-]{1,64}")) {
            throw failure("INVALID_POSTING_REQUEST", "请求键或内容摘要无效。");
        }
        String requestState = required(input, "requestState");
        if (requestState.equals("NONE")) {
            // 没有已存请求时不能夹带历史摘要，避免不一致证据被忽略。
            if (input.containsKey("storedPayloadHash") || input.containsKey("storedAction")) {
                throw failure("INVALID_POSTING_REQUEST", "无请求记录时不能提供已存摘要。");
            }
            return false;
        }
        if (!Set.of("OPEN", "COMPLETED").contains(requestState)) {
            throw failure("INVALID_POSTING_REQUEST", "请求记录状态未识别。");
        }
        if (!hash.equals(required(input, "storedPayloadHash"))
                || !required(input, "action").equals(required(input, "storedAction"))) {
            throw failure("POSTING_REQUEST_CONFLICT", "同一请求键的动作或内容不一致。");
        }
        if (requestState.equals("OPEN")) {
            throw failure("POSTING_REQUEST_IN_PROGRESS", "请求尚未完成，不能再次过账。");
        }
        return true;
    }

    /**
     * 从本算法真正使用的动作内容生成摘要，不信任客户端提供的 payloadHash。
     *
     * @param input 显式内容，例如 {kind:STOCK_ISSUE,action:POST,quantity:2,expectedVersion:0}
     * @return 按字段名排序、UTF-8 长度前缀编码的 SHA-256，固定 64 位小写十六进制
     * @throws CommonBusinessException 内容非字符串拒绝；SHA-256 系统故障保留原因，不存请求或业务数据
     * @throws CommonSystemException JDK无法提供SHA-256时保留系统原因并拒绝，不写入业务请求
     */
    public static String payloadHash(Map<String, Object> input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // 长度前缀区分字段边界，缺失与空串不会被分隔符拼接混同。
            for (String field : CONTENT_FIELDS.stream().sorted().toList()) {
                if (input.containsKey(field)) {
                    byte[] name = field.getBytes(StandardCharsets.UTF_8);
                    byte[] value = required(input, field).getBytes(StandardCharsets.UTF_8);
                    digest.update((name.length + ":").getBytes(StandardCharsets.UTF_8));
                    digest.update(name);
                    digest.update((value.length + ":").getBytes(StandardCharsets.UTF_8));
                    digest.update(value);
                }
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException unavailable) {
            throw new CommonSystemException(
                    "POSTING_DIGEST_UNAVAILABLE", "内容摘要计算不可用。", unavailable);
        }
    }

    /**
     * 校验可追溯来源、精确值和完整冲销条件，并生成零持久化副作用的预览。
     *
     * @param input 例如库存单
     *     {sourceDocumentId:100001,sourceDocumentState:APPROVED,quantity:2,quantityUnit:EA,availableQuantity:10}
     * @param kind 明确流水类型，例如 STOCK_ISSUE
     * @param reversal 完整冲销时 true
     * @param result 本次预检 Map，例如填入 stockDelta=-2 副作用示例：只填本次结果；实际库状态、权限及跨租户来源仍未验证，writeEnabled 保持
     *     false。
     */
    private static void inspectEntry(
            Map<String, Object> input, String kind, boolean reversal, Map<String, Object> result) {
        // 来源必须存在明确主键与审核快照，不能把无单据库存修改解释为业务流水。
        positiveId(required(input, "sourceDocumentId"));
        String sourceKind = required(input, "sourceDocumentKind");
        boolean sourceAllowed =
                switch (kind) {
                    case "STOCK_ISSUE" -> sourceKind.equals("SALES_ORDER");
                    case "STOCK_RECEIPT" ->
                            Set.of("PURCHASE_ORDER", "SALES_RETURN").contains(sourceKind);
                    case "FUNDS_RECEIPT" -> sourceKind.equals("SALES_ORDER");
                    case "FUNDS_PAYMENT" ->
                            Set.of("PURCHASE_ORDER", "SALES_RETURN").contains(sourceKind);
                    default -> false;
                };
        if (!sourceAllowed) {
            throw failure("INVALID_POSTING_SOURCE", "该流水类型不接受此来源单据。");
        }
        if (!required(input, "sourceDocumentState").equals("APPROVED")) {
            throw failure("POSTING_SOURCE_NOT_APPROVED", "来源单据未审核通过。");
        }
        String origin = required(input, "origin");
        if (!origin.equals("NEW")) {
            // 历史快照保持原金额与库存，不在预检中过账或重新触发历史业务。
            throw failure("HISTORICAL_POSTING_DISABLED", "历史快照不得重新过账。");
        }
        if (reversal) {
            positiveId(required(input, "originalEntryId"));
            if (!required(input, "originalEntryState").equals("POSTED")) {
                throw failure("POSTING_ALREADY_REVERSED", "只能冲销尚未冲销的原流水。");
            }
            if (!kind.equals(required(input, "originalKind"))
                    || !required(input, "sourceDocumentId")
                            .equals(required(input, "originalSourceDocumentId"))) {
                throw failure("INVALID_REVERSAL_REFERENCE", "冲销必须引用同来源同类型的原流水。");
            }
            result.put("originalEntryId", required(input, "originalEntryId"));
            result.put("retainOriginal", true);
        }
        boolean stock = kind.startsWith("STOCK_");
        // 入库/收款为正方向，出库/付款为负；完整冲销严格反向。
        int direction = kind.equals("STOCK_RECEIPT") || kind.equals("FUNDS_RECEIPT") ? 1 : -1;
        if (reversal) {
            direction = -direction;
        }
        if (stock) {
            positiveId(required(input, "warehouseId"));
            positiveId(required(input, "productId"));
            String quantityText = required(input, "quantity");
            if (!quantityText.matches("[1-9][0-9]{0,8}")
                    || !required(input, "quantityUnit").equals("EA")) {
                throw failure("INVALID_POSTING_QUANTITY", "当前库存单仅支持明确件数单位的正整数数量。");
            }
            BigDecimal quantity = decimal(quantityText);
            if (reversal
                    && (!required(input, "warehouseId")
                                    .equals(required(input, "originalWarehouseId"))
                            || !required(input, "productId")
                                    .equals(required(input, "originalProductId"))
                            || !required(input, "quantityUnit")
                                    .equals(required(input, "originalQuantityUnit")))) {
                throw failure("INVALID_REVERSAL_REFERENCE", "冲销不得改变原仓库、产品或数量单位。");
            }
            BigDecimal available = decimal(required(input, "availableQuantity"));
            if (available.signum() < 0 || available.stripTrailingZeros().scale() > 0) {
                throw failure("INVALID_POSTING_QUANTITY", "可用库存须为非负整数。");
            }
            if (reversal && quantity.compareTo(decimal(required(input, "originalQuantity"))) != 0) {
                throw failure("PARTIAL_REVERSAL_DISABLED", "当前仅支持与原流水一致的完整冲销。");
            }
            BigDecimal delta = quantity.multiply(BigDecimal.valueOf(direction));
            BigDecimal projected = available.add(delta);
            if (projected.signum() < 0) {
                throw failure("INSUFFICIENT_POSTING_STOCK", "预检库存不足，拒绝负库存。");
            }
            result.put("stockDelta", delta.toPlainString());
            result.put("projectedQuantity", projected.toPlainString());
            result.put("quantityUnit", "EA");
        } else {
            String currencyCode = required(input, "currency");
            String unit = required(input, "amountUnit");
            BigDecimal amount = decimal(required(input, "amount"));
            int scale;
            try {
                scale = Currency.getInstance(currencyCode).getDefaultFractionDigits();
            } catch (IllegalArgumentException invalidCurrency) {
                throw failure("INVALID_POSTING_CURRENCY", "币种未识别。");
            }
            if (scale < 0 || !Set.of("MAJOR", "MINOR").contains(unit) || amount.signum() <= 0) {
                throw failure("INVALID_POSTING_AMOUNT", "金额单位未识别或金额不是正数。");
            }
            try {
                // 新输入不偷偷舍入；含不能精确表示的最小单位时由调用方明确修正。
                amount =
                        amount.setScale(unit.equals("MINOR") ? 0 : scale, RoundingMode.UNNECESSARY);
            } catch (ArithmeticException needsRounding) {
                throw failure("POSTING_ROUNDING_REQUIRED", "金额精度超出明确单位，不执行隐式舍入。");
            }
            if (reversal
                    && (!currencyCode.equals(required(input, "originalCurrency"))
                            || !unit.equals(required(input, "originalAmountUnit"))
                            || amount.compareTo(decimal(required(input, "originalAmount"))) != 0)) {
                throw failure("PARTIAL_REVERSAL_DISABLED", "完整冲销必须保留原币种、单位与金额。");
            }
            result.put("currency", currencyCode);
            result.put("amountUnit", unit);
            result.put(
                    "fundsDelta", amount.multiply(BigDecimal.valueOf(direction)).toPlainString());
        }
    }

    /**
     * 读取显式字符串，拒绝客户端浮点数或自动填默认值。
     *
     * @param input 预检 Map，例如 {amount:10.20字符串}
     * @param field 必需字段，例如 amount
     * @return 原字符串，例如 "10.20"；不 trim 使错误格式显性暴露
     * @throws CommonBusinessException 缺失/空串/非字符串返回 INVALID_POSTING_PREVIEW
     */
    private static String required(Map<String, Object> input, String field) {
        if (!(input.get(field) instanceof String value)
                || value.isBlank()
                || value.length() > 128) {
            throw failure("INVALID_POSTING_PREVIEW", "预检缺少有效的 " + field + " 字段。");
        }
        return value;
    }

    /**
     * 校验业务引用主键，不从名称或手机号推导关系。
     *
     * @param value 显式来源 ID，例如 "100001" 返回示例：void，合法 ID 不修改输入或数据库。
     * @throws CommonBusinessException 非正整数、Long 溢出拒绝
     */
    private static void positiveId(String value) {
        try {
            if (!value.matches("[1-9][0-9]{0,18}") || Long.parseLong(value) <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException invalidId) {
            throw failure("INVALID_POSTING_REFERENCE", "业务来源主键须为有效正整数。");
        }
    }

    /**
     * 解析精确十进制，不接受科学计数法、逗号、空值或浮点转换。
     *
     * @param value 合成或显式同单位值，例如 "0.01"
     * @return BigDecimal，例如 0.01，保留输入精度
     * @throws CommonBusinessException 非十进制或超过 128 字符拒绝
     */
    private static BigDecimal decimal(String value) {
        if (value == null || value.length() > 128 || !value.matches("-?[0-9]+(?:\\.[0-9]+)?")) {
            throw failure("INVALID_POSTING_VALUE", "必须提供精确十进制字符串。");
        }
        return new BigDecimal(value);
    }

    /**
     * 使用平台统一异常类型表达稳定预检失败。
     *
     * @param code 本域业务码，例如 INVALID_POSTING_TRANSITION
     * @param message 安全提示，例如 该状态不允许此动作。
     * @return CommonBusinessException，errorCode 保留传入码 副作用示例：不携带账号、金额或原始数据记录。
     */
    private static CommonBusinessException failure(String code, String message) {
        return new CommonBusinessException(code, message);
    }

    /**
     * 核对新开发现金账户扣减，拒绝把应收、应付或信用语义套入现金余额。
     *
     * @param accountKind 明确账户语义，例如 CASH；其他类型未开放
     * @param currency 单据币种，例如 CNY
     * @param unit 单据单位，例如 MAJOR
     * @param balanceCurrency 锁定余额币种，例如 CNY
     * @param balanceUnit 锁定余额单位，例如 MAJOR
     * @param available 锁定非负现金余额，例如 "10.20"
     * @param delta 已计算有符号本次变化，例如 "-10.20"
     * @return 精确期末字符串，例如 "0.00"，没有舍入或单位转换 异常示例：现金不足、其他账户语义、币种/单位不匹配或精度无效拒绝，不改历史账或写库。
     */
    public static String cashProjection(
            String accountKind,
            String currency,
            String unit,
            String balanceCurrency,
            String balanceUnit,
            String available,
            String delta) {
        if (!"CASH".equals(accountKind)) {
            throw failure("UNSUPPORTED_POSTING_ACCOUNT_KIND", "仅开放新开发现金账户，其他账户语义待明确。");
        }
        if (currency == null
                || !currency.equals(balanceCurrency)
                || unit == null
                || !unit.equals(balanceUnit)) {
            throw failure("POSTING_ACCOUNT_UNIT_MISMATCH", "现金账户币种与金额单位必须完全匹配。");
        }
        int scale;
        try {
            scale = Currency.getInstance(currency).getDefaultFractionDigits();
        } catch (IllegalArgumentException invalid) {
            throw failure("INVALID_POSTING_CURRENCY", "币种未识别。");
        }
        if (scale < 0 || !Set.of("MAJOR", "MINOR").contains(unit)) {
            throw failure("INVALID_POSTING_AMOUNT", "金额单位未识别。");
        }
        BigDecimal opening = decimal(available), change = decimal(delta);
        try {
            opening = opening.setScale(unit.equals("MINOR") ? 0 : scale, RoundingMode.UNNECESSARY);
            change = change.setScale(unit.equals("MINOR") ? 0 : scale, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException rounding) {
            throw failure("POSTING_ROUNDING_REQUIRED", "拒绝现金单位隐式舍入。");
        }
        if (opening.signum() < 0) {
            throw failure("INVALID_POSTING_CASH_BALANCE", "现金余额必须为非负数。");
        }
        BigDecimal projected = opening.add(change);
        if (projected.signum() < 0) {
            throw failure("INSUFFICIENT_POSTING_FUNDS", "现金余额不足，不执行扣减或自动开放授信。");
        }
        return projected.toPlainString();
    }
}
