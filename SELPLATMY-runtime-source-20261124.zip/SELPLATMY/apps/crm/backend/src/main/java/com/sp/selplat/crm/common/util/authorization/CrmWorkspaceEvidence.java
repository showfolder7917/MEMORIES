/* 文件：CrmWorkspaceEvidence.java；职责：工作台显示真实授权来源；2026-10-14。 */
package com.sp.selplat.crm.common.util.authorization;

import com.sp.selplat.common.util.CommonResult;
import java.util.LinkedHashMap;
import java.util.Map;

/** 不改变公共控件、业务数据或许可；只修正正式授权不能标成合成测试的说明。 */
public final class CrmWorkspaceEvidence {
    /** 方法作用：禁止实例化；异常或副作用示例：不建立状态。 */
    private CrmWorkspaceEvidence() { }

    /**
     * 方法作用：将服务已复核的许可来源呈现到工作台，保留既有隔离说明。
     * @param result owning工作台结果，例如data包含真实分页和公共表单
     * @param scope 本次服务实际裁决，例如synthetic=false/businessOrgId901
     * @param language 已有三语候选，例如zh-CN
     * @return 真实返回示例：正式范围data.synthetic=false，原分页和控件字段不变。
     * 异常或副作用示例：只修改本次返回Map，不保存、授予或扩展任何动作。
     */
    public static CommonResult decorate(CommonResult result, Map<String, Object> scope, Object language) {
        if (!Boolean.FALSE.equals(scope.get("synthetic"))) { return result; }
        @SuppressWarnings("unchecked")
        var data = new LinkedHashMap<>((Map<String, Object>) result.getData());
        data.put("synthetic", false);
        data.put("notice", "ja-JP".equals(language) ? "現在の組織権限に基づいて利用できます。承認と計上は個別の権限が必要です。"
                : "en-US".equals(language) ? "Access follows current organization permissions. Approval and posting require separate permissions."
                : "按当前经营组织权限使用；审核和过账分别需要独立许可。");
        result.setData(data);
        return result;
    }
}
