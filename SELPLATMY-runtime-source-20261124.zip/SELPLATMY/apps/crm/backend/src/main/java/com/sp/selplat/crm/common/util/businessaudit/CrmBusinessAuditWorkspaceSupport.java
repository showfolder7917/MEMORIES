/* 原CRM审计的只读展示投影；2026-10-28，不查询、改写或复制审计事实。 */
package com.sp.selplat.crm.common.util.businessaudit;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 公共SelUI工作区定义与精确编号投影；审计读取资格及SQL由原拥有方负责。 */
public final class CrmBusinessAuditWorkspaceSupport {
  /** 方法作用：禁止实例化；副作用示例：不创建业务状态或权限。 */
  private CrmBusinessAuditWorkspaceSupport() {
    // 仅纯展示投影，不创建实例或持有会话。
  }

  /**
   * 方法作用：从原真实页构建只读列表和详情字段，编号以文本避免浏览器精度损失。
   *
   * @param page 原Service已核范围的真实分页，例如26条审计的第2页6条
   * @param requested 文案语言候选，例如zh-CN；不作为身份或业务参数
   * @return
   *     真实示例：data.grid.pagination.totalCount26，data.readOnlytrue，records含resourceId503和reasonText。
   *     异常或副作用示例：仅复制原行安全字段，不生成记录、时间或授权证据。
   */
  public static CommonResult build(CommonPageResult page, Object requested) {
    int locale = "en-US".equals(requested) ? 1 : "ja-JP".equals(requested) ? 2 : 0;
    String title = words(locale, "业务审计", "Business audit", "業務監査");
    var names = new LinkedHashMap<String, String>();
    names.put("id", words(locale, "审计编号", "Audit ID", "監査番号"));
    names.put("createdAt", words(locale, "操作时间", "Time", "操作日時"));
    names.put("actionLabel", words(locale, "操作", "Action", "操作"));
    names.put("resourceId", words(locale, "对象编号", "Record ID", "対象番号"));
    names.put("actorUserId", words(locale, "操作人编号", "Operator ID", "操作者番号"));
    names.put("previousVersion", words(locale, "变更前版本", "Previous version", "変更前の版"));
    names.put("newVersion", words(locale, "变更后版本", "New version", "変更後の版"));
    names.put("reasonText", words(locale, "操作原因", "Reason", "理由"));
    names.put("commandRequestId", words(locale, "原请求编号", "Original request ID", "元要求番号"));
    names.put("action", words(locale, "操作标识", "Action code", "操作識別子"));
    var records =
        page.getRecords().stream()
            .map(
                row -> {
                  var safe = new LinkedHashMap<String, Object>();
                  for (String field : names.keySet()) {
                    if (!field.equals("actionLabel") && row.get(field) != null) {
                      // 原编号、版本、时间均按真实值转换，不将客户、账号或来源按姓名猜测。
                      safe.put(field, row.get(field).toString());
                    }
                  }
                  // 列表缩短真实时间的显示，详情仍保留原始完整时间及精度。
                  safe.put(
                      "createdAtDisplay",
                      row.get("createdAt") instanceof java.time.OffsetDateTime time
                          ? time.format(
                              java.time.format.DateTimeFormatter.ofPattern(
                                  "uuuu-MM-dd HH:mm:ss XXX"))
                          : safe.get("createdAt"));
                  safe.put("actionLabel", action(row.get("action").toString(), locale));
                  return (Map<String, Object>) safe;
                })
            .toList();
    var fields =
        names.entrySet().stream()
            .map(
                entry ->
                    Map.<String, Object>of(
                        "id",
                        entry.getKey(),
                        "label",
                        entry.getValue(),
                        "readOnly",
                        true,
                        "type",
                        entry.getKey().equals("reasonText") ? "textarea" : "text"))
            .toList();
    var columns =
        List.of(
                "createdAtDisplay",
                "actionLabel",
                "resourceId",
                "actorUserId",
                "previousVersion",
                "newVersion")
            .stream()
            .map(
                field ->
                    Map.<String, Object>of(
                        "field",
                        field,
                        "label",
                        names.get(field.equals("createdAtDisplay") ? "createdAt" : field),
                        "wrapText",
                        true,
                        "width",
                        field.equals("createdAtDisplay")
                            ? "24%"
                            : field.equals("actionLabel")
                                ? "20%"
                                : field.equals("resourceId") || field.equals("actorUserId")
                                    ? "16%"
                                    : "12%"))
            .toList();
    var pagination = new LinkedHashMap<String, Object>();
    pagination.put("mode", "REMOTE");
    pagination.put("visible", true);
    pagination.put("currentPage", page.getPageNo());
    pagination.put("pageSize", page.getPageSize());
    pagination.put("totalCount", page.getTotalCount());
    pagination.put("previousLabel", words(locale, "上一页", "Previous page", "前のページ"));
    pagination.put("nextLabel", words(locale, "下一页", "Next page", "次のページ"));
    pagination.put("summaryAll", words(locale, "共 {total} 条", "{total} records", "合計 {total} 件"));
    pagination.put("summaryFiltered", pagination.get("summaryAll"));
    var grid =
        Map.<String, Object>of(
            "title",
            Map.of("messages", Map.of()),
            "grid",
            Map.of(
                "mode", "records", "idField", "id", "selectionMode", "SINGLE", "minTableWidth", 0),
            "column",
            Map.of(
                "ariaLabel",
                title,
                "emptyText",
                words(locale, "没有符合范围的记录", "No matching records", "該当する記録がありません"),
                "items",
                columns),
            "pagination",
            pagination,
            "data",
            Map.of("items", records, "selectedIds", List.of()));
    var result = new CommonResult();
    result.setSuccess(true);
    result.setData(Map.of("title", title, "readOnly", true, "grid", grid, "detailFields", fields));
    return result;
  }

  /**
   * 方法作用：为既有动作加可读名称，未知原动作保留真实标识。
   *
   * @param value 原审计动作，例如PARTNER_ARCHIVE
   * @param locale 固定语言序号，例如0为中文
   * @return 真实示例：PARTNER_ARCHIVE返回客户归档；未知动作保留原值。 异常或副作用示例：不改变原action字段或审计记录。
   */
  private static String action(String value, int locale) {
    return switch (value) {
      case "PARTNER_SAVE" -> words(locale, "保存客户", "Save customer", "顧客保存");
      case "CONTACT_SAVE" -> words(locale, "保存联系人", "Save contact", "連絡先保存");
      case "PRODUCT_SAVE" -> words(locale, "保存商品", "Save product", "商品保存");
      case "ORDER_SAVE" -> words(locale, "保存订单", "Save order", "注文保存");
      case "ORDER_WITHDRAW" -> words(locale, "撤回订单", "Withdraw order", "注文を取下げ");
      case "ORDER_SUBMIT" -> words(locale, "提交订单", "Submit order", "注文提出");
      case "ORDER_APPROVE" -> words(locale, "审核订单", "Approve order", "注文承認");
      case "FUNDS_DOCUMENT_SAVE" -> words(locale, "保存收付款单", "Save funds document", "入出金伝票保存");
      case "FUNDS_DOCUMENT_SUBMIT" -> words(locale, "提交收付款单", "Submit funds document", "入出金伝票提出");
      case "FUNDS_DOCUMENT_APPROVE" -> words(locale, "审核收付款单", "Approve funds document", "入出金伝票承認");
      case "FUNDS_DOCUMENT_REJECT" -> words(locale, "驳回收付款单", "Reject funds document", "入出金伝票差戻し");
      case "FUNDS_POST" -> words(locale, "登记资金", "Post funds", "入出金記帳");
      case "PARTNER_ARCHIVE" -> words(locale, "客户归档", "Archive customer", "顧客アーカイブ");
      case "PARTNER_RESTORE" -> words(locale, "恢复客户", "Restore customer", "顧客復元");
      default -> value;
    };
  }

  /**
   * 方法作用：选择固定三语展示文本，不读取动态业务或偏好。
   *
   * @param locale 原固定序号，例如0
   * @param zh 中文，例如业务审计
   * @param en 英文，例如Business audit
   * @param ja 日文，例如業務監査
   * @return 真实示例：locale0返回业务审计。 异常或副作用示例：只返回文案，无写入或I/O。
   */
  private static String words(int locale, String zh, String en, String ja) {
    return new String[] {zh, en, ja}[locale];
  }
}
