/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdependency.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmPostingDependencyService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定资金读取、冲正或审核动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);

    /**
     * 方法作用：owning依赖服务只查询已存在的同组织记录。
     *
     * @param input org901/parent1300000
     * @return 真实依赖，无人工置为无效接口 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    List<Map<String, Object>> parentEdges(CommonParam input);

    /**
     * 追加真实子POST→先前有效父POST依赖，不可同批或跨来源。
     *
     * @param input org901/childDetailId1300002/parentDetailId1300000/dependencyKind
     *     RETURN_FOR_ISSUE
     * @param action 当前真实stock.post或funds.post
     * @return 新不可变边id例如1800000；非法类型/引用/父冲正/同批拒绝，不改原明细
     */
    Long appendAllocation(CommonParam input, String action);

    /**
     * 两个精确冲正动作读本表父边；例如org901/parent1300000/stock.reverse返回真实边，无写入。
     *
     * @param input org901/parentDetailId1300000
     * @param action 精确stock.reverse或funds.reverse
     * @return 本组织不可变边列表，不按status隐藏
     */
    List<Map<String, Object>> parentEdges(CommonParam input, String action);

    /**
     * 真实冻结父节点和分摊引用；例如org901/child1300002/stock.reverse读批前序列边，无写入。
     *
     * @param input org901/childDetailId1300002
     * @param action 精确stock.reverse或funds.reverse
     * @return 本组织不可变边列表
     */
    List<Map<String, Object>> childEdges(CommonParam input, String action);
}
