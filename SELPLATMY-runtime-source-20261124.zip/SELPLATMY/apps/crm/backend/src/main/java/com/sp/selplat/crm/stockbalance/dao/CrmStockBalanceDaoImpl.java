/** CrmStockBalanceDaoImpl.java：固定参数化 SQL 只访问本表，绑定 CRM 事务连接。 */
package com.sp.selplat.crm.stockbalance.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表锁定读、条件更新及唯一约束由数据库协调，不依赖进程内锁。 */
@Repository
public class CrmStockBalanceDaoImpl extends CrmBaseDao implements CrmStockBalanceDao {
    // 与公共 MyBatis 使用同一个 crmDataSource，不自行建立连接池。
    private final JdbcTemplate jdbc;

    /**
     * 同sortnum余额按范围内唯一ID稳定翻页，保留原主排序与公共查询实现。
     *
     * @param conditions 服务核验的组织或本人范围，例如tenant92/org901/status1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 真实分页，例如余额880002及totalCount2；不调整数量、流水或权限
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            java.util.Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 唯一ID只打破排序平局；COUNT、占位参数和分页继续使用公共DAO。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 绑定本域SQL模板，不建立重复连接池。
     *
     * @param jdbc Spring提供的crmJdbcTemplate；构造不执行SQL
     */
    public CrmStockBalanceDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 精确读只接受零或一行，不隐藏多行数据错误。
     *
     * @param rows 实际SQL结果，例如[{id:880001,quantity:10}]
     * @return 示例单行返回该Map；空集合返回null，无写入
     * @throws IllegalStateException 两条余额结果时拒绝Expected one CRM row
     */
    private java.util.Map<String, Object> first(
            java.util.List<java.util.Map<String, Object>> rows) {
        if (rows.size() > 1) {
            throw new IllegalStateException("Expected one CRM row");
        }
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 本表固定 SQL 扩展 lockScoped；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmStockBalance WHERE tenantId=? AND ownerUserId=? AND"
                            + " warehouseId=? AND productId=? AND quantityUnit=? AND status=1 FOR"
                            + " UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("warehouseId"),
                        input.getParam("productId"),
                        input.getParam("quantityUnit")));
    }

    /**
     * 本表固定 SQL 扩展 applyDeltaIfVersion；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public int applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmStockBalance SET"
                    + " quantity=quantity+?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP,lastOperateUserId=?"
                    + " WHERE tenantId=? AND ownerUserId=? AND id=? AND status=1 AND versionNo=?"
                    + " AND quantity+? >= 0",
                input.getParam("delta"),
                input.getParam("ownerUserId"),
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("id"),
                input.getParam("versionNo"),
                input.getParam("delta"));
    }

    /**
     * 组织余额维度锁。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    public java.util.Map<String, Object> lockOrganization(
            com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmStockBalance WHERE tenantId=? AND businessOrgId=? AND"
                            + " warehouseId=? AND productId=? AND quantityUnit='EA' AND status=1"
                            + " FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("warehouseId"),
                        input.getParam("productId")));
    }

    /**
     * 组织聚合出库CAS。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    public int issueOrganization(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmStockBalance SET"
                    + " quantity=quantity-?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP,updatedByUserId=?,lastOperateUserId=?"
                    + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
                    + " AND versionNo<9223372036854775807 AND quantity>=?",
                input.getParam("quantity"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("versionNo"),
                input.getParam("quantity"));
    }

    /**
     * 固定本表正数量CAS，同时重核tenant/org、状态、版本和库存上限。
     *
     * @param input 例如tenant92/org901/id880001/versionNo0/quantity2/actor9211
     * @return 示例余额10→12返回1；旧版本、过上限或非有效余额返回0，服务必须回滚
     */
    @Override
    public int receiveOrganization(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmStockBalance SET"
                    + " quantity=quantity+?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP,updatedByUserId=?,lastOperateUserId=?"
                    + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
                    + " AND versionNo<9223372036854775807 AND ? BETWEEN 1 AND 999999999 AND"
                    + " quantity<=999999999-?",
                input.getParam("quantity"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("versionNo"),
                input.getParam("quantity"),
                input.getParam("quantity"));
    }
}
