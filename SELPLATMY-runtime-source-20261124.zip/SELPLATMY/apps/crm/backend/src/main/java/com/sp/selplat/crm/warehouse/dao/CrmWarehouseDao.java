/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.warehouse.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmWarehouseDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);
}
