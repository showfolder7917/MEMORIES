/** 完整销售库存单冲正；2026-10-03，Codex；只调用本表owning服务，正式权限未开放；2026-10-09空请求沿原身份及组织拒绝合同。 */
package com.sp.selplat.crm.capability.stockreversal.service.impl;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.stockreversal.service.CrmStockReversalService;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

/** Order/Line→Document→申请→Progress→批次依赖→账户；一个CRM事务承载全部反向效果。 */
@org.springframework.stereotype.Service
public class CrmStockReversalServiceImpl implements CrmStockReversalService {
    // 真实Session和组织动作准入，不能从请求绑定可信身份。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    // 真实冻结原库存单头行及原单状态，禁止供应商退款复用。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.document.service.CrmDocumentService documents;

    // 实际原单行和退款下游引用，只通过owning服务读取。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.documentline.service.CrmDocumentLineService lines;

    // 独立冲正申请及异人审核状态，不能自批。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.stockreversalrequest.service.CrmStockReversalRequestService
            applications;

    // 真实不可变下游边，阻止有有效下游的冲正。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService dependencies;

    // 原POST和完整REVERSE批次owning入口。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService batches;

    // 全部原与反向流水，复合引用不截断。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService details;

    // 组织同账户币种余额锁与固定减额CAS。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.stockbalance.service.CrmStockBalanceService balances;

    // 冻结来源正向结算计数及完整冲正回算。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.orderlineprogress.service.CrmOrderLineProgressService progress;

    // 申请/审核非过账幂等首次结果。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService commands;

    // 完整冲正批次请求与首次响应。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService requests;

    // 与业务同CRM事务的实际操作者审计。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;

    // CRM具名事务管理器，保留原传播和隔离级别。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
    private org.springframework.transaction.PlatformTransactionManager manager;

    // 独立冲正测试结构开关，生产默认拒绝。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmStockReversalIsolatedEnabled")
    private Boolean enabled;

    /** 方法作用：要求独立冲正结构开关。 副作用示例：未显式启用时CRM_SCOPE_UNAVAILABLE，在查新表前停止，不改旧profile。 */
    private void gate() {
        if (!Boolean.TRUE.equals(enabled) && !access.formalCapabilityAvailable("stockReversal")) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
    }

    /**
     * 方法作用：建立内部关系参数，不复制客户端可信身份。
     *
     * @param input org901
     * @param key 服务器固定id/documentId等字段
     * @param value 实际主键1200000
     * @return 新参数；无SQL副作用。
     */
    private CommonParam relation(CommonParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 方法作用：规范严格具名输入并拒绝客户端数量、审核人和摘要。
     *
     * @param input 原单/原批次/版本/key及申请引用或原因
     * @param mode request、approve或execute
     * @return 规范正数主键和整数版本；字段遗漏、未知字段、非REVERSE或空原因拒绝，无写入。
     */
    private CommonParam normalize(CommonParam input, String mode) {
        Set<String> fields =
                new HashSet<>(
                        Set.of(
                                "organizationCandidateId",
                                "id",
                                "originalBatchId",
                                "expectedVersion",
                                "requestKey"));
        if ("request".equals(mode)) {
            fields.add("reasonText");
        } else {
            fields.addAll(Set.of("reversalRequestId", "expectedReversalVersion"));
        }
        if ("execute".equals(mode)) {
            fields.add("action");
        }
        if (input == null || !fields.equals(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
        }
        var p = new CommonParam();
        for (String f : List.of("organizationCandidateId", "id", "originalBatchId")) {
            p.putParam(f, CrmPartnerValueSupport.positive(input.getParam(f)));
        }
        p.putParam(
                "expectedVersion",
                CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        var keyInput = new CommonParam();
        keyInput.putParam("organizationCandidateId", p.getParam("organizationCandidateId"));
        keyInput.putParam("requestKey", input.getParam("requestKey"));
        p.putParam(
                "requestKey", CrmOrderValueSupport.command(keyInput, false).getParam("requestKey"));
        if ("request".equals(mode)) {
            Object reason = input.getParam("reasonText");
            if (!(reason instanceof String text) || text.isBlank() || text.length() > 500) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
            }
            p.putParam("reasonText", text.trim());
        } else {
            p.putParam(
                    "reversalRequestId",
                    CrmPartnerValueSupport.positive(input.getParam("reversalRequestId")));
            p.putParam(
                    "expectedReversalVersion",
                    CrmPartnerValueSupport.version(input.getParam("expectedReversalVersion")));
        }
        if ("execute".equals(mode)) {
            if (!"REVERSE".equals(input.getParam("action"))) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
            }
            p.putParam("action", "REVERSE");
        }
        return p;
    }

    /**
     * 方法作用：开启独立CRM READ_COMMITTED原子事务。
     *
     * @return 实际事务模板；只有号段独立提交允许失败后技术性空号。
     */
    private org.springframework.transaction.support.TransactionTemplate transaction() {
        var t = new org.springframework.transaction.support.TransactionTemplate(manager);
        t.setPropagationBehavior(
                org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        t.setIsolationLevel(
                org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
        return t;
    }

    /**
     * 方法作用：核实原POST头和全部冻结CASH明细，并派生完整摘要。
     *
     * @param p org901/id1000000/originalBatch1200000/expected3
     * @param action 当前真实reverse或approve
     * @return 真实原单、批次和完整明细/数量/摘要；少行、错批次、非库存或修改冻结拒绝，无库存效果。
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> original(CommonParam p, String action) {
        var head = documents.prepareStockReverse(p, action);
        var candidates =
                batches.findForDocument(relation(p, "documentId", head.get("id")), action).stream()
                        .filter(row -> p.getParam("originalBatchId").equals(row.get("id")))
                        .toList();
        if (candidates.size() != 1) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var batch = candidates.get(0);
        if (!"POST".equals(batch.get("action"))
                || !head.get("id").equals(batch.get("documentId"))
                || !head.get("approvedSnapshotHash").equals(batch.get("approvedSnapshotHash"))) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        var values = details.readHistory(relation(p, "batchId", batch.get("id")), action);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) head.get("lines");
        if (values.size() != rows.size()
                || values.size() != ((Number) batch.get("detailCount")).intValue()) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        Map<Long, Map<String, Object>> byId = new HashMap<>();
        for (var line : rows) {
            byId.put(((Number) line.get("id")).longValue(), line);
        }
        BigDecimal total = BigDecimal.ZERO;
        List<Map<String, Object>> canonical = new ArrayList<>();
        for (var detail : values) {
            var line = byId.remove(((Number) detail.get("documentLineId")).longValue());
            if (line == null
                    || !"POST".equals(detail.get("action"))
                    || !"STOCK".equals(detail.get("effectKind"))) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            for (String f : List.of("sourceOrderLineId", "warehouseId", "productId", "lineNo")) {
                if (!line.get(f).equals(detail.get(f))) {
                    throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
                }
            }
            var amount = originalQuantity(head, detail);
            if (amount.compareTo(new BigDecimal(line.get("quantity").toString())) != 0) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            total = total.add(amount);
            var selected = new TreeMap<String, Object>();
            var view = CrmStockValueSupport.browser(detail);
            for (String f :
                    List.of(
                            "id",
                            "batchId",
                            "documentId",
                            "documentLineId",
                            "sourceOrderLineId",
                            "lineNo",
                            "stockBalanceId",
                            "warehouseId",
                            "productId",
                            "quantityDelta",
                            "action")) {
                selected.put(f, view.get(f));
            }
            canonical.add(selected);
        }
        if (total.precision() > 38) {
            throw CrmPartnerValueSupport.failure("FUNDS_AMOUNT_OVERFLOW");
        }
        var out = new LinkedHashMap<String, Object>();
        out.put("head", head);
        out.put("batch", batch);
        out.put("details", values);
        out.put("totalQuantity", total);
        out.put(
                "digest",
                CrmOrderValueSupport.hash(
                        Map.of(
                                "originalSnapshotHash",
                                head.get("approvedSnapshotHash"),
                                "details",
                                canonical)));
        return out;
    }

    /**
     * 方法作用：比较申请冻结的原始事实与当前真实批次。
     *
     * @param app 实际申请1700000
     * @param facts 当前真实原批次完整事实
     * @param p 客户端原单/批次/申请候选 副作用示例：任何引用、原版本、币种、数量或摘要变更CRM_REVERSAL_SOURCE_CHANGED，全事务回滚。
     */
    @SuppressWarnings("unchecked")
    private void match(Map<String, Object> app, Map<String, Object> facts, CommonParam p) {
        var head = (Map<String, Object>) facts.get("head");
        if (!app.get("id").equals(p.getParam("reversalRequestId"))
                || !app.get("originalDocumentId").equals(head.get("id"))
                || !app.get("originalBatchId").equals(p.getParam("originalBatchId"))
                || !app.get("originalDocumentVersion").equals(head.get("versionNo"))
                || !app.get("originalSnapshotHash").equals(head.get("approvedSnapshotHash"))
                || !app.get("originalBatchDigest").equals(facts.get("digest"))
                || new BigDecimal(app.get("totalQuantity").toString())
                                .compareTo((BigDecimal) facts.get("totalQuantity"))
                        != 0) {
            throw CrmPartnerValueSupport.failure("CRM_REVERSAL_SOURCE_CHANGED");
        }
    }

    /**
     * 方法作用：从实际批次和全部严格相反明细派生子POST是否仍有效。
     *
     * @param p org901
     * @param post 实际子POST批次
     * @return
     *     无完整已提交反向批次true；完整反向且原批准摘要/每行行号一致后false；摘要或行号改变、非法或不完整反向拒绝CRM_DEPENDENCY_INTEGRITY，人工status/state不参与。
     */
    private boolean active(CommonParam p, Map<String, Object> post) {
        var history =
                batches.findForDocument(
                        relation(p, "documentId", post.get("documentId")), "crm.stock.reverse");
        var reverses =
                history.stream()
                        .filter(
                                b ->
                                        "REVERSE".equals(b.get("action"))
                                                && post.get("id").equals(b.get("originalBatchId")))
                        .toList();
        var before = details.readAll(relation(p, "batchId", post.get("id")), "crm.stock.reverse");
        var after =
                reverses.size() == 1
                        ? details.readAll(
                                relation(p, "batchId", reverses.get(0).get("id")),
                                "crm.stock.reverse")
                        : List.<Map<String, Object>>of();
        return com.sp.selplat.crm.common.util.frozen.CrmFrozenExecutionSupport.effective(
                post, before, reverses, after);
    }

    /**
     * 方法作用：完成申请命令首次结果和唯一审计。
     *
     * @param p 规范命令引用
     * @param command STOCK_REVERSAL_REQUEST或APPROVE
     * @param requestId 当前真实claim主键
     * @param app 当前真实申请
     * @param previous 原版本或null
     * @return 精确首次申请JSON；权限撤销/请求完成/审计失败同事务回滚。
     */
    private CommonResult finish(
            CommonParam p, String command, long requestId, Map<String, Object> app, Long previous) {
        var scope = access.requireStockScope(
                p.getParam("organizationCandidateId"),
                CrmPartnerValueSupport.commandAction(command));
        var data = CrmStockValueSupport.browser(app);
        data.put("replay", false);
        data.put("synthetic", scope.get("synthetic"));
        var req = command(p, command);
        req.putParam("id", requestId);
        req.putParam("resultStockReversalRequestId", app.get("id"));
        req.putParam("resultVersionNo", app.get("versionNo"));
        req.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
        commands.complete(req);
        var event = relation(p, "commandRequestId", requestId);
        event.putParam("action", command);
        event.putParam("resourceId", app.get("id"));
        event.putParam("previousVersion", previous);
        event.putParam("newVersion", app.get("versionNo"));
        audit.append(event);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：服务器派生幂等命令摘要。
     *
     * @param p 规范完整申请引用/原因
     * @param name 固定命令名称
     * @return key/hash；不含真实actor、不由客户端提交hash。
     */
    private CommonParam command(CommonParam p, String name) {
        var req = relation(p, "commandName", name);
        req.putParam("requestKey", p.getParam("requestKey"));
        req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
        return req;
    }

    /**
     * 方法作用：回滚失败claim事务后读取首次已提交申请响应。
     *
     * @param p 规范命令
     * @param name 固定申请/审核命令
     * @param operation 实际事务业务函数
     * @return 首次真实结果或same-key首次快照replay=true；不同内容、撤权拒绝。
     */
    private CommonResult writeCommand(
            CommonParam p, String name, java.util.function.LongFunction<CommonResult> operation) {
        var req = command(p, name);
        try {
            return access.executeTransaction(p.getParam("organizationCandidateId"), CrmPartnerValueSupport.commandAction(name), transaction(),
                            tx -> {
                                access.requireStockScope(
                                        p.getParam("organizationCandidateId"),
                                        CrmPartnerValueSupport.commandAction(name));
                                documents.requireStockReverseReference(
                                        p, CrmPartnerValueSupport.commandAction(name));
                                return operation.apply(commands.claim(req));
                            });
        } catch (CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            return replay(commands.committed(req), req);
        }
    }

    /**
     * 方法作用：只返回已完成同内容首次快照。
     *
     * @param stored 真实已提交请求或null
     * @param req 服务器规范key/hash
     * @return replay=true首次结果；差内容或未完成拒绝，不新增流水。
     */
    @SuppressWarnings("unchecked")
    private CommonResult replay(Map<String, Object> stored, CommonParam req) {
        if (stored == null || !req.getParam("payloadHash").equals(stored.get("payloadHash"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
        }
        if (!"COMPLETED".equals(stored.get("requestState"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
        }
        var data =
                JsonUtils.fromJson(
                        (String) CrmStockValueSupport.browser(stored).get("responseSnapshot"),
                        Map.class);
        data.put("replay", true);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：提交并冻结整批冲正申请，保留原审批。
     *
     * @param input 原单1000000/批次1200000/expected3/reasonText/key
     * @return SUBMITTED申请1700000/version0；原库存和进度不变，重复key重放。
     *     业务示例：org901、原单1000000、批次1200000、expectedVersion=3、原因“合成完整冲正”；返回申请1700000、SUBMITTED/version0。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    @SuppressWarnings("unchecked")
    public CommonResult request(CommonParam input) {
        gate();
        // 空请求只作为缺失组织候选传入原准入；真实身份、隔离开关及动作检查仍先执行。
        access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var p = normalize(input, "request");
        return writeCommand(
                p,
                "STOCK_REVERSAL_REQUEST",
                requestId -> {
                    var facts = original(p, "crm.stock.reverse");
                    if (applications.forOriginal(
                                    relation(p, "originalBatchId", p.getParam("originalBatchId")),
                                    "crm.stock.reverse")
                            != null) {
                        throw CrmPartnerValueSupport.failure("CRM_REVERSAL_ALREADY_REQUESTED");
                    }
                    var head = (Map<String, Object>) facts.get("head");
                    var submit = relation(p, "originalDocumentId", head.get("id"));
                    submit.putParam("originalBatchId", p.getParam("originalBatchId"));
                    submit.putParam("originalDocumentVersion", head.get("versionNo"));
                    submit.putParam("originalSnapshotHash", head.get("approvedSnapshotHash"));
                    submit.putParam("originalBatchDigest", facts.get("digest"));
                    submit.putParam("totalQuantity", facts.get("totalQuantity"));
                    submit.putParam("reasonText", p.getParam("reasonText"));
                    long id = applications.submit(submit);
                    return finish(
                            p,
                            "STOCK_REVERSAL_REQUEST",
                            requestId,
                            applications.lockScoped(relation(p, "id", id), "crm.stock.reverse"),
                            null);
                });
    }

    /**
     * 方法作用：另一真实用户重核原事实并审核申请。
     *
     * @param input 原单/批次/申请1700000/expected3/expectedReversal0/key
     * @return APPROVED/version1；申请者自审、原事实变更或末尾失败拒绝，库存无效果。
     *     业务示例：用户9212审核用户9211提交的申请1700000、expectedReversalVersion=0；返回APPROVED/version1，自审拒绝。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult approve(CommonParam input) {
        gate();
        // 空请求只作为缺失组织候选传入原准入；真实身份、隔离开关及动作检查仍先执行。
        access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.approve");
        var p = normalize(input, "approve");
        return writeCommand(
                p,
                "STOCK_REVERSAL_APPROVE",
                requestId -> {
                    var facts = original(p, "crm.stock.approve");
                    var app =
                            applications.lockScoped(
                                    relation(p, "id", p.getParam("reversalRequestId")),
                                    "crm.stock.approve");
                    match(app, facts, p);
                    var change = relation(p, "id", app.get("id"));
                    change.putParam("expectedVersion", p.getParam("expectedReversalVersion"));
                    return finish(
                            p,
                            "STOCK_REVERSAL_APPROVE",
                            requestId,
                            applications.transition(change, false),
                            ((Number) app.get("versionNo")).longValue());
                });
    }

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService capacities;

    /**
     * 实际原库存流水绝对数量；销售出库-3、采购和销售退货入库+3均返回3。
     *
     * @param head 实际冻结单据
     * @param detail 实际原POST明细
     * @return 正数EA数量；方向错或数量非法拒绝，不写库存
     */
    private BigDecimal originalQuantity(Map<String, Object> head, Map<String, Object> detail) {
        long value = ((Number) detail.get("quantityDelta")).longValue();
        boolean issue = "STOCK_ISSUE".equals(head.get("documentKind"));
        if (value == Long.MIN_VALUE || (issue ? value >= 0 : value <= 0)) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        return BigDecimal.valueOf(Math.abs(value));
    }

    /**
     * 真实下游不可变图检查，例如有效退货或退款使原批次拒绝。
     *
     * @param p org901
     * @param values 全部原POST库存明细 副作用示例：有效子POST拒绝POSTING_DOWNSTREAM_ACTIVE，status不参与判断；无写入。
     */
    private void downstream(CommonParam p, List<Map<String, Object>> values) {
        for (var parent : values) {
            for (var edge :
                    dependencies.parentEdges(
                            relation(p, "parentDetailId", parent.get("id")), "crm.stock.reverse")) {
                String kind = String.valueOf(edge.get("dependencyKind"));
                var child =
                        details.lockScoped(
                                relation(p, "id", edge.get("childDetailId")), "crm.stock.reverse");
                boolean cash = "REFUND_FOR_RETURN".equals(kind);
                if (!Set.of("RETURN_FOR_ISSUE", "REFUND_FOR_RETURN", "SERIAL_RETURN_ENTITLEMENT")
                                .contains(kind)
                        || !parent.get("sourceOrderLineId").equals(child.get("sourceOrderLineId"))
                        || !"POST".equals(child.get("action"))
                        || !(cash ? "CASH" : "STOCK").equals(child.get("effectKind"))
                        || (cash
                                ? new BigDecimal(child.get("amountDeltaMinor").toString()).signum()
                                        != -1
                                : ((Number) child.get("quantityDelta")).longValue() <= 0)) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                var batch =
                        batches.lockScoped(
                                relation(p, "id", child.get("batchId")), "crm.stock.reverse");
                if (active(p, batch)) {
                    throw CrmPartnerValueSupport.failure("POSTING_DOWNSTREAM_ACTIVE");
                }
            }
        }
    }

    /**
     * 聚合真实退货原出库分配并与全部有效子POST对账。
     *
     * @param p org901
     * @param head 原完整冻结退货头及实际行
     * @param values 原批次全部库存POST
     * @return 父容量排序后的释放参数，例如used3释放3；缺边/使用量不符拒绝，不修改原明细
     */
    @SuppressWarnings("unchecked")
    private List<CommonParam> allocations(
            CommonParam p, Map<String, Object> head, List<Map<String, Object>> values) {
        Map<Object, Map<String, Object>> byLine = new HashMap<>();
        for (var line : (List<Map<String, Object>>) head.get("lines")) {
            byLine.put(line.get("id"), line);
        }
        Map<Long, CommonParam> parents = new TreeMap<>();
        for (var value : values) {
            var line = byLine.get(value.get("documentLineId"));
            long parent = ((Number) line.get("baseIssueDetailId")).longValue();
            var edges =
                    dependencies.childEdges(
                            relation(p, "childDetailId", value.get("id")), "crm.stock.reverse");
            if (edges.stream()
                            .filter(
                                    e ->
                                            "RETURN_FOR_ISSUE".equals(e.get("dependencyKind"))
                                                    && Long.valueOf(parent)
                                                            .equals(e.get("parentDetailId")))
                            .count()
                    != 1) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
            var q = parents.get(parent);
            if (q == null) {
                q = relation(p, "originalDetailId", parent);
                q.putParam("capacityKind", "ISSUE_RETURN");
                q.putParam("sourceOrderLineId", value.get("sourceOrderLineId"));
                q.putParam("quantity", 0L);
                parents.put(parent, q);
            }
            if (!q.getParam("sourceOrderLineId").equals(value.get("sourceOrderLineId"))) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
            q.putParam(
                    "quantity",
                    Math.addExact(
                            ((Number) q.getParam("quantity")).longValue(),
                            ((Number) value.get("quantityDelta")).longValue()));
        }
        for (var entry : parents.entrySet()) {
            var q = entry.getValue();
            var row = capacities.lockAllocation(q, "crm.stock.reverse");
            long used = 0;
            var original =
                    details.lockScoped(relation(p, "id", entry.getKey()), "crm.stock.reverse");
            if (!"STOCK".equals(original.get("effectKind"))
                    || ((Number) original.get("quantityDelta")).longValue() >= 0
                    || !active(
                            p,
                            batches.lockScoped(
                                    relation(p, "id", original.get("batchId")),
                                    "crm.stock.reverse"))) {
                throw CrmPartnerValueSupport.failure("POSTING_PARENT_INACTIVE");
            }
            for (var edge :
                    dependencies.parentEdges(
                            relation(p, "parentDetailId", entry.getKey()), "crm.stock.reverse")) {
                if (!"RETURN_FOR_ISSUE".equals(edge.get("dependencyKind"))) {
                    continue;
                }
                var child =
                        details.lockScoped(
                                relation(p, "id", edge.get("childDetailId")), "crm.stock.reverse");
                if (!q.getParam("sourceOrderLineId").equals(child.get("sourceOrderLineId"))
                        || !"STOCK".equals(child.get("effectKind"))
                        || !"POST".equals(child.get("action"))
                        || ((Number) child.get("quantityDelta")).longValue() <= 0) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                if (active(
                        p,
                        batches.lockScoped(
                                relation(p, "id", child.get("batchId")), "crm.stock.reverse"))) {
                    used = Math.addExact(used, ((Number) child.get("quantityDelta")).longValue());
                }
            }
            if (used != ((Number) row.get("usedQuantity")).longValue()) {
                throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
            }
            q.putParam("id", row.get("id"));
            q.putParam("versionNo", row.get("versionNo"));
        }
        return new ArrayList<>(parents.values());
    }

    /**
     * 回算每来源末退货节点和权益，整批多行只回退至批前外部父。
     *
     * @param p org901
     * @param values 实际当前退货全部POST，按lineNo冻结
     * @param counters 已锁来源进度
     * @param amounts 按来源聚合整批EA
     * @return 每来源真实批前末节点或null；非末批/权益不够/不同前驱拒绝，无写入
     */
    private Map<Long, Object> predecessors(
            CommonParam p,
            List<Map<String, Object>> values,
            Map<Long, Map<String, Object>> counters,
            Map<Long, Long> amounts) {
        Map<Long, Object> previous = new TreeMap<>();
        for (var entry : amounts.entrySet()) {
            long source = entry.getKey();
            var counter = counters.get(source);
            var rows =
                    values.stream()
                            .filter(d -> Long.valueOf(source).equals(d.get("sourceOrderLineId")))
                            .sorted(
                                    java.util.Comparator.comparingInt(
                                            d -> ((Number) d.get("lineNo")).intValue()))
                            .toList();
            if (!rows.get(rows.size() - 1).get("id").equals(counter.get("lastReturnDetailId"))) {
                throw CrmPartnerValueSupport.failure("POSTING_DOWNSTREAM_ACTIVE");
            }
            long before = ((Number) counter.get("stockReturnedQuantity")).longValue(),
                    after = before - entry.getValue();
            var remaining =
                    com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnValueSupport
                            .entitlement(counter, after);
            if (new BigDecimal(counter.get("cashRefundedMinor").toString()).compareTo(remaining)
                    > 0) {
                throw CrmPartnerValueSupport.failure("POSTING_DOWNSTREAM_ACTIVE");
            }
            BigDecimal frozen = BigDecimal.ZERO;
            Object parent = null;
            boolean first = true;
            for (var row : rows) {
                if (row.get("refundCapacityMinor") == null) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                frozen = frozen.add(new BigDecimal(row.get("refundCapacityMinor").toString()));
                var serial =
                        dependencies
                                .childEdges(
                                        relation(p, "childDetailId", row.get("id")),
                                        "crm.stock.reverse")
                                .stream()
                                .filter(
                                        e ->
                                                "SERIAL_RETURN_ENTITLEMENT"
                                                        .equals(e.get("dependencyKind")))
                                .toList();
                if (serial.size() > 1) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                Object candidate = serial.isEmpty() ? null : serial.get(0).get("parentDetailId");
                if (first) {
                    parent = candidate;
                    first = false;
                } else if (!Objects.equals(parent, candidate)) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
            }
            if (frozen.compareTo(
                            com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnValueSupport
                                    .entitlement(counter, before)
                                    .subtract(remaining))
                    != 0) {
                throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
            }
            if (parent != null) {
                var row = details.lockScoped(relation(p, "id", parent), "crm.stock.reverse");
                if (!Long.valueOf(source).equals(row.get("sourceOrderLineId"))
                        || !"STOCK".equals(row.get("effectKind"))
                        || !"POST".equals(row.get("action"))
                        || ((Number) row.get("quantityDelta")).longValue() <= 0
                        || row.get("refundCapacityMinor") == null
                        || values.stream().anyMatch(d -> row.get("id").equals(d.get("id")))
                        || !active(
                                p,
                                batches.lockScoped(
                                        relation(p, "id", row.get("batchId")),
                                        "crm.stock.reverse"))) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
            } else if (after != 0) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
            previous.put(source, parent);
        }
        return previous;
    }

    /**
     * 排序库存维度，锁定顺序不依赖客户端行序。
     *
     * @param warehouseId 实际仓库801
     * @param productId 实际商品701
     */
    private record BalanceKey(long warehouseId, long productId) implements Comparable<BalanceKey> {
        /**
         * 比较仓库再商品；例如仓库910/商品930先于920/930。
         *
         * @param other 已核真实库存维度
         * @return -1/0/1排序结果，不查询或修改数据库
         */
        @Override
        public int compareTo(BalanceKey other) {
            int c = Long.compare(warehouseId, other.warehouseId);
            return c == 0 ? Long.compare(productId, other.productId) : c;
        }
    }

    /**
     * 只读真实原整批和独立申请，例如原入库3EA预览反向-3EA。
     *
     * @param input org901/id1000000
     * @return 原批次数量、库存维度反向影响和申请状态；越域或缺读许可拒绝，无库存效果
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult preview(CommonParam input) {
        gate();
        // 预览同样先核真实身份及候选组织，空请求不再因字段解引用产生NPE。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        if (!input.getParamMap().keySet().equals(Set.of("organizationCandidateId", "id"))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
        }
        var head = documents.readStockForReversal(input);
        var posts =
                batches
                        .findForDocument(
                                relation(
                                        input,
                                        "documentId",
                                        CrmPartnerValueSupport.positive(input.getParam("id"))),
                                "crm.stock.read")
                        .stream()
                        .filter(b -> "POST".equals(b.get("action")))
                        .toList();
        if (posts.size() != 1) {
            throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
        }
        var batch = posts.get(0);
        var values = details.readAll(relation(input, "batchId", batch.get("id")), "crm.stock.read");
        if (values.isEmpty() || values.size() != ((Number) batch.get("detailCount")).intValue()) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        BigDecimal total = BigDecimal.ZERO;
        Map<BalanceKey, Long> effects = new TreeMap<>();
        for (var d : values) {
            if (!"STOCK".equals(d.get("effectKind"))) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            total = total.add(originalQuantity(head, d));
            effects.merge(
                    new BalanceKey(
                            ((Number) d.get("warehouseId")).longValue(),
                            ((Number) d.get("productId")).longValue()),
                    Math.negateExact(((Number) d.get("quantityDelta")).longValue()),
                    Math::addExact);
        }
        var data = new LinkedHashMap<String, Object>();
        data.put("documentId", head.get("id"));
        data.put("documentVersion", head.get("versionNo"));
        data.put("documentState", head.get("documentState"));
        data.put("originalBatchId", batch.get("id").toString());
        data.put("totalQuantity", total.toPlainString());
        data.put("quantityUnit", "EA");
        data.put(
                "stockEffects",
                effects.entrySet().stream()
                        .map(
                                e ->
                                        Map.of(
                                                "warehouseId",
                                                Long.toString(e.getKey().warehouseId()),
                                                "productId",
                                                Long.toString(e.getKey().productId()),
                                                "quantityDelta",
                                                e.getValue().toString()))
                        .toList());
        var app =
                applications.forOriginal(
                        relation(input, "originalBatchId", batch.get("id")), "crm.stock.read");
        if (app != null) {
            var view = CrmStockValueSupport.browser(app);
            view.put(
                    "canApprove",
                    "SUBMITTED".equals(app.get("requestState"))
                            && !scope.get("actorUserId").equals(app.get("submittedByUserId")));
            data.put("application", view);
        }
        data.put("synthetic", scope.get("synthetic"));
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 完整库存反向与进度容量同事务提交，例如退货3EA→REVERSE-3EA/T归零。
     *
     * @param input 原单/原批次/独立申请/双方版本/actionREVERSE/key
     * @return REVERSED/version4、新批次和全部相反明细；有效下游、非末批、库存不足、撤权或末尾失败整笔回滚
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    @SuppressWarnings("unchecked")
    public CommonResult execute(CommonParam input) {
        gate();
        // 空请求只作为缺失组织候选传入原准入；真实身份、隔离开关及动作检查仍先执行。
        access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var p = normalize(input, "execute");
        var req = relation(p, "documentId", p.getParam("id"));
        req.putParam("requestKey", p.getParam("requestKey"));
        req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
        try {
            return access.executeTransaction(p.getParam("organizationCandidateId"), "crm.stock.reverse", transaction(),
                            tx -> {
                                var scope = access.requireStockScope(
                                        p.getParam("organizationCandidateId"), "crm.stock.reverse");
                                documents.requireStockReverseReference(p, "crm.stock.reverse");
                                long requestId = requests.claimOrganizationStockReverse(req);
                                var facts = original(p, "crm.stock.reverse");
                                var head = (Map<String, Object>) facts.get("head");
                                var app =
                                        applications.lockScoped(
                                                relation(p, "id", p.getParam("reversalRequestId")),
                                                "crm.stock.reverse");
                                match(app, facts, p);
                                if (!"APPROVED".equals(app.get("requestState"))
                                        || !app.get("versionNo")
                                                .equals(p.getParam("expectedReversalVersion"))) {
                                    throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
                                }
                                var values = (List<Map<String, Object>>) facts.get("details");
                                var source = (Map<String, Object>) head.get("source");
                                Map<Long, Map<String, Object>> sourceById = new TreeMap<>();
                                for (var s : (List<Map<String, Object>>) source.get("lines")) {
                                    sourceById.put(((Number) s.get("id")).longValue(), s);
                                }
                                Map<Long, Long> amounts = new TreeMap<>();
                                Map<BalanceKey, Long> stockAmounts = new TreeMap<>();
                                for (var d : values) {
                                    amounts.merge(
                                            ((Number) d.get("sourceOrderLineId")).longValue(),
                                            originalQuantity(head, d).longValueExact(),
                                            Math::addExact);
                                    stockAmounts.merge(
                                            new BalanceKey(
                                                    ((Number) d.get("warehouseId")).longValue(),
                                                    ((Number) d.get("productId")).longValue()),
                                            Math.negateExact(
                                                    ((Number) d.get("quantityDelta")).longValue()),
                                            Math::addExact);
                                }
                                Map<Long, Map<String, Object>> counters = new TreeMap<>();
                                for (var entry : amounts.entrySet()) {
                                    counters.put(
                                            entry.getKey(),
                                            progress.lockForLine(
                                                    p,
                                                    sourceById.get(entry.getKey()),
                                                    "crm.stock.reverse"));
                                }
                                batches.lockScoped(
                                        relation(p, "id", p.getParam("originalBatchId")),
                                        "crm.stock.reverse");
                                for (var d : values) {
                                    if (!d.equals(
                                            details.lockScoped(
                                                    relation(p, "id", d.get("id")),
                                                    "crm.stock.reverse"))) {
                                        throw CrmPartnerValueSupport.failure(
                                                "CRM_REVERSAL_SOURCE_CHANGED");
                                    }
                                }
                                downstream(p, values);
                                boolean returned = "SALES_RETURN".equals(head.get("reason"));
                                Map<Long, Object> previous =
                                        returned
                                                ? predecessors(p, values, counters, amounts)
                                                : Map.of();
                                for (var entry : amounts.entrySet()) {
                                    if (!returned
                                            && ((Number)
                                                                            counters.get(
                                                                                            entry
                                                                                                    .getKey())
                                                                                    .get(
                                                                                            "stockPostedQuantity"))
                                                                    .longValue()
                                                            - entry.getValue()
                                                    < ((Number)
                                                                    counters.get(entry.getKey())
                                                                            .get(
                                                                                    "stockReturnedQuantity"))
                                                            .longValue()) {
                                        throw CrmPartnerValueSupport.failure(
                                                "POSTING_DOWNSTREAM_ACTIVE");
                                    }
                                }
                                var released =
                                        returned
                                                ? allocations(p, head, values)
                                                : List.<CommonParam>of();
                                Map<BalanceKey, Map<String, Object>> stocks = new TreeMap<>();
                                for (var entry : stockAmounts.entrySet()) {
                                    var key = entry.getKey();
                                    var q = relation(p, "warehouseId", key.warehouseId());
                                    q.putParam("productId", key.productId());
                                    var row = balances.lockForStockReverse(q);
                                    long next =
                                            Math.addExact(
                                                    ((Number) row.get("quantity")).longValue(),
                                                    entry.getValue());
                                    if (next < 0) {
                                        throw CrmPartnerValueSupport.failure("STOCK_INSUFFICIENT");
                                    }
                                    if (next > 999999999L) {
                                        throw CrmPartnerValueSupport.failure(
                                                "STOCK_QUANTITY_LIMIT");
                                    }
                                    stocks.put(key, row);
                                }
                                var batch = relation(p, "documentId", head.get("id"));
                                batch.putParam("originalBatchId", p.getParam("originalBatchId"));
                                batch.putParam("detailCount", values.size());
                                batch.putParam(
                                        "approvedSnapshotHash", head.get("approvedSnapshotHash"));
                                long batchId = batches.appendStockReverse(batch);
                                List<String> ids = new ArrayList<>();
                                for (var d : values) {
                                    var effect = relation(p, "originalDetailId", d.get("id"));
                                    effect.putParam("batchId", batchId);
                                    ids.add(details.appendStockReverse(effect).toString());
                                }
                                for (var entry : stockAmounts.entrySet()) {
                                    var row = stocks.get(entry.getKey());
                                    var q = relation(p, "id", row.get("id"));
                                    q.putParam("versionNo", row.get("versionNo"));
                                    q.putParam("quantityDelta", entry.getValue());
                                    balances.applyStockReverse(q);
                                }
                                for (var entry : amounts.entrySet()) {
                                    var row = counters.get(entry.getKey());
                                    var q = relation(p, "id", row.get("id"));
                                    q.putParam("versionNo", row.get("versionNo"));
                                    q.putParam("quantity", entry.getValue());
                                    if (returned) {
                                        q.putParam(
                                                "previousReturnDetailId",
                                                previous.get(entry.getKey()));
                                        progress.reverseReturn(q);
                                    } else {
                                        progress.reverseIssue(q);
                                    }
                                }
                                for (var allocation : released) {
                                    capacities.releaseReturn(allocation);
                                }
                                var posted = documents.markStockReversed(p);
                                var change = relation(p, "id", app.get("id"));
                                change.putParam(
                                        "expectedVersion", p.getParam("expectedReversalVersion"));
                                change.putParam("resultBatchId", batchId);
                                var resultApp = applications.transition(change, true);
                                access.requireStockScope(
                                        p.getParam("organizationCandidateId"), "crm.stock.reverse");
                                var data = new LinkedHashMap<String, Object>();
                                data.put("documentId", head.get("id").toString());
                                data.put("state", "REVERSED");
                                data.put("version", posted.get("versionNo").toString());
                                data.put("versionNo", posted.get("versionNo").toString());
                                data.put("reversalRequestId", app.get("id").toString());
                                data.put(
                                        "reversalVersionNo", resultApp.get("versionNo").toString());
                                data.put(
                                        "originalBatchId",
                                        p.getParam("originalBatchId").toString());
                                data.put("postingBatchId", Long.toString(batchId));
                                data.put("detailIds", ids);
                                data.put(
                                        "stockEffects",
                                        stockAmounts.entrySet().stream()
                                                .map(
                                                        e ->
                                                                Map.of(
                                                                        "warehouseId",
                                                                        Long.toString(
                                                                                e.getKey()
                                                                                        .warehouseId()),
                                                                        "productId",
                                                                        Long.toString(
                                                                                e.getKey()
                                                                                        .productId()),
                                                                        "quantityDelta",
                                                                        e.getValue().toString()))
                                                .toList());
                                data.put("replay", false);
                                data.put("synthetic", scope.get("synthetic"));
                                var complete = CrmStockValueSupport.param(req.getParamMap());
                                complete.putParam("id", requestId);
                                complete.putParam("resultBatchId", batchId);
                                complete.putParam("resultVersionNo", posted.get("versionNo"));
                                complete.putParam(
                                        "responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
                                requests.completeOrganizationStockReverse(complete);
                                var event = relation(p, "postingRequestId", requestId);
                                event.putParam("batchId", batchId);
                                event.putParam("action", "STOCK_REVERSE");
                                event.putParam("resourceId", head.get("id"));
                                event.putParam("previousVersion", head.get("versionNo"));
                                event.putParam("newVersion", posted.get("versionNo"));
                                audit.append(event);
                                return CrmPartnerValueSupport.result(data);
                            });
        } catch (CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            return replay(requests.committedOrganizationStockReverse(req), req);
        }
    }
}
