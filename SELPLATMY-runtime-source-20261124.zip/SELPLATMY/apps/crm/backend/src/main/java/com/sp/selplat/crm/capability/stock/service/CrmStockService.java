/** 单一销售出库能力；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.capability.stock.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 聚合多个owning服务的具名原子POST，不拥有表或DAO。 */
public interface CrmStockService {
    /**
     * 明确POST整个审核销售出库，不允许REVERSE。
     *
     * @param input org901/id1000000/actionPOST/expectedVersion2/requestKeyp1
     * @return 实际postingBatchId、全部detailIds、POSTED/version3/replay
     */
    CommonResult execute(CommonParam input);

    /**
     * 实际本组织批次与全部流水。
     *
     * @param input org901/id1200000
     * @return 同一真实批次头/全部detail；跨组织统一拒绝
     */
    CommonResult batch(CommonParam input);

    /**
     * 实际销售出库后台聚合配置。
     *
     * @param input org901/page1/langzh-CN
     * @return 实际单据、审核订单、仓库、余额、流水及三语SELUI配置
     */
    CommonResult workspace(CommonPageParam input);
}
