/** 一期销售退货退款容量服务；2026-10-04，Codex；不修改原流水。 */
package com.sp.selplat.crm.postingcapacity.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/* 修改记录：2026-10-09，关闭通用读取的固定错误由owning服务统一提供。 */
/** 原销售出库、收款、退货明细的独立有限容量；通用CRUD关闭。 */
public interface CrmPostingCapacityService extends BaseService {
    /**
     * 提供本表固定关闭通用读取的错误契约，不执行容量查询或身份推断。
     *
     * @return CRM_GENERIC_ACCESS_DISABLED业务异常；控制器或服务抛出后返回原400响应
     *     异常或副作用示例：只构造安全错误，无数据库、授权或号段变更。
     */
    com.sp.selplat.common.exception.CommonBusinessException genericReadRejection();

    /**
     * 从真实已提交状态的本事务POST明细建立容量，不接受客户端上限。
     *
     * @param input org901/originalDetailId1300000/sourceOrderLineId600001/capacityKind ISSUE_RETURN
     * @param action 当前真实stock.post或funds.post动作
     * @return 实际容量，例如{capacityQuantity:3,usedQuantity:0,versionNo:0}；已有容量不重置
     */
    Map<String, Object> registerOriginal(CommonParam input, String action);

    /**
     * 在来源进度锁后锁真实有效原明细容量；不能从缺历史推导零占用。
     *
     * @param input org901/originalDetailId1300000/sourceOrderLineId600001/capacityKind ISSUE_RETURN
     * @param action 当前真实stock.post或funds.post动作
     * @return 实际容量，例如{capacityQuantity:3,usedQuantity:1,versionNo:1}；不存在或父已冲正拒绝
     */
    Map<String, Object> lockAllocation(CommonParam input, String action);

    /**
     * 在本表版本与上限条件内占用实际容量；调用者先聚合同一原明细。
     *
     * @param input org901/id1900000/versionNo0/quantity1或amountMinor67及原明细、来源、容量类型
     * @param action 当前真实stock.post或funds.post动作
     *     副作用示例：usedQuantity0→1/version1；旧版本或超过真实原上限使整笔业务事务回滚。
     */
    void consume(CommonParam input, String action);

    /**
     * 完整冻结退款冲正只释放实际聚合占用；例如usedMinor2→0，上限不变，旧版本整笔回滚。
     *
     * @param input
     *     org901/id100000/version3/originalDetail1300001/source600000/kindRECEIPT_REFUND/amountMinor2
     */
    void releaseRefund(CommonParam input);

    /**
     * 完整退货逆转释放真实原ISSUE数量占用；例如used3→0，上限3不改，旧版本回滚。
     *
     * @param input
     *     org901/id100000/version3/originalDetail1300000/source600000/kindISSUE_RETURN/quantity3
     */
    void releaseReturn(CommonParam input);
}
