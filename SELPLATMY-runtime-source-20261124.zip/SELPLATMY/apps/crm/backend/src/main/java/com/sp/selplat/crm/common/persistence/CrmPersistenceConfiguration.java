/** CrmPersistenceConfiguration.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.common.db.datasource.BaseDataSourceContext;
import com.sp.selplat.common.db.sequence.CommonSequenceSegmentDao;
import com.sp.selplat.common.db.sequence.CommonSequenceSegmentDaoImpl;
import com.sp.selplat.common.db.sequence.model.CommonSequenceSegmentRange;
import com.sp.selplat.common.db.template.BaseTemplateDao;
import com.sp.selplat.common.db.template.BaseTemplateMapper;
import com.sp.selplat.crm.common.config.CrmIsolatedPersistentSourcePolicy;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.LocalCacheScope;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.transaction.SpringManagedTransactionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.nio.file.Files;
import java.nio.file.Path;

import javax.sql.DataSource;

/** 私人草稿使用本域限定连接池、模板上下文与事务；不改变宿主主数据源。 */
@Configuration(proxyBeanMethods = false)
@PropertySource("classpath:crm-module.properties")
public class CrmPersistenceConfiguration {

    /**
     * 在任何数据源单例创建前验证隔离测试的两套显式URL，防止属性回落默默创建文件库。
     *
     * @param environment 实际Spring配置，例如CRM/Uniauth分别指定mem:partner_crm、mem:partner_auth和对应expected
     *     URL
     * @return BeanFactory前置检查器；未请求持久测试时正式profile不执行本检查；显式持久测试还需专用标识和准确双文件URL
     * @throws IllegalStateException
     *     隔离profile缺URL、专用持久标识、冲销schema标识、预期不符或两库重名时，在DDL/种子前失败；冲销双文件缺CRM_SYNTHETIC_REVERSAL_V1标识拒绝，禁止升级旧测试库
     */
    @Bean
    public static org.springframework.beans.factory.config.BeanFactoryPostProcessor
            crmIsolatedSourceGuard(org.springframework.core.env.Environment environment) {
        return factory -> {
            boolean persistent = CrmIsolatedPersistentSourcePolicy.validate(environment);
            // 附件结构只进入显式双mem或既有协议已验证的专用双文件；正式默认库始终拒绝。
            if (orderAttachmentStructure(environment)
                    && (!java.util.Arrays.asList(environment.getActiveProfiles())
                                    .contains("crm-partner-maintenance-test")
                            || !environment.getProperty(
                                    "crm.order.isolated-enabled", Boolean.class, false)
                            || !environment.getProperty(
                                    "crm.partner.isolated-enabled", Boolean.class, false)
                            || (!persistent
                                    && (!environment
                                                    .getProperty("crm.datasource.jdbc-url", "")
                                                    .startsWith("jdbc:h2:mem:")
                                            || !environment
                                                    .getProperty("uniauth.datasource.jdbc-url", "")
                                                    .startsWith("jdbc:h2:mem:"))))) {
                throw new IllegalStateException("CRM_ORDER_ATTACHMENT_ISOLATED_SOURCE_REQUIRED");
            }
            if (orderAttachmentStructure(environment) && persistent) {
                Path marker =
                        Path.of(environment.getProperty("crm.isolated.persistence-directory"))
                                .resolve(".crm-isolated-order-attachment-schema");
                try {
                    if (!Files.isRegularFile(marker, java.nio.file.LinkOption.NOFOLLOW_LINKS)
                            || !Files.readString(marker)
                                    .equals(
                                            "CRM_SYNTHETIC_ORDER_ATTACHMENT_V1\n"
                                                    + environment.getProperty(
                                                            "crm.isolated.persistence-id")
                                                    + "\n")) {
                        throw new java.io.IOException(
                                "Explicit fresh attachment schema identity required");
                    }
                } catch (java.io.IOException failure) {
                    throw new IllegalStateException(
                            "CRM_ORDER_ATTACHMENT_SCHEMA_IDENTITY_REQUIRED", failure);
                }
            }

            if (reversalStructure(environment) && persistent) {
                Path marker =
                        Path.of(environment.getProperty("crm.isolated.persistence-directory"))
                                .resolve(".crm-isolated-reversal-schema");
                try {
                    if (!Files.isRegularFile(marker, java.nio.file.LinkOption.NOFOLLOW_LINKS)
                            || !Files.readString(marker)
                                    .equals(
                                            "CRM_SYNTHETIC_REVERSAL_V1\n"
                                                    + environment.getProperty(
                                                            "crm.isolated.persistence-id")
                                                    + "\n")) {
                        throw new java.io.IOException(
                                "Explicit fresh reversal schema identity required; no old database"
                                        + " upgrade");
                    }
                } catch (java.io.IOException failure) {
                    throw new IllegalStateException(
                            "CRM_REVERSAL_SCHEMA_IDENTITY_REQUIRED", failure);
                }
            }
            if (returnStructure(environment) && persistent) {
                Path marker =
                        Path.of(environment.getProperty("crm.isolated.persistence-directory"))
                                .resolve(".crm-isolated-sales-return-schema");
                try {
                    if (!Files.isRegularFile(marker, java.nio.file.LinkOption.NOFOLLOW_LINKS)
                            || !Files.readString(marker)
                                    .equals(
                                            "CRM_SYNTHETIC_SALES_RETURN_V1\n"
                                                    + environment.getProperty(
                                                            "crm.isolated.persistence-id")
                                                    + "\n")) {
                        throw new java.io.IOException(
                                "Explicit fresh sales-return schema identity required");
                    }
                } catch (java.io.IOException failure) {
                    throw new IllegalStateException(
                            "CRM_SALES_RETURN_SCHEMA_IDENTITY_REQUIRED", failure);
                }
            }
            if (stockReversalStructure(environment) && persistent) {
                Path marker =
                        Path.of(environment.getProperty("crm.isolated.persistence-directory"))
                                .resolve(".crm-isolated-stock-reversal-schema");
                try {
                    if (!Files.isRegularFile(marker, java.nio.file.LinkOption.NOFOLLOW_LINKS)
                            || !Files.readString(marker)
                                    .equals(
                                            "CRM_SYNTHETIC_STOCK_REVERSAL_V1\n"
                                                    + environment.getProperty(
                                                            "crm.isolated.persistence-id")
                                                    + "\n")) {
                        throw new java.io.IOException(
                                "Explicit fresh stock-reversal schema identity required");
                    }
                } catch (java.io.IOException failure) {
                    throw new IllegalStateException(
                            "CRM_STOCK_REVERSAL_SCHEMA_IDENTITY_REQUIRED", failure);
                }
            }
            if (!java.util.Arrays.asList(environment.getActiveProfiles())
                    .contains("crm-partner-maintenance-test")) {
                return;
            }
            String crm = environment.getProperty("crm.datasource.jdbc-url");
            String auth = environment.getProperty("uniauth.datasource.jdbc-url");
            String expectedCrm = environment.getProperty("crm.isolated.expected-crm-url");
            String expectedAuth = environment.getProperty("crm.isolated.expected-uniauth-url");
            if (crm == null
                    || auth == null
                    || (!persistent
                            && (!crm.startsWith("jdbc:h2:mem:")
                                    || !auth.startsWith("jdbc:h2:mem:")))
                    || !crm.equals(expectedCrm)
                    || !auth.equals(expectedAuth)
                    || crm.split(";", 2)[0].equals(auth.split(";", 2)[0])) {
                throw new IllegalStateException(
                        "CRM_ISOLATED_SOURCE_MISMATCH: explicit distinct expected isolated URLs"
                                + " required before initialization");
            }
        };
    }

    /**
     * @return 仅绑定 crm.datasource 的连接参数，例如 CrmDraftPool。
     */
    @Bean("crmHikariConfig")
    @ConfigurationProperties(prefix = "crm.datasource")
    public HikariConfig crmHikariConfig() {
        return new HikariConfig();
    }

    /**
     * 初始化本域新结构，不运行任何上传 SQL。 使用示例：隔离测试显式给jdbc:h2:mem:partner_crm，默认本地库仅用于原有草稿结构。
     *
     * @param config 本域参数，测试显式指定隔离内存 URL
     * @param environment 实际Spring配置，例如maintenance+stock-test及显式不同双memURL
     * @return 已初始化的私人草稿连接池
     * @throws Exception 无法定位本工程或初始化失败时阻断启动
     * @throws IllegalStateException 实际CRM URL与明确隔离预期不一致或找不到工程根时拒绝启动，不回退生产源
     */
    @Bean(name = "crmDataSource", destroyMethod = "close")
    public HikariDataSource crmDataSource(
            @Qualifier("crmHikariConfig") HikariConfig config,
            org.springframework.core.env.Environment environment)
            throws Exception {
        if (java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-partner-maintenance-test")
                && !java.util.Objects.equals(
                        config.getJdbcUrl(),
                        environment.getProperty("crm.isolated.expected-crm-url"))) {
            throw new IllegalStateException(
                    "CRM_ISOLATED_SOURCE_MISMATCH: actual CRM pool URL differs from explicit"
                            + " expectation");
        }
        // 空密码只允许明确的本域测试profile与实际命名内存URL，先于路径创建、建池及DDL。
        var profiles = java.util.Arrays.asList(environment.getActiveProfiles());
        boolean isolatedMemory =
                (profiles.contains("test")
                                || profiles.contains("crm-draft-contract-test")
                                || profiles.contains("crm-access-contract-test")
                                || profiles.contains("crm-partner-maintenance-test"))
                        && config.getJdbcUrl() != null
                        && config.getJdbcUrl().matches("jdbc:h2:mem:[A-Za-z0-9_\\-]+(?:;.*)?");
        if ((config.getPassword() == null || config.getPassword().isBlank()) && !isolatedMemory) {
            throw new IllegalStateException("CRM_DATASOURCE_PASSWORD_REQUIRED");
        }
        if (config.getJdbcUrl() == null || config.getJdbcUrl().isBlank()) {
            Path root = Path.of(System.getProperty("user.dir")).toAbsolutePath().normalize();
            while (root != null && !Files.isRegularFile(root.resolve("settings.gradle"))) {
                root = root.getParent();
            }
            if (root == null) {
                throw new IllegalStateException("无法定位 SELPLAT 工程根");
            }
            Path directory = root.resolve("private/production/db/crm");
            Files.createDirectories(directory);
            config.setJdbcUrl(
                    "jdbc:h2:file:"
                            + directory.resolve("crm")
                            + ";MODE=MySQL;DATABASE_TO_UPPER=false");
        }
        HikariDataSource dataSource = new HikariDataSource(config);
        try {
            ResourceDatabasePopulator scripts = new ResourceDatabasePopulator();
            String[] legacyTables =
                    stockStructure(environment)
                            ? new String[] {"CommonSequenceSegment"}
                            : new String[] {
                                "CommonSequenceSegment",
                                "CrmCustomerDraft",
                                "CrmOrderDraft",
                                "CrmOrderDraftLine",
                                "CrmDraftRequest",
                                "CrmPostingDocument",
                                "CrmStockBalance",
                                "CrmFundsBalance",
                                "CrmPostingEntry",
                                "CrmPostingRequest"
                            };
            for (String table : legacyTables) {
                scripts.addScript(new ClassPathResource("db/crm/sql/schema-" + table + ".sql"));
            }
            scripts.execute(dataSource);
            new org.springframework.transaction.support.TransactionTemplate(
                            new DataSourceTransactionManager(dataSource))
                    .executeWithoutResult(
                            transaction ->
                                    new ResourceDatabasePopulator(
                                                    new ClassPathResource(
                                                            "db/crm/sql/data-CommonSequenceSegment.sql"))
                                            .execute(dataSource));
            return dataSource;
        } catch (RuntimeException failure) {
            dataSource.close();
            throw failure;
        }
    }

    /**
     * 绑定固定业务 SQL 与公共模板的同一个连接池。
     *
     * @param dataSource 例如 crmDataSource
     * @return JdbcTemplate；事务内使用 Spring 绑定的同一连接 副作用示例：构造不执行 SQL、不建立独立事务。
     */
    @Bean("crmJdbcTemplate")
    public org.springframework.jdbc.core.JdbcTemplate crmJdbcTemplate(
            @Qualifier("crmDataSource") DataSource dataSource) {
        return new org.springframework.jdbc.core.JdbcTemplate(dataSource);
    }

    /**
     * 只允许显式测试 profile、内存 H2 与测试开关同时成立时写入。
     *
     * @param environment 例如 activeProfiles=[test]
     * @param source CRM 已初始化数据源，例如 jdbc:h2:mem:crm_posting_test
     * @return 隔离测试 true；生产、文件库、默认配置始终 false 副作用示例：不创建生产权限、不读取或迁移历史数据。
     */
    @Bean("crmPostingWriteEnabled")
    public Boolean crmPostingWriteEnabled(
            org.springframework.core.env.Environment environment,
            @Qualifier("crmDataSource") HikariDataSource source) {
        return java.util.Arrays.asList(environment.getActiveProfiles()).contains("test")
                && source.getJdbcUrl().startsWith("jdbc:h2:mem:")
                && environment.getProperty(
                        "crm.posting.isolated-write-enabled", Boolean.class, false);
    }

    /**
     * 限定客户维护隔离测试，尚无正式公共组织resolver时仅开放mem或通过专用标识验证的持久测试，不开放生产配置。
     *
     * @param environment 例如profile=test、crm-partner-maintenance-test且显式开关true
     * @param source 本域实际Hikari池，例如jdbc:h2:mem:crm_partner_test
     * @return 仅显式隔离条件全部满足true；默认/未标识文件库false 副作用示例：不生成权限、经营组织或客户种子。
     */
    @Bean("crmPartnerIsolatedEnabled")
    public Boolean crmPartnerIsolatedEnabled(
            org.springframework.core.env.Environment environment,
            @Qualifier("crmDataSource") HikariDataSource source) {
        return java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-partner-maintenance-test")
                && (source.getJdbcUrl().startsWith("jdbc:h2:mem:")
                        || CrmIsolatedPersistentSourcePolicy.matches(
                                environment, source.getJdbcUrl()))
                && environment.getProperty("crm.partner.isolated-enabled", Boolean.class, false);
    }

    /**
     * 订单额外隔离开关，缺正式授权不开放生产。
     *
     * @param enabled 真实双mem客户隔离前置结果，例如true
     * @param environment 显式订单开关，例如crm.order.isolated-enabled=true
     * @return 只有两个开关成立才true；默认false，不授予动作许可
     */
    @Bean("crmOrderIsolatedEnabled")
    public Boolean crmOrderIsolatedEnabled(
            @Qualifier("crmPartnerIsolatedEnabled") Boolean enabled,
            org.springframework.core.env.Environment environment) {
        return enabled
                && environment.getProperty("crm.order.isolated-enabled", Boolean.class, false);
    }

    /**
     * 初始化本步独立客户结构，只在显式隔离源测试门禁满足时执行本域新schema。
     *
     * @param enabled 例如测试三条件满足true，生产false
     * @param source 实际crmDataSource，不是上传SQL连接
     * @param environment 实际Spring配置，例如maintenance+stock-test及显式不同双memURL
     * @return 初始化完成标志，例如隔离测试true；生产未执行false 副作用示例：维护创建七表，stock专用隔离源选择十六表局部结构；不执行整包目标DDL、业务种子或迁移。
     * @throws IllegalStateException 例如既有Cmd表缺CRM_ORDER_ATTACHMENT_V1标识时，在附件DDL前拒绝；不升级旧约束
     */
    @Bean("crmPartnerMaintenanceInitialized")
    public Boolean crmPartnerMaintenanceInitialized(
            @Qualifier("crmPartnerIsolatedEnabled") Boolean enabled,
            @Qualifier("crmDataSource") HikariDataSource source,
            org.springframework.core.env.Environment environment) {
        if (!enabled) {
            return false;
        }
        // 既有未标识Cmd结构必须先拒绝，不允许CREATE IF NOT EXISTS掩盖未升级的旧约束。
        if (orderAttachmentStructure(environment)) {
            var existing =
                    new org.springframework.jdbc.core.JdbcTemplate(source)
                            .queryForList(
                                    "SELECT REMARKS FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=CURRENT_SCHEMA "
                                            + "AND TABLE_NAME='CrmCommandRequest'");
            if (!existing.isEmpty()
                    && !"CRM_ORDER_ATTACHMENT_V1".equals(existing.get(0).get("REMARKS"))) {
                throw new IllegalStateException("CRM_ORDER_ATTACHMENT_SOURCE_IDENTITY_MISMATCH");
            }
        }
        ResourceDatabasePopulator scripts = new ResourceDatabasePopulator();
        String[] tables =
                stockStructure(environment)
                        ? new String[] {
                            "CrmPartner",
                            "CrmContact",
                            "CrmProduct",
                            "CrmOrder",
                            "CrmOrderLine",
                            "CrmWarehouse",
                            "CrmOpeningBatch",
                            "CrmDocument",
                            "CrmDocumentLine",
                            "CrmStockBalance-v2",
                            "CrmPostingBatch",
                            "CrmPostingDetail",
                            "CrmOrderLineProgress",
                            "CrmPostingRequest-v2",
                            "CrmCommandRequest-v2",
                            "CrmBusinessAudit-v2"
                        }
                        : new String[] {
                            "CrmPartner",
                            "CrmContact",
                            "CrmProduct",
                            "CrmOrder",
                            "CrmOrderLine",
                            "CrmCommandRequest",
                            "CrmBusinessAudit"
                        };
        if (fundsStructure(environment)) {
            var expanded = new java.util.ArrayList<>(java.util.Arrays.asList(tables));
            expanded.add(expanded.indexOf("CrmDocument"), "CrmCashAccount");
            expanded.add(expanded.indexOf("CrmPostingBatch"), "CrmFundsBalance");
            tables = expanded.toArray(String[]::new);
        }
        if (reversalStructure(environment)) {
            var expanded = new java.util.ArrayList<>(java.util.Arrays.asList(tables));
            expanded.add(expanded.indexOf("CrmCommandRequest-v2"), "CrmFundsReversalRequest");
            expanded.add(expanded.indexOf("CrmOrderLineProgress"), "CrmPostingDependency");
            tables = expanded.toArray(String[]::new);
        }
        if (returnStructure(environment)) {
            var expanded = new java.util.ArrayList<>(java.util.Arrays.asList(tables));
            expanded.add(expanded.indexOf("CrmOrderLineProgress"), "CrmPostingCapacity");
            tables = expanded.toArray(String[]::new);
        }
        if (stockReversalStructure(environment)) {
            var expanded = new java.util.ArrayList<>(java.util.Arrays.asList(tables));
            expanded.add(expanded.indexOf("CrmCommandRequest-v2"), "CrmStockReversalRequest");
            tables = expanded.toArray(String[]::new);
        }
        if (orderAttachmentStructure(environment)) {
            var expanded = new java.util.ArrayList<>(java.util.Arrays.asList(tables));
            expanded.add("CrmOrderAttachment");
            tables = expanded.toArray(String[]::new);
        }
        for (String table : tables) {
            String schema =
                    table.endsWith("-v2")
                            ? "v2/schema-" + table.substring(0, table.length() - 3)
                            : "schema-" + table;
            if (fundsStructure(environment)
                    && java.util.Set.of(
                                    "CrmFundsBalance",
                                    "CrmDocument",
                                    "CrmDocumentLine",
                                    "CrmPostingDetail",
                                    "CrmCommandRequest-v2",
                                    "CrmBusinessAudit-v2")
                            .contains(table)) {
                schema = "funds/schema-" + table.replace("-v2", "");
            }
            if (reversalStructure(environment)
                    && java.util.Set.of(
                                    "CrmOrder",
                                    "CrmDocument",
                                    "CrmDocumentLine",
                                    "CrmPostingBatch",
                                    "CrmPostingDetail",
                                    "CrmPostingRequest-v2",
                                    "CrmCommandRequest-v2",
                                    "CrmBusinessAudit-v2")
                            .contains(table)) {
                schema = "fundsreversal/schema-" + table.replace("-v2", "");
            }
            if (returnStructure(environment) && "CrmPostingDetail".equals(table)) {
                schema = "salesreturn/schema-CrmPostingDetail";
            }
            if (stockReversalStructure(environment)
                    && java.util.Set.of("CrmCommandRequest-v2", "CrmBusinessAudit-v2")
                            .contains(table)) {
                schema = "stockreversal/schema-" + table.replace("-v2", "");
            }
            // 新附件专用命令枚举保留所有旧CASE；旧SQL文件及既有文件库不改。
            if (orderAttachmentStructure(environment) && table.startsWith("CrmCommandRequest")) {
                schema = "orderattachment/" + schema;
            }
            scripts.addScript(new ClassPathResource("db/crm/sql/" + schema + ".sql"));
        }
        if (reversalStructure(environment)) {
            scripts.addScript(
                    new ClassPathResource("db/crm/sql/fundsreversal/links-CrmDocumentLine.sql"));
        }
        // 唯一技术初始化清单；对应结构先创建，再只补缺，所有业务能力开关保持原样。
        scripts.execute(source);
        new org.springframework.transaction.support.TransactionTemplate(
                        new DataSourceTransactionManager(source))
                .executeWithoutResult(
                        transaction ->
                                new ResourceDatabasePopulator(
                                                new ClassPathResource(
                                                        "db/crm/sql/data-CommonSequenceSegment.sql"))
                                        .execute(source));
        return true;
    }

    /**
     * 方法作用：装配CRM具名事务，并只在实际事务中建立同步连接范围。
     *
     * @param dataSource 真实crmDataSource，例如隔离测试H2池大小4
     * @return SYNCHRONIZATION_ON_ACTUAL_TRANSACTION的DataSourceTransactionManager，例如库存原子动作绑定CRM连接
     *     异常或副作用示例：NOT_SUPPORTED身份读取及时归还辅助池连接；REQUIRES_NEW库存和号段仍独立绑定/提交，不提供跨库ACID。
     */
    @Bean("crmTransactionManager")
    public PlatformTransactionManager crmTransactionManager(
            @Qualifier("crmDataSource") DataSource dataSource) {
        DataSourceTransactionManager manager = new DataSourceTransactionManager(dataSource);
        // NOT_SUPPORTED不建立辅助数据源连接的空同步范围；真实CRM事务仍同步绑定与释放。
        // 两个并发请求的外层身份回查必须立即归还Uniauth连接，不悬挂到内层REQUIRES_NEW结束。
        manager.setTransactionSynchronization(
                org.springframework.transaction.support.AbstractPlatformTransactionManager
                        .SYNCHRONIZATION_ON_ACTUAL_TRANSACTION);
        return manager;
    }

    /**
     * @param dataSource 与模板 Mapper 共用的 CRM 数据源
     * @return CRM DAO 唯一上下文；不借用 Uniauth 的模板连接 业务示例：本域CRM连接池和公共号段组件，不与Uniauth池混用。
     */
    @Bean("crmBaseDataSourceContext")
    public BaseDataSourceContext crmBaseDataSourceContext(
            @Qualifier("crmDataSource") DataSource dataSource) {
        org.apache.ibatis.session.Configuration configuration =
                new org.apache.ibatis.session.Configuration();
        // 事务内等待/重验不得复用首次 SELECT 的会话缓存；每条语句读取当前数据库事实。
        configuration.setLocalCacheScope(LocalCacheScope.STATEMENT);
        configuration.setEnvironment(
                new Environment(
                        "crm-private-drafts", new SpringManagedTransactionFactory(), dataSource));
        configuration.addMapper(BaseTemplateMapper.class);
        SqlSessionTemplate sessions =
                new SqlSessionTemplate(new SqlSessionFactoryBuilder().build(configuration));
        return new BaseDataSourceContext(
                dataSource,
                new BaseTemplateDao(sessions.getMapper(BaseTemplateMapper.class), dataSource));
    }

    /**
     * @param dataSource 私库号段来源
     * @return 使用公共号段实现及独立提交边界的本域号段 DAO 业务示例：本域CRM连接池和公共号段组件，不与Uniauth池混用。
     */
    @Bean("crmCommonSequenceSegmentDao")
    public CommonSequenceSegmentDao crmCommonSequenceSegmentDao(
            @Qualifier("crmDataSource") DataSource dataSource) {
        return new CrmTransactionalSequenceSegmentDao(dataSource);
    }

    /** 配置装配的公共号段实现只增加本域事务边界，不重写 SQL 或号段算法。 */
    public static class CrmTransactionalSequenceSegmentDao extends CommonSequenceSegmentDaoImpl {
        /**
         * 绑定具名连接池。
         *
         * @param source CRM 数据源，例如 crmDataSource 副作用示例：构造不推进号段，不改变其他项目的首选数据源。
         */
        public CrmTransactionalSequenceSegmentDao(DataSource source) {
            super(source);
        }

        /**
         * 独立提交公共号段推进，防业务回滚后缓存区间重复。
         *
         * @param sequenceCode 本域稳定号段，例如 CrmOrderDraftId
         * @return 公共申请结果或竞争失败时 null 副作用示例：只提交 CommonSequenceSegment 游标，业务记录仍由外层事务管理。
         */
        @Override
        @Transactional(
                transactionManager = "crmTransactionManager",
                propagation = Propagation.REQUIRES_NEW)
        public CommonSequenceSegmentRange allocateNextRange(String sequenceCode) {
            return super.allocateNextRange(sequenceCode);
        }
    }

    /**
     * 明确隔离结构选择；不是生产结构升级。
     *
     * @param environment 实际profile及显式开关，例如maintenance+stock-test、stock=true
     * @return 两profile与开关同时成立才使用V2库存结构；默认false保留旧结构
     */
    private static boolean stockStructure(org.springframework.core.env.Environment environment) {
        var profiles = java.util.Arrays.asList(environment.getActiveProfiles());
        return profiles.contains("crm-stock-maintenance-test")
                && profiles.contains("crm-partner-maintenance-test")
                && environment.getProperty("crm.stock.isolated-enabled", Boolean.class, false);
    }

    /**
     * 额外库存隔离检查；构造不授予权限。
     *
     * @param enabled 实际客户隔离门禁，例如true
     * @param environment 明确stock测试profile及开关
     * @return 只有结构隔离和客户源检查都成立才true；生产false
     */
    @Bean("crmStockIsolatedEnabled")
    public Boolean crmStockIsolatedEnabled(
            @Qualifier("crmPartnerIsolatedEnabled") Boolean enabled,
            org.springframework.core.env.Environment environment) {
        return enabled && stockStructure(environment);
    }

    /**
     * Explicit funds structure requires the existing guarded stock structure as well.
     *
     * @param environment e.g. funds profile with funds=true and distinct expected memory sources
     * @return true only for the isolated receipt ledger; production false
     */
    private static boolean fundsStructure(org.springframework.core.env.Environment environment) {
        return stockStructure(environment)
                && java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-funds-maintenance-test")
                && environment.getProperty("crm.funds.isolated-enabled", Boolean.class, false);
    }

    /**
     * 方法作用及真实业务示例：装配额外资金隔离门禁；客户源检查true及funds/stock/maintenance测试开关；仅明确不同双mem返回true；生产返回false，不授予任何动作。
     * Isolated receipt gate does not grant any action.
     *
     * @param enabled guarded partner sources e.g. true
     * @param environment explicit funds test properties
     * @return false in production, true only for the dedicated synthetic ledger
     */
    @Bean("crmFundsIsolatedEnabled")
    public Boolean crmFundsIsolatedEnabled(
            @Qualifier("crmPartnerIsolatedEnabled") Boolean enabled,
            org.springframework.core.env.Environment environment) {
        return enabled && fundsStructure(environment);
    }

    /**
     * 方法作用：识别额外冲正隔离结构。
     *
     * @param environment 例如reversal profile与显式开关true
     * @return 仅已满足资金结构且冲正两条件全满足true；生产false 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    private static boolean reversalStructure(org.springframework.core.env.Environment environment) {
        return fundsStructure(environment)
                && java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-funds-reversal-test")
                && environment.getProperty(
                        "crm.funds.reversal.isolated-enabled", Boolean.class, false);
    }

    /**
     * 方法作用：装配冲正测试门禁。
     *
     * @param enabled 实际资金隔离门禁true
     * @param environment 明确冲正profile及开关
     * @return 测试双mem为true，默认false，无权限授予 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Bean("crmFundsReversalIsolatedEnabled")
    public Boolean crmFundsReversalIsolatedEnabled(
            @Qualifier("crmFundsIsolatedEnabled") Boolean enabled,
            org.springframework.core.env.Environment environment) {
        return enabled && reversalStructure(environment);
    }

    /**
     * 识别显式一期销售退货测试结构；旧profile与生产保持关闭。
     *
     * @param environment 例如crm-sales-return-test及显式isolated-enabled=true
     * @return 三结构/profile/开关全满足时true；默认false，不授予业务权限
     */
    private static boolean returnStructure(org.springframework.core.env.Environment environment) {
        return reversalStructure(environment)
                && java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-sales-return-test")
                && environment.getProperty(
                        "crm.sales-return.isolated-enabled", Boolean.class, false);
    }

    /**
     * 装配仅本域显式销售退货结构门禁，不开放生产或注册任何权限。
     *
     * @param enabled 已核真实资金冲正隔离门禁，例如true
     * @param environment 显式退货profile及开关
     * @return 测试条件全满足true；普通或生产环境false
     */
    @Bean("crmSalesReturnIsolatedEnabled")
    public Boolean crmSalesReturnIsolatedEnabled(
            @Qualifier("crmFundsReversalIsolatedEnabled") Boolean enabled,
            org.springframework.core.env.Environment environment) {
        return enabled && returnStructure(environment);
    }

    /**
     * 新库存冲正只在新建明确退货/资金冲正结构中开放；例如专用profile及显式true返回true，生产false。
     *
     * @param environment 实际配置，不读取客户端字段
     * @return 新隔离结构是否完整准入，不放宽生产权限
     */
    private static boolean stockReversalStructure(
            org.springframework.core.env.Environment environment) {
        return returnStructure(environment)
                && java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-stock-reversal-test")
                && environment.getProperty(
                        "crm.stock.reversal.isolated-enabled", Boolean.class, false);
    }

    /**
     * 库存REVERSE动作声明门禁；例如明确专用新结构true，正常生产始终false。
     *
     * @param environment 实际服务器配置
     * @return 隔离结构开关，不授予账户动作许可
     */
    @Bean("crmStockReversalIsolatedEnabled")
    public Boolean crmStockReversalIsolatedEnabled(
            org.springframework.core.env.Environment environment) {
        return stockReversalStructure(environment);
    }

    /**
     * 方法作用：辨识专用附件测试结构，不根据登录或默认配置打开。
     *
     * @param environment 例如profile=crm-order-attachment-test且显式binding-enabled=true
     * @return 两个显式条件同时成立true，否则false；不授予许可 异常或副作用示例：只有调用前置源守卫通过后才能创建专用内存结构，不迁移文件库。
     */
    private static boolean orderAttachmentStructure(
            org.springframework.core.env.Environment environment) {
        return java.util.Arrays.asList(environment.getActiveProfiles())
                        .contains("crm-order-attachment-test")
                && environment.getProperty("crm.orderfile.binding-enabled", Boolean.class, false);
    }

    /**
     * 方法作用：暴露结构/真实隔离门禁的交集，正式Host默认false。
     *
     * @param orders 实际crmOrderIsolatedEnabled，例如true
     * @param initialized 实际crmPartnerMaintenanceInitialized，例如true
     * @param environment 专用附件profile和显式开关
     * @return 显式双mem或已验证专用双文件true，其他环境false；不是动作授权 副作用示例：只返回门禁状态，不创建账号/权限或业务记录。
     */
    @Bean("crmOrderAttachmentEnabled")
    public Boolean crmOrderAttachmentEnabled(
            @Qualifier("crmOrderIsolatedEnabled") Boolean orders,
            @Qualifier("crmPartnerMaintenanceInitialized") Boolean initialized,
            org.springframework.core.env.Environment environment) {
        return orders && initialized && orderAttachmentStructure(environment);
    }
}
