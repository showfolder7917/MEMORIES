/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.document.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmDocumentDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 只读定位实际同范围来源。
     *
     * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    Map<String, Object> sourceReference(CommonParam input);

    /**
     * DRAFT头CAS。
     *
     * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    int updateDraft(CommonParam input);

    /**
     * 状态及冻结版本CAS。
     *
     * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    int transition(CommonParam input);
}
