/** 完整销售收款冲正；2026-10-03，Codex；只调用本表owning服务，正式权限未开放；2026-10-09空请求沿原身份及组织拒绝合同。 */
package com.sp.selplat.crm.capability.fundsreversal.service.impl;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.fundsreversal.service.CrmFundsReversalService;
import com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** Order/Line→Document→申请→Progress→批次依赖→账户；一个CRM事务承载全部反向效果。 */
@org.springframework.stereotype.Service
public class CrmFundsReversalServiceImpl implements CrmFundsReversalService {
    // 真实Session和组织动作准入，不能从请求绑定可信身份。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    // 真实冻结原收款头行及原单状态，禁止供应商退款复用。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.document.service.CrmDocumentService documents;

    // 实际原单行和退款下游引用，只通过owning服务读取。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.documentline.service.CrmDocumentLineService lines;

    // 独立冲正申请及异人审核状态，不能自批。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.fundsreversalrequest.service.CrmFundsReversalRequestService
            applications;

    // 真实不可变下游边，阻止有有效下游的冲正。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService dependencies;

    // 原POST和完整REVERSE批次owning入口。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService batches;

    // 全部原与反向流水，复合引用不截断。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService details;

    // 组织同账户币种余额锁与固定减额CAS。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.fundsbalance.service.CrmFundsBalanceService balances;

    // 冻结来源正向结算计数及完整冲正回算。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.orderlineprogress.service.CrmOrderLineProgressService progress;

    // 申请/审核非过账幂等首次结果。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService commands;

    // 完整冲正批次请求与首次响应。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService requests;

    // 与业务同CRM事务的实际操作者审计。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;

    // CRM具名事务管理器，保留原传播和隔离级别。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
    private org.springframework.transaction.PlatformTransactionManager manager;

    // 独立冲正测试结构开关，生产默认拒绝。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmFundsReversalIsolatedEnabled")
    private Boolean enabled;

    /** 方法作用：要求独立冲正结构开关。 副作用示例：未显式启用时CRM_SCOPE_UNAVAILABLE，在查新表前停止，不改旧profile。 */
    private void gate() {
        if (!Boolean.TRUE.equals(enabled)) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
    }

    /**
     * 方法作用：建立内部关系参数，不复制客户端可信身份。
     *
     * @param input org901
     * @param key 服务器固定id/documentId等字段
     * @param value 实际主键1200000
     * @return 新参数；无SQL副作用。
     */
    private CommonParam relation(CommonParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 方法作用：规范严格具名输入并拒绝客户端金额、审核人和摘要。
     *
     * @param input 原单/原批次/版本/key及申请引用或原因
     * @param mode request、approve或execute
     * @return 规范正数主键和整数版本；字段遗漏、未知字段、非REVERSE或空原因拒绝，无写入。
     */
    private CommonParam normalize(CommonParam input, String mode) {
        Set<String> fields =
                new HashSet<>(
                        Set.of(
                                "organizationCandidateId",
                                "id",
                                "originalBatchId",
                                "expectedVersion",
                                "requestKey"));
        if ("request".equals(mode)) {
            fields.add("reasonText");
        } else {
            fields.addAll(Set.of("reversalRequestId", "expectedReversalVersion"));
        }
        if ("execute".equals(mode)) {
            fields.add("action");
        }
        if (input == null || !fields.equals(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
        }
        var p = new CommonParam();
        for (String f : List.of("organizationCandidateId", "id", "originalBatchId")) {
            p.putParam(f, CrmPartnerValueSupport.positive(input.getParam(f)));
        }
        p.putParam(
                "expectedVersion",
                CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        var keyInput = new CommonParam();
        keyInput.putParam("organizationCandidateId", p.getParam("organizationCandidateId"));
        keyInput.putParam("requestKey", input.getParam("requestKey"));
        p.putParam(
                "requestKey", CrmOrderValueSupport.command(keyInput, false).getParam("requestKey"));
        if ("request".equals(mode)) {
            Object reason = input.getParam("reasonText");
            if (!(reason instanceof String text) || text.isBlank() || text.length() > 500) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
            }
            p.putParam("reasonText", text.trim());
        } else {
            p.putParam(
                    "reversalRequestId",
                    CrmPartnerValueSupport.positive(input.getParam("reversalRequestId")));
            p.putParam(
                    "expectedReversalVersion",
                    CrmPartnerValueSupport.version(input.getParam("expectedReversalVersion")));
        }
        if ("execute".equals(mode)) {
            if (!"REVERSE".equals(input.getParam("action"))) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
            }
            p.putParam("action", "REVERSE");
        }
        return p;
    }

    /**
     * 方法作用：开启独立CRM READ_COMMITTED原子事务。
     *
     * @return 实际事务模板；只有号段独立提交允许失败后技术性空号。
     */
    private org.springframework.transaction.support.TransactionTemplate transaction() {
        var t = new org.springframework.transaction.support.TransactionTemplate(manager);
        t.setPropagationBehavior(
                org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        t.setIsolationLevel(
                org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
        return t;
    }

    /**
     * 方法作用：核实原POST头和全部冻结CASH明细，并派生完整摘要。
     *
     * @param p org901/id1000000/originalBatch1200000/expected3
     * @param action 当前真实reverse或approve
     * @return 真实原单、批次和完整明细/金额/摘要；少行、错批次、非现金或修改冻结拒绝，无资金效果。
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> original(CommonParam p, String action) {
        var head = documents.prepareFundsReverse(p, action);
        var candidates =
                batches.findForDocument(relation(p, "documentId", head.get("id")), action).stream()
                        .filter(row -> p.getParam("originalBatchId").equals(row.get("id")))
                        .toList();
        if (candidates.size() != 1) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var batch = candidates.get(0);
        if (!"POST".equals(batch.get("action"))
                || !head.get("id").equals(batch.get("documentId"))
                || !head.get("approvedSnapshotHash").equals(batch.get("approvedSnapshotHash"))) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        var values = details.readHistory(relation(p, "batchId", batch.get("id")), action);
        List<Map<String, Object>> rows = (List<Map<String, Object>>) head.get("lines");
        if (values.size() != rows.size()
                || values.size() != ((Number) batch.get("detailCount")).intValue()) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        Map<Long, Map<String, Object>> byId = new HashMap<>();
        for (var line : rows) {
            byId.put(((Number) line.get("id")).longValue(), line);
        }
        BigDecimal total = BigDecimal.ZERO;
        List<Map<String, Object>> canonical = new ArrayList<>();
        for (var detail : values) {
            var line = byId.remove(((Number) detail.get("documentLineId")).longValue());
            if (line == null
                    || !"POST".equals(detail.get("action"))
                    || !"CASH".equals(detail.get("effectKind"))) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            for (String f : List.of("sourceOrderLineId", "accountId", "currency", "lineNo")) {
                if (!line.get(f).equals(detail.get(f))) {
                    throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
                }
            }
            var amount = originalAmount(head, detail);
            if (amount.compareTo(new BigDecimal(line.get("amountMinor").toString())) != 0) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            total = total.add(amount);
            var selected = new TreeMap<String, Object>();
            var view = CrmStockValueSupport.browser(detail);
            for (String f :
                    List.of(
                            "id",
                            "batchId",
                            "documentId",
                            "documentLineId",
                            "sourceOrderLineId",
                            "lineNo",
                            "fundsBalanceId",
                            "accountId",
                            "currency",
                            "amountDeltaMinor",
                            "action")) {
                selected.put(f, view.get(f));
            }
            canonical.add(selected);
        }
        if (total.precision() > 38) {
            throw CrmPartnerValueSupport.failure("FUNDS_AMOUNT_OVERFLOW");
        }
        var out = new LinkedHashMap<String, Object>();
        out.put("head", head);
        out.put("batch", batch);
        out.put("details", values);
        out.put("totalMinor", total);
        out.put(
                "digest",
                CrmOrderValueSupport.hash(
                        Map.of(
                                "originalSnapshotHash",
                                head.get("approvedSnapshotHash"),
                                "details",
                                canonical)));
        return out;
    }

    /**
     * 方法作用：比较申请冻结的原始事实与当前真实批次。
     *
     * @param app 实际申请1700000
     * @param facts 当前真实原批次完整事实
     * @param p 客户端原单/批次/申请候选 副作用示例：任何引用、原版本、币种、金额或摘要变更CRM_REVERSAL_SOURCE_CHANGED，全事务回滚。
     */
    @SuppressWarnings("unchecked")
    private void match(Map<String, Object> app, Map<String, Object> facts, CommonParam p) {
        var head = (Map<String, Object>) facts.get("head");
        if (!app.get("id").equals(p.getParam("reversalRequestId"))
                || !app.get("originalDocumentId").equals(head.get("id"))
                || !app.get("originalBatchId").equals(p.getParam("originalBatchId"))
                || !app.get("originalDocumentVersion").equals(head.get("versionNo"))
                || !app.get("originalSnapshotHash").equals(head.get("approvedSnapshotHash"))
                || !app.get("originalBatchDigest").equals(facts.get("digest"))
                || !app.get("currency").equals(head.get("currency"))
                || new BigDecimal(app.get("totalMinor").toString())
                                .compareTo((BigDecimal) facts.get("totalMinor"))
                        != 0) {
            throw CrmPartnerValueSupport.failure("CRM_REVERSAL_SOURCE_CHANGED");
        }
    }

    /**
     * 方法作用：从实际批次和全部严格相反明细派生子POST是否仍有效。
     *
     * @param p org901
     * @param post 实际子POST批次
     * @return
     *     无完整已提交反向批次true；完整反向且原批准摘要/每行行号一致后false；摘要或行号改变、非法或不完整反向拒绝CRM_DEPENDENCY_INTEGRITY，人工status/state不参与。
     */
    private boolean active(CommonParam p, Map<String, Object> post) {
        var history =
                batches.findForDocument(
                        relation(p, "documentId", post.get("documentId")), "crm.funds.reverse");
        var reverses =
                history.stream()
                        .filter(
                                b ->
                                        "REVERSE".equals(b.get("action"))
                                                && post.get("id").equals(b.get("originalBatchId")))
                        .toList();
        var before = details.readAll(relation(p, "batchId", post.get("id")), "crm.funds.reverse");
        var after =
                reverses.size() == 1
                        ? details.readAll(
                                relation(p, "batchId", reverses.get(0).get("id")),
                                "crm.funds.reverse")
                        : List.<Map<String, Object>>of();
        return com.sp.selplat.crm.common.util.frozen.CrmFrozenExecutionSupport.effective(
                post, before, reverses, after);
    }

    /**
     * 方法作用：检查实际FK图和实际baseReceipt引用的所有已提交下游。
     *
     * @param p org901
     * @param values 原批次所有真实POST明细
     *     副作用示例：REFUND_FOR_RECEIPT必须是同来源CASH子明细，STOCK伪装CRM_DEPENDENCY_INTEGRITY；任何有效已记账子批次POSTING_DOWNSTREAM_ACTIVE，即使账户足够或人工status=0；不声称实现未来退款工作流。
     */
    private void downstream(CommonParam p, List<Map<String, Object>> values) {
        for (var parent : values) {
            var q = relation(p, "parentDetailId", parent.get("id"));
            for (var edge : dependencies.parentEdges(q)) {
                var child =
                        details.lockScoped(
                                relation(p, "id", edge.get("childDetailId")), "crm.funds.reverse");
                if (!"REFUND_FOR_RECEIPT".equals(edge.get("dependencyKind"))
                        || !"CASH".equals(child.get("effectKind"))
                        || !parent.get("sourceOrderLineId")
                                .equals(child.get("sourceOrderLineId"))) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                var batch =
                        batches.lockScoped(
                                relation(p, "id", child.get("batchId")), "crm.funds.reverse");
                if (active(p, batch)) {
                    throw CrmPartnerValueSupport.failure("POSTING_DOWNSTREAM_ACTIVE");
                }
            }
            for (var line : lines.receiptChildren(q)) {
                if (!parent.get("sourceOrderLineId").equals(line.get("sourceOrderLineId"))) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                for (var batch :
                        batches.findForDocument(
                                relation(p, "documentId", line.get("documentId")),
                                "crm.funds.reverse")) {
                    if (!"POST".equals(batch.get("action"))) {
                        continue;
                    }
                    var childRows =
                            details.readAll(
                                    relation(p, "batchId", batch.get("id")), "crm.funds.reverse");
                    if (childRows.stream()
                                    .anyMatch(d -> line.get("id").equals(d.get("documentLineId")))
                            && active(p, batch)) {
                        throw CrmPartnerValueSupport.failure("POSTING_DOWNSTREAM_ACTIVE");
                    }
                }
            }
        }
    }

    /**
     * 方法作用：读取真实整批原金额及当前申请和账户反向影响。
     *
     * @param input org901/id1000000
     * @return
     *     totalMinor135/cashDeltaMinor-135/settledDeltaMinor-135/unsettledDeltaMinor135和实际账户；无写入，旧profile先拒绝。
     *     业务示例：组织901、原收款1000000、批次1200000；返回totalMinor=135、cashDeltaMinor=-135、unsettledDeltaMinor=135，不写资金。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.REQUIRES_NEW,
            readOnly = true)
    @SuppressWarnings("unchecked")
    public CommonResult preview(CommonParam input) {
        gate();
        // 空预览请求保留原真实身份及组织拒绝合同，不先解引用字段产生NPE。
        var scope =
                access.requireFundsScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
        if (!input.getParamMap().keySet().equals(Set.of("organizationCandidateId", "id"))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_REVERSAL_INPUT");
        }
        var head = documents.readFundsForReversal(input);
        var history =
                batches.findForDocument(
                        relation(
                                input,
                                "documentId",
                                CrmPartnerValueSupport.positive(input.getParam("id"))),
                        "crm.funds.read");
        var posts = history.stream().filter(b -> "POST".equals(b.get("action"))).toList();
        if (posts.size() != 1) {
            throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
        }
        var batch = posts.get(0);
        var values = details.readAll(relation(input, "batchId", batch.get("id")), "crm.funds.read");
        if (values.size() != ((Number) batch.get("detailCount")).intValue() || values.isEmpty()) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        BigDecimal total = BigDecimal.ZERO;
        Map<Long, BigDecimal> accountAmounts = new TreeMap<>();
        for (var d : values) {
            if (!"CASH".equals(d.get("effectKind"))) {
                throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
            }
            var amount = originalAmount(head, d);
            total = total.add(amount);
            accountAmounts.merge(
                    ((Number) d.get("accountId")).longValue(), amount, BigDecimal::add);
        }
        var data = new LinkedHashMap<String, Object>();
        data.put("documentId", head.get("id"));
        data.put("documentVersion", head.get("versionNo"));
        data.put("documentState", head.get("documentState"));
        data.put("originalBatchId", batch.get("id").toString());
        data.put("totalMinor", total.toPlainString());
        data.put("currency", head.get("currency"));
        data.put("cashDeltaMinor", (refund(head) ? total : total.negate()).toPlainString());
        data.put("settledDeltaMinor", refund(head) ? "0" : total.negate().toPlainString());
        data.put("refundedDeltaMinor", refund(head) ? total.negate().toPlainString() : "0");
        data.put("unsettledDeltaMinor", refund(head) ? "0" : total.toPlainString());
        data.put(
                "accountEffects",
                accountAmounts.entrySet().stream()
                        .map(
                                e ->
                                        Map.of(
                                                "accountId",
                                                e.getKey().toString(),
                                                "cashDeltaMinor",
                                                (refund(head)
                                                                ? e.getValue()
                                                                : e.getValue().negate())
                                                        .toPlainString()))
                        .toList());
        var app =
                applications.forOriginal(
                        relation(input, "originalBatchId", batch.get("id")), "crm.funds.read");
        if (app != null) {
            var view = CrmStockValueSupport.browser(app);
            view.put(
                    "canApprove",
                    "SUBMITTED".equals(app.get("requestState"))
                            && !scope.get("actorUserId").equals(app.get("submittedByUserId")));
            data.put("application", view);
        }
        data.put("synthetic", true);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：完成申请命令首次结果和唯一审计。
     *
     * @param p 规范命令引用
     * @param command FUNDS_REVERSAL_REQUEST或APPROVE
     * @param requestId 当前真实claim主键
     * @param app 当前真实申请
     * @param previous 原版本或null
     * @return 精确首次申请JSON；权限撤销/请求完成/审计失败同事务回滚。
     */
    private CommonResult finish(
            CommonParam p, String command, long requestId, Map<String, Object> app, Long previous) {
        access.requireFundsScope(
                p.getParam("organizationCandidateId"),
                CrmPartnerValueSupport.commandAction(command));
        var data = CrmStockValueSupport.browser(app);
        data.put("replay", false);
        data.put("synthetic", true);
        var req = command(p, command);
        req.putParam("id", requestId);
        req.putParam("resultReversalRequestId", app.get("id"));
        req.putParam("resultVersionNo", app.get("versionNo"));
        req.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
        commands.complete(req);
        var event = relation(p, "commandRequestId", requestId);
        event.putParam("action", command);
        event.putParam("resourceId", app.get("id"));
        event.putParam("previousVersion", previous);
        event.putParam("newVersion", app.get("versionNo"));
        audit.append(event);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：服务器派生幂等命令摘要。
     *
     * @param p 规范完整申请引用/原因
     * @param name 固定命令名称
     * @return key/hash；不含真实actor、不由客户端提交hash。
     */
    private CommonParam command(CommonParam p, String name) {
        var req = relation(p, "commandName", name);
        req.putParam("requestKey", p.getParam("requestKey"));
        req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
        return req;
    }

    /**
     * 方法作用：回滚失败claim事务后读取首次已提交申请响应。
     *
     * @param p 规范命令
     * @param name 固定申请/审核命令
     * @param operation 实际事务业务函数
     * @return 首次真实结果或same-key首次快照replay=true；不同内容、撤权拒绝。
     */
    private CommonResult writeCommand(
            CommonParam p, String name, java.util.function.LongFunction<CommonResult> operation) {
        var req = command(p, name);
        try {
            return transaction()
                    .execute(
                            tx -> {
                                access.requireFundsScope(
                                        p.getParam("organizationCandidateId"),
                                        CrmPartnerValueSupport.commandAction(name));
                                documents.requireFundsReverseReference(
                                        p, CrmPartnerValueSupport.commandAction(name));
                                return operation.apply(commands.claim(req));
                            });
        } catch (CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            return replay(commands.committed(req), req);
        }
    }

    /**
     * 方法作用：只返回已完成同内容首次快照。
     *
     * @param stored 真实已提交请求或null
     * @param req 服务器规范key/hash
     * @return replay=true首次结果；差内容或未完成拒绝，不新增流水。
     */
    @SuppressWarnings("unchecked")
    private CommonResult replay(Map<String, Object> stored, CommonParam req) {
        if (stored == null || !req.getParam("payloadHash").equals(stored.get("payloadHash"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
        }
        if (!"COMPLETED".equals(stored.get("requestState"))) {
            throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
        }
        var data =
                JsonUtils.fromJson(
                        (String) CrmStockValueSupport.browser(stored).get("responseSnapshot"),
                        Map.class);
        data.put("replay", true);
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 方法作用：提交并冻结整批冲正申请，保留原审批。
     *
     * @param input 原单1000000/批次1200000/expected3/reasonText/key
     * @return SUBMITTED申请1700000/version0；原现金和进度不变，重复key重放。
     *     业务示例：org901、原单1000000、批次1200000、expectedVersion=3、原因“合成完整冲正”；返回申请1700000、SUBMITTED/version0。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    @SuppressWarnings("unchecked")
    public CommonResult request(CommonParam input) {
        gate();
        // 空请求作为缺失组织候选传入原资金准入，真实身份、隔离开关和动作检查仍先执行。
        access.requireFundsScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var p = normalize(input, "request");
        return writeCommand(
                p,
                "FUNDS_REVERSAL_REQUEST",
                requestId -> {
                    var facts = original(p, "crm.funds.reverse");
                    if (applications.forOriginal(
                                    relation(p, "originalBatchId", p.getParam("originalBatchId")),
                                    "crm.funds.reverse")
                            != null) {
                        throw CrmPartnerValueSupport.failure("CRM_REVERSAL_ALREADY_REQUESTED");
                    }
                    var head = (Map<String, Object>) facts.get("head");
                    var submit = relation(p, "originalDocumentId", head.get("id"));
                    submit.putParam("originalBatchId", p.getParam("originalBatchId"));
                    submit.putParam("originalDocumentVersion", head.get("versionNo"));
                    submit.putParam("originalSnapshotHash", head.get("approvedSnapshotHash"));
                    submit.putParam("originalBatchDigest", facts.get("digest"));
                    submit.putParam("totalMinor", facts.get("totalMinor"));
                    submit.putParam("currency", head.get("currency"));
                    submit.putParam("reasonText", p.getParam("reasonText"));
                    long id = applications.submit(submit);
                    return finish(
                            p,
                            "FUNDS_REVERSAL_REQUEST",
                            requestId,
                            applications.lockScoped(relation(p, "id", id), "crm.funds.reverse"),
                            null);
                });
    }

    /**
     * 方法作用：另一真实用户重核原事实并审核申请。
     *
     * @param input 原单/批次/申请1700000/expected3/expectedReversal0/key
     * @return APPROVED/version1；申请者自审、原事实变更或末尾失败拒绝，资金无效果。
     *     业务示例：用户9212审核用户9211提交的申请1700000、expectedReversalVersion=0；返回APPROVED/version1，自审拒绝。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult approve(CommonParam input) {
        gate();
        // 空请求作为缺失组织候选传入原资金准入，真实身份、隔离开关和动作检查仍先执行。
        access.requireFundsScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.approve");
        var p = normalize(input, "approve");
        return writeCommand(
                p,
                "FUNDS_REVERSAL_APPROVE",
                requestId -> {
                    var facts = original(p, "crm.funds.approve");
                    var app =
                            applications.lockScoped(
                                    relation(p, "id", p.getParam("reversalRequestId")),
                                    "crm.funds.approve");
                    match(app, facts, p);
                    var change = relation(p, "id", app.get("id"));
                    change.putParam("expectedVersion", p.getParam("expectedReversalVersion"));
                    return finish(
                            p,
                            "FUNDS_REVERSAL_APPROVE",
                            requestId,
                            applications.transition(change, false),
                            ((Number) app.get("versionNo")).longValue());
                });
    }

    /**
     * 方法作用：完整反向登记原批次N条，余额和来源已收单次聚合CAS。
     *
     * @param input 原单/批次/申请/expected3/expectedReversal1/actionREVERSE/key
     * @return 新REVERSE头和全部新明细；无有效下游、足额余额、真实权限与双版本重核后提交，任一步失败全回滚。
     *     业务示例：org901、原单1000000、申请1700000/version1、action=REVERSE；返回新批次1200001、全部相反明细及REVERSED/version4，余额1135恢复1000。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    @SuppressWarnings("unchecked")
    public CommonResult execute(CommonParam input) {
        gate();
        // 空请求作为缺失组织候选传入原资金准入，真实身份、隔离开关和动作检查仍先执行。
        access.requireFundsScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var p = normalize(input, "execute");
        var req = relation(p, "documentId", p.getParam("id"));
        req.putParam("requestKey", p.getParam("requestKey"));
        req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
        try {
            return transaction()
                    .execute(
                            tx -> {
                                access.requireFundsScope(
                                        p.getParam("organizationCandidateId"), "crm.funds.reverse");
                                documents.requireFundsReverseReference(p, "crm.funds.reverse");
                                long requestId = requests.claimOrganizationFundsReverse(req);
                                var facts = original(p, "crm.funds.reverse");
                                var head = (Map<String, Object>) facts.get("head");
                                var app =
                                        applications.lockScoped(
                                                relation(p, "id", p.getParam("reversalRequestId")),
                                                "crm.funds.reverse");
                                match(app, facts, p);
                                if (!"APPROVED".equals(app.get("requestState"))
                                        || ((Number) app.get("versionNo")).longValue()
                                                != ((Number) p.getParam("expectedReversalVersion"))
                                                        .longValue()) {
                                    throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
                                }
                                var values = (List<Map<String, Object>>) facts.get("details");
                                var source = (Map<String, Object>) head.get("source");
                                var sourceRows = (List<Map<String, Object>>) source.get("lines");
                                Map<Long, Map<String, Object>> sourceById = new TreeMap<>();
                                for (var s : sourceRows) {
                                    sourceById.put(((Number) s.get("id")).longValue(), s);
                                }
                                Map<Long, BigDecimal> sourceAmounts = new TreeMap<>(),
                                        accountAmounts = new TreeMap<>();
                                for (var d : values) {
                                    var amount = originalAmount(head, d);
                                    sourceAmounts.merge(
                                            ((Number) d.get("sourceOrderLineId")).longValue(),
                                            amount,
                                            BigDecimal::add);
                                    accountAmounts.merge(
                                            ((Number) d.get("accountId")).longValue(),
                                            amount,
                                            BigDecimal::add);
                                }
                                Map<Long, Map<String, Object>> progressRows = new TreeMap<>();
                                for (var e : sourceAmounts.entrySet()) {
                                    var row =
                                            progress.lockForLine(
                                                    p,
                                                    sourceById.get(e.getKey()),
                                                    "crm.funds.reverse");
                                    progressRows.put(e.getKey(), row);
                                }
                                batches.lockScoped(
                                        relation(p, "id", p.getParam("originalBatchId")),
                                        "crm.funds.reverse");
                                for (var d : values) {
                                    var actual =
                                            details.lockScoped(
                                                    relation(p, "id", d.get("id")),
                                                    "crm.funds.reverse");
                                    if (!actual.equals(d)) {
                                        throw CrmPartnerValueSupport.failure(
                                                "CRM_REVERSAL_SOURCE_CHANGED");
                                    }
                                }
                                downstream(p, values);
                                var released =
                                        refund(head)
                                                ? refundAllocations(p, head, values)
                                                : List.<CommonParam>of();
                                for (var e : sourceAmounts.entrySet()) {
                                    var row = progressRows.get(e.getKey());
                                    if (!refund(head)
                                            && new BigDecimal(
                                                                    row.get("cashSettledMinor")
                                                                            .toString())
                                                            .subtract(e.getValue())
                                                            .compareTo(
                                                                    new BigDecimal(
                                                                            row.get(
                                                                                            "cashRefundedMinor")
                                                                                    .toString()))
                                                    < 0) {
                                        throw CrmPartnerValueSupport.failure(
                                                "POSTING_DOWNSTREAM_ACTIVE");
                                    }
                                }
                                Map<Long, Map<String, Object>> cashRows = new TreeMap<>();
                                for (var e : accountAmounts.entrySet()) {
                                    var q = relation(p, "accountId", e.getKey());
                                    q.putParam("currency", head.get("currency"));
                                    var row = balances.lockForFundsAction(q, "crm.funds.reverse");
                                    if (!refund(head)
                                            && new BigDecimal(row.get("amountMinor").toString())
                                                            .compareTo(e.getValue())
                                                    < 0) {
                                        throw CrmPartnerValueSupport.failure(
                                                "FUNDS_BALANCE_INSUFFICIENT");
                                    }
                                    cashRows.put(e.getKey(), row);
                                }
                                var batch = relation(p, "documentId", head.get("id"));
                                batch.putParam("originalBatchId", p.getParam("originalBatchId"));
                                batch.putParam("detailCount", values.size());
                                batch.putParam(
                                        "approvedSnapshotHash", head.get("approvedSnapshotHash"));
                                long batchId = batches.appendFundsReverse(batch);
                                List<String> ids = new ArrayList<>();
                                for (var d : values) {
                                    var effect = relation(p, "originalDetailId", d.get("id"));
                                    effect.putParam("batchId", batchId);
                                    ids.add(details.appendFundsReverse(effect).toString());
                                }
                                for (var e : accountAmounts.entrySet()) {
                                    var actual = cashRows.get(e.getKey());
                                    var update = relation(p, "id", actual.get("id"));
                                    update.putParam("versionNo", actual.get("versionNo"));
                                    update.putParam("amountMinor", e.getValue());
                                    if (refund(head)) {
                                        balances.restoreRefundOrganization(update);
                                    } else {
                                        balances.reverseOrganization(update);
                                    }
                                }
                                for (var e : sourceAmounts.entrySet()) {
                                    var actual = progressRows.get(e.getKey());
                                    var update = relation(p, "id", actual.get("id"));
                                    update.putParam("versionNo", actual.get("versionNo"));
                                    update.putParam("amountMinor", e.getValue());
                                    if (refund(head)) {
                                        progress.reverseRefund(update);
                                    } else {
                                        progress.reverseReceipt(update);
                                    }
                                }
                                for (var allocation : released) {
                                    capacities.releaseRefund(allocation);
                                }
                                var posted = documents.markFundsReversed(p);
                                var change = relation(p, "id", app.get("id"));
                                change.putParam(
                                        "expectedVersion", p.getParam("expectedReversalVersion"));
                                change.putParam("resultBatchId", batchId);
                                var resultApp = applications.transition(change, true);
                                access.requireFundsScope(
                                        p.getParam("organizationCandidateId"), "crm.funds.reverse");
                                Map<String, Object> data = new LinkedHashMap<>();
                                data.put("documentId", head.get("id").toString());
                                data.put("state", "REVERSED");
                                data.put("version", posted.get("versionNo").toString());
                                data.put("versionNo", posted.get("versionNo").toString());
                                data.put("reversalRequestId", app.get("id").toString());
                                data.put(
                                        "reversalVersionNo", resultApp.get("versionNo").toString());
                                data.put(
                                        "originalBatchId",
                                        p.getParam("originalBatchId").toString());
                                data.put("postingBatchId", Long.toString(batchId));
                                data.put("detailIds", ids);
                                data.put(
                                        "cashDeltaMinor",
                                        (refund(head)
                                                        ? (BigDecimal) facts.get("totalMinor")
                                                        : ((BigDecimal) facts.get("totalMinor"))
                                                                .negate())
                                                .toPlainString());
                                data.put("replay", false);
                                data.put("synthetic", true);
                                var complete = CrmStockValueSupport.param(req.getParamMap());
                                complete.putParam("id", requestId);
                                complete.putParam("resultBatchId", batchId);
                                complete.putParam("resultVersionNo", posted.get("versionNo"));
                                complete.putParam(
                                        "responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
                                requests.completeOrganizationFundsReverse(complete);
                                var event = relation(p, "postingRequestId", requestId);
                                event.putParam("batchId", batchId);
                                event.putParam("action", "FUNDS_REVERSE");
                                event.putParam("resourceId", head.get("id"));
                                event.putParam("previousVersion", head.get("versionNo"));
                                event.putParam("newVersion", posted.get("versionNo"));
                                audit.append(event);
                                return CrmPartnerValueSupport.result(data);
                            });
        } catch (CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            return replay(requests.committedOrganizationFundsReverse(req), req);
        }
    }

    // 容量归属服务仅在明确退货结构访问，保留独立流水与FK。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService capacities;

    /**
     * 从已核实际类型派生方向；例如FUNDS_PAYMENT/SALES_RETURN返回true，不接受客户端方向。
     *
     * @param head 真实已冻结头，例如id1000003
     * @return 商品退款true，旧销售收款false，不写入
     */
    private boolean refund(Map<String, Object> head) {
        return "SALES_RETURN".equals(head.get("reason"));
    }

    /**
     * 核实际POST的符号并取冻结绝对金额；例如退款-2返回2，收款+5返回5，错误符号拒绝。
     *
     * @param head 真实类型与原因
     * @param detail 原不可变现金效果例如amountDeltaMinor=-2
     * @return 实际正MINOR，不改变原流水
     */
    private BigDecimal originalAmount(Map<String, Object> head, Map<String, Object> detail) {
        var delta = new BigDecimal(detail.get("amountDeltaMinor").toString());
        if (delta.signum() != (refund(head) ? -1 : 1)) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        return CrmFundsValueSupport.minor(delta.abs());
    }

    /**
     * 按原退款行收款/退货两父真实引用聚合，并核不可变有效依赖对账后预锁容量。
     *
     * @param p org901，来源/单据锁已持有
     * @param head 完整实际退款头，例如1000003
     * @param values 全部原退款POST明细例如两行-1/-1
     * @return 真实释放参数例如两父各2分；缺边、人工占用篡改或有效POST汇总不符拒绝，未改库
     */
    @SuppressWarnings("unchecked")
    private List<CommonParam> refundAllocations(
            CommonParam p, Map<String, Object> head, List<Map<String, Object>> values) {
        Map<Object, Map<String, Object>> byLine = new HashMap<>();
        for (var line : (List<Map<String, Object>>) head.get("lines")) {
            byLine.put(line.get("id"), line);
        }
        Map<Long, CommonParam> parents = new TreeMap<>();
        Map<Long, BigDecimal> amounts = new TreeMap<>();
        for (var d : values) {
            var line = byLine.get(d.get("documentLineId"));
            for (String kind : List.of("RECEIPT_REFUND", "RETURN_REFUND")) {
                String field =
                        "RECEIPT_REFUND".equals(kind)
                                ? "baseReceiptDetailId"
                                : "baseReturnDetailId";
                long id = ((Number) line.get(field)).longValue();
                var q = relation(p, "originalDetailId", id);
                q.putParam("sourceOrderLineId", d.get("sourceOrderLineId"));
                q.putParam("capacityKind", kind);
                parents.putIfAbsent(id, q);
                amounts.merge(id, originalAmount(head, d), BigDecimal::add);
                String edgeKind =
                        "RECEIPT_REFUND".equals(kind) ? "REFUND_FOR_RECEIPT" : "REFUND_FOR_RETURN";
                long matches =
                        dependencies.parentEdges(relation(p, "parentDetailId", id)).stream()
                                .filter(
                                        e ->
                                                d.get("id").equals(e.get("childDetailId"))
                                                        && edgeKind.equals(e.get("dependencyKind")))
                                .count();
                if (matches != 1) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
            }
        }
        List<CommonParam> result = new ArrayList<>();
        for (var e : parents.entrySet()) {
            var q = e.getValue();
            var row = capacities.lockAllocation(q, "crm.funds.reverse");
            BigDecimal effective = BigDecimal.ZERO;
            String edgeKind =
                    "RECEIPT_REFUND".equals(q.getParam("capacityKind"))
                            ? "REFUND_FOR_RECEIPT"
                            : "REFUND_FOR_RETURN";
            for (var edge : dependencies.parentEdges(relation(p, "parentDetailId", e.getKey()))) {
                if (!edgeKind.equals(edge.get("dependencyKind"))) {
                    continue;
                }
                var child =
                        details.lockScoped(
                                relation(p, "id", edge.get("childDetailId")), "crm.funds.reverse");
                if (!"CASH".equals(child.get("effectKind"))
                        || !"POST".equals(child.get("action"))
                        || !q.getParam("sourceOrderLineId")
                                .equals(child.get("sourceOrderLineId"))) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
                var batch =
                        batches.lockScoped(
                                relation(p, "id", child.get("batchId")), "crm.funds.reverse");
                if (active(p, batch)) {
                    var delta = new BigDecimal(child.get("amountDeltaMinor").toString());
                    if (delta.signum() != -1) {
                        throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                    }
                    effective = effective.add(delta.negate());
                }
            }
            if (effective.compareTo(new BigDecimal(row.get("usedMinor").toString())) != 0) {
                throw CrmPartnerValueSupport.failure("CRM_CAPACITY_SOURCE_MISMATCH");
            }
            q.putParam("id", row.get("id"));
            q.putParam("versionNo", row.get("versionNo"));
            q.putParam("amountMinor", amounts.get(e.getKey()));
            result.add(q);
        }
        return result;
    }
}
