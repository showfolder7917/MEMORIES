/**
 * 销售收款登记明确v2 HTTP；2026-10-03，Codex；旧四字段协议不改。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.capability.funds.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 无DAO，调用实际Funds owning业务聚合器；生产写默认拒绝。
 */
@RestController
public class CrmFundsController {

  private final com.sp.selplat.crm.capability.funds.service.CrmFundsService service;

  /**
   * 注入实际业务聚合器，构造不执行SQL。
   *
   * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
   * @param documents 实际单据owning服务，例如读取资金单据101；构造不读写数据库。
   */
  public CrmFundsController(
      com.sp.selplat.crm.capability.funds.service.CrmFundsService service,
      com.sp.selplat.crm.document.service.CrmDocumentService documents) {
    this.service = service;
    this.documents = documents;
  }

  /**
   * v2组织完整POST，只有明确POST登记资金。
   *
   * @param input 例如org901/id1000000/actionPOST/expected2/keyk1
   * @return 同批全部真实效果ID/首次结果，不部分成功
   */
  @PostMapping("/api/crm/funds/posting/v2/execute.htm")
  public String execute(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.execute(input));
  }

  /**
   * 实际完整资金批次查询。
   *
   * @param input 例如org901/id1200000
   * @return 同范围真实批次及全部明细JSON，跨组织拒绝
   */
  @GetMapping("/api/crm/funds/posting/v2/batch/getById.htm")
  public String batch(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.batch(input));
  }

  /**
   * 真实收款登记工作区与服务端公共SELUI定义。
   *
   * @param input 例如org901/page1/langzh-CN
   * @return 公共实际聚合JSON，生产默认拒绝
   */
  @GetMapping("/api/crm/funds/workspace.htm")
  public String workspace(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(service.workspace(input));
  }

  /**
   * 方法作用：原资金拥有方读取活动课时预留的退款上限。
   * @param input studentId50/curriculumCourseId400/reservationId100000
   * @return 真实示例：success=true/data.maximumRefundMinor18/currencyCNY完整JSON。
   * 异常或副作用示例：无真实预留或资金资格拒绝，不执行退款。
   */
  @GetMapping("/api/crm/funds/course-refund/prepare.htm")
  public String courseRefundQuote(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.courseRefundQuote(input));
  }

  private final com.sp.selplat.crm.document.service.CrmDocumentService documents;

  /**
   * 方法作用及真实业务示例：销售收款完整头行保存；org901、冻结订单600000、分摊68/67最小单位；返回真实收款单1000000/version0；第N账户或金额失败整笔回滚。
   * Receipt saveDraft uses actual owning document, without payment-provider effects.
   *
   * @param input org901 with complete receipt lines or id/version/key
   * @return real atomic document JSON or rejection
   */
  @PostMapping("/api/crm/funds/document/saveDraft.htm")
  public String saveDraft(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(documents.saveFundsDraft(input));
  }

  /**
   * 方法作用及真实业务示例：销售收款具名提交；真实DRAFT单1000000/expected0/keysubmit；返回SUBMITTED/version1；不写资金流水或余额。
   * Receipt submit uses actual owning document, without payment-provider effects.
   *
   * @param input org901 with complete receipt lines or id/version/key
   * @return real atomic document JSON or rejection
   */
  @PostMapping("/api/crm/funds/document/submit.htm")
  public String submit(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(documents.submitFunds(input));
  }

  /**
   * 方法作用及真实业务示例：不同真实操作员审核收款；单1000000/expected1/keyapprove；返回APPROVED/version2及真实冻结；自审拒绝且资金不变。
   * Receipt approve uses actual owning document, without payment-provider effects.
   *
   * @param input org901 with complete receipt lines or id/version/key
   * @return real atomic document JSON or rejection
   */
  @PostMapping("/api/crm/funds/document/approve.htm")
  public String approve(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(documents.approveFunds(input));
  }

  /**
   * 方法作用：把具名驳回交给原资金单据拥有方，不能由页面指定审核身份。
   *
   * @param input 真实示例：organizationCandidateId901/id1000000/expectedVersion1/reasonText核对金额
   * @return 真实示例：JSON success=true/data.documentState=DRAFT/versionNo=2。
   *     异常或副作用示例：本人提交或非待审单拒绝，现金与原分摊行不变。
   */
  @PostMapping("/api/crm/funds/document/reject.htm")
  public String reject(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(documents.rejectFunds(input));
  }


  /**
   * 方法作用及真实业务示例：读取同组织收款头和全部分摊行；org901/id1000000；返回真实精确金额文本；跨组织或库存单统一拒绝。 Actual receipt/source
   * getById, scope is rechecked.
   *
   * @param input org901 and actual id/orderId
   * @return actual complete precise JSON, no writes
   */
  @GetMapping("/api/crm/funds/document/getById.htm")
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(documents.getFundsById(input));
  }

  /**
   * 方法作用及真实业务示例：读取实际冻结销售来源及已收未收；org901/orderId600000；返回应收135、已收68、未收67等真实派生值；不新增进度行或更改订单状态。
   * Actual receipt/source source, scope is rechecked.
   *
   * @param input org901 and actual id/orderId
   * @return actual complete precise JSON, no writes
   */
  @GetMapping("/api/crm/funds/document/source.htm")
  public String source(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.source(input));
  }
}
