/* 账务账户维护元数据安装；2026-10-28，保留原账户、资金和单据。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import java.sql.SQLException;
import java.sql.Types;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 仅向真实已安装资金账户附加维护元数据；不创建默认账户、余额或授权。 */
@Configuration(proxyBeanMethods = false)
public class CrmCashAccountMaintenancePersistenceConfiguration {

  /**
   * 方法作用：核原资金结构后幂等附加元数据，先检查不兼容列再执行固定拥有方DDL。
   *
   * @param source 原crmDataSource，例如正式CRM独立文件池
   * @param inspector 原只读检查器，例如已安装funds及CrmCashAccount
   * @return 真实返回示例：未安装资金false；三列类型和非空历史均核对后true。
   * @throws SQLException 元数据不可读时启动失败，不继续猜测结构
   * @throws IllegalStateException 活动事务或既有异类型字段拒绝，不重建原账户
   */
  @Bean("crmCashAccountMaintenanceInitialized")
  @DependsOn("crmBusinessStructureInspector")
  public Boolean initialize(
      @Qualifier("crmDataSource") DataSource source,
      @Qualifier("crmBusinessStructureInspector") CrmBusinessStructureInspector inspector)
      throws SQLException {
    if (!inspector.available().contains("funds")) {
      return false;
    }
    if (TransactionSynchronizationManager.isActualTransactionActive()) {
      throw new IllegalStateException("CRM_ACCOUNT_MAINTENANCE_ACTIVE_TRANSACTION");
    }
    verify(source, false);
    new ResourceDatabasePopulator(
            new ClassPathResource("db/crm/sql/maintenance-CrmCashAccount.sql"))
        .execute(source);
    verify(source, true);
    return true;
  }

  /**
   * 方法作用：检查维护列真实类型，缺失列仅允许在附加前存在。
   *
   * @param source 原CRM池，例如本例私有内存库
   * @param required true要求全部列存在，例如执行附加声明后
   * @throws SQLException 实际元数据访问失败传播，零业务写入
   * @throws IllegalStateException 短字段、异类型或可空历史拒绝，不覆盖未知结构
   */
  private void verify(DataSource source, boolean required) throws SQLException {
    try (var connection = source.getConnection()) {
      for (String field :
          java.util.List.of("creationRequestKey", "creationHash", "changeHistoryJson")) {
        try (var rows =
            connection
                .getMetaData()
                .getColumns(
                    connection.getCatalog(), connection.getSchema(), "CrmCashAccount", field)) {
          if (!rows.next()) {
            if (required) {
              throw new IllegalStateException("CRM_ACCOUNT_MAINTENANCE_COLUMN_MISSING");
            }
            continue;
          }
          if (rows.getInt("DATA_TYPE") != Types.VARCHAR
              || (!field.equals("changeHistoryJson") && rows.getInt("COLUMN_SIZE") != 64)
              || (field.equals("changeHistoryJson") && rows.getInt("COLUMN_SIZE") < 4000000)
              || (field.equals("changeHistoryJson") && !"'[]'".equals(rows.getString("COLUMN_DEF")))
              || (field.equals("changeHistoryJson")
                  && rows.getInt("NULLABLE") != java.sql.DatabaseMetaData.columnNoNulls)) {
            throw new IllegalStateException("CRM_ACCOUNT_MAINTENANCE_STRUCTURE_CONFLICT");
          }
        }
      }
      // 同名错误索引不能被IF NOT EXISTS静默接受，否则并发创建没有真实唯一保证。
      var indexed = new java.util.TreeMap<Integer, String>();
      try (var indexes =
          connection
              .getMetaData()
              .getIndexInfo(
                  connection.getCatalog(),
                  connection.getSchema(),
                  "CrmCashAccount",
                  false,
                  false)) {
        while (indexes.next()) {
          if ("crm_cash_account_creation_request"
              .equalsIgnoreCase(indexes.getString("INDEX_NAME"))) {
            if (indexes.getBoolean("NON_UNIQUE")) {
              throw new IllegalStateException("CRM_ACCOUNT_MAINTENANCE_INDEX_CONFLICT");
            }
            indexed.put(indexes.getInt("ORDINAL_POSITION"), indexes.getString("COLUMN_NAME"));
          }
        }
      }
      if ((required || !indexed.isEmpty())
          && !new java.util.ArrayList<>(indexed.values())
              .equals(java.util.List.of("tenantId", "businessOrgId", "creationRequestKey"))) {
        throw new IllegalStateException("CRM_ACCOUNT_MAINTENANCE_INDEX_CONFLICT");
      }
    }
  }
}
