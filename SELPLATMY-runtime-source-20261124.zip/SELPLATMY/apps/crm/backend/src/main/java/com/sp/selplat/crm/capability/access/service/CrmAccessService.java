/** CrmAccessService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.capability.access.service;

import com.sp.selplat.common.util.CommonResult;

import java.util.Map;

/** CRM 准入能力只核实当前身份及模块开放状态，不授予客户或库存操作权限。 */
public interface CrmAccessService {
    /**
     * 方法作用：以真实权限保护整个CRM事务，隔离测试沿用既有模板合同。
     * @param candidate 明确经营组织候选，例如901
     * @param action owning服务固定动作，例如crm.order.write
     * @param template 既有CRM事务模板，例如READ_COMMITTED/REQUIRES_NEW
     * @param operation 完整owning回调，例如保存两行订单、请求及审计
     * @return 真实返回示例：data.id=600000；同一CRM事务失败整体回滚。
     * 异常或副作用示例：正式模式缺精确许可或提交前到期拒绝，不生成授权关系。
     */
    CommonResult executeTransaction(Object candidate, String action,
            org.springframework.transaction.support.TransactionTemplate template,
            org.springframework.transaction.support.TransactionCallback<CommonResult> operation);
    /**
     * 订单隔离动作入口；候选org901、动作crm.order.write；缺正式resolver仍拒绝。
     *
     * @param candidate 候选组织主键，例如901；真实归属必须由Session重新核验。
     * @param action 服务内部选择的固定动作，例如crm.order.write；不得据客户端动作补授权限。
     * @return 实际服务重新核验的订单范围Map；缺正式resolver或许可时拒绝
     */
    java.util.Map<String, Object> requireOrderScope(Object candidate, String action);

    /**
     * 读取真实有效身份，并返回 CRM 当前开放状态。
     *
     * @return 统一结果，例如 {@code
     *     {"success":true,"data":{"businessReady":false,"identity":{"userId":12}}}}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无有效身份时抛出 {@code
     *     UNIAUTH_IDENTITY_REQUIRED}，不使用默认操作员
     */
    CommonResult readiness();

    /**
     * 方法作用：提供当前账号获准读取的经营组织目录，不从登录态推定默认组织。
     * @param query 字面组织名称，例如青禾；空字符串查询有界目录
     * @return 真实返回示例：data含actor={tenantId:"92",userId:"9211"}与organizations列表，组织901可读取客户。
     * 异常或副作用示例：无许可返回空目录；超过100项候选要求缩小查询，零写入。
     */
    CommonResult organizationChoices(String query);
    /**
     * 方法作用：提供原资金读取资格下的财务机构候选，不扩展原CRM四类目录。
     * @param query 原机构名称字面查询，例如新思度
     * @return 真实示例：data.actor为tenant9/user9101，organizations含901及crm.funds.read。
     * 异常或副作用示例：正式资金结构未安装返回空，身份或目录故障拒绝，不默认组织。
     */
    CommonResult fundsOrganizationChoices(String query);


    /**
     * 方法作用：只提供本域正式结构可用性给内部功能门禁，不构成操作员许可。
     * @param capability 固定能力，例如orderAttachment或stockReversal
     * @return 真实返回示例：显式正式模式且对应组织结构已安装为true，默认false。
     * 异常或副作用示例：纯结构读取；业务入口仍重新核验当前账号的独立动作。
     */
    boolean formalCapabilityAvailable(String capability);



    /**
     * 核验当前真实账号并提取私人草稿归属。
     *
     * @return 正数租户及本人，例如 {tenantId:92,ownerUserId:9211}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 归属无效时拒绝，无默认身份
     */
    Map<String, Long> requireDraftActor();

    /**
     * 核验本步经营组织动作；真实resolver未接通时生产入口一律拒绝。
     *
     * @param candidate 页面所选组织候选，例如"901"，不是可信scope
     * @param action 本域固定动作，例如crm.partner.write
     * @return 仅隔离合成许可测试返回{tenantId:92,businessOrgId:901,actorUserId:9211,synthetic:true}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无真实Session/缺resolver/缺合成许可时拒绝
     */
    Map<String, Object> requirePartnerScope(Object candidate, String action);

    /**
     * 库存真实动作scope，默认生产拒绝。
     *
     * @param candidate org候选，例如901
     * @param action 固定stock.write/submit/approve/post/read动作
     * @return 实际Session和test-only许可的范围；缺许可抛CRM_ACTION_FORBIDDEN
     */
    java.util.Map<String, Object> requireStockScope(Object candidate, String action);

    /**
     * 现有owning跨表组件按固定业务动作消费对应scope，不能绕隔离开关。
     *
     * @param candidate org候选，例如901
     * @param action 固定partner/order/stock动作
     * @return 实际范围，所有未知动作拒绝
     */
    java.util.Map<String, Object> requireBusinessScope(Object candidate, String action);

    /**
     * Real funds action gate, never a payment-provider authorization.
     *
     * @param candidate organization e.g. 901
     * @param action fixed crm.funds.post
     * @return verified actor/scope or rejection; production disabled
     */
    java.util.Map<String, Object> requireFundsScope(Object candidate, String action);
}
