/**
 * CrmPricingServiceImpl.java：真实身份后的新订单定价计算。
 * 修改记录：2026-10-03，Codex 实现纯计算，不开放商业写入。
 */
package com.sp.selplat.crm.capability.pricing.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.capability.pricing.service.CrmPricingService;
import com.sp.selplat.crm.common.util.pricing.CrmOrderPricingSupport;
import org.springframework.stereotype.Service;

/** 消费既有真实Session，委托无状态计算工具；无DAO、事务写或组织授权兜底。 */
@Service
public class CrmPricingServiceImpl implements CrmPricingService {
    // 登录状态与有效账号每次真实回查，前端身份不受信任。
    private final CrmAccessService accessService;

    /**
     * 装配本域身份能力。
     * @param accessService 真实CrmAccessServiceImpl
     * 副作用示例：构造不建Session或执行计算。
     */
    public CrmPricingServiceImpl(CrmAccessService accessService) {
        this.accessService = accessService;
    }

    /**
     * 登录后计算客户端显式新单输入，不读取或冻结任何业务记录。
     * @param input 公共参数，例如currency=CNY/fee=0/lines数量1单价1.00
     * @return CommonResult，例如success=true、data.totalMinor=100、data.approved=false
     * @throws com.sp.selplat.common.exception.CommonBusinessException 失效身份或非法金额拒绝，不写库
     */
    @Override
    @OperationLog
    public CommonResult preview(CommonParam input) {
        // 身份回查只开放无资产读取的计算，不能等同于订单审批或组织写许可。
        accessService.requireDraftActor();
        CommonResult result = new CommonResult();
        result.setData(CrmOrderPricingSupport.calculate(input == null ? null : input.getParamMap()));
        result.setSuccess(true);
        result.setMsg("金额计算完成；未核验主数据，未审核或保存订单。");
        return result;
    }
}
