/** CRM订单附件真实绑定与本人查询入口；2026-10-04，Codex。 */
package com.sp.selplat.crm.orderattachment.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.orderattachment.service.CrmOrderAttachmentService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只开放具名绑定和逐项获准读取；通用无版本写、共享授予及删除不开放。 */
@RestController
@RequestMapping("/api/crm/order-attachment")
public class CrmOrderAttachmentController {
    // 所有身份/文件/事务规则均由本表owning服务执行。
    private final CrmOrderAttachmentService service;

    /**
     * 方法作用：装配真实owning服务。
     *
     * @param service 例如CrmOrderAttachmentServiceImpl 副作用示例：构造不写SQL或发送文件HTTP。
     */
    public CrmOrderAttachmentController(CrmOrderAttachmentService service) {
        this.service = service;
    }

    /**
     * 方法作用：提交当前上传者的幂等引用CAS命令，不接收owner或URL。
     *
     * @param input
     *     例如org901/id600000/expectedVersion2/expectedAttachmentVersion0及真实fileId/sha256/byteSize/requestKey
     * @return 公共JSON，例如bindingWritten=true/attachmentId100000/versionNo1/replay=false
     *     异常或副作用示例：实际文件不可读、版本冲突或审计失败由统一处理器拒绝，不部分成功。
     */
    @PostMapping("bind.htm")
    public String bind(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.bind(input));
    }

    /**
     * 方法作用：分页当前上传者在准确订单范围的引用。
     *
     * @param input 例如organizationCandidateId901/orderId600000/pageNo1/pageSize20
     * @return 公共真实分页，例如records包含本人附件100000/totalCount1 异常或副作用示例：无order.read或跨组织拒绝；不返回其他上传者引用。
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 方法作用：读取准确订单内本人附件，不扩大file-service共享权限。
     *
     * @param input 例如organizationCandidateId901/orderId600000/id100000
     * @return 公共实际记录，例如fileId为本人32位ID/versionNo1 异常或副作用示例：不存在或其他上传者统一CRM_RECORD_NOT_FOUND，不写业务事实。
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }
    /**
     * 方法作用：读取其他上传者已独立共享给当前账号的订单引用，不自动授予正文权限。
     * @param input 例如organizationCandidateId901/orderId600000/id100000；所有者从已存引用取得
     * @return 真实返回示例：success=true/data.shared=true；失败不暴露未获准引用的存在性。
     * 异常或副作用示例：每次核订单读许可和文件系统共享许可，无上传、授权或CRM写入。
     */
    @GetMapping("getSharedById.htm")
    public String getSharedById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getSharedById(input));
    }

    /**
     * 方法作用：从共享收件箱的明确资源候选读取当前订单的引用，不把共享文件自动绑定到订单。
     * @param input 例如organizationCandidateId901/orderId600000/ownerUserId9212/fileId为32位ID
     * @return 真实返回示例：success=true/data.shared=true；无当前订单引用或无许可均拒绝。
     * 异常或副作用示例：只有读取，不授予共享、不复制正文或修改订单。
     */
    @GetMapping("getSharedByFile.htm")
    public String getSharedByFile(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getSharedByFile(input));
    }

    /**
     * 方法作用：订单附件所有响应绑定当前身份，禁止缓存旧共享或本人引用结果。
     * @param response 当前Servlet响应，例如Cache-Control=private, no-store
     * 异常或副作用示例：只设置响应头；撤权后下次请求仍须重新核权。
     */
    @org.springframework.web.bind.annotation.ModelAttribute
    public void preventCaching(jakarta.servlet.http.HttpServletResponse response) {
        response.setHeader("Cache-Control", "private, no-store");
    }

}
