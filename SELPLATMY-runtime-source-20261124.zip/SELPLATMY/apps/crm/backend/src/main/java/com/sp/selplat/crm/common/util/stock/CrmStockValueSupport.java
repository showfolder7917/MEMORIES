/** 销售出库/采购入库值契约；2026-10-04，Codex；采购仅明确类型配对，金额和权限策略不变。 */
/** 修改记录：2026-10-09，Codex；完整long行号先校验原1000上限，再转换为已验证int，保留原业务拒绝。 */
package com.sp.selplat.crm.common.util.stock;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** 固定销售出库/采购入库输入、精确数量和冻结快照；未开放退货、支付、冲销。 */
public final class CrmStockValueSupport {
    /** 不允许实例化无状态库存值工具；不建立账户、库存或授权。 */
    private CrmStockValueSupport() {
        // 所有值方法静态调用，禁止构造带状态的库存工具实例。
    }

    /**
     * 独立公共参数复制。
     *
     * @param values 已规范值，例如org901/id1000000
     * @return 新CommonParam，例如paramMap={"organizationCandidateId":"901","id":"1000000"}；不修改输入
     */
    public static CommonParam param(Map<String, Object> values) {
        // 独立复制已规范参数 -> 后续补充关联主键不污染调用方。
        var p = new CommonParam();
        p.setParamMap(new LinkedHashMap<>(values));
        return p;
    }

    /**
     * EA有限范围精确数量；遵循当前V2库存上限，不扩大策略。
     *
     * @param value 正整数字符串，例如2
     * @return 输入"2"返回2L；范围仍为1..999999999，不扩大库存数量策略
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     输入"1000000000"时抛STOCK_QUANTITY_LIMIT
     */
    public static long quantity(Object value) {
        // 先复用正整数契约，再维持本版本库存上限 -> 过界拒绝，不截断数量。
        long q = CrmPartnerValueSupport.positive(value);
        if (q > 999999999L) {
            throw CrmPartnerValueSupport.failure("STOCK_QUANTITY_LIMIT");
        }
        return q;
    }

    /**
     * 新建/编辑单一SALE出库或PURCHASE入库的完整行输入。
     *
     * @param input 例如org901/order600000/keyk1/完整source行及仓库商品数量；不能传actor/合计/hash
     * @return 新CommonParam；示例orderId=600000L，lines=[{lineNo:1,sourceOrderLineId:600001L,
     *     warehouseId:801L,productId:701L,quantity:2L}]，无客户端actor、合计或hash
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     传tenantId或重复行号时抛INVALID_CRM_DOCUMENT_INPUT；1001行抛DOCUMENT_LINE_LIMIT
     */
    public static CommonParam draft(CommonParam input) {
        return draft(input, false);
    }

    /**
     * 明确门禁后规范销售退货完整行，原出库引用必须真实正主键。
     *
     * @param input org901/STOCK_RECEIPT/SALES_RETURN及baseIssueDetailId1300000/quantity1
     * @param allowReturns 实际服务器退货结构门禁，客户端不能传
     * @return 规范完整行，例如{sourceOrderLineId:600001,baseIssueDetailId:1300000,quantity:1}
     */
    public static CommonParam draft(CommonParam input, boolean allowReturns) {
        // 固定白名单及销售/采购类型配对 -> 不能开启销售退货或可信身份字段。
        if (input == null
                || !Set.of(
                                "organizationCandidateId",
                                "id",
                                "expectedVersion",
                                "requestKey",
                                "orderId",
                                "documentKind",
                                "reason",
                                "lines")
                        .containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        String sourceKind =
                orderKind(input.getParam("documentKind"), input.getParam("reason"), allowReturns);
        var result =
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(input, false);
        result.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        result.putParam("documentKind", input.getParam("documentKind"));
        result.putParam("reason", input.getParam("reason"));
        result.putParam("orderKind", sourceKind);
        if (!(input.getParam("lines") instanceof List<?> items)
                || items.isEmpty()
                || items.size() > 1000) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
        }
        // 全量规范单据行 -> 保留显式行号策略、来源主键和精确EA数量。
        List<Map<String, Object>> rows = new ArrayList<>();
        Set<Integer> numbers = new HashSet<>();
        int position = 0;
        boolean salesReturn = "SALES_RETURN".equals(input.getParam("reason"));
        for (Object item : items) {
            if (!(item instanceof Map<?, ?> raw)
                    || !Set.of(
                                    "sourceOrderLineId",
                                    "warehouseId",
                                    "productId",
                                    "quantity",
                                    "lineNo",
                                    "baseIssueDetailId")
                            .containsAll(raw.keySet())) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
            }
            // 先校验完整long候选的原业务上限，避免超大行号提前产生ArithmeticException。
            long no =
                    raw.get("lineNo") == null
                            ? ++position
                            : CrmPartnerValueSupport.positive(raw.get("lineNo"));
            if (no > 1000 || !numbers.add((int) no)) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
            }
            var row = new TreeMap<String, Object>();
            row.put("lineNo", (int) no);
            for (String key : List.of("sourceOrderLineId", "warehouseId", "productId")) {
                row.put(key, CrmPartnerValueSupport.positive(raw.get(key)));
            }
            row.put("quantity", quantity(raw.get("quantity")));
            if (salesReturn) {
                row.put(
                        "baseIssueDetailId",
                        CrmPartnerValueSupport.positive(raw.get("baseIssueDetailId")));
            } else if (raw.containsKey("baseIssueDetailId")) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
            }
            rows.add(row);
        }
        // 固定行号顺序 -> 后续冻结和重放不受客户端数组顺序影响。
        rows.sort(Comparator.comparingInt(row -> ((Number) row.get("lineNo")).intValue()));
        result.putParam("lines", rows);
        return result;
    }

    /**
     * 明确POST v2，不接受REVERSE或未知可信字段。
     *
     * @param input 例如org901/id1000000/actionPOST/keyk1/expected2
     * @return 新CommonParam，例如id=1000000L、expectedVersion=2L、action="POST"，其余规范命令字段保留
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     action="REVERSE"或附加actor时抛INVALID_CRM_POSTING_INPUT
     */
    public static CommonParam post(CommonParam input) {
        // 精确键集合和POST动作 -> 冲正必须走自己的入口，不能混入可信字段。
        if (input == null
                || !input.getParamMap()
                        .keySet()
                        .equals(
                                Set.of(
                                        "organizationCandidateId",
                                        "id",
                                        "action",
                                        "requestKey",
                                        "expectedVersion"))
                || !"POST".equals(input.getParam("action"))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_POSTING_INPUT");
        }
        // 复用公共状态命令规范后恢复固定动作 -> 不修改输入对象。
        var copy = new LinkedHashMap<>(input.getParamMap());
        copy.remove("action");
        var p =
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(
                        param(copy), true);
        p.putParam("action", "POST");
        return p;
    }

    /**
     * 浏览器全部数量、主键及版本精确文本，不由JS记账。
     *
     * @param row 实际头/明细/余额，例如quantityDelta=-2
     * @return 输入{"id":1000000L,"quantityDelta":-2L}返回{"id":"1000000","quantityDelta":"-2"}；不修改原行
     */
    public static Map<String, Object> browser(Map<String, Object> row) {
        // 公共主键/金额/CLOB转换加库存数量转换 -> 浏览器不以浮点数记账。
        var result = CrmOrderValueSupport.browser(row);
        for (var e : result.entrySet()) {
            if (e.getValue() instanceof Number
                    && (e.getKey().contains("Quantity") || e.getKey().equals("quantityDelta"))) {
                e.setValue(e.getValue().toString());
            }
        }
        return result;
    }

    /**
     * 服务器冻结全部SALE来源与仓库商品数量。
     *
     * @param head 真实document头，例如sourceOrder600000/version1
     * @param rows 全部真实单据行，例如两条同SKU/source行的1/2EA
     * @return 固定头字段和全部行的TreeMap；示例lines=[{id:"1000001",lineNo:1,sourceOrderLineId:"600001",
     *     warehouseId:"801",productId:"701",quantity:"2"}]，头versionNo="1"；无时间字段参与
     */
    public static Map<String, Object> snapshot(
            Map<String, Object> head, List<Map<String, Object>> rows) {
        // 固定业务头字段 -> 可信范围、来源hash和版本参与冻结，不掺入未来余额。
        var result = new TreeMap<String, Object>();
        var shown = browser(head);
        for (String k :
                List.of(
                        "id",
                        "tenantId",
                        "businessOrgId",
                        "orderId",
                        "orderKind",
                        "currency",
                        "documentKind",
                        "reason",
                        "orderSnapshotHash",
                        "versionNo")) {
            result.put(k, shown.get(k));
        }
        // 按行号完整映射来源、仓库、商品和数量 -> 不分页截断快照。
        result.put(
                "lines",
                rows.stream()
                        .sorted(Comparator.comparingInt(r -> ((Number) r.get("lineNo")).intValue()))
                        .map(
                                r -> {
                                    var line = new TreeMap<String, Object>();
                                    var view = browser(r);
                                    for (String k :
                                            List.of(
                                                    "id",
                                                    "lineNo",
                                                    "sourceOrderLineId",
                                                    "warehouseId",
                                                    "productId",
                                                    "quantity")) {
                                        line.put(k, view.get(k));
                                    }
                                    if ("SALES_RETURN".equals(head.get("reason"))) {
                                        line.put(
                                                "baseIssueDetailId", view.get("baseIssueDetailId"));
                                    }
                                    return line;
                                })
                        .toList());
        return result;
    }

    /**
     * 过账重验实际冻结，不信任客户端或可变同版本行。
     *
     * @param head 实际APPROVED头，snapshot源版本1
     * @param rows 持锁实际全部行，例如来源600001、仓库801、商品701、数量2
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     数量被改为3或hash不符时抛CRM_DOCUMENT_SNAPSHOT_MISMATCH；无写库副作用
     */
    public static void verifySnapshot(Map<String, Object> head, List<Map<String, Object>> rows) {
        // 已冻结批准版本用于重建实际快照 -> 正文和持锁完整行分别重算摘要。
        @SuppressWarnings("unchecked")
        Map<String, Object> frozen =
                JsonUtils.fromJson((String) browser(head).get("frozenSnapshot"), Map.class);
        var source = new LinkedHashMap<>(head);
        source.put("versionNo", CrmPartnerValueSupport.version(frozen.get("versionNo")));
        if (!head.get("approvedSnapshotHash").equals(CrmOrderValueSupport.hash(frozen))
                || !head.get("approvedSnapshotHash")
                        .equals(CrmOrderValueSupport.hash(snapshot(source, rows)))) {
            throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SNAPSHOT_MISMATCH");
        }
    }

    /**
     * 固定库存类型和业务原因配对，禁止以采购入口开启销售退货。
     *
     * @param kind 例如STOCK_RECEIPT
     * @param reason 例如PURCHASE
     * @return STOCK_RECEIPT/PURCHASE返回PURCHASE；STOCK_ISSUE/SALE返回SALES
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     其他配对抛INVALID_CRM_DOCUMENT_INPUT
     */
    public static String orderKind(Object kind, Object reason) {
        return orderKind(kind, reason, false);
    }

    /**
     * 从服务器已核门禁和类型原因派生真实来源，退货仍为SALES。 实际调用示例：STOCK_RECEIPT、SALES_RETURN、true，返回SALES，不写库。
     *
     * @param kind 实际STOCK_RECEIPT
     * @param reason 实际SALES_RETURN
     * @param allowReturns 显式退货测试结构true，不是客户端字段
     * @return 门禁true时销售退货返回SALES；其他组合按既有契约或拒绝
     */
    public static String orderKind(Object kind, Object reason, boolean allowReturns) {
        if (allowReturns && "STOCK_RECEIPT".equals(kind) && "SALES_RETURN".equals(reason)) {
            return "SALES";
        }
        if ("STOCK_ISSUE".equals(kind) && "SALE".equals(reason)) {
            return "SALES";
        }
        if ("STOCK_RECEIPT".equals(kind) && "PURCHASE".equals(reason)) {
            return "PURCHASE";
        }
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }

    /**
     * 库存页面类型候选仅允许已有销售出库或采购入库。
     *
     * @param value null或STOCK_RECEIPT，例如STOCK_RECEIPT
     * @return null默认STOCK_ISSUE；STOCK_RECEIPT原样返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     其他值抛INVALID_CRM_DOCUMENT_INPUT
     */
    public static String pageKind(Object value) {
        if (value == null) {
            return "STOCK_ISSUE";
        }
        if (!Set.of("STOCK_ISSUE", "STOCK_RECEIPT").contains(value)) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        return value.toString();
    }

    /**
     * 判定实际库存单据的本阶段配对，不把历史销售退货当采购。
     *
     * @param kind 实际documentKind，例如STOCK_RECEIPT
     * @param reason 实际reason，例如PURCHASE
     * @return STOCK_RECEIPT/PURCHASE和STOCK_ISSUE/SALE返回true；FUNDS_RECEIPT/SALE返回false
     */
    public static boolean isStockDocument(Object kind, Object reason) {
        return isStockDocument(kind, reason, false);
    }

    /**
     * 验证本阶段实际库存配对，新增退货只能在明确服务器门禁后接受。 实际调用示例：STOCK_RECEIPT、SALES_RETURN、true，返回true，不写库。
     *
     * @param kind 实际STOCK_RECEIPT
     * @param reason 实际SALES_RETURN
     * @param allowReturns 服务器显式门禁true
     * @return 明确退货门禁时true；旧入口对销售退货仍false
     */
    public static boolean isStockDocument(Object kind, Object reason, boolean allowReturns) {
        if (allowReturns && "STOCK_RECEIPT".equals(kind) && "SALES_RETURN".equals(reason)) {
            return true;
        }
        return ("STOCK_ISSUE".equals(kind) && "SALE".equals(reason))
                || ("STOCK_RECEIPT".equals(kind) && "PURCHASE".equals(reason));
    }

    /**
     * 页面只选择已实现且已核服务器门禁的类型原因，空原因保持原页面行为。
     *
     * @param kind 实际页面类型例如STOCK_RECEIPT
     * @param reason 页面候选例如SALES_RETURN；不携可信组织或权限
     * @param allowReturns 服务器实际门禁true
     * @return 退货门禁满足时SALES_RETURN；空值按原类型返回PURCHASE或SALE，非法配对拒绝
     */
    public static String pageReason(Object kind, Object reason, boolean allowReturns) {
        String actualKind = pageKind(kind);
        String actualReason =
                reason == null
                        ? ("STOCK_RECEIPT".equals(actualKind) ? "PURCHASE" : "SALE")
                        : reason.toString();
        orderKind(actualKind, actualReason, allowReturns);
        return actualReason;
    }
}
