/**
 * CrmCommandRequestDaoImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
package com.sp.selplat.crm.commandrequest.dao;

/** 本表强类型公共DAO；审计/请求不对外开放通用更新。 */
@org.springframework.stereotype.Repository
public class CrmCommandRequestDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmCommandRequestDao {
    // 固定请求查找与完成只使用本域实际事务绑定的模板。
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 实际crmJdbcTemplate，不授权或更改连接归属
     */
    public CrmCommandRequestDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 精确锁读请求；参数例如tenant92/org901/PARTNER_SAVE/k1；返回真实行或null；无CRM事务拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public java.util.Map<String, Object> findRequest(com.sp.selplat.common.util.CommonParam p) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT"
                                + " id,payloadHash,requestState,resultPartnerId,resultContactId,resultOrderId,resultVersionNo,CAST(responseSnapshot"
                                + " AS VARCHAR) AS responseSnapshot FROM CrmCommandRequest WHERE"
                                + " tenantId=? AND businessOrgId=? AND commandName=? AND requestKey=?"
                                + " AND status=1 FOR UPDATE",
                        p.getParam("tenantId"),
                        p.getParam("businessOrgId"),
                        p.getParam("commandName"),
                        p.getParam("requestKey"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 同事务完成OPEN；参数例如id200000和首次结果；返回0/1；服务对0行抛错回滚。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public int complete(com.sp.selplat.common.util.CommonParam p) {
        requireCrmTransaction();
        // 商品回执只更新本表商品结果，约束拒绝与其他业务结果混用。
        if (p.getParam("resultProductId") != null) {
            return jdbc.update(
                    "UPDATE CrmCommandRequest SET requestState='COMPLETED',resultProductId=?,resultVersionNo=?,"
                            + "responseSnapshot=?,updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=?"
                            + " AND id=? AND requestState='OPEN' AND payloadHash=?",
                    p.getParam("resultProductId"), p.getParam("resultVersionNo"), p.getParam("responseSnapshot"),
                    p.getParam("tenantId"), p.getParam("businessOrgId"), p.getParam("id"), p.getParam("payloadHash"));
        }
        if (p.getParam("resultStockReversalRequestId") != null) {
            return jdbc.update(
                    "UPDATE CrmCommandRequest SET"
                            + " requestState='COMPLETED',resultStockReversalRequestId=?,resultVersionNo=?"
                            + ",responseSnapshot=?,updatedAt=CURRENT_TIMESTAMP"
                            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND requestState='OPEN'"
                            + " AND payloadHash=?",
                    p.getParam("resultStockReversalRequestId"),
                    p.getParam("resultVersionNo"),
                    p.getParam("responseSnapshot"),
                    p.getParam("tenantId"),
                    p.getParam("businessOrgId"),
                    p.getParam("id"),
                    p.getParam("payloadHash"));
        }
        if (p.getParam("resultReversalRequestId") != null) {
            return jdbc.update(
                    "UPDATE CrmCommandRequest SET"
                            + " requestState='COMPLETED',resultReversalRequestId=?,resultVersionNo=?,responseSnapshot=?,updatedAt=CURRENT_TIMESTAMP"
                            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND requestState='OPEN'"
                            + " AND payloadHash=?",
                    p.getParam("resultReversalRequestId"),
                    p.getParam("resultVersionNo"),
                    p.getParam("responseSnapshot"),
                    p.getParam("tenantId"),
                    p.getParam("businessOrgId"),
                    p.getParam("id"),
                    p.getParam("payloadHash"));
        }
        if (p.getParam("resultDocumentId") != null) {
            return jdbc.update(
                    "UPDATE CrmCommandRequest SET"
                            + " requestState='COMPLETED',resultDocumentId=?,resultVersionNo=?,responseSnapshot=?,updatedAt=CURRENT_TIMESTAMP"
                            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND requestState='OPEN'"
                            + " AND payloadHash=?",
                    p.getParam("resultDocumentId"),
                    p.getParam("resultVersionNo"),
                    p.getParam("responseSnapshot"),
                    p.getParam("tenantId"),
                    p.getParam("businessOrgId"),
                    p.getParam("id"),
                    p.getParam("payloadHash"));
        }
        return jdbc.update(
                "UPDATE CrmCommandRequest SET"
                        + " requestState='COMPLETED',resultPartnerId=?,resultContactId=?,resultOrderId=?,"
                        + "resultVersionNo=?,responseSnapshot=?,updatedAt=CURRENT_TIMESTAMP"
                        + " WHERE tenantId=? AND businessOrgId=? AND id=? AND requestState='OPEN' AND"
                        + " payloadHash=?",
                p.getParam("resultPartnerId"),
                p.getParam("resultContactId"),
                p.getParam("resultOrderId"),
                p.getParam("resultVersionNo"),
                p.getParam("responseSnapshot"),
                p.getParam("tenantId"),
                p.getParam("businessOrgId"),
                p.getParam("id"),
                p.getParam("payloadHash"));
    }

    /**
     * 保留请求审计列表默认主排序，同值记录以组织范围内唯一ID确定位置。
     *
     * @param conditions owning Service已核验条件，例如tenant92/org901/status1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际每页条数，例如2
     * @return 公共真实分页，例如三条同sortnum记录第2页返回唯一剩余记录、totalCount3
     *     异常或副作用示例：条件、SQL或方言错误沿公共链传播，不修改请求、审计或业务事实。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            java.util.Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }
}
