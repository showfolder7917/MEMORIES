/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.orderlineprogress.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.orderlineprogress.dao.CrmOrderLineProgressDao;
import com.sp.selplat.crm.orderlineprogress.service.CrmOrderLineProgressService;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。
 */
@org.springframework.stereotype.Service
public class CrmOrderLineProgressServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmOrderLineProgressDao>
    implements CrmOrderLineProgressService {

  // 真实Session和组织动作准入，不能从请求绑定可信身份。
  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  /**
   * 绑定真实身份及本域范围入口；构造不授予任何角色或许可。
   *
   * @param access Spring提供的真实CrmAccessService，例如Session核tenant92/actor9211后再核org901动作
   */
  public CrmOrderLineProgressServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
    this.access = access;
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
    page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
    return page;
  }

  /**
   * 公共真实范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 本组织有效记录；不存在统一拒绝
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 依据已锁真实冻结行创建或校验累计。
   *
   * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
   * @param source 已锁实际冻结来源行，例如id600000/quantity5/due500，不是客户端授权额度
   * @return 实际本表结果；缺真实许可/范围/事务拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockForLine(CommonParam input, Map<String, Object> source) {
    return lockForLine(input, source, "crm.stock.post");
  }

  /**
   * 方法作用及真实业务示例：在实际订单锁内创建或核验来源进度；org901/真实冻结source600000/actionfunds.post；返回真实授权数量与应收及累计；不信客户端额度，来源不匹配拒绝。
   * Frozen source and fixed action, e.g. org901/source600000/funds.post; returns actual progress
   * or rejects.
   *
   * @param input org901
   * @param source actual locked approved source
   * @param action fixed stock.post or funds.post
   * @return actual source-bound counters; never client due or default capacity
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockForLine(
      CommonParam input, Map<String, Object> source, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("orderLineId", source.get("id"));
    var row = getDao().lockForLine(p);
    if (row == null) {
      var entity = new CommonParam();
      entity.putParam("orderLineId", source.get("id"));
      entity.putParam("authorizedQuantity", CrmStockValueSupport.quantity(source.get("quantity")));
      entity.putParam("authorizedMinor", source.get("approvedDueMinor"));
      entity.putParam("refundableGoodsMinor", source.get("refundableGoodsMinor"));
      entity.putParam("refundPolicyVersion", source.get("refundPolicyVersion"));
      entity.putParam("stockPostedQuantity", 0L);
      entity.putParam("stockReturnedQuantity", 0L);
      entity.putParam("cashSettledMinor", java.math.BigDecimal.ZERO);
      entity.putParam("cashRefundedMinor", java.math.BigDecimal.ZERO);
      entity = CrmPartnerValueSupport.entity(entity, scope);
      entity.putParam("id", getSequence().get("id"));
      CrmPartnerValueSupport.changed(getDao().insert(entity));
      row = getDao().lockForLine(p);
    }
    if (!row.get("authorizedQuantity").toString().equals(source.get("quantity").toString())
        || !row.get("authorizedMinor").toString().equals(source.get("approvedDueMinor").toString())
        || !row.get("refundableGoodsMinor")
            .toString()
            .equals(source.get("refundableGoodsMinor").toString())
        || !row.get("refundPolicyVersion").equals(source.get("refundPolicyVersion"))) {
      throw CrmPartnerValueSupport.failure("CRM_PROGRESS_SOURCE_MISMATCH");
    }
    return row;
  }

  /**
   * 销售出库或采购入库累计履约量按固定库存许可在本表CAS。
   *
   * @param input org901/progress1400000/version0/quantity2，可信范围重新核验
   *     异常或副作用示例：stockPostedQuantity0→2且版本加一；超冻结数量或CAS0使外层完整库存单回滚，不因退货释放重复履约额度。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void applyIssue(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    var p = new CommonParam();
    for (String f : List.of("id", "versionNo")) {
      p.putParam(f, input.getParam(f));
    }
    p.putParam("quantity", CrmStockValueSupport.quantity(input.getParam("quantity")));
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().applyIssue(p));
  }

  /**
   * 销售已收或采购已付使用共同正向结算进度，不能超冻结来源应收应付。
   *
   * @param input org901/progress1400000/version0/amountMinor68，方向由实际冻结单据控制
   *     异常或副作用示例：cashSettledMinor0→68且版本加一，订单仍APPROVED；超额度、缺funds.post或CAS0整笔回滚，不创建退款权益。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void applyReceipt(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam(
        "amountMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("amountMinor")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().applyReceipt(p));
  }

  /**
   * 方法作用及真实业务示例：在实际订单锁内创建或核验来源进度；org901/真实冻结source600000/actionfunds.post；返回真实授权数量与应收及累计；不信客户端额度，来源不匹配拒绝。
   * Read actual source settlement; absence means no posted effects, no fabricated ledger row.
   *
   * @param input org901/sourceOrderLineId600000
   * @return actual counter or null, no writes
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> readFundsForLine(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("orderLineId", CrmPartnerValueSupport.positive(input.getParam("sourceOrderLineId")));
    return getDao().lockForLine(p);
  }

  /**
   * 读取实际来源库存履约与退货计数，不补缺进度或发号。
   *
   * @param input org901/sourceOrderLineId600001，真实stock.read范围重新检查
   * @return 原实际行或null，例如stockPostedQuantity3/stockReturnedQuantity1；副作用示例：只读库存进度，不释放履约容量。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> readStockForLine(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.read");
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("orderLineId", CrmPartnerValueSupport.positive(input.getParam("sourceOrderLineId")));
    return getDao().lockForLine(p);
  }

  /**
   * 已有原销售Order/OrderLine锁下只定位实际末退货节点，保持Document先于Progress组。
   *
   * @param input org901/sourceOrderLineId600001，范围不取客户端可信字段
   * @param action 固定crm.stock.post，重新核真实当前许可
   * @return 原实际行或null，例如lastReturnDetailId1300002；副作用示例：只读不锁进度，后续过账再锁进度核容量。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> peekReturnParent(CommonParam input, String action) {
    if (!"crm.stock.post".equals(action)) {
      throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
    }
    var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("orderLineId", CrmPartnerValueSupport.positive(input.getParam("sourceOrderLineId")));
    return getDao().peekForLine(p);
  }

  /**
   * 方法作用：重核真实权限并按来源行减少R，不改订单审批。
   *
   * @param input org901/id1400000/version1/amount68 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public void reverseReceipt(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam(
        "amountMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("amountMinor")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().reverseReceipt(p));
  }

  // 明确退货门禁，旧profile和生产不访问新增容量/节点业务。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
  private Boolean returnsEnabled;

  // 延迟消费不可变真实末退货效果，避免owning组件构造循环。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService>
      returnDetails;

  /**
   * 真实退货累计及本批末节点CAS；原I不减，不能借退货重开发货额度。
   *
   * @param input org901/id1400000/version1/quantity1/lastReturnDetailId1300002
   *     副作用示例：T0→1/version2/末节点1300002；节点跨来源、超额、旧版本整笔回滚。
   */
  @Override
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void applyReturn(CommonParam input) {
    if (!Boolean.TRUE.equals(returnsEnabled)) {
      throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
    }
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    var actual = getDao().lockScoped(p);
    var query = new CommonParam();
    query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    query.putParam("id", CrmPartnerValueSupport.positive(input.getParam("lastReturnDetailId")));
    var last = returnDetails.getObject().readAllocation(query, "crm.stock.post");
    if (actual == null
        || !actual.get("orderLineId").equals(last.get("sourceOrderLineId"))
        || !"STOCK".equals(last.get("effectKind"))
        || !"POST".equals(last.get("action"))
        || last.get("refundCapacityMinor") == null
        || ((Number) last.get("quantityDelta")).longValue() <= 0) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
    }
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam("quantity", CrmStockValueSupport.quantity(input.getParam("quantity")));
    p.putParam("lastReturnDetailId", last.get("id"));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().applyReturn(p));
  }

  /**
   * 按实际已收及商品退货权益增加F，原R保持且费用不纳入权益。
   *
   * @param input org901/id1400000/version2/amountMinor1 副作用示例：F0→1；超R/E(T)、Q0、接续无权益或旧版本整笔回滚。
   */
  @Override
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void applyRefund(CommonParam input) {
    if (!Boolean.TRUE.equals(returnsEnabled)) {
      throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
    }
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam(
        "amountMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("amountMinor")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().applyRefund(p));
  }

  /**
   * 方法作用：原资金拥有方沿本表实际范围和版本累计课程退款；不放宽原库存退货权益。
   * @param input 原org901/id100000/version1/amountMinor18/maximumCumulativeMinor18，累计上限由原资金核对给出
   * 异常或副作用示例：没有当前funds.post、超冻结净额／实收、混商品退货或旧版本拒绝；不自行写现金。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void applyCourseRefund(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", CrmPartnerValueSupport.version(input.getParam("versionNo")));
    p.putParam(
        "amountMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("amountMinor")));
    p.putParam(
        "maximumCumulativeMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("maximumCumulativeMinor")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().applyCourseRefund(p));
  }

  /**
   * 真实退款反向批次减少F，原R/I/T不变；例如F2→0、R5保持，旧版本整笔回滚。
   *
   * @param input org901/id1400000/version3/amountMinor2，身份从实际Session重核
   */
  @Override
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void reverseRefund(CommonParam input) {
    if (!Boolean.TRUE.equals(returnsEnabled)) {
      throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
    }
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam(
        "amountMinor",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
            input.getParam("amountMinor")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().reverseRefund(p));
  }

  /**
   * 真实库存reverse许可及版本CAS，原Order/现金不改；例如I3→0，失败全事务回滚。
   *
   * @param input org901/id1400000/version3/quantity1及实际服务器前驱
   */
  @Override
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void reverseIssue(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam("quantity", CrmStockValueSupport.quantity(input.getParam("quantity")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().reverseIssue(p));
  }

  /**
   * 真实库存reverse许可及版本CAS，原Order/现金不改；例如T3→2/回退末节点，失败全事务回滚。
   *
   * @param input org901/id1400000/version3/quantity1及实际服务器前驱
   */
  @Override
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void reverseReturn(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("versionNo", input.getParam("versionNo"));
    p.putParam("quantity", CrmStockValueSupport.quantity(input.getParam("quantity")));
    p.putParam("actorUserId", scope.get("actorUserId"));
    p.putParam("previousReturnDetailId", input.getParam("previousReturnDetailId"));
    CrmPartnerValueSupport.changed(getDao().reverseReturn(p));
  }
}
