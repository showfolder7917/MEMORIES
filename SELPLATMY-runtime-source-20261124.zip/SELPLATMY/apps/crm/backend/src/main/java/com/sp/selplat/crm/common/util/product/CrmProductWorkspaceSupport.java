/* 商品维护公共SELUI配置；2026-10-14，Codex。 */
package com.sp.selplat.crm.common.util.product;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 商品显示定义只消费真实分页和许可裁决，不执行SQL或付款激活。 */
public final class CrmProductWorkspaceSupport {
    /** 禁止构造；副作用示例：不建立商品或许可。 */
    private CrmProductWorkspaceSupport() { }

    /**
     * 构造商品列表及完整资料表单，中英日共用同一业务字段。
     * @param page 本组织真实分页，例如商品700000/totalCount1
     * @param writable 真实product.write裁决，例如false
     * @param language 语言候选，例如zh-CN
     * @return 实际示例：success=true/data包含grid、form、defaults、writeEnabled
     * 副作用示例：只产生本次JSON定义，不推定付款或目标系统已接通。
     */
    public static CommonResult build(CommonPageResult page, boolean writable, Object language) {
        int locale = "en-US".equals(language) ? 1 : "ja-JP".equals(language) ? 2 : 0;
        Map<String, String[]> words = Map.ofEntries(
                Map.entry("productCode", new String[]{"商品编码", "Product code", "商品コード"}),
                Map.entry("productName", new String[]{"商品名称", "Product name", "商品名"}),
                Map.entry("specification", new String[]{"规格说明", "Specification", "仕様"}),
                Map.entry("productKind", new String[]{"商品类型", "Product type", "商品種別"}),
                Map.entry("unitCode", new String[]{"单位", "Unit", "単位"}),
                Map.entry("purchasePrice", new String[]{"采购参考价（CNY）", "Purchase reference (CNY)", "仕入参考価格（CNY）"}),
                Map.entry("salePrice", new String[]{"销售参考价（CNY）", "Sale reference (CNY)", "販売参考価格（CNY）"}),
                Map.entry("businessState", new String[]{"状态", "State", "状態"}),
                Map.entry("termUnit", new String[]{"套餐时长单位", "Plan duration unit", "プラン期間単位"}),
                Map.entry("termCount", new String[]{"周期数量", "Duration count", "期間数"}),
                Map.entry("renewalMode", new String[]{"续订方式", "Renewal mode", "更新方式"}),
                Map.entry("activationSystemCode", new String[]{"服务系统标识", "Service system code", "サービスシステムコード"}));
        Map<String, Map<String, String>> enums = Map.of(
                "productKind", Map.of("GOODS", new String[]{"实物", "Goods", "物品"}[locale], "SERVICE", new String[]{"服务", "Service", "サービス"}[locale]),
                "unitCode", Map.of("EA", new String[]{"件/项（EA）", "Each (EA)", "件（EA）"}[locale]),
                "businessState", Map.of("ACTIVE", new String[]{"启用", "Active", "有効"}[locale], "INACTIVE", new String[]{"停用",
                "Inactive", "無効"}[locale]),
                "termUnit", Map.of("NONE", new String[]{"无时间套餐", "No time plan", "期間プランなし"}[locale], "DAY", new String[]{"天", "Day", "日"}[locale],
                        "MONTH", new String[]{"月", "Month", "月"}[locale], "YEAR", new String[]{"年", "Year", "年"}[locale]),
                "renewalMode", Map.of("NONE", new String[]{"不适用", "Not applicable", "対象外"}[locale], "MANUAL", new String[]{"手动续订",
                "Manual renewal", "手動更新"}[locale],
                        "AUTO", new String[]{"连续订阅", "Recurring subscription", "継続購読"}[locale]));
        List<Map<String, Object>> fields = new ArrayList<>();
        List<Map<String, Object>> columns = new ArrayList<>();
        // 固定字段序列避免Map遍历导致表单和列顺序变化。
        for (String id : List.of("productCode", "productName", "specification", "productKind", "unitCode", "purchasePrice", "salePrice",
                "businessState", "termUnit", "termCount", "renewalMode", "activationSystemCode")) {
            var field = new LinkedHashMap<String, Object>();
            field.put("id", id); field.put("label", words.get(id)[locale]); field.put("readOnly", !writable);
            field.put("maxLength", id.equals("productCode") || id.equals("activationSystemCode") ? 64 : 200);
            if (enums.containsKey(id)) {
                field.put("type", "select");
                field.put("options", enums.get(id).entrySet().stream().sorted(Map.Entry.comparingByKey())
                        .map(entry -> Map.of("value", entry.getKey(), "label", entry.getValue())).toList());
            }
            fields.add(field);
            if (List.of("productCode", "productName", "specification", "productKind", "purchasePrice", "salePrice", "businessState").contains(id)) {
                columns.add(Map.of("id", id, "field", id, "label", words.get(id)[locale], "wrapText", true));
            }
        }
        var items = page.getRecords().stream().map(row -> {
            var copy = new LinkedHashMap<>(row);
            for (String field : List.of("productKind", "businessState")) { copy.put(field, enums.get(field).get(row.get(field))); }
            return copy;
        }).toList();
        String title = new String[]{"商品管理", "Product management", "商品管理"}[locale];
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("title", title); data.put("writeEnabled", writable); data.put("synthetic", true);
        data.put("form", Map.of("id", "crm-product-editor", "title", title, "fields", fields, "actions", List.of()));
        data.put("defaults", Map.ofEntries(Map.entry("productCode", ""), Map.entry("productName", ""), Map.entry("specification", ""),
                Map.entry("productKind", "GOODS"), Map.entry("unitCode", "EA"), Map.entry("purchasePrice", "0.00"), Map.entry("salePrice", "0.00"),
                Map.entry("businessState", "ACTIVE"), Map.entry("termUnit", "NONE"), Map.entry("termCount", "0"), Map.entry("renewalMode", "NONE"),
                Map.entry("activationSystemCode", "")));
        data.put("grid", Map.of("grid", Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id", "minTableWidth", 760),
                "data", Map.of("items", items, "selectedIds", List.of()), "column", Map.of("items", columns, "ariaLabel", title),
                "select", Map.of("pageSize", Map.of("ariaLabel", new String[]{"每页行数", "Rows per page", "ページ件数"}[locale],
                        "options", List.of(10, 20, 50, 100).stream().map(size -> Map.of("value", size.toString(), "label",
                size.toString())).toList())),
                "title", Map.of("messages", Map.of("selectProject", title)),
                "pagination", Map.of("mode", "REMOTE", "totalCount", page.getTotalCount(), "currentPage", page.getPageNo(),
                "pageSize", page.getPageSize(),
                        "previousLabel", new String[]{"上一页", "Previous", "前へ"}[locale], "nextLabel", new String[]{"下一页", "Next", "次へ"}[locale],
                        "summaryAll", new String[]{"共 {total} 条", "{total} records", "合計 {total} 件"}[locale])));
        return CrmPartnerValueSupport.result(data);
    }
}
