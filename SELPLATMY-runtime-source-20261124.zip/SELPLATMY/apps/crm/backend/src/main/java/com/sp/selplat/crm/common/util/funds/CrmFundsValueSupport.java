/**
 * 销售收款值契约；2026-10-04，Codex；本轮仅格式和注释治理，不调用支付渠道。
 */
/**
 * 修改记录：2026-10-09，Codex；完整long行号先校验原1000上限；缺失/非文本币种保留原业务拒绝，避免算术与空指针异常。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.common.util.funds;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * 销售收款无状态值契约：同币种精确最小单位、完整分摊与真实冻结；不执行SQL、授予许可或接支付渠道。
 */
public final class CrmFundsValueSupport {

  /**
   * 不允许实例化无状态资金值工具；不创建账户或付款许可。
   */
  private CrmFundsValueSupport() {
    // 所有值方法静态调用，禁止构造带状态的资金工具实例。
  }

  /**
   * 规范正整数最小单位；小数、指数、零、负数或超过38位拒绝，不改变金额单位或舍入策略。
   *
   * @param value 输入金额文本，例如"68"或"9007199254740993"，不是主要单位小数"0.68"
   * @return 输入"68"返回BigDecimal整数68；大于JS安全整数的金额仍精确保存
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     输入"0"、"6.8e1"或39位数时抛INVALID_CRM_AMOUNT_MINOR
   */
  public static BigDecimal minor(Object value) {
    // 限制十进制整数文本 -> 不接受指数、负数或超DECIMAL38位数。
    String s = String.valueOf(value);
    if (!s.matches("[0-9]{1,38}")) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_AMOUNT_MINOR");
    }
    var n = new BigDecimal(s);
    if (n.signum() <= 0) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_AMOUNT_MINOR");
    }
    return n;
  }

  /**
   * 严格规范完整销售收款输入；只保留现有销售收款契约，不开放供应商付款或退款。
   *
   * @param input 客户端完整单据，例如org901/order600000/FUNDS_RECEIPT/SALE/CNY/keyk1，分摊金额"68"和"67"
   * @return
   *     新CommonParam；示例orderId=600000L、currency="CNY"，lines=[{lineNo:1,sourceOrderLineId:600001L,
   *     accountId:901L,amountMinor:BigDecimal(68)}]，规范命令字段保留
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     附加actor时抛INVALID_CRM_DOCUMENT_INPUT；金额数值而非文本时抛INVALID_CRM_AMOUNT_MINOR
   */
  public static CommonParam draft(CommonParam input) {
    return draft(input, false);
  }

  /**
   * 显式门禁后规范商品退款，要求原收款和真实退货两个引用。
   *
   * @param input
   *     org901/FUNDS_PAYMENT/SALES_RETURN/CNY及baseReceiptDetailId1300001/baseReturnDetailId1300002/amountMinor67
   * @param allowReturns 服务器明确退货结构门禁，不接受客户端开关
   * @return
   *     规范退款分摊，例如{sourceOrderLineId:600001,baseReceiptDetailId:1300001,baseReturnDetailId:1300002,amountMinor:67}
   */
  public static CommonParam draft(CommonParam input, boolean allowReturns) {
    return draft(input, allowReturns, false);
  }

  /**
   * 方法作用：原资金草稿额外接受已安装课程退款结构，来源数量与上限仍须实际拥有方核对。
   * @param input 原单据类型原因及一行courseReservationId/courseStudentId/curriculumCourseId/courseQuoteHash
   * @param allowReturns 原库存退货结构实际准入
   * @param allowCourseRefund 原课程退款结构实际准入，不接受客户端开关
   * @return 真实示例：FUNDS_PAYMENT/COURSE_RETURN及原预留100000，仍无现金效果。
   * 异常或副作用示例：未安装、混类型、缺真实摘要或多来源拒绝，不创建资金单据。
   */
  public static CommonParam draft(
      CommonParam input, boolean allowReturns, boolean allowCourseRefund) {
    boolean courseRefund = input != null && "COURSE_RETURN".equals(input.getParam("reason"));
    if (courseRefund && !allowCourseRefund) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_STRUCTURE_UNAVAILABLE");
    }
    // 白名单、类型、原因和明确文本币种同时校验；缺币种按业务错误拒绝，不漏出空指针。
    if (input == null
        || !Set.of(
                "organizationCandidateId",
                "id",
                "expectedVersion",
                "requestKey",
                "orderId",
                "documentKind",
                "reason",
                "currency",
                "lines")
            .containsAll(input.getParamMap().keySet())
        || !isFundsDocument(input.getParam("documentKind"), input.getParam("reason"), allowReturns)
        || !(input.getParam("currency") instanceof String currency)
        || !Set.of("CNY", "USD", "JPY").contains(currency)) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }
    var p = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(input, false);
    p.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("orderId")));
    p.putParam("currency", input.getParam("currency"));
    p.putParam("documentKind", input.getParam("documentKind"));
    p.putParam("reason", input.getParam("reason"));
    p.putParam(
        "orderKind",
        orderKind(input.getParam("documentKind"), input.getParam("reason"), allowReturns));
    if (!(input.getParam("lines") instanceof List<?> items)
        || items.isEmpty()
        || items.size() > 1000) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
    }
    // 完整规范来源行、账户和金额 -> 维持1000行及唯一行号限制。
    List<Map<String, Object>> lines = new ArrayList<>();
    Set<Integer> numbers = new HashSet<>();
    int position = 0;
    boolean refund = "SALES_RETURN".equals(input.getParam("reason"));
    if (courseRefund && items.size() != 1) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_ONE_SOURCE_REQUIRED");
    }
    for (Object item : items) {
      if (!(item instanceof Map<?, ?> row)
          || !Set.of(
                  "sourceOrderLineId",
                  "accountId",
                  "amountMinor",
                  "lineNo",
                  "baseReceiptDetailId",
                  "baseReturnDetailId",
                  "courseReservationId",
                  "courseStudentId",
                  "curriculumCourseId",
                  "courseQuoteHash")
              .containsAll(row.keySet())) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
      }
      // 先校验完整long候选的原业务上限，避免超大行号提前产生ArithmeticException。
      long no =
          row.get("lineNo") == null
              ? ++position
              : CrmPartnerValueSupport.positive(row.get("lineNo"));
      if (no > 1000 || !numbers.add((int) no)) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
      }
      var out = new TreeMap<String, Object>();
      out.put("lineNo", (int) no);
      out.put("sourceOrderLineId", CrmPartnerValueSupport.positive(row.get("sourceOrderLineId")));
      out.put("accountId", CrmPartnerValueSupport.positive(row.get("accountId")));
      if (!(row.get("amountMinor") instanceof String)) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_AMOUNT_MINOR");
      }
      out.put("amountMinor", minor(row.get("amountMinor")));
      if (refund) {
        out.put(
            "baseReceiptDetailId", CrmPartnerValueSupport.positive(row.get("baseReceiptDetailId")));
        out.put(
            "baseReturnDetailId", CrmPartnerValueSupport.positive(row.get("baseReturnDetailId")));
      } else if (row.containsKey("baseReceiptDetailId") || row.containsKey("baseReturnDetailId")) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
      }
      var courseFields =
          Set.of("courseReservationId", "courseStudentId", "curriculumCourseId", "courseQuoteHash");
      if (courseRefund) {
        for (String field :
            List.of("courseReservationId", "courseStudentId", "curriculumCourseId")) {
          out.put(field, CrmPartnerValueSupport.positive(row.get(field)));
        }
        Object hash = row.get("courseQuoteHash");
        if (!(hash instanceof String text) || !text.matches("[a-f0-9]{64}")) {
          throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        out.put("courseQuoteHash", hash);
      } else if (row.keySet().stream().anyMatch(courseFields::contains)) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
      }
      lines.add(out);
    }
    // 固定行序后交给状态服务 -> 值工具不写库或改变余额。
    lines.sort(Comparator.comparingInt(r -> ((Number) r.get("lineNo")).intValue()));
    p.putParam("lines", lines);
    return p;
  }

  /**
   * 冻结实际收款头与全部来源行、账户、币种和最小单位分摊；不重算历史批准金额。
   *
   * @param head 持锁实际收款头，例如org901/id1000000/version1/CNY
   * @param rows 全部实际分摊行，例如来源600001、账户901、金额68、币种CNY
   * @return 固定头字段和全部行的TreeMap；示例lines=[{id:"1000001",lineNo:1,sourceOrderLineId:"600001",
   *     accountId:"901",amountMinor:"68",currency:"CNY"}]，头versionNo="1"
   */
  public static Map<String, Object> snapshot(
      Map<String, Object> head, List<Map<String, Object>> rows) {
    // 固定可信头字段和来源摘要 -> 不带入未来余额或其他计算政策。
    var out = new TreeMap<String, Object>();
    var shown = CrmStockValueSupport.browser(head);
    for (String k :
        List.of(
            "id",
            "tenantId",
            "businessOrgId",
            "orderId",
            "orderKind",
            "currency",
            "documentKind",
            "reason",
            "orderSnapshotHash",
            "versionNo")) {
      out.put(k, shown.get(k));
    }
    // 每行稳定排序并映射全部资金维度 -> 不分页截断，不遗漏账户或币种。
    out.put(
        "lines",
        rows.stream()
            .sorted(Comparator.comparingInt(r -> ((Number) r.get("lineNo")).intValue()))
            .map(
                r -> {
                  var line = new TreeMap<String, Object>();
                  var view = CrmStockValueSupport.browser(r);
                  for (String k :
                      List.of(
                          "id",
                          "lineNo",
                          "sourceOrderLineId",
                          "accountId",
                          "amountMinor",
                          "currency")) {
                    line.put(k, view.get(k));
                  }
                  if ("SALES_RETURN".equals(head.get("reason"))) {
                    line.put("baseReceiptDetailId", view.get("baseReceiptDetailId"));
                    line.put("baseReturnDetailId", view.get("baseReturnDetailId"));
                  }
                  if ("COURSE_RETURN".equals(head.get("reason"))) {
                    for (String field :
                        List.of(
                            "courseReservationId",
                            "courseStudentId",
                            "curriculumCourseId",
                            "courseQuoteHash")) {
                      line.put(field, view.get(field));
                    }
                  }
                  return line;
                })
            .toList());
    return out;
  }

  /**
   * 根据实际批准状态与版本重验被冻结的完整金额、账户、币种及hash，不允许正文自报批准版本。
   *
   * @param head 持锁实际头，例如APPROVED/version2，批准前版本应为1
   * @param rows 持锁全部分摊行，例如来源600001/账户901/金额68/CNY
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     快照为空、版本被改或实际金额被篡改时抛CRM_DOCUMENT_SNAPSHOT_MISMATCH；不写库
   */
  public static void verifySnapshot(Map<String, Object> head, List<Map<String, Object>> rows) {
    Map<String, Object> frozen;
    Long originalVersion;
    try {
      // 解析已有批准快照并从实际状态推算批准前版本 -> 正文不能重定义授权。
      @SuppressWarnings("unchecked")
      Map<String, Object> parsed =
          JsonUtils.fromJson(
              (String) CrmStockValueSupport.browser(head).get("frozenSnapshot"), Map.class);
      if (parsed == null) {
        throw new IllegalArgumentException("Frozen snapshot object required");
      }
      frozen = parsed;
      int sinceFreeze =
          switch (String.valueOf(head.get("documentState"))) {
            case "APPROVED" -> 1;
            case "POSTED" -> 2;
            case "REVERSED" -> 3;
            default -> throw new IllegalArgumentException("Approved receipt state required");
          };
      originalVersion =
          Math.subtractExact(CrmPartnerValueSupport.version(head.get("versionNo")), sinceFreeze);
      if (originalVersion < 0
          || !originalVersion.equals(CrmPartnerValueSupport.version(frozen.get("versionNo")))) {
        throw new IllegalArgumentException("Frozen approval version changed");
      }
    } catch (RuntimeException malformed) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SNAPSHOT_MISMATCH");
    }
    // 正文摘要与实际完整行摘要双重比较 -> 拒绝同版本篡改，保留原拒绝码。
    var original = new LinkedHashMap<>(head);
    original.put("versionNo", originalVersion);
    if (!head.get("approvedSnapshotHash")
            .equals(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(frozen))
        || !head.get("approvedSnapshotHash")
            .equals(
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(
                    snapshot(original, rows)))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SNAPSHOT_MISMATCH");
    }
  }

  /**
   * 识别销售收款、采购付款及课程退款固定配对；课程写入仍须实际结构和来源核对。
   *
   * @param kind 实际单据类型，例如FUNDS_PAYMENT
   * @param reason 实际原因，例如PURCHASE
   * @return 示例返回true；付款SALE或销售退货返回false，不写库
   */
  public static boolean isFundsDocument(Object kind, Object reason) {
    return isFundsDocument(kind, reason, false);
  }

  /**
   * 验证实际资金配对；商品退款需服务器显式门禁。 实际调用示例：FUNDS_PAYMENT、SALES_RETURN、true，返回true，不写库。
   *
   * @param kind 实际FUNDS_PAYMENT
   * @param reason 实际SALES_RETURN
   * @param allowReturns 服务器明确门禁true
   * @return 门禁true的商品退款返回true；旧入口返回false
   */
  public static boolean isFundsDocument(Object kind, Object reason, boolean allowReturns) {
    if ("FUNDS_PAYMENT".equals(kind) && "COURSE_RETURN".equals(reason)) {
      return true;
    }
    if (allowReturns && "FUNDS_PAYMENT".equals(kind) && "SALES_RETURN".equals(reason)) {
      return true;
    }
    return ("FUNDS_RECEIPT".equals(kind) && "SALE".equals(reason))
        || ("FUNDS_PAYMENT".equals(kind) && "PURCHASE".equals(reason));
  }

  /**
   * 从严格类型原因派生冻结来源类型。
   *
   * @param kind 单据类型，例如FUNDS_PAYMENT
   * @param reason 原因，例如PURCHASE
   * @return PURCHASE或SALES；未知组合拒绝INVALID_CRM_DOCUMENT_INPUT
   */
  public static String orderKind(Object kind, Object reason) {
    return orderKind(kind, reason, false);
  }

  /**
   * 从严格实际配对及服务器门禁派生来源；销售退款不是采购付款。 实际调用示例：FUNDS_PAYMENT、SALES_RETURN、true，返回SALES，不写库。
   *
   * @param kind 实际FUNDS_PAYMENT
   * @param reason 实际SALES_RETURN
   * @param allowReturns 显式服务器true
   * @return 销售退款为SALES，采购付款为PURCHASE；非法组合拒绝
   */
  public static String orderKind(Object kind, Object reason, boolean allowReturns) {
    if (!isFundsDocument(kind, reason, allowReturns)) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }
    return "PURCHASE".equals(reason) ? "PURCHASE" : "SALES";
  }

  /**
   * 方法作用：规范原资金单据生命周期的可选查询条件，不由界面状态推导实收。
   *
   * @param candidate 可选原状态，例如SUBMITTED；null表示全部
   * @return SUBMITTED原文本，null返回null；不改变金额、组织或权限
   * @throws com.sp.selplat.common.exception.CommonBusinessException 空文本或未知状态拒绝INVALID_CRM_DOCUMENT_INPUT，无写入
   */
  public static String pageState(Object candidate) {
    if (candidate == null) {
      return null;
    }
    if (!(candidate instanceof String state)
        || !Set.of("DRAFT", "SUBMITTED", "APPROVED", "POSTED", "REVERSED").contains(state)) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }
    return state;
  }

  /**
   * 验证页面候选，默认保持现有销售收款入口。
   *
   * @param kind 可选页面类型，例如FUNDS_PAYMENT
   * @return 示例FUNDS_PAYMENT；空值返回FUNDS_RECEIPT，其他类型拒绝，无写入
   */
  public static String pageKind(Object kind) {
    if (kind == null) {
      return "FUNDS_RECEIPT";
    }
    if (!"FUNDS_RECEIPT".equals(kind) && !"FUNDS_PAYMENT".equals(kind)) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }
    return kind.toString();
  }

  /**
   * 页面只选择已实现且已核服务器门禁的类型原因，空原因保持原页面行为。
   *
   * @param kind 实际页面类型例如FUNDS_PAYMENT
   * @param reason 页面候选例如SALES_RETURN；不携可信组织或权限
   * @param allowReturns 服务器实际门禁true
   * @return 退货门禁满足时SALES_RETURN；空值按原类型返回PURCHASE或SALE，非法配对拒绝
   */
  public static String pageReason(Object kind, Object reason, boolean allowReturns) {
    String actualKind = pageKind(kind);
    String actualReason =
        reason == null
            ? ("FUNDS_PAYMENT".equals(actualKind) ? "PURCHASE" : "SALE")
            : reason.toString();
    orderKind(actualKind, actualReason, allowReturns);
    return actualReason;
  }
}
