/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.postingbatch.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.postingbatch.dao.CrmPostingBatchDao;
import com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService;
import java.util.List;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。
 */
@org.springframework.stereotype.Service
public class CrmPostingBatchServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmPostingBatchDao>
    implements CrmPostingBatchService {

  // 真实Session和组织动作准入，不能从请求绑定可信身份。
  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  /**
   * 绑定真实身份及本域范围入口；构造不授予任何角色或许可。
   *
   * @param access Spring提供的真实CrmAccessService，例如Session核tenant92/actor9211后再核org901动作
   */
  public CrmPostingBatchServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
    this.access = access;
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
    page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
    return page;
  }

  /**
   * 公共真实范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 本组织有效记录；不存在统一拒绝
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 真实POST批次插入；固定本表事务扩展。
   *
   * @param input 例如org901/id1000000及实际服务器字段
   * @return 实际本表结果；缺范围/事务拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Long append(CommonParam input) {
    var check = new CommonParam();
    check.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    check.putParam("id", input.getParam("documentId"));
    check.putParam("expectedVersion", input.getParam("headerVersion"));
    var approved = documents.preparePost(check);
    if (!"POST".equals(input.getParam("action"))
        || !approved.get("approvedSnapshotHash").equals(input.getParam("approvedSnapshotHash"))
        || ((List<?>) approved.get("lines")).size()
            != ((Number) input.getParam("detailCount")).intValue()) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    var row = CrmPartnerValueSupport.entity(input, scope);
    row.getParamMap().remove("versionNo");
    row.getParamMap().remove("headerVersion");
    row.putParam("postedByUserId", scope.get("actorUserId"));
    long id = getSequence().get("id");
    row.putParam("id", id);
    CrmPartnerValueSupport.changed(getDao().insert(row));
    return id;
  }

  // 真实冻结原收款头行及原单状态，禁止供应商退款复用。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.document.service.CrmDocumentService documents;

  /**
   * 真实POST批次插入；固定本表事务扩展。
   *
   * @param input 例如org901/id1000000及实际服务器字段
   * @return 实际本表结果；缺范围/事务拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Long appendFunds(CommonParam input) {
    return appendFundsChecked(input, java.util.Map.of());
  }

  /**
   * 方法作用：课程真实核对沿原批次事务再次验证，防止批次内部误走采购付款准备。
   * @param input 原org901/document100000/headerVersion2/冻结摘要
   * @param quotes 原资金取得的真实课程退款上限，例如预留100000对应18
   * @return 真实示例：原批次100000，不另建现金账本。
   * 异常或副作用示例：真实核对为空或冻结改变拒绝，所有现金效果回滚。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Long appendCourseFunds(
      CommonParam input, java.util.Map<Long, java.util.Map<String, Object>> quotes) {
    if (quotes == null || quotes.isEmpty()) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    return appendFundsChecked(input, quotes);
  }

  /**
   * 方法作用：原普通资金和课程退款共用批次插入，类型验证分别由原单据拥有方负责。
   * @param input 原实际批次字段，例如document100000/headerVersion2/detailCount1
   * @param quotes 课程真实核对Map，例如100000对应18；普通资金为空
   * @return 真实示例：原批次100000主键，头行冻结全部相符才插入。
   * 异常或副作用示例：冻结或行数不符拒绝，不把核对Map作为数据库字段写入。
   */
  private Long appendFundsChecked(
      CommonParam input, java.util.Map<Long, java.util.Map<String, Object>> quotes) {
    var check = new CommonParam();
    check.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    check.putParam("id", input.getParam("documentId"));
    check.putParam("expectedVersion", input.getParam("headerVersion"));
    var approved =
        quotes.isEmpty()
            ? documents.prepareFundsPost(check)
            : documents.prepareCourseFundsPost(check, quotes);
    if (!"POST".equals(input.getParam("action"))
        || !approved.get("approvedSnapshotHash").equals(input.getParam("approvedSnapshotHash"))
        || ((List<?>) approved.get("lines")).size()
            != ((Number) input.getParam("detailCount")).intValue()) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var row = CrmPartnerValueSupport.entity(input, scope);
    row.getParamMap().remove("versionNo");
    row.getParamMap().remove("headerVersion");
    row.putParam("postedByUserId", scope.get("actorUserId"));
    long id = getSequence().get("id");
    row.putParam("id", id);
    CrmPartnerValueSupport.changed(getDao().insert(row));
    return id;
  }

  /**
   * 方法作用：owning批次查询当前真实范围历史。
   *
   * @param input org901/document1000000
   * @param action crm.funds.read或reverse
   * @return 实际历史批次，不伪造有效标志 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public List<Map<String, Object>> findForDocument(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var p = new CommonParam();
    p.putParam("tenantId", scope.get("tenantId"));
    p.putParam("businessOrgId", scope.get("businessOrgId"));
    p.putParam("documentId", CrmPartnerValueSupport.positive(input.getParam("documentId")));
    return getDao().findForDocument(p);
  }

  /**
   * 方法作用：只新增绑定原批次的整批反向头，不更新原头。
   *
   * @param input 原批次1200000、document1000000、完整count2/hash
   * @return 新REVERSE批次id；重复原批次唯一约束拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Long appendFundsReverse(CommonParam input) {
    var query = new CommonParam();
    query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    query.putParam("id", input.getParam("originalBatchId"));
    var original = lockScoped(query, "crm.funds.reverse");
    if (!"POST".equals(original.get("action"))
        || !original.get("documentId").equals(input.getParam("documentId"))
        || !original.get("approvedSnapshotHash").equals(input.getParam("approvedSnapshotHash"))
        || !original.get("detailCount").equals(input.getParam("detailCount"))) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.reverse");
    var row = new CommonParam();
    for (String f :
        List.of("documentId", "originalBatchId", "approvedSnapshotHash", "detailCount")) {
      row.putParam(f, original.get(f.equals("originalBatchId") ? "id" : f));
    }
    row.putParam("action", "REVERSE");
    row.putParam("postedByUserId", scope.get("actorUserId"));
    row = CrmPartnerValueSupport.entity(row, scope);
    row.getParamMap().remove("versionNo");
    long id = getSequence().get("id");
    row.putParam("id", id);
    CrmPartnerValueSupport.changed(getDao().insert(row));
    return id;
  }

  /**
   * 方法作用：只新增绑定原批次的整批反向头，不更新原头。
   *
   * @param input 原批次1200000、document1000000、完整count2/hash
   * @return 新REVERSE批次id；重复原批次唯一约束拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Long appendStockReverse(CommonParam input) {
    var query = new CommonParam();
    query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    query.putParam("id", input.getParam("originalBatchId"));
    var original = lockScoped(query, "crm.stock.reverse");
    if (!"POST".equals(original.get("action"))
        || !original.get("documentId").equals(input.getParam("documentId"))
        || !original.get("approvedSnapshotHash").equals(input.getParam("approvedSnapshotHash"))
        || !original.get("detailCount").equals(input.getParam("detailCount"))) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.reverse");
    var row = new CommonParam();
    for (String f :
        List.of("documentId", "originalBatchId", "approvedSnapshotHash", "detailCount")) {
      row.putParam(f, original.get(f.equals("originalBatchId") ? "id" : f));
    }
    row.putParam("action", "REVERSE");
    row.putParam("postedByUserId", scope.get("actorUserId"));
    row = CrmPartnerValueSupport.entity(row, scope);
    row.getParamMap().remove("versionNo");
    long id = getSequence().get("id");
    row.putParam("id", id);
    CrmPartnerValueSupport.changed(getDao().insert(row));
    return id;
  }
}
