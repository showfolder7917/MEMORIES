/** 2026-10-06：限制CRM只读商品/用户关联预检JSON实际正文，不改平台或其他CRM接口容量。 */
package com.sp.selplat.crm.common.config;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.crm.product.controller.CrmProductController;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;

/** CRM迁移预检专属Spring绑定边界；平台底座冻结，不引入文件应用依赖或改变其他业务协议。 */
@ControllerAdvice(assignableTypes = {CrmProductController.class,
        com.sp.selplat.crm.contact.controller.CrmContactController.class})
public class CrmPreflightBodyBoundary extends RequestBodyAdviceAdapter {
    // 解码前2MiB实际流上限，纯词法层另有数量/字段/总文本限制。
    private static final int MAX_BODY_BYTES = 2 * 1024 * 1024;

    /**
     * 仅商品migrationPreflight和联系人migrationAssociationPreflight启用，原分页/详情接口规则不变。
     *
     * @param parameter Spring实际方法参数，例如CrmProductController.migrationPreflight
     * @param targetType 公共CommonParam类型
     * @param converterType Spring JSON转换器类型
     * @return 指定方法true，例如其他商品接口false；无权限/业务副作用
     */
    @Override
    public boolean supports(MethodParameter parameter, Type targetType,
            Class<? extends HttpMessageConverter<?>> converterType) {
        return parameter.getMethod() != null
                && java.util.Set.of("migrationPreflight", "migrationAssociationPreflight")
                        .contains(parameter.getMethod().getName());
    }

    /**
     * 在JSON解码前有界读取实际请求流，不以Content-Length代替实际字节计数。
     *
     * @param message 原HTTP JSON流，例如15字段商品词法清单
     * @param parameter CRM迁移预检CommonParam参数
     * @param targetType CommonParam目标类型
     * @param converterType 正式JSON转换器类型
     * @return 官方HttpInputMessage有界内存正文，例如1KiB JSON；不保存业务数据
     * @throws IOException 请求流失败时中止，例如客户端断开
     * @throws CommonBusinessException 实际超过2MiB时CRM_PREFLIGHT_INPUT_TOO_LARGE，由原公共异常处理器拒绝
     */
    @Override
    public HttpInputMessage beforeBodyRead(HttpInputMessage message, MethodParameter parameter,
            Type targetType, Class<? extends HttpMessageConverter<?>> converterType) throws IOException {
        byte[] body = message.getBody().readNBytes(MAX_BODY_BYTES + 1);
        if (body.length > MAX_BODY_BYTES) {
            throw new CommonBusinessException("CRM_PREFLIGHT_INPUT_TOO_LARGE", "迁移预检请求超过允许大小。");
        }
        return new HttpInputMessage() {
            /** @return 原HTTP头，例如Content-Type=application/json；不信任声明长度 */
            @Override
            public HttpHeaders getHeaders() {
                return message.getHeaders();
            }

            /** @return 实际有界JSON内存流；例如原词法清单，不访问源/目标库 */
            @Override
            public InputStream getBody() {
                return new ByteArrayInputStream(body);
            }
        };
    }
}
