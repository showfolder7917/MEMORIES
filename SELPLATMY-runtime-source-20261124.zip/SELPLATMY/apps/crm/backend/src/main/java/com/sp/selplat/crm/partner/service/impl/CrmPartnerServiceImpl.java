/**
 * CrmPartnerServiceImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
/* 修改记录：2026-10-09，Codex；缺请求沿原身份及组织准入拒绝，不先抛空指针，不修改许可。 */
/* 修改记录：2026-10-27，首次客户分类与原客户创建同事务提交；教学按稳定分类编号调用，已有分类独立维护。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.partner.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.partner.dao.CrmPartnerDao;
import com.sp.selplat.crm.partner.service.CrmPartnerService;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本表直接复用公共CRUD/号段，HTTP只开放明确范围和版本命令；不自建权限系统。
 */
@Service
public class CrmPartnerServiceImpl extends BaseServiceImpl<CrmPartnerDao>
    implements CrmPartnerService {

  // 真实Session和显式合成许可统一由本域准入检查，生产缺公共resolver时拒绝。
  private final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  // 事务协调使用公共Spring扩展，不在Service直接执行SQL或跨表DAO。
  private final org.springframework.transaction.support.TransactionTemplate transaction;

  private final com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests;

  private final com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;

  // 通过延迟拥有方避免客户与分类服务相互构造；首次类型在原客户事务内提交。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.customertypeselection.service.CrmCustomerTypeSelectionService>
      initialTypes;

  /**
   * 绑定伙伴真实准入、幂等、审计及具名事务；构造不创建伙伴或角色。
   *
   * @param access 真实Session及org901伙伴动作准入
   * @param requests 本域命令首次结果owning服务，例如PARTNER_SAVE/keyk1
   * @param audit 实际CRM事务审计服务，记录actor9211
   * @param manager crmTransactionManager，维持现有REQUIRES_NEW命令边界
   */
  public CrmPartnerServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access,
      com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests,
      com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit,
      @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
          org.springframework.transaction.PlatformTransactionManager manager) {
    this.access = access;
    this.requests = requests;
    this.audit = audit;
    transaction = new org.springframework.transaction.support.TransactionTemplate(manager);
    transaction.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    transaction.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
  }

  /**
   * 实际分页与后端控件配置；写裁决失败显示只读，不开放正式权限。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   *     业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
   * @return 公共结果，data包含真实分页和SELUI表单定义；synthetic明确为true
   */
  @Override
  @OperationLog
  public CommonResult workspace(CommonPageParam input) {
    CommonPageResult page = getStore(input);
    boolean writable = false;
    try {
      access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
      writable = true;
    } catch (com.sp.selplat.common.exception.CommonBusinessException denied) {
      if (!"CRM_ACTION_FORBIDDEN".equals(denied.getErrorCode())) {
        throw denied;
      }
    }
    return com.sp.selplat.crm.common.util.authorization.CrmWorkspaceEvidence.decorate(
        com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport.build(
            page, false, writable, input.getParam("lang")),
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read"),
        input.getParam("lang"));
  }

  /**
   * 分页本组织记录；参数例如org901/page1；返回公共分页；无真实read许可拒绝。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   * @return 公共真实分页，例如records包含本组织客户；不会退化为全库
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
    var scope =
        access.requirePartnerScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.read");
    var query = CrmPartnerValueSupport.page(input, scope, "partnerNameLike");
    // 归档筛选在本表SQL的COUNT及分页之前生效，不在浏览器过滤当前页。
    String archiveView = CrmPartnerValueSupport.archiveView(input.getParam("archiveView"));
    if (!"ALL".equals(archiveView)) {
      query.putParam("archivedFlag", "ARCHIVED".equals(archiveView));
    }
    var page = super.getStore(query);
    // 与详情/工作区复用原精确文本合同，避免公开分页主键在JavaScript中损失精度。
    page.setRecords(
        page.getRecords().stream()
            .map(com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport::browserRecord)
            .toList());
    return page;
  }

  /**
   * 本组织详情；参数例如org901/id200000；返回公共data；不存在或越组织同样拒绝。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
    var scope =
        access.requirePartnerScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.read");
    var row =
        getDao()
            .getById(
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
      throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
          "CRM_RECORD_NOT_FOUND");
    }
    return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(
        com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport.browserRecord(row));
  }

  /**
   * 未开放通用批量读取；参数例如空items；无成功返回；拒绝避免绕过组织许可。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
        "CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 服务端审计人；无参数；返回真实账号例如9211；失效身份拒绝，不使用默认1。
   *
   * @return 真实当前操作员，例如9211；失效身份抛错
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 服务端租户；无参数；返回真实租户例如92；不使用客户端或默认租户。
   *
   * @return 真实当前租户，例如92；不使用默认租户
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 没有默认管理员；无参数；返回false；不增加任何权限。 业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
   *
   * @return false；本域不隐式赋予管理员
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用无版本写入口关闭；参数例如id200000；无成功返回；维护只能经过具名保存事务。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
        "CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * 方法作用：本表保存并同事务完成首次分类、请求和业务审计；唯一冲突退出失败事务后才读首次结果。
   *
   * @param input 完整业务参数，例如org901/keyk1/name示范，编辑含id200000/expectedVersion0
   * @return 公共结果，例如data={id:"200000",versionNo:"0",replay:false,synthetic:true}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可、旧版本、同键异内容或约束失败整笔回滚
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult save(CommonParam input) {
    // 先实际回查组织动作，不让非法输入在未授权时探测业务记录。
    access.requirePartnerScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.write");
    CommonParam normalized =
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.normalize(input, false);
    String hash = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
    CommonParam request = new CommonParam();
    request.putParam("organizationCandidateId", normalized.getParam("organizationCandidateId"));
    request.putParam("commandName", "PARTNER_SAVE");
    request.putParam("requestKey", normalized.getParam("requestKey"));
    request.putParam("payloadHash", hash);
    try {
      return access.executeTransaction(
          normalized.getParam("organizationCandidateId"),
          "crm.partner.write",
          transaction,
          status -> {
            var scope =
                access.requirePartnerScope(
                    normalized.getParam("organizationCandidateId"), "crm.partner.write");
            Long requestId = requests.claim(request);
            CommonParam row =
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(
                    normalized, scope);
            Long prior = null;
            long id;
            long version;
            if (normalized.getParam("id") == null) {
              id = getSequence().get("id");
              version = 0;
              row.putParam("id", id);
              com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                  getDao().insert(row));
            } else {
              id = (Long) normalized.getParam("id");
              var existing =
                  getDao()
                      .lockScoped(
                          com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail(
                              normalized, scope));
              if (existing == null) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "CRM_RECORD_NOT_FOUND");
              }
              prior = ((Number) existing.get("versionNo")).longValue();
              if (prior.longValue() != (Long) normalized.getParam("expectedVersion")
                  || prior == Long.MAX_VALUE) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "STALE_CRM_VERSION");
              }
              row.putParam("actorUserId", scope.get("actorUserId"));
              row.putParam("expectedVersion", prior);
              com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                  getDao().updateVersion(row));
              version = prior + 1;
            }
            // 客户已插入但尚未提交；类型锁、集合及历史失败会连同原命令和客户一起回滚。
            if (normalized.getParam("initialCustomerTypeIdsJson") != null) {
              var owner = initialTypes.getIfAvailable();
              if (owner == null) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "INVALID_CRM_INPUT");
              }
              var selection = new CommonParam();
              selection.putParam(
                  "organizationCandidateId", normalized.getParam("organizationCandidateId"));
              selection.putParam("partnerId", id);
              selection.putParam("requestKey", normalized.getParam("requestKey"));
              selection.putParam("typeIdsJson", normalized.getParam("initialCustomerTypeIdsJson"));
              owner.initializeForPartner(selection);
            }
            // 提交前再次真实检查测试许可；将来公共许可撤销合同由owner提供，不声称两库ACID。
            access.requirePartnerScope(
                normalized.getParam("organizationCandidateId"), "crm.partner.write");
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("id", Long.toString(id));
            data.put("versionNo", Long.toString(version));
            data.put("replay", false);
            data.put("synthetic", scope.get("synthetic"));
            request.putParam("id", requestId);
            request.putParam("resultPartnerId", id);
            request.putParam("resultVersionNo", version);
            request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
            requests.complete(request);
            CommonParam event = new CommonParam();
            event.putParam(
                "organizationCandidateId", normalized.getParam("organizationCandidateId"));
            event.putParam("commandRequestId", requestId);
            event.putParam("action", "PARTNER_SAVE");
            event.putParam("resourceId", id);
            event.putParam("previousVersion", prior);
            event.putParam("newVersion", version);
            audit.append(event);
            return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(data);
          });
    } catch (com.sp.selplat.common.exception.CommonBusinessException conflict) {
      if (!"CRM_COMMAND_EXISTS".equals(conflict.getErrorCode())) {
        throw conflict;
      }
      var stored = requests.committed(request);
      if (stored == null || !hash.equals(stored.get("payloadHash"))) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
            "CRM_COMMAND_CONFLICT");
      }
      if (!"COMPLETED".equals(stored.get("requestState"))) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
            "CRM_COMMAND_IN_PROGRESS");
      }
      @SuppressWarnings("unchecked")
      Map<String, Object> data =
          JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
      data.put("replay", true);
      return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(data);
    }
  }

  /**
   * 本表同事务锁读；参数例如org901/id200000；返回真实行；缺许可/记录或无CRM事务拒绝。
   *
   * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
   * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockForMaintenance(CommonParam input) {
    // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
    var scope =
        access.requirePartnerScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.write");
    var row =
        getDao()
            .lockScoped(
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
          "CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  /**
   * 订单owning服务调用真实客户范围锁，不要求审核人拥有客户写许可。
   *
   * @param input 本表候选范围和主键，例如org901/id200000
   * @param action 固定订单动作，例如crm.order.approve
   * @return 本组织真实客户行；不存在/失效状态或缺动作许可拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺范围许可或非ACTIVE引用时拒绝，要求CRM事务
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockForOrder(CommonParam input, String action) {
    // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), action);
    var row =
        getDao()
            .lockScoped(
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.detail(input, scope));
    if (row == null || !"ACTIVE".equals(row.get("businessState"))
        || Boolean.TRUE.equals(row.get("archivedFlag"))) {
      throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
          "CRM_REFERENCE_UNAVAILABLE");
    }
    return row;
  }

  /**
   * 订单read许可范围内真实客户选择，不把缺客户写许可当订单审批阻断。
   *
   * @param input 候选org901/page1
   * @return 本组织status1且ACTIVE的真实分页；无范围许可拒绝
   *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
   */
  @Override
  @OperationLog
  public CommonPageResult orderChoices(CommonPageParam input) {
    // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
    var page =
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page(
            input, scope, "partnerNameLike");
    page.putParam("businessState", "ACTIVE");
    page.putParam("archivedFlag", false);
    return super.getStore(page);
  }

  /**
   * 方法作用：按原订单读取资格限定本页客户名称，读取前后重核真实范围。
   *
   * @param organizationCandidateId 明确组织候选，例如901
   * @param ids 调用方当前页主键，例如[600000]，不超过100项
   * @return 真实示例：本组织安全字段集合；空集合返回空，不读取全表
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格变化、主键非法或超页上限时拒绝
   */
  @Override
  @OperationLog
  public java.util.List<java.util.Map<String, Object>> orderListNames(
      Object organizationCandidateId, java.util.List<Long> ids) {
    var scope = access.requireOrderScope(organizationCandidateId, "crm.order.read");
    if (ids == null || ids.size() > 100) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
    }
    var selected = ids.stream().map(CrmPartnerValueSupport::positive).distinct().toList();
    // 仅本表DAO读取；原客户独立状态与历史订单商品快照不被重新解释为当前候选。
    var rows =
        getDao()
            .orderListNames(
                ((Number) scope.get("tenantId")).longValue(),
                ((Number) scope.get("businessOrgId")).longValue(),
                selected);
    if (!scope.equals(access.requireOrderScope(organizationCandidateId, "crm.order.read"))) {
      throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
    }
    return rows;
  }
  /**
   * 方法作用：按原资金读取资格查询本页往来方名称，前后核对同一租户和组织范围。
   *
   * @param organizationCandidateId 真实组织候选，例如901
   * @param ids 已审核来源本页往来方主键，例如[501]，最多100项
   * @return 真实示例：[{id:501,partnerName:课程报名家长}]；空集合返回空，不含联系方式
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格变化、主键非法或超限拒绝，无写入副作用
   */
  @Override
  @OperationLog
  public java.util.List<java.util.Map<String, Object>> fundsListNames(
      Object organizationCandidateId, java.util.List<Long> ids) {
    var scope = access.requireFundsScope(organizationCandidateId, "crm.funds.read");
    if (ids == null || ids.size() > 100) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
    }
    var selected = ids.stream().map(CrmPartnerValueSupport::positive).distinct().toList();
    var rows = getDao().orderListNames(
        ((Number) scope.get("tenantId")).longValue(),
        ((Number) scope.get("businessOrgId")).longValue(), selected);
    if (!scope.equals(access.requireFundsScope(organizationCandidateId, "crm.funds.read"))) {
      throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
    }
    return rows;
  }
  /**
   * 方法作用：归档单一客户，复用原客户写资格、CRM事务及具名请求，不操作他域资料。
   *
   * @param input 真实候选及版本，例如org901/id501/expectedVersion0/reasonText暂停往来/requestKeya1
   * @return 真实返回示例：data={id:"501",versionNo:"1",archivedFlag:true,replay:false,synthetic:false}。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺资格、旧版本、已归档或审计失败整笔回滚
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult archive(CommonParam input) {
    return changeArchive(input, true);
  }

  /**
   * 方法作用：恢复原归档客户，原业务状态和最近归档信息保留，原因追加到原审计。
   *
   * @param input 真实候选及版本，例如org901/id501/expectedVersion1/reasonText恢复往来/requestKeyr1
   * @return 真实返回示例：data={id:"501",versionNo:"2",archivedFlag:false,replay:false,synthetic:false}。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺资格、旧版本、未归档或审计失败整笔回滚
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult restore(CommonParam input) {
    return changeArchive(input, false);
  }

  /**
   * 方法作用：原客户维护请求与归档操作共享客户更新幂等命名空间，以完整目标/原因摘要区分操作。
   *
   * @param input 原服务器收到的正文，例如org901/id501/version0/reason暂停往来
   * @param archived 服务端固定目标，例如true归档或false恢复
   * @return 真实返回示例：同键原正文重放返回首次id501/version1/replay=true，不重复版本或审计。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 同键异内容、状态/版本竞争、失权或审计失败回滚
   */
  private CommonResult changeArchive(CommonParam input, boolean archived) {
    // 沿原资格先核范围，随后只接受具名正文，不让客户端写身份、业务状态或归档操作者。
    access.requirePartnerScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.write");
    CommonParam normalized = CrmPartnerValueSupport.archive(input, archived);
    String hash = CrmPartnerValueSupport.hash(normalized);
    var request = new CommonParam();
    request.putParam("organizationCandidateId", normalized.getParam("organizationCandidateId"));
    request.putParam("commandName", "PARTNER_SAVE");
    request.putParam("requestKey", normalized.getParam("requestKey"));
    request.putParam("payloadHash", hash);
    try {
      return access.executeTransaction(
          normalized.getParam("organizationCandidateId"),
          "crm.partner.write",
          transaction,
          state -> {
            var scope =
                access.requirePartnerScope(
                    normalized.getParam("organizationCandidateId"), "crm.partner.write");
            Long requestId = requests.claim(request);
            var existing = getDao().lockScoped(CrmPartnerValueSupport.detail(normalized, scope));
            if (existing == null) {
              throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
            }
            long prior = ((Number) existing.get("versionNo")).longValue();
            if (prior != (Long) normalized.getParam("expectedVersion") || prior == Long.MAX_VALUE) {
              throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
            }
            if (Boolean.TRUE.equals(existing.get("archivedFlag")) == archived) {
              throw CrmPartnerValueSupport.failure("CRM_ARCHIVE_STATE_CHANGED");
            }
            // 本表CAS与请求回执、原业务审计处在同一CRM事务，失败不得留下半笔归档。
            var update = CrmPartnerValueSupport.detail(normalized, scope);
            update.putParam("expectedVersion", prior);
            update.putParam("archivedFlag", archived);
            update.putParam("reasonText", normalized.getParam("reasonText"));
            update.putParam("actorUserId", scope.get("actorUserId"));
            CrmPartnerValueSupport.changed(getDao().updateArchive(update));
            access.requirePartnerScope(
                normalized.getParam("organizationCandidateId"), "crm.partner.write");
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("id", normalized.getParam("id").toString());
            data.put("versionNo", Long.toString(prior + 1));
            data.put("archivedFlag", archived);
            data.put("replay", false);
            data.put("synthetic", scope.get("synthetic"));
            request.putParam("id", requestId);
            request.putParam("resultPartnerId", normalized.getParam("id"));
            request.putParam("resultVersionNo", prior + 1);
            request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
            requests.complete(request);
            var event = new CommonParam();
            event.putParam(
                "organizationCandidateId", normalized.getParam("organizationCandidateId"));
            event.putParam("commandRequestId", requestId);
            event.putParam("action", archived ? "PARTNER_ARCHIVE" : "PARTNER_RESTORE");
            event.putParam("resourceId", normalized.getParam("id"));
            event.putParam("previousVersion", prior);
            event.putParam("newVersion", prior + 1);
            event.putParam("reasonText", normalized.getParam("reasonText"));
            audit.append(event);
            return CrmPartnerValueSupport.result(data);
          });
    } catch (com.sp.selplat.common.exception.CommonBusinessException conflict) {
      // 首次已提交后才可读取原快照；同键不同目标、原因或版本全部拒绝，不重新取当前实体冒充回执。
      if (!"CRM_COMMAND_EXISTS".equals(conflict.getErrorCode())) {
        throw conflict;
      }
      var stored = requests.committed(request);
      if (stored == null || !hash.equals(stored.get("payloadHash"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
      }
      if (!"COMPLETED".equals(stored.get("requestState"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
      }
      @SuppressWarnings("unchecked")
      Map<String, Object> data =
          JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
      data.put("replay", true);
      return CrmPartnerValueSupport.result(data);
    }
  }
}
