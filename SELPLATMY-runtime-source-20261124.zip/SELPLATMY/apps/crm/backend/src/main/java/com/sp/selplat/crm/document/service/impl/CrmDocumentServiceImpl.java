/**
 * 销售出库、采购入库和销售收款单据本表组件；2026-10-04，Codex；生产默认拒绝不变。
 * 修改：2026-10-27，Codex；原资金草稿与审核接真实课程预留，跨域核对先于写锁。
 * 修改：2026-10-10，Codex；工作台或来源缺请求仍先走原身份与组织拒绝，不落入空指针。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
/* 修改记录：2026-10-28，财务按明确来源订单精确查询原资金单据，不改变金额与记账。 */
/* 2026-11-06：原资金审核补具名驳回，保留异人/CAS/原审计与资金无副作用。 */
package com.sp.selplat.crm.document.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.document.dao.CrmDocumentDao;
import com.sp.selplat.crm.document.service.CrmDocumentService;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。
 */
@org.springframework.stereotype.Service
public class CrmDocumentServiceImpl
    extends com.sp.selplat.common.service.BaseServiceImpl<CrmDocumentDao>
    implements CrmDocumentService {

  // 复用真实Session/组织动作准入；本表服务不能自行授予权限。
  protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  /**
   * 注入真实范围入口；构造不授予权限或创建账本。
   *
   * @param access Spring提供的CrmAccessService，例如读取真实tenant92及候选组织901的服务
   */
  public CrmDocumentServiceImpl(
      com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
    this.access = access;
  }

  /**
   * 公共真实范围分页。
   *
   * @param input 例如org901/page1；可信身份由Session给出
   * @return 本组织精确文本记录；缺库存读许可拒绝
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var p = CrmPartnerValueSupport.page(input, scope, null);
    String documentKind = CrmStockValueSupport.pageKind(input.getParam("documentKind"));
    p.putParam("documentKind", documentKind);
    p.putParam(
        "reason",
        CrmStockValueSupport.pageReason(
            documentKind, input.getParam("reason"), returnsAvailable()));
    var page = super.getStore(p);
    page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
    return page;
  }

  /**
   * 批读不开放。
   *
   * @param input 例如空items
   * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
  }

  /**
   * 真实操作员，无默认账号。
   *
   * @return 例如9211；失效Session拒绝
   */
  @Override
  protected Long getCurrentOperatorId() {
    return access.requireDraftActor().get("ownerUserId");
  }

  /**
   * 真实租户，无默认租户。
   *
   * @return 例如92；失效Session拒绝
   */
  @Override
  protected Long getCurrentTenantId() {
    return access.requireDraftActor().get("tenantId");
  }

  /**
   * 无隐式管理员。
   *
   * @return 返回示例：false；不扩权
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 通用写关闭。
   *
   * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
  }

  /**
   * owning精确锁，只由具名真实CRM事务消费。
   *
   * @param input 例如org901/id1000000
   * @param action 固定stock.post动作
   * @return 本组织真实行；没有实际记录/许可拒绝
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> lockScoped(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    if (row == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    return row;
  }

  // 固定本域owning服务，不注入其他表DAO；Provider打破单据行状态重核依赖环。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.order.service.CrmOrderService orders;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.product.service.CrmProductService products;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.warehouse.service.CrmWarehouseService warehouses;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.documentline.service.CrmDocumentLineService lines;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService commands;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
  private org.springframework.transaction.PlatformTransactionManager manager;

  // 延迟取得原资金拥有方，跨域准备先于CRM写锁，避免循环依赖及事务互等。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.capability.funds.service.CrmFundsService>
      courseRefundFunds;

  /**
   * 方法作用：写锁前核真实课程预留及原净额，已有命令仍走原claim与首次回执。
   * @param input 原规范命令，例如org901/id100000/expectedVersion0/requestKey原UUID
   * @param command 原固定命令，例如FUNDS_DOCUMENT_SUBMIT
   * @param candidates 实际草稿行提供者，例如预留100000、学生50、课程400和原摘要
   * @return 真实示例：键100000对应maximumRefundMinor18；普通单据返回空Map。
   * 异常或副作用示例：预留失效或摘要改变拒绝；只读核对不持CRM写锁、不写现金。
   */
  private Map<Long, Map<String, Object>> prepareCourseQuotes(
      CommonParam input,
      String command,
      java.util.function.Supplier<List<Map<String, Object>>> candidates) {
    var req = request(input, command);
    if (commands.committed(req) != null) {
      return Map.of();
    }
    try {
      Map<Long, Map<String, Object>> quotes = new TreeMap<>();
      // 坐标来自规范草稿或本表实际行，真实金额只接受原资金拥有方的读取结果。
      for (var row : candidates.get()) {
        long reservation = CrmPartnerValueSupport.positive(row.get("courseReservationId"));
        var query = new CommonParam();
        query.putParam("studentId", row.get("courseStudentId"));
        query.putParam("curriculumCourseId", row.get("curriculumCourseId"));
        query.putParam("reservationId", reservation);
        var result = courseRefundFunds.getObject().courseRefundQuote(query);
        if (!result.isSuccess() || !(result.getData() instanceof Map<?, ?>)) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
        }
        @SuppressWarnings("unchecked")
        var quote = (Map<String, Object>) result.getData();
        if (!quote.get("quoteHash").equals(row.get("courseQuoteHash"))) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_QUOTE_CHANGED");
        }
        if (quotes.put(reservation, quote) != null) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_ONE_SOURCE_REQUIRED");
        }
      }
      return quotes;
    } catch (RuntimeException failure) {
      // 竞态首次已提交时交回原execute核payloadHash，不把后来的取消覆盖首次结果。
      if (commands.committed(req) != null) {
        return Map.of();
      }
      throw failure;
    }
  }

  /**
   * 方法作用：原提交或审核独立只读取得本表课程行，释放CRM连接后才跨域核对。
   * @param input 原命令org901/id100000，不接受外部课程行
   * @param action 固定原资金动作，例如crm.funds.approve
   * @return 真实示例：原COURSE_RETURN唯一预留行；普通收付款返回空List。
   * 异常或副作用示例：实际结构或资格不足拒绝，只读事务回滚且不更改状态。
   */
  private List<Map<String, Object>> courseQuoteRows(CommonParam input, String action) {
    var tx = transaction();
    tx.setReadOnly(true);
    return tx.execute(
        status -> {
          var scope = access.requireFundsScope(input.getParam("organizationCandidateId"), action);
          var ref = getDao().sourceReference(CrmPartnerValueSupport.detail(input, scope));
          status.setRollbackOnly();
          if (ref == null || !"COURSE_RETURN".equals(ref.get("reason"))) {
            return List.of();
          }
          if (!access.formalCapabilityAvailable("courseRefund")) {
            throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_STRUCTURE_UNAVAILABLE");
          }
          return lines.readAll(relation(input, "documentId", input.getParam("id")), action);
        });
  }

  /**
   * 每笔真实CRM事务独立执行，实际双池4不扩大以掩盖连接问题。
   *
   * @return READ_COMMITTED/REQUIRES_NEW的框架事务；无分布式ACID承诺
   */
  private org.springframework.transaction.support.TransactionTemplate transaction() {
    var t = new org.springframework.transaction.support.TransactionTemplate(manager);
    t.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    t.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    return t;
  }

  /**
   * 候选组织与关联id参数。
   *
   * @param input 规范候选例如org901
   * @param key 服务器选定id/orderId/documentId等固定键
   * @param value 实际正数主键，例如1000000
   * @return 新公共参数，不复制客户端身份
   */
  private CommonParam relation(CommonParam input, String key, Object value) {
    var p = new CommonParam();
    p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    p.putParam(key, value);
    return p;
  }

  /**
   * 从owningOrder锁真实销售冻结来源。
   *
   * @param input org901/orderId600000
   * @param action 固定库存动作，例如stock.post
   * @return 实际头/全部行；未审核或冻结不符拒绝
   */
  private Map<String, Object> order(CommonParam input, String action) {
    var sourceInput = relation(input, "id", input.getParam("orderId"));
    return "PURCHASE".equals(input.getParam("orderKind"))
        ? (action.startsWith("crm.funds.")
            ? orders.lockApprovedPurchaseForFunds(sourceInput, action)
            : orders.lockApprovedPurchaseForStock(sourceInput, action))
        : orders.lockApprovedForStock(sourceInput, action);
  }

  /**
   * 实际document行按owning服务完整读回。
   *
   * @param input org901
   * @param header 已锁单据1000000
   * @param action 固定stock动作
   * @return 本单全量真实行，按lineNo显示而非截断
   */
  private List<Map<String, Object>> rows(
      CommonParam input, Map<String, Object> header, String action) {
    var all =
        new ArrayList<>(lines.readAll(relation(input, "documentId", header.get("id")), action));
    all.sort(Comparator.comparingInt(r -> ((Number) r.get("lineNo")).intValue()));
    return all;
  }

  /**
   * 先非锁定位本表不可变orderId，再Order/OrderLine，再Document，遵守统一锁序。
   *
   * @param input org901/id1000000
   * @param action 固定stock.read/post等
   * @return 实际头含内部source，来源不可原地改
   */
  private Map<String, Object> locked(CommonParam input, String action) {
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var p = CrmPartnerValueSupport.detail(input, scope);
    var ref = getDao().sourceReference(p);
    if (ref == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    boolean funds = action.startsWith("crm.funds.");
    if ((funds
            && !com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.isFundsDocument(
                ref.get("documentKind"), ref.get("reason"), returnsAvailable()))
        || (!funds
            && !CrmStockValueSupport.isStockDocument(
                ref.get("documentKind"), ref.get("reason"), returnsAvailable()))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    // 从本表不可变真实类型派生采购来源，不能由状态命令传入方向或销售退货原因。
    String sourceKind =
        funds
            ? com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.orderKind(
                ref.get("documentKind"), ref.get("reason"), returnsAvailable())
            : CrmStockValueSupport.orderKind(
                ref.get("documentKind"), ref.get("reason"), returnsAvailable());
    var sourceInput = relation(input, "orderId", ref.get("orderId"));
    sourceInput.putParam("orderKind", sourceKind);
    var source = order(sourceInput, action);
    Map<String, Object> header;
    if ("SALES_RETURN".equals(ref.get("reason")) || "crm.stock.reverse".equals(action)) {
      var candidates =
          new java.util.ArrayList<Map<String, Object>>(
              lines.readAll(relation(input, "documentId", p.getParam("id")), action));
      if (input.getParam("lines") instanceof List<?> incoming) {
        for (Object value : incoming) {
          @SuppressWarnings("unchecked")
          var row = (Map<String, Object>) value;
          candidates.add(row);
        }
      }
      if ("crm.stock.reverse".equals(action)) {
        for (var batch :
            allocationBatches
                .getObject()
                .findForDocument(relation(input, "documentId", p.getParam("id")), action)) {
          if (!"POST".equals(batch.get("action"))) {
            continue;
          }
          for (var effect :
              allocationDetails
                  .getObject()
                  .readHistory(relation(input, "batchId", batch.get("id")), action)) {
            for (var edge :
                allocationDependencies
                    .getObject()
                    .childEdges(relation(input, "childDetailId", effect.get("id")), action)) {
              candidates.add(
                  Map.of(
                      "sourceOrderLineId",
                      effect.get("sourceOrderLineId"),
                      "baseReturnDetailId",
                      edge.get("parentDetailId")));
            }
            for (var edge :
                allocationDependencies
                    .getObject()
                    .parentEdges(relation(input, "parentDetailId", effect.get("id")), action)) {
              candidates.add(
                  Map.of(
                      "sourceOrderLineId",
                      effect.get("sourceOrderLineId"),
                      "baseReturnDetailId",
                      edge.get("childDetailId")));
            }
          }
        }
      }
      header =
          lockReturnDocuments(
              input,
              source,
              candidates,
              action,
              ((Number) p.getParam("id")).longValue(),
              "crm.stock.post".equals(action));
    } else {
      header = getDao().lockScoped(p);
    }
    if (header == null
        || !ref.get("orderId").equals(header.get("orderId"))
        || !source.get("snapshotHash").equals(header.get("orderSnapshotHash"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SOURCE_MISMATCH");
    }
    var result = new LinkedHashMap<>(header);
    result.put("source", source);
    return result;
  }

  /**
   * 严格检查当前版本。
   *
   * @param input expectedVersion0等
   * @param head 实际锁定version0 副作用示例：旧版本/最大版本拒绝STALE_CRM_VERSION，不覆盖并发更新。
   */
  private void version(CommonParam input, Map<String, Object> head) {
    long v = ((Number) head.get("versionNo")).longValue();
    if (v == Long.MAX_VALUE
        || v != CrmPartnerValueSupport.version(input.getParam("expectedVersion"))) {
      throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
    }
  }

  /**
   * 真实冻结来源映射，每行限定同来源商品且数量总和不超过授权；按主数据ID固定升序重核ACTIVE。
   *
   * @param input org901
   * @param source 实际审核销售头/全部订单行
   * @param values 本单全部真实或规范行，最多1000
   * @param action 固定库存动作
   * @return 按来源行ID排序的实际授权行；跨订单/商品/数量/仓库无记录统一拒绝
   */
  private Map<Long, Map<String, Object>> validate(
      CommonParam input,
      Map<String, Object> source,
      List<Map<String, Object>> values,
      String action) {
    if (values.isEmpty() || values.size() > 1000) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
    }
    @SuppressWarnings("unchecked")
    List<Map<String, Object>> original = (List<Map<String, Object>>) source.get("lines");
    Map<Long, Map<String, Object>> byId = new TreeMap<>();
    for (var l : original) {
      byId.put(((Number) l.get("id")).longValue(), l);
    }
    if (values.stream().anyMatch(row -> row.get("baseIssueDetailId") != null)) {
      lockReturnDocuments(input, source, values, action, null, false);
    }
    Map<Long, Long> quantities = new TreeMap<>();
    Set<Long> productIds = new TreeSet<>(), warehouseIds = new TreeSet<>();
    for (var row : values) {
      long id = CrmPartnerValueSupport.positive(row.get("sourceOrderLineId")),
          product = CrmPartnerValueSupport.positive(row.get("productId")),
          quantity = CrmStockValueSupport.quantity(row.get("quantity"));
      var sourceLine = byId.get(id);
      if (sourceLine == null
          || ((Number) sourceLine.get("productId")).longValue() != product
          || !"EA".equals(sourceLine.get("unitCode"))) {
        throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
      }
      if (row.get("baseIssueDetailId") != null) {
        validateParent(input, source, row, "baseIssueDetailId", "ISSUE_RETURN", action);
      }
      quantities.merge(id, quantity, Math::addExact);
      productIds.add(product);
      warehouseIds.add(CrmPartnerValueSupport.positive(row.get("warehouseId")));
    }
    for (var e : quantities.entrySet()) {
      if (e.getValue() > CrmStockValueSupport.quantity(byId.get(e.getKey()).get("quantity"))) {
        throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
      }
    }
    for (long id : productIds) {
      products.lockForOrder(relation(input, "id", id), action);
    }
    for (long id : warehouseIds) {
      var warehouse = warehouses.lockScoped(relation(input, "id", id), action);
      if (!"ACTIVE".equals(warehouse.get("businessState"))) {
        throw CrmPartnerValueSupport.failure("CRM_WAREHOUSE_INACTIVE");
      }
    }
    return byId;
  }

  /**
   * 请求规范hash不含requestKey，保存/状态/审计同一事务。
   *
   * @param input 服务器规范命令，例如org901/keyk1
   * @param command 固定DOCUMENT_SAVE/SUBMIT/APPROVE
   * @return 唯一claim参数，无客户端hash
   */
  private CommonParam request(CommonParam input, String command) {
    var p = relation(input, "commandName", command);
    p.putParam("requestKey", input.getParam("requestKey"));
    p.putParam(
        "payloadHash",
        com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(input.getParamMap()));
    return p;
  }

  /**
   * 写流程唯一claim；失败退出后读取首次真实已提交响应。
   *
   * @param input 服务器规范命令
   * @param command 固定DOCUMENT_SAVE等
   * @param operation 当前实际事务内整笔业务函数
   * @return 首次结果或同内容首次快照；异内容重放拒绝
   */
  private CommonResult execute(
      CommonParam input,
      String command,
      java.util.function.BiFunction<Map<String, Object>, Long, CommonResult> operation) {
    var req = request(input, command);
    String action = CrmPartnerValueSupport.commandAction(command);
    try {
      return access.executeTransaction(
          input.getParam("organizationCandidateId"),
          action,
          transaction(),
          tx -> {
            var scope =
                access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
            long id = commands.claim(req);
            return operation.apply(scope, id);
          });
    } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
      if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
        throw failure;
      }
      var stored = commands.committed(req);
      if (stored == null || !req.getParam("payloadHash").equals(stored.get("payloadHash"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
      }
      if (!"COMPLETED".equals(stored.get("requestState"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
      }
      @SuppressWarnings("unchecked")
      Map<String, Object> data =
          JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
      data.put("replay", true);
      return CrmPartnerValueSupport.result(data);
    }
  }

  /**
   * 已锁实际头行浏览器响应，内部source不外发。
   *
   * @param header 实际document头
   * @param values 全部真实行
   * @param scope 已核真实actor/org
   * @return 精确文本头行和当前actor是否可独立审核；无库存效果
   */
  private Map<String, Object> response(
      Map<String, Object> header, List<Map<String, Object>> values, Map<String, Object> scope) {
    var data = CrmStockValueSupport.browser(header);
    data.remove("source");
    data.put("documentId", data.get("id"));
    data.put("lines", values.stream().map(CrmStockValueSupport::browser).toList());
    data.put(
        "canApprove",
        "SUBMITTED".equals(header.get("documentState"))
            && !scope.get("actorUserId").equals(header.get("submittedByUserId")));
    return data;
  }

  /**
   * 末尾权限复核、typed首次结果、唯一审计；任一步失败全部回滚。
   *
   * @param input 规范命令
   * @param command 固定DOCUMENT_SAVE等
   * @param requestId 真实claim号段id
   * @param head 当前实际头/版本
   * @param previous 上一版本或null
   * @return 实际头行首次响应；审计不改变库存
   */
  private CommonResult finish(
      CommonParam input, String command, long requestId, Map<String, Object> head, Long previous) {
    String action = CrmPartnerValueSupport.commandAction(command);
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var data = response(head, rows(input, head, action), scope);
    data.put("replay", false);
    data.put("synthetic", scope.get("synthetic"));
    var req = request(input, command);
    req.putParam("id", requestId);
    req.putParam("resultDocumentId", head.get("id"));
    req.putParam("resultVersionNo", head.get("versionNo"));
    req.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
    commands.complete(req);
    var event = relation(input, "commandRequestId", requestId);
    event.putParam("action", "REJECT".equals(input.getParam("fundsOperation"))
        ? "FUNDS_DOCUMENT_REJECT" : command);
    event.putParam("resourceId", head.get("id"));
    event.putParam("previousVersion", previous);
    event.putParam("newVersion", head.get("versionNo"));
    // 驳回原因随原命令和状态同事务保存，不向其他单据动作补造原因。
    if ("REJECT".equals(input.getParam("fundsOperation"))) {
      event.putParam("reasonText", input.getParam("reasonText"));
    }
    audit.append(event);
    return CrmPartnerValueSupport.result(data);
  }

  /**
   * 完整销售出库草稿，锁真实冻结来源和全部引用；不扣库存。
   *
   * @param input 例如org901/order600000及所有source/warehouse/product/quantity行
   * @return 实际document/lines/version；第N行失败全回滚
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult saveDraft(CommonParam input) {
    access.requireStockScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.write");
    var p = CrmStockValueSupport.draft(input, returnsAvailable());
    return execute(
        p,
        "DOCUMENT_SAVE",
        (scope, requestId) -> {
          Map<String, Object> source;
          long id, version;
          Long previous = null;
          if (p.getParam("id") != null) {
            var head = locked(p, "crm.stock.write");
            if (!head.get("orderId").equals(p.getParam("orderId"))
                || !head.get("documentKind").equals(p.getParam("documentKind"))
                || !head.get("reason").equals(p.getParam("reason"))) {
              throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SOURCE_MISMATCH");
            }
            version(p, head);
            if (!"DRAFT".equals(head.get("documentState"))) {
              throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> actual = (Map<String, Object>) head.get("source");
            source = actual;
            id = ((Number) head.get("id")).longValue();
            previous = ((Number) head.get("versionNo")).longValue();
            version = previous + 1;
          } else {
            source = order(p, "crm.stock.write");
            id = getSequence().get("id");
            version = 0;
          }
          @SuppressWarnings("unchecked")
          List<Map<String, Object>> values = (List<Map<String, Object>>) p.getParam("lines");
          validate(p, source, values, "crm.stock.write");
          if (previous == null) {
            var head = new CommonParam();
            head.putParam("id", id);
            head.putParam("orderId", source.get("id"));
            head.putParam("orderKind", source.get("orderKind"));
            head.putParam("currency", source.get("currency"));
            head.putParam("documentKind", p.getParam("documentKind"));
            head.putParam("reason", p.getParam("reason"));
            head.putParam("documentState", "DRAFT");
            head.putParam("orderSnapshotHash", source.get("snapshotHash"));
            head = CrmPartnerValueSupport.entity(head, scope);
            CrmPartnerValueSupport.changed(getDao().insert(head));
          } else {
            var update = CrmPartnerValueSupport.detail(p, scope);
            update.putParam("orderId", source.get("id"));
            update.putParam("expectedVersion", previous);
            update.putParam("actorUserId", scope.get("actorUserId"));
            CrmPartnerValueSupport.changed(getDao().updateDraft(update));
          }
          var relation = relation(p, "documentId", id);
          relation.putParam("headerVersion", version);
          lines.clearDraft(relation);
          for (var value : values) {
            var line = CrmStockValueSupport.param(value);
            line.putParam("organizationCandidateId", p.getParam("organizationCandidateId"));
            line.putParam("documentId", id);
            line.putParam("headerVersion", version);
            line.putParam("orderId", source.get("id"));
            line.putParam("documentKind", p.getParam("documentKind"));
            line.putParam("reason", p.getParam("reason"));
            line.putParam("currency", source.get("currency"));
            lines.append(line, "crm.stock.write");
          }
          return finish(
              p,
              "DOCUMENT_SAVE",
              requestId,
              getDao().lockScoped(CrmPartnerValueSupport.detail(relation(p, "id", id), scope)),
              previous);
        });
  }

  /**
   * 提交实际完整DRAFT，不改库存。
   *
   * @param input 例如org901/id1000000/version0/keysubmit
   * @return SUBMITTED/version1，整笔头行/请求/审计原子
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult submit(CommonParam input) {
    return change(input, false);
  }

  /**
   * 真实不同审核人冻结头/全部行，不改库存。
   *
   * @param input 例如org901/id1000000/version1/keyapprove
   * @return APPROVED/version2，冻结来源和全部仓库商品数量
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult approve(CommonParam input) {
    return change(input, true);
  }

  /**
   * 提交/独立审核具名事务。
   *
   * @param input 原始白名单命令
   * @param approval true为独立审核、false提交
   * @return 真实状态结果；自审/旧版本/第N引用失败整笔拒绝
   */
  private CommonResult change(CommonParam input, boolean approval) {
    return change(input, approval, false);
  }

  /**
   * Typed domain dispatch; normalized commands never accept client action.
   *
   * @param input org901/id1000000/keyk1/expectedVersion1
   * @param approval true for independent approval
   * @param funds true only from owning receipt wrapper
   * @return actual atomic state result, no balance effects
   */
  private CommonResult change(CommonParam input, boolean approval, boolean funds) {
    String
        command =
            funds
                ? (approval ? "FUNDS_DOCUMENT_APPROVE" : "FUNDS_DOCUMENT_SUBMIT")
                : (approval ? "DOCUMENT_APPROVE" : "DOCUMENT_SUBMIT"),
        action = CrmPartnerValueSupport.commandAction(command);
    access.requireBusinessScope(
        input == null ? null : input.getParam("organizationCandidateId"), action);
    var p = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(input, true);
    var courseQuotes =
        funds
            ? prepareCourseQuotes(p, command, () -> courseQuoteRows(p, action))
            : Map.<Long, Map<String, Object>>of();
    return execute(
        p,
        command,
        (scope, requestId) -> {
          var head = locked(p, action);
          version(p, head);
          if (!(approval ? "SUBMITTED" : "DRAFT").equals(head.get("documentState"))) {
            throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
          }
          if (approval && scope.get("actorUserId").equals(head.get("submittedByUserId"))) {
            throw CrmPartnerValueSupport.failure("CRM_APPROVER_EQUALS_SUBMITTER");
          }
          var values = rows(p, head, action);
          @SuppressWarnings("unchecked")
          Map<String, Object> source = (Map<String, Object>) head.get("source");
          if (funds) {
            validateFunds(p, source, values, action, courseQuotes);
          } else {
            validate(p, source, values, action);
          }
          var update = CrmPartnerValueSupport.detail(p, scope);
          update.putParam("expectedVersion", head.get("versionNo"));
          update.putParam("previousState", head.get("documentState"));
          update.putParam("nextState", approval ? "APPROVED" : "SUBMITTED");
          update.putParam("actorUserId", scope.get("actorUserId"));
          if (approval) {
            var frozen =
                funds
                    ? com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.snapshot(
                        head, values)
                    : CrmStockValueSupport.snapshot(head, values);
            update.putParam("frozenSnapshot", JsonUtils.toJsonIgnoreNull(frozen));
            update.putParam(
                "approvedSnapshotHash",
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.hash(frozen));
          }
          CrmPartnerValueSupport.changed(getDao().transition(update));
          return finish(
              p,
              command,
              requestId,
              getDao().lockScoped(CrmPartnerValueSupport.detail(p, scope)),
              ((Number) head.get("versionNo")).longValue());
        });
  }

  /**
   * 内部行清理/插入也必须持有真实DRAFT头并匹配CAS后版本。
   *
   * @param input org901/documentId1000000/headerVersion0 副作用示例：非DRAFT或版本不符拒绝，不能通过内部写改冻结行。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void requireDraftLines(CommonParam input) {
    boolean funds =
        "FUNDS_RECEIPT".equals(input.getParam("documentKind"))
            || "FUNDS_PAYMENT".equals(input.getParam("documentKind"));
    String kind = funds ? input.getParam("documentKind").toString() : "STOCK_ISSUE";
    var scope =
        access.requireBusinessScope(
            input.getParam("organizationCandidateId"),
            funds ? "crm.funds.write" : "crm.stock.write");
    var head =
        getDao()
            .lockScoped(
                CrmPartnerValueSupport.detail(
                    relation(input, "id", input.getParam("documentId")), scope));
    if (head == null
        || (funds
            ? !com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.isFundsDocument(
                head.get("documentKind"), head.get("reason"), returnsAvailable())
            : !CrmStockValueSupport.isStockDocument(
                head.get("documentKind"), head.get("reason"), returnsAvailable()))
        || (input.getParam("documentKind") != null
            && !input.getParam("documentKind").equals(head.get("documentKind")))
        || (input.getParam("reason") != null
            && !input.getParam("reason").equals(head.get("reason")))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    if (!"DRAFT".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    if (((Number) head.get("versionNo")).longValue()
        != CrmPartnerValueSupport.version(input.getParam("headerVersion"))) {
      throw CrmPartnerValueSupport.failure("STALE_CRM_VERSION");
    }
  }

  /**
   * 一次实际范围头行读取，遵守Order→Line→Document锁序。
   *
   * @param input 例如org901/id1000000
   * @return 同版本真实全部行；不持不同版本拼接页面
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult getById(CommonParam input) {
    // 空请求交给原身份与组织候选校验，不能在校验前触发空指针。
    var scope =
        access.requireStockScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    var head = locked(input, "crm.stock.read");
    return CrmPartnerValueSupport.result(
        response(head, rows(input, head, "crm.stock.read"), scope));
  }

  // 只在明确退货页面读取真实进度；Provider避免Document/Detail/Progress构造循环。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.orderlineprogress.service.CrmOrderLineProgressService>
      returnProgress;

  /**
   * 页面选择真实审核销售来源及全部行。
   *
   * @param input 例如org901/orderId600000
   * @return 精确文本真实来源；未审核/跨组织统一拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守身份与组织准入；匿名UNIAUTH_IDENTITY_REQUIRED，实际登录无组织候选INVALID_CRM_ID，无业务写入
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult source(CommonParam input) {
    // 缺请求仍沿原准入核验真实身份和组织，不推定默认候选。
    access.requireStockScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
    String kind = CrmStockValueSupport.pageKind(input.getParam("documentKind"));
    var sourceInput = relation(input, "orderId", input.getParam("orderId"));
    sourceInput.putParam(
        "orderKind",
        CrmStockValueSupport.orderKind(
            kind,
            CrmStockValueSupport.pageReason(kind, input.getParam("reason"), returnsAvailable()),
            returnsAvailable()));
    var actual = order(sourceInput, "crm.stock.read");
    @SuppressWarnings("unchecked")
    List<Map<String, Object>> rows = (List<Map<String, Object>>) actual.get("lines");
    var result = CrmStockValueSupport.browser(actual);
    boolean salesReturn = "SALES_RETURN".equals(input.getParam("reason"));
    if (salesReturn) {
      List<Map<String, Object>> views = new java.util.ArrayList<>();
      for (var row : rows) {
        var counter =
            returnProgress
                .getObject()
                .readStockForLine(relation(input, "sourceOrderLineId", row.get("id")));
        long issued =
            counter == null ? 0L : ((Number) counter.get("stockPostedQuantity")).longValue();
        long returned =
            counter == null ? 0L : ((Number) counter.get("stockReturnedQuantity")).longValue();
        var view = CrmStockValueSupport.browser(row);
        view.put("stockPostedQuantity", Long.toString(issued));
        view.put("stockReturnedQuantity", Long.toString(returned));
        view.put("remainingQuantity", Long.toString(Math.subtractExact(issued, returned)));
        views.add(view);
      }
      result.put("lines", views);
    } else {
      result.put("lines", rows.stream().map(CrmStockValueSupport::browser).toList());
    }
    return CrmPartnerValueSupport.result(result);
  }

  /**
   * owning Document持锁验证POST准备事实，不接受外部冻结/数量摘要。
   *
   * @param input 例如org901/id1000000/expectedVersion2
   * @return 实际APPROVED头、全部行和冻结来源；没有库存/流水副作用
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> preparePost(CommonParam input) {
    var head = locked(input, "crm.stock.post");
    version(input, head);
    if (!"APPROVED".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, "crm.stock.post");
    @SuppressWarnings("unchecked")
    Map<String, Object> source = (Map<String, Object>) head.get("source");
    validate(input, source, all, "crm.stock.post");
    CrmStockValueSupport.verifySnapshot(head, all);
    head.put("lines", all);
    return head;
  }

  /**
   * owning Document最后状态CAS并重新取实际行；权限撤销/末尾状态失败整批回滚。
   *
   * @param input 例如org901/id1000000/expectedVersion2
   * @return POSTED/version3真实头，原审批冻结和不同审核员保留
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> markPosted(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("expectedVersion", input.getParam("expectedVersion"));
    p.putParam("previousState", "APPROVED");
    p.putParam("nextState", "POSTED");
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().transition(p));
    return getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
  }

  /**
   * 同范围存在性检查先于POST请求claim；claim后再按统一锁序核状态/版本。
   *
   * @param input org901/id1000000 副作用示例：越组织/不存在统一拒绝，不透露来源资源。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void requirePostReference(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.post");
    if (getDao().sourceReference(CrmPartnerValueSupport.detail(input, scope)) == null) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
  }

  /**
   * 一次实际范围头行读取，遵守Order→Line→Document锁序。
   *
   * @param input 例如org901/id1000000
   * @return 同版本真实全部行；不持不同版本拼接页面
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult getFundsById(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
    var head = locked(input, "crm.funds.read");
    var data = response(head, rows(input, head, "crm.funds.read"), scope);
    // 只读该原资金单的最近驳回；不额外要求或开放泛审计权限。
    data.put("rejection", audit.latestFundsRejection(input));
    return CrmPartnerValueSupport.result(data);
  }

  /**
   * 页面选择真实审核销售来源及全部行。
   *
   * @param input 例如org901/orderId600000
   * @return 精确文本真实来源；未审核/跨组织统一拒绝
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult fundsSource(CommonParam input) {
    access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
    var actual = order(input, "crm.funds.read");
    @SuppressWarnings("unchecked")
    List<Map<String, Object>> rows = (List<Map<String, Object>>) actual.get("lines");
    var result = CrmStockValueSupport.browser(actual);
    result.put("lines", rows.stream().map(CrmStockValueSupport::browser).toList());
    return CrmPartnerValueSupport.result(result);
  }

  /**
   * owning Document持锁验证POST准备事实，不接受外部冻结/数量摘要。
   *
   * @param input 例如org901/id1000000/expectedVersion2
   * @return 实际APPROVED头、全部行和冻结来源；没有库存/流水副作用
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> prepareFundsPost(CommonParam input) {
    var head = locked(input, "crm.funds.post");
    // 课程现金执行须先固定可恢复课时状态，不能误走原采购付款分支。
    if ("COURSE_RETURN".equals(head.get("reason"))) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_EXECUTION_NOT_CONNECTED");
    }
    version(input, head);
    if (!"APPROVED".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, "crm.funds.post");
    @SuppressWarnings("unchecked")
    Map<String, Object> source = (Map<String, Object>) head.get("source");
    validateFunds(input, source, all, "crm.funds.post");
    com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.verifySnapshot(head, all);
    head.put("lines", all);
    return head;
  }

  /**
   * 方法作用：原资金提交事务持有订单／单据锁后核课程冻结和实际金额上限。
   * @param input 原org901/id100000/expectedVersion2，不含客户端已退款标记
   * @param quotes 原资金拥有方取得的真实预留核对，例如100000对应maximumRefundMinor18
   * @return 真实示例：原APPROVED头、实际lines及source；没有现金效果。
   * 异常或副作用示例：非课程退款、旧版本或引用／冻结改变拒绝，原现金事务整体回滚。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> prepareCourseFundsPost(
      CommonParam input, Map<Long, Map<String, Object>> quotes) {
    var head = locked(input, "crm.funds.post");
    version(input, head);
    if (!"COURSE_RETURN".equals(head.get("reason"))
        || !"FUNDS_PAYMENT".equals(head.get("documentKind"))
        || !"APPROVED".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, "crm.funds.post");
    @SuppressWarnings("unchecked")
    var source = (Map<String, Object>) head.get("source");
    validateFunds(input, source, all, "crm.funds.post", quotes);
    com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.verifySnapshot(head, all);
    head.put("lines", all);
    return head;
  }

  /**
   * owning Document最后状态CAS并重新取实际行；权限撤销/末尾状态失败整批回滚。
   *
   * @param input 例如org901/id1000000/expectedVersion2
   * @return POSTED/version3真实头，原审批冻结和不同审核员保留
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> markFundsPosted(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("expectedVersion", input.getParam("expectedVersion"));
    p.putParam("previousState", "APPROVED");
    p.putParam("nextState", "POSTED");
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().transition(p));
    return getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
  }

  /**
   * 完整销售收款草稿，锁真实冻结来源和全部引用；不改资金。
   *
   * @param input 例如org901/order600000及所有source/account/amountMinor行
   * @return 实际document/lines/version；第N行失败全回滚
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult saveFundsDraft(CommonParam input) {
    access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.write");
    var p =
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.draft(
            input, returnsAvailable(), access.formalCapabilityAvailable("courseRefund"));
    var courseQuotes =
        prepareCourseQuotes(
            p,
            "FUNDS_DOCUMENT_SAVE",
            () -> {
              if (!"COURSE_RETURN".equals(p.getParam("reason"))) {
                return List.of();
              }
              @SuppressWarnings("unchecked")
              var values = (List<Map<String, Object>>) p.getParam("lines");
              return values;
            });
    return execute(
        p,
        "FUNDS_DOCUMENT_SAVE",
        (scope, requestId) -> {
          Map<String, Object> source;
          long id, version;
          Long previous = null;
          if (p.getParam("id") != null) {
            var head = locked(p, "crm.funds.write");
            if (!head.get("orderId").equals(p.getParam("orderId"))
                || !head.get("documentKind").equals(p.getParam("documentKind"))
                || !head.get("reason").equals(p.getParam("reason"))) {
              throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SOURCE_MISMATCH");
            }
            version(p, head);
            if (!"DRAFT".equals(head.get("documentState"))) {
              throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> actual = (Map<String, Object>) head.get("source");
            source = actual;
            id = ((Number) head.get("id")).longValue();
            previous = ((Number) head.get("versionNo")).longValue();
            version = previous + 1;
          } else {
            source = order(p, "crm.funds.write");
            id = getSequence().get("id");
            version = 0;
          }
          @SuppressWarnings("unchecked")
          List<Map<String, Object>> values = (List<Map<String, Object>>) p.getParam("lines");
          if (!p.getParam("currency").equals(source.get("currency"))) {
            throw CrmPartnerValueSupport.failure("CRM_CURRENCY_MISMATCH");
          }
          validateFunds(p, source, values, "crm.funds.write", courseQuotes);
          if (previous == null) {
            var head = new CommonParam();
            head.putParam("id", id);
            head.putParam("orderId", source.get("id"));
            head.putParam("orderKind", source.get("orderKind"));
            head.putParam("currency", source.get("currency"));
            head.putParam("documentKind", p.getParam("documentKind"));
            head.putParam("reason", p.getParam("reason"));
            head.putParam("documentState", "DRAFT");
            head.putParam("orderSnapshotHash", source.get("snapshotHash"));
            head = CrmPartnerValueSupport.entity(head, scope);
            CrmPartnerValueSupport.changed(getDao().insert(head));
          } else {
            var update = CrmPartnerValueSupport.detail(p, scope);
            update.putParam("orderId", source.get("id"));
            update.putParam("expectedVersion", previous);
            update.putParam("actorUserId", scope.get("actorUserId"));
            CrmPartnerValueSupport.changed(getDao().updateDraft(update));
          }
          var relation = relation(p, "documentId", id);
          relation.putParam("headerVersion", version);
          relation.putParam("documentKind", p.getParam("documentKind"));
          relation.putParam("reason", p.getParam("reason"));
          lines.clearDraft(relation);
          for (var value : values) {
            var line = CrmStockValueSupport.param(value);
            line.putParam("organizationCandidateId", p.getParam("organizationCandidateId"));
            line.putParam("documentId", id);
            line.putParam("headerVersion", version);
            line.putParam("orderId", source.get("id"));
            line.putParam("documentKind", p.getParam("documentKind"));
            line.putParam("reason", p.getParam("reason"));
            line.putParam("currency", source.get("currency"));
            lines.append(line, "crm.funds.write");
          }
          return finish(
              p,
              "FUNDS_DOCUMENT_SAVE",
              requestId,
              getDao().lockScoped(CrmPartnerValueSupport.detail(relation(p, "id", id), scope)),
              previous);
        });
  }

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.cashaccount.service.CrmCashAccountService accounts;

  /**
   * All allocations bind to one actual approved source, exact minor due and active same-currency
   * CASH accounts.
   *
   * @param input org901 and normalized allocation lines
   * @param source actual locked approved sales order with complete frozen lines
   * @param values whole receipt e.g. allocations 68/67 to account90101
   * @param action fixed funds.write/submit/approve/post
   * @return actual source map; foreign source/account, oversettlement or currency mismatch
   *     rejects
   */
  private Map<Long, Map<String, Object>> validateFunds(
      CommonParam input,
      Map<String, Object> source,
      List<Map<String, Object>> values,
      String action) {
    return validateFunds(input, source, values, action, Map.of());
  }

  /**
   * 方法作用：原完整资金行额外核服务器取得的课程预留坐标和金额上限，普通收付款不依赖教学。
   * @param input 原规范草稿或提交命令，例如org901/reasonCOURSE_RETURN
   * @param source 原已锁审核销售来源，例如id100000/currencyCNY
   * @param values 全部实际资金行，例如预留100000/amountMinor18
   * @param action 固定原动作，例如crm.funds.approve
   * @param courseQuotes 写锁前真实核对，例如100000对应maximumRefundMinor18
   * @return 真实示例：原sourceOrderLineId100000对应实际冻结来源行。
   * 异常或副作用示例：引用、摘要或金额超过真实上限拒绝，外层回滚头、行和请求回执。
   */
  private Map<Long, Map<String, Object>> validateFunds(
      CommonParam input,
      Map<String, Object> source,
      List<Map<String, Object>> values,
      String action,
      Map<Long, Map<String, Object>> courseQuotes) {
    if (values.isEmpty() || values.size() > 1000) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
    }
    @SuppressWarnings("unchecked")
    List<Map<String, Object>> originals = (List<Map<String, Object>>) source.get("lines");
    Map<Long, Map<String, Object>> byId = new TreeMap<>();
    for (var row : originals) {
      byId.put(((Number) row.get("id")).longValue(), row);
    }
    Map<Long, java.math.BigDecimal> amounts = new TreeMap<>();
    Set<Long> accountIds = new TreeSet<>();
    if (values.stream()
        .anyMatch(
            row ->
                row.get("baseReceiptDetailId") != null || row.get("baseReturnDetailId") != null)) {
      lockReturnDocuments(input, source, values, action, null, false);
    }
    for (var row : values) {
      long id = CrmPartnerValueSupport.positive(row.get("sourceOrderLineId"));
      if (!byId.containsKey(id)) {
        throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
      }
      boolean course =
          "COURSE_RETURN".equals(input.getParam("reason"))
              || "COURSE_RETURN".equals(row.get("reason"));
      if (course) {
        if (values.size() != 1) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_ONE_SOURCE_REQUIRED");
        }
        var quote =
            courseQuotes.get(CrmPartnerValueSupport.positive(row.get("courseReservationId")));
        // 锁内真实原单与每个跨域坐标逐一相符；不允许换学生、课程或订单。
        if (quote == null
            || !java.util.Objects.equals(
                "crm.funds.post".equals(action)
                    ? quote.get("approvalQuoteHash")
                    : quote.get("quoteHash"),
                row.get("courseQuoteHash"))
            || CrmPartnerValueSupport.positive(quote.get("crmOrderId"))
                != CrmPartnerValueSupport.positive(source.get("id"))
            || CrmPartnerValueSupport.positive(quote.get("crmOrderLineId")) != id
            || CrmPartnerValueSupport.positive(quote.get("studentId"))
                != CrmPartnerValueSupport.positive(row.get("courseStudentId"))
            || CrmPartnerValueSupport.positive(quote.get("curriculumCourseId"))
                != CrmPartnerValueSupport.positive(row.get("curriculumCourseId"))
            || !source.get("currency").equals(quote.get("currency"))) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_MISMATCH");
        }
        if (com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(row.get("amountMinor"))
                .compareTo(new java.math.BigDecimal(quote.get("maximumRefundMinor").toString()))
            > 0) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_LIMIT_EXCEEDED");
        }
      } else if (row.get("courseReservationId") != null
          || row.get("courseStudentId") != null
          || row.get("curriculumCourseId") != null
          || row.get("courseQuoteHash") != null) {
        throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
      }
      amounts.merge(
          id,
          com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(row.get("amountMinor")),
          java.math.BigDecimal::add);
      if (row.get("baseReceiptDetailId") != null || row.get("baseReturnDetailId") != null) {
        validateParent(input, source, row, "baseReceiptDetailId", "RECEIPT_REFUND", action);
        validateParent(input, source, row, "baseReturnDetailId", "RETURN_REFUND", action);
      }
      accountIds.add(CrmPartnerValueSupport.positive(row.get("accountId")));
    }
    for (var e : amounts.entrySet()) {
      if (e.getValue()
              .compareTo(
                  new java.math.BigDecimal(byId.get(e.getKey()).get("approvedDueMinor").toString()))
          > 0) {
        throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
      }
    }
    for (long id : accountIds) {
      var account = accounts.lockScoped(relation(input, "id", id), action);
      if (!"ACTIVE".equals(account.get("businessState"))
          || !"CASH".equals(account.get("accountKind"))) {
        throw CrmPartnerValueSupport.failure("CRM_CASH_ACCOUNT_INACTIVE");
      }
      if (!source.get("currency").equals(account.get("currency"))
          || !source.get("currencyScale").equals(account.get("currencyScale"))) {
        throw CrmPartnerValueSupport.failure("CRM_CURRENCY_MISMATCH");
      }
    }
    return byId;
  }

  /**
   * 方法作用及真实业务示例：提交完整收款草稿；org901/id1000000/expected0/keysubmit；返回SUBMITTED/version1；头行、请求、审计原子且资金无副作用。
   * Submit a complete real receipt; no cash balance side effect.
   *
   * @param input org901/id1000000/expectedVersion0/keysubmit
   * @return SUBMITTED/version1; all checks and command/audit are atomic
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult submitFunds(CommonParam input) {
    return change(input, false, true);
  }

  /**
   * 方法作用及真实业务示例：冻结收款分摊及独立审核人；org901/id1000000/expected1/keyapprove、真实用户9212；返回APPROVED/version2；提交者自审或来源失效拒绝且资金不变。
   * A different real actor freezes amounts and allocation accounts.
   *
   * @param input org901/id1000000/expectedVersion1/keyapprove
   * @return APPROVED/version2; self approval rejected and no funds written
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult approveFunds(CommonParam input) {
    return change(input, true, true);
  }

  /**
   * 方法作用：原资金审核权限下异人退回待审单，保留原分摊和具名原因，不记现金。
   *
   * @param input 真实页面示例：org901/id1000000/expectedVersion1/requestKey及reasonText核对金额
   * @return 真实示例：data.documentState=DRAFT/versionNo=2；同内容原键返回首次replay=true。
   *     异常或副作用示例：本人提交、空原因、旧版本或审计失败时整笔回滚；已审核/已登记单不能驳回。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult rejectFunds(CommonParam input) {
    var candidate = access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.approve");
    // 身份、命令和方向由服务器固定；不接收页面自定审核人或额外金额字段。
    if (input == null || !input.getParamMap().keySet().equals(Set.of(
        "organizationCandidateId", "id", "expectedVersion", "requestKey", "reasonText"))) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
    }
    var commandInput = new CommonParam();
    for (String field : List.of("organizationCandidateId", "id", "expectedVersion", "requestKey")) {
      commandInput.putParam(field, input.getParam(field));
    }
    var normalized = com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.command(commandInput, true);
    normalized.putParam("reasonText", CrmPartnerValueSupport.text(input.getParam("reasonText"), 200, true));
    normalized.putParam("reviewerUserId", candidate.get("actorUserId"));
    // 与原订单驳回一致：复用既有审核命令，方向和原因进入哈希，审计独立区分驳回。
    normalized.putParam("fundsOperation", "REJECT");
    return execute(normalized, "FUNDS_DOCUMENT_APPROVE", (scope, requestId) -> {
      // 沿原Order→Line→Document锁序重新核当前状态和版本，不重用锁前候选。
      var head = locked(normalized, "crm.funds.approve");
      version(normalized, head);
      if (!"SUBMITTED".equals(head.get("documentState"))
          || !scope.get("actorUserId").equals(normalized.getParam("reviewerUserId"))) {
        throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
      }
      if (scope.get("actorUserId").equals(head.get("submittedByUserId"))) {
        throw CrmPartnerValueSupport.failure("CRM_APPROVER_EQUALS_SUBMITTER");
      }
      var update = CrmPartnerValueSupport.detail(normalized, scope);
      update.putParam("expectedVersion", head.get("versionNo"));
      update.putParam("previousState", "SUBMITTED");
      update.putParam("nextState", "DRAFT");
      update.putParam("actorUserId", scope.get("actorUserId"));
      // 只退回本头，原行与现金不动；原提交身份由既有提交审计保留。
      CrmPartnerValueSupport.changed(getDao().transition(update));
      return finish(normalized, "FUNDS_DOCUMENT_APPROVE", requestId,
          getDao().lockScoped(CrmPartnerValueSupport.detail(normalized, scope)),
          ((Number) head.get("versionNo")).longValue());
    });
  }


  /**
   * 方法作用及真实业务示例：在请求claim前核实际同组织收款引用；org901/id1000000；成功无返回且不提前拒绝已POSTED重放；越组织或库存单统一CRM_RECORD_NOT_FOUND。
   * Check real receipt scope before request claim, without destroying first-result replay.
   *
   * @param input org901/id1000000 异常或副作用示例：不存在、本组织外或库存单据均拒绝；本方法只验证引用，不写资金。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void requireFundsPostReference(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.post");
    var ref = getDao().sourceReference(CrmPartnerValueSupport.detail(input, scope));
    if (ref == null
        || !com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.isFundsDocument(
            ref.get("documentKind"), ref.get("reason"), returnsAvailable())) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
  }

  /**
   * 方法作用及真实业务示例：读取真实资金资源分页；org901/page1；返回真实FUNDS_RECEIPT单据或CASH效果及精确最小单位文本；缺funds.read拒绝，不混库存记录。
   * Funds-only actual organization page, no mixed stock documents.
   *
   * @param input org901/page1
   * @return actual receipt page with exact amount strings
   */
  @Override
  @OperationLog
  public CommonPageResult fundsStore(CommonPageParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
    var p = CrmPartnerValueSupport.page(input, scope, null);
    String requestedState = com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageState(input.getParam("documentState"));
    if (requestedState != null) {
      p.putParam("documentState", requestedState);
    }
    // 2026-10-28：原资金来源查询只增加精确订单条件，COUNT和本页仍沿同一真实SQL范围。
    if (input.getParam("sourceOrderId") != null) {
      p.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("sourceOrderId")));
    }
    String kind =
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageKind(
            input.getParam("documentKind"));
    p.putParam("documentKind", kind);
    p.putParam(
        "reason",
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageReason(
            kind, input.getParam("reason"), returnsAvailable()));
    var page = super.getStore(p);
    page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
    return page;
  }

  /**
   * 方法作用：按Order→Line→Document锁序核实原已记账收款全部冻结行。
   *
   * @param input org901/id1000000/expected3
   * @param action crm.funds.reverse或审核动作
   * @return 实际POSTED头及全部原行，无资金效果 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Map<String, Object> prepareFundsReverse(CommonParam input, String action) {
    var head = locked(input, action);
    // 原销售收款冲正入口不能复用为供应商退款；采购付款一期仅正向记账。
    if (!("FUNDS_RECEIPT".equals(head.get("documentKind")) && "SALE".equals(head.get("reason")))
        && !(returnsAvailable()
            && "FUNDS_PAYMENT".equals(head.get("documentKind"))
            && "SALES_RETURN".equals(head.get("reason")))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    version(input, head);
    if (!"POSTED".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, action);
    com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.verifySnapshot(head, all);
    if (all.isEmpty() || all.size() > 1000) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
    }
    head.put("lines", all);
    return head;
  }

  /**
   * 方法作用：末尾CAS原收款状态且保留原审批和首次记账人。
   *
   * @param input org901/id1000000/expected3
   * @return REVERSED/version4；零行整笔回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Map<String, Object> markFundsReversed(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("expectedVersion", input.getParam("expectedVersion"));
    p.putParam("previousState", "POSTED");
    p.putParam("nextState", "REVERSED");
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().transition(p));
    return getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
  }

  /**
   * 方法作用：在冲正预览的同一CRM事务持有Order/Line→Document锁并读完整真实收款。
   *
   * @param input 例如org901/id1000000
   * @return 本组织实际头及全行、POSTED或REVERSED状态；无写入，引用或冻结不一致拒绝。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> readFundsForReversal(CommonParam input) {
    var scope =
        access.requireFundsScope(input.getParam("organizationCandidateId"), "crm.funds.read");
    var head = locked(input, "crm.funds.read");
    if (!java.util.Set.of("POSTED", "REVERSED").contains(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, "crm.funds.read");
    com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.verifySnapshot(head, all);
    return response(head, all, scope);
  }

  /**
   * 方法作用：在冲正claim前核实同组织实际原收款存在性，不先按状态阻断幂等重放。
   *
   * @param input 例如org901/id1000000
   * @param action 例如crm.funds.reverse或crm.funds.approve
   *     副作用示例：越租户、越组织、不存在或库存单统一CRM_RECORD_NOT_FOUND；不执行写入、不提前锁Document。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void requireFundsReverseReference(CommonParam input, String action) {
    var scope = access.requireFundsScope(input.getParam("organizationCandidateId"), action);
    var ref = getDao().sourceReference(CrmPartnerValueSupport.detail(input, scope));
    if (ref == null
        || !("FUNDS_RECEIPT".equals(ref.get("documentKind")) && "SALE".equals(ref.get("reason")))
            && !(returnsAvailable()
                && "FUNDS_PAYMENT".equals(ref.get("documentKind"))
                && "SALES_RETURN".equals(ref.get("reason")))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
  }

  /**
   * 方法作用：按Order→Line→Document锁序核实原已记账库存单全部冻结行。
   *
   * @param input org901/id1000000/expected3
   * @param action crm.stock.reverse或审核动作
   * @return 实际POSTED头及全部原行，无库存效果 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Map<String, Object> prepareStockReverse(CommonParam input, String action) {
    var head = locked(input, action);
    version(input, head);
    if (!"POSTED".equals(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, action);
    CrmStockValueSupport.verifySnapshot(head, all);
    if (all.isEmpty() || all.size() > 1000) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
    }
    head.put("lines", all);
    return head;
  }

  /**
   * 方法作用：末尾CAS原库存单状态且保留原审批和首次记账人。
   *
   * @param input org901/id1000000/expected3
   * @return REVERSED/version4；零行整笔回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "crmTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public Map<String, Object> markStockReversed(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.reverse");
    var p = CrmPartnerValueSupport.detail(input, scope);
    p.putParam("expectedVersion", input.getParam("expectedVersion"));
    p.putParam("previousState", "POSTED");
    p.putParam("nextState", "REVERSED");
    p.putParam("actorUserId", scope.get("actorUserId"));
    CrmPartnerValueSupport.changed(getDao().transition(p));
    return getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
  }

  /**
   * 方法作用：在冲正预览的同一CRM事务持有Order/Line→Document锁并读完整真实库存单。
   *
   * @param input 例如org901/id1000000
   * @return 本组织实际头及全行、POSTED或REVERSED状态；无写入，引用或冻结不一致拒绝。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public Map<String, Object> readStockForReversal(CommonParam input) {
    var scope =
        access.requireStockScope(input.getParam("organizationCandidateId"), "crm.stock.read");
    var head = locked(input, "crm.stock.read");
    if (!java.util.Set.of("POSTED", "REVERSED").contains(head.get("documentState"))) {
      throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
    }
    var all = rows(input, head, "crm.stock.read");
    CrmStockValueSupport.verifySnapshot(head, all);
    return response(head, all, scope);
  }

  /**
   * 方法作用：在冲正claim前核实同组织实际原库存单存在性，不先按状态阻断幂等重放。
   *
   * @param input 例如org901/id1000000
   * @param action 例如crm.stock.reverse或crm.stock.approve
   *     副作用示例：越租户、越组织、不存在或库存单统一CRM_RECORD_NOT_FOUND；不执行写入、不提前锁Document。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
  public void requireStockReverseReference(CommonParam input, String action) {
    var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
    var ref = getDao().sourceReference(CrmPartnerValueSupport.detail(input, scope));
    if (ref == null
        || !CrmStockValueSupport.isStockDocument(
            ref.get("documentKind"), ref.get("reason"), returnsAvailable())) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
  }

  // 显式本域退货结构门禁，不引入默认组织或新许可。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
  private Boolean returnsEnabled;

  // 延迟取得原流水owning服务，避免单据/批次/明细组件的构造循环。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService>
      allocationDetails;

  // 冲正前收齐父子文档，保持Order/Line→排序Document→Progress锁序。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService>
      allocationDependencies;

  // 批次有效性由不可变POST/REVERSE历史派生，不信客户端原单状态。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService>
      allocationBatches;

  /**
   * 原销售Order/OrderLine已锁后定位真实父单，按Document ID升序锁齐，再允许后续Progress与容量锁。
   *
   * @param input org901，身份仍由真实Session核验
   * @param source 已锁实际APPROVED销售来源，例如600000
   * @param values 实际已保存行及本次规范候选行，例如baseIssue1300000或baseReceipt/baseReturn
   * @param action 当前固定stock/funds动作，例如crm.stock.post
   * @param currentId 当前实际单据1000003，新建draft未存在时null
   * @param serialParent stock.post时true，在Progress锁前定位上一有效退货父单
   * @return currentId对应实际锁定头或新建场景null；跨订单引用在任何父单锁前拒绝，不改变进度/容量。
   */
  @SuppressWarnings("unchecked")
  private Map<String, Object> lockReturnDocuments(
      CommonParam input,
      Map<String, Object> source,
      List<Map<String, Object>> values,
      String action,
      Long currentId,
      boolean serialParent) {
    if (!returnsAvailable()) {
      throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
    }
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var documentIds = new java.util.TreeSet<Long>();
    var detailIds = new java.util.TreeSet<Long>();
    var sourceIds = new java.util.TreeSet<Long>();
    var allowedSources = new java.util.HashSet<Long>();
    for (var row : (List<Map<String, Object>>) source.get("lines")) {
      allowedSources.add(((Number) row.get("id")).longValue());
    }
    for (var row : values) {
      long sourceId = CrmPartnerValueSupport.positive(row.get("sourceOrderLineId"));
      if (!allowedSources.contains(sourceId)) {
        throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
      }
      sourceIds.add(sourceId);
      for (String key : List.of("baseIssueDetailId", "baseReceiptDetailId", "baseReturnDetailId")) {
        if (row.get(key) != null) {
          detailIds.add(CrmPartnerValueSupport.positive(row.get(key)));
        }
      }
    }
    if (serialParent) {
      for (long sourceId : sourceIds) {
        var counter =
            returnProgress
                .getObject()
                .peekReturnParent(relation(input, "sourceOrderLineId", sourceId), action);
        if (counter != null && counter.get("lastReturnDetailId") != null) {
          detailIds.add(((Number) counter.get("lastReturnDetailId")).longValue());
        }
      }
    }
    for (long detailId : detailIds) {
      var detail =
          allocationDetails.getObject().readAllocation(relation(input, "id", detailId), action);
      var parentId = ((Number) detail.get("documentId")).longValue();
      var parentRef =
          getDao()
              .sourceReference(
                  CrmPartnerValueSupport.detail(relation(input, "id", parentId), scope));
      if (parentRef == null
          || !source.get("id").equals(parentRef.get("orderId"))
          || !allowedSources.contains(((Number) detail.get("sourceOrderLineId")).longValue())) {
        throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
      }
      documentIds.add(parentId);
    }
    if (currentId != null) {
      documentIds.add(currentId);
    }
    Map<String, Object> current = null;
    for (long documentId : documentIds) {
      var row =
          getDao()
              .lockScoped(CrmPartnerValueSupport.detail(relation(input, "id", documentId), scope));
      if (row == null || !source.get("id").equals(row.get("orderId"))) {
        throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_SOURCE_MISMATCH");
      }
      if (java.util.Objects.equals(currentId, documentId)) {
        current = row;
      }
    }
    return current;
  }

  /**
   * 在同来源Order/Line锁内核真实有效原单和完整冻结，禁止跨订单或伪造引用。
   *
   * @param input org901实际候选
   * @param source 已锁审核订单例如600000及snapshotHash
   * @param row 本单实际或规范行例如source600001/baseIssueDetailId1300000/quantity1
   * @param key 固定baseIssueDetailId/baseReceiptDetailId/baseReturnDetailId
   * @param kind 固定ISSUE_RETURN/RECEIPT_REFUND/RETURN_REFUND
   * @param action 当前真实stock或funds保存/提交/审核/过账动作 副作用示例：只锁与核验，不占容量或改原单；无有效原出库/收款/退货、范围错或超原上限拒绝整笔。
   */
  private void validateParent(
      CommonParam input,
      Map<String, Object> source,
      Map<String, Object> row,
      String key,
      String kind,
      String action) {
    if (!returnsAvailable()) {
      throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
    }
    var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
    var detail =
        allocationDetails
            .getObject()
            .readAllocation(
                relation(input, "id", CrmPartnerValueSupport.positive(row.get(key))), action);
    var parent =
        getDao()
            .lockScoped(
                CrmPartnerValueSupport.detail(
                    relation(input, "id", detail.get("documentId")), scope));
    if (parent == null
        || !"POST".equals(detail.get("action"))
        || !"POSTED".equals(parent.get("documentState"))
        || !source.get("id").equals(parent.get("orderId"))
        || !source.get("snapshotHash").equals(parent.get("orderSnapshotHash"))
        || !detail
            .get("sourceOrderLineId")
            .toString()
            .equals(row.get("sourceOrderLineId").toString())) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
    }
    var history =
        allocationBatches
            .getObject()
            .findForDocument(relation(input, "documentId", parent.get("id")), action);
    if (history.size() != 1
        || !"POST".equals(history.get(0).get("action"))
        || !detail.get("batchId").equals(history.get(0).get("id"))) {
      throw CrmPartnerValueSupport.failure("POSTING_PARENT_INACTIVE");
    }
    var all = rows(input, parent, action);
    var effects =
        allocationDetails
            .getObject()
            .readHistory(relation(input, "batchId", detail.get("batchId")), action);
    if (effects.size() != ((Number) history.get(0).get("detailCount")).intValue()
        || effects.size() != all.size()
        || !parent.get("approvedSnapshotHash").equals(history.get(0).get("approvedSnapshotHash"))) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    if ("CASH".equals(detail.get("effectKind"))) {
      com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.verifySnapshot(parent, all);
    } else {
      CrmStockValueSupport.verifySnapshot(parent, all);
    }
    // 冻结原类型及效果方向必须吻合 -> 库存余额充足也不能伪造退货退款权益。
    boolean valid =
        switch (kind) {
          case "ISSUE_RETURN" ->
              "STOCK_ISSUE".equals(parent.get("documentKind"))
                  && "SALE".equals(parent.get("reason"))
                  && "STOCK".equals(detail.get("effectKind"))
                  && ((Number) detail.get("quantityDelta")).longValue() < 0
                  && detail.get("productId").toString().equals(row.get("productId").toString())
                  && ((Number) row.get("quantity")).longValue()
                      <= Math.negateExact(((Number) detail.get("quantityDelta")).longValue());
          case "RECEIPT_REFUND" ->
              "FUNDS_RECEIPT".equals(parent.get("documentKind"))
                  && "SALE".equals(parent.get("reason"))
                  && "CASH".equals(detail.get("effectKind"))
                  && source.get("currency").equals(detail.get("currency"))
                  && new java.math.BigDecimal(row.get("amountMinor").toString())
                          .compareTo(
                              new java.math.BigDecimal(detail.get("amountDeltaMinor").toString()))
                      <= 0;
          case "RETURN_REFUND" ->
              "STOCK_RECEIPT".equals(parent.get("documentKind"))
                  && "SALES_RETURN".equals(parent.get("reason"))
                  && "STOCK".equals(detail.get("effectKind"))
                  && ((Number) detail.get("quantityDelta")).longValue() > 0
                  && detail.get("refundCapacityMinor") != null
                  && new java.math.BigDecimal(row.get("amountMinor").toString())
                          .compareTo(
                              new java.math.BigDecimal(
                                  detail.get("refundCapacityMinor").toString()))
                      <= 0;
          default -> false;
        };
    if (!valid) {
      throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
    }
  }

  /**
   * 方法作用：隔离测试沿用原开关，正式模式只在真实退货结构已安装时使用退货合同。
   * @return 真实返回示例：已安装容量与依赖表的正式模式true，默认或旧结构false。
   * 异常或副作用示例：只读结构；不授予库存动作或打开资金权限。
   */
  private boolean returnsAvailable() {
    return Boolean.TRUE.equals(returnsEnabled) || access.formalCapabilityAvailable("salesReturn");
  }
}
