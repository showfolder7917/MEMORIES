/** 整批销售出库/采购入库实际事务；2026-10-04，Codex；生产默认拒绝。
 * 修改：2026-10-10，Codex；工作台及批次缺请求走原范围拒绝，超int分页候选返回安全业务错误。
 */
package com.sp.selplat.crm.capability.stock.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.stock.service.CrmStockService;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** 只调用实际owning服务，顺序Order/Line→Document→Progress→Stock，整批一个CRM事务。 */
@org.springframework.stereotype.Service
public class CrmStockServiceImpl implements CrmStockService {
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.document.service.CrmDocumentService documents;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.order.service.CrmOrderService orders;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.warehouse.service.CrmWarehouseService warehouses;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.orderlineprogress.service.CrmOrderLineProgressService progress;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.stockbalance.service.CrmStockBalanceService balances;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.openingbatch.service.CrmOpeningBatchService openings;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService batches;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService details;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService requests;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;

    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
    private org.springframework.transaction.PlatformTransactionManager manager;

    /**
     * 固定余额锁维度，同组织同仓库SKU不因操作者不同分账。
     *
     * @param warehouseId 真实仓库，例如801
     * @param productId 真实商品，例如701
     */
    private record BalanceKey(long warehouseId, long productId) implements Comparable<BalanceKey> {
        /**
         * 余额按仓库后商品升序锁。
         *
         * @param other 例如warehouse801/product701
         * @return 固定数值排序；不按客户端行顺序
         */
        @Override
        public int compareTo(BalanceKey other) {
            int c = Long.compare(warehouseId, other.warehouseId);
            return c == 0 ? Long.compare(productId, other.productId) : c;
        }
    }

    /**
     * 候选组织和服务器关联键。
     *
     * @param input 已规范org901
     * @param key 固定id/orderId等键
     * @param value 实际正数主键
     * @return 新公共参数，无客户端可信身份
     */
    private CommonParam relation(CommonParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 实际单据及冻结全部行进度和余额聚合，只有明确POST执行。
     *
     * @param input 例如org901/id1000000/expected2/actionPOST/requestKeyp1
     * @return 实际批次/全部明细ID，整批回滚或首次重放，无部分成功
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可/冻结错/累计超发/不足/旧版本拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult execute(CommonParam input) {
        access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.post");
        var p = CrmStockValueSupport.post(input);
        var req = relation(p, "documentId", p.getParam("id"));
        req.putParam("requestKey", p.getParam("requestKey"));
        req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
        var t = new org.springframework.transaction.support.TransactionTemplate(manager);
        t.setPropagationBehavior(
                org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        t.setIsolationLevel(
                org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
        try {
            return access.executeTransaction(p.getParam("organizationCandidateId"), "crm.stock.post", t,
                    tx -> {
                        var scope =
                                access.requireStockScope(
                                        p.getParam("organizationCandidateId"), "crm.stock.post");
                        documents.requirePostReference(p);
                        long requestId = requests.claimOrganization(req);
                        var head = documents.preparePost(p);
                        boolean purchase =
                                "PURCHASE"
                                        .equals(
                                                CrmStockValueSupport.orderKind(
                                                        head.get("documentKind"),
                                                        head.get("reason"),
                                                        returnsAvailable()));
                        boolean salesReturn = "SALES_RETURN".equals(head.get("reason"));
                        @SuppressWarnings("unchecked")
                        List<Map<String, Object>> values =
                                (List<Map<String, Object>>) head.get("lines");
                        @SuppressWarnings("unchecked")
                        Map<String, Object> source = (Map<String, Object>) head.get("source");
                        @SuppressWarnings("unchecked")
                        List<Map<String, Object>> sources =
                                (List<Map<String, Object>>) source.get("lines");
                        Map<Long, Map<String, Object>> sourceById = new TreeMap<>();
                        for (var s : sources) {
                            sourceById.put(((Number) s.get("id")).longValue(), s);
                        }
                        Map<Long, Long> sourceQuantities = new TreeMap<>();
                        Map<BalanceKey, Long> stockQuantities = new TreeMap<>();
                        for (var row : values) {
                            long q = ((Number) row.get("quantity")).longValue();
                            sourceQuantities.merge(
                                    ((Number) row.get("sourceOrderLineId")).longValue(),
                                    q,
                                    Math::addExact);
                            var key =
                                    new BalanceKey(
                                            ((Number) row.get("warehouseId")).longValue(),
                                            ((Number) row.get("productId")).longValue());
                            stockQuantities.merge(key, q, Math::addExact);
                        }
                        // 来源累计锁先于任何余额；整单锁也串行同来源不同子单，防并发超发。
                        Map<Long, Map<String, Object>> progressRows = new TreeMap<>();
                        for (var e : sourceQuantities.entrySet()) {
                            var actual = progress.lockForLine(p, sourceById.get(e.getKey()));
                            long posted = ((Number) actual.get("stockPostedQuantity")).longValue(),
                                    authorized =
                                            ((Number) actual.get("authorizedQuantity")).longValue();
                            long returned =
                                    ((Number) actual.get("stockReturnedQuantity")).longValue();
                            if (e.getValue()
                                    > (salesReturn ? posted - returned : authorized - posted)) {
                                throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
                            }
                            progressRows.put(e.getKey(), actual);
                        }
                        Map<Long, java.math.BigDecimal> returnEntitlements = new TreeMap<>();
                        Map<Long, Long> returnRunningTotals = new TreeMap<>();
                        Map<Long, CommonParam> capacityClaims = new TreeMap<>();
                        if (salesReturn) {
                            // 先聚合实际原出库分配；同原明细只锁/CAS一次，不能由客户端上传上限。
                            for (var row : values) {
                                long sourceId = ((Number) row.get("sourceOrderLineId")).longValue();
                                long originalId =
                                        ((Number) row.get("baseIssueDetailId")).longValue();
                                long quantity = ((Number) row.get("quantity")).longValue();
                                var claim = capacityClaims.get(originalId);
                                if (claim == null) {
                                    claim = relation(p, "originalDetailId", originalId);
                                    claim.putParam("sourceOrderLineId", sourceId);
                                    claim.putParam("capacityKind", "ISSUE_RETURN");
                                    claim.putParam("quantity", 0L);
                                    capacityClaims.put(originalId, claim);
                                }
                                claim.putParam(
                                        "quantity",
                                        Math.addExact(
                                                ((Number) claim.getParam("quantity")).longValue(),
                                                quantity));
                                var actual = progressRows.get(sourceId);
                                long before =
                                        returnRunningTotals.getOrDefault(
                                                sourceId,
                                                ((Number) actual.get("stockReturnedQuantity"))
                                                        .longValue());
                                long after = Math.addExact(before, quantity);
                                var amount =
                                        com.sp.selplat.crm.common.util.salesreturn
                                                .CrmSalesReturnValueSupport.entitlement(
                                                        actual, after)
                                                .subtract(
                                                        com.sp.selplat.crm.common.util.salesreturn
                                                                .CrmSalesReturnValueSupport
                                                                .entitlement(actual, before));
                                returnEntitlements.put(
                                        ((Number) row.get("id")).longValue(), amount);
                                returnRunningTotals.put(sourceId, after);
                            }
                            for (var claim : capacityClaims.values()) {
                                var actual = capacities.lockAllocation(claim, "crm.stock.post");
                                claim.putParam("id", actual.get("id"));
                                claim.putParam("versionNo", actual.get("versionNo"));
                            }
                            for (var claim : capacityClaims.values()) {
                                capacities.consume(claim, "crm.stock.post");
                            }
                        }
                        Map<BalanceKey, Map<String, Object>> stockRows = new TreeMap<>();
                        for (var e : stockQuantities.entrySet()) {
                            var key = e.getKey();
                            var search = relation(p, "warehouseId", key.warehouseId());
                            search.putParam("productId", key.productId());
                            var actual = balances.lockOrganization(search);
                            long current = ((Number) actual.get("quantity")).longValue();
                            if (purchase || salesReturn) {
                                if (e.getValue() > 999999999L - current) {
                                    throw CrmPartnerValueSupport.failure("STOCK_QUANTITY_LIMIT");
                                }
                            } else if (e.getValue() > current) {
                                throw CrmPartnerValueSupport.failure("STOCK_INSUFFICIENT");
                            }
                            openings.requireApprovedForPost(
                                    relation(p, "id", actual.get("openingBatchId")));
                            stockRows.put(key, actual);
                        }
                        var batch = relation(p, "documentId", head.get("id"));
                        batch.putParam("action", "POST");
                        batch.putParam("headerVersion", head.get("versionNo"));
                        batch.putParam("approvedSnapshotHash", head.get("approvedSnapshotHash"));
                        batch.putParam("detailCount", values.size());
                        long batchId = batches.append(batch);
                        List<String> ids = new ArrayList<>();
                        Map<Long, Long> lastReturnDetails = new TreeMap<>();
                        // 每个实际document行恰好一个效果；重复SKU仍保留来源行，不用聚合行替代流水。
                        for (var row : values) {
                            var key =
                                    new BalanceKey(
                                            ((Number) row.get("warehouseId")).longValue(),
                                            ((Number) row.get("productId")).longValue());
                            var effect = relation(p, "batchId", batchId);
                            effect.putParam("documentId", head.get("id"));
                            effect.putParam("documentLineId", row.get("id"));
                            for (String f :
                                    List.of(
                                            "sourceOrderLineId",
                                            "lineNo",
                                            "warehouseId",
                                            "productId")) {
                                effect.putParam(f, row.get(f));
                            }
                            effect.putParam("effectKind", "STOCK");
                            effect.putParam("action", "POST");
                            effect.putParam("stockBalanceId", stockRows.get(key).get("id"));
                            effect.putParam(
                                    "quantityDelta",
                                    ((Number) row.get("quantity")).longValue()
                                            * ((purchase || salesReturn) ? 1 : -1));
                            if (salesReturn) {
                                effect.putParam(
                                        "refundCapacityMinor",
                                        returnEntitlements.get(
                                                ((Number) row.get("id")).longValue()));
                            }
                            long detailId = details.append(effect, "crm.stock.post");
                            ids.add(Long.toString(detailId));
                            if (salesReturn) {
                                long sourceId = ((Number) row.get("sourceOrderLineId")).longValue();
                                var edge = relation(p, "childDetailId", detailId);
                                edge.putParam("parentDetailId", row.get("baseIssueDetailId"));
                                edge.putParam("dependencyKind", "RETURN_FOR_ISSUE");
                                dependencies.appendAllocation(edge, "crm.stock.post");
                                var previous = progressRows.get(sourceId).get("lastReturnDetailId");
                                if (previous != null) {
                                    // 所有本批行依赖批前末节点，不建立同batch边；跨批只能逆序补偿。
                                    edge.putParam("parentDetailId", previous);
                                    edge.putParam("dependencyKind", "SERIAL_RETURN_ENTITLEMENT");
                                    dependencies.appendAllocation(edge, "crm.stock.post");
                                }
                                lastReturnDetails.put(sourceId, detailId);
                            }
                        }
                        // 每个余额维度只CAS一次聚合数量，多个来源行共享余额时版本也仅加一次。
                        for (var e : stockQuantities.entrySet()) {
                            var actual = stockRows.get(e.getKey());
                            var update = relation(p, "id", actual.get("id"));
                            update.putParam("versionNo", actual.get("versionNo"));
                            update.putParam("quantity", e.getValue());
                            if (purchase || salesReturn) {
                                balances.receiveOrganization(update);
                            } else {
                                balances.issueOrganization(update);
                            }
                        }
                        // 采购到货也累计本来源的实际履约数量；不改变退货/现金列或授权上限。
                        for (var e : sourceQuantities.entrySet()) {
                            var actual = progressRows.get(e.getKey());
                            var update = relation(p, "id", actual.get("id"));
                            update.putParam("versionNo", actual.get("versionNo"));
                            update.putParam("quantity", e.getValue());
                            if (salesReturn) {
                                update.putParam(
                                        "lastReturnDetailId", lastReturnDetails.get(e.getKey()));
                                progress.applyReturn(update);
                            } else {
                                progress.applyIssue(update);
                            }
                        }
                        var posted = documents.markPosted(p);
                        if (returnsAvailable() && !purchase) {
                            for (int i = 0; i < values.size(); i++) {
                                var original =
                                        relation(p, "originalDetailId", Long.valueOf(ids.get(i)));
                                original.putParam(
                                        "sourceOrderLineId",
                                        values.get(i).get("sourceOrderLineId"));
                                original.putParam(
                                        "capacityKind",
                                        salesReturn ? "RETURN_REFUND" : "ISSUE_RETURN");
                                capacities.registerOriginal(original, "crm.stock.post");
                            }
                        }
                        access.requireStockScope(
                                p.getParam("organizationCandidateId"), "crm.stock.post");
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("documentId", head.get("id").toString());
                        data.put("state", "POSTED");
                        data.put("version", posted.get("versionNo").toString());
                        data.put("versionNo", posted.get("versionNo").toString());
                        data.put("postingBatchId", Long.toString(batchId));
                        data.put("detailIds", ids);
                        data.put("replay", false);
                        data.put("synthetic", scope.get("synthetic"));
                        var complete = CrmStockValueSupport.param(req.getParamMap());
                        complete.putParam("id", requestId);
                        complete.putParam("resultBatchId", batchId);
                        complete.putParam("resultVersionNo", posted.get("versionNo"));
                        complete.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
                        requests.completeOrganization(complete);
                        var event = relation(p, "postingRequestId", requestId);
                        event.putParam("batchId", batchId);
                        event.putParam("action", "STOCK_POST");
                        event.putParam("resourceId", head.get("id"));
                        event.putParam("previousVersion", head.get("versionNo"));
                        event.putParam("newVersion", posted.get("versionNo"));
                        audit.append(event);
                        return CrmPartnerValueSupport.result(data);
                    });
        } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
            if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
                throw failure;
            }
            var stored = requests.committedOrganization(req);
            if (stored == null || !req.getParam("payloadHash").equals(stored.get("payloadHash"))) {
                throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
            }
            if (!"COMPLETED".equals(stored.get("requestState"))) {
                throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> data =
                    JsonUtils.fromJson(
                            (String) CrmStockValueSupport.browser(stored).get("responseSnapshot"),
                            Map.class);
            data.put("replay", true);
            return CrmPartnerValueSupport.result(data);
        }
    }

    /**
     * 一次真实本组织POST批次/全部明细查询，FK保证同document/line/source/余额维度。
     *
     * @param input 例如org901/id1200000
     * @return 精确文本批次及全部detail，越组织统一拒绝
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     null请求先核真实身份：匿名UNIAUTH_IDENTITY_REQUIRED；已登录缺组织候选INVALID_CRM_ID，不写业务数据
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.REQUIRES_NEW,
            readOnly = true)
    public CommonResult batch(CommonParam input) {
        // 缺请求仍先核验真实身份与原组织候选，不让空指针先于原安全准入。
        access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var head = batches.lockScoped(input, "crm.stock.read");
        var all = details.readAll(relation(input, "batchId", head.get("id")), "crm.stock.read");
        if (all.stream().anyMatch(r -> !"STOCK".equals(r.get("effectKind")))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        if (all.size() != ((Number) head.get("detailCount")).intValue()) {
            throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
        }
        var data = CrmStockValueSupport.browser(head);
        data.put("details", all.stream().map(CrmStockValueSupport::browser).toList());
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 聚合后台真实业务和公共配置；所有分页独立20行，不向客户端拼假记录。
     *
     * @param input 例如org901/page1/langzh-CN
     * @return 实际单据/来源/仓库/余额/流水及SELUI定义；生产默认拒绝
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求先遵守身份与组织准入；匿名UNIAUTH_IDENTITY_REQUIRED，实际登录无组织候选INVALID_CRM_ID，无业务写入
     */
    @Override
    @OperationLog
    public CommonResult workspace(CommonPageParam input) {
        // 缺请求仍沿原准入核验真实身份和组织，不推定默认候选。
        var scope = access.requireStockScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var documentPage = documents.getStore(input);
        String reason =
                CrmStockValueSupport.pageReason(
                        input.getParam("documentKind"),
                        input.getParam("reason"),
                        returnsAvailable());
        boolean salesReturn = "SALES_RETURN".equals(reason);
        boolean purchase = "PURCHASE".equals(reason);
        var orderPage =
                purchase
                        ? orders.approvedPurchaseForStock(page(input, "orderPageNo"))
                        : orders.approvedSalesForStock(page(input, "orderPageNo"));
        var warehousePage = warehouses.getStore(page(input, "warehousePageNo"));
        var balancePage = balances.organizationStore(page(input, "balancePageNo"));
        var detailPage = details.getStore(page(input, "detailPageNo"));
        Map<String, Boolean> permits = new LinkedHashMap<>();
        for (String action :
                List.of(
                        "crm.stock.write",
                        "crm.stock.submit",
                        "crm.stock.approve",
                        "crm.stock.post")) {
            try {
                access.requireStockScope(input.getParam("organizationCandidateId"), action);
                permits.put(action, true);
            } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
                if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
                    throw failure;
                }
                permits.put(action, false);
            }
        }
        if (Boolean.TRUE.equals(stockReversalEnabled) || access.formalCapabilityAvailable("stockReversal")) {
            try {
                access.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
                permits.put("crm.stock.reverse", true);
            } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
                if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
                    throw failure;
                }
                permits.put("crm.stock.reverse", false);
            }
        }
        var workspace =
                com.sp.selplat.crm.common.util.stock.CrmStockWorkspaceSupport.build(
                        documentPage,
                        orderPage,
                        warehousePage,
                        balancePage,
                        detailPage,
                        permits,
                        input.getParam("lang"),
                        purchase);
        return com.sp.selplat.crm.common.util.authorization.CrmWorkspaceEvidence.decorate(
                com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnWorkspaceSupport.decorate(
                workspace,
                input.getParam("lang"),
                salesReturn,
                false,
                returnsAvailable()), scope, input.getParam("lang"));
    }

    /**
     * 每个右侧列表独立分页，候选组织不变。
     *
     * @param input 实际org901与分页候选
     * @param field 固定orderPageNo等服务器分页键
     * @return 公共page1/20，无客户端SQL或默认组织
     * @throws com.sp.selplat.common.exception.CommonBusinessException 页码2147483648拒绝INVALID_CRM_ID，无写入
     */
    private CommonPageParam page(CommonPageParam input, String field) {
        var p = new CommonPageParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        // 外部long分页候选先核公共int范围，避免算术异常泄漏；不截断原请求。
        long pageNo = input.getParam(field) == null
                ? 1 : CrmPartnerValueSupport.positive(input.getParam(field));
        if (pageNo > Integer.MAX_VALUE) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
        }
        p.setPageNo((int) pageNo);
        p.setPageSize(20);
        return p;
    }

    // 一期退货仅在本域显式结构与原库存动作许可全满足时进入实际过账。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
    private Boolean returnsEnabled;

    // 三类原容量各由本表owning服务锁和CAS，不直接访问跨表DAO。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService capacities;

    // 有效父依赖与跨批权益边不可变，与流水和余额同CRM事务。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService dependencies;

    // 显式新结构才提供独立库存冲正表单，生产默认不展示。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmStockReversalIsolatedEnabled")
    private Boolean stockReversalEnabled;

    /**
     * 方法作用：隔离测试沿用原开关，正式模式只在真实退货结构已安装时使用退货合同。
     * @return 真实返回示例：已安装容量与依赖表的正式模式true，默认或旧结构false。
     * 异常或副作用示例：只读结构；不授予库存动作或打开资金权限。
     */
    private boolean returnsAvailable() {
        return Boolean.TRUE.equals(returnsEnabled) || access.formalCapabilityAvailable("salesReturn");
    }
}
