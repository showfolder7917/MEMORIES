/** 2026-10-05：c_product 原词法待审预览，依照DESIGN_V2_1只读条款，不写主表或历史表。 */
package com.sp.selplat.crm.common.util.migration;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 商品特有只读待审清单；未知状态/时间/单位保持原值，没有通用迁入或权限能力。 */
public final class CrmProductMigrationPreflight {
    // 唯一合同来自migration-target-map-v2.json的c_product；缺字段不能按NULL填补。
    private static final List<String> FIELDS = List.of("id", "name", "source_price", "price",
            "zhe_kou", "dai_li_zhe_kou", "kucun", "kucun_alarm", "buhuo_record",
            "ymx_sys_product_tag_id", "sortnum", "status", "created", "modified", "machine_code");

    /** 无状态纯值预览不允许实例化；副作用示例：不分配ID或创建迁入批次。 */
    private CrmProductMigrationPreflight() {
    }

    /**
     * 校验完整c_product原词法候选，保留显式NULL与原状态/金额/时间；不推导typed状态/单位。
     *
     * @param input 已获准调用方提供的声明，例如{mode=DRY_RUN,sourceSystem=ERP,records=[完整词法行]}
     * @return 报告，例如{writeEnabled=false,typedImportBlocked=true,pendingReview=[],issues=[]}
     *     副作用示例：缺字段、数值类型或重复来源整批阻断；无法将旧负库存洗成0或把未知状态变ACTIVE。
     */
    public static Map<String, Object> inspect(Map<String, Object> input) {
        Map<String, Object> report = new LinkedHashMap<>();
        List<Map<String, Object>> issues = new ArrayList<>();
        report.put("mode", "DRY_RUN");
        report.put("writeEnabled", false);
        report.put("typedImportBlocked", true);
        report.put("archivePersistence", "NOT_IMPLEMENTED");
        report.put("batchPersistence", "NOT_IMPLEMENTED");
        report.put("rollbackWrites", "NOT_IMPLEMENTED");
        report.put("pendingReview", List.of());
        report.put("issues", issues);
        report.put("reportRedactions", List.of("machine_code", "buhuo_record"));
        report.put("blockingContracts", List.of("APPROVED_SCOPE_ID_LEDGER_REQUIRED",
                "UNIT_NOT_PROVED_EA", "PRODUCT_DDL_REJECTS_MIGRATION_PENDING",
                "STOCK_CUTOFF_WAREHOUSE_FACTS_REQUIRED"));
        // dry-run必须显式指定；不以未知mode、writeEnabled或客户端状态控制业务执行。
        if (input == null || !"DRY_RUN".equals(input.get("mode"))
                || !(input.get("sourceSystem") instanceof String system) || system.isBlank()
                || system.length() > 128 || system.codePoints().anyMatch(Character::isISOControl)
                || !(input.get("records") instanceof List<?> records) || records.size() > 1000
                || input.size() > 5
                || !Set.of("mode", "sourceSystem", "records", "organizationCandidateId", "writeEnabled")
                        .containsAll(input.keySet())
                || (input.containsKey("writeEnabled") && !Boolean.FALSE.equals(input.get("writeEnabled")))) {
            issues.add(Map.of("row", 0, "code", "READ_ONLY_INPUT_INVALID"));
            report.put("lexicalManifestValid", false);
            return report;
        }
        List<Map<String, Object>> pending = new ArrayList<>();
        Set<String> keys = new HashSet<>();
        long bytes = 0;
        for (int index = 0; index < records.size(); index++) {
            // 完整字段集合与词法输入保证NULL/缺失可区分；不把浮点舍入后的JSON当历史精确值。
            if (!(records.get(index) instanceof Map<?, ?> row)
                    || row.size() != FIELDS.size() || !row.keySet().containsAll(FIELDS)
                    || !(row.get("id") instanceof String id) || id.isBlank() || id.length() > 128) {
                issues.add(Map.of("row", index + 1, "code", "SOURCE_FIELD_OR_KEY_MISSING"));
                continue;
            }
            if (!keys.add(id)) {
                issues.add(Map.of("row", index + 1, "code", "DUPLICATE_ORIGIN"));
            }
            Map<String, Object> preserved = new LinkedHashMap<>();
            for (String field : FIELDS) {
                Object value = row.get(field);
                if (value == null) {
                    // 公共JSON忽略null，因此用显式NULL标记，绝不丢字段或填0/空字符串。
                    preserved.put(field, Map.of("kind", "NULL"));
                } else if (value instanceof String token && token.length() <= 500
                        && token.codePoints().noneMatch(Character::isISOControl)) {
                    bytes += token.getBytes(java.nio.charset.StandardCharsets.UTF_8).length;
                    // 原输入不变；可能包含标识/地址/私人备注的两列只在报告展示层遮蔽，不作为归档写入结果。
                    preserved.put(field, Set.of("machine_code", "buhuo_record").contains(field)
                            ? Map.of("kind", "REDACTED") : Map.of("kind", "LEXICAL", "value", token));
                } else {
                    issues.add(Map.of("row", index + 1, "code", "LEXICAL_VALUE_REQUIRED"));
                }
            }
            pending.add(Map.of("sourceSystem", system, "sourceTable", "c_product", "sourceId", id,
                    "candidateKind", "READ_ONLY_ARCHIVE_PREVIEW", "sourcePayload", preserved));
        }
        if (bytes > 2L * 1024 * 1024) {
            issues.add(Map.of("row", 0, "code", "LEXICAL_INPUT_TOO_LARGE"));
        }
        // 预览和typed导入分别表述：词法清单成功也不能冲破DDL/单位/身份/库存门禁。
        if (issues.isEmpty()) {
            report.put("pendingReview", pending);
        }
        report.put("lexicalManifestValid", issues.isEmpty());
        return report;
    }
}
