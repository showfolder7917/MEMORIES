/** CRM订单精确值/冻结契约；2026-10-03，Codex；无状态，不授予许可或查询SQL。
 * 修改记录：2026-10-09，Codex；已有行号由原定价入口统一校验，避免提前int转换漏出算术异常。 */
package com.sp.selplat.crm.common.util.order;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.pricing.CrmOrderPricingSupport;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** 完整新单输入白名单、MINOR和稳定快照，不处理历史接续。 */
public final class CrmOrderValueSupport {
    // 冻结的头金额和每行金额必须与服务器重新计算一致，不接受客户端总额。
    public static final List<String> HEAD_MONEY =
            List.of(
                    "subtotalMinor",
                    "discountMinor",
                    "feeMinor",
                    "totalMinor",
                    "refundableGoodsMinor",
                    "refundableFeeMinor");
    public static final List<String> LINE_MONEY =
            List.of(
                    "unitPriceMinor",
                    "grossMinor",
                    "lineDiscountMinor",
                    "lineNetMinor",
                    "feeAllocatedMinor",
                    "approvedDueMinor",
                    "refundableGoodsMinor",
                    "refundableFeeMinor");

    /** 静态值规范或实际页面配置工具，构造不连接数据库、创建业务记录或授予权限。 */
    private CrmOrderValueSupport() {
        // 只提供静态工具，禁止持有会话或业务状态。
    }

    /**
     * 完整新订单规范；输入org901/keyk1/客户200000及完整lines；返回服务器定价，未知可信字段拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 规范参数，含真实候选与服务器精确定价；不写库或授予许可
     */
    public static CommonParam draft(CommonParam input) {
        if (input == null
                || !Set.of(
                                "organizationCandidateId",
                                "id",
                                "expectedVersion",
                                "requestKey",
                                "orderKind",
                                "partnerId",
                                "currency",
                                "fee",
                                "lines")
                        .containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
        }
        CommonParam normalized = command(input, false);
        String kind = CrmPartnerValueSupport.text(input.getParam("orderKind"), 20, true);
        if (!Set.of("SALES", "PURCHASE").contains(kind)) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
        }
        normalized.putParam("orderKind", kind);
        normalized.putParam(
                "partnerId", CrmPartnerValueSupport.positive(input.getParam("partnerId")));
        if (!(input.getParam("lines") instanceof List<?> items)) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
        }
        List<Map<String, Object>> calculator = new ArrayList<>();
        Map<String, Long> existingIds = new HashMap<>();
        Set<Long> supplied = new HashSet<>();
        for (Object item : items) {
            if (!(item instanceof Map<?, ?> raw)) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
            }
            Map<String, Object> line = new LinkedHashMap<>();
            raw.forEach((k, v) -> line.put(String.valueOf(k), v));
            Object id = line.remove("lineId");
            if (id != null) {
                long parsed = CrmPartnerValueSupport.positive(id);
                // 仅保留已有行ID与候选行号的对应；原定价入口统一裁决行号类型及上界。
                String number = String.valueOf(line.get("lineNo"));
                if (!supplied.add(parsed)) {
                    throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
                }
                existingIds.put(number, parsed);
            }
            calculator.add(line);
        }
        Map<String, Object> calculation = new LinkedHashMap<>();
        calculation.put("currency", input.getParam("currency"));
        calculation.put("fee", input.getParam("fee"));
        calculation.put("lines", calculator);
        var pricing = CrmOrderPricingSupport.calculate(calculation);
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> lines = (List<Map<String, Object>>) pricing.get("lines");
        for (var line : lines) {
            Long id = existingIds.get((String) line.get("lineNo"));
            if (id != null) {
                line.put("lineId", id);
            }
        }
        normalized.putParam("pricing", pricing);
        return normalized;
    }

    /**
     * 状态命令或保存通用字段；id600000/version0/keyk1；返回新参数，保存的新单不允许expectedVersion。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     * @param transition 是否为提交审核命令，例如true时必须提供id/version/key，false允许新建
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 严格命令参数，例如org901/order600000/expected1/keyk1
     */
    public static CommonParam command(CommonParam input, boolean transition) {
        if (input == null
                || (transition
                        && !input.getParamMap()
                                .keySet()
                                .equals(
                                        Set.of(
                                                "organizationCandidateId",
                                                "id",
                                                "expectedVersion",
                                                "requestKey")))) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
        }
        var p = new CommonParam();
        p.putParam(
                "organizationCandidateId",
                CrmPartnerValueSupport.positive(input.getParam("organizationCandidateId")));
        String key = CrmPartnerValueSupport.text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
        }
        p.putParam("requestKey", key);
        if (input.getParam("id") != null || transition) {
            p.putParam("id", CrmPartnerValueSupport.positive(input.getParam("id")));
            p.putParam(
                    "expectedVersion",
                    CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        } else if (input.getParam("expectedVersion") != null) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_VERSION");
        }
        return p;
    }

    /**
     * 保存只挑本表列；规范客户和定价输入；返回精确DECIMAL头字段，不含客户端身份。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     * @param scope 服务刚从真实Session/隔离许可表回查的范围，例如tenant92/org901/actor9211
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 只含本表列和可信审计字段的插入/CAS参数；不含未知客户端字段
     */
    public static CommonParam header(CommonParam input, Map<String, Object> scope) {
        @SuppressWarnings("unchecked")
        Map<String, Object> price = (Map<String, Object>) input.getParam("pricing");
        var row = new CommonParam();
        row.putParam("orderKind", input.getParam("orderKind"));
        row.putParam("partnerId", input.getParam("partnerId"));
        for (String field :
                List.of(
                        "currency",
                        "currencyScale",
                        "pricingPolicyVersion",
                        "refundPolicyVersion")) {
            row.putParam(field, price.get(field));
        }
        for (String field : HEAD_MONEY) {
            row.putParam(field, new BigDecimal((String) price.get(field)));
        }
        row.putParam("orderState", "DRAFT");
        return CrmPartnerValueSupport.entity(row, scope);
    }

    /**
     * 复制真实头行并将ID、版本、数量和MINOR及实际CLOB快照转为浏览器安全文本。
     *
     * @param row 实际本表行，例如id600000/totalMinor135/snapshotClob
     * @return 示例{id:"600000",totalMinor:"135"}保留其他原字段；无舍入或SQL写入
     * @throws IllegalStateException 实际SQL CLOB读取失败时Cannot read own snapshot，保留原异常
     */
    public static Map<String, Object> browser(Map<String, Object> row) {
        Map<String, Object> result = new LinkedHashMap<>(row);
        for (var entry : result.entrySet()) {
            Object value = entry.getValue();
            String key = entry.getKey();
            if (value instanceof Number
                    && (key.endsWith("Id")
                            || key.equals("id")
                            || key.equals("versionNo")
                            || key.equals("quantity")
                            || key.endsWith("Minor"))) {
                entry.setValue(
                        value instanceof BigDecimal decimal
                                ? decimal.toPlainString()
                                : value.toString());
            }
            if (value instanceof java.sql.Clob clob) {
                try {
                    entry.setValue(clob.getSubString(1, Math.toIntExact(clob.length())));
                } catch (java.sql.SQLException failure) {
                    throw new IllegalStateException("Cannot read own snapshot", failure);
                }
            }
        }
        return result;
    }

    /**
     * 从真实头行重算并确认所有持久化金额；不能只信客户端/旧快照。
     *
     * @param header 真实订单头，例如currency=CNY/currencyScale2/version1；已持有范围头锁
     * @param rows 真实持久化全量订单行，例如lineNo1/2、dueMinor68/67；不能截断300行
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return MONEY_V1重算结果；所有头行持久化金额不一致拒绝
     */
    public static Map<String, Object> verify(
            Map<String, Object> header, List<Map<String, Object>> rows) {
        int scale = ((Number) header.get("currencyScale")).intValue();
        List<Map<String, Object>> inputs = new ArrayList<>();
        for (var row : rows) {
            if (((Number) row.get("currencyScale")).intValue() != scale) {
                throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
            }
            Map<String, Object> input = new LinkedHashMap<>();
            for (String f : List.of("lineNo", "productId", "quantity", "discountBps", "isGift")) {
                input.put(f, row.get(f) instanceof Boolean ? row.get(f) : row.get(f).toString());
            }
            input.put(
                    "unitPrice",
                    new BigDecimal(row.get("unitPriceMinor").toString())
                            .movePointLeft(scale)
                            .toPlainString());
            inputs.add(input);
        }
        var price =
                CrmOrderPricingSupport.calculate(
                        Map.of(
                                "currency",
                                header.get("currency"),
                                "fee",
                                new BigDecimal(header.get("feeMinor").toString())
                                        .movePointLeft(scale)
                                        .toPlainString(),
                                "lines",
                                inputs));
        if (((Number) price.get("currencyScale")).intValue() != scale) {
            throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
        }
        for (String f : HEAD_MONEY) {
            if (!new BigDecimal(header.get(f).toString()).toPlainString().equals(price.get(f))) {
                throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
            }
        }
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> computed = (List<Map<String, Object>>) price.get("lines");
        var byNumber = new HashMap<String, Map<String, Object>>();
        for (var row : rows) {
            byNumber.put(row.get("lineNo").toString(), row);
        }
        for (var line : computed) {
            for (String f : LINE_MONEY) {
                if (!new BigDecimal(byNumber.get(line.get("lineNo")).get(f).toString())
                        .toPlainString()
                        .equals(line.get(f))) {
                    throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
                }
            }
        }
        return price;
    }

    /**
     * 审核快照固定包含真实范围、源版本、业务头和全部行；不含未来余额或外部授权凭证。
     *
     * @param header 真实订单头，例如currency=CNY/currencyScale2/version1；已持有范围头锁
     * @param lines 实际完整订单行，例如稳定行ID600000/600001与精确MINOR值
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 稳定本组织订单头及全部行精确快照，包含真实源版本
     */
    public static Map<String, Object> snapshot(
            Map<String, Object> header, List<Map<String, Object>> lines) {
        Map<String, Object> snapshot = new TreeMap<>();
        for (String f :
                List.of(
                        "id",
                        "tenantId",
                        "businessOrgId",
                        "orderKind",
                        "partnerId",
                        "currency",
                        "currencyScale",
                        "pricingPolicyVersion",
                        "refundPolicyVersion",
                        "versionNo")) {
            snapshot.put(f, browser(header).get(f));
        }
        for (String f : HEAD_MONEY) {
            snapshot.put(f, browser(header).get(f));
        }
        snapshot.put(
                "lines",
                lines.stream()
                        .sorted(Comparator.comparingInt(l -> ((Number) l.get("lineNo")).intValue()))
                        .map(
                                l -> {
                                    var canonical = new TreeMap<String, Object>();
                                    for (String f :
                                            List.of(
                                                    "id",
                                                    "lineNo",
                                                    "productId",
                                                    "productNameSnapshot",
                                                    "unitCode",
                                                    "quantity",
                                                    "discountBps",
                                                    "isGift",
                                                    "refundPolicyVersion")) {
                                        canonical.put(f, browser(l).get(f));
                                    }
                                    for (String f : LINE_MONEY) {
                                        canonical.put(f, browser(l).get(f));
                                    }
                                    return canonical;
                                })
                        .toList());
        return snapshot;
    }

    /**
     * 请求或冻结内容SHA256；例如规范订单与全部行；返回稳定64位摘要，不含requestKey。
     *
     * @param content 服务器规范业务内容，例如订单头及全部精确行；不消费客户端hash
     * @return 稳定64字符SHA256摘要；不含请求键或外部授权凭证
     */
    public static String hash(Map<String, Object> content) {
        CommonParam p = new CommonParam();
        p.setParamMap(content);
        return CrmPartnerValueSupport.hash(p);
    }

    /**
     * 方法作用：从本域已审核快照提取订购名称与数量，供来源选择辨认，不输出金融字段。
     *
     * @param row 真实已审核订单浏览器行，例如frozenSnapshot包含华文商品一份
     * @return 真实示例：[{productName:"新思度华文",quantity:"1"}]，不含单价、总额或原始快照
     * @throws com.sp.selplat.common.exception.CommonBusinessException 快照或商品行不完整时拒绝；不写订单与资金
     */
    public static List<Map<String, Object>> sourceItems(Map<String, Object> row) {
        try {
            var snapshot = com.sp.selplat.common.util.JsonUtils.fromJson(
                    String.valueOf(row.get("frozenSnapshot")), Map.class);
            if (snapshot == null || !(snapshot.get("lines") instanceof List<?> lines)) {
                throw new IllegalArgumentException("Source lines required");
            }
            var items = new ArrayList<Map<String, Object>>();
            for (var value : lines) {
                if (!(value instanceof Map<?, ?> line)) {
                    throw new IllegalArgumentException("Source line required");
                }
                var name = CrmPartnerValueSupport.text(line.get("productNameSnapshot"), 200, true);
                var quantity = new BigDecimal(String.valueOf(line.get("quantity")));
                if (quantity.signum() <= 0) {
                    throw new IllegalArgumentException("Positive quantity required");
                }
                items.add(Map.of("productName", name, "quantity", quantity.stripTrailingZeros().toPlainString()));
            }
            return items;
        } catch (RuntimeException malformed) {
            throw CrmPartnerValueSupport.failure("CRM_PRICING_SNAPSHOT_MISMATCH");
        }
    }

    /**
     * 浏览器单价只作精确MAJOR展示，不重算记账金额。
     *
     * @param row 实际持久化订单行，例如unitPriceMinor=101、currencyScale=2
     * @return 精确文本字段与unitPrice；币种scale须由头供给，实际小步持久化行含currencyScale
     */
    public static Map<String, Object> browserLine(Map<String, Object> row) {
        var result = browser(row);
        int scale = ((Number) row.get("currencyScale")).intValue();
        result.put(
                "unitPrice",
                new BigDecimal(row.get("unitPriceMinor").toString())
                        .movePointLeft(scale)
                        .toPlainString());
        return result;
    }
}
