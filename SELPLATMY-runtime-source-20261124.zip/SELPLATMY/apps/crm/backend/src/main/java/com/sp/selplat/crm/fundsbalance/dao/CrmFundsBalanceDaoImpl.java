/** CrmFundsBalanceDaoImpl.java：固定参数化 SQL 只访问本表，绑定 CRM 事务连接。 */
package com.sp.selplat.crm.fundsbalance.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表锁定读、条件更新及唯一约束由数据库协调，不依赖进程内锁。 */
@Repository
public class CrmFundsBalanceDaoImpl extends CrmBaseDao implements CrmFundsBalanceDao {

  // 与公共 MyBatis 使用同一个 crmDataSource，不自行建立连接池。
  private final JdbcTemplate jdbc;

  /**
   * 绑定CRM具名SQL模板，构造不执行SQL或接银行渠道。
   *
   * @param jdbc Spring提供的crmJdbcTemplate，不建立额外连接池
   */
  public CrmFundsBalanceDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * 实际SQL只允许零或一条余额，不能隐藏重复维度错误。
   *
   * @param rows 真实SQL行，例如[{id:980001,amountMinor:1000}]
   * @return 示例返回唯一余额Map；空结果返回null，不创建余额
   * @throws IllegalStateException 两条余额结果时拒绝Expected one CRM row
   */
  private java.util.Map<String, Object> first(java.util.List<java.util.Map<String, Object>> rows) {
    if (rows.size() > 1) {
      throw new IllegalStateException("Expected one CRM row");
    }
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 本表固定 SQL 扩展 lockScoped；不拼接表名、字段名或请求 SQL。
   *
   * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
   * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
   */
  @Override
  public java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return first(
        jdbc.queryForList(
            "SELECT * FROM CrmFundsBalance WHERE tenantId=? AND ownerUserId=? AND"
                + " accountId=? AND currency=? AND amountUnit=? AND accountKind='CASH'"
                + " AND status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("ownerUserId"),
            input.getParam("accountId"),
            input.getParam("currency"),
            input.getParam("amountUnit")));
  }

  /**
   * 本表固定 SQL 扩展 applyDeltaIfVersion；不拼接表名、字段名或请求 SQL。
   *
   * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
   * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
   */
  @Override
  public int applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmFundsBalance SET"
            + " amount=amount+?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP,lastOperateUserId=?"
            + " WHERE tenantId=? AND ownerUserId=? AND id=? AND status=1 AND versionNo=? AND"
            + " accountKind='CASH' AND amount+? >= 0",
        input.getParam("delta"),
        input.getParam("ownerUserId"),
        input.getParam("tenantId"),
        input.getParam("ownerUserId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("delta"));
  }

  /**
   * 方法作用及真实业务示例：锁同组织同账户同币种真实余额；tenant92/org901/account90101/CNY；返回真实余额980001或null；不按actor分账、不创建不存在余额。
   * Real organization balance row lock.
   *
   * @param input verified org901/account90101/currencyCNY
   * @return actual CASH ledger row or null; no account fallback
   */
  @Override
  public java.util.Map<String, Object> lockOrganization(
      com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return first(
        jdbc.queryForList(
            "SELECT * FROM CrmFundsBalance WHERE tenantId=? AND businessOrgId=? AND"
                + " accountId=? AND currency=? AND status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("accountId"),
            input.getParam("currency")));
  }

  /**
   * 方法作用及真实业务示例：本表精确最小单位聚合加款CAS；余额980001/version0/amount135/actor9211；返回1或0；旧版本或DECIMAL38溢出零行须由服务抛异常整批回滚。
   * One aggregated minor-unit addition with version and DECIMAL38 bound.
   *
   * @param input actual id/version0/amountMinor135/actor9211
   * @return 1 for committed update or 0 for stale/overflow; outer service rolls back
   */
  @Override
  public int receiveOrganization(com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmFundsBalance SET"
            + " amountMinor=amountMinor+?,versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=? AND"
            + " versionNo<9223372036854775807 AND"
            + " amountMinor+?<=99999999999999999999999999999999999999",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"));
  }

  /**
   * 方法作用：同账户聚合减额CAS保证不负余额。
   *
   * @param input 余额980001/version1/amount135/actor9211
   * @return 影响1或0；0行外层回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  public int reverseOrganization(com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmFundsBalance SET"
            + " amountMinor=amountMinor-?,versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=? AND"
            + " versionNo<9223372036854775807 AND amountMinor>=?",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"));
  }

  /**
   * 方法作用：原余额本表固定插入，不使用MERGE或覆写已有账户维度。
   *
   * @param input 原期初真实参数，例如tenant92/org901/account90101/opening900000/amountMinor0
   * @return 真实返回示例：影响1，原账户币种唯一冲突直接失败。 异常或副作用示例：SQL失败使外层期初审核一并回滚，无银行操作。
   */
  @Override
  public int initializeOpening(com.sp.selplat.common.util.CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "INSERT INTO CrmFundsBalance"
            + " (id,tenantId,businessOrgId,createdByUserId,updatedByUserId,lastOperateUserId,accountId,currency,"
            + "openingBatchId,openingMinor,amountMinor,versionNo)"
            + " VALUES (?,?,?,?,?,?,?,?,?,?,?,0)",
        input.getParam("id"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("accountId"),
        input.getParam("currency"),
        input.getParam("openingBatchId"),
        input.getParam("amountMinor"),
        input.getParam("amountMinor"));
  }
}
