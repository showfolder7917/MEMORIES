/** 单一销售出库隔离本表组件；2026-10-03，Codex；2026-10-06补同sortnum稳定分页；生产默认拒绝。 */
package com.sp.selplat.crm.documentline.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonPageResult;

import java.util.List;
import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmDocumentLineDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmDocumentLineDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmDocumentLineDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 明细默认sortnum相同，追加范围内唯一id稳定排序，避免不同OFFSET页重复或遗漏行。
     *
     * @param conditions owning Service已验证的条件，例如tenant92/org901/status1/STOCK_ISSUE/SALE
     * @param pageNo 实际请求页码，例如2
     * @param pageSize 实际每页条数，例如1
     * @return 公共页，例如records中id1100001、totalCount2、pageNo2、pageSize1
     *     异常或副作用示例：仍由公共条件/方言校验及SQL查询失败传播，不改范围或写库。
     */
    @Override
    public CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 原主排序保持sortnum倒序，同值以id升序确定位置；分页/总数仍走公共SQL builder。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmDocumentLine WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 持锁稳定全量父行；固定本表事务扩展。
     *
     * @param input 例如org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public List<Map<String, Object>> readAll(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmDocumentLine WHERE tenantId=? AND businessOrgId=? AND documentId=? AND status=1 ORDER BY id FOR UPDATE",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("documentId"));
    }

    /**
     * 本表完整删除；固定本表事务扩展。
     *
     * @param input 例如org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public int deleteAll(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "DELETE FROM CrmDocumentLine WHERE tenantId=? AND businessOrgId=? AND documentId=?",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("documentId"));
    }

    /**
     * 方法作用：读取所有实际原收款明细引用，status不能关闭依赖。
     *
     * @param input tenant92/org901/parent1300000
     * @return 真实关联行或空列表 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public List<Map<String, Object>> receiptChildren(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmDocumentLine WHERE tenantId=? AND businessOrgId=? AND baseReceiptDetailId=? ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("parentDetailId"));
    }
}
