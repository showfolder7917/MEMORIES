/** CrmPostingRequestDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingrequest.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

/** 本人隔离过账记录 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmPostingRequestDao extends BaseDao {
    /**
     * 本表固定 SQL 扩展 claimRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    int claimRequest(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表固定 SQL 扩展 completeRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    int completeRequest(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表固定 SQL 扩展 findRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    java.util.Map<String, Object> findRequest(com.sp.selplat.common.util.CommonParam input);

    /**
     * V2组织批次首次结果。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    java.util.Map<String, Object> findOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查
     * @return 本表实际结果或无返回；零CAS、缺许可或约束异常整笔回滚
     */
    int completeOrganization(CommonParam input);

    /**
     * 方法作用：本表冲正请求真实唯一结果查询或条件完成。
     *
     * @param input tenant92/org901/REVERSE/keyr1及首次batch/version
     * @return 真实请求或影响行数；不存在null，0行拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    java.util.Map<String, Object> findFundsReverse(com.sp.selplat.common.util.CommonParam input);

    /**
     * 方法作用：本表冲正请求真实唯一结果查询或条件完成。
     *
     * @param input tenant92/org901/REVERSE/keyr1及首次batch/version
     * @return 真实请求或影响行数；不存在null，0行拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    int completeFundsReverse(com.sp.selplat.common.util.CommonParam input);
}
