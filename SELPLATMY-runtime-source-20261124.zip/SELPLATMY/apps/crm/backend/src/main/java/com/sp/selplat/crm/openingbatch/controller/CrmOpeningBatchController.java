/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.openingbatch.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

/** HTTP只调用本表owning服务，通用写没有路由。 */
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/crm/openingbatch")
public class CrmOpeningBatchController {

  private final com.sp.selplat.crm.openingbatch.service.CrmOpeningBatchService service;

  /**
   * 注入本表服务；构造不执行SQL。
   *
   * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
   */
  public CrmOpeningBatchController(
      com.sp.selplat.crm.openingbatch.service.CrmOpeningBatchService service) {
    this.service = service;
  }

  /**
   * 公共范围分页。
   *
   * @param input 例如org901/page1
   * @return 实际公共分页JSON；缺许可拒绝
   */
  @org.springframework.web.bind.annotation.GetMapping("getStore.htm")
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(service.getStore(input));
  }

  /**
   * 公共范围详情。
   *
   * @param input 例如org901/id1000000
   * @return 实际公共结果JSON；跨组织拒绝
   */
  @org.springframework.web.bind.annotation.GetMapping("getById.htm")
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.getById(input));
  }

  /**
   * 方法作用：只把原JSON交原期初拥有方，前端不能指定操作者或审核资格。
   *
   * @param input 原请求，例如operationSAVE/account90101/amountMinor0/requestKey opening-1
   * @return 真实示例：success=true/data.id900000/openingStateDRAFT/versionNo0。
   *     异常或副作用示例：拒绝自审和旧版本；批准才在原事务产生余额。
   */
  @org.springframework.web.bind.annotation.PostMapping("maintain-funds.htm")
  public String maintainFunds(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.maintainFunds(input));
  }

  /**
   * 方法作用：序列化资金期初实际分页。
   *
   * @param input org901/pageNo1/pageSize20
   * @return 真实示例：records含900000及totalCount1。 异常或副作用示例：原拥有方拒绝时沿统一错误合同，无写入。
   */
  @org.springframework.web.bind.annotation.GetMapping("funds-store.htm")
  public String fundsStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(service.fundsStore(input));
  }

  /**
   * 方法作用：序列化指定期初及安全历史。
   *
   * @param input org901/id900000
   * @return 真实示例：success=true/data.openingStateDRAFT/history一条。 异常或副作用示例：跨租户或未知来源拒绝，不创建记录。
   */
  @org.springframework.web.bind.annotation.GetMapping("read-funds.htm")
  public String readFunds(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.readFunds(input));
  }
}
