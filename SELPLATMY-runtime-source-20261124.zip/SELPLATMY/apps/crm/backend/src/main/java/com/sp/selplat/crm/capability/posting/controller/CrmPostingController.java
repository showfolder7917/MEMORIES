/** CrmPostingController.java：平台参数与结果的无写入预检入口。 修改记录：2026-10-03，Codex 按委托接入本域服务，只接入默认关闭的隔离开发过账路由。 */
package com.sp.selplat.crm.capability.posting.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.posting.service.CrmPostingService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只调用本能力服务并序列化公共结果；不读表、不执行 SQL、生产门禁关闭，过账只在隔离测试中开启。 */
@RestController
@RequestMapping("/api/crm/posting")
public class CrmPostingController {
    // 本控制器仅调用自身服务，真实身份由服务回查。
    private final CrmPostingService service;

    /**
     * 装配本能力服务。
     *
     * @param service Spring 的 CrmPostingServiceImpl 返回示例：构造实例；不触发预检或持久化。
     */
    public CrmPostingController(CrmPostingService service) {
        this.service = service;
    }

    /**
     * POST 只因接收预检参数，不产生业务记录或库存/金额变动。
     *
     * @param input 公共解析器产生的 CommonParam，例如 kind=SALES_ORDER/state=DRAFT/action=SUBMIT
     * @return 公共 JSON，例如 {success:true,data:{to:SUBMITTED,writeEnabled:false,factsVerified:false}}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 身份或预检失败沿用统一异常响应
     */
    @PostMapping("preview.htm")
    public String preview(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.preview(input));
    }

    /**
     * 调用具名原子流程；输入例如id102/actionPOST/keyr1/version0；返回公共JSON；生产门禁拒绝且不写库。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：调用具名原子流程；输入例如id102/actionPOST/keyr1/version0；返回公共JSON；生产门禁拒绝且不写库。
     * @return 公共JSON
     */
    @PostMapping("execute.htm")
    public String execute(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.execute(input));
    }
}
