/** CrmPostingDocumentDaoImpl.java：固定参数化 SQL 只访问本表，绑定 CRM 事务连接。 */
package com.sp.selplat.crm.postingdocument.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表锁定读、条件更新及唯一约束由数据库协调，不依赖进程内锁。 */
@Repository
public class CrmPostingDocumentDaoImpl extends CrmBaseDao implements CrmPostingDocumentDao {
    // 与公共 MyBatis 使用同一个 crmDataSource，不自行建立连接池。
    private final JdbcTemplate jdbc;

    /**
     * 绑定本域 SQL 模板；传参例如 crmJdbcTemplate；返回实例；构造不执行 SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmPostingDocumentDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 精确读返回单行或null；输入例如一条CRM结果；不隐藏多行，不写库。
     *
     * @param rows 真实SQL结果列表，例如[{id:101}]；空列表表示未找到。
     * @return 唯一实际行Map；空列表返回null，多行拒绝，不丢弃重复结果
     * @throws IllegalStateException 实际状态不满足正文条件时拒绝；不继续SQL或构造默认记录
     */
    private java.util.Map<String, Object> first(
            java.util.List<java.util.Map<String, Object>> rows) {
        if (rows.size() > 1) {
            throw new IllegalStateException("Expected one CRM row");
        }
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 本表固定 SQL 扩展 findScoped；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public java.util.Map<String, Object> findScoped(com.sp.selplat.common.util.CommonParam input) {
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingDocument WHERE tenantId=? AND ownerUserId=? AND id=? AND status=1",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("id")));
    }

    /**
     * 本表固定 SQL 扩展 lockScoped；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingDocument WHERE tenantId=? AND ownerUserId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("id")));
    }

    /**
     * 本表固定 SQL 扩展 changeStateIfVersion；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public int changeStateIfVersion(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmPostingDocument SET documentState=?,versionNo=versionNo+1,"
                        + "updatedAt=CURRENT_TIMESTAMP,lastOperateUserId=? WHERE tenantId=? AND "
                        + "ownerUserId=? AND id=? AND status=1 AND versionNo=? AND documentState=?",
                input.getParam("nextState"),
                input.getParam("ownerUserId"),
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("id"),
                input.getParam("versionNo"),
                input.getParam("documentState"));
    }
}
