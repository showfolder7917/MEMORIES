/** 完整收款冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.fundsreversalrequest.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmFundsReversalRequestService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定资金读取、冲正或审核动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);

    /**
     * 方法作用：按当前真实许可读取原收款对应申请。
     *
     * @param input org901/originalBatch1200000
     * @param action funds.read或reverse或approve
     * @return 实际申请，不替代原审批 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Map<String, Object> forOriginal(CommonParam input, String action);

    /**
     * 方法作用：申请全额冲正并记录完整原批次摘要，不改原单据。
     *
     * @param input 服务器实际originalDoc1000000/batch1200000/version3/amount135/reason
     * @return 新申请id1700000/version0；每原批次只有一条申请 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Long submit(CommonParam input);

    /**
     * 方法作用：他人审核或记录完整冲正结果并重查权限版本。
     *
     * @param input org901/申请1700000/expected0或1/实际resultBatch
     * @param execute false审核，true已完整执行
     * @return 实际申请APPROVED/version1或POSTED/version2；自审拒绝
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Map<String, Object> transition(CommonParam input, boolean execute);
}
