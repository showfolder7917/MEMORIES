/** CrmProduct：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.product.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.product.service.CrmProductService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表Controller只消费owning Service和公共结果。 */
@RestController
@RequestMapping("/api/crm/product")
public class CrmProductController {
    private final CrmProductService service;

    /**
     * 装配owning服务，不读写数据库；示例为真实CrmProductServiceImpl。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmProductController(CrmProductService service) {
        this.service = service;
    }

    /**
     * 仅序列化现有读范围下的原词法待审报告，不改变产品状态机。
     *
     * @param input JSON公共声明，例如{organizationCandidateId=901,mode=DRY_RUN,sourceSystem=ERP,records=[]}
     * @return JSON，例如{success=true,data={writeEnabled=false,typedImportBlocked=true,pendingReview=[]}}
     *     异常或副作用示例：现有权限不成立则公共处理器拒绝，无导入/授权写入。
     */
    @PostMapping(value = "migrationPreflight.htm", consumes = "application/json", produces = "application/json")
    public String migrationPreflight(@RequestBody CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.migrationPreflight(input));
    }

    /**
     * 实际范围分页；org901/page1；返回公共分页，无许可拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，限定本组织/status1；商品选择另限定ACTIVE
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(input));
    }

    /**
     * 实际范围详情；org901/id600000；返回公共data，无记录或跨组织拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/全部行或product701；拒绝不存在/越范围
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.getById(input));
    }
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 组织候选901/page1
     * @return 实际商品维护配置JSON；缺product.read拒绝
     */
    @GetMapping("workspace.htm")
    public String workspace(CommonPageParam input) { return JsonUtils.toJsonIgnoreNull(service.workspace(input)); }
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 组织候选901/page1
     * @return 实际分页JSON；无业务写入
     */
    @GetMapping("managementStore.htm")
    public String managementStore(CommonPageParam input) { return JsonUtils.toJsonIgnoreNull(service.managementStore(input)); }
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 组织候选901/id700000
     * @return 实际详情JSON；缺product.read拒绝
     */
    @GetMapping("detail.htm")
    public String detail(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.detail(input)); }
    /**
     * 商品维护公开边界，不执行其他模块业务。
     * @param input 商品编码BOOK-001/requestKeyp1
     * @return 实际id/versionNo回执JSON；失败整笔回滚
     */
    @PostMapping(value = "save.htm", consumes = "application/json", produces = "application/json")
    public String save(@RequestBody CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.save(input)); }

}
