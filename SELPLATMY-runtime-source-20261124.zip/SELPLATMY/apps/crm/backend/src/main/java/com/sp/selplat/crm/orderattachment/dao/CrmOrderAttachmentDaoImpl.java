/** CRM附件本表范围锁与CAS；2026-10-04，Codex。 */
package com.sp.selplat.crm.orderattachment.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/** 固定本表SQL与公共模板共用CRM连接和事务，不跨订单DAO。 */
@Repository
public class CrmOrderAttachmentDaoImpl extends CrmBaseDao implements CrmOrderAttachmentDao {
    // 只能绑定本域具名模板，不能选择宿主主数据源。
    private final JdbcTemplate jdbc;

    /**
     * 方法作用：装配CRM实际模板。
     *
     * @param jdbc 例如crmJdbcTemplate，与公共DAO同一连接池 副作用示例：构造不建表、读SQL或授予权限。
     */
    public CrmOrderAttachmentDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 方法作用：通过本表五个真实身份坐标锁定当前有效引用。
     *
     * @param input 例如tenant92/org901/order600000/owner9211/id100000
     * @return 实际行例如fileId为32位不可变ID/versionNo1，不存在为null 异常或副作用示例：无本域真实事务拒绝；不存在不扩大查询。
     */
    @Override
    public Map<String, Object> lockOwned(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmOrderAttachment WHERE tenantId=? AND businessOrgId=? "
                                + "AND orderId=? AND ownerUserId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("orderId"),
                        input.getParam("ownerUserId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 方法作用：仅替换本表引用和独立版本，不修改订单状态/冻结正文/账本。
     *
     * @param input 例如version1/新fileId及真实tenant92/org901/order600000/owner9211/id100000
     * @return 实际0或1行，成功version变2；其他版本保持原样 异常或副作用示例：约束失败回滚；本事务不访问文件磁盘或删除正文。
     */
    @Override
    public int compareAndSet(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmOrderAttachment SET fileId=?,sha256=?,byteSize=?,orderVersion=?,"
                        + "commandRequestId=?,versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,"
                        + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? AND orderId=? "
                        + "AND ownerUserId=? AND id=? AND versionNo=? AND status=1",
                input.getParam("fileId"),
                input.getParam("sha256"),
                input.getParam("byteSize"),
                input.getParam("orderVersion"),
                input.getParam("commandRequestId"),
                input.getParam("ownerUserId"),
                input.getParam("ownerUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("orderId"),
                input.getParam("ownerUserId"),
                input.getParam("id"),
                input.getParam("expectedAttachmentVersion"));
    }
    /**
     * 方法作用：固定五项资源坐标读取唯一引用，不使用客户端字段生成SQL。
     * @param input 例如tenant92/org901/order600000/owner9212/fileId为32位ID
     * @return 真实返回示例：准确引用Map含id100000；无匹配或非唯一时null，未证明文件许可。
     * 异常或副作用示例：只读本表，不跨文件库或订单DAO，不查询其他范围。
     */
    @Override
    public Map<String, Object> findByFileReference(CommonParam input) {
        var rows = jdbc.queryForList("SELECT * FROM CrmOrderAttachment WHERE tenantId=? AND businessOrgId=? "
                + "AND orderId=? AND ownerUserId=? AND fileId=? AND status=1 LIMIT 2",
                input.getParam("tenantId"), input.getParam("businessOrgId"), input.getParam("orderId"),
                input.getParam("ownerUserId"), input.getParam("fileId"));
        // 正式表有同订单/所有者/文件唯一键；损坏结构不能任选一行冒充准确引用。
        return rows.size() == 1 ? rows.get(0) : null;
    }

}
