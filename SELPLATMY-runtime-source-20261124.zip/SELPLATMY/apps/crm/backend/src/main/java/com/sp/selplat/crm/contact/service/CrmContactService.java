/** CrmContactService.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
package com.sp.selplat.crm.contact.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

import java.util.Map;

/** 本表维护服务；HTTP只消费明确接口，不开放通用无版本写入。 */
public interface CrmContactService extends BaseService {
    /**
     * 校验旧用户显式关联和客户历史转交声明，不读取身份目录或写入账户。
     * @param input JSON声明，例如organizationCandidateId=901/mode=DRY_RUN/mappings=[]/transfers=[]
     * @return 例如success=true,data={writeEnabled:false,targetFactsVerified:false,declarationValid:true}
     *     异常示例：缺crm.partner.read拒绝，映射歧义报告阻断，不授予权限。
     */
    CommonResult migrationAssociationPreflight(CommonParam input);

    /**
     * 聚合实际组织分页及公共控件定义；输入org901/lang；返回真实记录；缺read许可拒绝。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：聚合实际组织分页及公共控件定义；输入org901/lang；返回真实记录；缺read许可拒绝。
     * @return 真实记录
     */
    CommonResult workspace(com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 保存本表；输入例如org901/keyk1及完整业务字段；返回id/version/replay；生产缺resolver拒绝。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：保存本表；输入例如org901/keyk1及完整业务字段；返回id/version/replay；生产缺resolver拒绝。
     * @return id/version/replay
     */
    CommonResult save(CommonParam input);

    /**
     * 同事务锁范围内记录；输入例如org901/id200000；返回真实行；无许可/记录拒绝。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：同事务锁范围内记录；输入例如org901/id200000；返回真实行；无许可/记录拒绝。
     * @return 真实行
     */
    Map<String, Object> lockForMaintenance(CommonParam input);
}
