/** CrmBaseDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.common.db.dao.BaseDaoImpl;
import com.sp.selplat.common.db.datasource.BaseDataSourceContext;
import com.sp.selplat.common.db.sequence.model.IdSequenceDefinition;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.Map;

/** 所有私人草稿 DAO 绑定同一 CRM 上下文；租户和本人主键来自身份，不发号。 */
public abstract class CrmBaseDao extends BaseDaoImpl {
    private BaseDataSourceContext context;

    /**
     * 绑定固定CRM数据源上下文，避免跨库自动选择。
     *
     * @param context 具名CRM模板和数据源组合，例如crmBaseDataSourceContext；仅保留引用。
     */
    @Autowired
    protected final void setCrmContext(
            @Qualifier("crmBaseDataSourceContext") BaseDataSourceContext context) {
        this.context = context;
    }

    /**
     * @return 当前模块的私库上下文，例如 crmDataSource 与 CRM Mapper。
     */
    @Override
    protected final BaseDataSourceContext getDataSourceContext() {
        return context;
    }

    /**
     * 声明本表记录主键号段，身份字段不由号段生成。
     *
     * @return 例如CrmOrder表生成CrmOrderId的IdSequenceDefinition；只生成id，不生成tenantId或ownerUserId。
     */
    @Override
    public IdSequenceDefinition getIdSequenceDefinition() {
        return new IdSequenceDefinition(Map.of("id", getTableName() + "Id"));
    }

    /**
     * 确认当前连接属于 CRM 已开启的实际事务，拒绝自动提交的锁定读。 传参示例：无参数，由固定 SQL 扩展在使用 crmJdbcTemplate 前调用。 返回示例：void；CRM
     * 事务已绑定时继续。 异常示例：其他数据源事务或无事务抛出 IllegalStateException，不执行 SQL。
     *
     * @throws IllegalStateException 实际状态不满足正文条件时拒绝；不继续SQL或构造默认记录
     */
    protected final void requireCrmTransaction() {
        javax.sql.DataSource source = getDataSourceContext().getDataSource();
        if (!org.springframework.transaction.support.TransactionSynchronizationManager
                        .isActualTransactionActive()
                || !org.springframework.transaction.support.TransactionSynchronizationManager
                        .hasResource(source)) {
            throw new IllegalStateException("CRM SQL requires its own active transaction");
        }
    }
}
