/** CrmContactServiceImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 修改记录：2026-10-09，Codex；缺请求沿原身份及组织准入拒绝，不先抛空指针，不修改许可。 */
package com.sp.selplat.crm.contact.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.contact.dao.CrmContactDao;
import com.sp.selplat.crm.contact.service.CrmContactService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/** 本表直接复用公共CRUD/号段，HTTP只开放明确范围和版本命令；不自建权限系统。 */
@Service
public class CrmContactServiceImpl extends BaseServiceImpl<CrmContactDao>
        implements CrmContactService {
    // 真实Session和显式合成许可统一由本域准入检查，生产缺公共resolver时拒绝。
    private final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    // 事务协调使用公共Spring扩展，不在Service直接执行SQL或跨表DAO。
    private final org.springframework.transaction.support.TransactionTemplate transaction;
    private final com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests;
    private final com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;
    // 联系人关联通过主体Service锁读，不能跨表调用DAO。
    private final com.sp.selplat.crm.partner.service.CrmPartnerService partners;

    /**
     * 绑定联系人真实伙伴引用及同域命令事务，构造不新建默认客户。
     *
     * @param access 实际Session及org901联系人动作准入
     * @param requests 本域联系人命令幂等，例如CONTACT_SAVE/keyk1
     * @param audit 同CRM事务真实actor9211审计
     * @param manager crmTransactionManager，保留原传播和回滚
     * @param partners 实际伙伴owning服务，联系人写前锁同组织partner501
     */
    public CrmContactServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access,
            com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests,
            com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit,
            @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
                    org.springframework.transaction.PlatformTransactionManager manager,
            com.sp.selplat.crm.partner.service.CrmPartnerService partners) {
        this.access = access;
        this.requests = requests;
        this.audit = audit;
        transaction = new org.springframework.transaction.support.TransactionTemplate(manager);
        transaction.setPropagationBehavior(
                org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(
                org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
        this.partners = partners;
    }

    /**
     * 复用原客户读准入，只接受调用方声明，不借员工目录BIND许可查询客户负责人。
     * @param input 例如organizationCandidateId=901/mode=DRY_RUN/sourceSystem=ERP/mappings=[]/transfers=[]
     * @return 例如success=true,data={typedImportBlocked:true,targetFactsVerified:false,pendingTransfers:[]}
     *     异常示例：匿名或经营范围未配置拒绝，无账号/客户/号段/台账写入。
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
     */
    @Override
    public CommonResult migrationAssociationPreflight(CommonParam input) {
        // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
        var scope = access.requirePartnerScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.read");
        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(
                com.sp.selplat.crm.common.util.migration.CrmUserAssociationPreflight.inspect(input.getParamMap(),
                        ((Number) scope.get("tenantId")).longValue(), ((Number) scope.get("businessOrgId")).longValue()));
    }

    /**
     * 实际分页与后端控件配置；写裁决失败显示只读，不开放正式权限。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     *     业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     * @return 公共结果，data包含真实分页和SELUI表单定义；synthetic明确为true
     */
    @Override
    @OperationLog
    public CommonResult workspace(CommonPageParam input) {
        CommonPageResult page = getStore(input);
        boolean writable = false;
        try {
            access.requirePartnerScope(
                    input.getParam("organizationCandidateId"), "crm.partner.write");
            writable = true;
        } catch (com.sp.selplat.common.exception.CommonBusinessException denied) {
            if (!"CRM_ACTION_FORBIDDEN".equals(denied.getErrorCode())) {
                throw denied;
            }
        }
        return com.sp.selplat.crm.common.util.authorization.CrmWorkspaceEvidence.decorate(
                com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport.build(
                        page, true, writable, input.getParam("lang")),
                access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read"), input.getParam("lang"));
    }

    /**
     * 分页本组织记录；参数例如org901/page1；返回公共分页；无真实read许可拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 公共真实分页，例如records包含本组织客户；不会退化为全库
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.read");
        var page =
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page(
                        input, scope, "contactNameLike");
        if (input.getParam("partnerId") != null) {
            page.putParam(
                    "partnerId",
                    com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive(
                            input.getParam("partnerId")));
        }
        var result = super.getStore(page);
        // 列表与详情沿用原精确文本合同，联系人及父客户主键不能变成近似数字。
        result.setRecords(result.getRecords().stream()
                .map(com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport::browserRecord)
                .toList());
        return result;
    }

    /**
     * 本组织详情；参数例如org901/id200000；返回公共data；不存在或越组织同样拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.read");
        var row =
                getDao().getById(
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "CRM_RECORD_NOT_FOUND");
        }
        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(
                com.sp.selplat.crm.common.util.partner.CrmPartnerWorkspaceSupport.browserRecord(
                        row));
    }

    /**
     * 未开放通用批量读取；参数例如空items；无成功返回；拒绝避免绕过组织许可。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 服务端审计人；无参数；返回真实账号例如9211；失效身份拒绝，不使用默认1。
     *
     * @return 真实当前操作员，例如9211；失效身份抛错
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 服务端租户；无参数；返回真实租户例如92；不使用客户端或默认租户。
     *
     * @return 真实当前租户，例如92；不使用默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 没有默认管理员；无参数；返回false；不增加任何权限。 业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     *
     * @return false；本域不隐式赋予管理员
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写入口关闭；参数例如id200000；无成功返回；维护只能经过具名保存事务。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 本表保存并同事务完成请求和业务审计，唯一冲突事务退出后才读取首次结果。
     *
     * @param input 完整业务参数，例如org901/keyk1/name示范，编辑含id200000/expectedVersion0
     * @return 公共结果，例如data={id:"200000",versionNo:"0",replay:false,synthetic:true}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可、旧版本、同键异内容或约束失败整笔回滚
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult save(CommonParam input) {
        // 先实际回查组织动作，不让非法输入在未授权时探测业务记录。
        access.requirePartnerScope(
                input == null ? null : input.getParam("organizationCandidateId"),
                "crm.partner.write");
        CommonParam normalized =
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.normalize(
                        input, true);
        String hash =
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
        CommonParam request = new CommonParam();
        request.putParam("organizationCandidateId", normalized.getParam("organizationCandidateId"));
        request.putParam("commandName", "CONTACT_SAVE");
        request.putParam("requestKey", normalized.getParam("requestKey"));
        request.putParam("payloadHash", hash);
        try {
            return access.executeTransaction(normalized.getParam("organizationCandidateId"), "crm.partner.write", transaction,
                    status -> {
                        var scope =
                                access.requirePartnerScope(
                                        normalized.getParam("organizationCandidateId"),
                                        "crm.partner.write");
                        Long requestId = requests.claim(request);
                        CommonParam parent = new CommonParam();
                        parent.putParam(
                                "organizationCandidateId",
                                normalized.getParam("organizationCandidateId"));
                        parent.putParam("id", normalized.getParam("partnerId"));
                        partners.lockForMaintenance(parent);
                        CommonParam row =
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .entity(normalized, scope);
                        Long prior = null;
                        long id;
                        long version;
                        if (normalized.getParam("id") == null) {
                            id = getSequence().get("id");
                            version = 0;
                            row.putParam("id", id);
                            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                                    getDao().insert(row));
                        } else {
                            id = (Long) normalized.getParam("id");
                            var existing =
                                    getDao().lockScoped(
                                                    com.sp.selplat.crm.common.util.partner
                                                            .CrmPartnerValueSupport.detail(
                                                            normalized, scope));
                            if (existing == null) {
                                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .failure("CRM_RECORD_NOT_FOUND");
                            }
                            prior = ((Number) existing.get("versionNo")).longValue();
                            if (prior.longValue() != (Long) normalized.getParam("expectedVersion")
                                    || prior == Long.MAX_VALUE) {
                                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .failure("STALE_CRM_VERSION");
                            }
                            row.putParam("actorUserId", scope.get("actorUserId"));
                            row.putParam("expectedVersion", prior);
                            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                                    getDao().updateVersion(row));
                            version = prior + 1;
                        }
                        // 提交前再次真实检查测试许可；将来公共许可撤销合同由owner提供，不声称两库ACID。
                        access.requirePartnerScope(
                                normalized.getParam("organizationCandidateId"),
                                "crm.partner.write");
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("id", Long.toString(id));
                        data.put("versionNo", Long.toString(version));
                        data.put("replay", false);
                        data.put("synthetic", scope.get("synthetic"));
                        request.putParam("id", requestId);
                        request.putParam("resultContactId", id);
                        request.putParam("resultVersionNo", version);
                        request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
                        requests.complete(request);
                        CommonParam event = new CommonParam();
                        event.putParam(
                                "organizationCandidateId",
                                normalized.getParam("organizationCandidateId"));
                        event.putParam("commandRequestId", requestId);
                        event.putParam("action", "CONTACT_SAVE");
                        event.putParam("resourceId", id);
                        event.putParam("previousVersion", prior);
                        event.putParam("newVersion", version);
                        audit.append(event);
                        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(
                                data);
                    });
        } catch (com.sp.selplat.common.exception.CommonBusinessException conflict) {
            if (!"CRM_COMMAND_EXISTS".equals(conflict.getErrorCode())) {
                throw conflict;
            }
            var stored = requests.committed(request);
            if (stored == null || !hash.equals(stored.get("payloadHash"))) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                        "CRM_COMMAND_CONFLICT");
            }
            if (!"COMPLETED".equals(stored.get("requestState"))) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                        "CRM_COMMAND_IN_PROGRESS");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> data =
                    JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
            data.put("replay", true);
            return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(data);
        }
    }

    /**
     * 本表同事务锁读；参数例如org901/id200000；返回真实行；缺许可/记录或无CRM事务拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求先遵守原身份/范围拒绝；例如匿名UNIAUTH_IDENTITY_REQUIRED，隔离范围已开启时缺候选INVALID_CRM_ID
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockForMaintenance(CommonParam input) {
        // 缺请求仍由原准入先核验真实身份和候选，不从账号推定组织。
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.partner.write");
        var row =
                getDao().lockScoped(
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .detail(input, scope));
        if (row == null) {
            throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "CRM_RECORD_NOT_FOUND");
        }
        return row;
    }
}
