/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.postingdetail.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmPostingDetailDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmPostingDetailDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 本域crmJdbcTemplate，例如明确测试CRM池；副作用示例：不执行跨库SQL或发号。
     */
    public CrmPostingDetailDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 同sortnum流水追加范围内唯一ID，确保库存工作区翻页不重复遗漏。
     *
     * @param conditions 已核验的范围及流水种类，例如tenant92/org901/effectKindSTOCK
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如20
     * @return 原真实公共分页，例如24条流水的第2页4条；只读且不改变金额数量
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 主排序保留；唯一ID仅打破平局，范围、COUNT与参数化查询仍由公共DAO执行。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingDetail WHERE tenantId=? AND businessOrgId=? AND"
                                + " id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 持锁稳定全量父行；固定本表事务扩展。
     *
     * @param input 例如org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public List<Map<String, Object>> readAll(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingDetail WHERE tenantId=? AND businessOrgId=? AND batchId=?"
                        + " AND status=1 ORDER BY id FOR UPDATE",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("batchId"));
    }

    /**
     * 方法作用：读取不可变完整账本历史，不提前锁原明细、不按人工status隐藏行。
     *
     * @param input 例如tenant92/org901/batch1200000
     * @return 实际全部明细按id升序；无写入，缺CRM事务拒绝，执行在Progress后另外逐行锁与比较。
     */
    @Override
    public List<Map<String, Object>> readHistory(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingDetail WHERE tenantId=? AND businessOrgId=? AND batchId=?"
                        + " ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("batchId"));
    }

    /**
     * 读取实际本表来源行原POST候选，不跨表查余额或构造可退额度。
     *
     * @param input tenant92/org901/sourceOrderLineId600001
     * @return 完整原POST列表例如[{id:1300000,quantityDelta:-3}]，无写入；缺本域事务拒绝
     */
    @Override
    public List<Map<String, Object>> findForSource(CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForList(
                "SELECT * FROM CrmPostingDetail WHERE tenantId=? AND businessOrgId=? "
                        + "AND sourceOrderLineId=? AND action='POST' ORDER BY id",
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("sourceOrderLineId"));
    }
}
