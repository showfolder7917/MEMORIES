/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.postingbatch.service;

import com.sp.selplat.common.util.CommonParam;
import java.util.List;
import java.util.Map;

/**
 * 本表owning服务，只读HTTP和具名CRM事务扩展。
 */
public interface CrmPostingBatchService extends com.sp.selplat.common.service.BaseService {

  /**
   * 精确本组织内部锁；缺实际许可或事务拒绝。
   *
   * @param input org901/id1000000
   * @param action 固定stock.post等动作
   * @return 真实范围行；不存在统一拒绝
   */
  Map<String, Object> lockScoped(CommonParam input, String action);

  /**
   * 真实POST批次插入；固定本表事务扩展。
   *
   * @param input org901/id1000000及实际服务器字段
   * @return 实际本表结果；缺范围/事务拒绝
   */
  Long append(CommonParam input);

  /**
   * Actual full frozen receipt batch insert, no stock-kind bypass.
   *
   * @param input actual org901/document1000000/version2/count2/hash
   * @return real batch ID e.g.1200000; mismatch or missing funds.post rejects
   */
  Long appendFunds(CommonParam input);

  /**
   * 方法作用：owning批次查询当前真实范围历史。
   *
   * @param input org901/document1000000
   * @param action crm.funds.read或reverse
   * @return 实际历史批次，不伪造有效标志 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  List<Map<String, Object>> findForDocument(CommonParam input, String action);

  /**
   * 方法作用：只新增绑定原批次的整批反向头，不更新原头。
   *
   * @param input 原批次1200000、document1000000、完整count2/hash
   * @return 新REVERSE批次id；重复原批次唯一约束拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  Long appendFundsReverse(CommonParam input);

  /**
   * 新增唯一完整库存反向头；例如原POST1200000返回新REVERSE1200001，原流水保留。
   *
   * @param input org901/实际原批次或明细及新反向批次
   * @return 新真实主键，重复或错范围全事务回滚
   */
  Long appendStockReverse(CommonParam input);

  /**
   * 方法作用：原资金拥有方带真实课程核对创建同一原现金批次，不把核对写入批次字段。
   * @param input 原org901/document100000/headerVersion2及实际冻结摘要
   * @param quotes 原资金取得的真实预留上限，例如100000对应18
   * @return 真实示例：原CrmPostingBatchId100000。
   * 异常或副作用示例：冻结或真实上限不符使原CRM事务整体回滚。
   */
  Long appendCourseFunds(
      com.sp.selplat.common.util.CommonParam input,
      java.util.Map<Long, java.util.Map<String, Object>> quotes);
}
