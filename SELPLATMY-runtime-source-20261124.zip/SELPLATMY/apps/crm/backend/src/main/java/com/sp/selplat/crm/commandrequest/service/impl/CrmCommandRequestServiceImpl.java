/**
 * CrmCommandRequestServiceImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex
 * 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
package com.sp.selplat.crm.commandrequest.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.commandrequest.dao.CrmCommandRequestDao;
import com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/** 本表直接复用公共CRUD/号段，HTTP只开放明确范围和版本命令；不自建权限系统。 */
@Service
public class CrmCommandRequestServiceImpl extends BaseServiceImpl<CrmCommandRequestDao>
        implements CrmCommandRequestService {
    // 真实Session和显式合成许可统一由本域准入检查，生产缺公共resolver时拒绝。
    private final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 绑定实际命令范围，构造不占用幂等键或发放权限。
     *
     * @param access 实际Session与本域组织动作准入，例如org901/actor9211
     */
    public CrmCommandRequestServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

    /**
     * 分页本组织记录；参数例如org901/page1；返回公共分页；无真实read许可拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 公共真实分页，例如records包含本组织客户；不会退化为全库
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.audit.read");
        return super.getStore(
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.page(
                        input, scope, null));
    }

    /**
     * 本组织详情；参数例如org901/id200000；返回公共data；不存在或越组织同样拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        var scope =
                access.requirePartnerScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.audit.read");
        var row =
                getDao().getById(
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                    "CRM_RECORD_NOT_FOUND");
        }
        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(row);
    }

    /**
     * 未开放通用批量读取；参数例如空items；无成功返回；拒绝避免绕过组织许可。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 服务端审计人；无参数；返回真实账号例如9211；失效身份拒绝，不使用默认1。
     *
     * @return 真实当前操作员，例如9211；失效身份抛错
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 服务端租户；无参数；返回真实租户例如92；不使用客户端或默认租户。
     *
     * @return 真实当前租户，例如92；不使用默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 没有默认管理员；无参数；返回false；不增加任何权限。 业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     *
     * @return false；本域不隐式赋予管理员
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写入口关闭；参数例如id200000；无成功返回；维护只能经过具名保存事务。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                "CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 请求claim；参数例如org901/namePARTNER_SAVE/keyk1/hash；返回真实请求id；仅唯一错误转重放信号。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Long claim(CommonParam input) {
        var scope =
                access.requireBusinessScope(
                        input.getParam("organizationCandidateId"),
                        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.commandAction(
                                input.getParam("commandName")));
        CommonParam row = new CommonParam();
        row.putParam("commandName", input.getParam("commandName"));
        row.putParam("requestKey", input.getParam("requestKey"));
        row.putParam("payloadHash", input.getParam("payloadHash"));
        row.putParam("requestState", "OPEN");
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("requestKey", input.getParam("requestKey"));
        Long id = getSequence().get("id");
        row.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                    getDao().insert(row));
        } catch (org.springframework.dao.DuplicateKeyException conflict) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "CRM_COMMAND_EXISTS", "请求已存在，先退出当前事务。", conflict);
        }
        return id;
    }

    /**
     * 完成同事务首次结果；参数例如requestid200000/resultPartnerId200000；无返回；0行或约束异常回滚。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public void complete(CommonParam input) {
        var scope =
                access.requireBusinessScope(
                        input.getParam("organizationCandidateId"),
                        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.commandAction(
                                input.getParam("commandName")));
        CommonParam row = new CommonParam();
        row.setParamMap(input.getParamMap());
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                getDao().complete(row));
    }

    /**
     * 失败事务退出后读取已提交请求；参数例如org901/namePARTNER_SAVE/keyk1；返回真实请求或null；不写库。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.REQUIRES_NEW,
            readOnly = true)
    public Map<String, Object> committed(CommonParam input) {
        var scope =
                access.requireBusinessScope(
                        input.getParam("organizationCandidateId"),
                        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.commandAction(
                                input.getParam("commandName")));
        CommonParam row = new CommonParam();
        row.setParamMap(input.getParamMap());
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        return getDao().findRequest(row);
    }
}
