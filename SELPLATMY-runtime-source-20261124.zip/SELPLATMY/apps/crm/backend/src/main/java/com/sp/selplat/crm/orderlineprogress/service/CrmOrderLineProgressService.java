/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.orderlineprogress.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmOrderLineProgressService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定stock.post等动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);

    /**
     * 真实来源累计锁/首次初始化。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @param source 真实锁定审核来源行，例如id600001/quantity3/approvedDueMinor5
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    Map<String, Object> lockForLine(CommonParam input, Map<String, Object> source);

    /**
     * 来源履约CAS。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2 副作用示例：无返回；超累计量或旧版本全回滚
     */
    void applyIssue(CommonParam input);

    /**
     * Frozen source capacity consumed with a fixed owning action.
     *
     * @param input org901
     * @param source actual locked approved source600000
     * @param action stock.post or funds.post
     * @return actual scoped progress; mismatching frozen amounts reject
     */
    Map<String, Object> lockForLine(CommonParam input, Map<String, Object> source, String action);

    /**
     * Exact settled amount CAS in the complete posting transaction.
     *
     * @param input actual progress id/version/amountMinor68 副作用示例：void；撤权或容量溢出拒绝所有效果。
     */
    void applyReceipt(CommonParam input);

    /**
     * Actual receipt cumulative query without creating any progress row.
     *
     * @param input org901/sourceOrderLineId600000
     * @return actual row or null when no POST yet; funds.read required
     */
    Map<String, Object> readFundsForLine(CommonParam input);

    /**
     * 读取真实来源库存进度，不创建记录或发号。
     *
     * @param input org901/sourceOrderLineId600001，候选组织由真实Session重核
     * @return 实际I/T/版本行或null，例如I3/T1；副作用示例：只读，不改变原履约额度。
     */
    Map<String, Object> readStockForLine(CommonParam input);

    /**
     * 在已有原销售订单锁下，仅定位真实末退货父节点，不提前锁Progress。
     *
     * @param input org901/sourceOrderLineId600001
     * @param action 固定stock.post动作，真实当前授权重新检查
     * @return 原行或null，例如T1/lastReturnDetailId1300002；副作用示例：不占容量或写进度，后续实际Progress锁重核。
     */
    Map<String, Object> peekReturnParent(CommonParam input, String action);

    /**
     * 方法作用：重核真实权限并按来源行减少R，不改订单审批。
     *
     * @param input org901/id1400000/version1/amount68 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    void reverseReceipt(CommonParam input);

    /**
     * 更新实际退货T和末节点，原履约I不减。
     *
     * @param input org901/id1400000/version1/quantity1/lastReturnDetailId1300002
     *     副作用示例：T0→1、末节点1300002；跨来源节点、超额或CAS0整批回滚。
     */
    void applyReturn(CommonParam input);

    /**
     * 更新实际商品退款F，原收款R不减。
     *
     * @param input org901/id1400000/version2/amountMinor1 副作用示例：F0→1；超真实R/E(T)或CAS0整笔退款回滚。
     */
    void applyRefund(CommonParam input);

    /**
     * 方法作用：原资金事务内提交已核课程退款累计，不等同于执行现金。
     * @param input 原org901/id100000/version1/amountMinor18/maximumCumulativeMinor18
     * 异常或副作用示例：当前funds.post、实际来源或CAS不足拒绝，整个CRM事务回滚。
     */
    void applyCourseRefund(CommonParam input);


    /**
     * 完整退款冲正减少F；例如F2→0，R5保持，旧版本整笔回滚。
     *
     * @param input org901/id1400000/version3/amountMinor2，当前真实funds.reverse许可
     */
    void reverseRefund(CommonParam input);

    /**
     * 完整库存冲正减少I；例如I3/T0→I0，当前真实stock.reverse，旧版本回滚。
     *
     * @param input org901/id1400000/version3/quantity3
     */
    void reverseIssue(CommonParam input);

    /**
     * 最新完整退货冲正减少T并回退末节点；例如T3→2/前批节点1300001，I3保持。
     *
     * @param input org901/id1400000/version3/quantity1/previousReturnDetailId1300001
     */
    void reverseReturn(CommonParam input);
}
