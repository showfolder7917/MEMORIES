/** CrmPostingService.java：真实登录后的无写入预检契约。 修改记录：2026-10-03，Codex 按委托提供独立可验证的状态预览。 */
package com.sp.selplat.crm.capability.posting.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 提供预检与隔离动作，不继承 CRUD，不持有表或授予业务动作权限。 */
public interface CrmPostingService {
    /**
     * 检查登录后提交的假设快照；输入不是数据库事实。
     *
     * @param input 公共参数，例如 {kind:SALES_ORDER,state:DRAFT,action:SUBMIT}
     * @return CommonResult，例如
     *     {success:true,data:{to:SUBMITTED,writeEnabled:false,factsVerified:false}}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 身份或预检失败拒绝；不写记录
     */
    CommonResult preview(CommonParam input);

    /**
     * 执行隔离开发过账；输入例如{id:102,action:POST,requestKey:r1,expectedVersion:0}；返回真实提交/重放；生产拒绝。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：执行隔离开发过账；输入例如{id:102,action:POST,requestKey:r1,expectedVersion:0}；返回真实提交/重放；生产拒绝。
     * @return 真实提交/重放
     */
    CommonResult execute(CommonParam input);
}
