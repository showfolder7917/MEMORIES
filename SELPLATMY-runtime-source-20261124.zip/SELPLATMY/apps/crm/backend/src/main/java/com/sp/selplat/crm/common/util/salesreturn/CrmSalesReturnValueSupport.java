/** 一期销售退货退款权益计算；2026-10-04，Codex；冻结商品净额，费用不退。 */
package com.sp.selplat.crm.common.util.salesreturn;

import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;

/** 只计算已核真实冻结进度权益；不读写账本，不改变定价或退款策略。 */
public final class CrmSalesReturnValueSupport {
    /** 禁止实例化无状态权益工具；不创建退款许可或余额。 */
    private CrmSalesReturnValueSupport() {
        // 公式仅静态消费真实冻结字段，不携带可变业务状态。
    }

    /**
     * 按累计T求floor(goodsNet*T/Q)，避免逐件舍入超退；接续商品权益恒0。
     *
     * @param progress 真实锁定进度，例如Q3/refundableGoodsMinor1/GOODS_ONLY_V1
     * @param returned 实际累计退货EA，例如1、2、3
     * @return BigDecimal精确整数，示例T1/2/3分别0/0/1；fee2不进入计算
     */
    public static BigDecimal entitlement(Map<String, Object> progress, long returned) {
        long q = ((Number) progress.get("authorizedQuantity")).longValue();
        var goods =
                new BigDecimal(progress.get("refundableGoodsMinor").toString()).toBigIntegerExact();
        String policy = String.valueOf(progress.get("refundPolicyVersion"));
        if (q <= 0
                || returned < 0
                || returned > q
                || goods.signum() < 0
                || !("GOODS_ONLY_V1".equals(policy) || "CONTINUATION_NO_REFUND_V1".equals(policy))
                || ("CONTINUATION_NO_REFUND_V1".equals(policy) && goods.signum() != 0)) {
            throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
        }
        // 大整数先乘后整除 -> 累计权益0/0/1而不是每件独立四舍五入1/1/1。
        return new BigDecimal(
                goods.multiply(BigInteger.valueOf(returned)).divide(BigInteger.valueOf(q)));
    }
}
