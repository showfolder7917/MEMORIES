/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.documentline.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmDocumentLineDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 稳定全量父行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     */
    List<Map<String, Object>> readAll(CommonParam input);

    /**
     * 仅DRAFT整组行替换删除；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @return 实际影响行数，未来FK不允许删除时全部回滚
     */
    int deleteAll(CommonParam input);

    /**
     * 方法作用：读取所有实际原收款明细引用，status不能关闭依赖。
     *
     * @param input tenant92/org901/parent1300000
     * @return 真实关联行或空列表 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    List<Map<String, Object>> receiptChildren(CommonParam input);
}
