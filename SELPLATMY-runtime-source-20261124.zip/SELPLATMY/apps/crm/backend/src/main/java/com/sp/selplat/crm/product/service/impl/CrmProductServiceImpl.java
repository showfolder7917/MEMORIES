/** CrmProduct：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
/* 修改记录：2026-10-09，Codex；缺请求先沿原真实身份与组织候选拒绝，避免空指针，不扩大许可。 */
package com.sp.selplat.crm.product.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.migration.CrmProductMigrationPreflight;
import com.sp.selplat.crm.product.dao.CrmProductDao;
import com.sp.selplat.crm.common.util.product.CrmProductValueSupport;
import java.util.LinkedHashMap;
import com.sp.selplat.crm.product.service.CrmProductService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

/** 本表直接复用公共CRUD、公共号段；只有具名命令可写，默认生产拒绝。 */
@Service
public class CrmProductServiceImpl extends BaseServiceImpl<CrmProductDao>
        implements CrmProductService {
    // 每次从真实Session和隔离许可表核范围，不消费客户端tenant/actor。
    private final CrmAccessService access;
    // 商品、首次回执和审计使用同一CRM事务，不触发付款或激活。
    private final com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests;
    private final com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit;
    private final org.springframework.transaction.support.TransactionTemplate transaction;

    /**
     * 装配实际范围服务；构造不授权或写库。
     *
     * @param access 实际统一Session范围入口；例如组织901，不授予许可
     * @param requests 命令回执服务，例如PRODUCT_SAVE/p1
     * @param audit 审计服务，例如actor9211/version0
     * @param manager CRM事务管理器；构造仅保留依赖，不创建商品
     */
    public CrmProductServiceImpl(CrmAccessService access,
            com.sp.selplat.crm.commandrequest.service.CrmCommandRequestService requests,
            com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService audit,
            @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
            org.springframework.transaction.PlatformTransactionManager manager) {
        this.access = access; this.requests = requests; this.audit = audit;
        transaction = new org.springframework.transaction.support.TransactionTemplate(manager);
        transaction.setPropagationBehavior(org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 复用现有crm.order.read准入，只处理调用方声明原词法值，不查询或修改产品数据。
     *
     * @param input 声明候选，例如{organizationCandidateId=901,mode=DRY_RUN,sourceSystem=ERP,records=[]}
     * @return 公共报告，例如{success=true,data={writeEnabled=false,typedImportBlocked=true,archivePersistence=NOT_IMPLEMENTED}}
     *     异常或副作用示例：默认生产范围关闭仍拒绝；没有新动作授权、台账/ID/库存/金额写入。
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
     */
    @Override
    public CommonResult migrationPreflight(CommonParam input) {
        // 只沿用现有读准入，不新增synthetic许可事实或权限Provider，也不绕过生产默认关闭。
        // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
        access.requireOrderScope(
                input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        return CrmPartnerValueSupport.result(CrmProductMigrationPreflight.inspect(input.getParamMap()));
    }

    /**
     * 标准范围分页；org901/page1；委托公共DAO，缺范围拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，限定本组织/status1；商品选择另限定ACTIVE
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
        var scope =
                access.requireOrderScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var page = CrmPartnerValueSupport.page(input, scope, null);
        page.putParam("businessState", "ACTIVE");
        var result = super.getStore(page);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        return result;
    }

    /**
     * 范围详情；org901/id600000；无记录统一拒绝，避免跨组织探测。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/全部行或product701；拒绝不存在/越范围
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
        var scope =
                access.requireOrderScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.browser(row));
    }

    /**
     * 批量未开放；空items也拒绝，不退化为全库。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 实际操作员，例如9211；无身份拒绝。
     *
     * @return 真实账号Long，例如9211；无身份拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 实际租户，例如92；无默认1。
     *
     * @return 真实租户Long，例如92；无默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 不隐式扩权；始终false。 业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     *
     * @return false；不隐式扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写拒绝；id600000；只能具名事务命令。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 商品维护范围分页，包含停用商品，不改变订单选择读取合同。
     * @param input 候选org901/page1/productNameLike教材；身份由服务核验
     * @return 实际示例：records含商品700000、totalCount1的公共分页
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺商品读取许可或非法筛选拒绝
     */
    @Override
    public CommonPageResult managementStore(CommonPageParam input) {
        var scope = access.requireBusinessScope(input == null ? null : input.getParam("organizationCandidateId"), "crm.product.read");
        var page = CrmPartnerValueSupport.page(input, scope, null);
        // 空白搜索代表无条件，不能把null作为SQL的LIKE值。
        String keyword = CrmPartnerValueSupport.text(input.getParam("productNameLike"), 200, false);
        if (keyword != null) { page.putParam("productNameLike", keyword); }
        // 筛选值只允许固定枚举，COUNT和读取消费同一可信条件。
        for (String field : java.util.List.of("businessState", "productKind")) {
            Object value = input.getParam(field);
            if (value != null && !"".equals(value)) {
                var allowed = field.equals("businessState") ? java.util.Set.of("ACTIVE", "INACTIVE") : java.util.Set.of("GOODS", "SERVICE");
                if (!allowed.contains(value)) { throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT"); }
                page.putParam(field, value);
            }
        }
        var result = super.getStore(page);
        result.setRecords(result.getRecords().stream().map(CrmProductValueSupport::browser).toList());
        return result;
    }

    /**
     * 商品维护详情独立核权，不将订单读取许可升级为维护权限。
     * @param input 候选org901/id700000
     * @return 实际示例：success=true/data含productCode和versionNo字符串
     * @throws com.sp.selplat.common.exception.CommonBusinessException 不存在、跨组织或缺资格拒绝
     */
    @Override
    public CommonResult detail(CommonParam input) {
        var scope = access.requireBusinessScope(input == null ? null : input.getParam("organizationCandidateId"), "crm.product.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) { throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND"); }
        return CrmPartnerValueSupport.result(CrmProductValueSupport.browser(row));
    }

    /**
     * 返回真实商品分页及公共控件定义，不伪造支付或开通状态。
     * @param input 候选org901/langzh-CN/page1
     * @return 实际示例：data含grid、form、writeEnabled=false或true
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺读取许可拒绝；仅明确写动作不足可降只读
     */
    @Override
    public CommonResult workspace(CommonPageParam input) {
        var page = managementStore(input);
        boolean writable = false;
        try { access.requireBusinessScope(input.getParam("organizationCandidateId"), "crm.product.write"); writable = true; }
        catch (com.sp.selplat.common.exception.CommonBusinessException denied) {
            if (!"CRM_ACTION_FORBIDDEN".equals(denied.getErrorCode())) { throw denied; }
        }
        return com.sp.selplat.crm.common.util.authorization.CrmWorkspaceEvidence.decorate(
                com.sp.selplat.crm.common.util.product.CrmProductWorkspaceSupport.build(page, writable, input.getParam("lang")),
                access.requireBusinessScope(input.getParam("organizationCandidateId"), "crm.product.read"), input.getParam("lang"));
    }

    /**
     * 本表保存并同事务完成请求和业务审计，唯一冲突事务退出后才读取首次结果。
     *
     * @param input 完整业务参数，例如org901/keyp1/productCodeBOOK-001，编辑含id700000/expectedVersion0
     * @return 公共结果，例如data={id:"200000",versionNo:"0",replay:false,synthetic:true}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可、旧版本、同键异内容或约束失败整笔回滚
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.NOT_SUPPORTED)
    public CommonResult save(CommonParam input) {
        // 先实际回查组织动作，不让非法输入在未授权时探测业务记录。
        access.requirePartnerScope(
                input == null ? null : input.getParam("organizationCandidateId"),
                "crm.product.write");
        CommonParam normalized =
                CrmProductValueSupport.normalize(input);
        String hash =
                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
        CommonParam request = new CommonParam();
        request.putParam("organizationCandidateId", normalized.getParam("organizationCandidateId"));
        request.putParam("commandName", "PRODUCT_SAVE");
        request.putParam("requestKey", normalized.getParam("requestKey"));
        request.putParam("payloadHash", hash);
        try {
            return access.executeTransaction(normalized.getParam("organizationCandidateId"), "crm.product.write", transaction,
                    status -> {
                        var scope =
                                access.requirePartnerScope(
                                        normalized.getParam("organizationCandidateId"),
                                        "crm.product.write");
                        Long requestId = requests.claim(request);
                        CommonParam row =
                                com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .entity(normalized, scope);
                        Long prior = null;
                        long id;
                        long version;
                        if (normalized.getParam("id") == null) {
                            id = getSequence().get("id");
                            version = 0;
                            row.putParam("id", id);
                            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                                    getDao().insert(row));
                        } else {
                            id = (Long) normalized.getParam("id");
                            var existing =
                                    getDao().lockScoped(
                                                    com.sp.selplat.crm.common.util.partner
                                                            .CrmPartnerValueSupport.detail(
                                                            normalized, scope));
                            if (existing == null) {
                                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .failure("CRM_RECORD_NOT_FOUND");
                            }
                            // 类型/单位创建后固定；避免把已有实物改成服务而破坏库存来源。
                            if (!existing.get("productKind").equals(normalized.getParam("productKind"))
                                    || !existing.get("unitCode").equals(normalized.getParam("unitCode"))) {
                                throw CrmPartnerValueSupport.failure("CRM_PRODUCT_KIND_IMMUTABLE");
                            }
                            prior = ((Number) existing.get("versionNo")).longValue();
                            if (prior.longValue() != (Long) normalized.getParam("expectedVersion")
                                    || prior == Long.MAX_VALUE) {
                                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport
                                        .failure("STALE_CRM_VERSION");
                            }
                            row.putParam("actorUserId", scope.get("actorUserId"));
                            row.putParam("expectedVersion", prior);
                            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                                    getDao().updateVersion(row));
                            version = prior + 1;
                        }
                        // 提交前再次真实检查测试许可；将来公共许可撤销合同由owner提供，不声称两库ACID。
                        access.requirePartnerScope(
                                normalized.getParam("organizationCandidateId"),
                                "crm.product.write");
                        Map<String, Object> data = new LinkedHashMap<>();
                        data.put("id", Long.toString(id));
                        data.put("versionNo", Long.toString(version));
                        data.put("replay", false);
                        data.put("synthetic", scope.get("synthetic"));
                        request.putParam("id", requestId);
                        request.putParam("resultProductId", id);
                        request.putParam("resultVersionNo", version);
                        request.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
                        requests.complete(request);
                        CommonParam event = new CommonParam();
                        event.putParam(
                                "organizationCandidateId",
                                normalized.getParam("organizationCandidateId"));
                        event.putParam("commandRequestId", requestId);
                        event.putParam("action", "PRODUCT_SAVE");
                        event.putParam("resourceId", id);
                        event.putParam("previousVersion", prior);
                        event.putParam("newVersion", version);
                        audit.append(event);
                        return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(
                                data);
                    });
        } catch (org.springframework.dao.DuplicateKeyException duplicate) {
            throw new com.sp.selplat.common.exception.CommonBusinessException("CRM_PRODUCT_CODE_EXISTS", "商品编码已存在。", duplicate);
        } catch (com.sp.selplat.common.exception.CommonBusinessException conflict) {
            if (!"CRM_COMMAND_EXISTS".equals(conflict.getErrorCode())) {
                throw conflict;
            }
            var stored = requests.committed(request);
            if (stored == null || !hash.equals(stored.get("payloadHash"))) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                        "CRM_COMMAND_CONFLICT");
            }
            if (!"COMPLETED".equals(stored.get("requestState"))) {
                throw com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure(
                        "CRM_COMMAND_IN_PROGRESS");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> data =
                    JsonUtils.fromJson((String) stored.get("responseSnapshot"), Map.class);
            data.put("replay", true);
            return com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.result(data);
        }
    }

    /**
     * 实际商品引用锁，缺ACTIVE/EA引用拒绝；不自造商品事实。
     *
     * @param input 复合范围及商品ID，例如org901/id701
     * @param action 固定订单动作，例如crm.order.approve
     * @return 本组织真实商品行，不跨表DAO，不授予写许可
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     缺请求仍先核验真实身份；匿名UNIAUTH_IDENTITY_REQUIRED，已登录缺组织候选INVALID_CRM_ID，无数据写入
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockForOrder(CommonParam input, String action) {
        // 缺请求沿原准入核验身份和候选，不先解引用或从登录推定组织。
        var scope = access.requireBusinessScope(
                input == null ? null : input.getParam("organizationCandidateId"), action);
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null
                || (action.startsWith("crm.stock.") ? !"GOODS".equals(row.getOrDefault("productKind", "GOODS"))
                        : !"ACTIVE".equals(row.get("businessState")))
                || !"EA".equals(row.get("unitCode"))) {
            throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
        }
        return row;
    }
}
