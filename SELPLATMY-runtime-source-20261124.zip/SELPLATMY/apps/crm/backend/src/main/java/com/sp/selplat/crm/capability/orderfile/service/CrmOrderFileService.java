/** CRM 订单文件引用核验能力；2026-10-04，Codex；非 CRUD、非附件关联账本。 */
package com.sp.selplat.crm.capability.orderfile.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 当前订单范围与当前上传者文件概要的只读交集；不扩大跨用户文件权限。 */
public interface CrmOrderFileService {
    /**
     * 方法作用：以真实订单读写许可和同Host Session检查候选fileId，不创建关联。
     *
     * @param input
     *     业务候选，例如organizationCandidateId=901/id=600000/expectedVersion=0及fileId、sha256、byteSize=3
     * @return
     *     公共结果，例如success=true/data.bindingWritten=false、orderId=600000及核对后的fileId、sha256、byteSize
     *     异常或副作用示例：缺订单许可、默认关闭、他人文件或订单版本改变拒绝；不写金额、数量或审计账本。
     */
    CommonResult verify(CommonParam input);
    /**
     * 方法作用：在订单读许可内消费真实文件共享概要；所有者仅定位资源，不代理其身份。
     * @param input owning附件服务提供的org901/order600000/当前版本及已存ownerUserId/fileId/sha256/byteSize
     * @return 真实返回示例：核对后的ownerUserId=9211和不可变三元组，未写任何关联。
     * 异常或副作用示例：当前接收人无独立VIEW_METADATA许可或撤权时拒绝；不授予READ_BODY。
     */
    CommonResult readSharedReference(CommonParam input);

}
