/** CrmOrderLine：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.orderline.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.orderline.dao.CrmOrderLineDao;
import com.sp.selplat.crm.orderline.service.CrmOrderLineService;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** 本表直接复用公共CRUD、公共号段；只有具名命令可写，默认生产拒绝。 */
@Service
public class CrmOrderLineServiceImpl extends BaseServiceImpl<CrmOrderLineDao>
        implements CrmOrderLineService {
    // 每次从真实Session和隔离许可表核范围，不消费客户端tenant/actor。
    private final CrmAccessService access;
    // 延迟取得真实订单owning服务避免构造循环；行写前仍必须回查DRAFT头，不自查跨表DAO。
    private final org.springframework.beans.factory.ObjectProvider<
                    com.sp.selplat.crm.order.service.CrmOrderService>
            orders;

    /**
     * 装配真实范围与延迟订单引用，避免构造循环而不跳过DRAFT校验。
     *
     * @param access 实际Session及组织动作准入，例如tenant92/actor9211/org901
     * @param orders 实际Spring ObjectProvider，写行前获取order600000的owning DRAFT头
     */
    public CrmOrderLineServiceImpl(
            CrmAccessService access,
            org.springframework.beans.factory.ObjectProvider<
                            com.sp.selplat.crm.order.service.CrmOrderService>
                    orders) {
        this.access = access;
        this.orders = orders;
    }

    /**
     * 标准范围分页；org901/page1；委托公共DAO，缺范围拒绝。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共实际分页，限定本组织/status1；商品选择另限定ACTIVE
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var page = CrmPartnerValueSupport.page(input, scope, null);
        if (input.getParam("orderId") != null) {
            page.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        }
        var result = super.getStore(page);
        result.setRecords(
                result.getRecords().stream()
                        .map(com.sp.selplat.crm.common.util.order.CrmOrderValueSupport::browser)
                        .toList());
        return result;
    }

    /**
     * 范围详情；org901/id600000；无记录统一拒绝，避免跨组织探测。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 公共真实范围详情，例如order600000/全部行或product701；拒绝不存在/越范围
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
    // 空请求仍按原身份与组织校验拒绝，不推导默认经营组织。
    var scope =
        access.requireOrderScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.order.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(
                com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.browser(row));
    }

    /**
     * 批量未开放；空items也拒绝，不退化为全库。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 实际操作员，例如9211；无身份拒绝。
     *
     * @return 真实账号Long，例如9211；无身份拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 实际租户，例如92；无默认1。
     *
     * @return 真实租户Long，例如92；无默认租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 不隐式扩权；始终false。 业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     *
     * @return false；不隐式扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用无版本写拒绝；id600000；只能具名事务命令。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * 真实全量行读取，稳定行号；跨表调用只经过owning Service。
     *
     * @param input 候选org901/orderId600000
     * @param action 固定订单动作，例如crm.order.read或crm.order.approve
     * @return 实际全部行，不静默截断；无scope拒绝
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", readOnly = true)
    public List<Map<String, Object>> readForOrder(CommonParam input, String action) {
        var scope = access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        var rows = new ArrayList<>(getDao().lockOrderLines(p));
        rows.sort(Comparator.comparingInt(row -> ((Number) row.get("lineNo")).intValue()));
        return rows;
    }

    /**
     * 持有DRAFT头锁后完整替换；保留现有行ID/创建人/创建时间，新行取公共号段。
     *
     * @param input org901/orderId600000及已由订单服务定价、商品服务验证的全部行
     * @return 全部实际持久化行；第N行约束/FK失败回滚整笔头行和请求，不部分成功
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public List<Map<String, Object>> replaceDraft(CommonParam input) {
        orders.getObject().requireDraftForLines(input);
        var scope =
                access.requireOrderScope(
                        input.getParam("organizationCandidateId"), "crm.order.write");
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("orderId", CrmPartnerValueSupport.positive(input.getParam("orderId")));
        var existing = getDao().lockOrderLines(p);
        var byId = new HashMap<Long, Map<String, Object>>();
        for (var row : existing) {
            byId.put(((Number) row.get("id")).longValue(), row);
        }
        if (!(input.getParam("lines") instanceof List<?> all)
                || all.isEmpty()
                || all.size() > 1000) {
            throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_LIMIT");
        }
        Set<Long> seen = new HashSet<>();
        for (var item : all) {
            if (!(item instanceof Map<?, ?> line)) {
                throw CrmPartnerValueSupport.failure("INVALID_CRM_ORDER_INPUT");
            }
            Object id = line.get("lineId");
            if (id != null
                    && (!byId.containsKey(CrmPartnerValueSupport.positive(id))
                            || !seen.add(CrmPartnerValueSupport.positive(id)))) {
                throw CrmPartnerValueSupport.failure("CRM_ORDER_LINE_SCOPE_MISMATCH");
            }
        }
        // 仅DRAFT并受头锁保护的全量替换：行号交换不会撞唯一键；任何现有下游FK失败保留旧内容整笔回滚。
        for (var row : existing) {
            p.putParam("id", row.get("id"));
            CrmPartnerValueSupport.changed(getDao().deleteLine(p));
        }
        for (var item : all) {
            @SuppressWarnings("unchecked")
            Map<String, Object> line = (Map<String, Object>) item;
            var row = new CommonParam();
            for (String field :
                    List.of("productNameSnapshot", "unitCode", "isGift", "refundPolicyVersion")) {
                row.putParam(field, line.get(field));
            }
            for (String field : List.of("lineNo", "discountBps", "currencyScale")) {
                row.putParam(field, Integer.parseInt(line.get(field).toString()));
            }
            for (String field : List.of("productId", "quantity")) {
                row.putParam(field, CrmPartnerValueSupport.positive(line.get(field)));
            }
            for (String field :
                    com.sp.selplat.crm.common.util.order.CrmOrderValueSupport.LINE_MONEY) {
                row.putParam(field, new java.math.BigDecimal(line.get(field).toString()));
            }
            row.putParam("orderId", p.getParam("orderId"));
            row = CrmPartnerValueSupport.entity(row, scope);
            row.getParamMap().remove("versionNo");
            long id =
                    line.get("lineId") == null
                            ? getSequence().get("id")
                            : CrmPartnerValueSupport.positive(line.get("lineId"));
            row.putParam("id", id);
            if (byId.containsKey(id)) {
                row.putParam("createdByUserId", byId.get(id).get("createdByUserId"));
                row.putParam("createdAt", byId.get(id).get("createdAt"));
            }
            CrmPartnerValueSupport.changed(getDao().insert(row));
        }
        return readForOrder(input, "crm.order.write");
    }

  /**
   * 方法作用：按原订单读取资格限定本页订单商品快照与数量，读取前后重核真实范围。
   *
   * @param organizationCandidateId 明确组织候选，例如901
   * @param ids 调用方当前页主键，例如[600000]，不超过100项
   * @return 真实示例：本组织安全字段集合；空集合返回空，不读取全表
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格变化、主键非法或超页上限时拒绝
   */
  @Override
  @OperationLog
  public java.util.List<java.util.Map<String, Object>> orderListItems(
      Object organizationCandidateId, java.util.List<Long> ids) {
    var scope = access.requireOrderScope(organizationCandidateId, "crm.order.read");
    if (ids == null || ids.size() > 100) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
    }
    var selected = ids.stream().map(CrmPartnerValueSupport::positive).distinct().toList();
    // 仅本表DAO读取；原客户独立状态与历史订单商品快照不被重新解释为当前候选。
    var rows =
        getDao()
            .orderListItems(
                ((Number) scope.get("tenantId")).longValue(),
                ((Number) scope.get("businessOrgId")).longValue(),
                selected);
    if (!scope.equals(access.requireOrderScope(organizationCandidateId, "crm.order.read"))) {
      throw CrmPartnerValueSupport.failure("CRM_ACTION_FORBIDDEN");
    }
    return rows;
  }
}
