/** CrmPartnerValueSupport.java：客户维护严格参数、精确版本和请求内容摘要。 修改记录：2026-10-03，Codex 实现无状态工具，不持有权限或数据库对象。 */
/* 修改记录：2026-10-27，首次客户分类与原客户创建同事务提交；教学按稳定分类编号调用，已有分类独立维护。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.common.util.partner;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/** 无状态公共参数辅助，只消费服务已经回查的scope；不自行授予组织权限。 */
public final class CrmPartnerValueSupport {
    /** 静态值规范或实际页面配置工具，构造不连接数据库、创建业务记录或授予权限。 */
    private CrmPartnerValueSupport() {
        // 只提供静态工具，禁止持有会话或业务状态。
    }

    /**
     * 解析正数主键候选；参数例如"901"；返回901L；非法或溢出拒绝，不访问数据。
     *
     * @param value 候选值，例如主键文本"901"或版本文本"0"
     * @return 正数long主键，例如901；非法值抛错
     */
    public static long positive(Object value) {
        try {
            String text = String.valueOf(value);
            if (!text.matches("[1-9][0-9]{0,18}")) {
                throw failure("INVALID_CRM_ID");
            }
            return Long.parseLong(text);
        } catch (NumberFormatException error) {
            throw failure("INVALID_CRM_ID");
        }
    }

    /**
     * 解析版本；参数例如"0"；返回0L；负数、小数或溢出拒绝。
     *
     * @param value 候选值，例如主键文本"901"或版本文本"0"
     * @return 非负long版本，例如0；非法值抛错
     */
    public static long version(Object value) {
        try {
            String text = String.valueOf(value);
            if (!text.matches("0|[1-9][0-9]{0,18}")) {
                throw failure("INVALID_CRM_VERSION");
            }
            return Long.parseLong(text);
        } catch (NumberFormatException error) {
            throw failure("INVALID_CRM_VERSION");
        }
    }

    /**
     * 限定文本；参数例如姓名"示范客户"/上限200/必填true；返回规范文本；空白或超长拒绝。
     *
     * @param value 候选值，例如主键文本"901"或版本文本"0"
     * @param maximum 最大字符数，例如200
     * @param required 是否必填，例如姓名为true、电话为false
     * @return 规范文本或允许的null，例如合成客户
     */
    public static String text(Object value, int maximum, boolean required) {
        if (value == null) {
            if (required) {
                throw failure("INVALID_CRM_INPUT");
            }
            return null;
        }
        if (!(value instanceof String raw)) {
            throw failure("INVALID_CRM_INPUT");
        }
        String text = raw.strip();
        if (text.length() > maximum || (required && text.isEmpty())) {
            throw failure("INVALID_CRM_INPUT");
        }
        return text.isEmpty() ? null : text;
    }

    /**
     * 规范完整客户/联系人保存；输入例如org901/keyk1/name示范；返回新CommonParam；未知可信字段拒绝。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @param contact 是否为联系人维护，例如true时要求partnerId=200000
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonParam normalize(CommonParam input, boolean contact) {
        if (input == null) {
            throw failure("INVALID_CRM_INPUT");
        }
        Set<String> allowed =
                new HashSet<>(
                        List.of(
                                "organizationCandidateId",
                                "id",
                                "expectedVersion",
                                "requestKey",
                                "businessState",
                                "mobile"));
        allowed.addAll(
                contact
                        ? List.of("partnerId", "contactName", "organizationText")
                        : List.of(
                                "partnerKind",
                                "partnerName",
                                "customerRole",
                                "supplierRole",
                                "initialCustomerTypeIdsJson",
                                "receiverName",
                                "address",
                                "email"));
        if (!allowed.containsAll(input.getParamMap().keySet())) {
            throw failure("INVALID_CRM_INPUT");
        }
        CommonParam p = new CommonParam();
        p.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
        String key = text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) {
            throw failure("INVALID_CRM_INPUT");
        }
        p.putParam("requestKey", key);
        Object id = input.getParam("id");
        if (id != null) {
            p.putParam("id", positive(id));
            p.putParam("expectedVersion", version(input.getParam("expectedVersion")));
        } else if (input.getParam("expectedVersion") != null) {
            throw failure("INVALID_CRM_VERSION");
        }
        String state = text(input.getParam("businessState"), 30, true);
        if (!Set.of("ACTIVE", "INACTIVE").contains(state)) {
            throw failure("INVALID_CRM_INPUT");
        }
        p.putParam("businessState", state);
        p.putParam("mobile", text(input.getParam("mobile"), 50, false));
        if (contact) {
            p.putParam("partnerId", positive(input.getParam("partnerId")));
            p.putParam("contactName", text(input.getParam("contactName"), 100, true));
            p.putParam("organizationText", text(input.getParam("organizationText"), 200, false));
        } else {
            String kind = text(input.getParam("partnerKind"), 10, true);
            if (!Set.of("ORG", "PERSON").contains(kind)) {
                throw failure("INVALID_CRM_INPUT");
            }
            p.putParam("partnerKind", kind);
            p.putParam("partnerName", text(input.getParam("partnerName"), 200, true));
            if (!(input.getParam("customerRole") instanceof Boolean customer)
                    || !(input.getParam("supplierRole") instanceof Boolean supplier)
                    || !(customer || supplier)) {
                throw failure("INVALID_CRM_INPUT");
            }
            p.putParam("customerRole", customer);
            p.putParam("supplierRole", supplier);
            p.putParam("receiverName", text(input.getParam("receiverName"), 100, false));
            p.putParam("address", text(input.getParam("address"), 1000, false));
            p.putParam("email", text(input.getParam("email"), 200, false));
        }
        // 首次客户类型属于同一创建意图；编辑仍由独立分类版本入口维护，不能随资料保存覆盖。
        if (!contact && input.getParamMap().containsKey("initialCustomerTypeIdsJson")) {
            if (id != null || !Boolean.TRUE.equals(p.getParam("customerRole"))) {
                throw failure("INVALID_CRM_INPUT");
            }
            p.putParam("initialCustomerTypeIdsJson", customerTypeIdsJson(input.getParam("initialCustomerTypeIdsJson")));
        }
        return p;
    }

    /**
     * 方法作用：规范首次客户分类的稳定编号集合，不使用分类名称或固定家长孩子标签。
     * @param value 明确JSON编号数组，例如["100001",100000]
     * @return 真实返回示例：升序JSON文本[100000,100001]，空集合为[]。
     * 异常或副作用示例：重复、非法编号、非数组或超过50项拒绝；零写入。
     */
    public static String customerTypeIdsJson(Object value) {
        if (!(value instanceof String json) || json.length() > 2000) { throw failure("INVALID_CRM_INPUT"); }
        List<?> values;
        try { values = JsonUtils.fromJson(json, List.class); }
        catch (RuntimeException invalid) { throw failure("INVALID_CRM_INPUT"); }
        if (values == null || values.size() > 50) { throw failure("INVALID_CRM_INPUT"); }
        var sorted = new java.util.TreeSet<Long>();
        for (Object item : values) {
            if (!sorted.add(positive(item))) { throw failure("INVALID_CRM_INPUT"); }
        }
        return JsonUtils.toJsonIgnoreNull(new java.util.ArrayList<>(sorted));
    }

    /**
     * 计算实际规范命令正文SHA256，requestKey不参与业务内容摘要。
     *
     * @param normalized 已规范CommonParam，例如org901/partnerName合成供应商/requestKeyk1
     * @return 64位十六进制SHA256文本，不接受客户端摘要、不写库
     * @throws IllegalStateException JDK SHA-256不可用时SHA-256 unavailable，保留原异常
     */
    public static String hash(CommonParam normalized) {
        Map<String, Object> content = new TreeMap<>(normalized.getParamMap());
        content.remove("requestKey");
        try {
            return HexFormat.of()
                    .formatHex(
                            MessageDigest.getInstance("SHA-256")
                                    .digest(
                                            JsonUtils.toJsonIgnoreNull(content)
                                                    .getBytes(StandardCharsets.UTF_8)));
        } catch (java.security.NoSuchAlgorithmException error) {
            throw new IllegalStateException("SHA-256 unavailable", error);
        }
    }

    /**
     * 复制本表写字段及可信审计字段；输入例如规范name及scope92/901/9211；返回本表列，不携客户端身份。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @param scope 服务已经真实回查的隔离范围，例如tenant92/org901/actor9211；不在此授予权限
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonParam entity(CommonParam input, Map<String, Object> scope) {
        CommonParam row = new CommonParam();
        input.getParamMap()
                .forEach(
                        (k, v) -> {
                            if (!Set.of("organizationCandidateId", "requestKey", "expectedVersion", "initialCustomerTypeIdsJson")
                                    .contains(k)) {
                                row.putParam(k, v);
                            }
                        });
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        row.putParam("createdByUserId", scope.get("actorUserId"));
        row.putParam("updatedByUserId", scope.get("actorUserId"));
        row.putParam("lastOperateUserId", scope.get("actorUserId"));
        row.putParam("versionNo", 0L);
        row.putParam("status", 1);
        return row;
    }

    /**
     * 构建只含真实复合主键的详情；输入例如org候选901/id200000及可信scope；返回tenant92/org901/id200000。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @param scope 服务已经真实回查的隔离范围，例如tenant92/org901/actor9211；不在此授予权限
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonParam detail(CommonParam input, Map<String, Object> scope) {
        CommonParam row = new CommonParam();
        row.putParam("id", positive(input.getParam("id")));
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        return row;
    }

    /**
     * 构建范围内公共分页；输入例如page1/size20及可信scope；返回限定组织和status1的参数。
     *
     * @param input 业务候选或分页参数，例如organizationCandidateId=901、id=200000、pageNo=1；身份由服务端回查
     * @param scope 服务已经真实回查的隔离范围，例如tenant92/org901/actor9211；不在此授予权限
     * @param search 允许的搜索字段，例如partnerNameLike；null时不复制搜索
     * @return 规范范围分页，例如pageNo=1/pageSize=20/tenantId=92/businessOrgId=901/status=1
     * @throws CommonBusinessException 页码107374184、页长20超过公共int偏移上界时抛INVALID_CRM_ID；不访问数据库
     */
    public static CommonPageParam page(
            CommonPageParam input, Map<String, Object> scope, String search) {
        CommonPageParam row = new CommonPageParam();
        row.setPageNo(input.getPageNo());
        row.setPageSize(
                input.getPageSize() == null ? 20 : Math.max(1, Math.min(100, input.getPageSize())));
        // 用已规范页长计算安全上界，避免公共int偏移乘法环绕；不截断请求或改底座SQL。
        if (row.getPageNo() > 1L + Integer.MAX_VALUE / row.getPageSize()) {
            throw failure("INVALID_CRM_ID");
        }
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        row.putParam("status", 1);
        if (search != null && input.getParam(search) != null) {
            row.putParam(search, text(input.getParam(search), 200, false));
        }
        return row;
    }

    /**
     * 检查单次写影响；参数例如1；无返回；0或多行抛错让当前CRM事务回滚。
     *
     * @param rows 本次影响行数，例如1；非1导致当前事务失败
     */
    public static void changed(int rows) {
        if (rows != 1) {
            throw failure("CRM_CONCURRENT_CHANGE");
        }
    }

    /**
     * 创建安全公共结果；参数例如id200000/version0/replayfalse；返回CommonResult，不附信任凭据。
     *
     * @param data 真实结果数据，例如id=200000/versionNo=0；不附授权凭证
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonResult result(Map<String, Object> data) {
        CommonResult result = new CommonResult();
        result.setSuccess(true);
        result.setData(data);
        return result;
    }

    /**
     * 公共安全异常；参数例如STALE_CRM_VERSION；返回对应异常；不泄露原字段或SQL。
     *
     * @param code 安全业务错误码，例如STALE_CRM_VERSION
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    public static CommonBusinessException failure(String code) {
        return new CommonBusinessException(code, "业务操作未完成，请检查权限、输入或重新加载最新版本。");
    }

    /**
     * 为内部具名请求/审计确定固定动作，不让审核人必须拥有客户写权限。
     *
     * @param name 命令名，例如ORDER_APPROVE或PARTNER_SAVE
     * @return 固定动作，例如crm.order.approve；未知命令拒绝
     * @throws CommonBusinessException 命令不是本小步白名单时拒绝，不写库
     */
    public static String commandAction(Object name) {
        return switch (String.valueOf(name)) {
            case "PRODUCT_SAVE" -> "crm.product.write";
            case "PARTNER_SAVE", "CONTACT_SAVE", "PARTNER_ARCHIVE", "PARTNER_RESTORE" -> "crm.partner.write";
            case "ORDER_SAVE", "ORDER_FILE_BIND", "ORDER_WITHDRAW" -> "crm.order.write";
            case "ORDER_SUBMIT" -> "crm.order.submit";
            case "ORDER_APPROVE", "ORDER_REJECT" -> "crm.order.approve";
            case "DOCUMENT_SAVE" -> "crm.stock.write";
            case "DOCUMENT_SUBMIT" -> "crm.stock.submit";
            case "DOCUMENT_APPROVE" -> "crm.stock.approve";
            case "FUNDS_DOCUMENT_SAVE" -> "crm.funds.write";
            case "FUNDS_DOCUMENT_SUBMIT" -> "crm.funds.submit";
            case "FUNDS_DOCUMENT_APPROVE", "FUNDS_DOCUMENT_REJECT" -> "crm.funds.approve";
            case "FUNDS_POST" -> "crm.funds.post";
            case "FUNDS_REVERSAL_REQUEST", "FUNDS_REVERSE" -> "crm.funds.reverse";
            case "FUNDS_REVERSAL_APPROVE" -> "crm.funds.approve";
            case "STOCK_POST" -> "crm.stock.post";
            case "STOCK_REVERSAL_REQUEST", "STOCK_REVERSE" -> "crm.stock.reverse";
            case "STOCK_REVERSAL_APPROVE" -> "crm.stock.approve";
            default -> throw failure("INVALID_CRM_COMMAND");
        };
    }
  /**
   * 方法作用：规范具名归档或恢复正文，目标状态只由服务器方法给定，不接受客户端身份或资料覆盖。
   *
   * @param input 原正文，例如org901/id501/expectedVersion0/reasonText暂停往来/requestKeyarchive-1
   * @param archived 服务器固定目标，例如true归档、false恢复
   * @return 真实返回示例：含原稳定编号、规范原因与archivedFlag=true的CommonParam，供同键摘要。
   * @throws CommonBusinessException 多余字段、空原因、非法编号/版本或请求键时拒绝，零写入
   */
  public static CommonParam archive(CommonParam input, boolean archived) {
    var fields =
        Set.of("organizationCandidateId", "id", "expectedVersion", "requestKey", "reasonText");
    if (input == null || !fields.containsAll(input.getParamMap().keySet())) {
      throw failure("INVALID_CRM_INPUT");
    }
    var normalized = new CommonParam();
    normalized.putParam(
        "organizationCandidateId", positive(input.getParam("organizationCandidateId")));
    normalized.putParam("id", positive(input.getParam("id")));
    normalized.putParam("expectedVersion", version(input.getParam("expectedVersion")));
    String key = text(input.getParam("requestKey"), 64, true);
    if (!key.matches("[A-Za-z0-9_.:-]+")) {
      throw failure("INVALID_CRM_INPUT");
    }
    normalized.putParam("requestKey", key);
    normalized.putParam("reasonText", text(input.getParam("reasonText"), 200, true));
    normalized.putParam("archivedFlag", archived);
    return normalized;
  }

  /**
   * 方法作用：规范客户列表归档范围；空条件为未归档，不改变原业务启停过滤语义。
   *
   * @param value 明确视图，例如CURRENT、ARCHIVED或ALL
   * @return 真实返回示例：CURRENT；未知值拒绝，不退化为全部客户。
   * @throws CommonBusinessException 未声明的视图，例如任意SQL片段时拒绝，零业务写入
   */
  public static String archiveView(Object value) {
    if (value == null) {
      return "CURRENT";
    }
    String view = text(value, 20, true);
    if (!Set.of("CURRENT", "ARCHIVED", "ALL").contains(view)) {
      throw failure("INVALID_CRM_INPUT");
    }
    return view;
  }
}
