/** CrmCustomerDraftService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.customerdraft.service;

import com.sp.selplat.common.service.BaseService;

/** 本人客户草稿服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmCustomerDraftService extends BaseService {
    /**
     * 锁真实私人客户；输入例如{id:101}；返回行或缺失拒绝；仅参与已有CRM事务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：锁真实私人客户；输入例如{id:101}；返回行或缺失拒绝；仅参与已有CRM事务。
     * @return 行或缺失拒绝
     */
    java.util.Map<String, Object> lockForPosting(com.sp.selplat.common.util.CommonParam input);
}
