/** 销售出库/采购入库SELUI服务端聚合；2026-10-04，Codex；只消费实际分页。 */
package com.sp.selplat.crm.common.util.stock;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 业务显示配置在服务器，客户端不创造账务/许可事实。 */
public final class CrmStockWorkspaceSupport {
    /** 仅通过静态方法聚合页面配置；构造不创建库存、权限或账本。 */
    private CrmStockWorkspaceSupport() {
        // 所有聚合均为静态调用，不建立带状态的页面组件。
    }

    /**
     * 真实分页、服务端三语表单及明确库存操作。
     *
     * @param documents 实际本组织单据分页
     * @param orders 实际已审核销售来源分页
     * @param warehouses 实际本组织仓库分页
     * @param balances 实际组织仓库/商品库存分页
     * @param details 实际POST流水分页
     * @param permits 实际stock.write/submit/approve/post逐次裁决
     * @param requested 展示语言候选，例如zh-CN/en-US/ja-JP
     * @param purchase true为采购入库，例如true；false维持销售出库配置
     * @return 公共真实业务与SELUI配置，明确synthetic=true
     */
    public static CommonResult build(
            CommonPageResult documents,
            CommonPageResult orders,
            CommonPageResult warehouses,
            CommonPageResult balances,
            CommonPageResult details,
            Map<String, Boolean> permits,
            Object requested,
            boolean purchase) {
        String lang = String.valueOf(requested);
        int locale = lang.equals("en-US") ? 1 : lang.equals("ja-JP") ? 2 : 0;
        Map<String, String[]> words = new LinkedHashMap<>();
        words.put("totalDisplay", new String[] {"订单总额", "Order total", "注文合計"});
        words.put("title", new String[] {"销售出库与库存流水", "Sales issue and stock ledger", "販売出庫と在庫台帳"});
        words.put("id", new String[] {"编号", "Number", "番号"});
        words.put("orderId", new String[] {"销售订单", "Sales order", "販売注文"});
        words.put("documentStateLabel", new String[] {"状态", "State", "状態"});
        words.put("warehouseName", new String[] {"仓库", "Warehouse", "倉庫"});
        words.put("warehouseId", new String[] {"仓库编号", "Warehouse number", "倉庫番号"});
        words.put("productId", new String[] {"商品编号", "Product number", "商品番号"});
        words.put("sourceOrderLineId", new String[] {"订单行编号", "Order line number", "注文行番号"});
        words.put("productNameSnapshot", new String[] {"商品", "Product", "商品"});
        words.put("quantity", new String[] {"EA数量", "EA quantity", "EA数量"});
        words.put("quantityDelta", new String[] {"库存变动EA", "Stock movement EA", "在庫増減EA"});
        words.put("openingQuantity", new String[] {"期初EA", "Opening EA", "期首EA"});
        words.put("versionNo", new String[] {"版本", "Version", "バージョン"});
        words.put("batchId", new String[] {"批次", "Batch", "バッチ"});
        words.put("documentId", new String[] {"出库单", "Issue document", "出庫伝票"});
        words.put("lineNo", new String[] {"行号", "Line", "行番号"});
        words.put("new", new String[] {"新建出库单", "New issue", "新規出庫"});
        words.put("reload", new String[] {"重载详情", "Reload detail", "再読み込み"});
        words.put("saveDraft", new String[] {"保存全部行", "Save all lines", "全行保存"});
        words.put("submit", new String[] {"提交", "Submit", "提出"});
        words.put("approve", new String[] {"他人审核", "Independent approval", "独立承認"});
        words.put("post", new String[] {"明确过账扣库存", "Post and issue stock", "転記・在庫払出"});
        words.put("newLine", new String[] {"新行", "New line", "新規行"});
        words.put("addLine", new String[] {"加入/更新行", "Add / update line", "行追加・更新"});
        words.put("removeLine", new String[] {"移除当前行", "Remove line", "行削除"});
        words.put(
                "references",
                new String[] {
                    "审核订单、来源行与仓库", "Approved orders, source lines and warehouses", "承認注文・明細・倉庫"
                });
        if (purchase) {
            words.put(
                    "title",
                    new String[] {"采购入库与库存流水", "Purchase receipt and stock ledger", "仕入入庫と在庫台帳"});
            words.put("orderId", new String[] {"采购订单", "Purchase order", "仕入注文"});
            words.put("documentId", new String[] {"采购入库单", "Purchase receipt", "仕入入庫伝票"});
            words.put("new", new String[] {"新建采购入库单", "New purchase receipt", "新規仕入入庫"});
            words.put("post", new String[] {"明确过账增加库存", "Post and receive stock", "転記・在庫受入"});
        }
        Map<String, String> labels = new LinkedHashMap<>();
        words.forEach((k, v) -> labels.put(k, v[locale]));
        Map<String, String> states =
                Map.of(
                        "DRAFT",
                        new String[] {"草稿", "Draft", "下書き"}[locale],
                        "SUBMITTED",
                        new String[] {"已提交", "Submitted", "提出済み"}[locale],
                        "APPROVED",
                        new String[] {"已审核冻结", "Approved and frozen", "承認・凍結済み"}[locale],
                        "POSTED",
                        new String[] {"已过账出库", "Posted and issued", "転記・出庫済み"}[locale],
                        "REVERSED",
                        new String[] {"已整批冲正", "Full batch reversed", "バッチ全体反対仕訳済み"}[locale]);
        if (purchase) {
            states = new LinkedHashMap<>(states);
            states.put("POSTED", new String[] {"已过账入库", "Posted and received", "転記・入庫済み"}[locale]);
        }
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("documentKind", purchase ? "STOCK_RECEIPT" : "STOCK_ISSUE");
        data.put("reason", purchase ? "PURCHASE" : "SALE");
        data.put(
                "switchStockKind",
                (purchase
                                ? new String[] {"切换销售出库", "Sales issue", "販売出庫へ"}
                                : new String[] {"切换采购入库", "Purchase receipt", "仕入入庫へ"})
                        [locale]);
        data.put("synthetic", true);
        data.put("permits", permits);
        data.put("labels", labels);
        data.put("states", states);
        data.put("title", labels.get("title"));
        data.put(
                "notice",
                new String[] {
                            "隔离合成库：审核不扣库存，只有明确过账写流水；生产未开放。",
                            "Isolated synthetic database: approval changes no stock; only explicit"
                                    + " posting writes the ledger. Production disabled.",
                            "隔離合成DB：承認は在庫を変更せず、明示転記のみ台帳記入。本番未開放。"
                        }
                        [locale]);
        data.put(
                "dirty",
                new String[] {
                            "有未保存行，请先保存或重载。",
                            "Unsaved lines. Save or reload first.",
                            "未保存行があります。保存か再読込みしてください。"
                        }
                        [locale]);
        data.put(
                "linePending",
                new String[] {
                            "行字段尚未加入，请先加入/更新或重载。",
                            "Pending line fields. Add/update or reload first.",
                            "行フィールド未追加。追加・更新か再読込みしてください。"
                        }
                        [locale]);
        data.put(
                "selectionRequired",
                new String[] {
                            "请选择真实审核销售订单、来源行和仓库。",
                            "Select a real approved sales order, source line and warehouse.",
                            "実際の承認販売注文・明細・倉庫を選択してください。"
                        }
                        [locale]);
        data.put(
                "saved",
                new String[] {
                            "数据库已提交，全部行原子处理。",
                            "Database committed; all lines processed atomically.",
                            "DB確定。全行を原子的に処理。"
                        }
                        [locale]);
        data.put("lineLimit", 1000);
        data.put(
                "lineLimitMessage",
                new String[] {"出库单最多1000行。", "At most 1000 issue lines.", "出庫は最大1000行。"}[locale]);
        if (purchase) {
            data.put(
                    "selectionRequired",
                    new String[] {
                                "请选择真实审核采购订单、来源行和仓库。",
                                "Select an approved purchase order, source line and warehouse.",
                                "承認済み仕入注文・明細・倉庫を選択してください。"
                            }
                            [locale]);
            data.put(
                    "lineLimitMessage",
                    new String[] {
                                "采购入库单最多1000行。",
                                "At most 1000 purchase receipt lines.",
                                "仕入入庫は最大1000行。"
                            }
                            [locale]);
        }
        data.put(
                "headerForm",
                Map.of(
                        "id",
                        "crm-stock-editor",
                        "title",
                        labels.get("title"),
                        "fields",
                        List.of(
                                Map.of(
                                        "id",
                                        "orderId",
                                        "label",
                                        labels.get("orderId"),
                                        "readOnly",
                                        true)),
                        "actions",
                        List.of("new", "reload", "saveDraft", "submit", "approve", "post").stream()
                                .map(id -> Map.of("id", id, "label", labels.get(id)))
                                .toList(),
                        "slots",
                        List.of("lineForm", "lineGrid", "balanceGrid", "detailGrid")));
        data.put(
                "lineForm",
                Map.of(
                        "id",
                        "crm-stock-line-editor",
                        "fields",
                        List.of(
                                Map.of(
                                        "id",
                                        "productNameSnapshot",
                                        "label",
                                        labels.get("productNameSnapshot"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "sourceOrderLineId",
                                        "label",
                                        labels.get("sourceOrderLineId"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "warehouseName",
                                        "label",
                                        labels.get("warehouseName"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "quantity",
                                        "label",
                                        labels.get("quantity"),
                                        "maxLength",
                                        10)),
                        "actions",
                        List.of("newLine", "addLine", "removeLine").stream()
                                .map(id -> Map.of("id", id, "label", labels.get(id)))
                                .toList()));
        data.put(
                "referenceForm",
                Map.of(
                        "id",
                        "crm-stock-references",
                        "title",
                        labels.get("references"),
                        "fields",
                        List.of(),
                        "slots",
                        List.of("reversalForm", "orderGrid", "sourceGrid", "warehouseGrid")));
        List<Map<String, Object>> docs = new ArrayList<>();
        for (var row : documents.getRecords()) {
            var copy = CrmStockValueSupport.browser(row);
            copy.put("documentStateLabel", states.get(String.valueOf(row.get("documentState"))));
            docs.add(copy);
        }
        data.put(
                "documents",
                grid(
                        docs,
                        documents,
                        List.of("id", "orderId", "documentStateLabel"),
                        labels,
                        locale));
        List<Map<String, Object>> displayedOrders = new ArrayList<>();
        for (var row : orders.getRecords()) {
            var copy = CrmStockValueSupport.browser(row);
            copy.put(
                    "totalDisplay",
                    new java.math.BigDecimal(row.get("totalMinor").toString())
                                    .movePointLeft(((Number) row.get("currencyScale")).intValue())
                                    .toPlainString()
                            + " "
                            + row.get("currency"));
            displayedOrders.add(copy);
        }
        data.put(
                "orders",
                grid(displayedOrders, orders, List.of("id", "totalDisplay"), labels, locale));
        data.put(
                "warehouses",
                grid(
                        warehouses.getRecords(),
                        warehouses,
                        List.of("id", "warehouseName"),
                        labels,
                        locale));
        data.put(
                "balances",
                grid(
                        balances.getRecords(),
                        balances,
                        List.of(
                                "warehouseId",
                                "productId",
                                "openingQuantity",
                                "quantity",
                                "versionNo"),
                        labels,
                        locale));
        data.put(
                "details",
                grid(
                        details.getRecords(),
                        details,
                        List.of(
                                "id",
                                "batchId",
                                "sourceOrderLineId",
                                "warehouseId",
                                "productId",
                                "quantityDelta"),
                        labels,
                        locale));
        data.put(
                "lines",
                grid(
                        List.of(),
                        null,
                        List.of(
                                "lineNo",
                                "sourceOrderLineId",
                                "productNameSnapshot",
                                "warehouseName",
                                "quantity"),
                        labels,
                        locale));
        data.put(
                "sourceLines",
                grid(
                        List.of(),
                        null,
                        List.of("id", "productNameSnapshot", "quantity"),
                        labels,
                        locale));
        if (permits.containsKey("crm.stock.reverse")) {
            Map<String, String[]> reverseWords =
                    Map.ofEntries(
                            Map.entry(
                                    "title",
                                    new String[] {
                                        "库存整批冲正", "Full stock batch reversal", "在庫バッチ全体の反対仕訳"
                                    }),
                            Map.entry(
                                    "originalBatchId",
                                    new String[] {"原批次", "Original batch", "元バッチ"}),
                            Map.entry(
                                    "totalQuantity",
                                    new String[] {
                                        "原整批数量EA", "Original batch quantity EA", "元バッチ数量EA"
                                    }),
                            Map.entry(
                                    "requestState",
                                    new String[] {"冲正申请状态", "Reversal request state", "反対仕訳申請状態"}),
                            Map.entry(
                                    "approvedByUserId",
                                    new String[] {"独立审核人", "Independent approver", "独立承認者"}),
                            Map.entry(
                                    "reasonText",
                                    new String[] {
                                        "整批冲正原因", "Full batch reversal reason", "バッチ全体の反対仕訳理由"
                                    }),
                            Map.entry(
                                    "requestReverse",
                                    new String[] {
                                        "申请整批冲正", "Request full batch reversal", "バッチ全体の反対仕訳申請"
                                    }),
                            Map.entry(
                                    "approveReverse",
                                    new String[] {
                                        "审核他人申请", "Approve another user's request", "他者申請承認"
                                    }),
                            Map.entry(
                                    "executeReverse",
                                    new String[] {
                                        "明确反向记账", "Post full reverse ledger", "全体反対仕訳を転記"
                                    }),
                            Map.entry(
                                    "quantityDelta",
                                    new String[] {"库存变化EA", "Stock change EA", "在庫変化EA"}));
            Map<String, String> reverseLabels = new LinkedHashMap<>(labels);
            reverseWords.forEach((k, v) -> reverseLabels.put(k, v[locale]));
            List<Map<String, Object>> fields = new ArrayList<>();
            for (String f :
                    List.of(
                            "originalBatchId",
                            "totalQuantity",
                            "requestState",
                            "approvedByUserId")) {
                fields.add(Map.of("id", f, "label", reverseLabels.get(f), "readOnly", true));
            }
            fields.add(
                    Map.of(
                            "id",
                            "reasonText",
                            "label",
                            reverseLabels.get("reasonText"),
                            "maxLength",
                            500));
            data.put(
                    "reversalStates",
                    Map.of(
                            "SUBMITTED",
                            new String[] {"待他人审核", "Awaiting independent approval", "他者承認待ち"}
                                    [locale],
                            "APPROVED",
                            new String[] {
                                        "已审核待冲正",
                                        "Approved, awaiting explicit reversal",
                                        "承認済み反対仕訳待ち"
                                    }
                                    [locale],
                            "POSTED",
                            new String[] {"整批冲正完成", "Full batch reversal completed", "バッチ全体反対仕訳完了"}
                                    [locale]));
            data.put(
                    "reversalForm",
                    Map.of(
                            "id",
                            "crm-stock-reversal-editor",
                            "title",
                            reverseLabels.get("title"),
                            "fields",
                            fields,
                            "actions",
                            List.of("requestReverse", "approveReverse", "executeReverse").stream()
                                    .map(id -> Map.of("id", id, "label", reverseLabels.get(id)))
                                    .toList(),
                            "slots",
                            List.of("stockEffectsGrid")));
            data.put(
                    "reversalStockEffects",
                    grid(
                            List.of(),
                            null,
                            List.of("warehouseId", "productId", "quantityDelta"),
                            reverseLabels,
                            locale));
        }
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 公共Grid协议，仅实际分页或明确空待编辑行，不复制组件。
     *
     * @param rows 实际列表或暂存编辑空列表
     * @param page 实际分页；暂存行null
     * @param columns 固定服务器字段白名单
     * @param labels 服务端三语标题
     * @param locale 展示语言索引0/1/2
     * @return 公共Grid原生配置及真实REMOTE分页
     */
    private static Map<String, Object> grid(
            List<Map<String, Object>> rows,
            CommonPageResult page,
            List<String> columns,
            Map<String, String> labels,
            int locale) {
        var r = new LinkedHashMap<String, Object>();
        r.put("grid", Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id"));
        r.put("data", Map.of("items", rows, "selectedIds", List.of()));
        r.put(
                "column",
                Map.of(
                        "items",
                        columns.stream()
                                .map(
                                        f ->
                                                Map.of(
                                                        "id",
                                                        f,
                                                        "field",
                                                        f,
                                                        "label",
                                                        labels.getOrDefault(f, f)))
                                .toList()));
        r.put("title", Map.of("messages", Map.of("selectProject", labels.get("title"))));
        r.put(
                "pagination",
                Map.of(
                        "mode",
                        page == null ? "LOCAL" : "REMOTE",
                        "visible",
                        page != null,
                        "totalCount",
                        page == null ? rows.size() : page.getTotalCount(),
                        "currentPage",
                        page == null ? 1 : page.getPageNo(),
                        "pageSize",
                        page == null ? 1000 : page.getPageSize(),
                        "previousLabel",
                        new String[] {"上一页", "Previous", "前へ"}[locale],
                        "nextLabel",
                        new String[] {"下一页", "Next", "次へ"}[locale],
                        "summaryAll",
                        new String[] {"共 {total} 条", "{total} records", "合計 {total} 件"}[locale]));
        r.put(
                "select",
                Map.of(
                        "pageSize",
                        Map.of(
                                "ariaLabel",
                                new String[] {"每页行数", "Rows per page", "ページ行数"}[locale],
                                "options",
                                List.of(10, 20, 50, 100).stream()
                                        .map(
                                                n ->
                                                        Map.of(
                                                                "value",
                                                                n.toString(),
                                                                "label",
                                                                n
                                                                        + new String[] {
                                                                                    " 行/页",
                                                                                    " rows/page",
                                                                                    " 行/ページ"
                                                                                }
                                                                                [locale]))
                                        .toList())));
        return r;
    }
}
