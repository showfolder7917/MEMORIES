/** CrmPartnerController.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.partner.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.partner.service.CrmPartnerService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表Controller仅调用本表Service，公共参数和结果完整序列化。 */
@RestController
@RequestMapping("/api/crm/partner")
public class CrmPartnerController {
    // 本表Service核实际Session、组织动作和事务，不依赖客户端权限。
    private final CrmPartnerService service;

    /**
     * 装配本表服务；参数例如CrmPartnerServiceImpl；构造不读写数据库。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmPartnerController(CrmPartnerService service) {
        this.service = service;
    }

    /**
     * 聚合工作区；输入org901；返回真实分页和服务端控件配置；缺许可拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     *     业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     * @return 公共结果，data包含真实分页和SELUI表单定义；synthetic明确为true
     */
    @GetMapping("workspace.htm")
    public String workspace(CommonPageParam p) {
        return JsonUtils.toJsonIgnoreNull(service.workspace(p));
    }

    /**
     * 分页；输入例如org901/pageNo1；返回公共分页；无组织read许可拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 公共真实分页，例如records包含本组织客户；不会退化为全库
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam p) {
        return JsonUtils.toJsonIgnoreNull(service.getStore(p));
    }

    /**
     * 详情；输入例如org901/id200000；返回公共data记录；跨组织或非法主键拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam p) {
        return JsonUtils.toJsonIgnoreNull(service.getById(p));
    }

    /**
     * 保存；输入例如org901/keyk1及业务字段；返回id/version/replay；CAS/请求失败整笔回滚。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @PostMapping("save.htm")
    public String save(CommonParam p) {
        return JsonUtils.toJsonIgnoreNull(service.save(p));
    }
  /**
   * 方法作用：只序列化原客户拥有方归档结果，不在Controller判断身份、版本或替换返回合同。
   *
   * @param input 实际正文，例如organizationCandidateId901/id501/expectedVersion0/reasonText暂停往来
   * @return
   *     真实返回示例：{"success":true,"data":{"id":"501","versionNo":"1","archivedFlag":true,"replay":false}}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原服务拒绝时沿公共失败出口，零额外写入
   */
  @PostMapping("archive.htm")
  public String archive(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.archive(input));
  }

  /**
   * 方法作用：只序列化原客户拥有方恢复结果，原状态和历史不由页面覆盖。
   *
   * @param input 实际正文，例如organizationCandidateId901/id501/expectedVersion1/reasonText恢复往来
   * @return
   *     真实返回示例：{"success":true,"data":{"id":"501","versionNo":"2","archivedFlag":false,"replay":false}}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原服务拒绝时沿公共失败出口，零额外写入
   */
  @PostMapping("restore.htm")
  public String restore(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.restore(input));
  }
}
