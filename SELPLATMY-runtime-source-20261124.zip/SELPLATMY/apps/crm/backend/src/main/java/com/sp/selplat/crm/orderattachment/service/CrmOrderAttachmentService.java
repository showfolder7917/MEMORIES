/** CRM当前上传者订单附件引用；2026-10-04，Codex；不共享或删除远端文件。 */
package com.sp.selplat.crm.orderattachment.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 本表沿用公共签名，具名绑定和共享详情分别消费实际文件许可。 */
public interface CrmOrderAttachmentService extends BaseService {
    /**
     * 方法作用：真实文件概要验证后，在CRM事务内完成引用CAS、首次请求结果和审计。
     *
     * @param input
     *     org901/id600000/expectedVersion2/fileId、sha256、byteSize3/requestKey为UUID/expectedAttachmentVersion0；替换还含attachmentId
     * @return
     *     success=true/data.bindingWritten=true、attachmentId100000/versionNo1/replay=false；同键返回首次结果replay=true
     *     异常或副作用示例：失效身份、跨用户、旧附件版本或末尾审计失败使整笔引用/请求/审计回滚；不删远端正文。
     */
    CommonResult bind(CommonParam input);
    /**
     * 方法作用：读取准确订单内他人引用，必须再通过当前接收人的独立文件共享许可。
     * @param input 组织901/orderId600000/id100000；owner、tenant和文件坐标均不接受客户端覆盖
     * @return 真实返回示例：success=true/data含已存引用及shared=true；不代表正文下载许可。
     * 异常或副作用示例：缺订单读许可或文件共享许可拒绝，不改变本人目录或授予共享。
     */
    CommonResult getSharedById(CommonParam input);

    /**
     * 方法作用：将文件系统共享收件箱的明确文件候选解析为当前订单引用，再核独立共享许可。
     * @param input 组织901/orderId600000/ownerUserId9212/fileId为32位ID，所有者仅定位资源
     * @return 真实返回示例：已核对引用及shared=true；当前订单无引用或未获许可统一拒绝。
     * 异常或副作用示例：不按owner选择当前身份，不自动关联共享文件或修改所有者。
     */
    CommonResult getSharedByFile(CommonParam input);

}
