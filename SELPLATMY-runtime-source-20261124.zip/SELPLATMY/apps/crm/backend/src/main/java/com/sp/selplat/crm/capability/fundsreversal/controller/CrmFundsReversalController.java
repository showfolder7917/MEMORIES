/** 收款完整冲正明确HTTP契约；2026-10-03，Codex。 */
package com.sp.selplat.crm.capability.fundsreversal.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只调用能力服务；没有通用修改原账本的路由。 */
@RestController
@RequestMapping("/api/crm/funds/reversal")
public class CrmFundsReversalController {
    private final com.sp.selplat.crm.capability.fundsreversal.service.CrmFundsReversalService
            service;

    /**
     * 方法作用：注入真实冲正聚合器。
     *
     * @param service 实际CrmFundsReversalServiceImpl 副作用示例：构造不授权、不执行SQL。
     */
    public CrmFundsReversalController(
            com.sp.selplat.crm.capability.fundsreversal.service.CrmFundsReversalService service) {
        this.service = service;
    }

    /**
     * 方法作用：读完整真实冲正预览。
     *
     * @param input org901/id1000000
     * @return 真实金额和账户效果JSON；缺许可拒绝，无资金效果。
     *     业务示例：组织901、原收款1000000、批次1200000；返回totalMinor=135、cashDeltaMinor=-135、unsettledDeltaMinor=135，不写资金。
     */
    @GetMapping("preview.htm")
    public String preview(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.preview(input));
    }

    /**
     * 方法作用：提交完整冲正申请。
     *
     * @param input org901/id1000000/originalBatch1200000/expected3/reasonText/key
     * @return 实际申请JSON；失败整笔回滚，原资金不变。
     *     业务示例：org901、原单1000000、批次1200000、expectedVersion=3、原因“合成完整冲正”；返回申请1700000、SUBMITTED/version0。
     */
    @PostMapping("request.htm")
    public String request(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.request(input));
    }

    /**
     * 方法作用：不同真实用户审核。
     *
     * @param input 原单/批次/申请id和双方版本、key
     * @return APPROVED真实申请JSON；自审拒绝。
     *     业务示例：用户9212审核用户9211提交的申请1700000、expectedReversalVersion=0；返回APPROVED/version1，自审拒绝。
     */
    @PostMapping("approve.htm")
    public String approve(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.approve(input));
    }

    /**
     * 方法作用：明确REVERSE整批登记。
     *
     * @param input 原单/批次/申请id、版本、actionREVERSE/key
     * @return 实际新批次和全部新明细JSON；依赖、权限、余额或末尾失败整笔回滚。
     *     业务示例：org901、原单1000000、申请1700000/version1、action=REVERSE；返回新批次1200001、全部相反明细及REVERSED/version4，余额1135恢复1000。
     */
    @PostMapping("execute.htm")
    public String execute(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.execute(input));
    }
}
