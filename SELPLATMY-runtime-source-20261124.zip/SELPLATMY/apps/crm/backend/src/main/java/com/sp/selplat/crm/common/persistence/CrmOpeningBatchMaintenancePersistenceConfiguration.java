/* 原资金期初维护元数据安装；2026-10-28，保留库存期初、原审核条件及全部历史。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import java.sql.SQLException;
import java.sql.Types;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 只向已安装资金使用的原期初表附加维护元数据；不写期初、账户、余额或许可。 */
@Configuration(proxyBeanMethods = false)
public class CrmOpeningBatchMaintenancePersistenceConfiguration {

  /**
   * 方法作用：检查真实兼容结构后幂等附加期初维护字段，未知类型拒绝，不重建原表。
   *
   * @param source 原crmDataSource，例如正式CRM独立池
   * @param inspector 原结构检查器，例如已安装funds模块
   * @return 真实示例：未安装false；维护列及唯一索引核对后true。
   * @throws SQLException 元数据读取失败时启动拒绝，无业务写入
   * @throws IllegalStateException 活动事务或不兼容既有结构拒绝，不覆盖原字段
   */
  @Bean("crmOpeningBatchMaintenanceInitialized")
  @DependsOn("crmBusinessStructureInspector")
  public Boolean initialize(
      @Qualifier("crmDataSource") DataSource source,
      @Qualifier("crmBusinessStructureInspector") CrmBusinessStructureInspector inspector)
      throws SQLException {
    if (!inspector.available().contains("funds")) {
      return false;
    }
    if (TransactionSynchronizationManager.isActualTransactionActive()) {
      throw new IllegalStateException("CRM_OPENING_ACTIVE_TRANSACTION");
    }
    verify(source, false);
    new ResourceDatabasePopulator(
            new ClassPathResource("db/crm/sql/maintenance-CrmOpeningBatch.sql"))
        .execute(source);
    verify(source, true);
    return true;
  }

  /**
   * 方法作用：核对原资金期初六列及真实组织创建键唯一索引，避免IF NOT EXISTS隐藏冲突。
   *
   * @param source 原CRM池，例如本例双mem业务池
   * @param required true要求全部维护字段已安装，例如DDL后
   * @throws SQLException 元数据实际读取错误传播
   * @throws IllegalStateException 类型、默认历史、容量或索引列顺序错误拒绝
   */
  private void verify(DataSource source, boolean required) throws SQLException {
    try (var connection = source.getConnection()) {
      for (String field :
          java.util.List.of(
              "fundsAccountId",
              "fundsCurrency",
              "fundsAmountMinor",
              "fundsCreationKey",
              "fundsCreationHash",
              "fundsHistoryJson")) {
        try (var columns =
            connection
                .getMetaData()
                .getColumns(
                    connection.getCatalog(), connection.getSchema(), "CrmOpeningBatch", field)) {
          if (!columns.next()) {
            if (required) {
              throw new IllegalStateException("CRM_OPENING_COLUMN_MISSING");
            }
            continue;
          }
          int expected =
              field.equals("fundsAccountId")
                  ? Types.BIGINT
                  : field.equals("fundsAmountMinor") ? Types.DECIMAL : Types.VARCHAR;
          boolean history = field.equals("fundsHistoryJson");
          if (columns.getInt("DATA_TYPE") != expected
              || (field.equals("fundsAmountMinor")
                  && (columns.getInt("COLUMN_SIZE") != 38 || columns.getInt("DECIMAL_DIGITS") != 0))
              || (field.equals("fundsCurrency") && columns.getInt("COLUMN_SIZE") != 3)
              || ((field.equals("fundsCreationKey") || field.equals("fundsCreationHash"))
                  && columns.getInt("COLUMN_SIZE") != 64)
              || (history
                  && (columns.getInt("COLUMN_SIZE") < 4000000
                      || !"'[]'".equals(columns.getString("COLUMN_DEF"))
                      || columns.getInt("NULLABLE") != java.sql.DatabaseMetaData.columnNoNulls))
              || (!history
                  && columns.getInt("NULLABLE") != java.sql.DatabaseMetaData.columnNullable)) {
            throw new IllegalStateException("CRM_OPENING_STRUCTURE_CONFLICT");
          }
        }
      }
      var indexed = new java.util.TreeMap<Integer, String>();
      try (var indexes =
          connection
              .getMetaData()
              .getIndexInfo(
                  connection.getCatalog(),
                  connection.getSchema(),
                  "CrmOpeningBatch",
                  false,
                  false)) {
        while (indexes.next()) {
          if ("crm_opening_funds_creation".equalsIgnoreCase(indexes.getString("INDEX_NAME"))) {
            if (indexes.getBoolean("NON_UNIQUE")) {
              throw new IllegalStateException("CRM_OPENING_INDEX_CONFLICT");
            }
            indexed.put(indexes.getInt("ORDINAL_POSITION"), indexes.getString("COLUMN_NAME"));
          }
        }
      }
      if ((required || !indexed.isEmpty())
          && !new java.util.ArrayList<>(indexed.values())
              .equals(java.util.List.of("tenantId", "businessOrgId", "fundsCreationKey"))) {
        throw new IllegalStateException("CRM_OPENING_INDEX_CONFLICT");
      }
    }
  }
}
