/**
 * CrmDraftScopeSupport.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 * 2026-10-09，私人批读只保留有效记录，保持公共结果结构与精确主键查询。
 */
package com.sp.selplat.crm.common.util.draft;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import java.util.Set;

/** 无状态私人范围参数工具；不持有 Spring 服务、DAO、连接或表归属。 */
public final class CrmDraftScopeSupport {
    /** 静态工具无需构造实例；构造不产生持久化或身份副作用。 */
    private CrmDraftScopeSupport() {
    }

    /**
     * 复制允许的搜索字段并附加真实私人范围。
     * @param source 页面参数，例如 {pageNo:1,pageSize:20,customerNameLike:"本人"}
     * @param actor 已由真实 Uniauth 回查的归属，例如 {tenantId:92,ownerUserId:9211}
     * @param fields 本表实际搜索字段，例如 customerNameLike
     * @return 新公共分页参数，始终包含真实归属和 status=1
     * 副作用示例：不修改请求，不访问 SQL，不因空搜索移除私人范围。
     */
    public static CommonPageParam scopeStore(CommonPageParam source, Map<String, Long> actor, Set<String> fields) {
        CommonPageParam scoped = new CommonPageParam();
        scoped.setPageNo(source.getPageNo());
        Integer requestedSize = source.getPageSize();
        scoped.setPageSize(requestedSize == null ? 20 : Math.max(1, Math.min(100, requestedSize)));
        for (String field : fields) {
            Object value = source.getParam(field);
            if (value != null) {
                scoped.putParam(field, value);
            }
        }
        actor.forEach(scoped::putParam);
        scoped.putParam("status", 1);
        return scoped;
    }

    /**
     * 校验精确主键并构建公共详情参数。
     * @param source 记录参数，例如 {id:100001,tenantId:1}
     * @param actor 可信归属，例如 {tenantId:92,ownerUserId:9211}
     * @return 新公共复合主键，客户端身份会被覆盖
     * @throws CommonBusinessException 缺失、非整数、非正数或溢出 ID 返回 INVALID_DRAFT_ID；不访问 SQL
     */
    public static CommonParam scopeDetail(CommonParam source, Map<String, Long> actor) {
        Object requestedId = source.getParam("id");
        if (requestedId == null || !String.valueOf(requestedId).matches("[1-9][0-9]{0,18}")) {
            throw new CommonBusinessException("INVALID_DRAFT_ID", "草稿主键必须为正整数。");
        }
        long recordId;
        try {
            recordId = Long.parseLong(String.valueOf(requestedId));
        } catch (NumberFormatException failure) {
            throw new CommonBusinessException("INVALID_DRAFT_ID", "草稿主键超出可用范围。");
        }
        CommonParam scoped = new CommonParam();
        scoped.putParam("id", recordId);
        actor.forEach(scoped::putParam);
        return scoped;
    }

    /**
     * 为公共批量详情建立只含真实主键范围的副本。
     * @param source 原始批次，例如 items=[{id:100001,ownerUserId:1}]
     * @param actor 可信归属，例如 ownerUserId=9211
     * @return 新 CommonBatchParam；空批次保持空，不降为普通分页
     * @throws CommonBusinessException 非法主键拒绝；输入对象与数据库均不修改
     */
    public static CommonBatchParam scopeBatch(CommonBatchParam source, Map<String, Long> actor) {
        CommonBatchParam scoped = new CommonBatchParam();
        for (CommonParam item : source.getItems()) {
            scoped.getItems().add(scopeDetail(item, actor));
        }
        return scoped;
    }

    /**
     * 公共批量精确查询之后只保留本人有效记录，与本域分页和详情的软删除合同一致。
     *
     * @param result 公共DAO实际列表，例如data=[{id:100001,status:1},{id:100004,status:0}]
     * @return 同一公共结果，data仅含有效记录，例如[{id:100001,status:1}]；空批次仍为空
     * 副作用示例：只更新结果中的data；不修改请求、归属、msg或任何数据库记录，不循环查单条。
     */
    public static CommonResult activeBatch(CommonResult result) {
        var rows = (java.util.List<?>) result.getData();
        // 精确私人主键已由各owning Service绑定；删除状态不能借批读重新暴露。
        result.setData(rows.stream()
                .filter(value -> ((Map<?, ?>) value).get("status") instanceof Number state
                        && state.intValue() == 1)
                .toList());
        return result;
    }

    /**
     * 为公共写入流程覆盖真实归属和操作员。
     * @param writeIn 内部参数，例如 {customerName:"本人客户",tenantId:1}
     * @param actor 可信归属，例如 {tenantId:92,ownerUserId:9211}
     * 返回示例：void，writeIn 归属被覆盖且 lastOperateUserId=9211
     * 副作用示例：只改变传入参数，不查询或写入数据库。
     */
    public static void applyActor(CommonParam writeIn, Map<String, Long> actor) {
        actor.forEach(writeIn::putParam);
        writeIn.putParam("lastOperateUserId", actor.get("ownerUserId"));
    }

    /**
     * 在公共精确详情查询后检查软删除状态。
     * @param result 公共实际结果，例如 {success:true,data:{id:100001,status:1}}
     * @return 原公共结果，不包装本域协议
     * @throws CommonBusinessException 删除记录拒绝为 RECORD_NOT_FOUND；不改变查询结果或数据库
     */
    public static CommonResult requireActive(CommonResult result) {
        Map<?, ?> record = (Map<?, ?>) result.getData();
        if (!(record.get("status") instanceof Number status) || status.intValue() != 1) {
            throw new CommonBusinessException("RECORD_NOT_FOUND", "未找到属于当前账号的草稿。");
        }
        return result;
    }
}
