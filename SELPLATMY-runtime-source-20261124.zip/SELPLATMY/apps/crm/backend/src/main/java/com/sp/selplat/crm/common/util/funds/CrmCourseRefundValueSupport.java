/* 原冻结净额对应未用课程权益的精确退款上限；2026-10-27。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.common.util.funds;

import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Map;

/**
 * 无现金写入；课程按明确原开通课时折算，费用不退，不读取当前商品价或重算历史优惠。
 */
public final class CrmCourseRefundValueSupport {

  /**
   * 禁止构造；纯值工具不创建资金或课时状态。
   */
  private CrmCourseRefundValueSupport() { }

  /**
   * 方法作用：读取原冻结的非负最小币种单位。
   * @param value 原冻结文本，例如90，不是主要单位0.90
   * @return 真实示例：BigInteger90，零合法用于不可退费用。
   * 异常或副作用示例：小数、负数、指数或超过38位拒绝，无舍入及写入。
   */
  private static BigInteger minor(Object value) {
    if (value == null || !value.toString().matches("(?:0|[1-9][0-9]{0,37})")) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    return new BigInteger(value.toString());
  }

  /**
   * 方法作用：把已核原三位课时转精确千分整数，不使用浮点；原开通与本次预留须另核为正。
   * @param value 原开通或活动预留文本，例如20或0.125
   * @return 真实示例：20返回20000，0.125返回125。
   * 异常或副作用示例：负数、超精度、非规范或超上限拒绝，不修改课时。
   */
  private static BigInteger milli(Object value) {
    if (!(value instanceof String)
        || !value.toString().matches("(?:0|[1-9][0-9]{0,11})(?:\\.[0-9]{1,3})?")) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    var result = new BigDecimal(value.toString()).movePointRight(3).toBigIntegerExact();
    if (result.signum() < 0) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    return result;
  }

  /**
   * 方法作用：保留无已退课时来源的原入口，真实累计来源必须提供实际已完成课时。
   * @param source 原冻结净额90、实收120、费用不退和真实退款计数
   * @param grantedUnits 原开通20
   * @param reservedUnits 本次活动预留4
   * @return 真实示例：首次4课时上限18；无完成课时却已有课程退款时拒绝。
   * 异常或副作用示例：不从客户端猜累计已退课时，不写金额或课时。
   */
  public static String maximum(
      Map<String, Object> source, Object grantedUnits, Object reservedUnits) {
    return maximum(source, grantedUnits, reservedUnits, "0");
  }

  /**
   * 方法作用：按原净额与累计已退加本次预留课时求总上限，再减真实已退现金，保持累计向下取整。
   * @param source 原净额90／实收120、goodsRefundedMinor0、courseRefundedMinor18及合计18
   * @param grantedUnits 原不可变开通20
   * @param reservedUnits 本次原预留6
   * @param completedRefundedUnits 原教学实际COMPLETED累计4，不含执行未知记录
   * @return 真实示例：累计10课时上限45减实际已退18，本次最多27；费用30仍不退。
   * 异常或副作用示例：现金与已确认课时不一致、库存退款、超原课时或未收齐拒绝，零写入。
   */
  public static String maximum(
      Map<String, Object> source,
      Object grantedUnits,
      Object reservedUnits,
      Object completedRefundedUnits) {
    String policy = String.valueOf(source.get("refundPolicyVersion"));
    var goods = minor(source.get("refundableGoodsMinor"));
    var due = minor(source.get("approvedDueMinor"));
    var paid = minor(source.get("cashSettledMinor"));
    var totalRefunded = minor(source.get("cashRefundedMinor"));
    var fee = minor(source.get("refundableFeeMinor"));
    var courseRefunded =
        source.get("courseRefundedMinor") == null
            ? BigInteger.ZERO
            : minor(source.get("courseRefundedMinor"));
    var goodsRefunded =
        source.get("goodsRefundedMinor") == null
            ? totalRefunded.subtract(courseRefunded)
            : minor(source.get("goodsRefundedMinor"));
    if (!java.util.Set.of("GOODS_ONLY_V1", "CONTINUATION_NO_REFUND_V1").contains(policy)
        || fee.signum() != 0
        || goods.compareTo(due) > 0
        || due.compareTo(paid) != 0
        || goodsRefunded.signum() != 0
        || !goodsRefunded.add(courseRefunded).equals(totalRefunded)
        || ("CONTINUATION_NO_REFUND_V1".equals(policy) && goods.signum() != 0)) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    var granted = milli(grantedUnits);
    var reserved = milli(reservedUnits);
    var completed = milli(completedRefundedUnits);
    if (granted.signum() <= 0
        || reserved.signum() <= 0
        || completed.add(reserved).compareTo(granted) > 0
        || (completed.signum() == 0) != (courseRefunded.signum() == 0)) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    // 已成功金额必须能由已完成课时支撑；现金已成功而教学尚未确认时禁止准备下一笔。
    var previousLimit = goods.multiply(completed).divide(granted);
    if (courseRefunded.compareTo(previousLimit) > 0) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    return goods
        .multiply(completed.add(reserved))
        .divide(granted)
        .min(paid)
        .subtract(courseRefunded)
        .toString();
  }
}
