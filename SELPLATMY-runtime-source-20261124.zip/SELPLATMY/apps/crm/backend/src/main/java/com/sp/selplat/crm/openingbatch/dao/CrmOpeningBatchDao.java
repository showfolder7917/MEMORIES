/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.openingbatch.dao;

import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmOpeningBatchDao extends com.sp.selplat.common.db.dao.BaseDao {

  /**
   * 本表精确范围锁；缺CRM事务拒绝。
   *
   * @param input tenant92/org901/id1000000
   * @return 实际行或null；不构造默认主数据
   */
  Map<String, Object> lockScoped(CommonParam input);

  /**
   * 方法作用：按本组织创建键读取真实资金期初回执，不连接其他表。
   *
   * @param input 真实tenant92/org901/requestKey opening-1
   * @return 真实示例：原期初id900000或null；不构造默认期初。 异常或副作用示例：连接失败传播，不写业务。
   */
  Map<String, Object> fundsCreation(CommonParam input);

  /**
   * 方法作用：保存原期初及同一行资金维护历史，更新使用原状态与版本CAS。
   *
   * @param input 已核拥有方参数，例如id900000/expectedVersion0/openingStateSUBMITTED
   * @param create true建立草稿；false更新原未生效行
   * @return 真实返回示例：影响1；旧版本影响0，调用方须回滚。 异常或副作用示例：唯一冲突传播，不写账户余额。
   */
  int saveFunds(CommonParam input, boolean create);

  /**
   * 方法作用：本组织资金期初分页，只查本表实际资金来源非空行。
   *
   * @param input 真实tenant92/org901/pageNo1/pageSize20
   * @return 真实示例：records一行、totalCount1，固定id倒序。 异常或副作用示例：SQL失败传播，不返回伪造空成功。
   */
  com.sp.selplat.common.util.CommonPageResult fundsPage(
      com.sp.selplat.common.util.CommonPageParam input);
}
