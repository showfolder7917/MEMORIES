/** CrmFundsBalanceService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.fundsbalance.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;

/** 本人隔离过账记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmFundsBalanceService extends BaseService {
    /**
     * 本表原子流程扩展 lockScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 applyDeltaIfVersion，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖 成功条件更新恰好一行。
     *     异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    void applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input);

    /**
     * Actual scoped receipt balance.
     *
     * @param input org901/account90101/CNY
     * @return real row; missing scope/balance rejects
     */
    java.util.Map<String, Object> lockOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * Add a positive exact aggregate to the real ledger.
     *
     * @param input actual id/version/amountMinor135 权限或CAS失败由外层整批回滚，不生成默认余额。
     */
    void receiveOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * Actual organization balance query.
     *
     * @param input org901/page1
     * @return exact minor text rows, no browser numeric arithmetic
     */
    com.sp.selplat.common.util.CommonPageResult organizationStore(
            com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 方法作用：真实权限下减除原收款聚合金额。
     *
     * @param input org901/id980001/version1/amount135 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    void reverseOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * 方法作用：owning余额按当前指定动作锁真实账户。
     *
     * @param input org901/account90101/CNY
     * @param action crm.funds.reverse
     * @return 实际余额和CAS版本，无创建 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    java.util.Map<String, Object> lockForFundsAction(
            com.sp.selplat.common.util.CommonParam input, String action);

    /**
     * 采购付款本组织非负扣款CAS，仅内部业务记账。
     *
     * @param input org901/id980001/version0/amount135，资金post许可再次核验
     *     异常或副作用示例：1000扣135得865；不足或旧版本整批回滚，不连接银行。
     */
    void payOrganization(com.sp.selplat.common.util.CommonParam input);

    /**
     * 从真实已审核退款完整冲正恢复内部现金；例如原退款2分，现金1003→1005，版本增加；不连接银行。
     *
     * @param input org901/id980001/version3/amountMinor2，许可重新核验
     */
    void restoreRefundOrganization(CommonParam input);

    /**
     * 方法作用：按原期初实际批准结果建立余额，仅具名同库业务内部调用。
     * @param input 原期初引用，例如org901/id900000；不接受金额或审核人。
     * 异常或副作用示例：批准期初0生成余额0；已有任何余额拒绝，外层审核回滚。
     */
    void initializeApprovedOpening(CommonParam input);

}
