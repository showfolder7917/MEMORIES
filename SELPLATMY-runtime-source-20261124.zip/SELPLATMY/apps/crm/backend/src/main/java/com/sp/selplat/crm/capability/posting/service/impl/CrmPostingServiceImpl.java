/** CrmPostingServiceImpl.java：登录后的单据预检，不执行过账。 修改记录：2026-10-03，Codex 按委托落实服务调用与无写入结果。 */
package com.sp.selplat.crm.capability.posting.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.capability.posting.service.CrmPostingService;
import com.sp.selplat.crm.common.util.posting.CrmPostingPreflightSupport;

import org.springframework.stereotype.Service;

/** 无状态非持久化能力；真实身份校验后计算预检，不能替代实际库事实/权限/事务。 */
@Service
public class CrmPostingServiceImpl implements CrmPostingService {
    // 复用统一身份回查，不接收客户端操作员或增加任何动作权限。
    private final CrmAccessService accessService;

    /**
     * 绑定本域真实准入服务。
     *
     * @param accessService Spring 的 CrmAccessServiceImpl 返回示例：构造实例；不查询数据库或创建业务记录。
     */
    public CrmPostingServiceImpl(CrmAccessService accessService) {
        this.accessService = accessService;
    }

    /**
     * 回查有效身份后计算单据预检；客户端 state/requestState 不作为已核验事实。
     *
     * @param input 公共参数，例如 {kind:SALES_ORDER,state:DRAFT,action:SUBMIT}
     * @return
     *     {success:true,data:{from:DRAFT,to:SUBMITTED,writeEnabled:false,factsVerified:false}}，affectedRows
     *     保持 null
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名、失效身份、非法状态或数值拒绝；不写库
     */
    @Override
    @OperationLog
    public CommonResult preview(CommonParam input) {
        // 登录只允许使用无副作用预检，不构成组织或库存/资金写权限。
        accessService.requireDraftActor();
        CommonResult result = new CommonResult();
        result.setSuccess(true);
        result.setData(
                CrmPostingPreflightSupport.preview(input == null ? null : input.getParamMap()));
        result.setMsg("预检完成；未核验数据库事实，未执行业务写入。");
        return result;
    }

    // 非持久化编排只调用 owning service，不直接调用跨表DAO或构造独立连接。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingdocument.service.CrmPostingDocumentService documents;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService requests;

    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmPostingWriteEnabled")
    private Boolean postingWriteEnabled;

    /**
     * 执行或读取数据库唯一请求已提交的首次结果，失败事务结束后才查询重放。
     *
     * @param input 严格单动作参数，例如{id:102,action:POST,requestKey:r1,expectedVersion:0}
     * @return CommonResult，真实首次结果或{documentId:102,state:POSTED,entryId:100001,replay:true}
     *     异常或副作用示例：生产/文件库/身份失效/内容冲突拒绝；仅请求唯一冲突可重放，其他异常不吞掉。
     */
    @Override
    @OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
    public CommonResult execute(CommonParam input) {
        accessService.requireDraftActor();
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.enabled(postingWriteEnabled);
        CommonParam normalized =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.request(input);
        try {
            return documents.executeAtomic(normalized);
        } catch (com.sp.selplat.common.exception.CommonBusinessException conflict) {
            if (!"POSTING_REQUEST_EXISTS".equals(conflict.getErrorCode())) {
                throw conflict;
            }
            // REQUIRES_NEW 原子流程已因异常回滚，重放读取使用另一独立只读逻辑事务。
            java.util.Map<String, Object> stored =
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                            requests.readCommittedRequest(normalized));
            if (!com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.hash(normalized)
                    .equals(stored.get("payloadHash"))) {
                throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                        "POSTING_REQUEST_CONFLICT");
            }
            if (!"COMPLETED".equals(stored.get("requestState"))) {
                throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                        "POSTING_REQUEST_IN_PROGRESS");
            }
            java.util.Map<String, Object> replay = new java.util.LinkedHashMap<>();
            replay.put("documentId", stored.get("documentId"));
            replay.put("state", stored.get("resultState"));
            replay.put("entryId", stored.get("resultEntryId"));
            replay.put("replay", true);
            CommonResult result = new CommonResult();
            result.setSuccess(true);
            result.setData(replay);
            result.setMsg("读取首次提交结果，未重复扣减。");
            return result;
        }
    }
}
