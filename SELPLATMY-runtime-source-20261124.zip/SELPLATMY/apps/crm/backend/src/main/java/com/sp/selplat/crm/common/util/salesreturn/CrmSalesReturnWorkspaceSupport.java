/** 一期销售退货退款页面配置；2026-10-04，Codex；只复用既有SELUI。 */
package com.sp.selplat.crm.common.util.salesreturn;

import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 服务器提供三语业务字段和真实原明细选择槽，不创建账务或第三方组件。 */
public final class CrmSalesReturnWorkspaceSupport {
    /** 不允许实例化无状态配置工具；不建立库存、现金或权限。 */
    private CrmSalesReturnWorkspaceSupport() {
        // 静态消费实际业务结果，只配置公共组件。
    }

    /**
     * 获取本域已经构造的Map；只用于服务器配置，不解析不可信客户端对象。
     *
     * @param value 实际workspace.headerForm等固定Map
     * @return 可修改独立Map，例如{title:销售退货入库,slots:[lineForm,lineGrid]}
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> copy(Object value) {
        return new LinkedHashMap<>((Map<String, Object>) value);
    }

    /**
     * 在现有真实工作区上配置明确退货或商品退款，不复制公共SELUI组件。
     *
     * @param result 实际库存/资金owning聚合结果，不含假业务记录
     * @param requested 三语候选例如zh-CN/en-US/ja-JP
     * @param returnsMode true为明确SALES_RETURN页面
     * @param cash true为商品现金退款，false为销售退货入库
     * @param enabled 实际本域服务器退货结构门禁
     * @return 原真实工作区加字段槽，例如reason SALES_RETURN、原出库引用Grid；旧页面只加可用入口标识
     */
    @SuppressWarnings("unchecked")
    public static CommonResult decorate(
            CommonResult result,
            Object requested,
            boolean returnsMode,
            boolean cash,
            boolean enabled) {
        var data = (Map<String, Object>) result.getData();
        data.put("salesReturnAvailable", enabled);
        data.put("salesReturnMode", returnsMode);
        int locale = "en-US".equals(requested) ? 1 : "ja-JP".equals(requested) ? 2 : 0;
        data.put(
                "openSalesReturn",
                new String[] {"销售退货入库", "Sales return receipt", "販売返品入庫"}[locale]);
        data.put(
                "openSalesRefund", new String[] {"销售商品退款", "Sales goods refund", "販売商品返金"}[locale]);
        if (!returnsMode) {
            return result;
        }
        if (!enabled) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
        var labels = new LinkedHashMap<>((Map<String, String>) data.get("labels"));
        labels.put(
                "title",
                cash
                        ? new String[] {
                                    "销售商品退款与资金流水",
                                    "Sales goods refunds and cash ledger",
                                    "販売商品返金と資金台帳"
                                }
                                [locale]
                        : new String[] {
                                    "销售退货入库与库存流水",
                                    "Sales return receipts and stock ledger",
                                    "販売返品入庫と在庫台帳"
                                }
                                [locale]);
        labels.put("orderId", new String[] {"原销售订单", "Original sales order", "元販売注文"}[locale]);
        labels.put(
                "new",
                cash
                        ? new String[] {"新建商品退款单", "New goods refund", "新規商品返金"}[locale]
                        : new String[] {"新建销售退货单", "New sales return", "新規販売返品"}[locale]);
        labels.put(
                "post",
                cash
                        ? new String[] {"明确记账退款", "Post internal refund", "返金内部転記"}[locale]
                        : new String[] {"明确过账退货入库", "Post returned goods", "返品入庫転記"}[locale]);
        labels.put(
                "baseIssueDetailId",
                new String[] {"原出库明细", "Original issue detail", "元出庫明細"}[locale]);
        labels.put(
                "baseReceiptDetailId",
                new String[] {"原收款明细", "Original receipt detail", "元入金明細"}[locale]);
        labels.put(
                "baseReturnDetailId",
                new String[] {"已入库退货明细", "Received return detail", "入庫済返品明細"}[locale]);
        labels.put(
                "remainingQuantity",
                new String[] {"剩余可退EA", "Remaining return EA", "返品可能残EA"}[locale]);
        labels.put(
                "remainingMinor",
                new String[] {"剩余分配额度MINOR", "Remaining allocation MINOR", "残配分MINOR"}[locale]);
        labels.put(
                "references",
                new String[] {
                            "真实原单与剩余额度",
                            "Real original records and remaining capacity",
                            "実際の元記録と残容量"
                        }
                        [locale]);
        labels.put(
                "stockReturnedQuantity",
                new String[] {"已入库退货EA", "Returned goods EA", "返品入庫済EA"}[locale]);
        labels.put(
                "goodsEntitlementMinor",
                new String[] {"已冻结商品退款权益MINOR", "Frozen goods entitlement MINOR", "確定商品返金権利MINOR"}
                        [locale]);
        labels.put(
                "cashRefundedMinor",
                new String[] {"已记账退款MINOR", "Refund posted MINOR", "返金転記済MINOR"}[locale]);
        labels.put(
                "refundableRemainingMinor",
                new String[] {"剩余可退款MINOR", "Remaining refundable MINOR", "返金可能残MINOR"}[locale]);
        data.put("labels", labels);
        var sourceGrid = copy(data.get("sourceLines"));
        sourceGrid.put(
                "column",
                Map.of(
                        "items",
                        (cash
                                        ? List.of(
                                                "productNameSnapshot",
                                                "stockReturnedQuantity",
                                                "goodsEntitlementMinor",
                                                "cashRefundedMinor",
                                                "refundableRemainingMinor")
                                        : List.of("productNameSnapshot", "remainingQuantity"))
                                .stream()
                                        .map(
                                                field ->
                                                        Map.of(
                                                                "id",
                                                                field,
                                                                "field",
                                                                field,
                                                                "label",
                                                                labels.get(field)))
                                        .toList()));
        data.put("sourceLines", sourceGrid);
        data.put("title", labels.get("title"));
        data.put("reason", "SALES_RETURN");
        data.put("documentKind", cash ? "FUNDS_PAYMENT" : "STOCK_RECEIPT");
        data.put(
                "notice",
                cash
                        ? new String[] {
                                    "仅商品净额退款内部记账；费用不退，不执行真实付款，生产未开放。",
                                    "Goods-only internal refund ledger; fees remain, no actual"
                                            + " payout. Production disabled.",
                                    "商品純額のみ内部返金記帳。費用非返金、実送金なし。本番未開放。"
                                }
                                [locale]
                        : new String[] {
                                    "严格引用真实原出库；退货不释放再次发货额度，商品退款权益累计冻结，生产未开放。",
                                    "Real original issue required; returns do not reopen shipping"
                                            + " capacity. Goods entitlement frozen. Production"
                                            + " disabled.",
                                    "実際の元出庫を参照。返品で再出荷枠は戻らず、商品返金権利を累計凍結。本番未開放。"
                                }
                                [locale]);
        if (cash && data.get("reversalForm") instanceof Map<?, ?>) {
            var reversal = copy(data.get("reversalForm"));
            reversal.put(
                    "title",
                    new String[] {"商品退款整批冲正", "Full goods refund reversal", "商品返金の全額反対仕訳"}[locale]);
            var reversalFields = new java.util.ArrayList<Map<String, Object>>();
            for (var field : (List<Map<String, Object>>) reversal.get("fields")) {
                var changed = new LinkedHashMap<String, Object>(field);
                if ("settledDeltaMinor".equals(changed.get("id"))) {
                    changed.put("id", "refundedDeltaMinor");
                    changed.put(
                            "label",
                            new String[] {"累计退款变化MINOR", "Refund total change MINOR", "累計返金変化MINOR"}
                                    [locale]);
                }
                reversalFields.add(changed);
            }
            reversal.put("fields", reversalFields);
            data.put("reversalForm", reversal);
        }
        var states = new LinkedHashMap<>((Map<String, String>) data.get("states"));
        states.put(
                "POSTED",
                cash
                        ? new String[] {"已记账商品退款", "Goods refund posted", "商品返金転記済み"}[locale]
                        : new String[] {"已入库销售退货", "Sales return received", "販売返品入庫済み"}[locale]);
        data.put("states", states);
        var documentGrid = copy(data.get("documents"));
        var documentData = copy(documentGrid.get("data"));
        documentData.put(
                "items",
                ((List<Map<String, Object>>) documentData.get("items"))
                        .stream()
                                .map(
                                        item -> {
                                            var row = new LinkedHashMap<>(item);
                                            row.put(
                                                    "documentStateLabel",
                                                    states.get(
                                                            String.valueOf(
                                                                    item.get("documentState"))));
                                            return row;
                                        })
                                .toList());
        documentGrid.put("data", documentData);
        data.put("documents", documentGrid);
        var header = copy(data.get("headerForm"));
        header.put("title", labels.get("title"));
        header.put(
                "fields",
                List.of(Map.of("id", "orderId", "label", labels.get("orderId"), "readOnly", true)));
        header.put(
                "actions",
                List.of("new", "reload", "saveDraft", "submit", "approve", "post").stream()
                        .map(id -> Map.of("id", id, "label", labels.get(id)))
                        .toList());
        data.put("headerForm", header);
        var lineForm = copy(data.get("lineForm"));
        var fields = new ArrayList<>((List<Map<String, Object>>) lineForm.get("fields"));
        for (String name :
                cash
                        ? List.of("baseReceiptDetailId", "baseReturnDetailId")
                        : List.of("baseIssueDetailId")) {
            fields.add(Map.of("id", name, "label", labels.get(name), "readOnly", true));
        }
        lineForm.put("fields", fields);
        data.put("lineForm", lineForm);
        var references = copy(data.get("referenceForm"));
        var slots = new ArrayList<>((List<String>) references.get("slots"));
        slots.addAll(
                cash
                        ? List.of("receiptReferenceGrid", "returnReferenceGrid")
                        : List.of("issueReferenceGrid"));
        references.put("slots", slots);
        references.put("title", labels.get("references"));
        data.put("referenceForm", references);
        data.put("issueReferences", referencesGrid(List.of(), 0, 1, requested, "ISSUE_RETURN"));
        data.put("receiptReferences", referencesGrid(List.of(), 0, 1, requested, "RECEIPT_REFUND"));
        data.put("returnReferences", referencesGrid(List.of(), 0, 1, requested, "RETURN_REFUND"));
        return result;
    }

    /**
     * 真实原明细选择的公共Grid配置，独立REMOTE20行分页。
     *
     * @param records 本页真实可用原明细，例如id1300000/remainingQuantity2
     * @param total 实际可用候选总数，例如21
     * @param page 实际页号例如2
     * @param requested 三语候选例如zh-CN
     * @param kind 固定ISSUE_RETURN/RECEIPT_REFUND/RETURN_REFUND
     * @return 公共Grid原生配置，例如items1条、REMOTE total21/page2/pageSize20，空输入只是未选来源
     */
    public static Map<String, Object> referencesGrid(
            List<Map<String, Object>> records, int total, int page, Object requested, String kind) {
        int locale = "en-US".equals(requested) ? 1 : "ja-JP".equals(requested) ? 2 : 0;
        boolean stock = "ISSUE_RETURN".equals(kind);
        String title =
                stock
                        ? new String[] {
                                    "原出库明细与可退数量",
                                    "Original issues and returnable quantities",
                                    "元出庫明細と返品可能量"
                                }
                                [locale]
                        : "RECEIPT_REFUND".equals(kind)
                                ? new String[] {
                                            "原收款明细与剩余额度",
                                            "Original receipts and remaining capacity",
                                            "元入金明細と残容量"
                                        }
                                        [locale]
                                : new String[] {
                                            "已入库退货与商品退款额度",
                                            "Received returns and goods refund capacity",
                                            "入庫済返品と商品返金枠"
                                        }
                                        [locale];
        var labels =
                Map.of(
                        "id",
                        new String[] {"明细编号", "Detail number", "明細番号"}[locale],
                        "documentId",
                        new String[] {"原单编号", "Original document", "元伝票番号"}[locale],
                        "remainingQuantity",
                        new String[] {"可退EA", "Returnable EA", "返品可能EA"}[locale],
                        "remainingMinor",
                        new String[] {"剩余MINOR", "Remaining MINOR", "残MINOR"}[locale]);
        var result = new LinkedHashMap<String, Object>();
        result.put("grid", Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id"));
        result.put("data", Map.of("items", records, "selectedIds", List.of()));
        result.put(
                "column",
                Map.of(
                        "items",
                        List.of("id", "documentId", stock ? "remainingQuantity" : "remainingMinor")
                                .stream()
                                .map(
                                        field ->
                                                Map.of(
                                                        "id",
                                                        field,
                                                        "field",
                                                        field,
                                                        "label",
                                                        labels.get(field)))
                                .toList()));
        result.put("title", Map.of("messages", Map.of("selectProject", title)));
        result.put(
                "pagination",
                Map.of(
                        "mode",
                        "REMOTE",
                        "visible",
                        true,
                        "totalCount",
                        total,
                        "currentPage",
                        page,
                        "pageSize",
                        20,
                        "previousLabel",
                        new String[] {"上一页", "Previous", "前へ"}[locale],
                        "nextLabel",
                        new String[] {"下一页", "Next", "次へ"}[locale],
                        "summaryAll",
                        new String[] {"共 {total} 条", "{total} records", "合計 {total} 件"}[locale]));
        return result;
    }
}
