/** CrmCustomerDraftDao.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.customerdraft.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** 本人客户草稿 DAO 仅继承公共门面，不建立重复 CRUD 方法。 */
public interface CrmCustomerDraftDao extends BaseDao {
    /**
     * 锁本人有效客户；参数例如id101/tenant92/owner9211；返回真实行或null；须CRM事务，不写库。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：锁本人有效客户；参数例如id101/tenant92/owner9211；返回真实行或null；须CRM事务，不写库。
     * @return 真实行或null
     */
    java.util.Map<String, Object> lockForPosting(com.sp.selplat.common.util.CommonParam input);
}
