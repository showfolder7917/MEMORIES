/** CrmOrderLine：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.orderline.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import java.util.List;
import java.util.Map;

/** 本表owning接口，不暴露通用无版本业务写。 */
public interface CrmOrderLineService extends BaseService {
    /**
     * 读取本订单所有真实行；org901/order600000及固定动作；返回稳定lineNo顺序，不截断。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：读取本订单所有真实行；org901/order600000及固定动作；返回稳定lineNo顺序，不截断。
     * @param action 服务内部选择的固定动作，例如crm.order.write；不得据客户端动作补授权限。
     * @return 稳定lineNo顺序，不截断
     */
    List<Map<String, Object>> readForOrder(CommonParam input, String action);

    /**
     * 头锁保护下完整更新草稿行；org901/order600000/全部服务端定价行；返回实际行ID及输入快照；失败整笔回滚。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：头锁保护下完整更新草稿行；org901/order600000/全部服务端定价行；返回实际行ID及输入快照；失败整笔回滚。
     * @return 实际行ID及输入快照
     */
    List<Map<String, Object>> replaceDraft(CommonParam input);

  /**
   * 方法作用：订单读取许可内批量取得本页订单商品快照与数量，不依赖参考选择器第一页。
   *
   * @param organizationCandidateId 原经营组织候选，例如901，不接受客户端租户
   * @param ids 本页确定的主键，例如[600000]，最多100项
   * @return 真实示例：本组织安全字段集合；缺失引用不伪造名称或商品
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无原读取资格或主键非法时拒绝，零写入
   */
  java.util.List<java.util.Map<String, Object>> orderListItems(
      Object organizationCandidateId, java.util.List<Long> ids);
}
