/* 可定制客户分类合同；2026-10-26。 */
package com.sp.selplat.crm.customertype.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 分类属于CRM经营组织；不是用户角色或权限。 */
public interface CrmCustomerTypeService extends BaseService {
    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/id100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    CommonResult history(CommonParam input);

    /**
     * 方法作用：读取本组织分类；可选包含停用项以维护历史引用。
     * @param input 明确组织候选，例如organizationCandidateId=901/includeDisabled=true
     * @return 真实返回示例：data.types=[{id:"100000",typeName:"家长",enabledFlag:true,versionNo:"0"}]
     * 异常或副作用示例：无原客户读取许可拒绝；超过500项要求维护范围，零写入。
     */
    CommonResult directory(CommonParam input);

    /**
     * 方法作用：保存自定义类型，复用原客户写范围，保留版本历史及重试结果。
     * @param input 候选，例如org901/requestKey=type-1/typeName=校友/enabledFlag=true/sortnum=0
     * @return 真实返回示例：data={id:"100000",versionNo:"0",replay:false}；重试replay=true
     * 异常或副作用示例：同组织重名、旧版或同键异内容回滚；停用不删除类型。
     */
    CommonResult save(CommonParam input);
    /**
     * 方法作用：在调用者CRM事务中锁定一个本组织类型，供客户选择校验。
     * @param input 服务间候选，例如organizationCandidateId901/id100000
     * @return 真实返回示例：{id:"100000",typeName:"家长",enabledFlag:true,versionNo:"0",sortnum:0}。
     * 异常或副作用示例：无原客户写许可、越组织或无CRM事务拒绝，不公开HTTP入口。
     */
    java.util.Map<String, Object> lockForSelection(CommonParam input);
}
