/**
 * CrmBusinessAuditDao.java：CRM经营组织客户维护本表组件。
 * 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
package com.sp.selplat.crm.businessaudit.dao;
/** 本表复用公共DAO，不访问业务主体或其他表DAO。 */
public interface CrmBusinessAuditDao extends com.sp.selplat.common.db.dao.BaseDao {
}
