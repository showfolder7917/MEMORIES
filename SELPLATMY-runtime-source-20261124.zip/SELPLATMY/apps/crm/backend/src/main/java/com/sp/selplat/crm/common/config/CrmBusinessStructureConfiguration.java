/**
 * CRM已安装结构的只读基础设施装配；2026-10-14，Codex；不建立业务Service或数据库上下文。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.common.config;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.exception.CommonSystemException;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 固定CRM池的元数据检查Bean归配置层，不查询业务行或自动升级结构。
 */
@Configuration(proxyBeanMethods = false)
public class CrmBusinessStructureConfiguration {

  /**
   * 方法作用：按已初始化的实际CRM池装配只读结构检查，供准入层限定模块。
   * @param source 具名crmDataSource，例如测试独立CRM内存库
   * @return 真实返回示例：检查器available包含已安装partner/order；不代表动作许可。
   * 异常或副作用示例：构造仅保存池引用，不执行DDL、业务读写或建立第二数据库上下文。
   */
  @Bean("crmBusinessStructureInspector")
  @DependsOn({"crmPartnerMaintenanceInitialized", "crmFormalCustomerOrderInitialized"})
  public CrmBusinessStructureInspector inspector(@Qualifier("crmDataSource") DataSource source) {
    return new CrmBusinessStructureInspector(source);
  }

  /**
   * 固定池上的只读字段/主键/约束检查，不对外提供业务CRUD。
   */
  public static final class CrmBusinessStructureInspector {

    // 只读CRM本域结构，不查询认证表或业务行。
    private final DataSource source;

    // 经营组织复合主键必须完整；旧owner表不能作为正式组织表。
    private static final Set<String> SCOPE_KEY = Set.of("tenantId", "businessOrgId", "id");

    /**
     * 方法作用：绑定CRM实际数据源，不在构造阶段修改数据库。
     * @param source 实际crmDataSource，例如已安装组织模式的独立CRM库
     * 异常或副作用示例：仅保留连接池引用，不创建业务表。
     */
    public CrmBusinessStructureInspector(DataSource source) {
      this.source = source;
    }

    /**
     * 方法作用：逐模块核验实际字段、组织复合主键及幂等唯一键，不凭配置布尔值判断已安装。
     * @return 真实返回示例：Set含partner/order；旧owner库存表不产生stock。
     * @throws CommonSystemException 实际结构读取失败传播，不伪报空目录或已安装
     */
    public Set<String> available() {
      var connection = org.springframework.jdbc.datasource.DataSourceUtils.getConnection(source);
      try {
        // 若已在CRM业务事务内，复用其绑定连接，避免另占池连接或提前关闭业务连接。
        DatabaseMetaData metadata = connection.getMetaData();
        String catalog = connection.getCatalog();
        String schema = connection.getSchema();
        Set<String> installed = new LinkedHashSet<>();
        boolean command =
            table(
                    metadata,
                    catalog,
                    schema,
                    "CrmCommandRequest",
                    "commandName,requestKey,payloadHash,requestState,resultPartnerId,resultContactId,"
                        + "resultOrderId,resultVersionNo,responseSnapshot")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmCommandRequest",
                    Set.of("tenantId", "businessOrgId", "commandName", "requestKey"));
        boolean audit =
            table(
                    metadata,
                    catalog,
                    schema,
                    "CrmBusinessAudit",
                    "commandRequestId,action,actorUserId,decisionId,resourceId,previousVersion,newVersion,synthetic")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmBusinessAudit",
                    Set.of("tenantId", "businessOrgId", "commandRequestId"));
        boolean partner =
            command
                && audit
                && commands(schema, Set.of("PARTNER_SAVE", "CONTACT_SAVE"))
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPartner",
                    "partnerKind,partnerName,customerRole,supplierRole,businessState,versionNo,receiverName,mobile,address,email")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmContact",
                    "partnerId,contactName,mobile,organizationText,businessState,versionNo");
        if (partner) {
          installed.add("partner");
        }
        // 商品维护需独立字段、编码唯一键和具名命令；旧商品表仍可服务订单读取。
        boolean product =
            command
                && audit
                && commands(schema, Set.of("PRODUCT_SAVE"))
                && table(metadata, catalog, schema, "CrmCommandRequest", "resultProductId")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmProduct",
                    "productCode,productName,specification,productKind,unitCode,purchasePriceMinor,"
                        + "salePriceMinor,businessState,versionNo,termUnit,termCount,renewalMode,activationSystemCode")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmProduct",
                    Set.of("tenantId", "businessOrgId", "productCode"))
                && allowedValues(schema, "CrmProduct", "productKind", Set.of("GOODS", "SERVICE"))
                && productResultForeignKey(metadata, catalog, schema);
        if (product) {
          installed.add("product");
        }
        boolean order =
            partner
                && commands(schema, Set.of("ORDER_SAVE", "ORDER_SUBMIT", "ORDER_APPROVE"))
                && table(
                    metadata, catalog, schema, "CrmProduct", "productName,unitCode,businessState")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmOrder",
                    "orderKind,partnerId,orderState,versionNo,currency,currencyScale,pricingPolicyVersion,refundPolicyVersion,"
                        + "subtotalMinor,discountMinor,feeMinor,totalMinor,refundableGoodsMinor,refundableFeeMinor,"
                        + "submittedByUserId,approvedByUserId,submittedAt,approvedAt,snapshotHash,frozenSnapshot")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmOrderLine",
                    "orderId,lineNo,productId,productNameSnapshot,unitCode,quantity,unitPriceMinor,discountBps,isGift,"
                        + "grossMinor,lineDiscountMinor,lineNetMinor,feeAllocatedMinor,approvedDueMinor");
        if (order) {
          installed.add("order");
        }
        boolean stock =
            order
                && table(metadata, catalog, schema, "CrmCommandRequest", "resultDocumentId")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmWarehouse",
                    "warehouseCode,warehouseName,businessState,versionNo")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmDocument",
                    "orderId,orderKind,documentKind,reason,documentState,versionNo,"
                        + "orderSnapshotHash,approvedSnapshotHash,frozenSnapshot,submittedByUserId,approvedByUserId")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmDocumentLine",
                    "documentId,sourceOrderLineId,lineNo,productId,warehouseId,quantity")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmStockBalance",
                    "warehouseId,productId,quantityUnit,openingBatchId,"
                        + "openingQuantity,quantity,versionNo")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmOrderLineProgress",
                    "orderLineId,authorizedQuantity,stockPostedQuantity,stockReturnedQuantity,versionNo")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingBatch",
                    "documentId,action,approvedSnapshotHash,detailCount")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingDetail",
                    "batchId,documentLineId,sourceOrderLineId")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingRequest",
                    "documentId,action,requestKey,requestState")
                && commands(schema, Set.of("DOCUMENT_SAVE", "DOCUMENT_SUBMIT", "DOCUMENT_APPROVE"))
                && allowedValues(schema, "CrmPostingBatch", "action", Set.of("POST"));
        if (stock) {
          installed.add("stock");
        }
        // 原收款必须具备真实账户、余额、现金明细、累计及幂等结构，不能由库存或登录推定。
        boolean funds =
            stock
                && commands(
                    schema,
                    Set.of(
                        "FUNDS_DOCUMENT_SAVE", "FUNDS_DOCUMENT_SUBMIT", "FUNDS_DOCUMENT_APPROVE"))
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmCashAccount",
                    "accountCode,accountName,accountKind,currency,currencyScale,businessState,versionNo")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmCashAccount",
                    Set.of("tenantId", "businessOrgId", "accountCode"))
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmFundsBalance",
                    "accountId,currency,openingBatchId,openingMinor,amountMinor,versionNo")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmFundsBalance",
                    Set.of("tenantId", "businessOrgId", "accountId", "currency"))
                && table(metadata, catalog, schema, "CrmDocument", "currency")
                && allowedValues(
                    schema, "CrmDocument", "documentKind", Set.of("FUNDS_RECEIPT", "FUNDS_PAYMENT"))
                && table(
                    metadata, catalog, schema, "CrmDocumentLine", "accountId,currency,amountMinor")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingDetail",
                    "effectKind,fundsBalanceId,accountId,currency,amountDeltaMinor")
                && allowedValues(schema, "CrmPostingDetail", "effectKind", Set.of("CASH"))
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmOrderLineProgress",
                    "authorizedMinor,cashSettledMinor,cashRefundedMinor")
                && table(metadata, catalog, schema, "CrmBusinessAudit", "postingRequestId,batchId")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingRequest",
                    Set.of("tenantId", "businessOrgId", "action", "requestKey"))
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmBusinessAudit",
                    Set.of("tenantId", "businessOrgId", "postingRequestId"))
                && parents(metadata, catalog, schema, "CrmDocumentLine", Set.of("CrmCashAccount"))
                && parents(metadata, catalog, schema, "CrmPostingDetail", Set.of("CrmFundsBalance"))
                && parents(
                    metadata,
                    catalog,
                    schema,
                    "CrmBusinessAudit",
                    Set.of("CrmPostingRequest", "CrmPostingBatch"));
        if (funds) {
          installed.add("funds");
        }
        boolean courseRefund =
            funds
                && table(metadata, catalog, schema, "CrmOrderLineProgress", "courseRefundedMinor")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmDocumentLine",
                    "courseReservationId,courseStudentId,curriculumCourseId,courseQuoteHash")
                && unique(
                    metadata,
                    catalog,
                    schema,
                    "CrmDocumentLine",
                    Set.of("tenantId", "businessOrgId", "courseReservationId"))
                && allowedValues(schema, "CrmDocument", "reason", Set.of("COURSE_RETURN"));
        if (courseRefund) {
          installed.add("courseRefund");
        }
        boolean returns =
            stock
                && allowedValues(schema, "CrmDocument", "reason", Set.of("SALES_RETURN"))
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingCapacity",
                    "originalDetailId,capacityKind,capacityQuantity,usedQuantity,versionNo")
                && table(
                    metadata,
                    catalog,
                    schema,
                    "CrmPostingDependency",
                    "childDetailId,parentDetailId,dependencyKind");
        if (returns) {
          installed.add("salesReturn");
        }
        if (returns
            && table(
                metadata,
                catalog,
                schema,
                "CrmStockReversalRequest",
                "originalDocumentId,originalBatchId,"
                    + "originalDocumentVersion,originalSnapshotHash,originalBatchDigest,totalQuantity,reasonText,requestState,"
                    + "submittedByUserId,approvedByUserId,executedByUserId,resultBatchId,resultAction,versionNo")
            && commands(schema, Set.of("STOCK_REVERSAL_REQUEST", "STOCK_REVERSAL_APPROVE"))
            && table(metadata, catalog, schema, "CrmCommandRequest", "resultStockReversalRequestId")
            && allowedValues(schema, "CrmPostingBatch", "action", Set.of("POST", "REVERSE"))
            && allowedValues(schema, "CrmDocument", "documentState", Set.of("REVERSED"))) {
          installed.add("stockReversal");
        }
        if (order
            && table(
                metadata,
                catalog,
                schema,
                "CrmOrderAttachment",
                "orderId,orderVersion,ownerUserId,fileId,sha256,byteSize,versionNo,commandRequestId")
            && commands(schema, Set.of("ORDER_FILE_BIND"))) {
          installed.add("orderAttachment");
        }
        return Set.copyOf(installed);
      } catch (SQLException failure) {
        throw new CommonSystemException("CRM_STRUCTURE_READ_FAILED", "无法核验CRM业务结构。", failure);
      } finally {
        org.springframework.jdbc.datasource.DataSourceUtils.releaseConnection(connection, source);
      }
    }

    /**
     * 方法作用：按本域固定动作拒绝未安装模块，实际许可仍由统一owner独立核验。
     * @param action 服务器固定动作，例如crm.order.read
     * 异常或副作用示例：旧owner库存或缺版本字段抛CRM_SCOPE_UNAVAILABLE，不查业务行。
     * @throws CommonBusinessException 模块未安装或未知动作拒绝
     */
    public void require(String action) {
      if (action == null) {
        throw new CommonBusinessException("CRM_ACTION_FORBIDDEN", "未知CRM动作。");
      }
      String capability =
          action.startsWith("crm.product.")
              ? "product"
              : action.startsWith("crm.partner.") || action.equals("crm.audit.read")
                  ? "partner"
                  : action.startsWith("crm.funds.")
                      ? "funds"
                      : action.startsWith("crm.order.")
                          ? "order"
                          : action.equals("crm.stock.reverse")
                              ? "stockReversal"
                              : action.startsWith("crm.stock.") ? "stock" : "";
      if (!available().contains(capability)) {
        throw new CommonBusinessException("CRM_SCOPE_UNAVAILABLE", "当前环境尚未安装该CRM业务结构。");
      }
    }

    /**
     * 方法作用：资金扩展必须保留现金父记录关系；完整范围前缀仍由table的foreignKeys统一核验。
     * @param metadata 实际CRM连接元数据，例如H2
     * @param catalog 当前实际库，例如formal_funds_crm
     * @param schema 当前模式，例如PUBLIC
     * @param table 原固定资金表，例如CrmDocumentLine
     * @param required 原拥有方要求的父表，例如CrmCashAccount
     * @return 真实示例：资金单据行确实引用CrmCashAccount时true，删除该外键后false。
     * 异常或副作用示例：只读元数据，不补建缺失外键或查业务记录。
     * @throws SQLException 元数据读取失败保留原驱动异常
     */
    private boolean parents(
        DatabaseMetaData metadata,
        String catalog,
        String schema,
        String table,
        Set<String> required)
        throws SQLException {
      var actual = new LinkedHashSet<String>();
      try (var rows = metadata.getImportedKeys(catalog, schema, table)) {
        while (rows.next()) {
          actual.add(rows.getString("PKTABLE_NAME"));
        }
      }
      return actual.containsAll(required);
    }

    /**
     * 商品维护回执必须以完整组织复合键引用商品，不能只凭同名结果字段启用。
     * @param metadata 当前真实数据库元数据，例如H2
     * @param catalog 当前catalog，例如PRODUCT_UI
     * @param schema 当前schema，例如PUBLIC
     * @return 实际示例：tenant/org/resultProductId到商品tenant/org/id时true，否则false
     * @throws SQLException 元数据读取失败；不创建或修复外键
     */
    private boolean productResultForeignKey(
        DatabaseMetaData metadata, String catalog, String schema) throws SQLException {
      var keys = new LinkedHashMap<String, Map<String, String>>();
      try (var rows = metadata.getImportedKeys(catalog, schema, "CrmCommandRequest")) {
        while (rows.next()) {
          if ("CrmProduct".equals(rows.getString("PKTABLE_NAME"))) {
            keys.computeIfAbsent(rows.getString("FK_NAME"), key -> new LinkedHashMap<>())
                .put(rows.getString("FKCOLUMN_NAME"), rows.getString("PKCOLUMN_NAME"));
          }
        }
      }
      return keys.values().stream()
          .anyMatch(
              key ->
                  key.equals(
                      Map.of(
                          "tenantId",
                          "tenantId",
                          "businessOrgId",
                          "businessOrgId",
                          "resultProductId",
                          "id")));
    }

    /**
     * 方法作用：核验实际字段集合与经营组织复合主键，不将同名旧owner表当新结构。
     * @param metadata 真实连接的元数据，例如当前H2 schema
     * @param catalog 当前catalog，例如CRM_FORMAL_HTTP
     * @param schema 当前schema，例如PUBLIC
     * @param name 本域固定表，例如CrmPartner
     * @param fields 本域所需字段，例如partnerName,versionNo
     * @return 真实返回示例：完整字段及tenant/org/id主键为true；缺versionNo为false。
     * @throws SQLException 实际元数据读取失败
     */
    private boolean table(
        DatabaseMetaData metadata, String catalog, String schema, String name, String fields)
        throws SQLException {
      Set<String> columns = new LinkedHashSet<>();
      try (var rows = metadata.getColumns(catalog, schema, name, null)) {
        while (rows.next()) {
          columns.add(rows.getString("COLUMN_NAME"));
        }
      }
      Set<String> expected = new LinkedHashSet<>(SCOPE_KEY);
      expected.addAll(
          Set.of(
              "createdByUserId",
              "updatedByUserId",
              "lastOperateUserId",
              "status",
              "sortnum",
              "createdAt",
              "updatedAt"));
      if (!name.equals("CrmOrderAttachment")) {
        expected.addAll(Set.of("labelZh", "labelJa", "labelEn"));
      }
      expected.addAll(java.util.List.of(fields.split(",")));
      if (!columns.containsAll(expected)) {
        return false;
      }
      Set<String> primary = new LinkedHashSet<>();
      try (var rows = metadata.getPrimaryKeys(catalog, schema, name)) {
        while (rows.next()) {
          primary.add(rows.getString("COLUMN_NAME"));
        }
      }
      return primary.equals(SCOPE_KEY) && foreignKeys(metadata, catalog, schema, name);
    }

    /**
     * 方法作用：实际数据库唯一键必须覆盖完整幂等或审计坐标。
     * @param metadata 真实元数据，例如H2
     * @param catalog 当前catalog，例如CRM_FORMAL_HTTP
     * @param schema 当前schema，例如PUBLIC
     * @param table 固定表，例如CrmCommandRequest
     * @param fields 完整唯一坐标，例如tenant/org/commandName/requestKey
     * @return 真实返回示例：存在同集合唯一索引为true，缺唯一键为false。
     * @throws SQLException 实际唯一索引读取失败
     */
    private boolean unique(
        DatabaseMetaData metadata, String catalog, String schema, String table, Set<String> fields)
        throws SQLException {
      Map<String, Set<String>> indexes = new LinkedHashMap<>();
      try (var rows = metadata.getIndexInfo(catalog, schema, table, true, false)) {
        while (rows.next()) {
          String column = rows.getString("COLUMN_NAME");
          if (column != null) {
            indexes
                .computeIfAbsent(rows.getString("INDEX_NAME"), key -> new LinkedHashSet<>())
                .add(column);
          }
        }
      }
      return indexes.values().stream().anyMatch(fields::equals);
    }

    /**
     * 方法作用：按当前H2实际CHECK元数据确认新命令枚举已安装，不升级旧枚举。
     * @param schema 当前schema，例如PUBLIC
     * @param commands 服务器固定命令，例如ORDER_FILE_BIND
     * @return 真实返回示例：对应枚举CHECK含所需命令为true；旧枚举为false。
     * 异常或副作用示例：只读INFORMATION_SCHEMA；数据库失败传播，不执行DDL。
     */
    private boolean commands(String schema, Set<String> commands) {
      return allowedValues(schema, "CrmCommandRequest", "commandName", commands);
    }

    /**
     * 方法作用：只接受字段独立IN/等值CHECK的明确枚举，不能把条件表达式中的文字当已开放命令。
     * @param schema 当前schema，例如PUBLIC
     * @param table 固定本域表，例如CrmPostingBatch
     * @param field 固定字段，例如action
     * @param values 所需枚举，例如POST和REVERSE
     * @return 真实返回示例：明确action IN(POST,REVERSE)为true，仅POST为false。
     * 异常或副作用示例：只读元数据，不修改约束或版本。
     */
    private boolean allowedValues(String schema, String table, String field, Set<String> values) {
      var checks =
          new JdbcTemplate(source)
              .queryForList(
                  "SELECT cc.CHECK_CLAUSE FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS cc "
                      + "JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc ON cc.CONSTRAINT_CATALOG=tc.CONSTRAINT_CATALOG "
                      + "AND cc.CONSTRAINT_SCHEMA=tc.CONSTRAINT_SCHEMA AND cc.CONSTRAINT_NAME=tc.CONSTRAINT_NAME "
                      + "WHERE tc.TABLE_SCHEMA=? AND tc.TABLE_NAME=?",
                  schema,
                  table);
      String quotedField = java.util.regex.Pattern.quote(field);
      var enumeration =
          java.util.regex.Pattern.compile(
              "^\\(*\\s*\"?" + quotedField + "\"?\\s+IN\\s*\\(([^)]*)\\)\\s*\\)*$",
              java.util.regex.Pattern.CASE_INSENSITIVE);
      var equality =
          java.util.regex.Pattern.compile(
              "^\\(*\\s*\"?" + quotedField + "\"?\\s*=\\s*'([^']*)'\\s*\\)*$",
              java.util.regex.Pattern.CASE_INSENSITIVE);
      boolean found = false;
      for (var row : checks) {
        String clause = String.valueOf(row.get("CHECK_CLAUSE"));
        var list = enumeration.matcher(clause);
        var single = equality.matcher(clause);
        Set<String> declared = new LinkedHashSet<>();
        if (list.matches()) {
          var literals = java.util.regex.Pattern.compile("'([^']*)'").matcher(list.group(1));
          while (literals.find()) {
            declared.add(literals.group(1));
          }
        } else if (single.matches()) {
          declared.add(single.group(1));
        } else {
          continue;
        }
        found = true;
        if (!declared.containsAll(values)) {
          return false;
        }
      }
      return found;
    }

    /**
     * 方法作用：本域关联必须存在且携带完整租户/组织前缀，不接受只有id的跨范围外键。
     * @param metadata 实际数据库元数据，例如H2
     * @param catalog 当前catalog，例如CRM_FORMAL_HTTP
     * @param schema 当前schema，例如PUBLIC
     * @param table 固定本域表，例如CrmContact
     * @return 真实返回示例：Contact到Partner含tenant/org/id关联为true；缺关联或旧owner关联为false。
     * @throws SQLException 实际外键读取失败
     */
    private boolean foreignKeys(
        DatabaseMetaData metadata, String catalog, String schema, String table)
        throws SQLException {
      var required =
          Map.<String, Set<String>>ofEntries(
              Map.entry("CrmContact", Set.of("CrmPartner")),
              Map.entry("CrmOrder", Set.of("CrmPartner")),
              Map.entry("CrmOrderLine", Set.of("CrmOrder", "CrmProduct")),
              Map.entry("CrmCommandRequest", Set.of("CrmPartner", "CrmContact", "CrmOrder")),
              Map.entry("CrmBusinessAudit", Set.of("CrmCommandRequest")),
              Map.entry("CrmDocument", Set.of("CrmOrder")),
              Map.entry(
                  "CrmDocumentLine",
                  Set.of("CrmDocument", "CrmOrderLine", "CrmWarehouse", "CrmProduct")),
              Map.entry("CrmFundsBalance", Set.of("CrmCashAccount", "CrmOpeningBatch")),
              Map.entry("CrmStockBalance", Set.of("CrmWarehouse", "CrmProduct", "CrmOpeningBatch")),
              Map.entry("CrmOrderLineProgress", Set.of("CrmOrderLine", "CrmPostingDetail")),
              Map.entry("CrmPostingBatch", Set.of("CrmDocument", "CrmPostingBatch")),
              Map.entry(
                  "CrmPostingDetail",
                  Set.of("CrmPostingBatch", "CrmDocumentLine", "CrmOrderLine", "CrmStockBalance")),
              Map.entry("CrmPostingRequest", Set.of("CrmDocument", "CrmPostingBatch")),
              Map.entry("CrmPostingCapacity", Set.of("CrmPostingDetail")),
              Map.entry("CrmPostingDependency", Set.of("CrmPostingDetail")),
              Map.entry("CrmStockReversalRequest", Set.of("CrmDocument", "CrmPostingBatch")),
              Map.entry("CrmOrderAttachment", Set.of("CrmOrder", "CrmCommandRequest")));
      Set<String> parents = new LinkedHashSet<>();
      Map<String, Integer> keyColumns = new LinkedHashMap<>();
      Set<String> resourceKeys = new LinkedHashSet<>();
      try (var rows = metadata.getImportedKeys(catalog, schema, table)) {
        while (rows.next()) {
          parents.add(rows.getString("PKTABLE_NAME"));
          String key = rows.getString("FK_NAME");
          if (key == null) {
            return false;
          }
          keyColumns.merge(key, 1, Integer::sum);
          if ("id".equals(rows.getString("PKCOLUMN_NAME"))) {
            resourceKeys.add(key);
          }
          int sequence = rows.getShort("KEY_SEQ");
          if (sequence <= 2) {
            String expected = sequence == 1 ? "tenantId" : "businessOrgId";
            if (!expected.equals(rows.getString("FKCOLUMN_NAME"))
                || !expected.equals(rows.getString("PKCOLUMN_NAME"))) {
              return false;
            }
          }
        }
      }
      return keyColumns.values().stream().allMatch(count -> count >= 3)
          && resourceKeys.containsAll(keyColumns.keySet())
          && parents.containsAll(required.getOrDefault(table, Set.of()));
    }
  }
}
