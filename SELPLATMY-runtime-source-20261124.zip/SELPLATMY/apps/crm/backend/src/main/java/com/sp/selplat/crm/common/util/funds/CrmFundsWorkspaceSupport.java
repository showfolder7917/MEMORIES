/** 销售收款登记SELUI服务端聚合；2026-10-03，Codex；只消费实际分页。 */
package com.sp.selplat.crm.common.util.funds;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 业务显示配置在服务器，客户端不创造账务/许可事实。 */
public final class CrmFundsWorkspaceSupport {
    /** 静态聚合实际资金工作区，构造不创建账户、流水或权限。 */
    private CrmFundsWorkspaceSupport() {
        // 页面配置均静态构造，禁止创建带状态的资金记账组件。
    }

    /**
     * 真实分页、服务端三语表单及明确收款登记操作。
     *
     * @param documents 实际本组织单据分页
     * @param orders 实际已审核销售来源分页
     * @param accounts 实际本组织现金账本账户分页
     * @param balances 实际组织同组织同账户同币种现金最小单位余额分页
     * @param details 实际POST流水分页
     * @param permits 实际funds.write/submit/approve/post及可选reverse逐次裁决
     * @param requested 展示语言候选，例如zh-CN/en-US/ja-JP
     * @param payment true为采购付款，仅内部负金额记账；false保持销售收款
     * @param synthetic 实际准入证据，例如正式false、隔离true；不由客户端提供
     * @return 真实示例：data.synthetic=false及原documents/orders/accounts分页和SelUI定义。
     * 异常或副作用示例：仅聚合已读取事实，不创建账户、资金或权限。
     */
    public static CommonResult build(
            CommonPageResult documents,
            CommonPageResult orders,
            CommonPageResult accounts,
            CommonPageResult balances,
            CommonPageResult details,
            Map<String, Boolean> permits,
            Object requested,
            boolean payment,
            boolean synthetic) {
        String lang = String.valueOf(requested);
        int locale = lang.equals("en-US") ? 1 : lang.equals("ja-JP") ? 2 : 0;
        Map<String, String[]> words = new LinkedHashMap<>();
        words.put("counterpartyName", new String[] {"客户/供应商", "Customer / supplier", "顧客・仕入先"});
        words.put("itemsSummary", new String[] {"原订购项目", "Ordered items", "注文商品"});
        words.put("totalDisplay", new String[] {"订单总额", "Order total", "注文合計"});
        words.put(
                "title",
                new String[] {"销售收款登记与资金流水", "Sales receipt and cash ledger", "販売入金登録と資金台帳"});
        words.put("id", new String[] {"编号", "Number", "番号"});
        words.put("orderId", new String[] {"销售订单", "Sales order", "販売注文"});
        words.put("documentStateLabel", new String[] {"状态", "State", "状態"});
        words.put("accountName", new String[] {"现金账本账户", "Account", "現金台帳口座"});
        words.put("accountId", new String[] {"现金账本账户编号", "Account number", "現金台帳口座番号"});
        words.put("currency", new String[] {"币种", "Currency", "通貨"});
        words.put("sourceOrderLineId", new String[] {"订单行编号", "Order line number", "注文行番号"});
        words.put("productNameSnapshot", new String[] {"商品", "Product", "商品"});
        words.put("amountMinor", new String[] {"金额（最小单位）", "Amount (minor units)", "金額（最小単位）"});
        words.put(
                "amountDeltaMinor",
                new String[] {"资金变动最小单位", "Cash movement minor units", "資金増減最小単位"});
        words.put("openingMinor", new String[] {"期初最小单位", "Opening minor units", "期首最小単位"});
        words.put("versionNo", new String[] {"版本", "Version", "バージョン"});
        words.put("batchId", new String[] {"批次", "Batch", "バッチ"});
        words.put("documentId", new String[] {"收款单", "Receipt document", "入金伝票"});
        words.put("lineNo", new String[] {"行号", "Line", "行番号"});
        words.put("new", new String[] {"新建收款单", "New receipt", "新規入金"});
        words.put("reload", new String[] {"重载详情", "Reload detail", "再読み込み"});
        words.put("saveDraft", new String[] {"保存全部行", "Save all lines", "全行保存"});
        words.put("submit", new String[] {"提交", "Submit", "提出"});
        words.put("approve", new String[] {"他人审核", "Independent approval", "独立承認"});
        words.put("post", new String[] {"明确过账登记收款", "Post receipt ledger", "入金台帳転記"});
        words.put("newLine", new String[] {"新行", "New line", "新規行"});
        words.put("addLine", new String[] {"加入/更新行", "Add / update line", "行追加・更新"});
        words.put("removeLine", new String[] {"移除当前行", "Remove line", "行削除"});
        words.put(
                "references",
                new String[] {
                    "审核订单、来源行与现金账本账户",
                    "Approved orders, source lines and accounts",
                    "承認注文・明細・現金台帳口座"
                });
        words.put(
                "approvedDueMinor",
                new String[] {"冻结应收最小单位", "Approved due minor units", "承認請求最小単位"});
        words.put("cashSettledMinor", new String[] {"已收最小单位", "Settled minor units", "入金済み最小単位"});
        words.put("unsettledMinor", new String[] {"未收最小单位", "Unsettled minor units", "未入金最小単位"});
        if (payment) {
            words.put(
                    "title",
                    new String[] {"供应商付款与资金流水", "Supplier payment and cash ledger", "仕入先支払と資金台帳"});
            words.put("orderId", new String[] {"采购订单", "Purchase order", "仕入注文"});
            words.put("documentId", new String[] {"付款单", "Payment document", "支払伝票"});
            words.put("new", new String[] {"新建付款单", "New payment", "新規支払"});
            words.put("post", new String[] {"明确扣款记账", "Post payment ledger", "支払台帳転記"});
            words.put(
                    "approvedDueMinor",
                    new String[] {"冻结应付最小单位", "Approved payable minor units", "承認買掛最小単位"});
            words.put("cashSettledMinor", new String[] {"已付最小单位", "Paid minor units", "支払済み最小単位"});
            words.put("unsettledMinor", new String[] {"未付最小单位", "Unpaid minor units", "未払最小単位"});
        }
        Map<String, String> labels = new LinkedHashMap<>();
        words.forEach((k, v) -> labels.put(k, v[locale]));
        Map<String, String> states =
                Map.of(
                        "REVERSED",
                        new String[] {"已完整冲正", "Fully reversed", "全額反対仕訳済み"}[locale],
                        "DRAFT",
                        new String[] {"草稿", "Draft", "下書き"}[locale],
                        "SUBMITTED",
                        new String[] {"已提交", "Submitted", "提出済み"}[locale],
                        "APPROVED",
                        new String[] {"已审核冻结", "Approved and frozen", "承認・凍結済み"}[locale],
                        "POSTED",
                        (payment
                                        ? new String[] {"已扣款记账", "Posted payment", "支払転記済み"}
                                        : new String[] {"已过账登记收款", "Posted receipt", "転記・入金済み"})
                                [locale]);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("synthetic", synthetic);
        data.put("permits", permits);
        data.put("labels", labels);
        data.put("states", states);
        data.put("title", labels.get("title"));
        data.put(
                "notice",
                new String[] {
                            "隔离合成账本：仅登记收款，不连接支付渠道；审核不改资金，只有明确过账写流水；生产未开放。",
                            "Isolated synthetic ledger: receipt registration only; no payment"
                                    + " channel. Approval changes no cash. Production disabled.",
                            "隔離合成台帳：入金登録のみ、決済接続なし。承認は資金を変更せず、本番未開放。"
                        }
                        [locale]);
        if (!synthetic) {
            data.put("notice", new String[] {
                "收付款登记与资金流水：审核后需明确过账；登记不发起银行扣款或转账。",
                "Receipt/payment registration and ledger: explicitly post after approval; registration initiates no bank transaction.",
                "入出金登録と資金台帳：承認後に明示的な転記が必要です。登録から銀行取引は実行しません。"
            }[locale]);
        }
        data.put(
                "dirty",
                new String[] {
                            "有未保存行，请先保存或重载。",
                            "Unsaved lines. Save or reload first.",
                            "未保存行があります。保存か再読込みしてください。"
                        }
                        [locale]);
        data.put(
                "linePending",
                new String[] {
                            "行字段尚未加入，请先加入/更新或重载。",
                            "Pending line fields. Add/update or reload first.",
                            "行フィールド未追加。追加・更新か再読込みしてください。"
                        }
                        [locale]);
        data.put(
                "selectionRequired",
                new String[] {
                            "请选择真实审核销售订单、来源行和现金账本账户。",
                            "Select a real approved sales order, source line and account.",
                            "実際の承認販売注文・明細・現金台帳口座を選択してください。"
                        }
                        [locale]);
        data.put(
                "saved",
                new String[] {
                            "数据库已提交，全部行原子处理。",
                            "Database committed; all lines processed atomically.",
                            "DB確定。全行を原子的に処理。"
                        }
                        [locale]);
        data.put("lineLimit", 1000);
        data.put(
                "lineLimitMessage",
                new String[] {"收款单最多1000行。", "At most 1000 issue lines.", "出庫は最大1000行。"}[locale]);
        data.put("documentKind", payment ? "FUNDS_PAYMENT" : "FUNDS_RECEIPT");
        data.put("reason", payment ? "PURCHASE" : "SALE");
        data.put(
                "switchFundsKind",
                (payment
                                ? new String[] {"销售收款", "Sales receipts", "販売入金"}
                                : new String[] {"供应商付款", "Supplier payments", "仕入先支払"})
                        [locale]);
        data.put(
                "lineLimitMessage",
                new String[] {"资金单最多1000行。", "At most 1000 allocations.", "資金伝票は最大1000行。"}[locale]);
        if (payment && synthetic) {
            data.put(
                    "notice",
                    new String[] {
                                "隔离合成账本：供应商付款仅内部业务记账，不进行真实银行付款；审核不扣资金，明确过账写负金额流水；生产未开放。",
                                "Isolated synthetic ledger: internal supplier payment recording; no"
                                    + " real bank payment. Approval does not debit cash. Production"
                                    + " disabled.",
                                "隔離合成台帳：仕入先支払の内部記帳のみ。実際の銀行支払なし。承認は資金を減らさず、本番未開放。"
                            }
                            [locale]);
        }
        if (payment) {
            data.put(
                    "selectionRequired",
                    new String[] {
                                "请选择真实审核采购订单、来源行和现金账本账户。",
                                "Select a real approved purchase order, source line and account.",
                                "実際の承認仕入注文・明細・現金台帳口座を選択してください。"
                            }
                            [locale]);
        }
        data.put(
                "headerForm",
                Map.of(
                        "id",
                        "crm-funds-editor",
                        "title",
                        labels.get("title"),
                        "fields",
                        List.of(
                                Map.of(
                                        "id",
                                        "orderId",
                                        "label",
                                        labels.get("orderId"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "currency",
                                        "label",
                                        labels.get("currency"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "cashSettledMinor",
                                        "label",
                                        labels.get("cashSettledMinor"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "unsettledMinor",
                                        "label",
                                        labels.get("unsettledMinor"),
                                        "readOnly",
                                        true)),
                        "actions",
                        List.of("new", "reload", "saveDraft", "submit", "approve", "post").stream()
                                .map(id -> Map.of("id", id, "label", labels.get(id)))
                                .toList(),
                        "slots",
                        permits.containsKey("crm.funds.reverse")
                                ? List.of(
                                        "lineForm",
                                        "lineGrid",
                                        "balanceGrid",
                                        "detailGrid",
                                        "reversalForm")
                                : List.of("lineForm", "lineGrid", "balanceGrid", "detailGrid")));
        data.put(
                "lineForm",
                Map.of(
                        "id",
                        "crm-funds-line-editor",
                        "fields",
                        List.of(
                                Map.of(
                                        "id",
                                        "productNameSnapshot",
                                        "label",
                                        labels.get("productNameSnapshot"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "sourceOrderLineId",
                                        "label",
                                        labels.get("sourceOrderLineId"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "accountName",
                                        "label",
                                        labels.get("accountName"),
                                        "readOnly",
                                        true),
                                Map.of(
                                        "id",
                                        "amountMinor",
                                        "label",
                                        labels.get("amountMinor"),
                                        "maxLength",
                                        38)),
                        "actions",
                        List.of("newLine", "addLine", "removeLine").stream()
                                .map(id -> Map.of("id", id, "label", labels.get(id)))
                                .toList()));
        data.put(
                "referenceForm",
                Map.of(
                        "id",
                        "crm-funds-references",
                        "title",
                        labels.get("references"),
                        "fields",
                        List.of(),
                        "slots",
                        List.of("orderGrid", "sourceGrid", "accountGrid")));
        List<Map<String, Object>> docs = new ArrayList<>();
        for (var row : documents.getRecords()) {
            var copy = CrmStockValueSupport.browser(row);
            copy.put("documentStateLabel", states.get(String.valueOf(row.get("documentState"))));
            docs.add(copy);
        }
        data.put(
                "documents",
                grid(
                        docs,
                        documents,
                        List.of("id", "orderId", "documentStateLabel"),
                        labels,
                        locale));
        List<Map<String, Object>> displayedOrders = new ArrayList<>();
        for (var row : orders.getRecords()) {
            var copy = CrmStockValueSupport.browser(row);
            copy.put(
                    "totalDisplay",
                    new java.math.BigDecimal(row.get("totalMinor").toString())
                                    .movePointLeft(((Number) row.get("currencyScale")).intValue())
                                    .toPlainString()
                            + " "
                            + row.get("currency"));
            copy.put("itemsSummary", ((List<?>) row.get("sourceItems")).stream()
                    .map(value -> { var item = (Map<?, ?>) value;
                        return item.get("productName") + " × " + item.get("quantity"); })
                    .collect(java.util.stream.Collectors.joining("；")));
            displayedOrders.add(copy);
        }
        data.put(
                "orders",
                grid(displayedOrders, orders, List.of("id", "counterpartyName", "itemsSummary", "totalDisplay"), labels, locale));
        data.put(
                "accounts",
                grid(
                        accounts.getRecords(),
                        accounts,
                        List.of("id", "accountName", "currency"),
                        labels,
                        locale));
        data.put(
                "balances",
                grid(
                        balances.getRecords(),
                        balances,
                        List.of(
                                "accountId",
                                "currency",
                                "openingMinor",
                                "amountMinor",
                                "versionNo"),
                        labels,
                        locale));
        data.put(
                "details",
                grid(
                        details.getRecords(),
                        details,
                        List.of(
                                "id",
                                "batchId",
                                "sourceOrderLineId",
                                "accountId",
                                "currency",
                                "amountDeltaMinor"),
                        labels,
                        locale));
        data.put(
                "lines",
                grid(
                        List.of(),
                        null,
                        List.of(
                                "lineNo",
                                "sourceOrderLineId",
                                "productNameSnapshot",
                                "accountName",
                                "amountMinor"),
                        labels,
                        locale));
        data.put(
                "sourceLines",
                grid(
                        List.of(),
                        null,
                        List.of(
                                "id",
                                "productNameSnapshot",
                                "approvedDueMinor",
                                "cashSettledMinor",
                                "unsettledMinor"),
                        labels,
                        locale));
        if (permits.containsKey("crm.funds.reverse")) {
            Map<String, String[]> reverseWords =
                    Map.ofEntries(
                            Map.entry(
                                    "title",
                                    new String[] {
                                        "原收款完整冲正", "Full original receipt reversal", "元入金の全額反対仕訳"
                                    }),
                            Map.entry(
                                    "originalBatchId",
                                    new String[] {"原批次", "Original batch", "元バッチ"}),
                            Map.entry(
                                    "totalMinor",
                                    new String[] {
                                        "原金额最小单位", "Original amount minor units", "元金額最小単位"
                                    }),
                            Map.entry(
                                    "cashDeltaMinor",
                                    new String[] {
                                        "账户减少最小单位", "Cash decrease minor units", "口座減少最小単位"
                                    }),
                            Map.entry(
                                    "settledDeltaMinor",
                                    new String[] {
                                        "已收变化最小单位", "Settled change minor units", "入金済み変化最小単位"
                                    }),
                            Map.entry(
                                    "unsettledDeltaMinor",
                                    new String[] {
                                        "未收恢复最小单位", "Unsettled restored minor units", "未入金復元最小単位"
                                    }),
                            Map.entry(
                                    "requestState",
                                    new String[] {"冲正申请状态", "Reversal request state", "反対仕訳申請状態"}),
                            Map.entry(
                                    "approvedByUserId",
                                    new String[] {"冲正审核人", "Reversal approver", "反対仕訳承認者"}),
                            Map.entry(
                                    "reasonText",
                                    new String[] {"完整冲正原因", "Full reversal reason", "全額反対仕訳理由"}),
                            Map.entry(
                                    "requestReverse",
                                    new String[] {"申请完整冲正", "Request full reversal", "全額反対仕訳申請"}),
                            Map.entry(
                                    "approveReverse",
                                    new String[] {
                                        "他人审核冲正", "Approve another user's request", "他者申請承認"
                                    }),
                            Map.entry(
                                    "executeReverse",
                                    new String[] {
                                        "明确反向记账", "Post full reverse ledger", "全額反対仕訳を転記"
                                    }));
            Map<String, String> reverseLabels = new LinkedHashMap<>(labels);
            reverseWords.forEach((k, v) -> reverseLabels.put(k, v[locale]));
            List<Map<String, Object>> reverseFields = new ArrayList<>();
            for (String f :
                    List.of(
                            "originalBatchId",
                            "totalMinor",
                            "cashDeltaMinor",
                            "settledDeltaMinor",
                            "unsettledDeltaMinor",
                            "currency",
                            "requestState",
                            "approvedByUserId")) {
                reverseFields.add(Map.of("id", f, "label", reverseLabels.get(f), "readOnly", true));
            }
            reverseFields.add(
                    Map.of(
                            "id",
                            "reasonText",
                            "label",
                            reverseLabels.get("reasonText"),
                            "maxLength",
                            500));
            data.put(
                    "reversalStates",
                    Map.of(
                            "SUBMITTED",
                            new String[] {"待他人审核", "Awaiting independent approval", "他者承認待ち"}
                                    [locale],
                            "APPROVED",
                            new String[] {
                                        "已审核，待明确冲正",
                                        "Approved, awaiting explicit reversal",
                                        "承認済み、明示的な反対仕訳待ち"
                                    }
                                    [locale],
                            "POSTED",
                            new String[] {"已完成完整冲正", "Full reversal completed", "全額反対仕訳完了"}
                                    [locale]));
            data.put(
                    "reversalForm",
                    Map.of(
                            "id",
                            "crm-funds-reversal-editor",
                            "title",
                            reverseLabels.get("title"),
                            "fields",
                            reverseFields,
                            "actions",
                            List.of("requestReverse", "approveReverse", "executeReverse").stream()
                                    .map(id -> Map.of("id", id, "label", reverseLabels.get(id)))
                                    .toList(),
                            "slots",
                            List.of("accountEffectsGrid")));
            data.put(
                    "reversalAccountEffects",
                    grid(
                            List.of(),
                            null,
                            List.of("accountId", "cashDeltaMinor"),
                            reverseLabels,
                            locale));
        }
        return CrmPartnerValueSupport.result(data);
    }

    /**
     * 公共Grid协议，仅实际分页或明确空待编辑行，不复制组件。
     *
     * @param rows 实际列表或暂存编辑空列表
     * @param page 实际分页；暂存行null
     * @param columns 固定服务器字段白名单
     * @param labels 服务端三语标题
     * @param locale 展示语言索引0/1/2
     * @return 公共Grid原生配置及真实REMOTE分页
     */
    private static Map<String, Object> grid(
            List<Map<String, Object>> rows,
            CommonPageResult page,
            List<String> columns,
            Map<String, String> labels,
            int locale) {
        var r = new LinkedHashMap<String, Object>();
        r.put("grid", Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id"));
        r.put("data", Map.of("items", rows, "selectedIds", List.of()));
        r.put(
                "column",
                Map.of(
                        "items",
                        columns.stream()
                                .map(
                                        f ->
                                                Map.of(
                                                        "id",
                                                        f,
                                                        "field",
                                                        f,
                                                        "label",
                                                        labels.getOrDefault(f, f)))
                                .toList()));
        r.put("title", Map.of("messages", Map.of("selectProject", labels.get("title"))));
        r.put(
                "pagination",
                Map.of(
                        "mode",
                        page == null ? "LOCAL" : "REMOTE",
                        "visible",
                        page != null,
                        "totalCount",
                        page == null ? rows.size() : page.getTotalCount(),
                        "currentPage",
                        page == null ? 1 : page.getPageNo(),
                        "pageSize",
                        page == null ? 1000 : page.getPageSize(),
                        "previousLabel",
                        new String[] {"上一页", "Previous", "前へ"}[locale],
                        "nextLabel",
                        new String[] {"下一页", "Next", "次へ"}[locale],
                        "summaryAll",
                        new String[] {"共 {total} 条", "{total} records", "合計 {total} 件"}[locale]));
        r.put(
                "select",
                Map.of(
                        "pageSize",
                        Map.of(
                                "ariaLabel",
                                new String[] {"每页行数", "Rows per page", "ページ行数"}[locale],
                                "options",
                                List.of(10, 20, 50, 100).stream()
                                        .map(
                                                n ->
                                                        Map.of(
                                                                "value",
                                                                n.toString(),
                                                                "label",
                                                                n
                                                                        + new String[] {
                                                                                    " 行/页",
                                                                                    " rows/page",
                                                                                    " 行/ページ"
                                                                                }
                                                                                [locale]))
                                        .toList())));
        return r;
    }
}
