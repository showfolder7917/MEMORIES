/** CrmPostingEntryService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingentry.service;

import com.sp.selplat.common.service.BaseService;

/** 本人隔离过账记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmPostingEntryService extends BaseService {
    /**
     * 本表原子流程扩展 findOriginal，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> findOriginal(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 appendEntry，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    Long appendEntry(com.sp.selplat.common.util.CommonParam input);

    /**
     * 来源原流水计数；输入例如sourceDocumentId101；返回0或正数；仅参加CRM事务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：来源原流水计数；输入例如sourceDocumentId101；返回0或正数；仅参加CRM事务。
     * @return 0或正数
     */
    Long countSourcePosts(com.sp.selplat.common.util.CommonParam input);
}
