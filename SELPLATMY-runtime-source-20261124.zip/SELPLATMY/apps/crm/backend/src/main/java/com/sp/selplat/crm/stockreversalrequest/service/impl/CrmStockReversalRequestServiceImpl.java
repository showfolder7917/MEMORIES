/** 完整库存冲正隔离本表组件；2026-10-03，Codex；生产默认拒绝；2026-10-10公开读取空请求遵循真实身份拒绝。 */
package com.sp.selplat.crm.stockreversalrequest.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import com.sp.selplat.crm.stockreversalrequest.dao.CrmStockReversalRequestDao;
import com.sp.selplat.crm.stockreversalrequest.service.CrmStockReversalRequestService;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/** 本表直接继承公共CRUD，通用写关闭，跨表只调用owning服务。 */
@org.springframework.stereotype.Service
public class CrmStockReversalRequestServiceImpl
        extends com.sp.selplat.common.service.BaseServiceImpl<CrmStockReversalRequestDao>
        implements CrmStockReversalRequestService {
    // 真实Session和组织动作准入，不能从请求绑定可信身份。
    protected final com.sp.selplat.crm.capability.access.service.CrmAccessService access;

    /**
     * 绑定真实身份及本域范围入口；构造不授予任何角色或许可。
     *
     * @param access Spring提供的真实CrmAccessService，例如Session核tenant92/actor9211后再核org901动作
     */
    public CrmStockReversalRequestServiceImpl(
            com.sp.selplat.crm.capability.access.service.CrmAccessService access) {
        this.access = access;
    }

    /**
     * 公共真实范围分页。
     *
     * @param input 例如org901/page1；可信身份由Session给出
     * @return 本组织精确文本记录；缺库存读许可拒绝
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        requireReversalStructure();
        // 空请求仍由真实身份及组织入口按原顺序拒绝；不补造候选组织。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var page = super.getStore(CrmPartnerValueSupport.page(input, scope, null));
        page.setRecords(page.getRecords().stream().map(CrmStockValueSupport::browser).toList());
        return page;
    }

    /**
     * 公共真实范围详情。
     *
     * @param input 例如org901/id1000000
     * @return 本组织有效记录；不存在统一拒绝
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        requireReversalStructure();
        // 空请求仍由真实身份及组织入口按原顺序拒绝；不补造候选组织。
        var scope =
                access.requireStockScope(
                        input == null ? null : input.getParam("organizationCandidateId"), "crm.stock.read");
        var row = getDao().getById(CrmPartnerValueSupport.detail(input, scope));
        if (row == null || !Integer.valueOf(1).equals(row.get("status"))) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return CrmPartnerValueSupport.result(CrmStockValueSupport.browser(row));
    }

    /**
     * 批读不开放。
     *
     * @param input 例如空items
     * @return 无成功返回；抛CRM_GENERIC_ACCESS_DISABLED
     */
    @Override
    public CommonResult getByIds(CommonBatchParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_ACCESS_DISABLED");
    }

    /**
     * 真实操作员，无默认账号。
     *
     * @return 例如9211；失效Session拒绝
     */
    @Override
    protected Long getCurrentOperatorId() {
        return access.requireDraftActor().get("ownerUserId");
    }

    /**
     * 真实租户，无默认租户。
     *
     * @return 例如92；失效Session拒绝
     */
    @Override
    protected Long getCurrentTenantId() {
        return access.requireDraftActor().get("tenantId");
    }

    /**
     * 无隐式管理员。
     *
     * @return 返回示例：false；不扩权
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 通用写关闭。
     *
     * @param input 例如id1000000 副作用示例：抛CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam input) {
        throw CrmPartnerValueSupport.failure("CRM_GENERIC_WRITE_DISABLED");
    }

    /**
     * owning精确锁，只由具名真实CRM事务消费。
     *
     * @param input 例如org901/id1000000
     * @param action 固定库存读取、冲正或审核动作
     * @return 本组织真实行；没有实际记录/许可拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.MANDATORY)
    public Map<String, Object> lockScoped(CommonParam input, String action) {
        requireReversalStructure();
        var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
        var row = getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        return row;
    }

    /**
     * 方法作用：按当前真实许可读取原库存对应申请。
     *
     * @param input org901/originalBatch1200000
     * @param action stock.read或reverse或approve
     * @return 实际申请，不替代原审批 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Map<String, Object> forOriginal(CommonParam input, String action) {
        requireReversalStructure();
        var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam(
                "originalBatchId",
                CrmPartnerValueSupport.positive(input.getParam("originalBatchId")));
        return getDao().forOriginal(p);
    }

    /**
     * 方法作用：申请全额冲正并记录完整原批次摘要，不改原单据。
     *
     * @param input 服务器实际originalDoc1000000/batch1200000/version3/quantity3/reason
     * @return 新申请id1700000/version0；每原批次只有一条申请 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long submit(CommonParam input) {
        requireReversalStructure();
        var scope =
                access.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var row = new CommonParam();
        for (String f :
                List.of(
                        "originalDocumentId",
                        "originalBatchId",
                        "originalDocumentVersion",
                        "originalSnapshotHash",
                        "originalBatchDigest",
                        "totalQuantity",
                        "reasonText")) {
            row.putParam(f, input.getParam(f));
        }
        row.putParam("requestState", "SUBMITTED");
        row.putParam("submittedByUserId", scope.get("actorUserId"));
        row = CrmPartnerValueSupport.entity(row, scope);
        long id = getSequence().get("id");
        row.putParam("id", id);
        CrmPartnerValueSupport.changed(getDao().insert(row));
        return id;
    }

    /**
     * 方法作用：他人审核或记录完整冲正结果并重查权限版本。
     *
     * @param input org901/申请1700000/expected0或1/实际resultBatch
     * @param execute false审核，true已完整执行
     * @return 实际申请APPROVED/version1或POSTED/version2；自审拒绝
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Map<String, Object> transition(CommonParam input, boolean execute) {
        String action = execute ? "crm.stock.reverse" : "crm.stock.approve";
        requireReversalStructure();
        var scope = access.requireStockScope(input.getParam("organizationCandidateId"), action);
        var p = CrmPartnerValueSupport.detail(input, scope);
        var row = getDao().lockScoped(p);
        if (row == null) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        if (!execute && row.get("submittedByUserId").equals(scope.get("actorUserId"))) {
            throw CrmPartnerValueSupport.failure("CRM_APPROVER_EQUALS_SUBMITTER");
        }
        p.putParam(
                "expectedVersion",
                CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        p.putParam("previousState", execute ? "APPROVED" : "SUBMITTED");
        p.putParam("nextState", execute ? "POSTED" : "APPROVED");
        p.putParam("actorUserId", scope.get("actorUserId"));
        p.putParam("resultBatchId", execute ? input.getParam("resultBatchId") : null);
        p.putParam("resultAction", execute ? "REVERSE" : null);
        CrmPartnerValueSupport.changed(getDao().transition(p));
        return getDao().lockScoped(CrmPartnerValueSupport.detail(input, scope));
    }

    // 新增冲正结构读取前显式准入，不扩生产权限。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmStockReversalIsolatedEnabled")
    private Boolean reversalEnabled;

    /** 方法作用：在新表读取或写入前检查额外显式冲正测试结构。 副作用示例：旧profile或生产默认CRM_SCOPE_UNAVAILABLE；不查询不存在的新表、不扩权。 */
    private void requireReversalStructure() {
        if (!Boolean.TRUE.equals(reversalEnabled) && !access.formalCapabilityAvailable("stockReversal")) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
    }
}
