/** CrmOrderLine本表参数化DAO；2026-10-03，Codex；2026-10-06补同sortnum稳定分页。 */
package com.sp.selplat.crm.orderline.dao;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 只执行本表固定SQL，与公共DAO共享同一CRM池和事务。 */
@Repository
public class CrmOrderLineDaoImpl extends CrmBaseDao implements CrmOrderLineDao {
    private final JdbcTemplate jdbc;

    /**
     * 装配本表CRM模板；示例crmJdbcTemplate；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmOrderLineDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 保留默认sortnum倒序并以范围内唯一id确定同值行位置，避免普通订单分页重复或遗漏。
     *
     * @param conditions owning Service已校验条件，例如tenant92/org901/status1/order600000
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际每页条数，例如1
     * @return 公共页，例如records中id600001、totalCount2、pageNo2、pageSize1
     *     异常或副作用示例：公共条件/方言校验及SQL失败沿原链传播，无写入或范围变化。
     */
    @Override
    public CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 原主排序保持，唯一id仅打破同sortnum平局；COUNT和分页继续由公共SQL builder执行。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 锁本订单全部有效行，ID升序避免客户端锁序；scope92/901/order600000；返回真实行。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 本表真实结果，例如id600000/version1或实际行集合；失败拒绝，不部分成功
     */
    @Override
    public List<Map<String, Object>> lockOrderLines(CommonParam input) {
        requireCrmTransaction();
    return jdbc.queryForList(
        "SELECT * FROM CrmOrderLine WHERE tenantId=? AND businessOrgId=? AND orderId=? AND status=1"
            + " ORDER BY id FOR UPDATE",
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("orderId"));
    }

    /**
     * 删除当前DRAFT全量输入中移除的行；scope92/901/order600000/id600001；返回0/1，FK失败回滚。
     *
     * @param input 本表业务候选/命令，例如organizationCandidateId=901、id=600000、expectedVersion=0；客户端身份不受信任
     *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
     * @return 实际本订单行删除数0/1；FK失败当前整笔事务回滚
     */
    @Override
    public int deleteLine(CommonParam input) {
        requireCrmTransaction();
    return jdbc.update(
        "DELETE FROM CrmOrderLine WHERE tenantId=? AND businessOrgId=? AND orderId=? AND id=?",
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("orderId"),
        input.getParam("id"));
    }

  /**
   * 方法作用：一次参数化查询当前页的订单商品快照与数量，租户和组织在SQL中限定。
   *
   * @param tenant 真实范围租户，例如9
   * @param organization 真实范围组织，例如901
   * @param ids 所有者校验后的主键，例如[600000]，空集合不发SQL
   * @return 真实示例：限定本组织的安全投影；不含联系资料、金额或审计正文
   * @throws IllegalArgumentException 超过100项时拒绝，无写入或锁副作用
   */
  @Override
  public java.util.List<java.util.Map<String, Object>> orderListItems(
      long tenant, long organization, java.util.List<Long> ids) {
    if (ids.isEmpty()) {
      return java.util.List.of();
    }
    if (ids.size() > 100) {
      throw new IllegalArgumentException("Order list page limit exceeded");
    }
    // 占位符数量只来自有界集合，实际值全部绑定，不拼接用户主键。
    var placeholders = String.join(",", java.util.Collections.nCopies(ids.size(), "?"));
    var arguments = new java.util.ArrayList<Object>();
    arguments.add(tenant);
    arguments.add(organization);
    arguments.addAll(ids);
    return jdbc.queryForList(
        "SELECT orderId,productNameSnapshot,SUM(quantity) AS quantity FROM CrmOrderLine WHERE"
            + " tenantId=? AND businessOrgId=? AND status=1 AND orderId IN ("
            + placeholders
            + ") GROUP BY orderId,productNameSnapshot ORDER BY orderId,productNameSnapshot",
        arguments.toArray());
  }
}
