/*
 * 文件：CrmPostingCapacityController.java
 * 职责：提供本表控制器结构，所有通用读取由容量服务明确拒绝。
 * 修改记录：2026-10-04，整合修复缺失controller；不提供写入、容量占用或管理员入口。
 * 修改记录：2026-10-09，关闭查询直接交由服务拒绝，不声明或序列化不存在的成功结果。
 */
package com.sp.selplat.crm.postingcapacity.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表控制器只调用owning服务；服务明确关闭通用读取，不开放任何写路由。 */
@RestController
@RequestMapping("/api/crm/postingcapacity")
public class CrmPostingCapacityController {
    // 本表公共服务的拒绝契约不依赖客户端组织、权限或操作者字段。
    private final CrmPostingCapacityService service;

    /**
     * 注入本表服务，构造不读写数据库或建立身份。
     *
     * @param service 实际CrmPostingCapacityServiceImpl，通用读取固定拒绝
     *     返回示例：构造本表控制器；无SQL、授权或容量变更副作用。
     */
    public CrmPostingCapacityController(CrmPostingCapacityService service) {
        this.service = service;
    }

    /**
     * 将通用分页请求交给本表明确拒绝的服务，不执行容量查询。
     *
     * @param input 例如organizationCandidateId901/page1，不能建立业务范围
     * @return 无成功响应；始终抛出owning服务提供的固定拒绝异常，数据库保持不变。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 服务固定抛CRM_GENERIC_ACCESS_DISABLED
     */
    @GetMapping("getStore.htm")
    public String getStore(CommonPageParam input) {
        // owning服务固定拒绝 -> 共通异常处理器继续返回原400和原错误码。
        throw service.genericReadRejection();
    }

    /**
     * 将通用详情请求交给本表明确拒绝的服务，不暴露容量事实。
     *
     * @param input 例如organizationCandidateId901/id1900000，不能建立业务范围
     * @return 无成功响应；始终抛出owning服务提供的固定拒绝异常，无授权或写入副作用。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 服务固定抛CRM_GENERIC_ACCESS_DISABLED
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam input) {
        // 不构造不存在的容量成功响应，也不绕过服务的关闭边界。
        throw service.genericReadRejection();
    }
}
