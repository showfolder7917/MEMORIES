/** CrmPostingRequestDaoImpl.java：固定参数化 SQL 只访问本表，绑定 CRM 事务连接。 */
package com.sp.selplat.crm.postingrequest.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表锁定读、条件更新及唯一约束由数据库协调，不依赖进程内锁。 */
@Repository
public class CrmPostingRequestDaoImpl extends CrmBaseDao implements CrmPostingRequestDao {
    // 与公共 MyBatis 使用同一个 crmDataSource，不自行建立连接池。
    private final JdbcTemplate jdbc;

    /**
     * 绑定本域 SQL 模板；传参例如 crmJdbcTemplate；返回实例；构造不执行 SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmPostingRequestDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 精确读返回单行或null；输入例如一条CRM结果；不隐藏多行，不写库。
     *
     * @param rows 真实SQL结果列表，例如[{id:101}]；空列表表示未找到。
     * @return 唯一实际行Map；空列表返回null，多行拒绝，不丢弃重复结果
     * @throws IllegalStateException 实际状态不满足正文条件时拒绝；不继续SQL或构造默认记录
     */
    private java.util.Map<String, Object> first(
            java.util.List<java.util.Map<String, Object>> rows) {
        if (rows.size() > 1) {
            throw new IllegalStateException("Expected one CRM row");
        }
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 本表固定 SQL 扩展 claimRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public int claimRequest(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "INSERT INTO CrmPostingRequest (id,tenantId,ownerUserId,lastOperateUserId,"
                        + "documentId,action,requestKey,payloadHash,requestState) VALUES (?,?,?,?,?,?,"
                        + "?,?,'OPEN')",
                input.getParam("id"),
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("ownerUserId"),
                input.getParam("documentId"),
                input.getParam("action"),
                input.getParam("requestKey"),
                input.getParam("payloadHash"));
    }

    /**
     * 本表固定 SQL 扩展 completeRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public int completeRequest(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmPostingRequest SET requestState='COMPLETED',resultEntryId=?,"
                        + "resultState=?,updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND "
                        + "ownerUserId=? AND id=? AND payloadHash=? AND requestState='OPEN'",
                input.getParam("resultEntryId"),
                input.getParam("resultState"),
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("id"),
                input.getParam("payloadHash"));
    }

    /**
     * 本表固定 SQL 扩展 findRequest；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public java.util.Map<String, Object> findRequest(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingRequest WHERE tenantId=? AND ownerUserId=? AND action=? AND requestKey=? AND status=1",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("action"),
                        input.getParam("requestKey")));
    }

    /**
     * 组织首次请求锁。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    public java.util.Map<String, Object> findOrganization(
            com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingRequest WHERE tenantId=? AND businessOrgId=? AND "
                                + "action='POST' AND requestKey=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("requestKey")));
    }

    /**
     * 真实批次类型化结果完成。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    public int completeOrganization(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmPostingRequest SET requestState='COMPLETED',resultBatchId=?,"
                        + "resultVersionNo=?,resultState='POSTED',responseSnapshot=?,"
                        + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? AND id=? "
                        + "AND payloadHash=? AND requestState='OPEN'",
                input.getParam("resultBatchId"),
                input.getParam("resultVersionNo"),
                input.getParam("responseSnapshot"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("payloadHash"));
    }

    /**
     * 方法作用：本表冲正请求真实唯一结果查询或条件完成。
     *
     * @param input tenant92/org901/REVERSE/keyr1及首次batch/version
     * @return 真实请求或影响行数；不存在null，0行拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public java.util.Map<String, Object> findFundsReverse(
            com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingRequest WHERE tenantId=? AND businessOrgId=? AND action='REVERSE' AND requestKey=? FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("requestKey")));
    }

    /**
     * 方法作用：本表冲正请求真实唯一结果查询或条件完成。
     *
     * @param input tenant92/org901/REVERSE/keyr1及首次batch/version
     * @return 真实请求或影响行数；不存在null，0行拒绝 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    public int completeFundsReverse(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmPostingRequest SET requestState='COMPLETED',resultBatchId=?,"
                        + "resultVersionNo=?,resultState='REVERSED',responseSnapshot=?,"
                        + "updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? AND id=? "
                        + "AND action='REVERSE' AND payloadHash=? AND requestState='OPEN'",
                input.getParam("resultBatchId"),
                input.getParam("resultVersionNo"),
                input.getParam("responseSnapshot"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("payloadHash"));
    }
}
