/** CrmPartnerService.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.partner.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;

/** 本表维护服务；HTTP只消费明确接口，不开放通用无版本写入。 */
public interface CrmPartnerService extends BaseService {
    /**
     * 订单动作许可内只读客户候选；org901/page1；返回真实公共分页，无范围拒绝。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：订单动作许可内只读客户候选；org901/page1；返回真实公共分页，无范围拒绝。
     * @return 真实公共分页，无范围拒绝
     */
    com.sp.selplat.common.util.CommonPageResult orderChoices(
            com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 订单持锁验证真实客户引用；org901/id200000/actioncrm.order.write；返回本组织真实行，拒绝缺许可/记录。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：订单持锁验证真实客户引用；org901/id200000/actioncrm.order.write；返回本组织真实行，拒绝缺许可/记录。
     * @param action 服务内部选择的固定动作，例如crm.order.write；不得据客户端动作补授权限。
     * @return 本组织真实行，拒绝缺许可/记录
     */
    Map<String, Object> lockForOrder(CommonParam input, String action);

    /**
     * 聚合实际组织分页及公共控件定义；输入org901/lang；返回真实记录；缺read许可拒绝。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：聚合实际组织分页及公共控件定义；输入org901/lang；返回真实记录；缺read许可拒绝。
     * @return 真实记录
     */
    CommonResult workspace(com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 保存本表；输入例如org901/keyk1及完整业务字段；返回id/version/replay；生产缺resolver拒绝。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：保存本表；输入例如org901/keyk1及完整业务字段；返回id/version/replay；生产缺resolver拒绝。
     * @return id/version/replay
     */
    CommonResult save(CommonParam input);

    /**
     * 同事务锁范围内记录；输入例如org901/id200000；返回真实行；无许可/记录拒绝。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：同事务锁范围内记录；输入例如org901/id200000；返回真实行；无许可/记录拒绝。
     * @return 真实行
     */
    Map<String, Object> lockForMaintenance(CommonParam input);

  /**
   * 方法作用：订单读取许可内批量取得本页客户名称，不依赖参考选择器第一页。
   *
   * @param organizationCandidateId 原经营组织候选，例如901，不接受客户端租户
   * @param ids 本页确定的主键，例如[600000]，最多100项
   * @return 真实示例：本组织安全字段集合；缺失引用不伪造名称或商品
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无原读取资格或主键非法时拒绝，零写入
   */
  java.util.List<java.util.Map<String, Object>> orderListNames(
      Object organizationCandidateId, java.util.List<Long> ids);
  /**
   * 方法作用：在原资金读取范围内批量取得本页来源订单往来方名称，不开放客户详情。
   *
   * @param organizationCandidateId 原经营组织候选，例如901
   * @param ids 本页已审核来源的往来方主键，例如[501]，最多100项
   * @return 真实示例：[{id:501,partnerName:课程报名家长}]；不含电话、地址或联系人
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无资金读取资格或非法主键时拒绝，零写入
   */
  java.util.List<java.util.Map<String, Object>> fundsListNames(
      Object organizationCandidateId, java.util.List<Long> ids);
  /**
   * 方法作用：明确归档一个客户，不删除关系、订单或其他系统资料。
   *
   * @param input 原候选及版本，例如org901/id501/version0/reasonText暂停往来/requestKeya1
   * @return 真实返回示例：data={id:"501",versionNo:"1",archivedFlag:true,replay:false,synthetic:false}。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺原客户写权、旧版本或状态冲突时整笔拒绝
   */
  CommonResult archive(CommonParam input);

  /**
   * 方法作用：按原因恢复归档客户，原业务启停状态及最近归档历史保持。
   *
   * @param input 原候选及版本，例如org901/id501/version1/reasonText恢复往来/requestKeyr1
   * @return 真实返回示例：data={id:"501",versionNo:"2",archivedFlag:false,replay:false,synthetic:false}。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺原客户写权、旧版本或状态冲突时整笔拒绝
   */
  CommonResult restore(CommonParam input);
}
