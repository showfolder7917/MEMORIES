/** CRM 订单文件概要核验入口；2026-10-04，Codex；不提供上传或绑定成功声明。 */
package com.sp.selplat.crm.capability.orderfile.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.orderfile.service.CrmOrderFileService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 控制器只委托本域核验能力；不转发客户端身份、URL或Cookie字段。 */
@RestController
@RequestMapping("/api/crm/order-file")
public class CrmOrderFileController {
    // 真正的订单与文件核验由Service执行，控制器不访问文件存储。
    private final CrmOrderFileService service;

    /**
     * 方法作用：装配本域实际服务。
     *
     * @param service Spring服务，例如CrmOrderFileServiceImpl 副作用示例：仅保留服务引用，不发HTTP或授予权限。
     */
    public CrmOrderFileController(CrmOrderFileService service) {
        this.service = service;
    }

    /**
     * 方法作用：核验当前订单候选引用，结果明确bindingWritten=false。
     *
     * @param input 例如org901/id600000/expectedVersion0、上传返回的32位fileId/64位sha256/byteSize3
     * @return 公共JSON，例如success=true/data.bindingWritten=false、orderId=600000和核对后的文件三元组
     *     异常或副作用示例：实际范围或文件不可读拒绝；不把一次核验当作已持久化关联。
     */
    @PostMapping("verify.htm")
    public String verify(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.verify(input));
    }
}
