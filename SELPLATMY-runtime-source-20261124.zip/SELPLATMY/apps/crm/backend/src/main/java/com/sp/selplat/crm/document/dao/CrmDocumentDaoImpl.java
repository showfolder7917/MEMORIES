/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.document.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmDocumentDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmDocumentDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 绑定本域实际SQL连接，不执行DDL或迁移。
     *
     * @param jdbc Spring提供的crmJdbcTemplate；构造仅保留引用
     */
    public CrmDocumentDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 同sortnum单据追加范围内唯一ID，避免库存列表翻页重复或遗漏。
     *
     * @param conditions 已核验的范围和类型，例如tenant92/org901/STOCK_ISSUE/SALE
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 原真实公共分页，例如两笔实际出库单的第2笔及totalCount2；只读不改状态
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 原主排序保留，唯一ID只打破平局；范围、COUNT与分页仍走公共DAO。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmDocument WHERE tenantId=? AND businessOrgId=? AND id=?"
                                + " AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 只查本表来源，锁序先Order再Document。
     *
     * @param input 例如org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public Map<String, Object> sourceReference(CommonParam input) {
        requireCrmTransaction();
        var r =
                jdbc.queryForList(
                        "SELECT orderId,documentKind,reason FROM CrmDocument WHERE tenantId=? AND"
                                + " businessOrgId=? AND id=? AND status=1",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return r.isEmpty() ? null : r.get(0);
    }

    /**
     * DRAFT仅换同来源头，来源永不原地换单。
     *
     * @param input 例如org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public int updateDraft(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmDocument SET"
                    + " versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
                    + " WHERE tenantId=? AND businessOrgId=? AND id=? AND orderId=? AND"
                    + " documentState='DRAFT' AND versionNo=? AND versionNo<9223372036854775807 AND"
                    + " status=1",
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("orderId"),
                input.getParam("expectedVersion"));
    }

    /**
     * 只通过条件CAS推进状态，POST保留审批冻结；退回DRAFT清当前提交人，历史仍在原审计。
     *
     * @param input 例如org901/id1000000/expectedVersion0；实际actor由Session给出
     * @return 实际本表结果；缺范围/事务拒绝
     */
    @Override
    public int transition(CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "UPDATE CrmDocument SET"
                    + " documentState=?,versionNo=versionNo+1,submittedByUserId=CASE WHEN"
                    + " ?='DRAFT' THEN NULL WHEN ?='SUBMITTED' THEN ? ELSE submittedByUserId END,approvedByUserId=CASE WHEN"
                    + " ?='APPROVED' THEN ? ELSE approvedByUserId END,approvedSnapshotHash=CASE"
                    + " WHEN ?='APPROVED' THEN ? ELSE approvedSnapshotHash END,frozenSnapshot=CASE"
                    + " WHEN ?='APPROVED' THEN ? ELSE frozenSnapshot END,postedByUserId=CASE WHEN"
                    + " ?='POSTED' THEN ? ELSE postedByUserId"
                    + " END,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP WHERE"
                    + " tenantId=? AND businessOrgId=? AND id=? AND versionNo=? AND"
                    + " versionNo<9223372036854775807 AND documentState=? AND status=1",
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("nextState"),
                input.getParam("approvedSnapshotHash"),
                input.getParam("nextState"),
                input.getParam("frozenSnapshot"),
                input.getParam("nextState"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("actorUserId"),
                input.getParam("tenantId"),
                input.getParam("businessOrgId"),
                input.getParam("id"),
                input.getParam("expectedVersion"),
                input.getParam("previousState"));
    }
}
