/* 自定义客户类型附加结构；2026-10-26，不迁移原业务记录。 */
package com.sp.selplat.crm.common.persistence;

import com.sp.selplat.crm.common.config.CrmBusinessStructureConfiguration.CrmBusinessStructureInspector;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionTemplate;

/** 仅在原经营组织客户结构实际可用时附加类型表；不打开原隔离开关或授予权限。 */
@Configuration(proxyBeanMethods = false)
public class CrmCustomerTypePersistenceConfiguration {
    /**
     * 方法作用：创建幂等新类型表并补本表号段，原客户和原命令约束均不修改。
     * @param source 实际具名CRM数据源，例如独立CRM数据库
     * @param inspector 原结构检查器，例如实际partner已安装
     * @return 真实返回示例：true代表新结构已安装；原partner未安装为false。
     * 异常或副作用示例：新表DDL失败沿初始化失败传播，不伪装成功或创建默认业务类型。
     */
    @Bean("crmCustomerTypesInitialized")
    @DependsOn("crmBusinessStructureInspector")
    public Boolean initialize(@Qualifier("crmDataSource") DataSource source,
            @Qualifier("crmBusinessStructureInspector") CrmBusinessStructureInspector inspector) {
        if (!inspector.available().contains("partner")) {
            return false;
        }
        new ResourceDatabasePopulator(new ClassPathResource("db/crm/sql/schema-CrmCustomerType.sql"),
                new ClassPathResource("db/crm/sql/schema-CrmCustomerTypeSelection.sql"))
                .execute(source);
        new TransactionTemplate(new DataSourceTransactionManager(source)).executeWithoutResult(state ->
                new ResourceDatabasePopulator(new ClassPathResource("db/crm/sql/data-CommonSequenceSegment.sql"))
                        .execute(source));
        return true;
    }
}
