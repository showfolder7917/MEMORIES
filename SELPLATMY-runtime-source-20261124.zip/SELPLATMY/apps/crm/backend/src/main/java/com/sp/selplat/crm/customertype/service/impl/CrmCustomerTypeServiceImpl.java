/* 客户类型自定义保存；2026-10-26，保留本表历史及原CRM范围。 */
package com.sp.selplat.crm.customertype.service.impl;

import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.text;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.version;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.customertype.dao.CrmCustomerTypeDao;
import com.sp.selplat.crm.customertype.service.CrmCustomerTypeService;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

/** 类型是组织内业务分类，不增删用户许可；自带变更历史不修改旧命令表约束。 */
@Service
public class CrmCustomerTypeServiceImpl extends BaseServiceImpl<CrmCustomerTypeDao>
        implements CrmCustomerTypeService {
    // 原CRM主体范围入口，创建分类不能成为授权来源。
    private final CrmAccessService access;
    // 所有类型写入及历史保存在同一CRM事务。
    private final TransactionTemplate transaction;

    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/id100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    @Override
    @OperationLog
    public CommonResult history(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "id"));
        var query = new CommonParam();
        scopeKey(scope).forEach(query::putParam);
        query.putParam("id", positive(input.getParam("id")));
        query.putParam("status", 1);
        var row = getDao().getByQuery(query);
        if (row == null) { throw failure("CRM_RECORD_NOT_FOUND"); }
        var entries = com.sp.selplat.crm.common.util.customer.CrmCustomerHistorySupport.project(
                row == null ? null : row.get("changeHistoryJson"));
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(Map.of("resourceId", input.getParam("id").toString(),
                "readOnly", true, "entries", entries), "分类历史读取完成。");
    }

    /**
     * 方法作用：装配原准入及具名事务；DAO由公共BaseService绑定。
     * @param access 实际CRM范围Service，例如org901/actor9211
     * @param manager 原crmTransactionManager，例如同一CRM池的事务管理器
     * 异常或副作用示例：构造不新增默认分类或更改任何客户。
     */
    public CrmCustomerTypeServiceImpl(CrmAccessService access,
            @Qualifier("crmTransactionManager") PlatformTransactionManager manager) {
        this.access = access;
        transaction = new TransactionTemplate(manager);
        transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 方法作用：读取可信组织的有界目录，停用项可供历史维护选择。
     * @param input HTTP候选，例如organizationCandidateId=901/includeDisabled=true
     * @return 真实返回示例：success=true/data.types=[{id:"100000",typeName:"家长",versionNo:"0"}]
     * 异常或副作用示例：无原客户读取资格拒绝，超过500项不截断冒充完整目录。
     */
    @Override
    @OperationLog
    public CommonResult directory(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "includeDisabled"));
        Map<String, Object> conditions = new LinkedHashMap<>(scopeKey(scope));
        conditions.put("status", 1);
        // 新建客户只选启用类型，类型管理显式请求停用项。
        if (!flag(input.getParam("includeDisabled"), false)) {
            conditions.put("enabledFlag", true);
        }
        var page = getDao().getPageList(conditions, "sortnum desc id asc", 1, 501);
        if (page.getTotalCount() > 500) {
            throw failure("CRM_TYPE_DIRECTORY_LIMIT");
        }
        var records = page.getRecords().stream().map(this::projection).toList();
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(Map.of("types", records), "客户类型读取完成。");
    }

    /**
     * 方法作用：保存类型及追加审计，创建重试和旧修改重试都返回原结果版本。
     * @param input HTTP候选，例如org901/requestKey=type-1/typeName=校友/enabledFlag=true
     * @return 真实返回示例：success=true/data={id:"100000",versionNo:"0",replay:false}
     * 异常或副作用示例：旧版、重名、同键异内容或提交前资格变化整体回滚。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.NOT_SUPPORTED)
    public CommonResult save(CommonParam input) {
        access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.write");
        var normalized = normalize(input);
        String hash = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
        try {
            return access.executeTransaction(normalized.getParam("organizationCandidateId"),
                    "crm.partner.write", transaction, state -> store(normalized, hash));
        } catch (DataIntegrityViolationException conflict) {
            // 创建并发唯一冲突必须离开失败事务后核对已提交的原请求，不重用失败连接。
            var scope = access.requirePartnerScope(normalized.getParam("organizationCandidateId"), "crm.partner.write");
            if (normalized.getParam("id") == null) {
                var first = creation(scope, normalized.getParam("requestKey"));
                if (first != null && !first.isEmpty()) {
                    return creationReplay(first, hash);
                }
            }
            throw failure("CRM_TYPE_NAME_EXISTS");
        }
    }

    /**
     * 方法作用：在已开启CRM事务内完成一个对象的版本变更和审计。
     * @param input 规范正文，例如org901/id100000/expectedVersion0/typeName家长
     * @param hash 服务端正文摘要，例如64位SHA256文本
     * @return 真实返回示例：data.id=100000/versionNo=1/replay=false
     * 异常或副作用示例：记录失效、旧版或同键异内容拒绝，历史不覆盖。
     */
    private CommonResult store(CommonParam input, String hash) {
        var scope = access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        var row = new CommonParam();
        scopeKey(scope).forEach(row::putParam);
        row.putParam("typeName", input.getParam("typeName"));
        row.putParam("typeNameKey", input.getParam("typeName").toString().toLowerCase(Locale.ROOT));
        row.putParam("enabledFlag", input.getParam("enabledFlag"));
        row.putParam("sortnum", input.getParam("sortnum"));
        row.putParam("lastOperateUserId", scope.get("actorUserId"));
        long id;
        long next;
        List<Map<String, Object>> history = new ArrayList<>();
        Map<String, Object> before = Map.of();
        if (input.getParam("id") == null) {
            var first = creation(scope, input.getParam("requestKey"));
            if (first != null && !first.isEmpty()) {
                return creationReplay(first, hash);
            }
            id = getSequence().get("id");
            next = 0;
            row.putParam("code", "CrmCustomerType_" + id);
            row.putParam("creationRequestKey", input.getParam("requestKey"));
            row.putParam("creationHash", hash);
            row.putParam("versionNo", next);
            row.putParam("status", 1);
        } else {
            id = positive(input.getParam("id"));
            var selected = new CommonParam();
            scopeKey(scope).forEach(selected::putParam);
            selected.putParam("id", id);
            var existing = getDao().lockScoped(selected);
            if (existing == null) {
                throw failure("CRM_RECORD_NOT_FOUND");
            }
            history = history(existing.get("changeHistoryJson"));
            // 同对象请求键在完整历史中保留，后来修改不能改变早先重试的结果版本。
            for (var event : history) {
                if (input.getParam("requestKey").equals(event.get("requestKey"))) {
                    if (!hash.equals(event.get("payloadHash"))) {
                        throw failure("CRM_COMMAND_CONFLICT");
                    }
                    return receipt(id, version(event.get("versionNo")), true);
                }
            }
            long prior = version(existing.get("versionNo"));
            if (prior != version(input.getParam("expectedVersion")) || prior == Long.MAX_VALUE) {
                throw failure("STALE_CRM_VERSION");
            }
            before = projection(existing);
            next = prior + 1;
            row.putParam("expectedVersion", prior);
        }
        if (history.size() >= 2000) {
            throw failure("CRM_TYPE_HISTORY_LIMIT");
        }
        row.putParam("id", id);
        Map<String, Object> event = new LinkedHashMap<>();
        event.put("requestKey", input.getParam("requestKey"));
        event.put("payloadHash", hash);
        event.put("versionNo", next);
        event.put("actorUserId", scope.get("actorUserId").toString());
        event.put("recordedAt", Instant.now().toString());
        event.put("before", before);
        event.put("after", Map.of("typeName", input.getParam("typeName"), "enabledFlag",
                input.getParam("enabledFlag"), "sortnum", input.getParam("sortnum")));
        history.add(event);
        row.putParam("changeHistoryJson", JsonUtils.toJsonIgnoreNull(history));
        int affected = input.getParam("id") == null ? getDao().insert(row) : getDao().updateVersion(row);
        if (affected != 1) {
            throw failure("STALE_CRM_VERSION");
        }
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        return receipt(id, next, false);
    }

    /**
     * 方法作用：按可信组织和创建请求查询首次记录。
     * @param scope 原准入范围，例如tenantId92/businessOrgId901
     * @param key 对象创建请求，例如type-1
     * @return 真实返回示例：id100000/creationHash；未命中为空或null。
     * 异常或副作用示例：只读本表，不依姓名合并分类。
     */
    private Map<String, Object> creation(Map<String, Object> scope, Object key) {
        var query = new CommonParam();
        scopeKey(scope).forEach(query::putParam);
        query.putParam("creationRequestKey", key);
        query.putParam("status", 1);
        return getDao().getByQuery(query);
    }

    /**
     * 方法作用：首次请求摘要相同才重放，不以当前名称代替首次正文。
     * @param first 原记录，例如id100000/creationHash64位文本
     * @param hash 本次规范摘要，例如同一类型创建正文SHA256
     * @return 真实返回示例：data={id:"100000",versionNo:"0",replay:true}
     * 异常或副作用示例：同键不同名称抛CRM_COMMAND_CONFLICT。
     */
    private CommonResult creationReplay(Map<String, Object> first, String hash) {
        if (!hash.equals(first.get("creationHash"))) {
            throw failure("CRM_COMMAND_CONFLICT");
        }
        return receipt(positive(first.get("id")), 0, true);
    }

    /**
     * 方法作用：建立公开回执，精确ID和版本不转换为JavaScript浮点数。
     * @param id 实际主键，例如100000
     * @param revision 实际首次结果版本，例如0
     * @param replay 原结果重放，例如true
     * @return 真实返回示例：success=true/data={id:"100000",versionNo:"0",replay:true}
     * 异常或副作用示例：纯组装，不标记未提交数据为已保存。
     */
    private CommonResult receipt(long id, long revision, boolean replay) {
        return buildSuccessResult(Map.of("id", Long.toString(id), "versionNo", Long.toString(revision),
                "replay", replay), "客户类型已保存。");
    }

    /**
     * 方法作用：公开必要显示字段，不把请求正文与操作历史混入选择目录。
     * @param row 本表实际行，例如id100000/typeName家长/versionNo0
     * @return 真实返回示例：{id:"100000",typeName:"家长",enabledFlag:true,versionNo:"0",sortnum:0}
     * 异常或副作用示例：纯映射，不修改DAO返回行。
     */
    private Map<String, Object> projection(Map<String, Object> row) {
        return Map.of("id", row.get("id").toString(), "typeName", row.get("typeName"),
                "enabledFlag", row.get("enabledFlag"), "versionNo", row.get("versionNo").toString(),
                "sortnum", row.get("sortnum"));
    }

    /**
     * 方法作用：规范完整保存白名单，可信归属由原范围入口提供。
     * @param input HTTP候选，例如org901/typeName家长/requestKeytype-1
     * @return 真实返回示例：CommonParam含组织901、名称家长、启用true、排序0及请求键。
     * 异常或副作用示例：客户端tenantId、非法布尔、空名或控制字符拒绝。
     */
    private static CommonParam normalize(CommonParam input) {
        keys(input, Set.of("organizationCandidateId", "id", "expectedVersion", "requestKey",
                "typeName", "enabledFlag", "sortnum"));
        String name = text(input.getParam("typeName"), 100, true);
        String key = text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+") || name.chars().anyMatch(Character::isISOControl)) {
            throw failure("INVALID_CRM_INPUT");
        }
        BigDecimal order;
        try {
            order = new BigDecimal(String.valueOf(input.getParam("sortnum") == null ? "0" : input.getParam("sortnum")));
            if (order.abs().compareTo(new BigDecimal("99999999.99")) > 0 || order.scale() > 2) {
                throw new NumberFormatException("sortnum");
            }
        } catch (NumberFormatException invalid) {
            throw failure("INVALID_CRM_INPUT");
        }
        var normalized = new CommonParam();
        normalized.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
        normalized.putParam("requestKey", key);
        normalized.putParam("typeName", name);
        normalized.putParam("enabledFlag", flag(input.getParam("enabledFlag"), true));
        normalized.putParam("sortnum", order.setScale(2));
        if (input.getParam("id") != null) {
            normalized.putParam("id", positive(input.getParam("id")));
            normalized.putParam("expectedVersion", version(input.getParam("expectedVersion")));
        } else if (input.getParam("expectedVersion") != null) {
            throw failure("INVALID_CRM_VERSION");
        }
        return normalized;
    }

    /**
     * 方法作用：提取服务端可信组织复合条件。
     * @param scope 已核范围，例如tenantId92/businessOrgId901/actorUserId9211
     * @return 真实返回示例：{tenantId:92,businessOrgId:901}
     * 异常或副作用示例：不接受客户端tenantId或扩展全库查询。
     */
    private static Map<String, Object> scopeKey(Map<String, Object> scope) {
        return Map.of("tenantId", scope.get("tenantId"), "businessOrgId", scope.get("businessOrgId"));
    }

    /**
     * 方法作用：读取保存的本表历史，拒绝损坏内容而非丢弃审计。
     * @param value 已保存JSON，例如包含requestKey=type-1/versionNo=0的数组
     * @return 真实返回示例：可追加的历史列表，原数据不变。
     * 异常或副作用示例：损坏JSON传播系统失败，不重置为空历史。
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> history(Object value) {
        return new ArrayList<>((List<Map<String, Object>>) (List<?>) JsonUtils.fromJson(value.toString(), List.class));
    }

    /**
     * 方法作用：白名单字段检查。
     * @param input 候选，例如organizationCandidateId901
     * @param allowed 本接口字段集合，例如组织和includeDisabled
     * 异常或副作用示例：未知tenantId拒绝；不查询数据库。
     */
    private static void keys(CommonParam input, Set<String> allowed) {
        if (input == null || !allowed.containsAll(input.getParamMap().keySet())) {
            throw failure("INVALID_CRM_INPUT");
        }
    }

    /**
     * 方法作用：安全提取空候选，让原范围入口先裁决身份。
     * @param input HTTP候选，例如null
     * @param key 字段，例如organizationCandidateId
     * @return 真实返回示例：null或901。
     * 异常或副作用示例：纯读取，不建立默认组织。
     */
    private static Object value(CommonParam input, String key) {
        return input == null ? null : input.getParam(key);
    }

    /**
     * 方法作用：接受实际布尔或明确文本，不把任意字符串当作true。
     * @param value 候选，例如true或"false"
     * @param fallback 未提供时默认值，例如目录false
     * @return 真实返回示例：false。
     * 异常或副作用示例：非true/false文本拒绝。
     */
    private static boolean flag(Object value, boolean fallback) {
        if (value == null) { return fallback; }
        if (Boolean.TRUE.equals(value) || "true".equals(value)) { return true; }
        if (Boolean.FALSE.equals(value) || "false".equals(value)) { return false; }
        throw failure("INVALID_CRM_INPUT");
    }

    /**
     * 方法作用：锁定真实类型，调用者再判断新选或保留停用引用。
     * @param input 服务间候选，例如organizationCandidateId901/id100000
     * @return 真实返回示例：id100000/enabledFlagfalse/versionNo2的安全投影。
     * 异常或副作用示例：无事务、无许可或无记录拒绝；不修改类型。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
    public Map<String, Object> lockForSelection(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.write");
        keys(input, Set.of("organizationCandidateId", "id"));
        var p = new CommonParam();
        scopeKey(scope).forEach(p::putParam);
        p.putParam("id", positive(input.getParam("id")));
        var row = getDao().lockScoped(p);
        if (row == null) { throw failure("CRM_RECORD_NOT_FOUND"); }
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        return projection(row);
    }

    /**
     * 方法作用：当前租户来自原CRM会话。
     * @return 真实返回示例：92。
     * 异常或副作用示例：匿名拒绝，不使用默认租户。
     */
    @Override protected Long getCurrentTenantId() { return access.requireDraftActor().get("tenantId"); }

    /**
     * 方法作用：真实操作人来自原CRM会话。
     * @return 真实返回示例：9211。
     * 异常或副作用示例：失效账号拒绝，不接受请求operatorId。
     */
    @Override protected Long getCurrentOperatorId() { return access.requireDraftActor().get("ownerUserId"); }

    /**
     * 方法作用：不因类型维护产生默认管理员身份。
     * @return 真实返回示例：false。
     * 异常或副作用示例：纯声明，不改权限。
     */
    @Override protected boolean isAdmin() { return false; }

    /**
     * 方法作用：关闭无版本通用写，所有保存走本表具名事务。
     * @param input 通用写入候选，例如id100000
     * 异常或副作用示例：一律CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override protected void applyCurrentIdentity(CommonParam input) { throw failure("CRM_GENERIC_WRITE_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用分页。
     * @param input 通用分页候选，例如pageNo1
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED，改用有范围directory。
     */
    @Override public CommonPageResult getStore(CommonPageParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用单项读取。
     * @param input 通用候选，例如id100000
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED。
     */
    @Override public CommonResult getById(CommonParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用批量读取。
     * @param input 通用候选，例如items内id100000
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED。
     */
    @Override public CommonResult getByIds(CommonBatchParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }
}
