/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.documentline.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 本表owning服务，只读HTTP和具名CRM事务扩展。 */
public interface CrmDocumentLineService extends com.sp.selplat.common.service.BaseService {
    /**
     * 精确本组织内部锁；缺实际许可或事务拒绝。
     *
     * @param input org901/id1000000
     * @param action 固定stock.post等动作
     * @return 真实范围行；不存在统一拒绝
     */
    Map<String, Object> lockScoped(CommonParam input, String action);

    /**
     * 全量父行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     * @param action 服务内部选择的固定动作，例如crm.stock.post；不得据客户端动作补授权限。
     */
    List<Map<String, Object>> readAll(CommonParam input, String action);

    /**
     * 同一CRM事务插入效果/行；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     * @return 实际本表结果；缺范围/事务拒绝
     * @param action 服务内部选择的固定动作，例如crm.stock.post；不得据客户端动作补授权限。
     */
    Long append(CommonParam input, String action);

    /**
     * 本表替换前删除；固定本表事务扩展。
     *
     * @param input org901/id1000000及实际服务器字段
     */
    void clearDraft(CommonParam input);

    /**
     * 方法作用：owning行服务按真实冲正范围查下游引用。
     *
     * @param input org901/parent1300000
     * @return 实际行，不信人工依赖布尔值 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    List<Map<String, Object>> receiptChildren(CommonParam input);
}
