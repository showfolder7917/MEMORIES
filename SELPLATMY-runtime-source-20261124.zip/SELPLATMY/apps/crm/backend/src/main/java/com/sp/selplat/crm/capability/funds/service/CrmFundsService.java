/** 单一销售出库能力；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.capability.funds.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 聚合多个owning服务的具名原子POST，不拥有表或DAO。 */
public interface CrmFundsService {
    /**
     * 明确POST整个审核销售出库，不允许REVERSE。
     *
     * @param input org901/id1000000/actionPOST/expectedVersion2/requestKeyp1
     * @return 实际postingBatchId、全部detailIds、POSTED/version3/replay
     */
    CommonResult execute(CommonParam input);

    /**
     * 实际本组织批次与全部流水。
     *
     * @param input org901/id1200000
     * @return 同一真实批次头/全部detail；跨组织统一拒绝
     */
    CommonResult batch(CommonParam input);

    /**
     * 实际销售出库后台聚合配置。
     *
     * @param input org901/page1/langzh-CN
     * @return 实际单据、审核订单、仓库、余额、流水及三语SELUI配置
     */
    CommonResult workspace(CommonPageParam input);

    /**
     * 方法作用：读取真实活动课时预留对应原净额的退款上限，仅准备财务审核，不执行现金。
     * @param input studentId50/curriculumCourseId400/reservationId100000，不接受金额、组织或已付款覆盖
     * @return 真实示例：maximumRefundMinor18/currencyCNY/quoteStateREVIEW_ONLY，原费用不退。
     * 异常或副作用示例：缺真实预留、已取消、原现金来源变化或资金读取资格不足拒绝，零写入。
     */
    CommonResult courseRefundQuote(CommonParam input);
    /**
     * Actual frozen due/settled/unsettled query, not payment execution.
     *
     * @param input org901/orderId600000
     * @return real order and source line minor values
     */
    CommonResult source(CommonParam input);
}
