/** CrmStockBalanceService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.stockbalance.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;

/** 本人隔离过账记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmStockBalanceService extends BaseService {
    /**
     * 本表原子流程扩展 lockScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 applyDeltaIfVersion，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖 成功副作用：条件更新恰好一行。
     *     异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    void applyDeltaIfVersion(com.sp.selplat.common.util.CommonParam input);

    /**
     * 组织V2出库，旧owner入口保留。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    java.util.Map<String, Object> lockOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查 成功副作用：本表实际结果或无返回；零CAS、缺许可或约束异常整笔回滚
     */
    void issueOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查
     * @return 本表实际结果或无返回；零CAS、缺许可或约束异常整笔回滚
     */
    CommonPageResult organizationStore(CommonPageParam input);

    /**
     * 按现有库存许可增加已核验采购数量，不自动创建余额或期初。
     *
     * @param input org901/id880001/version0/quantity2 异常或副作用示例：成功余额10→12、版本0→1；零CAS/越组织/缺许可整笔回滚。
     */
    void receiveOrganization(CommonParam input);

    /**
     * 当前库存reverse范围下锁真实维度，不以post许可代用；例如org901/warehouse801/product701返回余额880001。
     *
     * @param input org901/warehouse801/product701
     * @return 实际EA余额，无创建
     */
    java.util.Map<String, Object> lockForStockReverse(com.sp.selplat.common.util.CommonParam input);

    /**
     * 原POST符号由冻结执行派生后聚合反向CAS；例如delta+3/余额7→10或delta-3/余额10→7，旧版本回滚。
     *
     * @param input org901/id880001/version3/quantityDelta3，不接受HTTP直接金额
     */
    void applyStockReverse(com.sp.selplat.common.util.CommonParam input);
}
