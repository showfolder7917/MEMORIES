/* 客户稳定编号关系HTTP入口；2026-10-28。 */
package com.sp.selplat.crm.customerrelation.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.customerrelation.service.CrmCustomerRelationService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只转交本关系Service，不开放无范围通用CRUD。 */
@RestController
@RequestMapping("/api/crm/customer-relations")
public class CrmCustomerRelationController {
    // 原关系拥有方负责身份、组织、客户锁和版本。
    private final CrmCustomerRelationService service;

    /**
     * 方法作用：绑定实际关系Service，不初始化业务数据。
     * @param service 实际CrmCustomerRelationServiceImpl
     * 异常或副作用示例：构造只保留原依赖。
     */
    public CrmCustomerRelationController(CrmCustomerRelationService service) { this.service = service; }

    /**
     * 方法作用：返回原关系真实双向分页。
     * @param input HTTP候选，例如org901/partner200000/pageNo1
     * @return 真实返回示例：success=true/data.page.totalCount=2。
     * 异常或副作用示例：无读取资格由拥有方拒绝，无业务写入。
     */
    @GetMapping("page.htm")
    public String page(CommonPageParam input) { return JsonUtils.toJsonIgnoreNull(service.page(input)); }

    /**
     * 方法作用：返回明确两端客户及关系当前版本。
     * @param input HTTP候选，例如partner200000/related200001
     * @return 真实返回示例：success=true/data.relation.versionNo="1"。
     * 异常或副作用示例：跨组织或自关联拒绝，不按名称关联。
     */
    @GetMapping("read.htm")
    public String read(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.read(input)); }

    /**
     * 方法作用：将完整候选交原关系拥有方版本保存。
     * @param input HTTP候选，例如org901/requestKey原UUID/expectedVersion0/relationName孩子
     * @return 真实返回示例：success=true/data.id="100000"/versionNo="1"。
     * 异常或副作用示例：旧版本和失效资格拒绝，不产生部分历史。
     */
    @PostMapping("save.htm")
    public String save(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.save(input)); }
}
