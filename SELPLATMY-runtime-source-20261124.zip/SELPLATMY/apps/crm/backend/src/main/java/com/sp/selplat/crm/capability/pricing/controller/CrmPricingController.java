/**
 * CrmPricingController.java：公共参数解析后的新订单计算入口。
 * 修改记录：2026-10-03，Codex 复用CommonParam/JsonUtils，不另造HTTP协议。
 */
package com.sp.selplat.crm.capability.pricing.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.pricing.service.CrmPricingService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只调用本能力Service，不查表、不执行SQL、不开放保存或审批动作。 */
@RestController
@RequestMapping("/api/crm/pricing")
public class CrmPricingController {
    // 公共结果由Service拥有，Controller仅完整序列化。
    private final CrmPricingService service;

    /**
     * 装配真实计算服务。
     * @param service Spring装配的CrmPricingServiceImpl
     * 副作用示例：构造不查询账号或金额。
     */
    public CrmPricingController(CrmPricingService service) {
        this.service = service;
    }

    /**
     * 接收显式新单输入并完整序列化公共计算结果。
     * @param input 公共解析器参数，例如currency=CNY/fee=0/lines数量1单价1.00
     * @return JSON，例如success=true、data.totalMinor=100、data.writeEnabled=false
     * @throws com.sp.selplat.common.exception.CommonBusinessException 身份/输入错误交公共异常处理器，不写库
     */
    @PostMapping("preview.htm")
    public String preview(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.preview(input));
    }
}
