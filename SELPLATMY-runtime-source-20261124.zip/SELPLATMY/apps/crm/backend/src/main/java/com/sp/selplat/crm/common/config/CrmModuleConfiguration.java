/**
 * CrmModuleConfiguration.java：CRM 本域平台分层实现。
 * 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。
 */
package com.sp.selplat.crm.common.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/** CRM 由统一 Host 显式装配，只扫描本域组件；统一身份仍由 Host 装配。 */
@Configuration(proxyBeanMethods = false)
@ComponentScan("com.sp.selplat.crm")
public class CrmModuleConfiguration {
}
