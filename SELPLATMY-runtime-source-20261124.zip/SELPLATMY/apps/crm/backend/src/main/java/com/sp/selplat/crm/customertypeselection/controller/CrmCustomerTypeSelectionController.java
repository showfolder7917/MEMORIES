/* 客户类型选择HTTP入口；2026-10-26。 */
package com.sp.selplat.crm.customertypeselection.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.customertypeselection.service.CrmCustomerTypeSelectionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只序列化本选择Service的完整返回，不公开无范围通用CRUD。 */
@RestController
@RequestMapping("/api/crm/customer-type-selection")
public class CrmCustomerTypeSelectionController {
    // 组织范围、客户和类型核验均留在业务拥有方。
    private final CrmCustomerTypeSelectionService service;

    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    @GetMapping("history.htm")
    public String history(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.history(input)); }

    /**
     * 方法作用：装配实际选择服务。
     * @param service 实际CrmCustomerTypeSelectionServiceImpl
     * 异常或副作用示例：只绑定依赖，不更改已有客户。
     */
    public CrmCustomerTypeSelectionController(CrmCustomerTypeSelectionService service) {
        this.service = service;
    }

    /**
     * 方法作用：返回实际客户分类和组织目录。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId200000
     * @return 真实返回示例：success=true/data.versionNo="0"/data.typeIds=[]。
     * 异常或副作用示例：缺读取资格由Service拒绝，无写入。
     */
    @GetMapping("read.htm")
    public String read(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.read(input)); }

    /**
     * 方法作用：保存客户多类型选择，序列化完整业务回执。
     * @param input HTTP候选，例如partnerId200000/expectedVersion0/typeIdsJson[]/requestKeypick-1
     * @return 真实返回示例：success=true/data={partnerId:"200000",versionNo:"1",replay:false}。
     * 异常或副作用示例：版本冲突或停用类型由Service拒绝，零部分写入。
     */
    @PostMapping("save.htm")
    public String save(CommonParam input) { return JsonUtils.toJsonIgnoreNull(service.save(input)); }
}
