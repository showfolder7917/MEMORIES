/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.warehouse.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表固定参数化SQL与公共模板共用CRM连接。 */
@org.springframework.stereotype.Repository
public class CrmWarehouseDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
        implements CrmWarehouseDao {
    private final org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 注入本域固定模板；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmWarehouseDaoImpl(
            @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
                    org.springframework.jdbc.core.JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 原sortnum主排序追加范围内唯一ID，稳定仓库参考页与重复翻页。
     *
     * @param conditions 服务核验的范围，例如tenant92/org901/status1
     * @param pageNo 原实际页码，例如2
     * @param pageSize 原实际页长，例如1
     * @return 真实分页，例如仓库802及totalCount2；只读且不改变范围或COUNT
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        // 唯一ID打破同sortnum平局，实际SQL及分页仍复用公共DAO。
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    /**
     * 本表范围锁，不从客户端读取可信org。
     *
     * @param input 例如tenant92/org901/id1000000
     * @return 实际有效行或null；事务缺失时拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam input) {
        requireCrmTransaction();
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmWarehouse WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("businessOrgId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }
}
