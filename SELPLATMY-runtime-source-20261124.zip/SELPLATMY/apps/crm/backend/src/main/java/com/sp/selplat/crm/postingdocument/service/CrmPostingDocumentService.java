/** CrmPostingDocumentService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingdocument.service;

import com.sp.selplat.common.service.BaseService;

/** 本人隔离过账记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmPostingDocumentService extends BaseService {
    /**
     * 本表原子流程扩展 findScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> findScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 lockScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> lockScoped(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 changeStateIfVersion，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖 副作用：成功条件更新恰好一行；失败由调用事务回滚。
     */
    void changeStateIfVersion(com.sp.selplat.common.util.CommonParam input);

    /**
     * 原子单动作；输入例如{id:101,action:POST,requestKey:r1,expectedVersion:0}；返回真实状态/流水ID；失败全部回滚。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：原子单动作；输入例如{id:101,action:POST,requestKey:r1,expectedVersion:0}；返回真实状态/流水ID；失败全部回滚。
     * @return 真实状态/流水ID
     */
    com.sp.selplat.common.util.CommonResult executeAtomic(
            com.sp.selplat.common.util.CommonParam input);
}
