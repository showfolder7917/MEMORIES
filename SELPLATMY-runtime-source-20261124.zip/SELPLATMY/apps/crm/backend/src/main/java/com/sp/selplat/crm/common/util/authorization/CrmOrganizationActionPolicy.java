/* 文件：CrmOrganizationActionPolicy.java；职责：CRM组织资源的独立动作合同；2026-10-14。 */
package com.sp.selplat.crm.common.util.authorization;

import com.sp.selplat.common.service.authorization.ExactGrantCoordinates;

import java.util.Map;
import java.util.Set;

/** 精确CRM组织资源不是任意资源通配许可；收款沿原五动作，冲正仍受原独立门禁保护。 */
public final class CrmOrganizationActionPolicy {
    // 逐动作声明只是支持目录，不能自动生成任何组织、成员或许可。
    public static final Set<String> ACTIONS = Set.of(
            "crm.product.read", "crm.product.write",
            "crm.partner.read", "crm.partner.write", "crm.audit.read",
            "crm.order.read", "crm.order.write", "crm.order.submit", "crm.order.approve",
            "crm.stock.read", "crm.stock.write", "crm.stock.submit", "crm.stock.approve",
            "crm.stock.post", "crm.stock.reverse",
            "crm.funds.read", "crm.funds.write", "crm.funds.submit", "crm.funds.approve", "crm.funds.post");

    /** 方法作用：禁止实例化；异常或副作用示例：不建立状态或授予关系。 */
    private CrmOrganizationActionPolicy() { }

    /**
     * 方法作用：限定CRM动作及明确经营组织资源，拒绝跨组织、未知动作及尚未接入的资金冲正。
     * @param expected 统一owner已校验的七坐标，例如crm.order.write/CRM_ORGANIZATION901/org901
     * @return 真实返回示例：组织901一致且动作已声明为true；资源902或crm.funds.reverse为false。
     * 异常或副作用示例：空字段拒绝，不查询、创建或升级任何许可。
     */
    public static boolean supports(Map<String, Object> expected) {
        // 单独授予的组织资源只覆盖这一经营组织，不允许换成任意订单主键。
        return expected != null && "crm".equals(expected.get("application"))
                && "CRM_ORGANIZATION".equals(expected.get("resourceType"))
                && expected.get("action") instanceof String action && ACTIONS.contains(action)
                && ExactGrantCoordinates.sameId(expected.get("organizationId"), expected.get("resourceId"));
    }
}
