/** 一期销售退货退款真实原引用读取；2026-10-04，Codex；复用原owning服务。
 * 修改记录：2026-10-10，空原明细查询遵守原参数拒绝合同，避免校验前空指针。 */
package com.sp.selplat.crm.capability.salesreturn.service.impl;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.capability.salesreturn.service.CrmSalesReturnService;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnWorkspaceSupport;
import com.sp.selplat.crm.document.service.CrmDocumentService;
import com.sp.selplat.crm.order.service.CrmOrderService;
import com.sp.selplat.crm.postingbatch.service.CrmPostingBatchService;
import com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService;
import com.sp.selplat.crm.postingdetail.service.CrmPostingDetailService;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 非持久化能力只调owning服务；现有库存或资金读许可分别决定引用可见性。 */
@Service
public class CrmSalesReturnServiceImpl implements CrmSalesReturnService {
    // 统一身份核当前真实组织读许可，不创建默认用户或扩权。
    private final CrmAccessService access;
    // 来源订单先锁，保证引用数量/金额来自同一已核冻结销售来源。
    private final CrmOrderService orders;
    // 明细owning服务提供本来源完整不可变原POST候选。
    private final CrmPostingDetailService details;
    // 单据owning服务重核真实父POSTED与业务类型。
    private final CrmDocumentService documents;
    // 批次owning服务剔除已经真实REVERSE的原效果。
    private final CrmPostingBatchService batches;
    // 剩余额度来自容量表实际已用，不凭前端数量或余额推算。
    private final CrmPostingCapacityService capacities;
    // 显式退货隔离结构门禁，旧环境及生产默认关闭。
    private final Boolean enabled;

    /**
     * 绑定本域真实owning事实和读取门禁，不写业务数据。
     *
     * @param access 真实Session/组织读范围，例如tenant92/org901
     * @param orders 原销售订单服务，例如锁APPROVED600000
     * @param details 不可变原明细服务，例如读source600001
     * @param documents 原真实单据服务，例如POSTED1000000
     * @param batches 原批次历史服务，例如POST1200000或真实REVERSE
     * @param capacities 实际剩余量/金额服务，例如quantity3-used1=2
     * @param enabled 显式crmSalesReturnIsolatedEnabled，例如合成环境true
     */
    public CrmSalesReturnServiceImpl(
            CrmAccessService access,
            CrmOrderService orders,
            CrmPostingDetailService details,
            CrmDocumentService documents,
            CrmPostingBatchService batches,
            CrmPostingCapacityService capacities,
            @Qualifier("crmSalesReturnIsolatedEnabled") Boolean enabled) {
        this.access = access;
        this.orders = orders;
        this.details = details;
        this.documents = documents;
        this.batches = batches;
        this.capacities = capacities;
        this.enabled = enabled;
    }

    /**
     * 候选组织和固定真实关联键，不传播客户端可信身份。
     *
     * @param input org901读取候选
     * @param key 固定id或documentId
     * @param value 实际id例如600000
     * @return 新参数，例如{organizationCandidateId:901,id:600000}
     */
    private CommonParam relation(CommonPageParam input, String key, Object value) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam(key, value);
        return p;
    }

    /**
     * 同销售来源真实原明细及剩余量/金额读取，已退或已退满额度不再作为可用候选。
     *
     * @param input org901/order600000/source600001/ISSUE_RETURN/page1/langzh-CN
     * @return 实际公共Grid配置，例如id1300000/remainingQuantity2，REMOTE total1/page1/20；缺真实读权拒绝
     */
    @Override
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = Propagation.REQUIRES_NEW,
            readOnly = true)
    @SuppressWarnings("unchecked")
    public CommonResult references(CommonPageParam input) {
        if (!Boolean.TRUE.equals(enabled)) {
            throw CrmPartnerValueSupport.failure("CRM_SCOPE_UNAVAILABLE");
        }
        // 空请求与缺少具名权益候选遵守同一参数合同，不在身份或范围裁决前暴露空指针。
        if (input == null) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        String kind = String.valueOf(input.getParam("capacityKind"));
        if (!Set.of("ISSUE_RETURN", "RECEIPT_REFUND", "RETURN_REFUND").contains(kind)) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        String action = "ISSUE_RETURN".equals(kind) ? "crm.stock.read" : "crm.funds.read";
        access.requireBusinessScope(input.getParam("organizationCandidateId"), action);
        var order =
                orders.lockApprovedForStock(
                        relation(
                                input,
                                "id",
                                CrmPartnerValueSupport.positive(input.getParam("orderId"))),
                        action);
        long source = CrmPartnerValueSupport.positive(input.getParam("sourceOrderLineId"));
        if (((List<Map<String, Object>>) order.get("lines"))
                .stream().noneMatch(row -> ((Number) row.get("id")).longValue() == source)) {
            throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
        }
        var candidates =
                details.findForSource(relation(input, "sourceOrderLineId", source), action);
        var parentIds = new java.util.TreeSet<Long>();
        for (var original : candidates) {
            parentIds.add(((Number) original.get("documentId")).longValue());
        }
        var parents = new java.util.TreeMap<Long, Map<String, Object>>();
        for (long parentId : parentIds) {
            var parent = documents.lockScoped(relation(input, "id", parentId), action);
            if (!order.get("id").equals(parent.get("orderId"))
                    || !order.get("snapshotHash").equals(parent.get("orderSnapshotHash"))) {
                throw CrmPartnerValueSupport.failure("DOCUMENT_LINE_SCOPE_MISMATCH");
            }
            parents.put(parentId, parent);
        }
        var eligible = new ArrayList<Map<String, Object>>();
        for (var original : candidates) {
            var parent = parents.get(((Number) original.get("documentId")).longValue());
            boolean typed =
                    switch (kind) {
                        case "ISSUE_RETURN" ->
                                "STOCK_ISSUE".equals(parent.get("documentKind"))
                                        && "SALE".equals(parent.get("reason"));
                        case "RECEIPT_REFUND" ->
                                "FUNDS_RECEIPT".equals(parent.get("documentKind"))
                                        && "SALE".equals(parent.get("reason"));
                        case "RETURN_REFUND" ->
                                "STOCK_RECEIPT".equals(parent.get("documentKind"))
                                        && "SALES_RETURN".equals(parent.get("reason"));
                        default -> false;
                    };
            if (!typed || !"POSTED".equals(parent.get("documentState"))) {
                continue;
            }
            var history =
                    batches.findForDocument(
                            relation(input, "documentId", original.get("documentId")), action);
            if (history.size() != 1
                    || !"POST".equals(history.get(0).get("action"))
                    || !original.get("batchId").equals(history.get(0).get("id"))) {
                continue;
            }
            var query = relation(input, "originalDetailId", original.get("id"));
            query.putParam("sourceOrderLineId", source);
            query.putParam("capacityKind", kind);
            var capacity = capacities.lockAllocation(query, action);
            var limit =
                    new BigDecimal(
                            capacity.get(
                                            "ISSUE_RETURN".equals(kind)
                                                    ? "capacityQuantity"
                                                    : "capacityMinor")
                                    .toString());
            var used =
                    new BigDecimal(
                            capacity.get("ISSUE_RETURN".equals(kind) ? "usedQuantity" : "usedMinor")
                                    .toString());
            var remaining = limit.subtract(used);
            if (remaining.signum() <= 0) {
                continue;
            }
            var row = new LinkedHashMap<String, Object>();
            row.put("id", original.get("id").toString());
            row.put("documentId", original.get("documentId").toString());
            row.put("sourceOrderLineId", Long.toString(source));
            row.put(
                    "ISSUE_RETURN".equals(kind) ? "remainingQuantity" : "remainingMinor",
                    remaining.toPlainString());
            eligible.add(row);
        }
        int page = input.getPageNo() == null ? 1 : input.getPageNo();
        if (page <= 0 || page > 1000000) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_DOCUMENT_INPUT");
        }
        int offset = Math.min(Math.multiplyExact(page - 1, 20), eligible.size());
        var records = eligible.subList(offset, Math.min(offset + 20, eligible.size()));
        return CrmPartnerValueSupport.result(
                CrmSalesReturnWorkspaceSupport.referencesGrid(
                        records, eligible.size(), page, input.getParam("lang"), kind));
    }
}
