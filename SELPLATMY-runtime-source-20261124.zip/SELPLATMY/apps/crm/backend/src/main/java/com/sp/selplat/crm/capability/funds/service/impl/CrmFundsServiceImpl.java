/**
 * 整批销售收款账本登记实际事务；2026-10-04，Codex；本轮质量治理，生产默认拒绝不变。
 * 修改：2026-10-10，Codex；工作台及批次缺请求走原范围拒绝，超int分页候选返回安全业务错误。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
/* 修改记录：2026-10-28，财务来源条件交给原单据/订单拥有方，按同范围分页返回且不写资金。 */
package com.sp.selplat.crm.capability.funds.service.impl;

import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.funds.service.CrmFundsService;
import com.sp.selplat.crm.common.util.order.CrmOrderValueSupport;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import com.sp.selplat.crm.common.util.stock.CrmStockValueSupport;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * 只调用实际owning服务，原现金批次Order/Line→Document→Progress→Funds在一个CRM事务；课程保护与确认分别持久保存。
 */
@org.springframework.stereotype.Service
public class CrmFundsServiceImpl implements CrmFundsService {

  // 教学真实活动预留只通过Host公开Service接入；CRM不访问教学表，也不回传金额到教学。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmCourseRefundReservationOwner")
  private org.springframework.beans.factory.ObjectProvider<
          java.util.function.BiFunction<Map<String, Object>, CommonParam, Map<String, Object>>>
      courseReservations;

  // 沿现有Host桥接固定课时执行与原现金回执完成，不创建HTTP通信框架。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmCourseRefundExecutionLifecycle")
  private org.springframework.beans.factory.ObjectProvider<
          java.util.function.BiFunction<Map<String, Object>, CommonParam, Map<String, Object>>>
      courseExecution;

  // 身份、候选组织和资金动作消费平台既有准入；不创建本域角色许可。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.capability.access.service.CrmAccessService access;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.document.service.CrmDocumentService // 单据owning服务负责真实头行、独立审核和批准冻结。
      documents;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.order.service.CrmOrderService // 来源owning服务先锁实际已审核订单及完整来源行。
      orders;

  // 只读来源往来方名称，复用原资金读取范围，不取得客户维护权限。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.partner.service.CrmPartnerService partners;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.cashaccount.service
          .CrmCashAccountService // 账户owning服务验证ACTIVE、CASH及固定币种，不调用付款渠道。
      accounts;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.orderlineprogress.service
          .CrmOrderLineProgressService // 来源行进度限定累计收款不能超过冻结应收金额。
      progress;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.fundsbalance.service
          .CrmFundsBalanceService // 余额owning服务按账户币种锁定并CAS，多个明细先聚合再更新一次。
      balances;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.openingbatch.service
          .CrmOpeningBatchService // 期初owning服务确认真实批准期初，不能用历史订单推算现金。
      openings;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.postingbatch.service
          .CrmPostingBatchService // 批次owning服务建立一笔POST批头，不代替逐行真实效果。
      batches;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.postingdetail.service
          .CrmPostingDetailService // 效果owning服务保存每条实际来源/账户/MINOR分摊和复合FK。
      details;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.postingrequest.service
          .CrmPostingRequestService // 请求owning服务保留组织幂等唯一键和首次完整响应，不以actor分账。
      requests;

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.businessaudit.service
          .CrmBusinessAuditService // 实际审计与余额、批次、请求完成在同一CRM业务事务提交。
      audit;

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmTransactionManager")
  private org.springframework.transaction
          .PlatformTransactionManager // 明确使用CRM具名事务；不接管Uniauth池或承诺跨库ACID。
      manager;

  /**
   * 候选组织和服务器关联键。
   *
   * @param input 已规范org901
   * @param key 固定id/orderId等键
   * @param value 实际正数主键
   * @return 新公共参数，无客户端可信身份
   */
  private CommonParam relation(CommonParam input, String key, Object value) {
    var p = new CommonParam();
    p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    p.putParam(key, value);
    return p;
  }

  /**
   * 实际单据及冻结全部行进度和余额聚合，只有明确POST执行。
   *
   * @param input 例如org901/id1000000/expected2/actionPOST/requestKeyp1
   * @return 真实示例：data.state=POSTED/versionNo=3/postingBatchId=1200000/detailIds=[1300000]/synthetic=false；隔离模式仍true。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺许可/冻结错/累计超收/不足/旧版本拒绝
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult execute(CommonParam input) {
    access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmStockValueSupport.post(input);
    if (!coursePosting(p)) {
      return executeOriginal(p, Map.of());
    }
    return executeCourse(p);
  }

  /**
   * 方法作用：独立只读本表实际单据类型后释放锁，再准备跨域课时执行，普通POST不额外要求读权。
   * @param input 原规范org901/id100000/actionPOST/expectedVersion2/UUID
   * @return 真实示例：原COURSE_RETURN返回true；普通原收付款false。
   * 异常或副作用示例：无实际post范围或引用拒绝，不写单据、号段或资金。
   */
  private boolean coursePosting(CommonParam input) {
    var tx = new org.springframework.transaction.support.TransactionTemplate(manager);
    tx.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    tx.setReadOnly(true);
    return Boolean.TRUE.equals(
        tx.execute(
            status -> {
              var head = documents.lockScoped(input, "crm.funds.post");
              status.setRollbackOnly();
              return "COURSE_RETURN".equals(head.get("reason"));
            }));
  }

  /**
   * 方法作用：沿原资金单据固定课时执行，原现金提交成功后才确认消减，未知结果以同UUID恢复。
   * @param input 原规范org901/id100000/expectedVersion2/actionPOST/requestKey原UUID
   * @return 真实示例：原POSTED批次100000及原回执；完成课时确认后返回，不另建现金请求。
   * 异常或副作用示例：金额核对、原身份或确认失败保留执行状态；现金已成功时重试只回原批次并补确认。
   */
  @SuppressWarnings("unchecked")
  private CommonResult executeCourse(CommonParam input) {
    if (!access.formalCapabilityAvailable("courseRefund")
        || courseExecution.getIfAvailable() == null) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_EXECUTION_NOT_CONNECTED");
    }
    var result = documents.getFundsById(relation(input, "id", input.getParam("id")));
    if (!result.isSuccess() || !(result.getData() instanceof Map<?, ?>)) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    var document = (Map<String, Object>) result.getData();
    var rows = (List<Map<String, Object>>) document.get("lines");
    if (rows == null || rows.size() != 1) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_ONE_SOURCE_REQUIRED");
    }
    var line = rows.get(0);
    var identity = access.requireDraftActor();
    var actor =
        Map.<String, Object>of(
            "tenantId", identity.get("tenantId"), "userId", identity.get("ownerUserId"));
    var intent = new LinkedHashMap<String, Object>();
    intent.put("studentId", line.get("courseStudentId"));
    intent.put("curriculumCourseId", line.get("curriculumCourseId"));
    intent.put("reservationId", line.get("courseReservationId"));
    intent.put("executionDocumentId", document.get("id"));
    intent.put("executionDocumentVersion", input.getParam("expectedVersion"));
    intent.put("executionDocumentHash", document.get("approvedSnapshotHash"));
    intent.put("executionRequestKey", input.getParam("requestKey"));
    intent.put("executionPayloadHash", CrmOrderValueSupport.hash(input.getParamMap()));
    Map<Long, Map<String, Object>> quotes = Map.of();
    if (!"POSTED".equals(document.get("documentState"))) {
      var query = new CommonParam();
      query.putParam("studentId", line.get("courseStudentId"));
      query.putParam("curriculumCourseId", line.get("curriculumCourseId"));
      query.putParam("reservationId", line.get("courseReservationId"));
      var quoteResult = courseRefundQuote(query);
      if (!quoteResult.isSuccess() || !(quoteResult.getData() instanceof Map<?, ?>)) {
        throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
      }
      if (!"APPROVED".equals(document.get("documentState"))) {
        throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_STATE_CONFLICT");
      }
      var quote = new LinkedHashMap<String, Object>((Map<String, Object>) quoteResult.getData());
      // 明确低于批准金额的最新上限先拒绝，不把尚未执行的可取消申请推进为执行保护。
      if (com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(line.get("amountMinor"))
              .compareTo(new java.math.BigDecimal(quote.get("maximumRefundMinor").toString()))
          > 0) {
        throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_LIMIT_EXCEEDED");
      }
      // 已审核的金额和旧摘要继续冻结；执行时另外按真实累计上限复核，不能提高原批准金额。
      quote.put("approvalQuoteHash", line.get("courseQuoteHash"));
      quotes = Map.of(CrmPartnerValueSupport.positive(line.get("courseReservationId")), quote);
    }
    intent.put("operation", "BEGIN");
    courseExecution.getObject().apply(actor, CrmStockValueSupport.param(intent));
    // 原现金拥有方只执行一次；失败或未知不释放已经固定的课时执行保护。
    var posted = executeOriginal(input, quotes);
    intent.put("operation", "FINISH");
    courseExecution.getObject().apply(actor, CrmStockValueSupport.param(intent));
    return posted;
  }

  /**
   * 方法作用：原单据／请求／现金流水／余额／审计同一CRM事务提交，课程也沿该原拥有方。
   * @param input 原规范POST，例如org901/id100000/expectedVersion2/原UUID
   * @param courseQuotes 真实课程上限，例如预留100000对应18；普通收付款为空Map
   * @return 真实示例：POSTED/version3/原postingBatchId100000，重放只回首次结果。
   * 异常或副作用示例：旧版本、额度或任何SQL失败使整笔CRM事务回滚，教学保护由外部原状态保存。
   */
  private CommonResult executeOriginal(
      CommonParam input, Map<Long, Map<String, Object>> courseQuotes) {
    access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.post");
    var p = CrmStockValueSupport.post(input);
    var req = relation(p, "documentId", p.getParam("id"));
    req.putParam("requestKey", p.getParam("requestKey"));
    req.putParam("payloadHash", CrmOrderValueSupport.hash(p.getParamMap()));
    var t = new org.springframework.transaction.support.TransactionTemplate(manager);
    t.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    t.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    try {
      // 正式路径由原统一拥有方保护真实CRM提交；隔离模式仍沿原事务，不增加现金拥有方。
      return access.executeTransaction(
          p.getParam("organizationCandidateId"),
          "crm.funds.post",
          t,
          tx -> {
            var scope =
                access.requireFundsScope(p.getParam("organizationCandidateId"), "crm.funds.post");
            documents.requireFundsPostReference(p);
            long requestId = requests.claimOrganizationFunds(req);
            var head =
                courseQuotes.isEmpty()
                    ? documents.prepareFundsPost(p)
                    : documents.prepareCourseFundsPost(p, courseQuotes);
            boolean courseRefund = "COURSE_RETURN".equals(head.get("reason"));
            boolean payment = "FUNDS_PAYMENT".equals(head.get("documentKind"));
            boolean refund = "SALES_RETURN".equals(head.get("reason"));
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> values = (List<Map<String, Object>>) head.get("lines");
            @SuppressWarnings("unchecked")
            Map<String, Object> source = (Map<String, Object>) head.get("source");
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> sources = (List<Map<String, Object>>) source.get("lines");
            Map<Long, Map<String, Object>> sourceById = new TreeMap<>();
            for (var s : sources) {
              sourceById.put(((Number) s.get("id")).longValue(), s);
            }
            Map<Long, java.math.BigDecimal> sourceAmounts = new TreeMap<>(),
                accountAmounts = new TreeMap<>();
            for (var row : values) {
              var amount =
                  com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.minor(
                      row.get("amountMinor"));
              sourceAmounts.merge(
                  ((Number) row.get("sourceOrderLineId")).longValue(),
                  amount,
                  java.math.BigDecimal::add);
              accountAmounts.merge(
                  ((Number) row.get("accountId")).longValue(), amount, java.math.BigDecimal::add);
            }
            Map<Long, Map<String, Object>> progressRows = new TreeMap<>();
            for (var e : sourceAmounts.entrySet()) {
              var actual = progress.lockForLine(p, sourceById.get(e.getKey()), "crm.funds.post");
              var settled = new java.math.BigDecimal(actual.get("cashSettledMinor").toString());
              var due = new java.math.BigDecimal(actual.get("authorizedMinor").toString());
              var available = due.subtract(settled);
              if (courseRefund) {
                var courseAmount =
                    new java.math.BigDecimal(actual.get("courseRefundedMinor").toString());
                if (settled.compareTo(due) != 0
                    || courseAmount.compareTo(
                            new java.math.BigDecimal(
                                courseQuotes
                                    .values()
                                    .iterator()
                                    .next()
                                    .get("alreadyRefundedMinor")
                                    .toString()))
                        != 0
                    || new java.math.BigDecimal(actual.get("cashRefundedMinor").toString()).signum()
                        != 0
                    || ((Number) actual.get("stockReturnedQuantity")).longValue() != 0) {
                  throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_CHANGED");
                }
                available =
                    new java.math.BigDecimal(
                        courseQuotes
                            .values()
                            .iterator()
                            .next()
                            .get("maximumRefundMinor")
                            .toString());
              }
              if (refund) {
                var refunded = new java.math.BigDecimal(actual.get("cashRefundedMinor").toString());
                var entitlement =
                    com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnValueSupport
                        .entitlement(
                            actual, ((Number) actual.get("stockReturnedQuantity")).longValue());
                available = settled.min(entitlement).subtract(refunded);
              }
              if (e.getValue().compareTo(available) > 0) {
                throw CrmPartnerValueSupport.failure("POSTING_CAPACITY_EXCEEDED");
              }
              progressRows.put(e.getKey(), actual);
            }
            Map<Long, CommonParam> capacityClaims = new TreeMap<>();
            if (refund) {
              // 每条退款同时占真实原收款与实际退货的冻结额度；多行先聚合，防重复分摊。
              for (var row : values) {
                for (String kind : List.of("RECEIPT_REFUND", "RETURN_REFUND")) {
                  long originalId =
                      ((Number)
                              row.get(
                                  "RECEIPT_REFUND".equals(kind)
                                      ? "baseReceiptDetailId"
                                      : "baseReturnDetailId"))
                          .longValue();
                  var claim = capacityClaims.get(originalId);
                  if (claim == null) {
                    claim = relation(p, "originalDetailId", originalId);
                    claim.putParam("sourceOrderLineId", row.get("sourceOrderLineId"));
                    claim.putParam("capacityKind", kind);
                    claim.putParam("amountMinor", java.math.BigDecimal.ZERO);
                    capacityClaims.put(originalId, claim);
                  }
                  claim.putParam(
                      "amountMinor",
                      ((java.math.BigDecimal) claim.getParam("amountMinor"))
                          .add(new java.math.BigDecimal(row.get("amountMinor").toString())));
                }
              }
              for (var claim : capacityClaims.values()) {
                var actual = capacities.lockAllocation(claim, "crm.funds.post");
                claim.putParam("id", actual.get("id"));
                claim.putParam("versionNo", actual.get("versionNo"));
              }
              for (var claim : capacityClaims.values()) {
                capacities.consume(claim, "crm.funds.post");
              }
            }
            Map<Long, Map<String, Object>> cashRows = new TreeMap<>();
            for (var e : accountAmounts.entrySet()) {
              var search = relation(p, "accountId", e.getKey());
              search.putParam("currency", head.get("currency"));
              var actual = balances.lockOrganization(search);
              var total =
                  new java.math.BigDecimal(actual.get("amountMinor").toString())
                      .add(payment ? e.getValue().negate() : e.getValue());
              if (total.signum() < 0) {
                throw CrmPartnerValueSupport.failure("FUNDS_INSUFFICIENT");
              }
              if (total.precision() > 38) {
                throw CrmPartnerValueSupport.failure("FUNDS_AMOUNT_OVERFLOW");
              }
              openings.requireApprovedForFundsPost(relation(p, "id", actual.get("openingBatchId")));
              cashRows.put(e.getKey(), actual);
            }
            var batch = relation(p, "documentId", head.get("id"));
            batch.putParam("action", "POST");
            batch.putParam("headerVersion", head.get("versionNo"));
            batch.putParam("approvedSnapshotHash", head.get("approvedSnapshotHash"));
            batch.putParam("detailCount", values.size());
            long batchId =
                courseRefund
                    ? batches.appendCourseFunds(batch, courseQuotes)
                    : batches.appendFunds(batch);
            List<String> ids = new ArrayList<>();
            // Every actual allocation yields exactly one cash detail; each account
            // receives a single aggregate CAS.
            for (var row : values) {
              long account = ((Number) row.get("accountId")).longValue();
              var effect = relation(p, "batchId", batchId);
              effect.putParam("documentId", head.get("id"));
              effect.putParam("documentLineId", row.get("id"));
              for (String f : List.of("sourceOrderLineId", "lineNo", "accountId", "currency")) {
                effect.putParam(f, row.get(f));
              }
              effect.putParam("effectKind", "CASH");
              effect.putParam("action", "POST");
              effect.putParam("fundsBalanceId", cashRows.get(account).get("id"));
              var amount = new java.math.BigDecimal(row.get("amountMinor").toString());
              effect.putParam("amountDeltaMinor", payment ? amount.negate() : amount);
              long detailId = details.append(effect, "crm.funds.post");
              ids.add(Long.toString(detailId));
              if (refund) {
                for (String kind : List.of("REFUND_FOR_RECEIPT", "REFUND_FOR_RETURN")) {
                  var edge = relation(p, "childDetailId", detailId);
                  edge.putParam(
                      "parentDetailId",
                      row.get(
                          "REFUND_FOR_RECEIPT".equals(kind)
                              ? "baseReceiptDetailId"
                              : "baseReturnDetailId"));
                  edge.putParam("dependencyKind", kind);
                  dependencies.appendAllocation(edge, "crm.funds.post");
                }
              }
            }
            for (var e : accountAmounts.entrySet()) {
              var actual = cashRows.get(e.getKey());
              var update = relation(p, "id", actual.get("id"));
              update.putParam("versionNo", actual.get("versionNo"));
              update.putParam("amountMinor", e.getValue());
              if (payment) {
                balances.payOrganization(update);
              } else {
                balances.receiveOrganization(update);
              }
            }
            for (var e : sourceAmounts.entrySet()) {
              var actual = progressRows.get(e.getKey());
              var update = relation(p, "id", actual.get("id"));
              update.putParam("versionNo", actual.get("versionNo"));
              update.putParam("amountMinor", e.getValue());
              if (courseRefund) {
                update.putParam(
                    "maximumCumulativeMinor",
                    courseQuotes.values().iterator().next().get("maximumCumulativeRefundMinor"));
                progress.applyCourseRefund(update);
              } else if (refund) {
                progress.applyRefund(update);
              } else {
                progress.applyReceipt(update);
              }
            }
            var posted = documents.markFundsPosted(p);
            if (Boolean.TRUE.equals(returnsEnabled) && !payment) {
              for (int i = 0; i < values.size(); i++) {
                var original = relation(p, "originalDetailId", Long.valueOf(ids.get(i)));
                original.putParam("sourceOrderLineId", values.get(i).get("sourceOrderLineId"));
                original.putParam("capacityKind", "RECEIPT_REFUND");
                capacities.registerOriginal(original, "crm.funds.post");
              }
            }
            access.requireFundsScope(p.getParam("organizationCandidateId"), "crm.funds.post");
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("documentId", head.get("id").toString());
            data.put("state", "POSTED");
            data.put("version", posted.get("versionNo").toString());
            data.put("versionNo", posted.get("versionNo").toString());
            data.put("postingBatchId", Long.toString(batchId));
            data.put("detailIds", ids);
            data.put("replay", false);
            data.put("synthetic", scope.get("synthetic"));
            var complete = CrmStockValueSupport.param(req.getParamMap());
            complete.putParam("id", requestId);
            complete.putParam("resultBatchId", batchId);
            complete.putParam("resultVersionNo", posted.get("versionNo"));
            complete.putParam("responseSnapshot", JsonUtils.toJsonIgnoreNull(data));
            requests.completeOrganizationFunds(complete);
            var event = relation(p, "postingRequestId", requestId);
            event.putParam("batchId", batchId);
            event.putParam("action", "FUNDS_POST");
            event.putParam("resourceId", head.get("id"));
            event.putParam("previousVersion", head.get("versionNo"));
            event.putParam("newVersion", posted.get("versionNo"));
            audit.append(event);
            return CrmPartnerValueSupport.result(data);
          });
    } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
      if (!"CRM_COMMAND_EXISTS".equals(failure.getErrorCode())) {
        throw failure;
      }
      var stored = requests.committedOrganizationFunds(req);
      if (stored == null || !req.getParam("payloadHash").equals(stored.get("payloadHash"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_CONFLICT");
      }
      if (!"COMPLETED".equals(stored.get("requestState"))) {
        throw CrmPartnerValueSupport.failure("CRM_COMMAND_IN_PROGRESS");
      }
      @SuppressWarnings("unchecked")
      Map<String, Object> data =
          JsonUtils.fromJson(
              (String) CrmStockValueSupport.browser(stored).get("responseSnapshot"), Map.class);
      data.put("replay", true);
      return CrmPartnerValueSupport.result(data);
    }
  }

  /**
   * 一次真实本组织POST批次/全部明细查询，FK保证同document/line/source/余额维度。
   *
   * @param input 例如org901/id1200000
   * @return 精确文本批次及全部detail，越组织统一拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     null请求先核真实身份：匿名UNIAUTH_IDENTITY_REQUIRED；已登录缺组织候选INVALID_CRM_ID，不写业务数据
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult batch(CommonParam input) {
    // 缺请求仍先核验真实身份与原组织候选，不让空指针先于原安全准入。
    access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    var head = batches.lockScoped(input, "crm.funds.read");
    var all = details.readAll(relation(input, "batchId", head.get("id")), "crm.funds.read");
    if (all.stream().anyMatch(r -> !"CASH".equals(r.get("effectKind")))) {
      throw CrmPartnerValueSupport.failure("CRM_RECORD_NOT_FOUND");
    }
    if (all.size() != ((Number) head.get("detailCount")).intValue()) {
      throw CrmPartnerValueSupport.failure("CRM_BATCH_DETAIL_MISMATCH");
    }
    var data = CrmStockValueSupport.browser(head);
    data.put("details", all.stream().map(CrmStockValueSupport::browser).toList());
    return CrmPartnerValueSupport.result(data);
  }

  /**
   * 聚合后台真实业务和公共配置；各列表独立页码，共用请求页长，默认20且最多100行。
   *
   * @param input 例如org901/page1/langzh-CN
   * @return 实际单据/来源/账户/余额/流水及SELUI定义；生产默认拒绝
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守身份与组织准入；匿名UNIAUTH_IDENTITY_REQUIRED，实际登录无组织候选INVALID_CRM_ID，无业务写入
   */
  @Override
  @OperationLog
  public CommonResult workspace(CommonPageParam input) {
    // 缺请求仍沿原准入核验真实身份和组织，不推定默认候选。
    var currentScope =
        access.requireFundsScope(
            input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    // 来源只是候选主键；先核原资金准入，再规范编号，返回实际应用条件供页面核对。
    Long sourceOrderId = input.getParam("sourceOrderId") == null
        ? null : CrmPartnerValueSupport.positive(input.getParam("sourceOrderId"));
    var documentPage = documents.fundsStore(input);
    // 列表金额由原单据拥有方的真实全部行合计，不把订单总价或已审核误当已收款。
    documentTotals(documentPage, input);
    String reason =
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageReason(
            input.getParam("documentKind"),
            input.getParam("reason"),
            Boolean.TRUE.equals(returnsEnabled));
    boolean refund = "SALES_RETURN".equals(reason);
    boolean courseRefund = "COURSE_RETURN".equals(reason);
    boolean payment =
        "FUNDS_PAYMENT"
            .equals(
                com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageKind(
                    input.getParam("documentKind")));
    var orderPage =
        payment && !refund && !courseRefund
            ? orders.approvedPurchaseForFunds(page(input, "orderPageNo"))
            : orders.approvedSalesForFunds(page(input, "orderPageNo"));
    var accountPage = accounts.getStore(page(input, "accountPageNo"));
    var balancePage = balances.organizationStore(page(input, "balancePageNo"));
    var detailPage = details.fundsStore(page(input, "detailPageNo"));
    Map<String, Boolean> permits = new LinkedHashMap<>();
    var actions =
        new ArrayList<>(
            List.of("crm.funds.write", "crm.funds.submit", "crm.funds.approve", "crm.funds.post"));
    if ((!payment || refund) && Boolean.TRUE.equals(reversalEnabled)) {
      actions.add("crm.funds.reverse");
    }
    for (String action : actions) {
      try {
        access.requireFundsScope(input.getParam("organizationCandidateId"), action);
        permits.put(action, true);
      } catch (com.sp.selplat.common.exception.CommonBusinessException failure) {
        if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
          throw failure;
        }
        permits.put(action, false);
      }
    }
    var workspace =
        com.sp.selplat.crm.common.util.funds.CrmFundsWorkspaceSupport.build(
            documentPage,
            orderPage,
            accountPage,
            balancePage,
            detailPage,
            permits,
            input.getParam("lang"),
            payment,
            Boolean.TRUE.equals(currentScope.get("synthetic")));
    var result =
        com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnWorkspaceSupport.decorate(
            workspace, input.getParam("lang"), refund, true, Boolean.TRUE.equals(returnsEnabled));
    if (courseRefund) {
      // 课程退款沿原销售来源，不能在工作区中误标采购付款原因。
      @SuppressWarnings("unchecked")
      var data = new LinkedHashMap<String, Object>((Map<String, Object>) result.getData());
      String lang = String.valueOf(input.getParam("lang"));
      data.put("reason", "COURSE_RETURN");
      data.put(
          "title",
          "en-US".equals(lang) ? "Course refunds" : "ja-JP".equals(lang) ? "コース返金" : "课程退款");
      result.setData(data);
    }
    @SuppressWarnings("unchecked")
    var filtered = new LinkedHashMap<String, Object>((Map<String, Object>) result.getData());
    filtered.put("sourceOrderId", sourceOrderId == null ? "" : sourceOrderId.toString());
    String appliedState = com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageState(input.getParam("documentState"));
    filtered.put("documentState", appliedState == null ? "" : appliedState);
    if (input.getParam("openingPageNo") != null) {
      // 仅明确期初页面请求读取原拥有方真实分页；不把账户记录或客户端缓存当作期初事实。
      var openingPage = openings.fundsStore(page(input, "openingPageNo"));
      filtered.put("openings", Map.of(
          "data", Map.of("items", openingPage.getRecords()),
          "pagination", Map.of("currentPage", openingPage.getPageNo(),
              "pageSize", openingPage.getPageSize(), "totalCount", openingPage.getTotalCount())));
    }

    result.setData(filtered);
    return result;
  }

  /**
   * 方法作用：真实资金单页补齐原全部分摊行合计，草稿金额与已登记状态分别展示。
   * @param page 原已核机构的当前页，例如org901/page1含单100000
   * @param input 实际查询，例如organizationCandidateId901，不接受客户端金额
   * 异常或副作用示例：头行版本变化或币种无效拒绝，原账本、单据和分页不写入；20行仍为原20行。
   */
  @SuppressWarnings("unchecked")
  private void documentTotals(com.sp.selplat.common.util.CommonPageResult page, CommonParam input) {
    var records = new ArrayList<Map<String, Object>>();
    for (var header : page.getRecords()) {
      var query = new CommonParam();
      query.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
      query.putParam("id", header.get("id"));
      var response = documents.getFundsById(query);
      if (!response.isSuccess()
          || !(response.getData() instanceof Map<?, ?> current)
          || !header.get("versionNo").toString().equals(current.get("versionNo").toString())) {
        throw CrmPartnerValueSupport.failure("CRM_DOCUMENT_VERSION_CONFLICT");
      }
      var sum = java.math.BigInteger.ZERO;
      for (var line : (List<Map<String, Object>>) current.get("lines")) {
        sum =
            sum.add(
                new java.math.BigDecimal(line.get("amountMinor").toString()).toBigIntegerExact());
      }
      int scale =
          switch (String.valueOf(header.get("currency"))) {
            case "JPY" -> 0;
            case "CNY", "USD" -> 2;
            default -> throw CrmPartnerValueSupport.failure("INVALID_CRM_CURRENCY");
          };
      var row = new LinkedHashMap<String, Object>(header);
      row.put("totalMinor", sum.toString());
      row.put(
          "totalDisplay",
          new java.math.BigDecimal(sum, scale).toPlainString() + " " + header.get("currency"));
      records.add(row);
    }
    page.setRecords(records);
  }

  /**
   * 每个右侧列表独立分页，候选组织不变。
   *
   * @param input 实际org901与分页候选
   * @param field 固定orderPageNo等服务器分页键
   * @return 公共page1/1至100（默认20），按原公共分页范围规范，不含客户端SQL或默认组织
   * @throws com.sp.selplat.common.exception.CommonBusinessException 页码2147483648拒绝INVALID_CRM_ID，无写入
   */
  private CommonPageParam page(CommonPageParam input, String field) {
    var p = new CommonPageParam();
    p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
    // 外部long分页候选先核公共int范围，避免算术异常泄漏；不截断原请求。
    long pageNo =
        input.getParam(field) == null ? 1 : CrmPartnerValueSupport.positive(input.getParam(field));
    if (pageNo > Integer.MAX_VALUE) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_ID");
    }
    // 只向订单拥有方传来源候选，不把订单筛选混入账户、余额或流水条件。
    if ("orderPageNo".equals(field) && input.getParam("sourceOrderId") != null) {
      p.putParam("sourceOrderId", CrmPartnerValueSupport.positive(input.getParam("sourceOrderId")));
    }
    p.setPageNo((int) pageNo);
    p.setPageSize(input.getPageSize() == null ? 20 : Math.max(1, Math.min(100, input.getPageSize())));
    return p;
  }

  /**
   * 方法作用及真实业务示例：读取实际冻结销售来源及已收未收；org901/orderId600000；返回应收135、已收68、未收67等真实派生值；不新增进度行或更改订单状态。 Read
   * frozen source and actual settled counters under the same order-first transaction.
   *
   * @param input org901/orderId600000
   * @return exact authorized/settled/unsettled MINOR at line and order levels; no cash effect
   * @throws com.sp.selplat.common.exception.CommonBusinessException
   *     缺请求先遵守身份与组织准入；匿名UNIAUTH_IDENTITY_REQUIRED，实际登录无组织候选INVALID_CRM_ID，无业务写入
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.REQUIRES_NEW,
      readOnly = true)
  public CommonResult source(CommonParam input) {
    // 缺请求仍沿原准入核验真实身份和组织，不推定默认候选。
    access.requireFundsScope(
        input == null ? null : input.getParam("organizationCandidateId"), "crm.funds.read");
    String reason =
        com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageReason(
            input.getParam("documentKind"),
            input.getParam("reason"),
            Boolean.TRUE.equals(returnsEnabled));
    boolean refund = "SALES_RETURN".equals(reason);
    boolean courseRefund = "COURSE_RETURN".equals(reason);
    boolean payment =
        "FUNDS_PAYMENT"
            .equals(
                com.sp.selplat.crm.common.util.funds.CrmFundsValueSupport.pageKind(
                    input.getParam("documentKind")));
    var sourceInput = relation(input, "id", input.getParam("orderId"));
    var actual =
        payment && !refund && !courseRefund
            ? orders.lockApprovedPurchaseForFunds(sourceInput, "crm.funds.read")
            : orders.lockApprovedForStock(sourceInput, "crm.funds.read");
    @SuppressWarnings("unchecked")
    List<Map<String, Object>> sources = (List<Map<String, Object>>) actual.get("lines");
    var out = CrmStockValueSupport.browser(actual);
    var counterparty = partners.fundsListNames(input.getParam("organizationCandidateId"),
        List.of(CrmPartnerValueSupport.positive(actual.get("partnerId"))));
    if (counterparty.size() != 1) {
      throw CrmPartnerValueSupport.failure("CRM_REFERENCE_UNAVAILABLE");
    }
    out.put("counterpartyName", CrmPartnerValueSupport.text(counterparty.get(0).get("partnerName"), 200, true));
    out.remove("lines");
    List<Map<String, Object>> rows = new ArrayList<>();
    java.math.BigDecimal settledTotal = java.math.BigDecimal.ZERO,
        dueTotal = java.math.BigDecimal.ZERO;
    for (var row : sources) {
      var progressRow =
          progress.readFundsForLine(relation(input, "sourceOrderLineId", row.get("id")));
      var due = new java.math.BigDecimal(row.get("approvedDueMinor").toString());
      var settled =
          progressRow == null
              ? java.math.BigDecimal.ZERO
              : new java.math.BigDecimal(progressRow.get("cashSettledMinor").toString());
      var view = CrmStockValueSupport.browser(row);
      view.put("cashSettledMinor", settled.toPlainString());
      view.put("unsettledMinor", due.subtract(settled).toPlainString());
      view.put("currency", actual.get("currency"));
      // 履约消费者也必须看见真实已退金额和退货数量，不能把曾经收齐误作当前无退款来源。
      var goodsRefunded =
          progressRow == null
              ? java.math.BigDecimal.ZERO
              : new java.math.BigDecimal(progressRow.get("cashRefundedMinor").toString());
      var courseRefunded =
          progressRow == null || progressRow.get("courseRefundedMinor") == null
              ? java.math.BigDecimal.ZERO
              : new java.math.BigDecimal(progressRow.get("courseRefundedMinor").toString());
      // 外部履约不能把已经发生的课程退款忽略；原商品与课程计数仍分别可核对。
      view.put("cashRefundedMinor", goodsRefunded.add(courseRefunded).toPlainString());
      view.put("goodsRefundedMinor", goodsRefunded.toPlainString());
      view.put("courseRefundedMinor", courseRefunded.toPlainString());
      view.put(
          "stockReturnedQuantity",
          progressRow == null ? "0" : progressRow.get("stockReturnedQuantity").toString());
      if (refund) {
        long returned =
            progressRow == null
                ? 0L
                : ((Number) progressRow.get("stockReturnedQuantity")).longValue();
        var refunded =
            progressRow == null
                ? java.math.BigDecimal.ZERO
                : new java.math.BigDecimal(progressRow.get("cashRefundedMinor").toString());
        var entitlement =
            progressRow == null
                    || ((Number) progressRow.get("authorizedQuantity")).longValue() == 0L
                ? java.math.BigDecimal.ZERO
                : com.sp.selplat.crm.common.util.salesreturn.CrmSalesReturnValueSupport.entitlement(
                    progressRow, returned);
        view.put("stockReturnedQuantity", Long.toString(returned));
        view.put("goodsEntitlementMinor", entitlement.toPlainString());
        view.put("cashRefundedMinor", refunded.add(courseRefunded).toPlainString());
        view.put(
            "refundableRemainingMinor",
            settled
                .subtract(courseRefunded)
                .min(entitlement)
                .subtract(refunded)
                .max(java.math.BigDecimal.ZERO)
                .toPlainString());
      }
      if (payment && !refund && !courseRefund) {
        view.put("approvedPayableMinor", due.toPlainString());
        view.put("cashPaidMinor", settled.toPlainString());
        view.put("unpaidMinor", due.subtract(settled).toPlainString());
      }
      rows.add(view);
      settledTotal = settledTotal.add(settled);
      dueTotal = dueTotal.add(due);
    }
    if (dueTotal.compareTo(new java.math.BigDecimal(actual.get("totalMinor").toString())) != 0) {
      throw CrmPartnerValueSupport.failure("CRM_PROGRESS_SOURCE_MISMATCH");
    }
    out.put("lines", rows);
    out.put("cashSettledMinor", settledTotal.toPlainString());
    out.put("unsettledMinor", dueTotal.subtract(settledTotal).toPlainString());
    if (payment && !refund && !courseRefund) {
      out.put("approvedPayableMinor", dueTotal.toPlainString());
      out.put("cashPaidMinor", settledTotal.toPlainString());
      out.put("unpaidMinor", dueTotal.subtract(settledTotal).toPlainString());
    }
    return CrmPartnerValueSupport.result(out);
  }

  /**
   * 方法作用：在独立CRM只读回滚事务内读取原资金完整冻结来源，防止同类调用跳过原事务边界。
   * @param organization 原预留拥有方给出的组织，例如901
   * @param order 原开通固定订单，例如600000
   * @return 真实示例：原APPROVED SALES订单及完整已收最小单位行。
   * 异常或副作用示例：原来源不完整或准入不足拒绝，不分配序列或写现金。
   */
  @SuppressWarnings("unchecked")
  private Map<String, Object> courseRefundSource(long organization, long order) {
    var p = new CommonParam();
    p.putParam("organizationCandidateId", organization);
    p.putParam("orderId", order);
    var tx = new org.springframework.transaction.support.TransactionTemplate(manager);
    tx.setPropagationBehavior(
        org.springframework.transaction.TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    tx.setIsolationLevel(
        org.springframework.transaction.TransactionDefinition.ISOLATION_READ_COMMITTED);
    tx.setReadOnly(true);
    return tx.execute(
        status -> {
          var result = source(p);
          if (!result.isSuccess() || !(result.getData() instanceof Map<?, ?>)) {
            throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
          }
          status.setRollbackOnly();
          return (Map<String, Object>) result.getData();
        });
  }

  /**
   * 方法作用：在原资金拥有方组合实际预留和原冻结净额，只出退款上限，不能将其当成已审核或已过账。
   * @param input studentId50/curriculumCourseId400/reservationId100000
   * @return 真实示例：maximumRefundMinor18/currencyCNY/reservedUnits4/grantedUnits20/quoteStateREVIEW_ONLY及实际摘要。
   * 异常或副作用示例：客户端金额或机构覆盖、取消、来源或当前主体变化拒绝，无现金与课时写入。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "crmTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  @SuppressWarnings("unchecked")
  public CommonResult courseRefundQuote(CommonParam input) {
    if (input == null
        || !java.util.Set.of("studentId", "curriculumCourseId", "reservationId")
            .equals(input.getParamMap().keySet())) {
      throw CrmPartnerValueSupport.failure("INVALID_CRM_COURSE_REFUND_INPUT");
    }
    var identity = access.requireDraftActor();
    var actor =
        Map.<String, Object>of(
            "tenantId", identity.get("tenantId"), "userId", identity.get("ownerUserId"));
    var owner = courseReservations.getIfAvailable();
    if (owner == null) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_UNAVAILABLE");
    }
    var proof = owner.apply(actor, input);
    long organization = CrmPartnerValueSupport.positive(proof.get("organizationId"));
    var scope = access.requireFundsScope(organization, "crm.funds.read");
    if (!Boolean.FALSE.equals(scope.get("synthetic"))
        || !actor.get("tenantId").toString().equals(scope.get("tenantId").toString())
        || !actor.get("userId").toString().equals(scope.get("actorUserId").toString())) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    long order = CrmPartnerValueSupport.positive(proof.get("crmOrderId")),
        line = CrmPartnerValueSupport.positive(proof.get("crmOrderLineId"));
    var source = courseRefundSource(organization, order);
    if (!"APPROVED".equals(source.get("orderState"))
        || !"SALES".equals(source.get("orderKind"))
        || CrmPartnerValueSupport.positive(source.get("id")) != order) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    Map<String, Object> selected = null;
    for (var row : (List<Map<String, Object>>) source.get("lines")) {
      if (CrmPartnerValueSupport.positive(row.get("id")) == line) {
        if (selected != null) {
          throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
        }
        selected = row;
      }
    }
    if (selected == null
        || !selected.get("productId").toString().equals(proof.get("crmProductId").toString())
        || !"0".equals(selected.get("stockReturnedQuantity").toString())) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_INVALID");
    }
    String maximum =
        com.sp.selplat.crm.common.util.funds.CrmCourseRefundValueSupport.maximum(
            selected,
            proof.get("grantedUnits"),
            proof.get("reservedUnits"),
            proof.getOrDefault("completedRefundedUnits", "0"));
    if (!proof.equals(owner.apply(actor, input))
        || !source.equals(courseRefundSource(organization, order))
        || !identity.equals(access.requireDraftActor())) {
      throw CrmPartnerValueSupport.failure("CRM_COURSE_REFUND_SOURCE_CHANGED");
    }
    access.requireFundsScope(organization, "crm.funds.read");
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    var out = new LinkedHashMap<String, Object>();
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    for (String field :
        List.of(
            "studentId",
            "curriculumCourseId",
            "reservationId",
            "reservationVersion",
            "entitlementId",
            "crmOrderId",
            "crmOrderLineId",
            "crmProductId",
            "crmCustomerId",
            "grantedUnits",
            "reservedUnits")) {
      out.put(field, proof.get(field));
    }
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("currency", source.get("currency"));
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("originalRefundPolicyVersion", selected.get("refundPolicyVersion"));
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("courseRefundPolicyVersion", "COURSE_UNUSED_NET_V1");
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("maximumRefundMinor", maximum);
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("alreadyRefundedMinor", selected.getOrDefault("courseRefundedMinor", "0"));
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("completedRefundedUnits", proof.getOrDefault("completedRefundedUnits", "0"));
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put(
        "maximumCumulativeRefundMinor",
        new java.math.BigInteger(maximum)
            .add(
                new java.math.BigInteger(
                    selected.getOrDefault("courseRefundedMinor", "0").toString()))
            .toString());
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("refundableFeeMinor", "0");
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put("quoteState", "REVIEW_ONLY");
    // 沿原资金浏览器合同输出精确编号文本；核价摘要仍使用原始拥有方事实计算，不被展示转换重算。
    out.put(
        "quoteHash",
        CrmOrderValueSupport.hash(
            Map.of(
                "reservation",
                new TreeMap<>(proof),
                "source",
                source,
                "maximumRefundMinor",
                maximum,
                "courseRefundPolicyVersion",
                "COURSE_UNUSED_NET_V1")));
    var view = CrmOrderValueSupport.browser(out);
    view.put("reservationVersion", String.valueOf(out.get("reservationVersion")));
    return CrmPartnerValueSupport.result(view);
  }

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmFundsReversalIsolatedEnabled")
  private Boolean reversalEnabled;

  // 商品退款仅内部记账，显式本域门禁不会连接退款渠道或扩权。
  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("crmSalesReturnIsolatedEnabled")
  private Boolean returnsEnabled;

  // 原收款与原退货两种额度由容量owning服务分别CAS。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.postingcapacity.service.CrmPostingCapacityService capacities;

  // 双真实父边与现金流水、进度、余额、请求和审计同CRM事务提交。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.crm.postingdependency.service.CrmPostingDependencyService dependencies;
}
