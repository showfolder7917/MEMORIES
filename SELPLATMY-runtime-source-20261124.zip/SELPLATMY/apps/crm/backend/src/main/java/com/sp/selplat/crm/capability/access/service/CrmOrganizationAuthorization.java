/* 文件：CrmOrganizationAuthorization.java；职责：CRM消费现有统一身份和组织关系；2026-10-14。 */
/* 2026-10-27：接入真实租户管理员、本租户组织来源及提交前原角色复核，不创建权限记录。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
/* 2026-10-28：审计目录仅复用既有crm.audit.read，不授予新动作。 */
package com.sp.selplat.crm.capability.access.service;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.authorization.CrmOrganizationActionPolicy;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.identity.LocalIdentityLockAccess;
import com.sp.selplat.common.service.authorization.ExactGrantCoordinates;
import com.sp.selplat.common.service.authorization.CrmOrganizationQualificationAccess;
import com.sp.selplat.common.service.authorization.LocalCrmQualificationTransactionAccess;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * 只调用认证owner公开服务与公共资格策略，不复制授权表、不直接访问认证DAO或授予权限。
 */
@Service
public class CrmOrganizationAuthorization {

  // 当前Session的身份和互斥锁由认证owner维护，CRM不另建登录协议。
  private final CurrentSessionAccess identities;

  // 原同进程身份互斥单独装配，不能通过HTTP携带Java回调。
  private final LocalIdentityLockAccess identityLocks;

  // 原资格事实由权限拥有方组合，CRM不复制管理员或精确许可规则。
  private final CrmOrganizationQualificationAccess qualificationFacts;

  // 原认证事务与真实请求保护由Host本地合同持有，不向CRM暴露权限库管理器。
  private final LocalCrmQualificationTransactionAccess qualificationTransactions;

  // 仅本次正式提交记录所有额外读取许可，锁及有效期复核覆盖引用链，结束后清理。
  private final ThreadLocal<Map<Map<String, Object>, Map<String, Object>>> lockedReads =
      new ThreadLocal<>();

  /**
   * 方法作用：装配现有统一身份和三关系owner，不查询或初始化授权。
   * @param identities Host具名公共身份读取，例如user9211/tenant92
   * @param identityLocks Host具名原本地互斥，仅同进程，不是HTTP合同
   * @param qualificationFacts Host具名原资格拥有方，例如组织901与原许可903
   * @param qualificationTransactions Host本地资格事务及请求保护，例如原认证只回滚释放锁
   * 异常或副作用示例：只创建读已提交模板，不创建账号、关系或数据库。
   */
  public CrmOrganizationAuthorization(
      @Qualifier("crmCurrentSessionAccess") CurrentSessionAccess identities,
      @Qualifier("crmLocalIdentityLockAccess") LocalIdentityLockAccess identityLocks,
      @Qualifier("crmOrganizationQualificationAccess")
          CrmOrganizationQualificationAccess qualificationFacts,
      @Qualifier("crmLocalQualificationTransactionAccess")
          LocalCrmQualificationTransactionAccess qualificationTransactions) {
    this.identities = identities;
    this.identityLocks = identityLocks;
    this.qualificationFacts = qualificationFacts;
    this.qualificationTransactions = qualificationTransactions;
  }

  /**
   * 方法作用：复用统一组织目录，再逐项按实际CRM读取许可过滤，不泄露未授权组织名称。
   * @param query 字面名称，例如青禾；目录owner处理100项窗口和非法输入
   * @return 真实返回示例：[{id:"901",displayName:"青禾",readActions:["crm.partner.read"]}]。
   * @throws CommonBusinessException 身份变化、目录失败或非许可拒绝类错误传播，不授予权限
   */
  public java.util.List<Map<String, Object>> organizationChoices(String query) {
    return directory(
        query,
        java.util.List.of(
            "crm.product.read", "crm.partner.read", "crm.order.read", "crm.stock.read", "crm.audit.read"));
  }

  /**
   * 方法作用：独立财务只按原资金读取动作筛选真实机构，不要求客户或库存许可。
   * @param query 字面名称，例如新思度；沿原目录100项显式上限，超限要求缩小查询
   * @return 真实示例：[{id:"901",displayName:新思度,readActions:[crm.funds.read]}]。
   * 异常或副作用示例：未授予资金读取返回空，故障传播；不创建成员或授权。
   */
  public java.util.List<Map<String, Object>> fundsOrganizationChoices(String query) {
    return directory(query, java.util.List.of("crm.funds.read"));
  }

  /**
   * 方法作用：原统一机构拥有方筛选固定服务端只读动作，前后复核实际会话。
   * @param query 原字面查询，例如新思度
   * @param actions 拥有方固定动作，例如仅crm.funds.read，不能由HTTP覆盖
   * @return 真实示例：原组织901及已核readActions，不伪造未授权组织。
   * 异常或副作用示例：资格或身份变化拒绝，无业务或权限写入。
   */
  private java.util.List<Map<String, Object>> directory(
      String query, java.util.List<String> actions) {
    var identity = identities.current();
    if (!identity.isSuccess() || !(identity.getData() instanceof Map<?, ?> profile)) {
      throw denied();
    }
    var actor =
        Map.<String, Object>of(
            "tenantId", profile.get("tenantId"), "userId", profile.get("userId"));
    var selected = new java.util.ArrayList<Map<String, Object>>();
    for (var organization : qualificationFacts.selectionSources(actor, query)) {
      var permitted = new java.util.ArrayList<String>();
      for (String action : actions) {
        var input = new CommonParam();
        input.putParam("actor", actor);
        input.putParam("scope", Map.of("operatingOrganizationId", organization.get("id")));
        input.putParam(
            "resource",
            Map.of("application", "crm", "type", "CRM_ORGANIZATION", "id", organization.get("id")));
        input.putParam("action", action);
        try {
          evidence(input);
          permitted.add(action);
        } catch (CommonBusinessException failure) {
          // 独立动作未授予只过滤该动作；SQL、身份或目录故障不能被当作空目录。
          if (!"CRM_ACTION_FORBIDDEN".equals(failure.getErrorCode())) {
            throw failure;
          }
        }
      }
      if (!permitted.isEmpty()) {
        selected.add(
            Map.of(
                "id",
                organization.get("id").toString(),
                "displayName",
                organization.get("displayName"),
                "readActions",
                java.util.List.copyOf(permitted)));
      }
    }
    var current = identities.current();
    if (!(current.getData() instanceof Map<?, ?> latest)
        || !ExactGrantCoordinates.sameId(actor.get("tenantId"), latest.get("tenantId"))
        || !ExactGrantCoordinates.sameId(actor.get("userId"), latest.get("userId"))) {
      throw denied();
    }
    return java.util.List.copyOf(selected);
  }

  /**
   * 方法作用：依据当前账户和固定CRM组织资源返回只读资格证据。
   * @param input 服务端要求，例如actor9211/org901/crm.order.read/CRM_ORGANIZATION901
   * @return 真实返回示例：allow=true、scopeId=901、decisionId=903:0:2:0；不是提交令牌。
   * 异常或副作用示例：缺资格、旧修订或读取期间变化返回CRM_ACTION_FORBIDDEN。
   */
  public CommonResult evidence(CommonParam input) {
    var expected = requirement(input);
    var before = fact(expected, lockedReads.get() != null);
    if (!before.equals(fact(expected, false))) {
      throw denied();
    }
    if (lockedReads.get() != null) {
      lockedReads.get().put(expected, before);
    }
    // 审计明确区分真实管理员任命与原个人动作许可，不伪造grantId/memberRevision。
    String decisionId;
    if ("TENANT_ADMIN".equals(before.get("authorizationKind"))) {
      var role = (Map<?, ?>) before.get("role");
      var organization = (Map<?, ?>) before.get("organization");
      decisionId =
          "tenant-admin:"
              + role.get("roleAssignmentId")
              + ":"
              + role.get("roleRevision")
              + ":"
              + organization.get("sourceVersion");
    } else {
      decisionId =
          before.get("grantId")
              + ":"
              + before.get("organizationRevision")
              + ":"
              + before.get("memberRevision")
              + ":"
              + before.get("grantRevision");
    }
    var result = new CommonResult();
    result.setSuccess(true);
    result.setData(
        Map.of(
            "allow",
            true,
            "tenantId",
            expected.get("tenantId"),
            "actorUserId",
            expected.get("userId"),
            "scopeId",
            expected.get("organizationId"),
            "decisionId",
            decisionId));
    return result;
  }

  /**
   * 方法作用：身份→资格锁→CRM事务固定顺序，保护完整实际提交和末尾有效期复核。
   * @param input 服务端要求，例如crm.order.write/组织901
   * @param business CRM既有模板，例如crmTransactionManager/READ_COMMITTED/REQUIRES_NEW
   * @param mutation 完整业务回调，例如两行订单、请求回执和审计一起落库
   * @return 真实返回示例：提交成功data.id=600000；身份或资格失效则整笔回滚。
   * @throws CommonBusinessException 同一DataSource、外层事务、缺容器保护或失败结果拒绝；认证库仅持锁无写入。
   */
  public CommonResult execute(
      CommonParam input, TransactionTemplate business, TransactionCallback<CommonResult> mutation) {
    qualificationTransactions.requireIndependentBusinessTransaction(business, mutation);
    requireLifecycle();
    var expected = requirement(input);
    return identityLocks.executeWithCurrentIdentityLock(
        () ->
            qualificationTransactions.executeQualification(
                () -> {
                  identityLocks.lockCurrentForAuthorization();
                  var locked = fact(expected, true);
                  lockedReads.set(new java.util.LinkedHashMap<>());
                  try {
                    return business.execute(
                        status -> {
                          var result = mutation.doInTransaction(status);
                          if (result == null || !result.isSuccess()) {
                            throw new CommonBusinessException(
                                "CRM_AUTHORIZATION_RESULT_INVALID", "CRM事务未返回明确成功结果。");
                          }
                          // 所有业务beforeCommit之后再核实际身份及到期，不将预检允许缓存成许可证。
                          TransactionSynchronizationManager.registerSynchronization(
                              new TransactionSynchronization() {

                                /**
                                 * 方法作用：在真实SQL提交前复核身份、资格和期限。
                                 * @param readOnly 当前模板标志，例如false
                                 * 异常或副作用示例：撤权或到期抛CRM_ACTION_FORBIDDEN，CRM及回执整体回滚。
                                 */
                                @Override
                                public void beforeCommit(boolean readOnly) {
                                  requireLifecycle();
                                  if (!expected.equals(requirement(input))
                                      || !locked.equals(fact(expected, false))) {
                                    throw denied();
                                  }
                                  // 各owning服务引用时要求的独立读取许可也重验，不只保护最终写动作。
                                  for (var entry : lockedReads.get().entrySet()) {
                                    if (!entry.getValue().equals(fact(entry.getKey(), false))) {
                                      throw denied();
                                    }
                                  }
                                }
                              });
                          return result;
                        });
                  } finally {
                    lockedReads.remove();
                  }
                }));
  }

  /**
   * 方法作用：归一化完整服务器要求并核当前身份，不接受伪造tenant或actor。
   * @param input 服务端范围，例如CRM_ORGANIZATION901/actioncrm.partner.read
   * @return 真实返回示例：tenant92/user9211/org901及固定动作、crm应用、组织资源七坐标。
   * 异常或副作用示例：缺字段、跨组织资源或资金动作拒绝，不读业务库。
   */
  private Map<String, Object> requirement(CommonParam input) {
    var result = identities.current();
    if (!result.isSuccess()
        || !(result.getData() instanceof Map<?, ?> actor)
        || input == null
        || !(input.getParam("actor") instanceof Map<?, ?> claimed)
        || !(input.getParam("scope") instanceof Map<?, ?> scope)
        || !(input.getParam("resource") instanceof Map<?, ?> resource)
        || !ExactGrantCoordinates.sameId(actor.get("userId"), claimed.get("userId"))
        || !ExactGrantCoordinates.sameId(actor.get("tenantId"), claimed.get("tenantId"))
        || !ExactGrantCoordinates.positive(scope.get("operatingOrganizationId"))
        || !ExactGrantCoordinates.positive(resource.get("id"))
        || !(input.getParam("action") instanceof String action)
        || !(resource.get("application") instanceof String application)
        || !(resource.get("type") instanceof String type)) {
      throw denied();
    }
    var expected =
        Map.<String, Object>of(
            "tenantId",
            actor.get("tenantId"),
            "userId",
            actor.get("userId"),
            "organizationId",
            scope.get("operatingOrganizationId"),
            "action",
            action,
            "application",
            application,
            "resourceType",
            type,
            "resourceId",
            resource.get("id"));
    if (!CrmOrganizationActionPolicy.supports(expected)) {
      throw denied();
    }
    return expected;
  }

  /**
   * 方法作用：复用统一owner公开读取/锁和同一完整资格策略，缺关系不补造。
   * @param expected 完整七坐标，例如tenant92/user9211/org901
   * @param locking 是否持有认证读已提交事务，例如写入前true
   * @return 真实返回示例：许可903的组织/成员/许可修订证据。
   * 异常或副作用示例：不唯一、未激活、期限或关系不符拒绝；SQL失败传播。
   */
  private Map<String, Object> fact(Map<String, Object> expected, boolean locking) {
    var fact = qualificationFacts.qualifiedFact(expected, locking);
    if (fact == null) {
      throw denied();
    }
    return fact;
  }

  /**
   * 方法作用：缺当前真实Host活动请求保护时拒绝正式事务。
   * @throws CommonBusinessException 未装配或异步请求返回CRM_AUTHORIZATION_LIFECYCLE_UNAVAILABLE。
   */
  private void requireLifecycle() {
    qualificationTransactions.requireRequestLifecycle();
  }

  /**
   * 方法作用：生成范围安全的统一CRM拒绝，不泄露关系原始字段。
   * @return 真实返回示例：CRM_ACTION_FORBIDDEN及当前许可不足说明。
   * 异常或副作用示例：仅构造异常，没有任何数据库写入。
   */
  private CommonBusinessException denied() {
    return new CommonBusinessException("CRM_ACTION_FORBIDDEN", "当前账号未获该经营组织动作许可或许可已失效。");
  }
}
