/** 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.orderlineprogress.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmOrderLineProgressDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 来源行累计锁。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    Map<String, Object> lockForLine(CommonParam input);

    /**
     * 仅定位实际来源末退货明细，供Document组锁前使用。
     *
     * @param input tenant92/org901/orderLineId600001，调用者已持有原销售订单锁
     * @return 原实际行或null，例如lastReturnDetailId1300002；副作用示例：不加Progress锁、不创建记录。
     */
    Map<String, Object> peekForLine(CommonParam input);

    /**
     * 来源累计数量CAS。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    int applyIssue(CommonParam input);

    /**
     * Exact source settlement CAS.
     *
     * @param input real scoped id/version0/amountMinor68
     * @return 1 or 0; zero causes outer transaction rollback
     */
    int applyReceipt(CommonParam input);

    /**
     * 方法作用：减除原收款已收R并保留F≤R约束。
     *
     * @param input org901/progress1400000/version1/amount68
     * @return 影响1或0；不能使未冲退款大于剩余已收 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    int reverseReceipt(CommonParam input);

    /**
     * 对完整退货批次累计T并记本批末退货节点，不修改原履约I。
     *
     * @param input tenant92/org901/id1400000/version1/quantity1/lastReturnDetailId1300002/actor9211
     * @return 影响1或0；T不能超过I，旧版本或Q0拒绝
     */
    int applyReturn(CommonParam input);

    /**
     * 累计现金商品退款F，不减少原已收R或重开收款额度。
     *
     * @param input tenant92/org901/id1400000/version2/amountMinor1/actor9211
     * @return 影响1或0；F不能超过R或真实累计商品权益
     */
    int applyRefund(CommonParam input);

    /**
     * 方法作用：原进度按当前版本增加课程退款累计，保留商品退款和库存计数。
     * @param input 真实范围tenant9/org901/id100000/version1/amountMinor18/maximumCumulativeMinor18
     * @return 真实示例：成功1；旧版本、超净额、超实收或混入退货返回0。
     * 异常或副作用示例：SQL失败由原CRM事务回滚，不创建现金流水或伪造库存退货。
     */
    int applyCourseRefund(CommonParam input);


    /**
     * 减除实际完整退款F；例如F2→0、R5不变，旧版本影响0行。
     *
     * @param input tenant92/org901/id1400000/version3/amountMinor2/actor9211
     * @return 实际影响1或0行；非负边界与版本保护，无部分写入
     */
    int reverseRefund(CommonParam input);

    /**
     * I完整逆转，例如I3/T0→I0，原订单不改，旧版本0行。
     *
     * @param input tenant92/org901/id1400000/version3/quantity3/actor9211
     * @return 实际影响1或0行
     */
    int reverseIssue(CommonParam input);

    /**
     * 最新退货整批逆转，例如T3→2/末节点回前批1300001，F守恒，旧版本0行。
     *
     * @param input
     *     tenant92/org901/id1400000/version3/quantity1/previousReturnDetailId1300001/actor9211
     * @return 实际影响1或0行，DB CHECK仍保护F≤E(T)
     */
    int reverseReturn(CommonParam input);
}
