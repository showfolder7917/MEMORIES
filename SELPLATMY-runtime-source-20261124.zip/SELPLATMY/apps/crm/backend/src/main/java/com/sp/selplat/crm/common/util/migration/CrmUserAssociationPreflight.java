/** 2026-10-06：旧用户显式关联及客户转交词法报告，不读取账号或写入身份事实。 */
package com.sp.selplat.crm.common.util.migration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 仅校验调用方的旧新关联声明，声明不是权威映射；不按pin、手机号或同ID推导身份。 */
public final class CrmUserAssociationPreflight {
    // 新目标各自拥有生命周期，旧身份表不会变成CRM账户表。
    private static final Map<String, String> SOURCES = Map.of(
            "UNIAUTH_ACCOUNT", "authority_user", "ATTENDANCE_EMPLOYEE", "authority_user",
            "CRM_CONTACT", "crm_user_info", "CRM_PARTNER", "ymx_sys_org",
            "UNIAUTH_ORGANIZATION", "authority_organize", "UNIAUTH_ROLE", "authority_role");
    // 从清洁DDL及转交Service证实的完整旧字段；NULL不能用缺字段替代。
    private static final List<String> TRANSFER_FIELDS = List.of("id", "crm_user_info_id", "authority_user_id",
            "start_time", "end_time", "opt_pin", "sortnum", "status", "created", "modified", "machine_code");

    /** 无状态工具不实例化；不创建账号、许可或迁移台账。 */
    private CrmUserAssociationPreflight() {
    }

    /**
     * 核显式来源键、分型、目标和完整转交字段；任何歧义整批停止，报告仍不授予迁入许可。
     * @param input 公共声明，例如mode=DRY_RUN/sourceSystem=ERP/mappings=[]/transfers=[]
     * @param tenantId 准入服务真实租户，例如92，不接受客户端覆盖
     * @param businessOrgId 原准入核验经营组织，例如901，不授予新范围
     * @return 例如{declarationValid:true,targetFactsVerified:false,writeEnabled:false,pendingTransfers:[]}
     *     副作用示例：同ID不会自动匹配，密码/手机号等额外字段拒绝且不回显。
     */
    public static Map<String, Object> inspect(Map<String, Object> input, long tenantId, long businessOrgId) {
        var issues = new ArrayList<Map<String, Object>>();
        var pending = new ArrayList<Map<String, Object>>();
        var candidates = new ArrayList<Map<String, Object>>();
        var relations = new ArrayList<Map<String, Object>>();
        var report = new LinkedHashMap<String, Object>();
        report.put("writeEnabled", false);
        report.put("targetFactsVerified", false);
        report.put("typedImportBlocked", true);
        report.put("mappingPersistence", "NOT_IMPLEMENTED");
        report.put("pendingMappings", List.of());
        report.put("pendingTransfers", List.of());
        report.put("pendingRelationships", List.of());
        report.put("permissionsCreated", false);
        report.put("issues", issues);
        report.put("blockingContracts", List.of("AUTHORITATIVE_SOURCE_TARGET_LEDGER_REQUIRED",
                "CRM_OWNER_DIRECTORY_PURPOSE_NOT_AUTHORIZED", "ORGANIZATION_ROLE_MAPPING_REQUIRED",
                "TRANSFER_OPT_PIN_IDENTITY_AND_TIMEZONE_UNPROVED", "SHOWFOLDER_ACCOUNT_SCOPE_NOT_VERIFIED"));
        // 输入仅声明只读清单，禁止把状态、凭据或scope放在额外参数中。
        if (input == null || !Set.of("mode", "sourceSystem", "organizationCandidateId", "mappings", "transfers",
                "historicalOwnerCandidates", "relationships")
                .containsAll(input.keySet()) || !"DRY_RUN".equals(input.get("mode"))
                || !token(input.get("sourceSystem")) || !(input.get("mappings") instanceof List<?> mappings)
                || !(input.get("transfers") instanceof List<?> transfers)
                || !(input.get("relationships") instanceof List<?> relationships)
                || mappings.size() > 1000 || transfers.size() > 1000 || relationships.size() > 1000) {
            issue(issues, 0, "READ_ONLY_INPUT_INVALID");
            report.put("declarationValid", false);
            return report;
        }
        report.put("sourceSystem", input.get("sourceSystem"));
        // 用户已指定业务负责人showfolder；候选仅声明，不通过员工目录用途扩张CRM账号查询。
        Map<String, Object> historicalOwner = Map.of();
        if (!(input.get("historicalOwnerCandidates") instanceof List<?> owners) || owners.size() != 1
                || !(owners.getFirst() instanceof Map<?, ?> owner) || owner.size() != 4
                || !owner.keySet().containsAll(Set.of("loginName", "userId", "tenantId", "businessOrgId"))
                || !"showfolder".equals(owner.get("loginName")) || !positive(owner.get("userId"))
                || !Long.toString(tenantId).equals(owner.get("tenantId"))
                || !Long.toString(businessOrgId).equals(owner.get("businessOrgId"))) {
            issue(issues, 0, "HISTORICAL_OWNER_UNIQUE_SCOPED_CANDIDATE_REQUIRED");
        } else {
            historicalOwner = Map.of("loginName", "showfolder", "userId", owner.get("userId"),
                    "tenantId", owner.get("tenantId"), "businessOrgId", owner.get("businessOrgId"),
                    "verificationStatus", "UNVERIFIED_DECLARATION", "purpose", "HISTORICAL_BUSINESS_OWNER_ONLY");
        }
        var origin = new HashMap<String, String>();
        var targets = new HashSet<String>();
        for (int i = 0; i < mappings.size(); i++) {
            if (!(mappings.get(i) instanceof Map<?, ?> row) || row.size() != 6
                    || !row.keySet().containsAll(Set.of("sourceTable", "sourceId", "sourceType",
                            "targetKind", "targetId", "evidenceRef"))
                    || !token(row.get("sourceId")) || !token(row.get("evidenceRef"))
                    || !positive(row.get("targetId")) || !(row.get("targetKind") instanceof String kind)
                    || !SOURCES.containsKey(kind) || !SOURCES.get(kind).equals(row.get("sourceTable"))) {
                issue(issues, i + 1, "EXPLICIT_MAPPING_REQUIRED");
                continue;
            }
            // 旧type仅来自已读注释合同；声明分型不证明实际旧账号的类型或有效性。
            boolean account = "authority_user".equals(row.get("sourceTable"));
            if ((account && !(row.get("sourceType") instanceof String type && Set.of("0", "1", "2", "3").contains(type)))
                    || (!account && row.get("sourceType") != null)
                    || ("ATTENDANCE_EMPLOYEE".equals(kind) && !"1".equals(row.get("sourceType")))) {
                issue(issues, i + 1, "SOURCE_TYPE_UNPROVED");
                continue;
            }
            String key = kind + ":" + row.get("sourceId");
            if (origin.putIfAbsent(key, (String) row.get("targetId")) != null
                    || !targets.add(kind + ":" + row.get("targetId"))) {
                issue(issues, i + 1, "AMBIGUOUS_MAPPING");
            }
            candidates.add(Map.of("sourceTable", row.get("sourceTable"), "sourceId", row.get("sourceId"),
                    "targetKind", kind, "targetId", row.get("targetId"), "evidenceStatus", "UNVERIFIED_DECLARATION",
                    "declaredSourceType", row.get("sourceType") == null ? Map.of("kind", "NULL")
                            : Map.of("kind", "LEXICAL", "value", row.get("sourceType"))));
        }
        var transferIds = new HashSet<String>();
        for (int i = 0; i < transfers.size(); i++) {
            if (!(transfers.get(i) instanceof Map<?, ?> row) || row.size() != TRANSFER_FIELDS.size()
                    || !row.keySet().containsAll(TRANSFER_FIELDS) || !token(row.get("id"))) {
                issue(issues, i + 1, "TRANSFER_FIELDS_REQUIRED");
                continue;
            }
            if (!transferIds.add((String) row.get("id"))) {
                issue(issues, i + 1, "DUPLICATE_TRANSFER_ORIGIN");
            }
            var preserved = new LinkedHashMap<String, Object>();
            for (String field : TRANSFER_FIELDS) {
                Object value = row.get(field);
                if (value == null) {
                    preserved.put(field, Map.of("kind", "NULL"));
                } else if (value instanceof String text && text.length() <= 500
                        && text.codePoints().noneMatch(Character::isISOControl)) {
                    // 旧经手时间/状态保留词法；不转换时区、不制造新转交动作，自由标识展示遮蔽。
                    preserved.put(field, Set.of("opt_pin", "machine_code").contains(field)
                            ? Map.of("kind", "REDACTED") : Map.of("kind", "LEXICAL", "value", value));
                } else {
                    issue(issues, i + 1, "TRANSFER_LEXICAL_REQUIRED");
                }
            }
            String contact = token(row.get("crm_user_info_id"))
                    ? origin.get("CRM_CONTACT:" + row.get("crm_user_info_id")) : null;
            String actor = token(row.get("authority_user_id"))
                    ? origin.get("UNIAUTH_ACCOUNT:" + row.get("authority_user_id")) : null;
            if (contact == null || actor == null) {
                issue(issues, i + 1, "TRANSFER_REFERENCE_MAPPING_REQUIRED");
            } else {
                pending.add(Map.of("sourceTable", "crm_user_info_zhuanjiao_record", "sourceId", row.get("id"),
                        "declaredContactId", contact, "declaredPreviousHandlerUserId", actor,
                        "sourcePayload", preserved, "candidateKind", "HISTORICAL_TRANSFER_PREVIEW"));
            }
        }
        var relationIds = new HashSet<String>();
        for (int i = 0; i < relationships.size(); i++) {
            if (!(relationships.get(i) instanceof Map<?, ?> declaration) || declaration.size() != 2
                    || !declaration.keySet().containsAll(Set.of("sourceTable", "sourcePayload"))
                    || !(declaration.get("sourceTable") instanceof String table)
                    || !Set.of("authority_user_rose_middle", "authority_organize_user").contains(table)
                    || !(declaration.get("sourcePayload") instanceof Map<?, ?> row)) {
                issue(issues, i + 1, "RELATION_FIELDS_REQUIRED");
                continue;
            }
            boolean role = "authority_user_rose_middle".equals(table);
            String reference = role ? "role_id" : "organize_id";
            var fields = List.of("id", "user_id", reference, "sortnum", "created", "modified", "machine_code");
            if (row.size() != fields.size() || !row.keySet().containsAll(fields) || !token(row.get("id"))) {
                issue(issues, i + 1, "RELATION_FIELDS_REQUIRED");
                continue;
            }
            if (!relationIds.add(table + ":" + row.get("id"))) {
                issue(issues, i + 1, "DUPLICATE_RELATION_ORIGIN");
            }
            var payload = new LinkedHashMap<String, Object>();
            for (String field : fields) {
                Object value = row.get(field);
                if (value == null) {
                    payload.put(field, Map.of("kind", "NULL"));
                } else if (value instanceof String text && text.length() <= 500
                        && text.codePoints().noneMatch(Character::isISOControl)) {
                    payload.put(field, "machine_code".equals(field) ? Map.of("kind", "REDACTED")
                            : Map.of("kind", "LEXICAL", "value", value));
                } else {
                    issue(issues, i + 1, "RELATION_LEXICAL_REQUIRED");
                }
            }
            String accountId = token(row.get("user_id")) ? origin.get("UNIAUTH_ACCOUNT:" + row.get("user_id")) : null;
            String target = token(row.get(reference))
                    ? origin.get((role ? "UNIAUTH_ROLE:" : "UNIAUTH_ORGANIZATION:") + row.get(reference)) : null;
            if (accountId == null || target == null) {
                issue(issues, i + 1, "RELATION_REFERENCE_MAPPING_REQUIRED");
            } else {
                // 保存来源边的声明，不把旧角色/组织成员等价为新许可事实或showfolder角色。
                relations.add(Map.of("sourceTable", table, "sourceId", row.get("id"), "sourcePayload", payload,
                        "declaredAccountId", accountId, "declaredRelationTargetId", target,
                        "candidateKind", "LEGACY_RELATION_PREVIEW", "authorizationEffective", false));
            }
        }
        // 全清单原子阻断，不能输出部分成功而丢掉孤儿引用或多对一声明。
        report.put("declarationValid", issues.isEmpty());
        if (issues.isEmpty()) {
            report.put("historicalBusinessOwner", historicalOwner);
            report.put("originalActorsPreserved", true);
            report.put("pendingMappings", candidates);
            report.put("pendingTransfers", pending);
            report.put("pendingRelationships", relations);
        }
        return report;
    }

    /**
     * 核有界词法，不接纳控制字符或JSON数值导致的精度丢失。
     * @param value 调用方字段，例如000123或2020-01-01 09:00:00
     * @return 合法true；例如超500字符false，不写数据
     */
    private static boolean token(Object value) {
        return value instanceof String text && !text.isBlank() && text.length() <= 500
                && text.codePoints().noneMatch(Character::isISOControl);
    }

    /**
     * 核新目标规范正整数，防止01与1成为同一目标的不同声明。
     * @param value 明确目标主键，例如9211
     * @return 合法true；例如01、浮点或溢出false，不按旧ID推导
     */
    private static boolean positive(Object value) {
        try {
            return value instanceof String text && text.matches("[1-9][0-9]{0,18}") && Long.parseLong(text) > 0;
        } catch (NumberFormatException overflow) {
            return false;
        }
    }

    /**
     * 只记录位置和安全码，未知字段值/凭据不进入报告。
     * @param issues 当前报告列表，例如空列表
     * @param row 声明位置，例如1
     * @param code 安全问题码，例如AMBIGUOUS_MAPPING
     *     副作用示例：追加{row:1,code:AMBIGUOUS_MAPPING}，不记录原输入秘密
     */
    private static void issue(List<Map<String, Object>> issues, int row, String code) {
        issues.add(Map.of("row", row, "code", code));
    }
}
