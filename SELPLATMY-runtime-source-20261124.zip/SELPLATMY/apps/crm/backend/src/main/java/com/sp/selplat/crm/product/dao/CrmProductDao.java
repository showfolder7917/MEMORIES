/** CrmProduct：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.product.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，只固定参数化本表SQL。 */
public interface CrmProductDao extends BaseDao {
    /**
     * 锁本组织实际行；scope92/901/id600000；返回行或null，要求CRM事务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：锁本组织实际行；scope92/901/id600000；返回行或null，要求CRM事务。
     * @return 行或null，要求CRM事务
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * 商品本表版本更新，不写库存或订单快照。
     * @param input 范围tenant92/org901/id700000/version0和规范字段
     * @return 实际影响行数，例如1；0为未覆盖任何版本
     */
    int updateVersion(CommonParam input);
}
