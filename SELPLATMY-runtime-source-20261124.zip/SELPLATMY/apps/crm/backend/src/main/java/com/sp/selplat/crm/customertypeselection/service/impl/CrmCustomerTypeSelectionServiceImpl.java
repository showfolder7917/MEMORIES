/* 客户自定义多类型选择；2026-10-26，保留原客户资料及分类历史。 */
/* 修改记录：2026-10-27，首次客户分类与原客户创建同事务提交；教学按稳定分类编号调用，已有分类独立维护。 */
package com.sp.selplat.crm.customertypeselection.service.impl;

import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.text;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.version;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.customertype.service.CrmCustomerTypeService;
import com.sp.selplat.crm.customertypeselection.dao.CrmCustomerTypeSelectionDao;
import com.sp.selplat.crm.customertypeselection.service.CrmCustomerTypeSelectionService;
import com.sp.selplat.crm.partner.service.CrmPartnerService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

/** 一个客户对应一个版本化集合；持有原客户锁串行化，停用类型仍保留原引用。 */
@Service
public class CrmCustomerTypeSelectionServiceImpl extends BaseServiceImpl<CrmCustomerTypeSelectionDao>
        implements CrmCustomerTypeSelectionService {
    // 当前身份和组织范围复用原CRM服务，不接受客户端tenantId。
    private final CrmAccessService access;
    // 原客户主档案及锁只由客户拥有方提供。
    private final CrmPartnerService partners;
    // 类型读取和锁只由类型拥有方提供。
    private final CrmCustomerTypeService types;
    // 本表变更及历史在同一CRM事务提交。
    private final TransactionTemplate transaction;

    /**
     * 方法作用：读取原对象分类变更历史，沿原客户读取范围。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId100000
     * @return 真实返回示例：data={resourceId:"100000",readOnly:true,entries:[{versionNo:"1",actorUserId:"9211"}]}。
     * 异常或副作用示例：跨组织拒绝，不返回请求键或摘要，不修改历史。
     */
    @Override
    @OperationLog
    public CommonResult history(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "partnerId"));
        partners.getById(reference(input));
        var row = find(scope, positive(input.getParam("partnerId")));
        var entries = com.sp.selplat.crm.common.util.customer.CrmCustomerHistorySupport.project(
                row == null ? null : row.get("changeHistoryJson"));
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(Map.of("resourceId", input.getParam("partnerId").toString(),
                "readOnly", true, "entries", entries), "分类历史读取完成。");
    }

    /**
     * 方法作用：装配实际拥有方及具名事务，DAO由BaseService绑定。
     * @param access 原CRM准入，例如组织901/操作人9211
     * @param partners 实际客户Service，例如CrmPartnerServiceImpl
     * @param types 实际类型Service，例如CrmCustomerTypeServiceImpl
     * @param manager 原crmTransactionManager
     * 异常或副作用示例：仅绑定依赖，不创建默认分类或客户。
     */
    public CrmCustomerTypeSelectionServiceImpl(CrmAccessService access, CrmPartnerService partners,
            CrmCustomerTypeService types, @Qualifier("crmTransactionManager") PlatformTransactionManager manager) {
        this.access = access;
        this.partners = partners;
        this.types = types;
        transaction = new TransactionTemplate(manager);
        transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 方法作用：读取客户已选集合及原组织完整有界类型目录。
     * @param input HTTP候选，例如organizationCandidateId901/partnerId200000
     * @return 真实返回示例：data={partnerId:"200000",partnerVersion:"0",versionNo:"0",typeIds:[],types:[]}。
     * 异常或副作用示例：越组织或失效客户拒绝，不回填原客户分类。
     */
    @Override
    @OperationLog
    public CommonResult read(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "partnerId"));
        var reference = reference(input);
        var partner = (Map<?, ?>) partners.getById(reference).getData();
        var directory = new CommonParam();
        directory.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        directory.putParam("includeDisabled", true);
        var all = (Map<?, ?>) types.directory(directory).getData();
        var row = find(scope, positive(input.getParam("partnerId")));
        var result = new LinkedHashMap<String, Object>();
        result.put("partnerId", input.getParam("partnerId").toString());
        result.put("partnerVersion", partner.get("versionNo").toString());
        result.put("versionNo", row == null ? "0" : row.get("versionNo").toString());
        result.put("typeIds", row == null ? List.of() : ids(row.get("typeIdsJson")).stream().map(Object::toString).toList());
        result.put("types", all.get("types"));
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(result, "客户分类读取完成。");
    }

    /**
     * 方法作用：沿原客户写许可替换类型集合并追加本表审计，旧请求返回原结果。
     * @param input HTTP候选，例如org901/partnerId200000/typeIdsJson[100000]/expectedVersion0/expectedPartnerVersion0
     * @return 真实返回示例：data={partnerId:"200000",versionNo:"1",replay:false}。
     * 异常或副作用示例：类型已停用、客户变化或许可撤回时整体回滚。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.NOT_SUPPORTED)
    public CommonResult save(CommonParam input) {
        access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.write");
        keys(input, Set.of("organizationCandidateId", "partnerId", "expectedVersion", "expectedPartnerVersion",
                "requestKey", "typeIdsJson"));
        var normalized = new CommonParam();
        normalized.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
        normalized.putParam("partnerId", positive(input.getParam("partnerId")));
        normalized.putParam("expectedVersion", version(input.getParam("expectedVersion")));
        normalized.putParam("expectedPartnerVersion", version(input.getParam("expectedPartnerVersion")));
        String key = text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) { throw failure("INVALID_CRM_INPUT"); }
        normalized.putParam("requestKey", key);
        normalized.putParam("typeIdsJson", JsonUtils.toJsonIgnoreNull(ids(input.getParam("typeIdsJson"))));
        String hash = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
        return access.executeTransaction(normalized.getParam("organizationCandidateId"), "crm.partner.write",
                transaction, state -> store(normalized, hash));
    }

    /**
     * 方法作用：沿调用方CRM创建事务初始化首次分类，客户及集合不形成部分提交。
     * @param input 服务间候选，例如org901/partnerId200001/typeIdsJson[100000]/requestKeycreate-1
     * @return 真实返回示例：success=true/data.versionNo="1"/data.partnerId="200001"。
     * 异常或副作用示例：无CRM事务、客户非首次版本、旧分类已存在或类型失效整体回滚。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.MANDATORY)
    public CommonResult initializeForPartner(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.write");
        keys(input, Set.of("organizationCandidateId", "partnerId", "requestKey", "typeIdsJson"));
        var normalized = new CommonParam();
        normalized.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
        normalized.putParam("partnerId", positive(input.getParam("partnerId")));
        normalized.putParam("expectedVersion", 0L);
        normalized.putParam("expectedPartnerVersion", 0L);
        String key = text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) { throw failure("INVALID_CRM_INPUT"); }
        normalized.putParam("requestKey", key);
        normalized.putParam("typeIdsJson", JsonUtils.toJsonIgnoreNull(ids(input.getParam("typeIdsJson"))));
        // 只为原客户创建事务使用；已有集合必须走带所见版本的独立保存。
        var partner = partners.lockForMaintenance(reference(normalized));
        if (version(partner.get("versionNo")) != 0 || find(scope, positive(input.getParam("partnerId"))) != null) {
            throw failure("STALE_CRM_VERSION");
        }
        return store(normalized, com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized));
    }

    /**
     * 方法作用：在真实客户锁下保存一个集合；原客户资料与版本保持不变。
     * @param input 规范保存候选，例如partnerId200000/expectedVersion0/typeIdsJson[100000]
     * @param hash 规范正文SHA256，例如64位文本
     * @return 真实返回示例：data.versionNo="1"/replay=false。
     * 异常或副作用示例：同键异内容、旧版或失效类型不产生部分历史。
     */
    private CommonResult store(CommonParam input, String hash) {
        var partner = partners.lockForMaintenance(reference(input));
        var scope = access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        long partnerId = positive(input.getParam("partnerId"));
        var existing = find(scope, partnerId);
        List<Map<String, Object>> history = existing == null ? new ArrayList<>() : history(existing.get("changeHistoryJson"));
        // 必须在客户锁及当前资格核验后重放，避免失权账号读取原回执。
        for (var event : history) {
            if (input.getParam("requestKey").equals(event.get("requestKey"))) {
                if (!hash.equals(event.get("payloadHash"))) { throw failure("CRM_COMMAND_CONFLICT"); }
                return receipt(partnerId, version(event.get("versionNo")), true);
            }
        }
        long prior = existing == null ? 0 : version(existing.get("versionNo"));
        if (prior != version(input.getParam("expectedVersion")) || prior == Long.MAX_VALUE
                || version(partner.get("versionNo")) != version(input.getParam("expectedPartnerVersion"))) {
            throw failure("STALE_CRM_VERSION");
        }
        if (history.size() >= 2000) { throw failure("CRM_TYPE_HISTORY_LIMIT"); }
        var selected = ids(input.getParam("typeIdsJson"));
        var previous = existing == null ? List.<Long>of() : ids(existing.get("typeIdsJson"));
        // 主键升序锁定类型，防止两个客户反序选择时死锁；已停用类型只能保留原引用。
        for (long typeId : selected) {
            var candidate = new CommonParam();
            candidate.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
            candidate.putParam("id", typeId);
            var type = types.lockForSelection(candidate);
            if (!Boolean.TRUE.equals(type.get("enabledFlag")) && !previous.contains(typeId)) {
                throw failure("CRM_TYPE_DISABLED");
            }
        }
        long next = prior + 1;
        var event = new LinkedHashMap<String, Object>();
        event.put("requestKey", input.getParam("requestKey"));
        event.put("payloadHash", hash);
        event.put("versionNo", next);
        event.put("actorUserId", scope.get("actorUserId").toString());
        event.put("recordedAt", Instant.now().toString());
        event.put("before", previous);
        event.put("after", selected);
        history.add(event);
        var row = new CommonParam();
        row.putParam("tenantId", scope.get("tenantId"));
        row.putParam("businessOrgId", scope.get("businessOrgId"));
        row.putParam("partnerId", partnerId);
        row.putParam("lastOperateUserId", scope.get("actorUserId"));
        row.putParam("typeIdsJson", input.getParam("typeIdsJson"));
        row.putParam("changeHistoryJson", JsonUtils.toJsonIgnoreNull(history));
        row.putParam("versionNo", next);
        int changed;
        if (existing == null) {
            long id = getSequence().get("id");
            row.putParam("id", id);
            row.putParam("code", "CrmCustomerTypeSelection_" + id);
            row.putParam("status", 1);
            row.putParam("sortnum", 0);
            changed = getDao().insert(row);
        } else {
            row.putParam("id", existing.get("id"));
            row.putParam("expectedVersion", prior);
            changed = getDao().updateVersion(row);
        }
        if (changed != 1) { throw failure("STALE_CRM_VERSION"); }
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        return receipt(partnerId, next, false);
    }

    /**
     * 方法作用：按可信范围及客户稳定主键读取本集合。
     * @param scope 原CRM范围，例如tenantId92/businessOrgId901
     * @param partnerId 实际客户主键，例如200000
     * @return 真实返回示例：typeIdsJson="[100000]"/versionNo1；未选择为null。
     * 异常或副作用示例：只读本表，不按客户姓名合并。
     */
    private Map<String, Object> find(Map<String, Object> scope, long partnerId) {
        var p = new CommonParam();
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        p.putParam("partnerId", partnerId);
        p.putParam("status", 1);
        var row = getDao().getByQuery(p);
        return row == null || row.isEmpty() ? null : row;
    }

    /**
     * 方法作用：构造原客户拥有方的候选，不透传其他HTTP字段。
     * @param input 规范输入，例如organizationCandidateId901/partnerId200000
     * @return 真实返回示例：CommonParam{organizationCandidateId:901,id:200000}。
     * 异常或副作用示例：非法或缺主键拒绝，不回退查询全库。
     */
    private static CommonParam reference(CommonParam input) {
        var p = new CommonParam();
        p.putParam("organizationCandidateId", positive(input.getParam("organizationCandidateId")));
        p.putParam("id", positive(input.getParam("partnerId")));
        return p;
    }

    /**
     * 方法作用：严格解析有界多选数组，排序后形成稳定请求摘要。
     * @param value 前端JSON文本，例如[100001,"100000"]
     * @return 真实返回示例：[100000,100001]。
     * 异常或副作用示例：缺数组、重复主键、非法主键或超过50项拒绝。
     */
    private static List<Long> ids(Object value) {
        if (!(value instanceof String json) || json.length() > 2000) { throw failure("INVALID_CRM_INPUT"); }
        List<?> values;
        try { values = JsonUtils.fromJson(json, List.class); }
        catch (RuntimeException invalid) { throw failure("INVALID_CRM_INPUT"); }
        if (values == null || values.size() > 50) { throw failure("INVALID_CRM_INPUT"); }
        var sorted = new TreeSet<Long>();
        for (Object item : values) {
            if (!sorted.add(positive(item))) { throw failure("INVALID_CRM_INPUT"); }
        }
        return new ArrayList<>(sorted);
    }

    /**
     * 方法作用：读取本表历史，损坏内容不能当作首次保存。
     * @param value 数据库实际JSON，例如requestKeypick-1/versionNo1
     * @return 真实返回示例：可追加的历史列表，原值不覆盖。
     * 异常或副作用示例：损坏内容传播错误，不重置审计。
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> history(Object value) {
        return new ArrayList<>((List<Map<String, Object>>) (List<?>) JsonUtils.fromJson(value.toString(), List.class));
    }

    /**
     * 方法作用：返回精确文本版本和稳定客户编号。
     * @param partnerId 实际客户，例如200000
     * @param revision 本请求首次结果版本，例如1
     * @param replay 是否原结果重放，例如false
     * @return 真实返回示例：data={partnerId:"200000",versionNo:"1",replay:false}。
     * 异常或副作用示例：不把未提交的变更声明为成功。
     */
    private CommonResult receipt(long partnerId, long revision, boolean replay) {
        return buildSuccessResult(Map.of("partnerId", Long.toString(partnerId), "versionNo", Long.toString(revision),
                "replay", replay), "客户分类已保存。");
    }

    /**
     * 方法作用：校验前端字段白名单，不接受身份覆盖。
     * @param input 候选，例如organizationCandidateId901/partnerId200000
     * @param allowed 本操作明确字段，例如组织和客户主键
     * 异常或副作用示例：传入tenantId立即拒绝，不执行SQL。
     */
    private static void keys(CommonParam input, Set<String> allowed) {
        if (input == null || !allowed.containsAll(input.getParamMap().keySet())) { throw failure("INVALID_CRM_INPUT"); }
    }

    /**
     * 方法作用：安全读取范围候选，让匿名请求先遵循原准入。
     * @param input 前端输入，例如null
     * @param key 需要字段，例如organizationCandidateId
     * @return 真实返回示例：null或901。
     * 异常或副作用示例：零业务写入，不使用默认组织。
     */
    private static Object value(CommonParam input, String key) {
        return input == null ? null : input.getParam(key);
    }

    /**
     * 方法作用：当前租户来自原CRM会话。
     * @return 真实返回示例：92。
     * 异常或副作用示例：匿名拒绝，不使用默认租户。
     */
    @Override protected Long getCurrentTenantId() { return access.requireDraftActor().get("tenantId"); }

    /**
     * 方法作用：真实操作人来自原CRM会话。
     * @return 真实返回示例：9211。
     * 异常或副作用示例：失效账号拒绝，不接受请求operatorId。
     */
    @Override protected Long getCurrentOperatorId() { return access.requireDraftActor().get("ownerUserId"); }

    /**
     * 方法作用：不因类型维护产生默认管理员身份。
     * @return 真实返回示例：false。
     * 异常或副作用示例：纯声明，不改权限。
     */
    @Override protected boolean isAdmin() { return false; }

    /**
     * 方法作用：关闭无版本通用写，所有保存走本表具名事务。
     * @param input 通用写入候选，例如id100000
     * 异常或副作用示例：一律CRM_GENERIC_WRITE_DISABLED，不写库。
     */
    @Override protected void applyCurrentIdentity(CommonParam input) { throw failure("CRM_GENERIC_WRITE_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用分页。
     * @param input 通用分页候选，例如pageNo1
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED，改用有范围directory。
     */
    @Override public CommonPageResult getStore(CommonPageParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用单项读取。
     * @param input 通用候选，例如id100000
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED。
     */
    @Override public CommonResult getById(CommonParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }

    /**
     * 方法作用：关闭未暴露的无范围通用批量读取。
     * @param input 通用候选，例如items内id100000
     * @return 真实返回示例：无成功返回。
     * 异常或副作用示例：CRM_GENERIC_ACCESS_DISABLED。
     */
    @Override public CommonResult getByIds(CommonBatchParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }
}
