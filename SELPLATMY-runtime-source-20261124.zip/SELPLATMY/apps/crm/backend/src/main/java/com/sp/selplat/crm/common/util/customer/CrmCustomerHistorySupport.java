package com.sp.selplat.crm.common.util.customer;

import com.sp.selplat.common.util.JsonUtils;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 原分类历史的公开只读投影；请求键和摘要不进入页面。 */
public final class CrmCustomerHistorySupport {
    /** 方法作用：禁止实例化纯投影工具；异常或副作用示例：不装配数据库。 */
    private CrmCustomerHistorySupport() { }

    /**
     * 方法作用：读取原对象有界历史，仅保留可展示业务事实。
     * @param value 原历史JSON，例如版本1、操作人9211、before[]、after[100000]
     * @return 真实返回示例：[{versionNo:"1",actorUserId:"9211",recordedAt:"2026-11-06T00:00:00Z",before:[],after:["100000"]}]。
     * 异常或副作用示例：损坏或超过2000条历史拒绝，不改原记录或回填空历史。
     * @throws IllegalStateException 历史结构损坏或超过已保存上限
     */
    public static List<Map<String, Object>> project(Object value) {
        if (value == null) { return List.of(); }
        List<?> events = JsonUtils.fromJson(value.toString(), List.class);
        if (events == null || events.size() > 2000) { throw new IllegalStateException("CRM_TYPE_HISTORY_INVALID"); }
        return events.stream().map(item -> {
            if (!(item instanceof Map<?, ?> event)) { throw new IllegalStateException("CRM_TYPE_HISTORY_INVALID"); }
            Map<String, Object> row = new LinkedHashMap<>();
            for (String key : List.of("versionNo", "actorUserId", "recordedAt")) {
                if (event.get(key) == null) { throw new IllegalStateException("CRM_TYPE_HISTORY_INVALID"); }
                row.put(key, event.get(key).toString());
            }
            row.put("before", snapshot(event.get("before")));
            row.put("after", snapshot(event.get("after")));
            return row;
        }).toList();
    }

    /**
     * 方法作用：投影类型字段或客户所选编号，禁止泄露内部请求元数据。
     * @param value 原业务快照，例如typeName教师/enabledFlagtrue/sortnum10，或[100000]
     * @return 真实返回示例：{typeName:"教师",enabledFlag:"true",sortnum:"10"}或["100000"]。
     * 异常或副作用示例：不支持的快照形态拒绝；创建前空快照保持null。
     * @throws IllegalStateException 保存的快照不属于业务字段或类型集合
     */
    private static Object snapshot(Object value) {
        if (value == null) { return null; }
        if (value instanceof List<?> ids) { return ids.stream().map(Object::toString).toList(); }
        if (!(value instanceof Map<?, ?> fields)) { throw new IllegalStateException("CRM_TYPE_HISTORY_INVALID"); }
        Map<String, Object> result = new LinkedHashMap<>();
        for (String key : List.of("id", "typeName", "enabledFlag", "sortnum")) {
            if (fields.get(key) != null) { result.put(key, fields.get(key).toString()); }
        }
        return result;
    }
}
