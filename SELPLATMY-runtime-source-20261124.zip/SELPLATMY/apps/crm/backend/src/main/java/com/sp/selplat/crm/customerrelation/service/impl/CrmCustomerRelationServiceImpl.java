/* 客户稳定编号关系拥有方；2026-10-28。 */
package com.sp.selplat.crm.customerrelation.service.impl;

import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.failure;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.positive;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.text;
import static com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.version;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.customerrelation.dao.CrmCustomerRelationDao;
import com.sp.selplat.crm.customerrelation.service.CrmCustomerRelationService;
import com.sp.selplat.crm.partner.service.CrmPartnerService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

/** 一对明确客户独立版本化；原客户不因关系维护改名、变分类、删档或获得权限。 */
@Service
public class CrmCustomerRelationServiceImpl extends BaseServiceImpl<CrmCustomerRelationDao>
        implements CrmCustomerRelationService {
    // 当前实际范围复用原CRM客户读写动作，不接收客户端身份。
    private final CrmAccessService access;
    // 原客户资料与锁只由原客户Service提供。
    private final CrmPartnerService partners;
    // 原CRM事务同时保存本关系、首次回执及追加历史。
    private final TransactionTemplate transaction;

    /**
     * 方法作用：装配原公开范围、客户拥有方和具名事务。
     * @param access 实际CRM准入，例如组织901/crm.partner.write
     * @param partners 原客户Service，例如客户200000和200001
     * @param manager 原crmTransactionManager，例如独立CRM池事务
     * 异常或副作用示例：构造不创建关系或许可。
     */
    public CrmCustomerRelationServiceImpl(CrmAccessService access, CrmPartnerService partners,
            @Qualifier("crmTransactionManager") PlatformTransactionManager manager) {
        this.access = access;
        this.partners = partners;
        transaction = new TransactionTemplate(manager);
        transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
    }

    /**
     * 方法作用：读取当前客户发出及收到的同一关系分页，姓名来自当前原客户拥有方。
     * @param input 页面候选，例如org901/partner200000/pageNo1/pageSize20
     * @return 真实返回示例：data.partner.id="200000"，page.records含OUTGOING关系100000及孩子200001。
     * 异常或副作用示例：越范围或不可见端点拒绝，不按同名客户合并。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 非法页码或页长拒绝
     */
    @Override
    @OperationLog
    public CommonResult page(CommonPageParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "partnerId"));
        long partner = positive(input.getParam("partnerId"));
        long requestedPage = positive(input.getPageNo());
        long requestedSize = positive(input.getPageSize());
        if (requestedPage > 100000 || !Set.of(5L, 10L, 20L, 50L, 100L).contains(requestedSize)) {
            throw failure("INVALID_CRM_INPUT");
        }
        var source = party(partners.getById(reference(input, partner)).getData());
        var filter = scoped(scope, partner, null);
        var page = getDao().page(filter, (int) requestedPage, (int) requestedSize);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (var raw : page.getRecords()) {
            var owner = party(partners.getById(reference(input, positive(raw.get("partnerId")))).getData());
            var related = party(partners.getById(reference(input, positive(raw.get("relatedPartnerId")))).getData());
            var row = browser(raw);
            row.put("partnerName", owner.get("partnerName"));
            row.put("relatedPartnerName", related.get("partnerName"));
            row.put("direction", positive(raw.get("partnerId")) == partner ? "OUTGOING" : "INCOMING");
            row.put("partnerState", owner.get("businessState"));
            row.put("relatedPartnerState", related.get("businessState"));
            rows.add(row);
        }
        page.setRecords(rows);
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(Map.of("partner", source, "page", page), "客户关系读取完成。");
    }

    /**
     * 方法作用：准备明确方向的两端客户及当前关系版本，旧姓名不作为关联证据。
     * @param input 页面候选，例如org901/partner200000/related200001
     * @return 真实返回示例：partner和relatedPartner的id/版本均为文本，relation.versionNo="0"表示尚未建立。
     * 异常或副作用示例：隐藏端点、跨组织或自关联拒绝，无业务写入。
     */
    @Override
    @OperationLog
    public CommonResult read(CommonParam input) {
        var scope = access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.read");
        keys(input, Set.of("organizationCandidateId", "partnerId", "relatedPartnerId"));
        long owner = positive(input.getParam("partnerId")), related = positive(input.getParam("relatedPartnerId"));
        distinct(owner, related);
        var first = party(partners.getById(reference(input, owner)).getData());
        var second = party(partners.getById(reference(input, related)).getData());
        var row = find(scope, owner, related);
        var relation = row == null ? Map.<String, Object>of("versionNo", "0", "relationName", "", "enabledFlag", true)
                : browser(row);
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.read");
        return buildSuccessResult(Map.of("partner", first, "relatedPartner", second, "relation", relation), "客户关系已准备。");
    }

    /**
     * 方法作用：规范明确两端的原版本和关系说明，使用原范围执行保护实际提交。
     * @param input 页面完整候选，例如org901/partner200000/related200001/expectedVersion0/两端版本0
     * @return 真实返回示例：data={id:"100000",partnerId:"200000",relatedPartnerId:"200001",versionNo:"1",replay:false}。
     * 异常或副作用示例：未知字段、旧版本或无资格整笔拒绝，不覆写客户资料。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 非布尔启停或非法请求键拒绝
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager", propagation = Propagation.NOT_SUPPORTED)
    public CommonResult save(CommonParam input) {
        access.requirePartnerScope(value(input, "organizationCandidateId"), "crm.partner.write");
        keys(input, Set.of("organizationCandidateId", "partnerId", "relatedPartnerId", "expectedVersion",
                "expectedPartnerVersion", "expectedRelatedPartnerVersion", "relationName", "enabledFlag", "requestKey"));
        CommonParam normalized = new CommonParam();
        for (String key : List.of("organizationCandidateId", "partnerId", "relatedPartnerId")) {
            normalized.putParam(key, positive(input.getParam(key)));
        }
        for (String key : List.of("expectedVersion", "expectedPartnerVersion", "expectedRelatedPartnerVersion")) {
            normalized.putParam(key, version(input.getParam(key)));
        }
        distinct(positive(normalized.getParam("partnerId")), positive(normalized.getParam("relatedPartnerId")));
        normalized.putParam("relationName", text(input.getParam("relationName"), 100, true));
        if (!(input.getParam("enabledFlag") instanceof Boolean)) { throw failure("INVALID_CRM_INPUT"); }
        normalized.putParam("enabledFlag", input.getParam("enabledFlag"));
        String key = text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) { throw failure("INVALID_CRM_INPUT"); }
        normalized.putParam("requestKey", key);
        String hash = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.hash(normalized);
        return access.executeTransaction(normalized.getParam("organizationCandidateId"), "crm.partner.write",
                transaction, state -> store(normalized, hash));
    }

    /**
     * 方法作用：按主键升序锁两端客户，串行保存该有向客户对，首次结果和历史同时提交。
     * @param input 已规范候选，例如parent200000/child200001/enabledFlagtrue
     * @param hash 规范完整正文摘要，例如64位SHA256
     * @return 真实返回示例：关系100000/version1；同对原键原正文返回首次版本且replay=true。
     * 异常或副作用示例：同键异正文、旧版、损坏历史或失效客户启用拒绝并回滚。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 关系冲突或版本/端点变化时拒绝
     */
    private CommonResult store(CommonParam input, String hash) {
        long ownerId = positive(input.getParam("partnerId")), relatedId = positive(input.getParam("relatedPartnerId"));
        // 反向同时维护也按同一锁顺序，避免A→B与B→A反序持锁。
        var lower = partners.lockForMaintenance(reference(input, Math.min(ownerId, relatedId)));
        var upper = partners.lockForMaintenance(reference(input, Math.max(ownerId, relatedId)));
        var owner = ownerId < relatedId ? lower : upper;
        var related = ownerId < relatedId ? upper : lower;
        var scope = access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        var existing = find(scope, ownerId, relatedId);
        var history = existing == null ? new ArrayList<Map<String, Object>>() : history(existing);
        // 原键仅属于这对稳定客户；即使回复丢失，也不再生成第二条同对关系或重复历史。
        for (var event : history) {
            if (input.getParam("requestKey").equals(event.get("requestKey"))) {
                if (!hash.equals(event.get("payloadHash"))) { throw failure("CRM_COMMAND_CONFLICT"); }
                return receipt(positive(existing.get("id")), ownerId, relatedId, version(event.get("versionNo")), true);
            }
        }
        long prior = existing == null ? 0 : version(existing.get("versionNo"));
        if (prior != version(input.getParam("expectedVersion")) || prior == Long.MAX_VALUE
                || version(owner.get("versionNo")) != version(input.getParam("expectedPartnerVersion"))
                || version(related.get("versionNo")) != version(input.getParam("expectedRelatedPartnerVersion"))) {
            throw failure("STALE_CRM_VERSION");
        }
        if ((existing == null || Boolean.TRUE.equals(input.getParam("enabledFlag")))
                && (!"ACTIVE".equals(owner.get("businessState")) || !"ACTIVE".equals(related.get("businessState")))) {
            throw failure("CRM_RELATION_CUSTOMER_INACTIVE");
        }
        if (history.size() >= 2000) { throw failure("CRM_RELATION_HISTORY_LIMIT"); }
        var before = existing == null ? Map.<String, Object>of() : Map.<String, Object>of(
                "relationName", existing.get("relationName"), "enabledFlag", existing.get("enabledFlag"));
        var after = Map.of("relationName", input.getParam("relationName"), "enabledFlag", input.getParam("enabledFlag"));
        long next = prior + 1;
        var event = new LinkedHashMap<String, Object>();
        event.put("requestKey", input.getParam("requestKey")); event.put("payloadHash", hash);
        event.put("versionNo", next); event.put("actorUserId", scope.get("actorUserId").toString());
        event.put("recordedAt", Instant.now().toString()); event.put("before", before); event.put("after", after);
        history.add(event);
        var row = scoped(scope, ownerId, relatedId);
        row.putParam("relationName", input.getParam("relationName")); row.putParam("enabledFlag", input.getParam("enabledFlag"));
        row.putParam("changeHistoryJson", JsonUtils.toJsonIgnoreNull(history)); row.putParam("lastOperateUserId", scope.get("actorUserId"));
        row.putParam("versionNo", next);
        long id;
        int changed;
        if (existing == null) {
            id = getSequence().get("id"); row.putParam("id", id); row.putParam("code", "CrmCustomerRelation_" + id);
            row.putParam("sortnum", 0); changed = getDao().insert(row);
        } else {
            id = positive(existing.get("id")); row.putParam("expectedVersion", prior); changed = getDao().updateVersion(row);
        }
        if (changed != 1) { throw failure("STALE_CRM_VERSION"); }
        access.requirePartnerScope(input.getParam("organizationCandidateId"), "crm.partner.write");
        return receipt(id, ownerId, relatedId, next, false);
    }

    /**
     * 方法作用：读取唯一同组织有向客户对，不按名称寻找。
     * @param scope 原可信范围，例如tenant92/org901
     * @param owner 原客户200000
     * @param related 目标客户200001
     * @return 真实返回示例：关系100000/version1；未建立为null。
     * 异常或副作用示例：只读本表，不生成默认关系。
     */
    private Map<String, Object> find(Map<String, Object> scope, long owner, long related) {
        var row = getDao().getByQuery(scoped(scope, owner, related));
        return row == null || row.isEmpty() ? null : row;
    }

    /**
     * 方法作用：构造本表可信过滤条件，所有客户坐标来自明确正整数。
     * @param scope 原范围，例如tenant92/org901
     * @param owner 原客户，例如200000
     * @param related 明确对方，例如200001；分页时为null
     * @return 真实返回示例：tenantId92/businessOrgId901/partnerId200000/status1。
     * 异常或副作用示例：不从客户名推导身份，无写入。
     */
    private static CommonParam scoped(Map<String, Object> scope, long owner, Long related) {
        CommonParam p = new CommonParam(); p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId")); p.putParam("partnerId", owner); p.putParam("status", 1);
        if (related != null) { p.putParam("relatedPartnerId", related); }
        return p;
    }

    /**
     * 方法作用：调用原客户公开读取或锁接口时只携带组织候选和客户编号。
     * @param input 原规范候选，例如org901
     * @param id 原客户，例如200000
     * @return 真实返回示例：CommonParam{organizationCandidateId:901,id:200000}。
     * 异常或副作用示例：不传身份覆盖或外域字段。
     */
    private static CommonParam reference(CommonParam input, long id) {
        CommonParam p = new CommonParam(); p.putParam("organizationCandidateId", input.getParam("organizationCandidateId"));
        p.putParam("id", id); return p;
    }

    /**
     * 方法作用：只输出本窗口所需的真实客户名、编号、版本及业务状态。
     * @param value 原客户服务正文，例如id200000/partnerName林女士/versionNo0
     * @return 真实返回示例：{id:"200000",partnerName:"林女士",versionNo:"0",businessState:"ACTIVE"}。
     * 异常或副作用示例：不复制电话、联系人或其他客户专属资料。
     */
    private static Map<String, Object> party(Object value) {
        var row = (Map<?, ?>) value;
        return Map.of("id", row.get("id").toString(), "partnerName", row.get("partnerName"),
                "versionNo", row.get("versionNo").toString(), "businessState", row.get("businessState"));
    }

    /**
     * 方法作用：输出真实关系安全字段，内部完整回执历史不直接暴露给页面。
     * @param row 本表行，例如id100000/version1/partner200000/related200001
     * @return 真实返回示例：id、两端客户、versionNo均为文本，enabledFlag为布尔值。
     * 异常或副作用示例：不返回请求摘要及其他账号私有记录。
     */
    private static Map<String, Object> browser(Map<String, Object> row) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (String key : List.of("id", "partnerId", "relatedPartnerId", "versionNo")) { out.put(key, row.get(key).toString()); }
        out.put("relationName", row.get("relationName")); out.put("enabledFlag", row.get("enabledFlag"));
        return out;
    }

    /**
     * 方法作用：核对本关系历史连续性，损坏内容不能重置为首次创建。
     * @param row 本表原行，例如version2和两个按序事件
     * @return 真实返回示例：可追加的两条历史Map。
     * 异常或副作用示例：损坏JSON、重复请求键、断档版本拒绝，不改原历史。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 历史不完整时拒绝
     */
    @SuppressWarnings("unchecked")
    private static ArrayList<Map<String, Object>> history(Map<String, Object> row) {
        try {
            String json = row.get("changeHistoryJson").toString();
            if (json.length() > 2000000) { throw failure("CRM_RELATION_HISTORY_INVALID"); }
            var raw = JsonUtils.fromJson(json, List.class);
            if (raw == null || raw.size() != version(row.get("versionNo")) || raw.size() > 2000) { throw failure("CRM_RELATION_HISTORY_INVALID"); }
            ArrayList<Map<String, Object>> result = new ArrayList<>(); Set<String> seen = new java.util.HashSet<>();
            for (Object item : raw) {
                if (!(item instanceof Map<?, ?> event) || version(event.get("versionNo")) != result.size() + 1L
                        || !(event.get("requestKey") instanceof String key) || !seen.add(key)
                        || !(event.get("payloadHash") instanceof String hash) || !hash.matches("[a-f0-9]{64}")
                        || !(event.get("before") instanceof Map<?, ?>) || !(event.get("after") instanceof Map<?, ?>)) {
                    throw failure("CRM_RELATION_HISTORY_INVALID");
                }
                var before = (Map<?, ?>) event.get("before");
                var after = (Map<?, ?>) event.get("after");
                if (!event.keySet().equals(Set.of("requestKey", "payloadHash", "versionNo", "actorUserId", "recordedAt", "before", "after"))
                        || !key.matches("[A-Za-z0-9_.:-]{1,64}")
                        || !after.keySet().equals(Set.of("relationName", "enabledFlag"))
                        || !(after.get("relationName") instanceof String name) || name.isBlank() || name.length() > 100
                        || !(after.get("enabledFlag") instanceof Boolean)
                        || (result.isEmpty() ? !before.isEmpty() : !before.equals(result.get(result.size() - 1).get("after")))) {
                    throw failure("CRM_RELATION_HISTORY_INVALID");
                }
                positive(event.get("actorUserId")); Instant.parse(event.get("recordedAt").toString());
                result.add((Map<String, Object>) event);
            }
            if (result.isEmpty() || !result.get(result.size() - 1).get("after").equals(
                    Map.of("relationName", row.get("relationName"), "enabledFlag", row.get("enabledFlag")))) {
                throw failure("CRM_RELATION_HISTORY_INVALID");
            }
            return result;
        } catch (RuntimeException failure) { throw failure("CRM_RELATION_HISTORY_INVALID"); }
    }

    /**
     * 方法作用：返回该客户对原请求的首次关系编号及版本，不宣告当前版本未被后续更新。
     * @param id 原关系100000
     * @param owner 原客户200000
     * @param related 对方200001
     * @param revision 原请求结果版本，例如1
     * @param replay 是否旧请求，例如true
     * @return 真实返回示例：data.id="100000"/versionNo="1"/replay=true。
     * 异常或副作用示例：只在事务完成路径返回，不写其他域。
     */
    private CommonResult receipt(long id, long owner, long related, long revision, boolean replay) {
        return buildSuccessResult(Map.of("id", Long.toString(id), "partnerId", Long.toString(owner),
                "relatedPartnerId", Long.toString(related), "versionNo", Long.toString(revision), "replay", replay), "客户关系已保存。");
    }

    /**
     * 方法作用：拒绝同一客户关联自身，不根据姓名判断。
     * @param first 原客户，例如200000
     * @param second 目标客户，例如200001
     * 异常或副作用示例：同编号返回INVALID_CRM_INPUT，无关系写入。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 两端相同拒绝
     */
    private static void distinct(long first, long second) { if (first == second) { throw failure("INVALID_CRM_INPUT"); } }

    /**
     * 方法作用：检查本操作明确字段，拒绝客户端tenantId/actor/scope覆盖。
     * @param input 原输入，例如organizationCandidateId901
     * @param allowed 当前固定字段集合，例如组织及客户对
     * 异常或副作用示例：未知字段拒绝，无SQL执行。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺输入或未知字段拒绝
     */
    private static void keys(CommonParam input, Set<String> allowed) {
        if (input == null || !allowed.containsAll(input.getParamMap().keySet())) { throw failure("INVALID_CRM_INPUT"); }
    }

    /**
     * 方法作用：安全取候选，确保身份和范围先于输入错误处理。
     * @param input 原页面候选，例如null
     * @param key 明确字段，例如organizationCandidateId
     * @return 真实返回示例：901或null，不默认组织。
     * 异常或副作用示例：无业务读写。
     */
    private static Object value(CommonParam input, String key) { return input == null ? null : input.getParam(key); }

    /** 方法作用：服务端租户来自原CRM当前身份。
     * @return 真实返回示例：92；匿名拒绝，无默认租户。 */
    @Override protected Long getCurrentTenantId() { return access.requireDraftActor().get("tenantId"); }
    /** 方法作用：真实操作人来自原CRM身份。
     * @return 真实返回示例：9211；不接受客户端操作员。 */
    @Override protected Long getCurrentOperatorId() { return access.requireDraftActor().get("ownerUserId"); }
    /** 方法作用：关闭默认管理员推定。
     * @return 真实返回示例：false，无权限写入。 */
    @Override protected boolean isAdmin() { return false; }
    /** 方法作用：关闭无版本通用写。
     * @param input 通用候选，例如id100000；一律拒绝。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 所有通用写拒绝，无数据库写入 */
    @Override protected void applyCurrentIdentity(CommonParam input) { throw failure("CRM_GENERIC_WRITE_DISABLED"); }
    /** 方法作用：关闭无范围通用分页。
     * @param input 通用候选，例如pageNo1
     * @return 真实返回示例：无成功返回，使用具名page。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无范围通用读拒绝 */
    @Override public CommonPageResult getStore(CommonPageParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }
    /** 方法作用：关闭无范围通用详情。
     * @param input 通用候选，例如id100000
     * @return 真实返回示例：无成功返回，使用具名read。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无范围通用读拒绝 */
    @Override public CommonResult getById(CommonParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }
    /** 方法作用：关闭无范围批量读取。
     * @param input 通用批量候选，例如items内id100000
     * @return 真实返回示例：无成功返回，不绕过客户资格。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无范围通用读拒绝 */
    @Override public CommonResult getByIds(CommonBatchParam input) { throw failure("CRM_GENERIC_ACCESS_DISABLED"); }
}
