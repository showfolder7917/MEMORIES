/** CrmCommandRequestDao.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
package com.sp.selplat.crm.commandrequest.dao;

/** 本表复用公共DAO，不访问业务主体或其他表DAO。 */
public interface CrmCommandRequestDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 请求按scope/name/key锁读；参数例如org901/PARTNER_SAVE/k1；返回真实行或null；无CRM事务拒绝。
     *
     * @param p
     *     本方法声明的业务候选；示例与正文相同：请求按scope/name/key锁读；参数例如org901/PARTNER_SAVE/k1；返回真实行或null；无CRM事务拒绝。
     * @return 真实行或null
     */
    java.util.Map<String, Object> findRequest(com.sp.selplat.common.util.CommonParam p);

    /**
     * 完成请求；参数例如id200000/partner200000/version0/首次JSON；返回影响行数；重复完成拒绝。
     *
     * @param p 本方法声明的业务候选；示例与正文相同：完成请求；参数例如id200000/partner200000/version0/首次JSON；返回影响行数；重复完成拒绝。
     * @return 影响行数
     */
    int complete(com.sp.selplat.common.util.CommonParam p);
}
