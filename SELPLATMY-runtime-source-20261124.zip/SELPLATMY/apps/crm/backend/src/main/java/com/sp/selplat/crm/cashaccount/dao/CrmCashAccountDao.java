/** 单一销售收款隔离本表组件；2026-10-03，Codex；生产默认拒绝。 */
package com.sp.selplat.crm.cashaccount.dao;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，不跨表SQL。 */
public interface CrmCashAccountDao extends com.sp.selplat.common.db.dao.BaseDao {
    /**
     * 本表精确范围锁；缺CRM事务拒绝。
     *
     * @param input tenant92/org901/id1000000
     * @return 实际行或null；不构造默认主数据
     */
    Map<String, Object> lockScoped(CommonParam input);
    /**
     * 方法作用：按真实组织和创建请求找首次账户，不按姓名合并。
     * @param input 原范围tenant92/org901/creationRequestKey=account-1
     * @return 真实返回示例：id1600000/creationHash；未命中null。
     * 异常或副作用示例：纯读取，不访问余额或其他表。
     */
    Map<String, Object> creation(CommonParam input);

    /**
     * 方法作用：本表原子保存账户及追加维护历史；更新不改变编码、币种或余额。
     * @param input 已核范围及规范正文，例如id1600000/name学校现金/expectedVersion0
     * @param create true首次创建；false执行原版本CAS
     * @return 真实返回示例：1成功；0为旧版本，服务层整体回滚。
     * 异常或副作用示例：重复编码或请求由原数据库唯一约束拒绝，无半份审计。
     */
    int saveMaintenance(CommonParam input, boolean create);
}
