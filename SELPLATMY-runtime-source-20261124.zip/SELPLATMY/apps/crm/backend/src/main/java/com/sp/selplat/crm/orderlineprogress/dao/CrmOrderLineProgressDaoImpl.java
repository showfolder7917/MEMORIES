/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.orderlineprogress.dao;

import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/**
 * 本表固定参数化SQL与公共模板共用CRM连接。
 */
@org.springframework.stereotype.Repository
public class CrmOrderLineProgressDaoImpl extends com.sp.selplat.crm.common.persistence.CrmBaseDao
    implements CrmOrderLineProgressDao {

  /**
   * 保留默认sortnum主排序，以本组织唯一id稳定读取同值分页，不改变业务范围或写入。
   *
   * @param conditions 服务回查的实际条件，例如tenantId=92/businessOrgId=901/status=1
   * @param pageNo 原页码，例如2
   * @param pageSize 原页长，例如1
   * @return 公共实际页，例如totalCount=12/pageNo=2/records为第二个真实ID
   *     异常或副作用示例：公共查询异常沿原合同抛出；不修改履约、账本或号段。
   */
  @Override
  public com.sp.selplat.common.util.CommonPageResult getPageList(
      Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
    return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
  }

  private final org.springframework.jdbc.core.JdbcTemplate jdbc;

  /**
   * 注入本域固定模板；构造不执行SQL。
   *
   * @param jdbc 本域crmJdbcTemplate，例如明确测试CRM池；副作用示例：不执行跨库SQL或发号。
   */
  public CrmOrderLineProgressDaoImpl(
      @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
          org.springframework.jdbc.core.JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * 本表范围锁，不从客户端读取可信org。
   *
   * @param input 例如tenant92/org901/id1000000
   * @return 实际有效行或null；事务缺失时拒绝
   */
  @Override
  public Map<String, Object> lockScoped(CommonParam input) {
    requireCrmTransaction();
    var rows =
        jdbc.queryForList(
            "SELECT * FROM CrmOrderLineProgress WHERE tenantId=? AND businessOrgId=?"
                + " AND id=? AND status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("id"));
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 真实来源行累计锁。
   *
   * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
   * @return 实际本表结果；缺真实许可/范围/事务拒绝
   */
  @Override
  public Map<String, Object> lockForLine(CommonParam input) {
    requireCrmTransaction();
    var r =
        jdbc.queryForList(
            "SELECT * FROM CrmOrderLineProgress WHERE tenantId=? AND businessOrgId=?"
                + " AND orderLineId=? AND status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("orderLineId"));
    return r.isEmpty() ? null : r.get(0);
  }

  /**
   * 只查询本表来源行，不在Document组之前取得Progress行锁。
   *
   * @param input tenant92/org901/orderLineId600001，必须存在CRM事务及上层原订单锁
   * @return 实际行或null，例如lastReturnDetailId1300002；副作用示例：不发号、不写入、不锁Progress。
   */
  @Override
  public Map<String, Object> peekForLine(CommonParam input) {
    requireCrmTransaction();
    var rows =
        jdbc.queryForList(
            "SELECT * FROM CrmOrderLineProgress WHERE tenantId=? AND businessOrgId=?"
                + " AND orderLineId=? AND status=1",
            input.getParam("tenantId"),
            input.getParam("businessOrgId"),
            input.getParam("orderLineId"));
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 履约总量条件CAS。
   *
   * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
   * @return 实际本表结果；缺真实许可/范围/事务拒绝
   */
  @Override
  public int applyIssue(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " stockPostedQuantity=stockPostedQuantity+?,versionNo=versionNo+1,"
            + "updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND versionNo=? AND"
            + " versionNo<9223372036854775807 AND"
            + " stockPostedQuantity+?<=authorizedQuantity",
        input.getParam("quantity"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("quantity"));
  }

  /**
   * 方法作用及真实业务示例：本表累计已收最小单位条件CAS；progress1400000/version0/amount68/actor9211；成功计数68、版本加1；超冻结额度、撤权或零行拒绝整笔，订单仍APPROVED。
   * Fixed parameterized source cash settlement capacity update.
   *
   * @param input actual org901/id1400000/version0/amountMinor68/actor9211
   * @return one changed row or zero; no source order state side effect
   */
  @Override
  public int applyReceipt(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " cashSettledMinor=cashSettledMinor+?,versionNo=versionNo+1,updatedByUserId=?"
            + ",lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND versionNo=? AND"
            + " versionNo<9223372036854775807 AND cashSettledMinor+?<=authorizedMinor AND"
            + " status=1",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"));
  }

  /**
   * 方法作用：减除原收款已收R并保留F≤R约束。
   *
   * @param input org901/progress1400000/version1/amount68
   * @return 影响1或0；不能使未冲退款大于剩余已收 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  @Override
  public int reverseReceipt(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " cashSettledMinor=cashSettledMinor-?,versionNo=versionNo+1,updatedByUserId=?"
            + ",lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
            + " AND versionNo<9223372036854775807 AND"
            + " cashSettledMinor-?>=cashRefundedMinor+courseRefundedMinor",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"));
  }

  /**
   * 原进度I保持，只增加有效实际退货T和末明细节点。 实际写入示例：T从0增加到1，I保持3，版本从1增加到2；越界影响0行。
   *
   * @param input tenant92/org901/id1400000/version1/quantity1/lastReturnDetailId1300002/actor9211
   * @return 实际影响1或0行，T越I、Q0或旧版本返回0
   */
  @Override
  public int applyReturn(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET stockReturnedQuantity=stockReturnedQuantity+?,"
            + " lastReturnDetailId=?,versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,"
            + " updatedAt=CURRENT_TIMESTAMP WHERE tenantId=? AND businessOrgId=? AND id=?"
            + " AND status=1 AND versionNo=? AND versionNo<9223372036854775807 AND"
            + " authorizedQuantity>0 AND stockReturnedQuantity+?<=stockPostedQuantity",
        input.getParam("quantity"),
        input.getParam("lastReturnDetailId"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("quantity"));
  }

  /**
   * 按原累计权益与真实已收限额条件CAS一次F，DB CHECK再次保护商品权益。 实际写入示例：F从0增加到1，R保持3，版本从2增加到3；越界影响0行。
   *
   * @param input tenant92/org901/id1400000/version2/amountMinor1/actor9211
   * @return 影响1或0行；旧版本、超过R/E(T)或接续策略返回0
   */
  @Override
  public int applyRefund(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET cashRefundedMinor=cashRefundedMinor+?,"
            + " versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
            + " AND versionNo<9223372036854775807 AND authorizedQuantity>0 AND"
            + " refundPolicyVersion='GOODS_ONLY_V1' AND"
            + " cashRefundedMinor+?+courseRefundedMinor<=cashSettledMinor AND CAST(cashRefundedMinor+? AS"
            + " DECIMAL(48,0))*authorizedQuantity <=CAST(refundableGoodsMinor AS"
            + " DECIMAL(48,0))*stockReturnedQuantity",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"),
        input.getParam("amountMinor"));
  }

  /**
   * 方法作用：原行课程退款独立累计，CAS同时限制真实实收、原净额及服务器核定累计上限。
   * @param input 原范围9/901/id100000/version1/amountMinor18/maximumCumulativeMinor18/actor9101
   * @return 真实示例：courseRefundedMinor0变18返回1，旧版本或上限冲突返回0。
   * 异常或副作用示例：不更改cashRefundedMinor、stockReturnedQuantity或冻结政策，不写现金。
   */
  @Override
  public int applyCourseRefund(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET courseRefundedMinor=courseRefundedMinor+?,"
            + "versionNo=versionNo+1,updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP "
            + "WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=? "
            + "AND versionNo<9223372036854775807 AND refundPolicyVersion='GOODS_ONLY_V1' "
            + "AND stockReturnedQuantity=0 AND cashRefundedMinor=0 "
            + "AND courseRefundedMinor+?<=cashSettledMinor "
            + "AND courseRefundedMinor+?<=refundableGoodsMinor "
            + "AND courseRefundedMinor+?<=? AND ?<=refundableGoodsMinor",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"),
        input.getParam("amountMinor"),
        input.getParam("amountMinor"),
        input.getParam("maximumCumulativeMinor"),
        input.getParam("maximumCumulativeMinor"));
  }

  /**
   * 减除实际F，保留R与I/T；例如F2→0、R5不变，版本3→4，超F影响0行。
   *
   * @param input tenant92/org901/id1400000/version3/amountMinor2/actor9211
   * @return 本表实际影响1或0行，不更新订单
   */
  @Override
  public int reverseRefund(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " cashRefundedMinor=cashRefundedMinor-?,versionNo=versionNo+1,updatedByUserId=?"
            + ",lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
            + " AND versionNo<9223372036854775807 AND cashRefundedMinor>=?",
        input.getParam("amountMinor"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("amountMinor"));
  }

  /**
   * 减完整原库存履约I；例如I3/T0→I0，旧版本或有效T越界影响0行。
   *
   * @param input tenant92/org901/id1400000/version3/quantity3/actor9211
   * @return 本表影响1或0行，不更改Order
   */
  @Override
  public int reverseIssue(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " stockPostedQuantity=stockPostedQuantity-?,versionNo=versionNo+1,updatedByUserId=?,"
            + "lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
            + " AND versionNo<9223372036854775807 AND"
            + " stockPostedQuantity-?>=stockReturnedQuantity",
        input.getParam("quantity"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("quantity"));
  }

  /**
   * 减完整最新退货T并回退末节点；例如T3→2/末节点1300001，越界0行，不重开发货I。
   *
   * @param input
   *     tenant92/org901/id1400000/version3/quantity1/previousReturnDetailId1300001/actor9211
   * @return 本表影响1或0行，权益CHECK失败全事务回滚
   */
  @Override
  public int reverseReturn(CommonParam input) {
    requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmOrderLineProgress SET"
            + " stockReturnedQuantity=stockReturnedQuantity-?,lastReturnDetailId=?,versionNo=versionNo+1,updatedByUserId=?,"
            + "lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=?"
            + " AND versionNo<9223372036854775807 AND stockReturnedQuantity>=?",
        input.getParam("quantity"),
        input.getParam("previousReturnDetailId"),
        input.getParam("actorUserId"),
        input.getParam("actorUserId"),
        input.getParam("tenantId"),
        input.getParam("businessOrgId"),
        input.getParam("id"),
        input.getParam("versionNo"),
        input.getParam("quantity"));
  }
}
