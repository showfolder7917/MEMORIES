/** CrmPartnerDao.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.partner.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 本表公共DAO及固定锁/CAS扩展，不能访问其他表。 */
public interface CrmPartnerDao extends BaseDao {
    /**
     * 锁当前组织记录；参数例如tenant92/org901/id200000；返回真实行或null；无CRM事务拒绝。
     *
     * @param p 本方法声明的业务候选；示例与正文相同：锁当前组织记录；参数例如tenant92/org901/id200000；返回真实行或null；无CRM事务拒绝。
     * @return 真实行或null
     */
    Map<String, Object> lockScoped(CommonParam p);

    /**
     * 按版本保存业务字段；参数例如id200000/version0；返回影响行数0/1；调用服务负责0行回滚。
     *
     * @param p 本方法声明的业务候选；示例与正文相同：按版本保存业务字段；参数例如id200000/version0；返回影响行数0/1；调用服务负责0行回滚。
     * @return 影响行数0/1
     */
    int updateVersion(CommonParam p);

  /**
   * 方法作用：只读本表当前页所需客户名称，不跨表查询或取得写锁。
   *
   * @param tenant 服务端真实租户，例如9
   * @param organization 服务端真实经营组织，例如901
   * @param ids 已校验当前页主键集合，例如[600000]，最多100个
   * @return 真实示例：本表安全字段集合；空主键返回空集合，不退化为全表
   * @throws IllegalArgumentException 主键超过100项时拒绝，无写入副作用
   */
  java.util.List<java.util.Map<String, Object>> orderListNames(
      long tenant, long organization, java.util.List<Long> ids);
  /**
   * 方法作用：按原组织、版本及相反归档状态CAS更新本表，保留原业务启停和资料。
   *
   * @param input 拥有方已核实参数，例如tenant9/org901/id501/version0/archivedFlag=true及原因
   * @return 真实返回示例：1表示只更新目标客户；0表示版本或状态冲突，无其他写入。
   * @throws IllegalStateException 未进入原CRM事务时拒绝，不修改数据
   */
  int updateArchive(CommonParam input);
}
