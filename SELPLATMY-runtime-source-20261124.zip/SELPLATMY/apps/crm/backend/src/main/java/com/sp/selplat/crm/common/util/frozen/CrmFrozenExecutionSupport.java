/** CRM完整冻结执行历史校验；2026-10-04，Codex；纯值，不造身份或效果。 */
package com.sp.selplat.crm.common.util.frozen;

import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** 资金与库存共用完整反向历史校验，不信人工status或头状态。 */
public final class CrmFrozenExecutionSupport {
    /** 无状态工具不实例化，不创建数据库或许可。 */
    private CrmFrozenExecutionSupport() {
        // 仅核完整冻结值，不保存可变状态。
    }

    /**
     * 校验真实完整POST及唯一严格相反批次；例如POST两行-1/-1、唯一REVERSE两行+1/+1返回false；缺反向true。
     *
     * @param post 实际POST头，例如1200000/count2/hash
     * @param before 实际POST全部明细，不是客户端输入
     * @param reverse 所有引用该原POST的真实反向头，0或1
     * @param after 唯一反向头全部明细，无反向时空列表
     * @return 有效POST true，完整反向false；不完整/改维度/摘要/非相反金额数量拒绝，无写入
     */
    public static boolean effective(
            Map<String, Object> post,
            List<Map<String, Object>> before,
            List<Map<String, Object>> reverse,
            List<Map<String, Object>> after) {
        if (!"POST".equals(post.get("action"))
                || before.size() != ((Number) post.get("detailCount")).intValue()
                || before.isEmpty()) {
            throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
        }
        Map<Object, Map<String, Object>> originals = new HashMap<>();
        for (var row : before) {
            if (!"POST".equals(row.get("action"))
                    || !post.get("id").equals(row.get("batchId"))
                    || !post.get("documentId").equals(row.get("documentId"))
                    || originals.put(row.get("id"), row) != null) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
        }
        if (reverse.isEmpty()) {
            if (!after.isEmpty()) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
            return true;
        }
        if (reverse.size() != 1) {
            throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
        }
        var batch = reverse.get(0);
        if (!"REVERSE".equals(batch.get("action"))
                || !post.get("id").equals(batch.get("originalBatchId"))
                || !post.get("documentId").equals(batch.get("documentId"))
                || !post.get("approvedSnapshotHash").equals(batch.get("approvedSnapshotHash"))
                || after.size() != before.size()
                || after.size() != ((Number) batch.get("detailCount")).intValue()) {
            throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
        }
        for (var row : after) {
            var old = originals.remove(row.get("originalDetailId"));
            if (old == null
                    || !"REVERSE".equals(row.get("action"))
                    || !batch.get("id").equals(row.get("batchId"))) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
            for (String field :
                    List.of(
                            "documentId",
                            "documentLineId",
                            "sourceOrderLineId",
                            "lineNo",
                            "effectKind",
                            "fundsBalanceId",
                            "accountId",
                            "currency",
                            "stockBalanceId",
                            "warehouseId",
                            "productId",
                            "quantityUnit")) {
                if (!Objects.equals(old.get(field), row.get(field))) {
                    throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
                }
            }
            String delta =
                    "CASH".equals(old.get("effectKind")) ? "amountDeltaMinor" : "quantityDelta";
            if (new BigDecimal(old.get(delta).toString())
                            .negate()
                            .compareTo(new BigDecimal(row.get(delta).toString()))
                    != 0) {
                throw CrmPartnerValueSupport.failure("CRM_DEPENDENCY_INTEGRITY");
            }
        }
        return false;
    }
}
