/** CrmPostingRequestService.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingrequest.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;

/** 本人隔离过账记录服务继承公共契约，仅由本域工作流调用，不开放通用管理 HTTP。 */
public interface CrmPostingRequestService extends BaseService {
    /**
     * 本表原子流程扩展 claimRequest，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    Long claimRequest(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 completeRequest，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖 返回示例：void，成功条件更新恰好一行。
     *     异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    void completeRequest(com.sp.selplat.common.util.CommonParam input);

    /**
     * 本表原子流程扩展 readCommittedRequest，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    java.util.Map<String, Object> readCommittedRequest(
            com.sp.selplat.common.util.CommonParam input);

    /**
     * V2组织批次首次结果。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    Long claimOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查 返回示例：void；零CAS、缺许可或约束异常整笔回滚
     */
    void completeOrganization(CommonParam input);

    /**
     * 本表V2固定范围/版本方法。
     *
     * @param input 例如org901/id1000000/version0；真实身份服务端回查
     * @return 首次实际已提交请求或null，无余额副作用；缺真实许可拒绝
     */
    java.util.Map<String, Object> committedOrganization(CommonParam input);

    /**
     * Actual receipt request claim/complete/first-result read through the same owning organization
     * key.
     *
     * @param input org901/document1000000/keyreceipt and actual first batch/result
     * @return Long result; failed claim must exit transaction before replay, altered content
     *     rejects
     */
    Long claimOrganizationFunds(com.sp.selplat.common.util.CommonParam input);

    /**
     * Actual receipt request claim/complete/first-result read through the same owning organization
     * key.
     *
     * @param input org901/document1000000/keyreceipt and actual first batch/result 返回示例：void
     *     result; failed claim must exit transaction before replay, altered content rejects
     */
    void completeOrganizationFunds(com.sp.selplat.common.util.CommonParam input);

    /**
     * Actual receipt request claim/complete/first-result read through the same owning organization
     * key.
     *
     * @param input org901/document1000000/keyreceipt and actual first batch/result
     * @return java.util.Map<String,Object> result; failed claim must exit transaction before
     *     replay, altered content rejects
     */
    java.util.Map<String, Object> committedOrganizationFunds(
            com.sp.selplat.common.util.CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Long claimOrganizationFundsReverse(CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    void completeOrganizationFundsReverse(CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    java.util.Map<String, Object> committedOrganizationFundsReverse(CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    Long claimOrganizationStockReverse(CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    void completeOrganizationStockReverse(CommonParam input);

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    java.util.Map<String, Object> committedOrganizationStockReverse(CommonParam input);
}
