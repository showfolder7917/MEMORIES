/** CrmCustomerDraftDaoImpl.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.customerdraft.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.stereotype.Repository;

/** 本人客户草稿持久化复用本域上下文及公共 DAO，归属在真实主键中。 */
@Repository
public class CrmCustomerDraftDaoImpl extends CrmBaseDao implements CrmCustomerDraftDao {
    // 客户锁使用与公共模板相同的 CRM 数据源。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmJdbcTemplate")
    private org.springframework.jdbc.core.JdbcTemplate jdbc;

    /**
     * 锁本人有效客户；参数例如id101/tenant92/owner9211；返回行或null；无CRM事务拒绝，锁持续至提交。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：锁本人有效客户；参数例如id101/tenant92/owner9211；返回行或null；无CRM事务拒绝，锁持续至提交。
     * @return 行或null
     */
    @Override
    public java.util.Map<String, Object> lockForPosting(
            com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        java.util.List<java.util.Map<String, Object>> rows =
                jdbc.queryForList(
                        "SELECT * FROM CrmCustomerDraft WHERE tenantId=? AND ownerUserId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("id"));
        if (rows.size() > 1) {
            throw new IllegalStateException("Expected one customer");
        }
        return rows.isEmpty() ? null : rows.get(0);
    }
}
