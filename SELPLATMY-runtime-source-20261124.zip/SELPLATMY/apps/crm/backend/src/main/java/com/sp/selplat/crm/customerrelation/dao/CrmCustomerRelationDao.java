/* 客户稳定编号关系本表存取；2026-10-28。 */
package com.sp.selplat.crm.customerrelation.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonPageResult;

/** 只访问关系表；两端客户锁和范围由公开客户Service提供。 */
public interface CrmCustomerRelationDao extends BaseDao {
    /**
     * 方法作用：分页读取客户发出和收到的同一份关系记录。
     * @param input 可信范围，例如tenant92/org901/partner200000
     * @param page 页码，例如1
     * @param size 页容量，例如20
     * @return 真实返回示例：records含一条关系、totalCount=1、pageNo=1。
     * 异常或副作用示例：只读本表，查询失败传播，无跨表SQL。
     */
    CommonPageResult page(CommonParam input, int page, int size);

    /**
     * 方法作用：在原客户锁内按关系原版本更新说明、启停和追加历史。
     * @param input 本表字段，例如id100000/expectedVersion1/relationName孩子/enabledFlag=false
     * @return 真实返回示例：更新1条；旧版本为0。
     * 异常或副作用示例：缺CRM事务拒绝，不修改客户档案。
     */
    int updateVersion(CommonParam input);
}
