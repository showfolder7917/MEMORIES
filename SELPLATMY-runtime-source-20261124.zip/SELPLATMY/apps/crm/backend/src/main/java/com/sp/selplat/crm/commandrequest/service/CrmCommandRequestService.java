/**
 * CrmCommandRequestService.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
package com.sp.selplat.crm.commandrequest.service;

import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 仅本表追加/读取，事务由 owning业务Service协调。 */
public interface CrmCommandRequestService extends com.sp.selplat.common.service.BaseService {
    /**
     * claim请求；输入例如org901/PARTNER_SAVE/k1/hash；返回请求id；唯一冲突要求外层回滚后读重放。
     *
     * @param input
     *     本方法声明的业务候选；示例与正文相同：claim请求；输入例如org901/PARTNER_SAVE/k1/hash；返回请求id；唯一冲突要求外层回滚后读重放。
     * @return 请求id
     */
    Long claim(CommonParam input);

    /**
     * 完成首次结果；输入例如requestid200000/partnerId/version0；无返回；失败回滚业务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：完成首次结果；输入例如requestid200000/partnerId/version0；无返回；失败回滚业务。
     */
    void complete(CommonParam input);

    /**
     * 已提交首次结果；输入例如org901/PARTNER_SAVE/k1；返回真实请求或null；单独CRM事务读取。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：已提交首次结果；输入例如org901/PARTNER_SAVE/k1；返回真实请求或null；单独CRM事务读取。
     * @return 真实请求或null
     */
    Map<String, Object> committed(CommonParam input);
}
