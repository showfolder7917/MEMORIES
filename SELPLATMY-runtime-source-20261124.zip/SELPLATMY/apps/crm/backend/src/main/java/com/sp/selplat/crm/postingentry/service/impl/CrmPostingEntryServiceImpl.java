/** 修改记录：2026-10-09，私人批读沿用有效记录边界，不开放新的写路由。 */
/** CrmPostingEntryServiceImpl.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingentry.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.draft.CrmDraftScopeSupport;
import com.sp.selplat.crm.postingentry.dao.CrmPostingEntryDao;
import com.sp.selplat.crm.postingentry.service.CrmPostingEntryService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

/** 本表服务直接复用公共 CRUD；仅预处理私人归属、校验和本域事务。 */
@Service
public class CrmPostingEntryServiceImpl extends BaseServiceImpl<CrmPostingEntryDao>
        implements CrmPostingEntryService {
    // 准入能力从真实 Uniauth 回查身份，字段不由客户端提供。
    private final CrmAccessService accessService;

    // 只允许本表真实搜索字段，不允许请求传入租户或 owner 操作符。
    private static final Set<String> SEARCH_FIELDS = Set.of();

    /**
     * 装配真实准入能力；DAO 由公共泛型绑定。
     *
     * @param accessService 本域准入服务，例如 CrmAccessServiceImpl 副作用示例：构造不建立 Session、不查询 SQL、不授予管理员权限。
     */
    public CrmPostingEntryServiceImpl(CrmAccessService accessService) {
        this.accessService = accessService;
    }

    /**
     * 查询本人有效记录的公共分页。
     *
     * @param queryIn 标准参数，例如 {pageNo:1,pageSize:20}
     * @return 公共页，例如 {records:[],totalCount:0,pageNo:1,pageSize:20} 异常示例：无真实账号或正数归属时拒绝，不执行无范围 SQL。
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam queryIn) {
        CommonPageParam scoped =
                CrmDraftScopeSupport.scopeStore(
                        queryIn, accessService.requireDraftActor(), SEARCH_FIELDS);
        return super.getStore(scoped);
    }

    /**
     * 委托公共精确复合主键读取本人记录。
     *
     * @param queryIn 参数，例如 {id:100001,tenantId:1}
     * @return 公共结果，例如 {success:true,data:{id:100001,status:1}} 异常示例：非法 ID、其他 owner/tenant
     *     和删除记录均拒绝；不写库。
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam queryIn) {
        CommonParam scoped =
                CrmDraftScopeSupport.scopeDetail(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.requireActive(super.getById(scoped));
    }

    /**
     * 批量读取公共精确主键，空输入保持空批次，软删除记录不返回。
     *
     * @param queryIn 参数，例如 items=[{id:100001}] 或 []
     * @return 公共批量结果，例如 {success:true,data:[]} 异常示例：非法身份或 ID 拒绝；不会退化为分页查询。
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam queryIn) {
        CommonBatchParam scoped =
                CrmDraftScopeSupport.scopeBatch(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.activeBatch(super.getByIds(scoped));
    }

    /**
     * 取得真实审计操作员。
     *
     * @return 当前账号主键，例如 9211L；无默认操作员 异常示例：账号失效时沿用统一身份拒绝，不访问本表 SQL。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return accessService.requireDraftActor().get("ownerUserId");
    }

    /**
     * 取得真实租户。
     *
     * @return 当前租户，例如 92L；无默认租户 异常示例：归属无效时拒绝，不接收客户端身份。
     */
    @Override
    protected Long getCurrentTenantId() {
        return accessService.requireDraftActor().get("tenantId");
    }

    /**
     * 私人维护不产生管理员授权。
     *
     * @return 恒 false 副作用示例：不授予组织写入、库存或财务权限。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 公共写入前覆盖可信归属。
     *
     * @param writeIn 内部参数，例如 {tenantId:1,ownerUserId:1} 返回示例：无正常返回；通用写入抛
     *     POSTING_GENERIC_WRITE_DISABLED。 异常示例：失效账号或通用写入均拒绝，不执行 SQL。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam writeIn) {
        accessService.requireDraftActor();
        throw new com.sp.selplat.common.exception.CommonBusinessException(
                "POSTING_GENERIC_WRITE_DISABLED", "过账记录只能由具名原子流程写入，禁止通用 CRUD 修改。");
    }

    /**
     * 在 CRM 具名事务内委托公共 insertBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult insertBatch(CommonBatchParam writeIn) {
        return super.insertBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 updateBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult updateBatch(CommonBatchParam writeIn) {
        return super.updateBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 deleteBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult deleteBatch(CommonBatchParam writeIn) {
        return super.deleteBatch(writeIn);
    }

    // 三个隔离条件同时满足才允许内部过账；HTTP登录不授予写权限。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmPostingWriteEnabled")
    private Boolean postingWriteEnabled;

    /**
     * 参数绑定真实身份；输入例如{id:101}；返回独立公共参数；生产门禁拒绝，不写库。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：参数绑定真实身份；输入例如{id:101}；返回独立公共参数；生产门禁拒绝，不写库。
     * @return 独立公共参数
     */
    private CommonParam bound(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.enabled(postingWriteEnabled);
        CommonParam result =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(
                        input.getParamMap());
        CrmDraftScopeSupport.applyActor(result, accessService.requireDraftActor());
        return result;
    }

    /**
     * 本表原子流程扩展 findOriginal，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public java.util.Map<String, Object> findOriginal(CommonParam input) {
        return getDao().findOriginal(bound(input));
    }

    /**
     * 本表原子流程扩展 appendEntry，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public Long appendEntry(CommonParam input) {
        CommonParam scoped = bound(input);
        Long id = getSequence().get("id");
        scoped.putParam("id", id);
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.changed(
                getDao().appendEntry(scoped));
        return id;
    }

    /**
     * 来源原流水计数；输入例如sourceDocumentId101；返回真实数量；门禁拒绝，不修改流水。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：来源原流水计数；输入例如sourceDocumentId101；返回真实数量；门禁拒绝，不修改流水。
     * @return 真实数量
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long countSourcePosts(CommonParam input) {
        return getDao().countSourcePosts(bound(input));
    }
}
