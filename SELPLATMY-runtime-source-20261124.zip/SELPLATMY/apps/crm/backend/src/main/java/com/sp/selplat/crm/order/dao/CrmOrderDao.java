/** CrmOrder：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.order.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表强类型DAO，只固定参数化本表SQL。 */
public interface CrmOrderDao extends BaseDao {
    /**
     * 锁本组织实际行；scope92/901/id600000；返回行或null，要求CRM事务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：锁本组织实际行；scope92/901/id600000；返回行或null，要求CRM事务。
     * @return 行或null，要求CRM事务
     */
    Map<String, Object> lockScoped(CommonParam input);

    /**
     * DRAFT头CAS；id600000/expected0；返回0或1，不覆盖已提交状态。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：DRAFT头CAS；id600000/expected0；返回0或1，不覆盖已提交状态。
     * @return 0或1，不覆盖已提交状态
     */
    int updateDraft(CommonParam input);

    /**
     * 状态与版本CAS；id600000/expected0/DRAFT→SUBMITTED；返回0/1，要求CRM事务。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：状态与版本CAS；id600000/expected0/DRAFT→SUBMITTED；返回0/1，要求CRM事务。
     * @return 0/1，要求CRM事务
     */
    int transition(CommonParam input);
}
