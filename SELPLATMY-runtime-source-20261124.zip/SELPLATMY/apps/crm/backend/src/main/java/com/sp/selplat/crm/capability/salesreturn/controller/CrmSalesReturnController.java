/** 一期销售退货退款原明细读取HTTP；2026-10-04，Codex；无新增写入口或权限。 */
package com.sp.selplat.crm.capability.salesreturn.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.capability.salesreturn.service.CrmSalesReturnService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** HTTP只转交实际同来源引用读取；写仍复用既有库存资金v2协议。 */
@RestController
public class CrmSalesReturnController {
    // 真实owning读取聚合能力，不直接连接数据库或提供默认身份。
    private final CrmSalesReturnService service;

    /**
     * 绑定真实读取能力，构造不读取文件、凭据或业务数据。
     *
     * @param service 实际CrmSalesReturnService，例如同来源库存原明细读取服务
     */
    public CrmSalesReturnController(CrmSalesReturnService service) {
        this.service = service;
    }

    /**
     * 读取实际原明细及剩余额度，真实权限与有效性每次重新检查。
     *
     * @param input org901/order600000/source600001/capacityKind ISSUE_RETURN/page1
     * @return 公共JSON，例如success true/data含真实Grid items1300000/remainingQuantity2
     */
    @GetMapping("/api/crm/sales-return/references.htm")
    public String references(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.references(input));
    }
}
