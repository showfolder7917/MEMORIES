/** CrmPartnerDaoImpl.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
/* 2026-10-28：客户归档与原业务启停分离，保留原资料、请求和历史。 */
package com.sp.selplat.crm.partner.dao;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.persistence.CrmBaseDao;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表固定参数化SQL，CRUD/号段复用公共DAO，数据库约束保护同组织关系。 */
@Repository
public class CrmPartnerDaoImpl extends CrmBaseDao implements CrmPartnerDao {
    /**
     * 保留默认sortnum主排序，以组织内唯一id稳定读取同值页，不改变客户角色或关联范围。
     *
     * @param conditions 原服务可信条件，例如tenantId=92/businessOrgId=901/status=1
     * @param pageNo 实际页码，例如2
     * @param pageSize 实际页长，例如1
     * @return 公共真实页，例如totalCount=2/pageNo=2/records含第二条本组织记录
     *     异常或副作用示例：公共查询异常沿用原合同；不写客户、联系人或号段。
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            Map<String, Object> conditions, Integer pageNo, Integer pageSize) {
        return super.getPageList(conditions, "sortnum desc id asc", pageNo, pageSize);
    }

    // 与公共模板共用CRM池及真实事务，不打开独立连接。
    private final JdbcTemplate jdbc;

    /**
     * 绑定模板；参数例如crmJdbcTemplate；构造不执行SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmPartnerDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 锁本表；参数例如tenant92/org901/id200000；返回真实行或null；无实际CRM事务拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @Override
    public Map<String, Object> lockScoped(CommonParam p) {
        requireCrmTransaction();
    var rows =
        jdbc.queryForList(
            "SELECT * FROM CrmPartner WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1"
                + " FOR UPDATE",
            p.getParam("tenantId"),
            p.getParam("businessOrgId"),
            p.getParam("id"));
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * CAS更新；参数含id200000/version0和已校验业务字段；返回影响行数；0行不覆盖其他版本。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     *     业务示例：组织901、合成账号9211、记录200000；失败遵循上文拒绝/回滚规则。
     * @return 实际影响行数，例如1；0代表未覆盖任何版本
     */
    @Override
    public int updateVersion(CommonParam p) {
        requireCrmTransaction();
    return jdbc.update(
        "UPDATE CrmPartner SET partnerKind=?,partnerName=?,customerRole=?,"
            + "supplierRole=?,receiverName=?,mobile=?,address=?,email=?,businessState=?,"
            + "updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP,"
            + "versionNo=versionNo+1 WHERE tenantId=? AND businessOrgId=? AND id=? AND "
            + "status=1 AND versionNo=?",
        p.getParam("partnerKind"),
        p.getParam("partnerName"),
        p.getParam("customerRole"),
        p.getParam("supplierRole"),
        p.getParam("receiverName"),
        p.getParam("mobile"),
        p.getParam("address"),
        p.getParam("email"),
        p.getParam("businessState"),
        p.getParam("actorUserId"),
        p.getParam("actorUserId"),
        p.getParam("tenantId"),
        p.getParam("businessOrgId"),
        p.getParam("id"),
        p.getParam("expectedVersion"));
    }

  /**
   * 方法作用：一次参数化查询当前页的客户名称，租户和组织在SQL中限定。
   *
   * @param tenant 真实范围租户，例如9
   * @param organization 真实范围组织，例如901
   * @param ids 所有者校验后的主键，例如[600000]，空集合不发SQL
   * @return 真实示例：限定本组织的安全投影；不含联系资料、金额或审计正文
   * @throws IllegalArgumentException 超过100项时拒绝，无写入或锁副作用
   */
  @Override
  public java.util.List<java.util.Map<String, Object>> orderListNames(
      long tenant, long organization, java.util.List<Long> ids) {
    if (ids.isEmpty()) {
      return java.util.List.of();
    }
    if (ids.size() > 100) {
      throw new IllegalArgumentException("Order list page limit exceeded");
    }
    // 占位符数量只来自有界集合，实际值全部绑定，不拼接用户主键。
    var placeholders = String.join(",", java.util.Collections.nCopies(ids.size(), "?"));
    var arguments = new java.util.ArrayList<Object>();
    arguments.add(tenant);
    arguments.add(organization);
    arguments.addAll(ids);
    return jdbc.queryForList(
        "SELECT id,partnerName FROM CrmPartner WHERE tenantId=? AND businessOrgId=? AND status=1"
            + " AND id IN ("
            + placeholders
            + ") ORDER BY id",
        arguments.toArray());
  }
  /**
   * 方法作用：本表归档CAS只改变归档信息、版本和原操作审计列，不改联系人或业务状态。
   *
   * @param input 真实参数，例如tenant9/org901/id501/expectedVersion0/archivedFlag=true
   * @return 真实返回示例：1；0代表目标不符、旧版本或已处于目标状态，调用方整笔回滚。
   * @throws IllegalStateException 无本域事务时拒绝，在SQL执行前停止
   */
  @Override
  public int updateArchive(CommonParam input) {
    requireCrmTransaction();
    // 恢复只撤销归档标志，最近归档原因和操作者保留，历次原因另由原业务审计保存。
    boolean archived = Boolean.TRUE.equals(input.getParam("archivedFlag"));
    String change =
        archived
            ? "archivedFlag=TRUE,archiveReasonText=?,archivedByUserId=?,archivedAt=CURRENT_TIMESTAMP,"
            : "archivedFlag=FALSE,";
    var values = new java.util.ArrayList<Object>();
    if (archived) {
      values.add(input.getParam("reasonText"));
      values.add(input.getParam("actorUserId"));
    }
    values.add(input.getParam("actorUserId"));
    values.add(input.getParam("actorUserId"));
    values.add(input.getParam("tenantId"));
    values.add(input.getParam("businessOrgId"));
    values.add(input.getParam("id"));
    values.add(input.getParam("expectedVersion"));
    values.add(!archived);
    return jdbc.update(
        "UPDATE CrmPartner SET "
            + change
            + "updatedByUserId=?,lastOperateUserId=?,updatedAt=CURRENT_TIMESTAMP,versionNo=versionNo+1"
            + " WHERE tenantId=? AND businessOrgId=? AND id=? AND status=1 AND versionNo=? AND"
            + " archivedFlag=?",
        values.toArray());
  }
}
