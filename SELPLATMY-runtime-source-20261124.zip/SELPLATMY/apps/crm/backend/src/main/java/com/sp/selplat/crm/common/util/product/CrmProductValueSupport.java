/* 商品基础资料严格规范；2026-10-14，Codex。 */
package com.sp.selplat.crm.common.util.product;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** 只规范商品候选和精确金额，不持有身份、连接或激活状态。 */
public final class CrmProductValueSupport {
    /** 禁止构造；副作用示例：不产生商品或付款。 */
    private CrmProductValueSupport() { }

    /**
     * 规范完整商品保存白名单，金额仅接受文本。
     * @param input 候选，例如org901/codeBOOK-001/salePrice12.50/requestKeyp1
     * @return 实际示例：productCode=BOOK-001、salePriceMinor=1250L的独立CommonParam
     * @throws com.sp.selplat.common.exception.CommonBusinessException 非法金额、客户端身份或套餐组合拒绝
     */
    public static CommonParam normalize(CommonParam input) {
        Set<String> allowed = Set.of("organizationCandidateId", "id", "expectedVersion", "requestKey",
                "productCode", "productName", "specification", "productKind", "unitCode", "purchasePrice",
                "salePrice", "businessState", "termUnit", "termCount", "renewalMode", "activationSystemCode");
        // 未知身份和库存字段不得通过通用DAO成为可信值。
        if (input == null || !allowed.containsAll(input.getParamMap().keySet())) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT");
        }
        var p = new CommonParam();
        p.putParam("organizationCandidateId", CrmPartnerValueSupport.positive(input.getParam("organizationCandidateId")));
        String key = CrmPartnerValueSupport.text(input.getParam("requestKey"), 64, true);
        if (!key.matches("[A-Za-z0-9_.:-]+")) { throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT"); }
        p.putParam("requestKey", key);
        if (input.getParam("id") != null) {
            p.putParam("id", CrmPartnerValueSupport.positive(input.getParam("id")));
            p.putParam("expectedVersion", CrmPartnerValueSupport.version(input.getParam("expectedVersion")));
        } else if (input.getParam("expectedVersion") != null) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_VERSION");
        }
        // 编码统一大写；数据库组织唯一键负责并发冲突。
        String code = CrmPartnerValueSupport.text(input.getParam("productCode"), 64, true).toUpperCase(Locale.ROOT);
        if (!code.matches("[A-Z0-9][A-Z0-9_.-]{0,63}")) { throw CrmPartnerValueSupport.failure("INVALID_CRM_PRODUCT_CODE"); }
        p.putParam("productCode", code);
        p.putParam("productName", CrmPartnerValueSupport.text(input.getParam("productName"), 200, true));
        p.putParam("specification", CrmPartnerValueSupport.text(input.getParam("specification"), 200, false));
        String kind = enumeration(input, "productKind", Set.of("GOODS", "SERVICE"));
        p.putParam("productKind", kind);
        p.putParam("unitCode", enumeration(input, "unitCode", Set.of("EA")));
        p.putParam("businessState", enumeration(input, "businessState", Set.of("ACTIVE", "INACTIVE")));
        p.putParam("purchasePriceMinor", money(input.getParam("purchasePrice")));
        p.putParam("salePriceMinor", money(input.getParam("salePrice")));
        String term = enumeration(input, "termUnit", Set.of("NONE", "DAY", "MONTH", "YEAR"));
        String renewal = enumeration(input, "renewalMode", Set.of("NONE", "MANUAL", "AUTO"));
        long count = CrmPartnerValueSupport.version(input.getParam("termCount"));
        String target = CrmPartnerValueSupport.text(input.getParam("activationSystemCode"), 64, false);
        if (target != null && !target.matches("[A-Z][A-Z0-9_]{0,63}")) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_ACTIVATION_SYSTEM");
        }
        // 实物不定义服务期限；自动续订标识不授予代扣或开通权限。
        if (count > 120 || ("NONE".equals(term) ? count != 0 || !"NONE".equals(renewal)
                : !"SERVICE".equals(kind) || count == 0 || "NONE".equals(renewal))
                || ("GOODS".equals(kind) && target != null)) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_PRODUCT_TERM");
        }
        p.putParam("termUnit", term); p.putParam("termCount", (int) count);
        p.putParam("renewalMode", renewal); p.putParam("activationSystemCode", target);
        return p;
    }

    /**
     * 校验固定商品枚举，不提供默认启用。
     * @param input 商品候选，例如productKind=SERVICE
     * @param field 固定字段，例如productKind
     * @param values 允许值，例如GOODS/SERVICE
     * @return 实际示例：SERVICE
     * @throws com.sp.selplat.common.exception.CommonBusinessException 未知或缺字段拒绝
     */
    private static String enumeration(CommonParam input, String field, Set<String> values) {
        String value = CrmPartnerValueSupport.text(input.getParam(field), 20, true);
        if (!values.contains(value)) { throw CrmPartnerValueSupport.failure("INVALID_CRM_INPUT"); }
        return value;
    }

    /**
     * 将CNY两位金额文本精确转换为分。
     * @param input 原金额文本，例如12.50
     * @return 实际示例：1250L；最大999999999999L
     * @throws com.sp.selplat.common.exception.CommonBusinessException 超界、浮点JSON或多位小数拒绝
     */
    private static long money(Object input) {
        if (!(input instanceof String text) || !text.matches("(?:0|[1-9][0-9]{0,9})(?:[.][0-9]{1,2})?")) {
            throw CrmPartnerValueSupport.failure("INVALID_CRM_PRODUCT_PRICE");
        }
        long value = new BigDecimal(text).movePointRight(2).longValueExact();
        if (value > 999999999999L) { throw CrmPartnerValueSupport.failure("INVALID_CRM_PRODUCT_PRICE"); }
        return value;
    }

    /**
     * 商品浏览器精确文本映射，价格不变成二进制浮点。
     * @param source 真实行，例如id700000/versionNo0/salePriceMinor1250
     * @return 实际示例：id=700000、versionNo=0、salePrice=12.50均为String
     * 副作用示例：只复制本次结果，不修改历史订单或开通服务。
     */
    public static Map<String, Object> browser(Map<String, Object> source) {
        Map<String, Object> row = new LinkedHashMap<>(source);
        for (String field : Set.of("id", "tenantId", "businessOrgId", "versionNo", "createdByUserId",
                "updatedByUserId", "lastOperateUserId", "purchasePriceMinor", "salePriceMinor")) {
            if (row.get(field) != null) { row.put(field, row.get(field).toString()); }
        }
        for (String side : Set.of("purchase", "sale")) {
            if (source.get(side + "PriceMinor") != null) {
                row.put(side + "Price", new BigDecimal(source.get(side + "PriceMinor").toString()).movePointLeft(2).setScale(2).toPlainString());
            }
        }
        return row;
    }
}
