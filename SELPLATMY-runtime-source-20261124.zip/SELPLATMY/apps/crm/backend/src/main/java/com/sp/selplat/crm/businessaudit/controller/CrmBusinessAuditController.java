/**
 * CrmBusinessAuditController.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。
 */
/* 2026-10-28：补原业务审计只读页面合同，复用原范围和动作，不新增写入。 */
package com.sp.selplat.crm.businessaudit.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.crm.businessaudit.service.CrmBusinessAuditService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 本表只读审计入口，不暴露通用写或清除请求。 */
@RestController
@RequestMapping("/api/crm/businessaudit")
public class CrmBusinessAuditController {
    // owning服务逐请求回查真实身份及审计read许可。
    private final CrmBusinessAuditService service;

    /**
     * 装配；参数例如CrmBusinessAuditServiceImpl；构造不查询SQL。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmBusinessAuditController(CrmBusinessAuditService service) {
        this.service = service;
    }

  /**
   * 方法作用：只序列化原Service已核组织资格的只读工作区结果。
   *
   * @param input HTTP组织与分页候选，例如organizationCandidateId901/pageNo2/resourceId503
   * @return 真实示例：CommonResult的data.grid为当前审计页，readOnlytrue。 异常或副作用示例：缺审计读取资格沿原业务异常；控制器不补身份或数据。
   */
  @GetMapping("workspace.htm")
  public String workspace(com.sp.selplat.common.util.CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(service.workspace(input));
  }

    /**
     * 范围内读取；输入例如org901/id200000；返回公共记录；跨组织或缺审计read拒绝。
     *
     * @param p 本表业务/复合范围参数，例如tenantId=92、businessOrgId=901、id=200000；SQL采用占位符
     * @return 本表真实结果，例如id=200000的记录/首次结果；不存在时返回null或按上文规则拒绝
     */
    @GetMapping("getById.htm")
    public String getById(CommonParam p) {
        return JsonUtils.toJsonIgnoreNull(service.getById(p));
    }
}
