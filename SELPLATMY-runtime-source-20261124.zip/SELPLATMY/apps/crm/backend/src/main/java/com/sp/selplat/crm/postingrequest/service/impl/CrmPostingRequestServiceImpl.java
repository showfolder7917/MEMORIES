/** 修改记录：2026-10-09，私人批读沿用有效记录边界，不开放新的写路由。 */
/** CrmPostingRequestServiceImpl.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingrequest.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.draft.CrmDraftScopeSupport;
import com.sp.selplat.crm.postingrequest.dao.CrmPostingRequestDao;
import com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

/** 本表服务直接复用公共 CRUD；仅预处理私人归属、校验和本域事务。 */
@Service
public class CrmPostingRequestServiceImpl extends BaseServiceImpl<CrmPostingRequestDao>
        implements CrmPostingRequestService {
    // 准入能力从真实 Uniauth 回查身份，字段不由客户端提供。
    // 既有真实Session准入，不生成默认操作者。
    private final CrmAccessService accessService;

    // 只允许本表真实搜索字段，不允许请求传入租户或 owner 操作符。
    private static final Set<String> SEARCH_FIELDS = Set.of();

    /**
     * 装配真实准入能力；DAO 由公共泛型绑定。
     *
     * @param accessService 本域准入服务，例如 CrmAccessServiceImpl 副作用示例：构造不建立 Session、不查询 SQL、不授予管理员权限。
     */
    public CrmPostingRequestServiceImpl(CrmAccessService accessService) {
        this.accessService = accessService;
    }

    /**
     * 查询本人有效记录的公共分页。
     *
     * @param queryIn 标准参数，例如 {pageNo:1,pageSize:20}
     * @return 公共页，例如 {records:[],totalCount:0,pageNo:1,pageSize:20} 异常示例：无真实账号或正数归属时拒绝，不执行无范围 SQL。
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam queryIn) {
        CommonPageParam scoped =
                CrmDraftScopeSupport.scopeStore(
                        queryIn, accessService.requireDraftActor(), SEARCH_FIELDS);
        return super.getStore(scoped);
    }

    /**
     * 委托公共精确复合主键读取本人记录。
     *
     * @param queryIn 参数，例如 {id:100001,tenantId:1}
     * @return 公共结果，例如 {success:true,data:{id:100001,status:1}} 异常示例：非法 ID、其他 owner/tenant
     *     和删除记录均拒绝；不写库。
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam queryIn) {
        CommonParam scoped =
                CrmDraftScopeSupport.scopeDetail(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.requireActive(super.getById(scoped));
    }

    /**
     * 批量读取公共精确主键，空输入保持空批次，软删除记录不返回。
     *
     * @param queryIn 参数，例如 items=[{id:100001}] 或 []
     * @return 公共批量结果，例如 {success:true,data:[]} 异常示例：非法身份或 ID 拒绝；不会退化为分页查询。
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam queryIn) {
        CommonBatchParam scoped =
                CrmDraftScopeSupport.scopeBatch(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.activeBatch(super.getByIds(scoped));
    }

    /**
     * 取得真实审计操作员。
     *
     * @return 当前账号主键，例如 9211L；无默认操作员 异常示例：账号失效时沿用统一身份拒绝，不访问本表 SQL。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return accessService.requireDraftActor().get("ownerUserId");
    }

    /**
     * 取得真实租户。
     *
     * @return 当前租户，例如 92L；无默认租户 异常示例：归属无效时拒绝，不接收客户端身份。
     */
    @Override
    protected Long getCurrentTenantId() {
        return accessService.requireDraftActor().get("tenantId");
    }

    /**
     * 私人维护不产生管理员授权。
     *
     * @return 恒 false 副作用示例：不授予组织写入、库存或财务权限。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 公共写入前覆盖可信归属。
     *
     * @param writeIn 内部参数，例如 {tenantId:1,ownerUserId:1} 返回示例：无正常返回；通用写入抛
     *     POSTING_GENERIC_WRITE_DISABLED。 异常示例：失效账号或通用写入均拒绝，不执行 SQL。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam writeIn) {
        accessService.requireDraftActor();
        throw new com.sp.selplat.common.exception.CommonBusinessException(
                "POSTING_GENERIC_WRITE_DISABLED", "过账记录只能由具名原子流程写入，禁止通用 CRUD 修改。");
    }

    /**
     * 在 CRM 具名事务内委托公共 insertBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult insertBatch(CommonBatchParam writeIn) {
        return super.insertBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 updateBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult updateBatch(CommonBatchParam writeIn) {
        return super.updateBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 deleteBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult deleteBatch(CommonBatchParam writeIn) {
        return super.deleteBatch(writeIn);
    }

    // 三个隔离条件同时满足才允许内部过账；HTTP登录不授予写权限。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmPostingWriteEnabled")
    private Boolean postingWriteEnabled;

    /**
     * 私人隔离请求仅在已有写开关下绑定真实Session，不建立默认租户。
     *
     * @param input 内部请求候选，例如id101/requestKeyk1
     * @return 独立CommonParam，tenant92/owner9211来自Session；缺门禁拒绝，无SQL副作用
     */
    private CommonParam bound(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.enabled(postingWriteEnabled);
        CommonParam result =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(
                        input.getParamMap());
        CrmDraftScopeSupport.applyActor(result, accessService.requireDraftActor());
        return result;
    }

    /**
     * 私人隔离过账请求只在当前CRM事务唯一占位。
     *
     * @param input 内部document101/actionPOST/requestKeyk1，可信身份重新绑定
     * @return 实际新请求id，例如100001；公共号段允许失败后空号
     * @throws com.sp.selplat.common.exception.CommonBusinessException
     *     同范围同键已存在时POSTING_REQUEST_EXISTS，必须退出失败事务后读取首次结果
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public Long claimRequest(CommonParam input) {
        CommonParam scoped = bound(input);
        Long id = getSequence().get("id");
        scoped.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.changed(
                    getDao().claimRequest(scoped));
        } catch (org.springframework.dao.DuplicateKeyException conflict) {
            // 仅请求唯一冲突进入新事务重放；流水和余额错误不能吞掉。
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "POSTING_REQUEST_EXISTS", "请求已存在，当前事务必须先回滚。", conflict);
        }
        return id;
    }

    /**
     * 私人隔离请求同事务完成首次响应，不能独立提交部分过账。
     *
     * @param input 内部实际request100001/resultEntry100002，Session重新核归属
     *     异常或副作用示例：OPEN→COMPLETED恰好一行；缺门禁、旧版本或零CAS使整笔回滚。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public void completeRequest(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.changed(
                getDao().completeRequest(bound(input)));
    }

    /**
     * 本表原子流程扩展 readCommittedRequest，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            readOnly = true,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public java.util.Map<String, Object> readCommittedRequest(CommonParam input) {
        return getDao().findRequest(bound(input));
    }

    /**
     * V2同事务唯一claim。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long claimOrganization(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.post");
        var row = new CommonParam();
        for (String f : java.util.List.of("documentId", "requestKey", "payloadHash")) {
            row.putParam(f, input.getParam(f));
        }
        row.putParam("action", "POST");
        row.putParam("requestState", "OPEN");
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("requestKey", input.getParam("requestKey"));
        long id = getSequence().get("id");
        row.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                    getDao().insert(row));
        } catch (org.springframework.dao.DuplicateKeyException failure) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "CRM_COMMAND_EXISTS", "过账请求已存在，先退出失败事务。", failure);
        }
        return id;
    }

    /**
     * 库存请求在当前CRM事务完成真实完整批次快照。
     *
     * @param input org901/request100001/resultBatch1200000/responseSnapshot及服务器实际版本
     *     异常或副作用示例：当前OPEN→COMPLETED；范围失效或CAS0使全部库存、流水和请求回滚。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public void completeOrganization(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.post");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                getDao().completeOrganization(p));
    }

    /**
     * 失败事务退出后取V2首次结果。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            readOnly = true)
    public java.util.Map<String, Object> committedOrganization(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.post");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        return getDao().findOrganization(p);
    }

    /**
     * V2同事务唯一claim。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long claimOrganizationFunds(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.post");
        var row = new CommonParam();
        for (String f : java.util.List.of("documentId", "requestKey", "payloadHash")) {
            row.putParam(f, input.getParam(f));
        }
        row.putParam("action", "POST");
        row.putParam("requestState", "OPEN");
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("requestKey", input.getParam("requestKey"));
        long id = getSequence().get("id");
        row.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                    getDao().insert(row));
        } catch (org.springframework.dao.DuplicateKeyException failure) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "CRM_COMMAND_EXISTS", "过账请求已存在，先退出失败事务。", failure);
        }
        return id;
    }

    /**
     * 收款或采购付款在当前CRM事务完成真实完整批次快照。
     *
     * @param input org901/request100001/resultBatch1200000及完整responseSnapshot
     *     异常或副作用示例：OPEN→COMPLETED；缺funds.post、末尾SQL失败或CAS0使现金和请求全回滚。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public void completeOrganizationFunds(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.post");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                getDao().completeOrganization(p));
    }

    /**
     * 失败事务退出后取V2首次结果。
     *
     * @param input org901及实际服务器字段，例如id1000000/version0/quantity2
     * @return 实际本表结果；缺真实许可/范围/事务拒绝
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            readOnly = true)
    public java.util.Map<String, Object> committedOrganizationFunds(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.post");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        return getDao().findOrganization(p);
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long claimOrganizationFundsReverse(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var row = new CommonParam();
        for (String f : java.util.List.of("documentId", "requestKey", "payloadHash")) {
            row.putParam(f, input.getParam(f));
        }
        row.putParam("action", "REVERSE");
        row.putParam("requestState", "OPEN");
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("requestKey", input.getParam("requestKey"));
        long id = getSequence().get("id");
        row.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                    getDao().insert(row));
        } catch (org.springframework.dao.DuplicateKeyException failure) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "CRM_COMMAND_EXISTS", "过账请求已存在，先退出失败事务。", failure);
        }
        return id;
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public void completeOrganizationFundsReverse(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                getDao().completeFundsReverse(p));
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            readOnly = true)
    public java.util.Map<String, Object> committedOrganizationFundsReverse(CommonParam input) {
        var scope =
                accessService.requireFundsScope(
                        input.getParam("organizationCandidateId"), "crm.funds.reverse");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        return getDao().findFundsReverse(p);
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public Long claimOrganizationStockReverse(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var row = new CommonParam();
        for (String f : java.util.List.of("documentId", "requestKey", "payloadHash")) {
            row.putParam(f, input.getParam(f));
        }
        row.putParam("action", "REVERSE");
        row.putParam("requestState", "OPEN");
        row = com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.entity(row, scope);
        row.getParamMap().remove("versionNo");
        row.putParam("requestKey", input.getParam("requestKey"));
        long id = getSequence().get("id");
        row.putParam("id", id);
        try {
            com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                    getDao().insert(row));
        } catch (org.springframework.dao.DuplicateKeyException failure) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "CRM_COMMAND_EXISTS", "过账请求已存在，先退出失败事务。", failure);
        }
        return id;
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     *     异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public void completeOrganizationStockReverse(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport.changed(
                getDao().completeFundsReverse(p));
    }

    /**
     * 方法作用：冲正同事务唯一claim、完成或失败事务退出后的首次快照读取。
     *
     * @param input org901/document1000000/keyr1/hash及实际结果
     * @return 真实请求id或已提交首次结果，冲突退出失败事务 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
     */
    @Override
    @com.sp.selplat.common.service.logging.OperationLog
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            readOnly = true)
    public java.util.Map<String, Object> committedOrganizationStockReverse(CommonParam input) {
        var scope =
                accessService.requireStockScope(
                        input.getParam("organizationCandidateId"), "crm.stock.reverse");
        var p =
                com.sp.selplat.crm.common.util.stock.CrmStockValueSupport.param(
                        input.getParamMap());
        p.putParam("tenantId", scope.get("tenantId"));
        p.putParam("businessOrgId", scope.get("businessOrgId"));
        return getDao().findFundsReverse(p);
    }
}
