/* 客户稳定编号关系公开合同；2026-10-28。 */
package com.sp.selplat.crm.customerrelation.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonResult;

/** 关系说明可自定义，不固定家长孩子分类，不构成身份、监护权或系统权限。 */
public interface CrmCustomerRelationService extends BaseService {
    /**
     * 方法作用：读取当前客户发出和收到的同一关系分页。
     * @param input 页面候选，例如org901/partnerId200000/pageNo1/pageSize20
     * @return 真实返回示例：data.partner为原客户，data.page.records含两个孩子的客户编号。
     * 异常或副作用示例：无原客户读取资格拒绝；不创建反向关系。
     */
    CommonResult page(CommonPageParam input);

    /**
     * 方法作用：准备明确两端原客户及关系当前版本。
     * @param input 页面候选，例如org901/partnerId200000/relatedPartnerId200001
     * @return 真实返回示例：data.partner.versionNo="0"、relatedPartner.id="200001"、relation.versionNo="0"。
     * 异常或副作用示例：越租户、自关联或不可见原客户拒绝。
     */
    CommonResult read(CommonParam input);

    /**
     * 方法作用：保存一对明确客户的关系说明和启停，追加审计并支持原请求重放。
     * @param input 原版本候选，例如两端版本0/关系版本0/relationName孩子/enabledFlag=true
     * @return 真实返回示例：data.id="100000"/versionNo="1"/replay=false。
     * 异常或副作用示例：旧版本、重复键异正文或失效客户启用拒绝；不修改原客户或教学资料。
     */
    CommonResult save(CommonParam input);
}
