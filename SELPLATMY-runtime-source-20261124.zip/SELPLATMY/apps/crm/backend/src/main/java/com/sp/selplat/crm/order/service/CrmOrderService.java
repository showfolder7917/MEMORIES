/** CrmOrder：本域订单隔离小步；2026-10-03，Codex；不开放生产授权。 */
package com.sp.selplat.crm.order.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

import java.util.Map;

/** 本表owning接口，不暴露通用无版本业务写。 */
public interface CrmOrderService extends BaseService {
    /**
     * 仅行owning服务内部回查真实DRAFT头，不能借内部全量替换绕过已审核不可改。
     *
     * @param input org901/orderId600000/headerVersion0，版本由订单保存事务给出
     * @return 实际已持锁DRAFT头，版本必须匹配；缺真实范围/状态拒绝，要求CRM事务
     */
    Map<String, Object> requireDraftForLines(CommonParam input);

    /**
     * 聚合本组织真实订单和客户商品分页，不创建记录。
     *
     * @param input org901/page1/langzh-CN
     * @return 包含实际orders/partners/products与SELUI定义的CommonResult；缺order.read拒绝
     */
    CommonResult workspace(CommonPageParam input);

    /**
     * 原子保存全量订单头行，采购要求实际供应商角色。
     *
     * @param input org901/PURCHASE/partner501/keyp1及完整lines
     * @return 示例DRAFT/id600000/version0及精确最小单位头行；非法来源整笔回滚
     */
    CommonResult saveDraft(CommonParam input);

    /**
     * 提交实际草稿，不改变库存和现金。
     *
     * @param input org901/id600000/expectedVersion0/requestKeyp1
     * @return 示例SUBMITTED/version1；旧版本和错误状态拒绝
     */
    CommonResult submit(CommonParam input);

    /**
     * 不同审核人冻结实际头行定价和来源版本。
     *
     * @param input org901/id600000/expectedVersion1/requestKeyp2
     * @return 示例APPROVED/version2及冻结正文；提交人自审整笔拒绝
     */
    CommonResult approve(CommonParam input);

    /**
     * 方法作用：原提交人撤回尚未审核订单到草稿，保留原行和提交历史，不动资金或库存。
     * @param input 原页面候选，例如organizationCandidateId901/id600000/expectedVersion1/requestKeywithdraw1
     * @return 真实示例：data.id600000/orderStateDRAFT/versionNo2/replayfalse。
     * 异常或副作用示例：非原提交人、已审核、旧版本或失去order.write时整笔拒绝。
     */
    CommonResult withdraw(CommonParam input);

    /**
     * 方法作用：独立审核人驳回待审订单到草稿，原因与审计同事务保留。
     * @param input 真实示例：organizationCandidateId901/id600000/expectedVersion1/requestKeyreject1/reasonText核对订购数量
     * @return 真实示例：data.id600000/orderStateDRAFT/versionNo2，原键重放replaytrue。
     * 异常或副作用示例：本人提交、缺审核资格、空原因或已审核拒绝；不动资金库存课时。
     */
    CommonResult reject(CommonParam input);



    /**
     * 持锁读取审核销售来源供库存owning流程，非HTTP。
     *
     * @param input org901/id600000
     * @param action 固定stock.write/submit/approve/post/read
     * @return 实际审核头和全部行；冻结/hash/来源不符时拒绝
     */
    java.util.Map<String, Object> lockApprovedForStock(
            com.sp.selplat.common.util.CommonParam input, String action);

    /**
     * 库存owning聚合器选择真实审核销售，不借客户/order.write许可。
     *
     * @param input org901/page1
     * @return 审核SALES真实公共分页，缺stock.read拒绝
     */
    com.sp.selplat.common.util.CommonPageResult approvedSalesForStock(
            com.sp.selplat.common.util.CommonPageParam input);

    /**
     * Actual approved sales list for the receipt scope.
     *
     * @param input e.g. org901/page1
     * @return real approved orders, no paid status mutation
     */
    CommonPageResult approvedSalesForFunds(CommonPageParam input);

    /**
     * 锁定已审核采购来源，供库存owning事务使用。
     *
     * @param input org901/id600000
     * @param action 固定crm.stock.write等库存动作
     * @return 实际APPROVED PURCHASE头和全部冻结行；错误来源/许可/快照拒绝，无余额副作用
     */
    java.util.Map<String, Object> lockApprovedPurchaseForStock(CommonParam input, String action);

    /**
     * 库存页面选择真实审核采购来源，缺stock.read拒绝。
     *
     * @param input org901/page1
     * @return 实际APPROVED PURCHASE分页，无订单、库存或资金写入
     */
    CommonPageResult approvedPurchaseForStock(CommonPageParam input);

    /**
     * 实际审核采购付款来源锁定。
     *
     * @param input org901/id600000
     * @param action 固定funds.post等，不允许reverse
     * @return 实际PURCHASE冻结头及全部行；无付款或权限扩展
     */
    java.util.Map<String, Object> lockApprovedPurchaseForFunds(
            com.sp.selplat.common.util.CommonParam input, String action);

    /**
     * 实际审核采购选择器。
     *
     * @param input org901/page1
     * @return 实际APPROVED PURCHASE分页，无写入
     */
    com.sp.selplat.common.util.CommonPageResult approvedPurchaseForFunds(
            com.sp.selplat.common.util.CommonPageParam input);

    /**
     * 方法作用：在调用方CRM事务内锁定真实订单与版本，仅支持附件引用，不更新冻结正文。
     *
     * @param input 实际org901/id600000/expectedVersion2；身份和动作由服务端回查
     * @return 实际范围内订单头，例如APPROVED/version2；不更新金额或数量 异常或副作用示例：无事务、越范围或版本改变拒绝，外层关联事务全部回滚。
     */
    Map<String, Object> lockForAttachment(CommonParam input);
}
