/** CrmPostingEntryDaoImpl.java：固定参数化 SQL 只访问本表，绑定 CRM 事务连接。 */
package com.sp.selplat.crm.postingentry.dao;

import com.sp.selplat.crm.common.persistence.CrmBaseDao;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/** 本表锁定读、条件更新及唯一约束由数据库协调，不依赖进程内锁。 */
@Repository
public class CrmPostingEntryDaoImpl extends CrmBaseDao implements CrmPostingEntryDao {
    // 与公共 MyBatis 使用同一个 crmDataSource，不自行建立连接池。
    private final JdbcTemplate jdbc;

    /**
     * 绑定本域 SQL 模板；传参例如 crmJdbcTemplate；返回实例；构造不执行 SQL。
     *
     * @param jdbc 固定限定名crmJdbcTemplate，例如本域实际数据库模板；构造不执行SQL。
     */
    public CrmPostingEntryDaoImpl(@Qualifier("crmJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /**
     * 精确读返回单行或null；输入例如一条CRM结果；不隐藏多行，不写库。
     *
     * @param rows 真实SQL结果列表，例如[{id:101}]；空列表表示未找到。
     * @return 唯一实际行Map；空列表返回null，多行拒绝，不丢弃重复结果
     * @throws IllegalStateException 实际状态不满足正文条件时拒绝；不继续SQL或构造默认记录
     */
    private java.util.Map<String, Object> first(
            java.util.List<java.util.Map<String, Object>> rows) {
        if (rows.size() > 1) {
            throw new IllegalStateException("Expected one CRM row");
        }
        return rows.isEmpty() ? null : rows.get(0);
    }

    /**
     * 本表固定 SQL 扩展 findOriginal；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 实际数据库行或null；不构造默认记录。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public java.util.Map<String, Object> findOriginal(
            com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return first(
                jdbc.queryForList(
                        "SELECT * FROM CrmPostingEntry WHERE tenantId=? AND ownerUserId=? AND documentId=? AND action='POST' AND status=1",
                        input.getParam("tenantId"),
                        input.getParam("ownerUserId"),
                        input.getParam("documentId")));
    }

    /**
     * 本表固定 SQL 扩展 appendEntry；不拼接表名、字段名或请求 SQL。
     *
     * @param input 例如 {id:101,tenantId:92,ownerUserId:9211,versionNo:0}
     * @return 影响行数0或1，0必须由服务抛异常回滚。 异常或副作用示例：约束/连接错误原样传播；锁与写操作仅在本域真实事务中执行。
     */
    @Override
    public int appendEntry(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.update(
                "INSERT INTO CrmPostingEntry (id,tenantId,ownerUserId,lastOperateUserId,"
                        + "documentId,sourceDocumentId,kind,action,originalEntryId,stockBalanceId,"
                        + "fundsBalanceId,warehouseId,productId,quantityUnit,quantityDelta,accountId,"
                        + "accountKind,currency,amountUnit,amountDelta) VALUES (?,?,?,?,?,?,?,?,?,?,?,"
                        + "?,?,?,?,?,?,?,?,?)",
                input.getParam("id"),
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("ownerUserId"),
                input.getParam("documentId"),
                input.getParam("sourceDocumentId"),
                input.getParam("kind"),
                input.getParam("action"),
                input.getParam("originalEntryId"),
                input.getParam("stockBalanceId"),
                input.getParam("fundsBalanceId"),
                input.getParam("warehouseId"),
                input.getParam("productId"),
                input.getParam("quantityUnit"),
                input.getParam("quantityDelta"),
                input.getParam("accountId"),
                input.getParam("accountKind"),
                input.getParam("currency"),
                input.getParam("amountUnit"),
                input.getParam("amountDelta"));
    }

    /**
     * 统计已存在原流水；输入例如sourceDocumentId101；返回0或正数量；须CRM事务，不写库。
     *
     * @param input 本方法声明的业务候选；示例与正文相同：统计已存在原流水；输入例如sourceDocumentId101；返回0或正数量；须CRM事务，不写库。
     * @return 0或正数量
     */
    @Override
    public Long countSourcePosts(com.sp.selplat.common.util.CommonParam input) {
        requireCrmTransaction();
        return jdbc.queryForObject(
                "SELECT COUNT(*) FROM CrmPostingEntry WHERE tenantId=? AND ownerUserId=? AND sourceDocumentId=? AND action='POST'",
                Long.class,
                input.getParam("tenantId"),
                input.getParam("ownerUserId"),
                input.getParam("sourceDocumentId"));
    }
}
