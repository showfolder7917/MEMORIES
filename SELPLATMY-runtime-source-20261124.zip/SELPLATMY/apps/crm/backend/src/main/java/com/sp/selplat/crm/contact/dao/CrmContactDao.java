/** CrmContactDao.java：CRM经营组织客户维护本表组件。 修改记录：2026-10-03，Codex 按V2.1实现隔离客户切片，生产许可未接通时拒绝。 */
package com.sp.selplat.crm.contact.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.Map;

/** 本表公共DAO及固定锁/CAS扩展，不能访问其他表。 */
public interface CrmContactDao extends BaseDao {
    /**
     * 锁当前组织记录；参数例如tenant92/org901/id200000；返回真实行或null；无CRM事务拒绝。
     *
     * @param p 本方法声明的业务候选；示例与正文相同：锁当前组织记录；参数例如tenant92/org901/id200000；返回真实行或null；无CRM事务拒绝。
     * @return 真实行或null
     */
    Map<String, Object> lockScoped(CommonParam p);

    /**
     * 按版本保存业务字段；参数例如id200000/version0；返回影响行数0/1；调用服务负责0行回滚。
     *
     * @param p 本方法声明的业务候选；示例与正文相同：按版本保存业务字段；参数例如id200000/version0；返回影响行数0/1；调用服务负责0行回滚。
     * @return 影响行数0/1
     */
    int updateVersion(CommonParam p);
}
