/** 一期退货退款原明细读取能力；2026-10-04，Codex；无数据库直连。 */
package com.sp.selplat.crm.capability.salesreturn.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonResult;

/** 只聚合实际同销售来源的已POST原明细和剩余额度；写仍走既有库存资金入口。 */
public interface CrmSalesReturnService {
    /**
     * 真实来源锁内选择有效原出库、收款或退货并独立分页。
     *
     * @param input org901/orderId600000/sourceOrderLineId600001/capacityKind
     *     ISSUE_RETURN/page1/langzh-CN
     * @return 实际公共Grid配置例如items原出库1300000/remainingQuantity2，REMOTE20行；越范围拒绝
     */
    CommonResult references(CommonPageParam input);
}
