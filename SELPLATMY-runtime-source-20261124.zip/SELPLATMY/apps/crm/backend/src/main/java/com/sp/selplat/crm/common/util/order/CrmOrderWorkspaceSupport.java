/** 订单公共SELUI聚合定义；2026-10-08，Codex；精确订单号公共Search配置，不授予许可。 */
/* 2026-10-28：原订单列表只读投影已开通学生，不创建开通、现金或授权。 */
package com.sp.selplat.crm.common.util.order;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.common.util.partner.CrmPartnerValueSupport;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 真实分页及服务端三语表单，订单数据库保持唯一事实源。 */
public final class CrmOrderWorkspaceSupport {

  /** 静态值规范或实际页面配置工具，构造不连接数据库、创建业务记录或授予权限。 */
  private CrmOrderWorkspaceSupport() {
    // 只提供静态工具，禁止持有会话或业务状态。
  }

  /**
   * 聚合工作区，输入实际分页/逐动作裁决；返回真实订单/客户/商品和公共表单配置。
   *
   * @param orders 实际本组织订单公共分页，例如page1/total1，不是前端假数组
   * @param partners 客户owning服务返回的真实范围分页，例如客户501，缺范围拒绝
   * @param products 商品owning服务返回的真实ACTIVE/EA分页，例如商品701，未实现生产维护
   * @param permits 实际固定动作逐项裁决，例如order.approve=true、write=false；不是客户端许可
   * @param requested 展示语言候选，例如zh-CN/en-US/ja-JP，不影响范围或资金策略
   *     业务示例：组织901、真实合成账号9211、订单600000、两行dueMinor68/67；失败遵循上文事务拒绝/回滚。
   * @return 公共data：实际分页和服务端表单/字段/操作/三语提示；例如pricingForm.id=crm-order-pricing-preview，
   *     pricingMessages.success明确未保存/未核验/未审核，synthetic为true；无计算、保存或授权副作用
   */
  public static CommonResult build(
      CommonPageResult orders,
      CommonPageResult partners,
      CommonPageResult products,
      Map<String, Boolean> permits,
      Object requested) {
    String lang =
        Set.of("zh-CN", "en-US", "ja-JP").contains(String.valueOf(requested))
            ? String.valueOf(requested)
            : "zh-CN";
    int locale = lang.equals("en-US") ? 1 : lang.equals("ja-JP") ? 2 : 0;
    Map<String, String[]> words = new LinkedHashMap<>();
    words.put("id", new String[] {"订单号", "Order number", "注文番号"});
    words.put("productNameSnapshot", new String[] {"商品名称", "Product name", "商品名"});
    words.put(
        "approvedDueMinor", new String[] {"行应付（最小货币单位）", "Line due (minor units)", "行支払額（最小通貨単位）"});
    words.put(
        "title",
        new String[] {"订单维护与独立审核", "Order maintenance and independent approval", "注文管理と独立承認"});
    words.put("orderKind", new String[] {"订单类型", "Order type", "注文種別"});
    words.put("currency", new String[] {"币种", "Currency", "通貨"});
    words.put("fee", new String[] {"订单费用", "Order fee", "注文費用"});
    words.put("partnerName", new String[] {"客户/供应商", "Customer / supplier", "顧客・仕入先"});
    words.put("productName", new String[] {"商品", "Product", "商品"});
    words.put("quantity", new String[] {"EA数量", "EA quantity", "EA数量"});
    words.put("unitPrice", new String[] {"单价", "Unit price", "単価"});
    words.put(
        "discountBps",
        new String[] {
          "折减万分率（1000减10%）", "Discount basis points (1000 reduces 10%)", "割引万分率（1000は10%引き）"
        });
    words.put("isGift", new String[] {"赠品", "Gift", "景品"});
    words.put("orderState", new String[] {"状态", "State", "状態"});
    words.put(
        "totalMinor", new String[] {"总额（最小货币单位）", "Total (minor currency units)", "合計（最小通貨単位）"});
    words.put("lineNo", new String[] {"行号", "Line number", "行番号"});
    words.put("new", new String[] {"新建订单", "New order", "新規注文"});
    words.put("saveDraft", new String[] {"保存全部头行", "Save complete draft", "全ヘッダ・行を保存"});
    words.put("submit", new String[] {"提交", "Submit", "提出"});
    words.put("withdraw", new String[] {"撤回修改", "Withdraw for editing", "取下げて編集"});
    words.put(
        "withdrawQuestion",
        new String[] {
          "将本人提交且未审核的订单撤回草稿？原提交记录保留，不影响资金、库存或课时。",
          "Withdraw your unapproved order to draft? Submission history is retained; funds, stock"
              + " and lesson units are unchanged.",
          "自分が提出した未承認の注文を下書きに戻しますか？提出履歴を保持し、資金・在庫・コマ数は変更しません。"
        });
    words.put("withdrawConfirm", new String[] {"确定撤回", "Confirm withdrawal", "取下げを確定"});
    words.put("withdrawCancel", new String[] {"取消", "Cancel", "キャンセル"});
    words.put("approve", new String[] {"独立审核", "Independent approval", "独立承認"});
    words.put("reject", new String[] {"驳回修改", "Return for correction", "差戻して修正"});
    // 新订单预览只显示计算候选，不能冒充已保存或已审核金额。
    words.put("preview", new String[] {"计算新订单金额", "Calculate new order", "新規注文の金額を計算"});
    words.put(
        "subtotalMinor", new String[] {"原价合计（最小货币单位）", "Subtotal (minor units)", "小計（最小通貨単位）"});
    words.put(
        "discountMinor", new String[] {"折减合计（最小货币单位）", "Discount (minor units)", "割引額（最小通貨単位）"});
    words.put("feeMinor", new String[] {"费用（最小货币单位）", "Fee (minor units)", "費用（最小通貨単位）"});
    words.put("reload", new String[] {"重载详情", "Reload detail", "再読み込み"});
    words.put("addLine", new String[] {"加入/更新行", "Add / update line", "行を追加・更新"});
    words.put("removeLine", new String[] {"移除当前行", "Remove selected line", "選択行を削除"});
    words.put("newLine", new String[] {"新行", "New line", "新しい行"});
    words.put("switch", new String[] {"切换", "Toggle", "切替"});
    Map<String, String> labels = new LinkedHashMap<>();
    words.forEach((key, values) -> labels.put(key, values[locale]));
    List<Map<String, Object>> fields = new ArrayList<>(), actions = new ArrayList<>();
    for (String field : List.of("orderKind", "partnerName", "currency", "fee")) {
      fields.add(
          Map.of(
              "id",
              field,
              "label",
              labels.get(field),
              "readOnly",
              !field.equals("fee"),
              "maxLength",
              200));
    }
    for (String action :
        List.of("new", "reload", "saveDraft", "submit", "withdraw", "approve", "reject", "preview")) {
      actions.add(Map.of("id", action, "label", labels.get(action)));
    }
    actions.add(
        Map.of(
            "id",
            "orderKind",
            "label",
            labels.get("switch") + " " + labels.get("orderKind"),
            "values",
            List.of("SALES", "PURCHASE"),
            "valueLabels",
            locale == 0
                ? List.of("销售", "采购")
                : locale == 1 ? List.of("Sales", "Purchase") : List.of("販売", "仕入")));
    actions.add(
        Map.of(
            "id",
            "currency",
            "label",
            labels.get("switch") + " " + labels.get("currency"),
            "values",
            List.of("CNY", "USD", "JPY")));
    List<Map<String, Object>> lineFields = new ArrayList<>();
    for (String field : List.of("productName", "quantity", "unitPrice", "discountBps", "isGift")) {
      lineFields.add(
          Map.of(
              "id",
              field,
              "label",
              labels.get(field),
              "readOnly",
              Set.of("productName", "isGift").contains(field),
              "maxLength",
              200));
    }
    List<Map<String, Object>> lineActions = new ArrayList<>();
    for (String action : List.of("newLine", "addLine", "removeLine")) {
      lineActions.add(Map.of("id", action, "label", labels.get(action)));
    }
    lineActions.add(
        Map.of(
            "id",
            "isGift",
            "label",
            labels.get("switch") + " " + labels.get("isGift"),
            "values",
            List.of("false", "true"),
            "valueLabels",
            locale == 0
                ? List.of("否", "是")
                : locale == 1 ? List.of("No", "Yes") : List.of("いいえ", "はい")));
    Map<String, Object> data = new LinkedHashMap<>();
    data.put("synthetic", true);
    data.put("permits", permits);
    data.put("title", labels.get("title"));
    data.put(
        "notice",
        new String[] {
              "隔离测试：合成身份、许可和商品。审核不改库存资金；生产写入未开放。",
              "Isolated test: synthetic identity, permission and products. Approval"
                  + " does not post stock or funds; production writes disabled.",
              "隔離テスト：合成アカウント・権限・商品。承認は在庫・資金を変更せず、本番書込み未開放。"
            }
            [locale]);
    data.put(
        "dirty",
        new String[] {
              "存在未保存头行，请先保存或重载。",
              "Unsaved draft. Save or reload first.",
              "未保存のヘッダ・行があります。保存または再読込みしてください。"
            }
            [locale]);
    data.put(
        "saved",
        new String[] {
              "数据库已提交；审核快照保留精确头行。",
              "Database committed; approval freezes exact header and lines.",
              "データベースに確定。承認スナップショットは精確なヘッダ・行を保存。"
            }
            [locale]);
    data.put("lineLimit", 1000);
    data.put(
        "lineLimitMessage",
        new String[] {
              "订单最多1000行，请先移除一行。",
              "An order supports at most 1000 lines. Remove a line first.",
              "注文は最大1000行です。先に行を削除してください。"
            }
            [locale]);
    data.put(
        "linePending",
        new String[] {
              "行字段尚未加入，请先加入/更新行或重载详情。",
              "Line fields are pending. Add/update the line or reload detail first.",
              "行フィールドが未追加です。行を追加・更新するか詳細を再読込みしてください。"
            }
            [locale]);
    data.put(
        "selectionRequired",
        new String[] {"请选择真实客户和商品。", "Select a real customer and product.", "実際の顧客と商品を選択してください。"}
            [locale]);
    data.put("labels", labels);
    data.put(
        "states",
        Map.of(
            "DRAFT",
            new String[] {"草稿", "Draft", "下書き"}[locale],
            "SUBMITTED",
            new String[] {"已提交", "Submitted", "提出済み"}[locale],
            "APPROVED",
            new String[] {"已审核冻结", "Approved and frozen", "承認・凍結済み"}[locale]));
    data.put(
        "headerForm",
        Map.of(
            "id",
            "crm-order-editor",
            "title",
            labels.get("title"),
            "fields",
            fields,
            "actions",
            actions,
            "slots",
            List.of("pricingPreview", "lineForm", "lineGrid", "attachments")));
    // 只读公共Form直接呈现服务端MINOR字符串；例如totalMinor=135，不在客户端换算或记账。
    List<Map<String, Object>> pricingFields = new ArrayList<>();
    for (String field :
        List.of("currency", "subtotalMinor", "discountMinor", "feeMinor", "totalMinor")) {
      pricingFields.add(
          Map.of("id", field, "label", labels.get(field), "readOnly", true, "maxLength", 200));
    }
    data.put(
        "pricingForm",
        Map.of(
            "id",
            "crm-order-pricing-preview",
            "title",
            labels.get("preview"),
            "fields",
            pricingFields));
    // 每种结果状态均保留事实边界；过期或失败不继续显示旧计算金额。
    Map<String, String> pricingMessages = new LinkedHashMap<>();
    pricingMessages.put(
        "initial",
        new String[] {
              "未保存；主数据未核验；未审核。加入全部行后可计算新订单金额。",
              "Not saved; master data not verified; not approved. Add all lines before calculating"
                  + " a new order.",
              "未保存・主データ未検証・未承認。全行を追加して新規注文の金額を計算してください。"
            }
            [locale]);
    pricingMessages.put(
        "pending",
        new String[] {
              "计算中；未保存；主数据未核验；未审核。",
              "Calculating; not saved; master data not verified; not approved.",
              "計算中・未保存・主データ未検証・未承認。"
            }
            [locale]);
    pricingMessages.put(
        "stale",
        new String[] {
              "输入已变化，请重新计算；未保存；主数据未核验；未审核。",
              "Input changed. Calculate again; not saved; master data not verified; not approved.",
              "入力が変わりました。再計算してください。未保存・主データ未検証・未承認。"
            }
            [locale]);
    pricingMessages.put(
        "success",
        new String[] {
              "新订单计算结果；未保存；主数据未核验；未审核。金额以最小货币单位显示。",
              "New order calculation; not saved; master data not verified; not approved. Amounts"
                  + " are in minor currency units.",
              "新規注文の計算結果。未保存・主データ未検証・未承認。金額は最小通貨単位で表示。"
            }
            [locale]);
    pricingMessages.put(
        "invalid",
        new String[] {
              "计算结果格式不符合合同；未保存；主数据未核验；未审核。",
              "Calculation response does not match the contract; not saved; master data not"
                  + " verified; not approved.",
              "計算結果の形式が契約と一致しません。未保存・主データ未検証・未承認。"
            }
            [locale]);
    data.put("pricingMessages", pricingMessages);
    data.put(
        "lineForm",
        Map.of("id", "crm-order-line-editor", "fields", lineFields, "actions", lineActions));
    List<Map<String, Object>> displayedOrders = new ArrayList<>();
    for (var source : orders.getRecords()) {
      var shown = CrmOrderValueSupport.browser(source);
      String state = String.valueOf(source.get("orderState"));
      shown.put(
          "orderStateLabel",
          switch (state) {
            case "DRAFT" -> new String[] {"草稿", "Draft", "下書き"}[locale];
            case "SUBMITTED" -> new String[] {"已提交", "Submitted", "提出済み"}[locale];
            case "APPROVED" -> new String[] {"已审核冻结", "Approved and frozen", "承認・凍結済み"}[locale];
            default -> state;
          });
      shown.put(
          "orderKindLabel",
          "SALES".equals(source.get("orderKind"))
              ? new String[] {"销售", "Sales", "販売"}[locale]
              : new String[] {"采购", "Purchase", "仕入"}[locale]);
      shown.put(
          "totalDisplay",
          new java.math.BigDecimal(source.get("totalMinor").toString())
                  .movePointLeft(((Number) source.get("currencyScale")).intValue())
                  .toPlainString()
              + " "
              + source.get("currency"));
      // 商品名称来自保存时的订单行快照；件数合计使用精确十进制，不换算为课时。
      @SuppressWarnings("unchecked")
      var items = (List<Map<String, Object>>) source.getOrDefault("orderItems", List.of());
      shown.put(
          "customerDisplay", source.getOrDefault("customerDisplay", "#" + source.get("partnerId")));
      String summary =
          items.stream()
              .limit(3)
              .map(item -> item.get("productNameSnapshot") + " × " + item.get("quantity"))
              .collect(java.util.stream.Collectors.joining("；"));
      if (items.size() > 3) {
        summary +=
            "；"
                + new String[] {"另", "+", "ほか"}[locale]
                + (items.size() - 3)
                + new String[] {"项", " items", "件"}[locale];
      }
      shown.put("itemsDisplay", summary.isEmpty() ? "—" : summary);
      shown.put(
          "quantityDisplay",
          items.isEmpty()
              ? "—"
              : items.stream()
                  .map(item -> new java.math.BigDecimal(item.get("quantity").toString()))
                  .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add)
                  .stripTrailingZeros()
                  .toPlainString());
      @SuppressWarnings("unchecked")
      var students =
          (List<Map<String, Object>>) source.getOrDefault("beneficiaryStudents", List.of());
      String studentDisplay =
          switch (String.valueOf(source.get("beneficiaryState"))) {
            case "AVAILABLE" ->
                students.isEmpty()
                    ? new String[] {"尚无课时开通", "No lesson entitlement opened", "受講枠は未開通"}[locale]
                    : students.stream()
                            .limit(3)
                            .map(
                                student ->
                                    student.get("displayName") + " (#" + student.get("id") + ")")
                            .collect(java.util.stream.Collectors.joining("；"))
                        + (students.size() > 3 ? " +" + (students.size() - 3) : "");
            case "FORBIDDEN" ->
                new String[] {"无权查看受益学生", "Not authorized to view beneficiaries", "受益学生の参照権限なし"}
                    [locale];
            case "UNAVAILABLE" ->
                new String[] {"受益来源暂不可读", "Beneficiary source unavailable", "受益情報を取得できません"}[locale];
            case "NOT_APPLICABLE" -> "—";
            default -> new String[] {"教学未接入", "Teaching not connected", "教学未接続"}[locale];
          };
      shown.put("studentDisplay", studentDisplay);
      displayedOrders.add(shown);
    }
    labels.put("orderStateLabel", labels.get("orderState"));
    labels.put("orderKindLabel", labels.get("orderKind"));
    labels.put("totalDisplay", new String[] {"总额", "Total", "合計"}[locale]);
    labels.put(
        "customerDisplay",
        new String[] {"客户 / 已开通学生", "Customer / beneficiaries", "顧客・開通済み学生"}[locale]);
    labels.put("beneficiaryStudents", new String[] {"已开通学生", "Beneficiaries", "開通済み学生"}[locale]);
    labels.put("itemsDisplay", new String[] {"订购项目", "Ordered items", "注文内容"}[locale]);
    labels.put("quantityDisplay", new String[] {"件数", "Qty", "数量"}[locale]);
    // 公共Search仅提交精确订单号；搜索覆盖服务端获准范围，不筛当前页数组。
    var orderGrid =
        grid(
            displayedOrders,
            orders,
            List.of(
                "id",
                "customerDisplay",
                "itemsDisplay",
                "quantityDisplay",
                "orderKindLabel",
                "orderStateLabel",
                "totalDisplay"),
            labels,
            locale);
    orderGrid.put(
        "search",
        Map.of(
            "label",
            labels.get("id"),
            "placeholder",
            new String[] {"输入完整订单号", "Enter the exact order number", "注文番号を完全入力"}[locale],
            "buttonLabel",
            new String[] {"查询", "Search", "検索"}[locale],
            "clearLabel",
            new String[] {"清除订单号查询", "Clear order number search", "注文番号検索をクリア"}[locale],
            "trim",
            false));
    data.put("orders", orderGrid);
    data.put(
        "partners",
        grid(
            partners.getRecords().stream().map(CrmOrderValueSupport::browser).toList(),
            partners,
            List.of("partnerName"),
            labels,
            locale));
    data.put(
        "products",
        grid(
            products.getRecords().stream().map(CrmOrderValueSupport::browser).toList(),
            products,
            List.of("productName"),
            labels,
            locale));
    data.put(
        "lines",
        grid(
            List.of(),
            null,
            List.of(
                "lineNo",
                "productNameSnapshot",
                "quantity",
                "unitPrice",
                "discountBps",
                "approvedDueMinor"),
            labels,
            locale));
    attachmentDefinition(data, locale);
    return CrmPartnerValueSupport.result(data);
  }

  /**
   * 方法作用：聚合订单附件公共控件三语配置；空列表只表示尚未读取，不构造文件或授权。
   *
   * @param data 真实工作区输出，例如当前订单和逐动作许可已由owning服务聚合
   * @param locale 已验证语言索引，例如0中文、1英文、2日文 副作用示例：只追加form/grid/filePicker定义；默认关闭文案不等于实际开放。
   */
  private static void attachmentDefinition(Map<String, Object> data, int locale) {
    Map<String, String[]> words = new LinkedHashMap<>();
    words.put("title", new String[] {"订单附件", "Order attachments", "注文添付"});
    words.put("choose", new String[] {"选择本地文件", "Choose local file", "ローカルファイルを選択"});
    words.put("empty", new String[] {"未选择文件", "No file selected", "ファイル未選択"});
    words.put(
        "uploadBind", new String[] {"上传并关联 / 重试", "Upload and bind / retry", "アップロード・関連付け / 再試行"});
    words.put(
        "bind", new String[] {"关联所选文件 / 重试", "Bind selected file / retry", "選択ファイルを関連付け / 再試行"});
    words.put(
        "refresh", new String[] {"刷新本人文件与引用", "Refresh your files and references", "本人ファイルと参照を更新"});
    words.put("nextFiles", new String[] {"下一页本人文件", "Next page of your files", "本人ファイルの次ページ"});
    words.put("sharedFiles", new String[] {"共享给我的文件", "Files shared with me", "共有されたファイル"});
    words.put("nextSharedFiles", new String[] {"下一页共享文件", "Next shared files", "共有ファイルの次ページ"});
    words.put("name", new String[] {"文件名称", "File name", "ファイル名"});
    words.put("ownerUserId", new String[] {"所有者账号", "Owner account", "所有者アカウント"});
    words.put(
        "sharedReady",
        new String[] {
          "已读取共享文件。选择后查看本订单引用，下载需要独立许可。",
          "Shared files loaded. Select to view this order's reference; downloading needs separate"
              + " access.",
          "共有ファイルを取得しました。選択して注文参照を表示します。取得には個別の許可が必要です。"
        });
    words.put(
        "sharedSelected",
        new String[] {
          "共享附件可查看，不可替换或重新关联。",
          "Shared attachment is available for viewing. It cannot be replaced or rebound.",
          "共有添付を表示できます。置換や再関連付けはできません。"
        });
    words.put(
        "sharedUnavailable",
        new String[] {
          "本订单没有可读取的该文件引用，请刷新核对。",
          "No readable reference to this file in this order. Refresh to check.",
          "この注文に読み取り可能なファイル参照がありません。更新して確認してください。"
        });
    words.put(
        "newReference",
        new String[] {"新增引用（取消替换）", "New reference (cancel replacement)", "参照を新規追加（置換解除）"});
    words.put("clear", new String[] {"清除本地选择", "Clear local selection", "ローカル選択を解除"});
    words.put("download", new String[] {"下载所选文件", "Download selected file", "選択ファイルを取得"});
    words.put(
        "files",
        new String[] {
          "本人已上传文件（当前root页）",
          "Your uploaded files (current root page)",
          "本人のアップロード済みファイル（rootの現在ページ）"
        });
    words.put("references", new String[] {"本订单本人引用", "Your references on this order", "この注文の本人参照"});
    words.put("target", new String[] {"关联目标", "Binding target", "関連付け先"});
    words.put("candidate", new String[] {"待关联文件", "File to bind", "関連付け候補"});
    words.put("fileId", new String[] {"文件编号", "File ID", "ファイルID"});
    words.put("byteSize", new String[] {"字节数", "Bytes", "バイト数"});
    words.put("id", new String[] {"引用编号", "Reference ID", "参照ID"});
    words.put("versionNo", new String[] {"独立版本", "Reference version", "参照バージョン"});
    words.put(
        "selectOrder",
        new String[] {
          "请先选择已保存订单。附件关联默认关闭，仅明确启用后可用。",
          "Select a saved order. Attachment binding is disabled by default and requires explicit"
              + " enablement.",
          "保存済み注文を選択してください。添付関連付けは既定で無効、明示的な有効化が必要です。"
        });
    words.put(
        "closed",
        new String[] {
          "附件当前不可用或读取失败；关联状态未确认，请刷新引用核对。",
          "Attachments are unavailable or could not be read. Binding status is unconfirmed; refresh"
              + " references to check.",
          "添付は利用不可または読み取り失敗です。関連付け状態は未確認のため、参照を更新してください。"
        });
    words.put(
        "ready",
        new String[] {
          "已读取本人文件和引用。选择文件后明确关联；不改变订单冻结金额或库存。",
          "Your files and references loaded. Select then explicitly bind; frozen amounts and stock"
              + " remain unchanged.",
          "本人ファイル・参照を取得。選択後に明示的に関連付けます。凍結金額・在庫は変わりません。"
        });
    words.put(
        "working",
        new String[] {
          "正在核验、上传或关联，请等待。",
          "Checking, uploading or binding. Please wait.",
          "確認・アップロード・関連付け中です。お待ちください。"
        });
    words.put(
        "uploaded",
        new String[] {
          "文件已上传，关联尚未确认。重试复用原文件和请求键。",
          "File uploaded; binding unconfirmed. Retry reuses the file and request key.",
          "アップロード済み、関連付け未確定。再試行は同じファイル・要求キーを使用。"
        });
    words.put(
        "saved",
        new String[] {
          "关联已提交；引用与审计由服务器确认。",
          "Binding committed; reference and audit confirmed by server.",
          "関連付け確定。参照・監査はサーバー確認済み。"
        });
    words.put(
        "replayed",
        new String[] {
          "原请求已提交，本次返回首次关联结果。",
          "Original request committed; first binding result replayed.",
          "元の要求は確定済み。初回の関連付け結果を再取得。"
        });
    words.put(
        "pending",
        new String[] {
          "附件选择或请求尚未确认，请先重试或清除选择。",
          "Attachment selection or request is pending. Retry or clear selection first.",
          "添付選択・要求は未確定。再試行または選択解除してください。"
        });
    words.put("newTarget", new String[] {"新增引用", "New reference", "新規参照"});
    words.put(
        "invalid",
        new String[] {
          "文件接口响应不完整或容量不允许，未确认关联。",
          "Incomplete file response or invalid capacity; binding unconfirmed.",
          "ファイル応答不完全または容量不可。関連付け未確定。"
        });
    words.put(
        "cleared",
        new String[] {
          "仅清除本地选择，不撤销服务器上传或关联；未确认提交请先刷新引用。",
          "Local selection cleared; server uploads and bindings are not revoked. Refresh references"
              + " for unconfirmed requests.",
          "ローカル選択のみ解除。サーバーのアップロード・関連付けは取り消しません。未確定の要求は参照を更新してください。"
        });
    Map<String, String> labels = new LinkedHashMap<>();
    words.forEach((key, value) -> labels.put(key, value[locale]));
    data.put("attachmentMessages", labels);
    data.put(
        "attachmentPicker",
        Map.of(
            "choose",
            labels.get("choose"),
            "empty",
            labels.get("empty"),
            "label",
            labels.get("candidate")));
    List<Map<String, Object>> actions = new ArrayList<>();
    for (String id :
        List.of(
            "uploadBind",
            "bind",
            "refresh",
            "nextFiles",
            "sharedFiles",
            "nextSharedFiles",
            "newReference",
            "clear",
            "download")) {
      actions.add(
          id.equals("download")
              ? Map.of("id", id, "label", labels.get(id), "type", "link")
              : Map.of("id", id, "label", labels.get(id)));
    }
    data.put(
        "attachmentForm",
        Map.of(
            "id",
            "selFormCrmOrderAttachmentsId",
            "title",
            labels.get("title"),
            "fields",
            List.of(
                Map.of("id", "target", "label", labels.get("target"), "readOnly", true),
                Map.of("id", "candidate", "label", labels.get("candidate"), "readOnly", true)),
            "slots",
            List.of("picker", "files", "references"),
            "actions",
            actions));
    data.put(
        "attachmentFiles",
        grid(
            List.of(), null, List.of("name", "fileId", "ownerUserId", "byteSize"), labels, locale));
    data.put(
        "attachmentReferences",
        grid(List.of(), null, List.of("id", "versionNo", "fileId", "byteSize"), labels, locale));
  }

  /**
   * 将实际分页行和已确定后台文字聚合到公共Grid合同，不生成假的订单数据。
   *
   * @param rows 实际订单行，例如[{id:600000,totalMinor:135}]；空列表只表示待编辑
   * @param page 实际CommonPageResult，例如totalCount1/pageNo1
   * @param columns 后台固定显示字段，例如id/orderStateLabel
   * @param labels 实际三语已选文字，例如id对应编号
   * @param locale 已验证语言索引，0中文、1英文、2日文
   * @return grid.mode=records、data.items实际行、column.items固定字段及pagination真实页码，无写入
   */
  private static Map<String, Object> grid(
      List<Map<String, Object>> rows,
      CommonPageResult page,
      List<String> columns,
      Map<String, String> labels,
      int locale) {
    Map<String, Object> result = new LinkedHashMap<>();
    result.put("grid", Map.of("mode", "records", "selectionMode", "SINGLE", "idField", "id"));
    result.put("data", Map.of("items", rows, "selectedIds", List.of()));
    result.put(
        "column",
        Map.of(
            "items",
            columns.stream()
                .map(
                    field ->
                        Map.of(
                            "id",
                            field,
                            "field",
                            field,
                            "label",
                            labels.getOrDefault(field, field)))
                .toList()));
    result.put("title", Map.of("messages", Map.of("selectProject", labels.get("title"))));
    result.put(
        "pagination",
        Map.of(
            "mode",
            page == null ? "LOCAL" : "REMOTE",
            "visible",
            page != null,
            "totalCount",
            page == null ? rows.size() : page.getTotalCount(),
            "currentPage",
            page == null ? 1 : page.getPageNo(),
            "pageSize",
            page == null ? 1000 : page.getPageSize(),
            "previousLabel",
            new String[] {"上一页", "Previous", "前へ"}[locale],
            "nextLabel",
            new String[] {"下一页", "Next", "次へ"}[locale],
            "summaryAll",
            new String[] {"共 {total} 条", "{total} records", "合計 {total} 件"}[locale]));
    result.put(
        "select",
        Map.of(
            "pageSize",
            Map.of(
                "ariaLabel",
                new String[] {"每页行数", "Rows per page", "ページ行数"}[locale],
                "options",
                List.of(10, 20, 50, 100).stream()
                    .map(
                        size ->
                            Map.of(
                                "value",
                                size.toString(),
                                "label",
                                size + new String[] {" 行/页", " rows/page", " 行/ページ"}[locale]))
                    .toList())));
    return result;
  }
}
