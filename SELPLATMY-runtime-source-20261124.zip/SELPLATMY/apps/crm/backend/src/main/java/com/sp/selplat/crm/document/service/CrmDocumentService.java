/**
 * 单一销售出库隔离本表组件；2026-10-03，Codex；生产默认拒绝。
 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.crm.document.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;

/**
 * 本表owning服务，只读HTTP和具名CRM事务扩展。
 */
public interface CrmDocumentService extends com.sp.selplat.common.service.BaseService {

  /**
   * 精确本组织内部锁；缺实际许可或事务拒绝。
   *
   * @param input org901/id1000000
   * @param action 固定stock.post等动作
   * @return 真实范围行；不存在统一拒绝
   */
  Map<String, Object> lockScoped(CommonParam input, String action);

  /**
   * 具名saveDraft，审核不扣库存。
   *
   * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
   * @return 实际本表结果；缺范围/事务拒绝
   */
  CommonResult saveDraft(CommonParam input);

  /**
   * 具名submit，审核不扣库存。
   *
   * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
   * @return 实际本表结果；缺范围/事务拒绝
   */
  CommonResult submit(CommonParam input);

  /**
   * 具名approve，审核不扣库存。
   *
   * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
   * @return 实际本表结果；缺范围/事务拒绝
   */
  CommonResult approve(CommonParam input);

  /**
   * 具名source，审核不扣库存。
   *
   * @param input org901/id1000000/expectedVersion0；实际actor由Session给出
   * @return 实际本表结果；缺范围/事务拒绝
   */
  CommonResult source(CommonParam input);

  /**
   * 内部行写也重验真实DRAFT。
   *
   * @param input org901/id1000000/expectedVersion0；实际actor由Session给出 返回示例：void；非DRAFT或版本不符整笔拒绝
   */
  void requireDraftLines(CommonParam input);

  /**
   * owning Document准备明确POST，全部引用/冻结先实际核验。
   *
   * @param input org901/id1000000/expectedVersion2
   * @return 已锁APPROVED头、真实source和全部lines；不改余额
   */
  Map<String, Object> preparePost(CommonParam input);

  /**
   * owning Document同事务最后推进POSTED。
   *
   * @param input org901/id1000000/expectedVersion2
   * @return 已CAS为POSTED/version3实际头；缺许可/旧状态拒绝
   */
  Map<String, Object> markPosted(CommonParam input);

  /**
   * 同范围实际POST引用检查，不提前检查变化状态破坏首次重放。
   *
   * @param input org901/id1000000 副作用示例：不存在/越组织统一CRM_RECORD_NOT_FOUND，不claim越范围FK。
   */
  void requirePostReference(CommonParam input);

  /**
   * Actual receipt owning operation saveFundsDraft; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonResult saveFundsDraft(CommonParam input);

  /**
   * Actual receipt owning operation submitFunds; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonResult submitFunds(CommonParam input);

  /**
   * Actual receipt owning operation approveFunds; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonResult approveFunds(CommonParam input);

  /**
   * 方法作用：现有资金审核人将待审收付款单退回草稿，原因沿原审计保留。
   *
   * @param input 页面候选，例如organizationCandidateId901/id1000000/expectedVersion1及reasonText核对金额
   * @return 真实示例：success=true/data.documentState=DRAFT/versionNo=2；同原键回放replay=true。
   *     异常或副作用示例：自审、旧版本、空原因或缺原审核权限拒绝；不生成现金流水。
   */
  CommonResult rejectFunds(CommonParam input);


  /**
   * Actual receipt owning operation getFundsById; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonResult getFundsById(CommonParam input);

  /**
   * Actual receipt owning operation fundsSource; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonResult fundsSource(CommonParam input);

  /**
   * Actual receipt owning operation prepareFundsPost; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  Map<String, Object> prepareFundsPost(CommonParam input);

  /**
   * Actual receipt owning operation markFundsPosted; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  Map<String, Object> markFundsPosted(CommonParam input);

  /**
   * Actual receipt owning operation requireFundsPostReference; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   *     返回示例：void；实际scope不符拒绝，无业务写入
   */
  void requireFundsPostReference(CommonParam input);

  /**
   * Actual receipt owning operation fundsStore; no payment channel.
   *
   * @param input e.g. org901/id1000000/expectedVersion2 and typed complete receipt input
   * @return actual scope-bound result or rejection; atomic CRM transaction where written
   */
  CommonPageResult fundsStore(CommonPageParam input);

  /**
   * 方法作用：按Order→Line→Document锁序核实原已记账收款全部冻结行。
   *
   * @param input org901/id1000000/expected3
   * @param action crm.funds.reverse或审核动作
   * @return 实际POSTED头及全部原行，无资金效果 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  Map<String, Object> prepareFundsReverse(CommonParam input, String action);

  /**
   * 方法作用：末尾CAS原收款状态且保留原审批和首次记账人。
   *
   * @param input org901/id1000000/expected3
   * @return REVERSED/version4；零行整笔回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  Map<String, Object> markFundsReversed(CommonParam input);

  /**
   * 方法作用：在冲正预览的同一CRM事务持有Order/Line→Document锁并读完整真实收款。
   *
   * @param input 例如org901/id1000000
   * @return 本组织实际头及全行、POSTED或REVERSED状态；无写入，引用或冻结不一致拒绝。
   */
  Map<String, Object> readFundsForReversal(CommonParam input);

  /**
   * 方法作用：在冲正claim前核实同组织实际原收款存在性，不先按状态阻断幂等重放。
   *
   * @param input 例如org901/id1000000
   * @param action 例如crm.funds.reverse或crm.funds.approve
   *     副作用示例：越租户、越组织、不存在或库存单统一CRM_RECORD_NOT_FOUND；不执行写入、不提前锁Document。
   */
  void requireFundsReverseReference(CommonParam input, String action);

  /**
   * 方法作用：按Order→Line→Document锁序核实原已记账库存单全部冻结行。
   *
   * @param input org901/id1000000/expected3
   * @param action crm.stock.reverse或审核动作
   * @return 实际POSTED头及全部原行，无库存效果 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  Map<String, Object> prepareStockReverse(CommonParam input, String action);

  /**
   * 方法作用：末尾CAS原库存单状态且保留原审批和首次记账人。
   *
   * @param input org901/id1000000/expected3
   * @return REVERSED/version4；零行整笔回滚 异常或副作用示例：缺真实当前许可、引用或版本不符拒绝，写入失败由外层CRM事务全部回滚。
   */
  Map<String, Object> markStockReversed(CommonParam input);

  /**
   * 方法作用：在冲正预览的同一CRM事务持有Order/Line→Document锁并读完整真实库存单。
   *
   * @param input 例如org901/id1000000
   * @return 本组织实际头及全行、POSTED或REVERSED状态；无写入，引用或冻结不一致拒绝。
   */
  Map<String, Object> readStockForReversal(CommonParam input);

  /**
   * 方法作用：在冲正claim前核实同组织实际原库存单存在性，不先按状态阻断幂等重放。
   *
   * @param input 例如org901/id1000000
   * @param action 例如crm.stock.reverse或crm.stock.approve
   *     副作用示例：越租户、越组织、不存在或库存单统一CRM_RECORD_NOT_FOUND；不执行写入、不提前锁Document。
   */
  void requireStockReverseReference(CommonParam input, String action);

  /**
   * 方法作用：原资金事务在持久课时执行保护后核课程退款完整冻结，不复用采购付款验证。
   * @param input 原org901/id100000/expectedVersion2
   * @param quotes 原资金拥有方实际核出的预留100000对应maximumRefundMinor18，不接受HTTP提供
   * @return 真实示例：原APPROVED课程退款头、全部原行及冻结来源，尚无现金写入。
   * 异常或副作用示例：摘要、原单行、金额或版本不符拒绝并回滚外层CRM事务。
   */
  Map<String, Object> prepareCourseFundsPost(
      CommonParam input, Map<Long, Map<String, Object>> quotes);
}
