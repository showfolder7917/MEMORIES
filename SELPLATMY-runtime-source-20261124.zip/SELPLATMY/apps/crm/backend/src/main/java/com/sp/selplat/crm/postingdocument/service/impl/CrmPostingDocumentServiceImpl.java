/** 修改记录：2026-10-09，私人批读沿用有效记录边界，不开放新的写路由。 */
/** CrmPostingDocumentServiceImpl.java：CRM 本域平台分层实现。 修改记录：2026-10-03，Codex 按用户委托整理本域归属与安全边界。 */
package com.sp.selplat.crm.postingdocument.service.impl;

import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.crm.capability.access.service.CrmAccessService;
import com.sp.selplat.crm.common.util.draft.CrmDraftScopeSupport;
import com.sp.selplat.crm.postingdocument.dao.CrmPostingDocumentDao;
import com.sp.selplat.crm.postingdocument.service.CrmPostingDocumentService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

/** 本表服务直接复用公共 CRUD；仅预处理私人归属、校验和本域事务。 */
@Service
public class CrmPostingDocumentServiceImpl extends BaseServiceImpl<CrmPostingDocumentDao>
        implements CrmPostingDocumentService {
    // 准入能力从真实 Uniauth 回查身份，字段不由客户端提供。
    private final CrmAccessService accessService;

    // 只允许本表真实搜索字段，不允许请求传入租户或 owner 操作符。
    private static final Set<String> SEARCH_FIELDS = Set.of();

    /**
     * 装配真实准入能力；DAO 由公共泛型绑定。
     *
     * @param accessService 本域准入服务，例如 CrmAccessServiceImpl 副作用示例：构造不建立 Session、不查询 SQL、不授予管理员权限。
     */
    public CrmPostingDocumentServiceImpl(CrmAccessService accessService) {
        this.accessService = accessService;
    }

    /**
     * 查询本人有效记录的公共分页。
     *
     * @param queryIn 标准参数，例如 {pageNo:1,pageSize:20}
     * @return 公共页，例如 {records:[],totalCount:0,pageNo:1,pageSize:20} 异常示例：无真实账号或正数归属时拒绝，不执行无范围 SQL。
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam queryIn) {
        CommonPageParam scoped =
                CrmDraftScopeSupport.scopeStore(
                        queryIn, accessService.requireDraftActor(), SEARCH_FIELDS);
        return super.getStore(scoped);
    }

    /**
     * 委托公共精确复合主键读取本人记录。
     *
     * @param queryIn 参数，例如 {id:100001,tenantId:1}
     * @return 公共结果，例如 {success:true,data:{id:100001,status:1}} 异常示例：非法 ID、其他 owner/tenant
     *     和删除记录均拒绝；不写库。
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam queryIn) {
        CommonParam scoped =
                CrmDraftScopeSupport.scopeDetail(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.requireActive(super.getById(scoped));
    }

    /**
     * 批量读取公共精确主键，空输入保持空批次，软删除记录不返回。
     *
     * @param queryIn 参数，例如 items=[{id:100001}] 或 []
     * @return 公共批量结果，例如 {success:true,data:[]} 异常示例：非法身份或 ID 拒绝；不会退化为分页查询。
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam queryIn) {
        CommonBatchParam scoped =
                CrmDraftScopeSupport.scopeBatch(queryIn, accessService.requireDraftActor());
        return CrmDraftScopeSupport.activeBatch(super.getByIds(scoped));
    }

    /**
     * 取得真实审计操作员。
     *
     * @return 当前账号主键，例如 9211L；无默认操作员 异常示例：账号失效时沿用统一身份拒绝，不访问本表 SQL。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return accessService.requireDraftActor().get("ownerUserId");
    }

    /**
     * 取得真实租户。
     *
     * @return 当前租户，例如 92L；无默认租户 异常示例：归属无效时拒绝，不接收客户端身份。
     */
    @Override
    protected Long getCurrentTenantId() {
        return accessService.requireDraftActor().get("tenantId");
    }

    /**
     * 私人维护不产生管理员授权。
     *
     * @return 恒 false 副作用示例：不授予组织写入、库存或财务权限。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 公共写入前覆盖可信归属。
     *
     * @param writeIn 内部参数，例如 {tenantId:1,ownerUserId:1} 返回示例：无正常返回；通用写入抛
     *     POSTING_GENERIC_WRITE_DISABLED。 异常示例：失效账号或通用写入均拒绝，不执行 SQL。
     */
    @Override
    protected void applyCurrentIdentity(CommonParam writeIn) {
        accessService.requireDraftActor();
        throw new com.sp.selplat.common.exception.CommonBusinessException(
                "POSTING_GENERIC_WRITE_DISABLED", "过账记录只能由具名原子流程写入，禁止通用 CRUD 修改。");
    }

    /**
     * 在 CRM 具名事务内委托公共 insertBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult insertBatch(CommonBatchParam writeIn) {
        return super.insertBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 updateBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult updateBatch(CommonBatchParam writeIn) {
        return super.updateBatch(writeIn);
    }

    /**
     * 在 CRM 具名事务内委托公共 deleteBatch。
     *
     * @param writeIn 已校验的内部批次，例如 items=[{id:100001}]
     * @return 公共批量结果，例如 {success:true,affectedRows:1} 异常或副作用示例：失败回滚本域批次；HTTP 只读控制器不提供该写入口。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "crmTransactionManager")
    public CommonResult deleteBatch(CommonBatchParam writeIn) {
        return super.deleteBatch(writeIn);
    }

    // 三个隔离条件同时满足才允许内部过账；HTTP登录不授予写权限。
    @org.springframework.beans.factory.annotation.Autowired
    @org.springframework.beans.factory.annotation.Qualifier("crmPostingWriteEnabled")
    private Boolean postingWriteEnabled;

    /**
     * 既有私人隔离写入口按真实Session重新绑定归属。
     *
     * @param input 内部实际单据候选，例如id101；不将客户端tenant/owner当可信值
     * @return 独立CommonParam，tenant92/owner9211来自真实Session；原门禁关闭拒绝，不写库
     */
    private CommonParam bound(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.enabled(postingWriteEnabled);
        CommonParam result =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(
                        input.getParamMap());
        CrmDraftScopeSupport.applyActor(result, accessService.requireDraftActor());
        return result;
    }

    /**
     * 本表原子流程扩展 findScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public java.util.Map<String, Object> findScoped(CommonParam input) {
        return getDao().findScoped(bound(input));
    }

    /**
     * 本表原子流程扩展 lockScoped，只经本表 getDao 访问本表SQL。
     *
     * @param input 例如 {id:101,versionNo:0,tenantId:92}；归属重新从真实账号覆盖
     * @return 实际数据库行或新流水/请求主键，例如101L。 异常或副作用示例：门禁/归属/零行数/唯一约束失败传播至外层回滚；读取不构造默认记录。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public java.util.Map<String, Object> lockScoped(CommonParam input) {
        return getDao().lockScoped(bound(input));
    }

    /**
     * 既有私人过账单按真实范围和版本条件更新状态。
     *
     * @param input 内部单据id101/version0及目标状态，身份重新绑定
     *     异常或副作用示例：仅恰好一行条件更新成功；门禁关闭、旧版本或CAS0由原事务整笔回滚，不构造缺失单据。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public void changeStateIfVersion(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.changed(
                getDao().changeStateIfVersion(bound(input)));
    }

    // 跨表只能调用 owning service；每个服务经自己的 getDao 访问同一 CRM 事务。
    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingrequest.service.CrmPostingRequestService requests;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.postingentry.service.CrmPostingEntryService entries;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.stockbalance.service.CrmStockBalanceService stock;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.fundsbalance.service.CrmFundsBalanceService funds;

    @org.springframework.beans.factory.annotation.Autowired
    private com.sp.selplat.crm.customerdraft.service.CrmCustomerDraftService customers;

    /**
     * 在独立 CRM 事务中执行整个动作；订单审核不生成库存或资金流水。
     *
     * @param input 严格四字段，例如{id:102,action:POST,requestKey:r1,expectedVersion:0}
     * @return CommonResult，例如{data:{documentId:102,state:POSTED,entryId:100001,replay:false}}
     *     异常或副作用示例：请求冲突先整笔回滚，由外层新事务查询；锁/CAS/约束失败无部分业务提交。
     */
    @OperationLog
    @Transactional(
            transactionManager = "crmTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.REQUIRES_NEW,
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult executeAtomic(CommonParam input) {
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.enabled(postingWriteEnabled);
        CommonParam action =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.request(input);
        String hash = com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.hash(action);
        Long documentId = Long.valueOf(String.valueOf(action.getParam("id")));
        CommonParam claim =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(
                        action.getParamMap());
        claim.putParam("documentId", documentId);
        claim.putParam("payloadHash", hash);
        // 先精确验证本人记录存在，避免用外键错误代替跨租户授权拒绝。
        java.util.Map<String, Object> initial =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                        getDao().findScoped(bound(action)));
        Long requestId = requests.claimRequest(claim);
        // 发现锁集合后，按客户→升序单据→余额锁定；锁后重验引用，拒绝发现期间变动。
        Object sourceId = initial.get("sourceDocumentId");
        java.util.Map<String, Object> sourceInitial =
                sourceId == null
                        ? null
                        : com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                                getDao().findScoped(
                                                bound(
                                                        com.sp.selplat.crm.common.util.posting
                                                                .CrmPostingValueSupport.param(
                                                                java.util.Map.of(
                                                                        "id", sourceId)))));
        Object customerId =
                sourceInitial == null ? initial.get("customerId") : sourceInitial.get("customerId");
        String sourceKind =
                String.valueOf(
                        sourceInitial == null ? initial.get("kind") : sourceInitial.get("kind"));
        if (java.util.Set.of("SALES_ORDER", "SALES_RETURN").contains(sourceKind)
                && customerId == null) {
            throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                    "POSTING_CUSTOMER_REQUIRED");
        }
        if (customerId != null) {
            customers.lockForPosting(
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(
                            java.util.Map.of("id", customerId)));
        }
        java.util.TreeSet<Long> ids = new java.util.TreeSet<>();
        ids.add(documentId);
        if (sourceId != null) {
            ids.add(((Number) sourceId).longValue());
        }
        java.util.Map<Long, java.util.Map<String, Object>> locked = new java.util.HashMap<>();
        for (Long id : ids) {
            locked.put(
                    id,
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                            getDao().lockScoped(
                                            bound(
                                                    com.sp.selplat.crm.common.util.posting
                                                            .CrmPostingValueSupport.param(
                                                            java.util.Map.of("id", id))))));
        }
        java.util.Map<String, Object> document = locked.get(documentId);
        java.util.Map<String, Object> source =
                sourceId == null ? null : locked.get(((Number) sourceId).longValue());
        if (!java.util.Objects.equals(sourceId, document.get("sourceDocumentId"))
                || !java.util.Objects.equals(
                        customerId,
                        source == null ? document.get("customerId") : source.get("customerId"))) {
            throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                    "POSTING_CONCURRENT_CHANGE");
        }
        long expected = Long.parseLong(String.valueOf(action.getParam("expectedVersion")));
        if (((Number) document.get("versionNo")).longValue() != expected) {
            throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                    "STALE_POSTING_VERSION");
        }
        if (!"NEW".equals(document.get("origin"))) {
            throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                    "HISTORICAL_POSTING_DISABLED");
        }
        String verb = String.valueOf(action.getParam("action"));
        String kind = String.valueOf(document.get("kind"));
        java.util.Map<String, Object> values = new java.util.LinkedHashMap<>();
        document.forEach(
                (key, value) -> {
                    if (value != null) {
                        values.put(key, text(value));
                    }
                });
        values.put("state", document.get("documentState"));
        values.put("action", verb);
        values.put("expectedVersion", Long.toString(expected));
        values.put("currentVersion", text(document.get("versionNo")));
        values.put("requestKey", action.getParam("requestKey"));
        values.put("requestState", "NONE");
        // 单来源可能有多张过账子单；持有来源锁时检查不可变原流水而非信任客户端计数。
        if ("CANCEL".equals(verb) && "APPROVED".equals(document.get("documentState"))) {
            values.put(
                    "postedEntryCount",
                    Long.toString(
                            entries.countSourcePosts(
                                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport
                                            .param(
                                                    java.util.Map.of(
                                                            "sourceDocumentId", documentId)))));
        }
        boolean posting = java.util.Set.of("POST", "REVERSE").contains(verb);
        java.util.Map<String, Object> balance = null;
        java.util.Map<String, Object> original = null;
        boolean stockKind = kind.startsWith("STOCK_");
        if (posting) {
            if (!stockKind && !"CASH".equals(document.get("accountKind"))) {
                throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                        "UNSUPPORTED_POSTING_ACCOUNT_KIND");
            }
            if (source == null) {
                throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                        "INVALID_POSTING_SOURCE");
            }
            values.put("sourceDocumentKind", source.get("kind"));
            values.put("sourceDocumentState", source.get("documentState"));
            if (!"NEW".equals(source.get("origin"))) {
                throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                        "HISTORICAL_POSTING_DISABLED");
            }
            balance =
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                            stockKind
                                    ? stock.lockScoped(
                                            com.sp.selplat.crm.common.util.posting
                                                    .CrmPostingValueSupport.param(document))
                                    : funds.lockScoped(
                                            com.sp.selplat.crm.common.util.posting
                                                    .CrmPostingValueSupport.param(document)));
            if (stockKind) {
                values.put("availableQuantity", text(balance.get("quantity")));
            }
            if ("REVERSE".equals(verb)) {
                original =
                        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.row(
                                entries.findOriginal(
                                        com.sp.selplat.crm.common.util.posting
                                                .CrmPostingValueSupport.param(
                                                java.util.Map.of("documentId", documentId))));
                values.put("originalEntryId", text(original.get("id")));
                values.put("originalEntryState", "POSTED");
                values.put("originalKind", original.get("kind"));
                values.put("originalSourceDocumentId", text(original.get("sourceDocumentId")));
                for (String field :
                        stockKind
                                ? new String[] {"warehouseId", "productId", "quantityUnit"}
                                : new String[] {"currency", "amountUnit"}) {
                    values.put(
                            "original"
                                    + Character.toUpperCase(field.charAt(0))
                                    + field.substring(1),
                            text(original.get(field)));
                }
                if (!stockKind
                        && (!java.util.Objects.equals(
                                        original.get("accountId"), document.get("accountId"))
                                || !java.util.Objects.equals(
                                        original.get("accountKind"),
                                        document.get("accountKind")))) {
                    throw com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.failure(
                            "INVALID_REVERSAL_REFERENCE");
                }
                values.put(
                        stockKind ? "originalQuantity" : "originalAmount",
                        new java.math.BigDecimal(
                                        text(
                                                original.get(
                                                        stockKind
                                                                ? "quantityDelta"
                                                                : "amountDelta")))
                                .abs()
                                .toPlainString());
            }
        }
        java.util.Map<String, Object> preview =
                com.sp.selplat.crm.common.util.posting.CrmPostingPreflightSupport.preview(values);
        Long entryId = null;
        if (posting && !stockKind) {
            com.sp.selplat.crm.common.util.posting.CrmPostingPreflightSupport.cashProjection(
                    text(balance.get("accountKind")),
                    text(document.get("currency")),
                    text(document.get("amountUnit")),
                    text(balance.get("currency")),
                    text(balance.get("amountUnit")),
                    text(balance.get("amount")),
                    String.valueOf(preview.get("fundsDelta")));
        }
        if (posting) {
            CommonParam entry =
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(document);
            entry.putParam("documentId", documentId);
            entry.putParam("action", verb);
            entry.putParam("originalEntryId", original == null ? null : original.get("id"));
            Object delta =
                    stockKind
                            ? Long.valueOf(String.valueOf(preview.get("stockDelta")))
                            : new java.math.BigDecimal(String.valueOf(preview.get("fundsDelta")));
            entry.putParam(stockKind ? "stockBalanceId" : "fundsBalanceId", balance.get("id"));
            entry.putParam(stockKind ? "quantityDelta" : "amountDelta", delta);
            entryId = entries.appendEntry(entry);
            CommonParam change =
                    com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(balance);
            change.putParam("delta", delta);
            if (stockKind) {
                stock.applyDeltaIfVersion(change);
            } else {
                funds.applyDeltaIfVersion(change);
            }
        }
        CommonParam change =
                com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.param(document);
        change.putParam("nextState", preview.get("to"));
        // affected=0 必须抛异常：流水、余额、单据和请求均由当前独立事务一起回滚。
        com.sp.selplat.crm.common.util.posting.CrmPostingValueSupport.changed(
                getDao().changeStateIfVersion(bound(change)));
        claim.putParam("id", requestId);
        claim.putParam("resultEntryId", entryId);
        claim.putParam("resultState", preview.get("to"));
        requests.completeRequest(claim);
        java.util.Map<String, Object> result = new java.util.LinkedHashMap<>();
        result.put("documentId", documentId);
        result.put("state", preview.get("to"));
        result.put("entryId", entryId);
        result.put("replay", false);
        return buildSuccessResult(result, "隔离单据动作已原子提交。");
    }

    /**
     * 仅将实际库数值转为精确显示文本，不参与定价或记账。
     *
     * @param value 例如DECIMAL 2.00000000或实际其他列值
     * @return 示例返回"2"，不舍入、不写库；非BigDecimal沿用String.valueOf
     */
    private static String text(Object value) {
        return value instanceof java.math.BigDecimal decimal
                ? decimal.stripTrailingZeros().toPlainString()
                : String.valueOf(value);
    }
}
