/** 销售出库明确v2 HTTP；2026-10-03，Codex；旧四字段协议不改。 */
package com.sp.selplat.crm.capability.stock.controller;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

/** 无DAO，调用实际Stock owning业务聚合器；生产写默认拒绝。 */
@RestController
public class CrmStockController {
    private final com.sp.selplat.crm.capability.stock.service.CrmStockService service;

    /**
     * 注入实际业务聚合器，构造不执行SQL。
     *
     * @param service Spring注入的本表或业务服务，例如本类声明的实际实现；构造仅保留引用。
     */
    public CrmStockController(com.sp.selplat.crm.capability.stock.service.CrmStockService service) {
        this.service = service;
    }

    /**
     * v2组织完整POST，只有明确POST扣库存。
     *
     * @param input 例如org901/id1000000/actionPOST/expected2/keyk1
     * @return 同批全部真实效果ID/首次结果，不部分成功
     */
    @PostMapping("/api/crm/posting/v2/execute.htm")
    public String execute(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.execute(input));
    }

    /**
     * 实际完整库存批次查询。
     *
     * @param input 例如org901/id1200000
     * @return 同范围真实批次及全部明细JSON，跨组织拒绝
     */
    @GetMapping("/api/crm/posting/v2/batch/getById.htm")
    public String batch(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.batch(input));
    }

    /**
     * 真实出库工作区与服务端公共SELUI定义。
     *
     * @param input 例如org901/page1/langzh-CN
     * @return 公共实际聚合JSON，生产默认拒绝
     */
    @GetMapping("/api/crm/stock/workspace.htm")
    public String workspace(CommonPageParam input) {
        return JsonUtils.toJsonIgnoreNull(service.workspace(input));
    }
}
