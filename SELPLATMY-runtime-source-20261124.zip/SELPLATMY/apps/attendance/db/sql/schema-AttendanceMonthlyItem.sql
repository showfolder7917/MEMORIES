-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceMonthlyItem (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    monthlyId BIGINT NOT NULL,
    itemCode VARCHAR(50) NOT NULL,
    itemName VARCHAR(100) NOT NULL,
    itemValue VARCHAR(100),
    itemOrder INT DEFAULT 0,
    sourceJson CLOB,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deletedFlag TINYINT DEFAULT 0,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0
);
