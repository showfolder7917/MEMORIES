-- 仅结构；不迁入历史身份、组织、秘密或原始请求。
CREATE TABLE IF NOT EXISTS AttendancePunchSourceConfig (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    sourceSystem VARCHAR(50) NOT NULL,
    configName VARCHAR(100) NOT NULL,
    providerType VARCHAR(50) NOT NULL DEFAULT 'CSV',
    enabled INTEGER NOT NULL DEFAULT 0,
    replayEnabled INTEGER NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT uk_AttendancePunchSourceConfig UNIQUE (tenantId,sourceSystem)
);
