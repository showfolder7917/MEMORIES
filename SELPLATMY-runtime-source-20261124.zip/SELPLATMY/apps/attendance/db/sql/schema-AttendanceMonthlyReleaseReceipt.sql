-- 尾回执与CAS/当前指针/审计同事务；旧成功不能复活失效版本。
CREATE TABLE IF NOT EXISTS AttendanceMonthlyReleaseReceipt (
 id BIGINT PRIMARY KEY, tenantId BIGINT NOT NULL, monthlyId BIGINT NOT NULL, employeeId BIGINT NOT NULL,
 lastOperateUserId BIGINT NOT NULL, status INTEGER NOT NULL DEFAULT 1, sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 actionCode VARCHAR(30) NOT NULL, requestKey VARCHAR(100) NOT NULL, fingerprint VARCHAR(64) NOT NULL,
 actorId BIGINT NOT NULL, freezeId BIGINT NOT NULL, sourceVersion BIGINT NOT NULL, freezeHash VARCHAR(64) NOT NULL,
 publicationId BIGINT, resultRevision BIGINT NOT NULL, resultJson CLOB NOT NULL,
 CONSTRAINT uk_AttendanceMonthlyReleaseReceipt_Key UNIQUE(tenantId,actorId,monthlyId,actionCode,requestKey),
 CONSTRAINT fk_AttendanceMonthlyReleaseReceipt_Freeze FOREIGN KEY(tenantId,freezeId,monthlyId,employeeId,sourceVersion,freezeHash) REFERENCES AttendanceMonthlyReview(tenantId,id,monthlyId,employeeId,sourceVersion,freezeHash),
 CONSTRAINT fk_AttendanceMonthlyReleaseReceipt_Publication FOREIGN KEY(tenantId,publicationId,monthlyId,employeeId) REFERENCES AttendanceMonthlyPublication(tenantId,id,monthlyId,employeeId)
);
