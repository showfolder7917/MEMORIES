-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceShiftSchedule (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    workDate DATE NOT NULL,
    shiftTemplateId BIGINT,
    scheduledStartTime TIMESTAMP,
    scheduledEndTime TIMESTAMP,
    scheduledBreakMinutes INT DEFAULT 0,
    workDayType VARCHAR(30) DEFAULT 'WORKDAY',
    businessStatus VARCHAR(30) DEFAULT 'ACTIVE',
    locked TINYINT DEFAULT 0,
    remark VARCHAR(500),
    createdBy BIGINT,
    updatedBy BIGINT,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT uk_AttendanceShiftSchedule UNIQUE (tenantId, employeeId, workDate)
);
