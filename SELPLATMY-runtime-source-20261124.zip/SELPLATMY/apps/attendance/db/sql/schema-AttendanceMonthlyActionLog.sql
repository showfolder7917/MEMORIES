CREATE UNIQUE INDEX IF NOT EXISTS uk_AttendanceMonthly_TenantId ON AttendanceMonthly(tenantId,id);
-- 本域新空结构，沿用旧审批/审计字段语义；无原始记录、口令或身份默认授予。
CREATE TABLE IF NOT EXISTS AttendanceMonthlyActionLog (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    monthlyId BIGINT,
    actionType VARCHAR(30) NOT NULL,
    operatorId BIGINT NOT NULL,
    actionComment VARCHAR(2000),
    snapshotJson CLOB,
    deletedFlag TINYINT DEFAULT 0,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_AttendanceMonthlyActionLog_Monthly FOREIGN KEY (tenantId,monthlyId) REFERENCES AttendanceMonthly(tenantId,id),
    CONSTRAINT uk_AttendanceMonthlyActionLog_TenantId UNIQUE (tenantId,id)
);
