-- 固定员工新增的私有请求槽；记录本身不授予员工写权限。
CREATE TABLE IF NOT EXISTS AttendanceEmployeeCreateRequest (
 id BIGINT PRIMARY KEY, tenantId BIGINT NOT NULL, accountId BIGINT NOT NULL, userId BIGINT NOT NULL,
 requestKey VARCHAR(36) NOT NULL, commandHash VARCHAR(64) NOT NULL, payloadJson VARCHAR(8192) NOT NULL,
 stateCode VARCHAR(20) NOT NULL DEFAULT 'RECORDED', currentAttemptId BIGINT, attemptNo BIGINT NOT NULL DEFAULT 0,
 revision BIGINT NOT NULL DEFAULT 0, lastOperateUserId BIGINT NOT NULL,
 createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 status INTEGER NOT NULL DEFAULT 1, sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 CONSTRAINT uq_employee_create_request UNIQUE(accountId,requestKey),
 CONSTRAINT uq_employee_create_request_tenant UNIQUE(tenantId,id),
 CONSTRAINT ck_employee_create_request_state CHECK(stateCode IN ('RECORDED','COMMITTED')),
 CONSTRAINT ck_employee_create_request_attempt CHECK(attemptNo>=0 AND revision>=0 AND
  ((attemptNo=0 AND currentAttemptId IS NULL) OR (attemptNo>0 AND currentAttemptId IS NOT NULL))),
 CONSTRAINT ck_employee_create_request_status CHECK(status=1)
);
