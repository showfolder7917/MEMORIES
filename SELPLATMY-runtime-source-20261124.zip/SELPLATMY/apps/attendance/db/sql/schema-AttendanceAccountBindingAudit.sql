-- 显式账号绑定审计结构；仅受核验接入安装，不在常规启动自动升级旧库。
CREATE TABLE IF NOT EXISTS AttendanceAccountBindingAudit (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    userId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    revisionNo BIGINT NOT NULL,
    requestKey VARCHAR(64) NOT NULL,
    fingerprint VARCHAR(200) NOT NULL,
    actionCode VARCHAR(20) NOT NULL,
    effectiveAt TIMESTAMP NOT NULL,
    directoryRevision VARCHAR(80) NOT NULL,
    payloadJson CLOB NOT NULL,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenantId,userId,revisionNo),
    UNIQUE(tenantId,userId,requestKey),
    FOREIGN KEY(tenantId,userId) REFERENCES AttendanceEmployeeAccount(tenantId,userId),
    FOREIGN KEY(tenantId,employeeId) REFERENCES AttendanceEmployee(tenantId,id)
);
