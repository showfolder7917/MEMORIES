-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceShiftTemplate (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    revision BIGINT NOT NULL DEFAULT 0,
    referenceLocked TINYINT NOT NULL DEFAULT 0,
    effectiveFromDate DATE,
    templateCode VARCHAR(50) NOT NULL,
    templateName VARCHAR(200) NOT NULL,
    shiftType VARCHAR(30) NOT NULL,
    startTime VARCHAR(20),
    endTime VARCHAR(20),
    crossDay TINYINT DEFAULT 0,
    scheduledBreakMinutes INT DEFAULT 0,
    color VARCHAR(30),
    isActive TINYINT DEFAULT 1,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT uk_AttendanceShiftTemplate UNIQUE (tenantId, templateCode)
);

-- 旧行生效日期未知保持NULL，不伪造历史版本边界。
ALTER TABLE AttendanceShiftTemplate ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 0;
ALTER TABLE AttendanceShiftTemplate ADD COLUMN IF NOT EXISTS referenceLocked TINYINT NOT NULL DEFAULT 0;
ALTER TABLE AttendanceShiftTemplate ADD COLUMN IF NOT EXISTS effectiveFromDate DATE;
