-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendancePunchRawLog (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT,
    externalEmployeeId VARCHAR(100),
    sourceSystem VARCHAR(50) NOT NULL,
    sourceEventId VARCHAR(100),
    punchTime TIMESTAMP NOT NULL,
    punchType VARCHAR(30) NOT NULL,
    deviceId VARCHAR(100),
    deviceName VARCHAR(200),
    rawPayload CLOB,
    importBatchId BIGINT,
    processStatus VARCHAR(30) DEFAULT 'PENDING',
    errorMessage VARCHAR(500),
    ignoredReason VARCHAR(500),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT uk_AttendancePunchRawLog UNIQUE (tenantId, sourceSystem, sourceEventId)
);
