-- 待配置模型，无业务授权种子；PENDING 行不能用于放行。
CREATE TABLE IF NOT EXISTS AttendanceEmployeeAccount (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    userId BIGINT NOT NULL,
    configurationStatus VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    employeeId BIGINT NOT NULL,
    FOREIGN KEY (tenantId, employeeId) REFERENCES AttendanceEmployee(tenantId, id),
    UNIQUE (tenantId, userId)
);
