CREATE UNIQUE INDEX IF NOT EXISTS uk_AttendanceDaily_TenantEmployee ON AttendanceDaily(tenantId,id,employeeId);
-- 本域新空结构，沿用旧审批/审计字段语义；无原始记录、口令或身份默认授予。
CREATE TABLE IF NOT EXISTS AttendanceCase (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    attendanceDailyId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    workplaceId BIGINT,
    departmentId BIGINT,
    caseType VARCHAR(40) NOT NULL,
    caseStatus VARCHAR(30) NOT NULL,
    applicantId BIGINT NOT NULL,
    applicantRole VARCHAR(20) NOT NULL,
    currentApproverId BIGINT,
    reasonCategory VARCHAR(40),
    reasonText VARCHAR(2000),
    expectedResolution VARCHAR(2000),
    patchPayloadJson CLOB,
    dailyBeforeJson CLOB,
    revision BIGINT NOT NULL DEFAULT 0,
    submittedAt TIMESTAMP,
    approvedAt TIMESTAMP,
    rejectedAt TIMESTAMP,
    lockedAt TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_AttendanceCase_Daily FOREIGN KEY (tenantId,attendanceDailyId,employeeId) REFERENCES AttendanceDaily(tenantId,id,employeeId),
    CONSTRAINT uk_AttendanceCase_TenantId UNIQUE (tenantId,id)
);

-- 历史案件不伪造申请快照；默认修订0，生产结构升级需数据库owner接入。
ALTER TABLE AttendanceCase ADD COLUMN IF NOT EXISTS dailyBeforeJson CLOB;
ALTER TABLE AttendanceCase ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 0;
