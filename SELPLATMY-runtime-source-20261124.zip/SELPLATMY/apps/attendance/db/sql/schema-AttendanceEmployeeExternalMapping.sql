-- 仅结构；不迁入历史身份、组织、秘密或原始请求。
CREATE TABLE IF NOT EXISTS AttendanceEmployeeExternalMapping (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    sourceSystem VARCHAR(50) NOT NULL,
    externalEmployeeId VARCHAR(100) NOT NULL,
    externalEmployeeNo VARCHAR(100),
    mappingStatus VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    configurationStatus VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    verifiedBy BIGINT,
    verifiedAt TIMESTAMP,
    revokedBy BIGINT,
    revokedAt TIMESTAMP,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0
);
