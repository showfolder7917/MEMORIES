-- 旧结构字段；无原始记录，业务状态与软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceCalcLog (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    workDate DATE NOT NULL,
    attendanceDailyId BIGINT,
    triggerType VARCHAR(30) NOT NULL,
    triggerRefId BIGINT,
    calcStatus VARCHAR(30) NOT NULL,
    stepName VARCHAR(100) NOT NULL,
    stepMessage VARCHAR(1000),
    payloadJson CLOB,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- 公共软删除保留旧计算日志并记录失效时间，不修改计算结果或历史分钟。
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0
);
