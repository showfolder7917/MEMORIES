-- 待配置模型，无业务授权种子；PENDING 行不能用于放行。
CREATE TABLE IF NOT EXISTS AttendanceAccessGrant (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    userId BIGINT NOT NULL,
    configurationStatus VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    roleCode VARCHAR(20) NOT NULL,
    scopeCode VARCHAR(20) NOT NULL,
    departmentId BIGINT,
    employeeId BIGINT,
    expiresAt TIMESTAMP,
    UNIQUE (tenantId, userId, roleCode, scopeCode)
);
-- 结构补充不创建真实用户许可；旧管理/审批行保持员工范围为空。
ALTER TABLE AttendanceAccessGrant ADD COLUMN IF NOT EXISTS employeeId BIGINT;
