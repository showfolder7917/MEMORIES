-- 批量排班成功尾回执与审计，不存原始历史数据，不提供客户端直接CRUD写入。
CREATE TABLE IF NOT EXISTS AttendanceScheduleBatch (
 id BIGINT PRIMARY KEY,
 tenantId BIGINT NOT NULL,
 requestKey VARCHAR(100) NOT NULL,
 fingerprint VARCHAR(64) NOT NULL,
 rowCount INT NOT NULL,
 resultJson CLOB NOT NULL,
 createdBy BIGINT NOT NULL,
 lastOperateUserId BIGINT NOT NULL,
 sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 labelZh VARCHAR(200), labelJa VARCHAR(200), labelEn VARCHAR(200),
 status INTEGER NOT NULL DEFAULT 1,
 createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT uk_AttendanceScheduleBatch UNIQUE(tenantId,createdBy,requestKey)
);
