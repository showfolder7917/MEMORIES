-- 本域新空结构，沿用旧审批/审计字段语义；无原始记录、口令或身份默认授予。
CREATE TABLE IF NOT EXISTS AttendanceCaseActionLog (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    attendanceCaseId BIGINT NOT NULL,
    actionType VARCHAR(30) NOT NULL,
    operatorId BIGINT NOT NULL,
    operatorRole VARCHAR(20) NOT NULL,
    actionComment VARCHAR(2000),
    beforeSnapshotJson CLOB,
    afterSnapshotJson CLOB,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_AttendanceCaseActionLog_Case FOREIGN KEY (tenantId,attendanceCaseId) REFERENCES AttendanceCase(tenantId,id),
    CONSTRAINT uk_AttendanceCaseActionLog_TenantId UNIQUE (tenantId,id)
);
