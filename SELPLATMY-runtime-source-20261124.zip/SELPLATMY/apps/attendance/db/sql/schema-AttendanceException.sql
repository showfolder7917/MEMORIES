-- 旧结构字段；无原始记录，业务状态与软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceException (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    workDate DATE NOT NULL,
    attendanceDailyId BIGINT,
    exceptionType VARCHAR(50) NOT NULL,
    exceptionLevel VARCHAR(30) DEFAULT 'WARN',
    businessStatus VARCHAR(30) DEFAULT 'OPEN',
    message VARCHAR(500),
    suggestedAction VARCHAR(100),
    resolved TINYINT DEFAULT 0,
    resolvedBy BIGINT,
    resolvedAt TIMESTAMP,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0
);
