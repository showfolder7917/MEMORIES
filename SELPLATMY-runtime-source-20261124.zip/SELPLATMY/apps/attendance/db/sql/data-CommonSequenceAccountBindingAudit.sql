-- 显式核验绑定审计结构后才安装技术号段；不在常规启动自动运行，不修改旧游标。
INSERT INTO CommonSequenceSegment(tenantId,lastOperateUserId,seqCode,seqName,nextStartId,stepSize,versionNo,sortnum,status)
SELECT 1,1,'AttendanceAccountBindingAuditId','AttendanceAccountBindingAudit主键号段',100001,1000,0,43,1
WHERE EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=SCHEMA() AND TABLE_NAME='AttendanceAccountBindingAudit')
AND NOT EXISTS(SELECT 1 FROM CommonSequenceSegment WHERE seqCode='AttendanceAccountBindingAuditId');
