-- 通用考勤人员；不复制学生为雇员，不迁入原业务记录。
CREATE TABLE IF NOT EXISTS AttendancePerson (
    id BIGINT PRIMARY KEY CHECK(id>0),
    code VARCHAR(100) NOT NULL UNIQUE,
    tenantId BIGINT NOT NULL CHECK(tenantId>0),
    lastOperateUserId BIGINT NOT NULL CHECK(lastOperateUserId>0),
    personNumber VARCHAR(100) NOT NULL,
    numberKey VARCHAR(100) NOT NULL,
    personName VARCHAR(100) NOT NULL,
    personKind VARCHAR(30) NOT NULL CHECK(personKind IN('STUDENT','TEACHER','STAFF','OTHER')),
    personState VARCHAR(30) NOT NULL CHECK(personState IN('ACTIVE','INACTIVE')),
    creationRequestKey VARCHAR(36) NOT NULL,
    creationHash VARCHAR(64) NOT NULL,
    changeHistoryJson TEXT NOT NULL,
    versionNo BIGINT NOT NULL CHECK(versionNo>=0),
    labelZh VARCHAR(200),
    labelJa VARCHAR(200),
    labelEn VARCHAR(200),
    status INTEGER NOT NULL DEFAULT 1 CHECK(status IN(0,1)),
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    createdAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(tenantId,id),
    UNIQUE(tenantId,numberKey),
    UNIQUE(tenantId,creationRequestKey)
);
COMMENT ON TABLE AttendancePerson IS '独立通用考勤人员档案，学生与雇佣档案分离';
COMMENT ON COLUMN AttendancePerson.id IS '公共AttendancePersonId号段主键';
COMMENT ON COLUMN AttendancePerson.code IS '服务端不可变人员编码';
COMMENT ON COLUMN AttendancePerson.tenantId IS '实际有效租户';
COMMENT ON COLUMN AttendancePerson.lastOperateUserId IS '真实最后操作账号';
COMMENT ON COLUMN AttendancePerson.personNumber IS '租户人员编号，空输入由号段生成';
COMMENT ON COLUMN AttendancePerson.numberKey IS '规范小写人员编号，租户内唯一';
COMMENT ON COLUMN AttendancePerson.personName IS '显示姓名，不作为跨系统关联依据';
COMMENT ON COLUMN AttendancePerson.personKind IS '人员用途，不是登录角色';
COMMENT ON COLUMN AttendancePerson.personState IS '独立业务状态，停用保留历史';
COMMENT ON COLUMN AttendancePerson.creationRequestKey IS '租户内创建原请求UUID';
COMMENT ON COLUMN AttendancePerson.creationHash IS '创建正文摘要，原键重试不重复建人';
COMMENT ON COLUMN AttendancePerson.changeHistoryJson IS '完整追加原请求、前后值、真实操作人及原结果版本';
COMMENT ON COLUMN AttendancePerson.versionNo IS '人员资料版本';
COMMENT ON COLUMN AttendancePerson.labelZh IS '中文显示名';
COMMENT ON COLUMN AttendancePerson.labelJa IS '日文显示名';
COMMENT ON COLUMN AttendancePerson.labelEn IS '英文显示名';
COMMENT ON COLUMN AttendancePerson.status IS '有效记录标志，业务停用使用personState';
COMMENT ON COLUMN AttendancePerson.sortnum IS '显示顺序';
COMMENT ON COLUMN AttendancePerson.createdAt IS '首次建立时间';
COMMENT ON COLUMN AttendancePerson.updatedAt IS '最后修改时间';

-- 兼容旧通用人员，原行默认为未关联；员工拥有方仍保留原资料和考勤记录。
ALTER TABLE AttendancePerson ADD COLUMN IF NOT EXISTS employeeId BIGINT;
-- 关联仅允许教师与职员用途，学生不能借人员档案变成员工。
ALTER TABLE AttendancePerson ADD CONSTRAINT IF NOT EXISTS ck_AttendancePerson_employee CHECK(employeeId IS NULL OR (employeeId>0 AND personKind IN('TEACHER','STAFF')));
-- 一个原员工只对应一份通用人员，停用保留原关系，不允许另建第二人。
CREATE UNIQUE INDEX IF NOT EXISTS uk_AttendancePerson_employee ON AttendancePerson(tenantId,employeeId);
-- 真实同租户外键保护原员工编号，不按显示姓名推断关系。
ALTER TABLE AttendancePerson ADD CONSTRAINT IF NOT EXISTS fk_AttendancePerson_employee FOREIGN KEY(tenantId,employeeId) REFERENCES AttendanceEmployee(tenantId,id);
COMMENT ON COLUMN AttendancePerson.employeeId IS '明确关联原员工稳定编号，未关联为空；同租户一人一员工，不按姓名合并';
