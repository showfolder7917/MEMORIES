-- 仅新空隔离库或已具账本库初始化；来源为真实CLOSE审计，不生成历史来源版本。
CREATE UNIQUE INDEX IF NOT EXISTS uk_AttendanceMonthly_ReleaseOwner ON AttendanceMonthly(tenantId,id,employeeId);
CREATE UNIQUE INDEX IF NOT EXISTS uk_AttendanceMonthlyActionLog_ReleaseOwner ON AttendanceMonthlyActionLog(tenantId,id,monthlyId);
CREATE TABLE IF NOT EXISTS AttendanceMonthlyReview (
 id BIGINT PRIMARY KEY, tenantId BIGINT NOT NULL, monthlyId BIGINT NOT NULL, employeeId BIGINT NOT NULL,
 lastOperateUserId BIGINT NOT NULL, status INTEGER NOT NULL DEFAULT 1, sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 sourceVersion BIGINT NOT NULL, freezeHash VARCHAR(64) NOT NULL, payloadJson CLOB NOT NULL,
 activeMonthlyId BIGINT, reviewStatus VARCHAR(20) NOT NULL, revision BIGINT NOT NULL DEFAULT 0,
 preparedBy BIGINT NOT NULL, reviewedBy BIGINT, reviewedAt TIMESTAMP, invalidatedAt TIMESTAMP, invalidationReason VARCHAR(2000),
 CONSTRAINT uk_AttendanceMonthlyReview_Freeze UNIQUE(tenantId,id,monthlyId,employeeId,sourceVersion,freezeHash),
 CONSTRAINT uk_AttendanceMonthlyReview_Current UNIQUE(tenantId,activeMonthlyId),
 CONSTRAINT ck_AttendanceMonthlyReview_Current CHECK(activeMonthlyId IS NULL OR activeMonthlyId=monthlyId),
 CONSTRAINT fk_AttendanceMonthlyReview_Monthly FOREIGN KEY(tenantId,monthlyId,employeeId) REFERENCES AttendanceMonthly(tenantId,id,employeeId),
 CONSTRAINT fk_AttendanceMonthlyReview_Source FOREIGN KEY(tenantId,sourceVersion,monthlyId) REFERENCES AttendanceMonthlyActionLog(tenantId,id,monthlyId)
);
