-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceRuleConfig (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    revision BIGINT NOT NULL DEFAULT 0,
    referenceLocked TINYINT NOT NULL DEFAULT 0,
    ruleCode VARCHAR(50) NOT NULL,
    ruleName VARCHAR(200) NOT NULL,
    standardDailyMinutes INT NOT NULL,
    standardWeeklyMinutes INT NOT NULL,
    autoBreakEnabled TINYINT DEFAULT 0,
    autoBreakThresholdMinutes INT DEFAULT 0,
    autoBreakDeductMinutes INT DEFAULT 0,
    nightWorkStart VARCHAR(20) NOT NULL,
    nightWorkEnd VARCHAR(20) NOT NULL,
    roundingUnitMinutes INT,
    roundingMode VARCHAR(30),
    monthlyOvertimeAlertHours INT DEFAULT 45,
    yearlyOvertimeAlertHours INT DEFAULT 360,
    paidLeaveReminderEnabled TINYINT DEFAULT 1,
    activeFlag TINYINT DEFAULT 1,
    note VARCHAR(500),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deletedFlag TINYINT DEFAULT 0,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT uk_AttendanceRuleConfig UNIQUE (tenantId, ruleCode)
);

-- 旧行技术修订从0开始；引用保护由真实所属表查询补足，不伪造历史版本。
ALTER TABLE AttendanceRuleConfig ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 0;
ALTER TABLE AttendanceRuleConfig ADD COLUMN IF NOT EXISTS referenceLocked TINYINT NOT NULL DEFAULT 0;
