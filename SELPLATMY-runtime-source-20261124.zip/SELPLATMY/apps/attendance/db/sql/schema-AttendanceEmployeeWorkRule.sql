-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceEmployeeWorkRule (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    employeeId BIGINT NOT NULL,
    ruleId BIGINT,
    workRuleType VARCHAR(30) NOT NULL,
    standardDailyMinutes INT NOT NULL,
    standardWeeklyMinutes INT NOT NULL,
    overtimeEnabled TINYINT DEFAULT 1,
    nightWorkEnabled TINYINT DEFAULT 0,
    holidayWorkEnabled TINYINT DEFAULT 0,
    roundingRuleId BIGINT,
    effectiveStartDate DATE NOT NULL,
    effectiveEndDate DATE,
    ruleNote VARCHAR(500),
    -- 公共更新和软删除的审计字段，与员工工时判定字段独立。
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0
);
