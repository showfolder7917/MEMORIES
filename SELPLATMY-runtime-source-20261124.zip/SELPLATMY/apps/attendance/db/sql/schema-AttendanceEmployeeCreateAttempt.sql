-- 每次尝试保留独立历史，终止旧尝试后不复用其提交检查点。
CREATE TABLE IF NOT EXISTS AttendanceEmployeeCreateAttempt (
 id BIGINT PRIMARY KEY, tenantId BIGINT NOT NULL, requestId BIGINT NOT NULL, attemptNo BIGINT NOT NULL,
 attemptKey VARCHAR(36) NOT NULL UNIQUE, stateCode VARCHAR(20) NOT NULL DEFAULT 'PREPARED',
 employeeId BIGINT, resultJson VARCHAR(16384), receiptHash VARCHAR(64), revision BIGINT NOT NULL DEFAULT 0,
 lastOperateUserId BIGINT NOT NULL, createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, status INTEGER NOT NULL DEFAULT 1,
 sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 CONSTRAINT uq_employee_create_attempt UNIQUE(requestId,attemptNo),
 CONSTRAINT fk_employee_create_attempt_request FOREIGN KEY(tenantId,requestId)
  REFERENCES AttendanceEmployeeCreateRequest(tenantId,id),
 CONSTRAINT fk_employee_create_attempt_employee FOREIGN KEY(tenantId,employeeId) REFERENCES AttendanceEmployee(tenantId,id),
 CONSTRAINT ck_employee_create_attempt_state CHECK(stateCode IN ('PREPARED','ABORTED','COMMITTED')),
 CONSTRAINT ck_employee_create_attempt_receipt CHECK(
  (stateCode='COMMITTED' AND employeeId IS NOT NULL AND resultJson IS NOT NULL AND receiptHash IS NOT NULL)
  OR (stateCode IN ('PREPARED','ABORTED') AND employeeId IS NULL AND resultJson IS NULL AND receiptHash IS NULL)),
 CONSTRAINT ck_employee_create_attempt_revision CHECK(attemptNo>0 AND revision>=0 AND status=1)
);
