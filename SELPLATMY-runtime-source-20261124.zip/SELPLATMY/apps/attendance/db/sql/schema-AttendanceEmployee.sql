-- 从旧结构迁移字段语义；无原始记录，业务字符串状态与共通软删除状态分离。
CREATE TABLE IF NOT EXISTS AttendanceEmployee (
    id BIGINT PRIMARY KEY,
    tenantId BIGINT NOT NULL,
    workplaceId BIGINT,
    departmentId BIGINT,
    employeeNo VARCHAR(50) NOT NULL,
    employeeName VARCHAR(100) NOT NULL,
    employeeNameKana VARCHAR(100),
    gender VARCHAR(20),
    employmentType VARCHAR(30) NOT NULL,
    hireDate DATE,
    resignDate DATE,
    email VARCHAR(100),
    phone VARCHAR(50),
    businessStatus VARCHAR(30) DEFAULT 'ACTIVE',
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lastOperateUserId BIGINT NOT NULL,
    status INTEGER NOT NULL DEFAULT 1,
    sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
    UNIQUE (tenantId, id),
    CONSTRAINT uk_AttendanceEmployee UNIQUE (tenantId, employeeNo)
);
