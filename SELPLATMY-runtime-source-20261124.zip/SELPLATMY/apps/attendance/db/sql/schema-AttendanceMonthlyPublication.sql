-- 不覆写冻结，ACTIVE唯一当前指针；撤回/重开保留失效历史。
CREATE TABLE IF NOT EXISTS AttendanceMonthlyPublication (
 id BIGINT PRIMARY KEY, tenantId BIGINT NOT NULL, monthlyId BIGINT NOT NULL, employeeId BIGINT NOT NULL,
 lastOperateUserId BIGINT NOT NULL, status INTEGER NOT NULL DEFAULT 1, sortnum DECIMAL(10,2) NOT NULL DEFAULT 0,
 createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 freezeId BIGINT NOT NULL, sourceVersion BIGINT NOT NULL, freezeHash VARCHAR(64) NOT NULL,
 activeMonthlyId BIGINT, publicationStatus VARCHAR(20) NOT NULL, revision BIGINT NOT NULL,
 publishedBy BIGINT NOT NULL, publishedAt TIMESTAMP NOT NULL, effectiveAt TIMESTAMP NOT NULL,
 invalidatedBy BIGINT, invalidatedAt TIMESTAMP, invalidationReason VARCHAR(2000),
 CONSTRAINT uk_AttendanceMonthlyPublication_Link UNIQUE(tenantId,id,monthlyId,employeeId),
 CONSTRAINT uk_AttendanceMonthlyPublication_Version UNIQUE(tenantId,monthlyId,revision),
 CONSTRAINT uk_AttendanceMonthlyPublication_Current UNIQUE(tenantId,activeMonthlyId),
 CONSTRAINT ck_AttendanceMonthlyPublication_Current CHECK(activeMonthlyId IS NULL OR activeMonthlyId=monthlyId),
 CONSTRAINT fk_AttendanceMonthlyPublication_Freeze FOREIGN KEY(tenantId,freezeId,monthlyId,employeeId,sourceVersion,freezeHash) REFERENCES AttendanceMonthlyReview(tenantId,id,monthlyId,employeeId,sourceVersion,freezeHash)
);
