/*
 * 员工考勤 SEL UI 装配：panel 负责左中右响应式工作区，grid 负责真实后台页的记录与选择，
 * tooltip 由 Grid 统一提供截断文本提示，personalization 统一皮肤、语言与偏好，window 承载诊断与对象选择，
 * core.element 创建安全业务节点，net.ajax 请求相对接口。
 * panel/tree/tabs 负责页面、导航及记录/编辑区；原生业务内容使用共享 selform，不定义业务 CSS。
 * 真实接口错误直接显示，不以模拟数据替代持久化，不从浏览器身份字段授予权限。
 */
(function app() {
    "use strict";
    window.sel.require(["core.element", "core.query", "core.freeze", "net.ajax", "components.panel", "components.tree", "components.tabs", "components.contextMenu", "components.dropdownMenu", "components.datePicker", "components.form", "components.grid", "components.tooltip", "components.pageBackground", "components.personalization", "components.window"]);
    const selBase = window.sel.core;
    const { freeze: selFreeze } = selBase;
    const { ajax: selAjax } = window.sel.net;
    const { panel, tree, tabs, dropdownMenu: attendanceDropdown, datePicker: attendanceDatePicker, form: formComponent, grid, pageBackground, personalization, window: windowComponent } = window.sel.components;
    const attendanceModules = selFreeze([
        { code: "person", title: "通用人员", fields: [] },
        { code: "classroom", title: "课堂出勤", fields: [] },
        { code: "employee", title: "员工", fields: [["employeeNo", "员工编号"], ["employeeName", "姓名"], ["employmentType", "雇用类型"], ["businessStatus", "在职状态"]] },
        { code: "ruleconfig", title: "计算规则", fields: [["ruleCode", "规则编号"], ["ruleName", "规则名称"], ["roundingMode", "舍入方式"], ["roundingUnitMinutes", "舍入分钟"], ["revision", "配置修订"]] },
        { code: "employeeworkrule", title: "员工规则", fields: [["employeeId", "员工"], ["ruleId", "计算规则"], ["effectiveStartDate", "生效日期"], ["effectiveEndDate", "结束日期"]] },
        { code: "shifttemplate", title: "班次模板", fields: [["templateCode", "班次编号"], ["templateName", "班次名称"], ["shiftType", "班次类型"], ["startTime", "开始时间"], ["endTime", "结束时间"], ["crossDay", "跨日"], ["effectiveFromDate", "生效日期"], ["revision", "配置修订"]] },
        { code: "shiftschedule", title: "排班", fields: [["employeeId", "员工"], ["workDate", "工作日期"], ["scheduledStartTime", "计划开始"], ["scheduledEndTime", "计划结束"], ["locked", "锁定"]] },
        { code: "punchrawlog", title: "原始打卡", fields: [["employeeId", "员工"], ["punchTime", "打卡时间"], ["punchType", "打卡类型"], ["processStatus", "处理状态"]] },
        { code: "daily", title: "日次结果", fields: [["employeeId", "员工"], ["workDate", "工作日期"], ["actualWorkMinutes", "实际分钟"], ["businessStatus", "考勤状态"], ["approvalStatus", "审批状态"]] },
        { code: "attendancecase", title: "补卡与审批", fields: [["id", "处理单主键"], ["attendanceDailyId", "日次记录"], ["employeeId", "员工"], ["caseType", "处理单类型"], ["caseStatus", "处理单状态"], ["reasonText", "申请说明"], ["submittedAt", "提交时间"], ["patchPayloadJson", "已保存审批补丁"]] },
        { code: "monthly", title: "月次报表", fields: [["employeeId", "员工"], ["yearMonth", "月份"], ["totalWorkMinutes", "实际分钟"], ["closeStatus", "月结状态"]] },
        { code: "monthlyrelease", title: "月审核与发布", fields: [["employeeId", "员工"], ["yearMonth", "月份"], ["totalWorkMinutes", "实际分钟"], ["closeStatus", "月结状态"]] },
        { code: "monthlyitem", title: "月次指标", fields: [["monthlyId", "月次报表"], ["itemCode", "指标"], ["itemValue", "值"]] },
        { code: "employeeexternalmapping", title: "外部员工映射", fields: [["sourceSystem", "来源标识"], ["externalEmployeeId", "外部员工标识"], ["employeeId", "员工"], ["configurationStatus", "核准状态"]] },
        { code: "punchsourceconfig", title: "CSV来源", fields: [["sourceSystem", "来源标识"], ["configName", "来源名称"], ["providerType", "来源类型"], ["enabled", "外部连接启用"], ["replayEnabled", "历史重放启用"]] },
        { code: "punchimportbatch", title: "CSV导入批次", fields: [["importKey", "幂等批次键"], ["sourceSystem", "来源标识"], ["importStatus", "导入状态"], ["totalCount", "总行数"], ["successCount", "成功数"], ["duplicateCount", "重复数"], ["unmatchedCount", "未匹配数（含冲突）"], ["conflictCount", "冲突数"], ["errorCount", "格式错误数"], ["resultJson", "逐行处理明细"]] }
    ]);
    let attendancePeople = null;
    let attendanceClassrooms = null;
    let attendanceLocale = selBase.preference.get("selplat.attendance.locale", "zh-CN");
    let attendanceMessages = {};
    let attendanceWindowMessages = {};
    let attendanceDateMessages = {}, attendanceDateSequence = 0;
    const attendanceDates = new Map();
    let attendanceLocaleEpoch = 0;
    let attendanceLastPage = null;
    let attendanceSelectorEntity = null;
    let attendanceBindingWindow = null;
    let attendanceSelectorPage = null;
    const attendanceHost = selBase.query("[data-attendance-app]");
    // 公共 Panel 创建全页外壳和左树；不保留本域 CSS、私有导航按钮或自定视口尺寸。
    const attendancePanel = panel.create(attendanceHost, { gridId: "AttendanceWorkspace", entity: "attendance",
        layoutOptions: { responsive: true, header: "compact", right: "content" }, structure: {
        top: [{ component: "title" }, { component: "selForm", slot: "sessionActions" }], left: [{ component: "selTree" }],
        center: [{ component: "selTabs" }], right: [{ component: "selForm", slot: "details" }], bottom: []
    } });
    const attendanceWorkspaceTabs = tabs.mount(panel.getComponent("AttendanceWorkspace", "selTabs"), {
        id: "AttendanceModuleWorkspace", ariaLabel: "考勤工作区", contextMenu: false
    });
    let attendanceRecordsHost;
    attendanceWorkspaceTabs.open({ id: "workspace", label: "员工", closable: false, mount(host) { attendanceRecordsHost = host; } });
    // 单一列表工作区直接提供常用操作；原表单由公共Window承载，避免再切一层编辑页签。
    const attendanceCenter = attendanceRecordsHost;
    // 业务节点由公共core.element创建，组件外观仍使用已登记SelUI样式。
    function attendanceElement(tag, text, className) { return selBase.element(tag, { text, className }); }
    const attendanceDetailForm = formComponent.mount(panel.getComponent("AttendanceWorkspace", "selForm", "details"), {
        id: "AttendanceContextDetails", slots: ["content"]
    });
    const attendanceRight = attendanceDetailForm.getSlot("content");
    let attendanceNavigation;
    let attendanceConnection = "checking";
    let attendanceSessionEpoch = 0;
    // 新月角色必须来自当前配置；管理/补卡审批不自动获得月动作。
    function attendanceCanRelease() { return !!(attendanceConfiguration?.canReviewMonthly || attendanceConfiguration?.canPublishMonthly || attendanceConfiguration?.canWithdrawMonthly); }
    // 本人每次详情/指标固定同一发布版本，旧选择不能悄悄读取后来发布。
    function attendancePublicationBinding(record) {
        if (!record?.publicationId) return {};
        return { publicationId: record.publicationId, publicationRevision: record.publicationRevision, freezeHash: record.freezeHash };
    }
    // 过期选择/重新核验销毁真实冻结窗口与Grid，迟到结果不能重新挂载。
    function attendanceClearRelease() {
        attendanceReleaseGrid?.destroy(); attendanceReleaseGrid = null;
        attendanceReleaseVersionsForm?.destroy(); attendanceReleaseVersionsForm = null;
        attendanceReleaseWindow?.destroy(); attendanceReleaseWindow = null;
    }
    // 业务详情显示实际版本和独立动作；不代填员工身份、分钟、审核人或发布状态。
    function attendanceRenderRelease(data, epoch, detailEpoch) {
        const ruleNotice = attendanceUiElement("p", "规则来源须核验：未配置规则仍保留历史兜底算法；零加班、月结或发布状态不代表工时口径已审核。不得用当前规则覆盖历史快照。");
        ruleNotice.setAttribute("role", "status"); ruleNotice.dataset.attendanceRuleWarning = "true"; attendanceDetail.append(ruleNotice);
        const facts = [["月份", data.monthly.yearMonth], ["员工", attendanceDisplayValue("employeeId", data.monthly.employeeId, data.monthly)], ["实际分钟", data.monthly.totalWorkMinutes], ["月结操作人", data.monthly.closedBy], ["来源月结版本", data.sourceVersion], ["审核状态", data.review?.reviewStatus === "PENDING" ? "待月审核" : data.review?.reviewStatus === "APPROVED" ? "月审核已通过" : "尚未准备冻结"], ["当前发布修订", data.publicationRevision], ["发布状态", data.publication ? "已发布（立即生效）" : "尚未发布"]];
        facts.forEach(([label, value]) => { const line = attendanceElement("div"); line.append(attendanceUiElement("dt", label), attendanceElement("dd", attendanceText(String(value ?? "—")))); attendanceDetail.append(line); });
        attendanceDetail.append(attendanceUiElement("p", "审核人必须不同于本次月结操作人；审核与发布各需独立许可。"));
        for (const [action, label, permission, available] of [
            ["prepare-review", "准备审核快照", "canReviewMonthly", !!data.source && !data.review],
            ["approve-review", "审核此冻结版本", "canReviewMonthly", data.review?.reviewStatus === "PENDING" && String(data.monthly.closedBy) !== String(attendanceConfiguration.userId)],
            ["publish", "发布已审核版本", "canPublishMonthly", data.review?.reviewStatus === "APPROVED" && !data.publication],
            ["withdraw", "撤回当前发布", "canWithdrawMonthly", !!data.publication]
        ]) if (attendanceConfiguration?.[permission]) {
            const button = attendanceButton(label, () => attendanceOpenRelease(action, data, permission, epoch, detailEpoch)); button.disabled = !available; attendanceDetail.append(button);
        }
    }
    // 使用公共Window/Grid预览完整实际指标；令牌只关联服务端冻结，用户不能编辑工资/工时结果。
    function attendanceOpenRelease(action, data, permission, epoch, detailEpoch) {
        if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch || !attendanceConfiguration?.[permission]) return;
        attendanceClearRelease();
        const labels = { "prepare-review": ["准备审核快照", "冻结并送审"], "approve-review": ["审核此冻结版本", "确认审核"], publish: ["发布已审核版本", "确认发布"], withdraw: ["撤回当前发布", "确认撤回"] };
        const snapshot = action === "prepare-review" ? data.source : JSON.parse(data.review.payloadJson);
        const content = attendanceElement("section", undefined, "selform-root");
        content.append(attendanceElement("p", attendanceText("{month} · {minutes}分钟；月结操作人：{actor}", { month: snapshot.monthly.yearMonth, minutes: snapshot.monthly.totalWorkMinutes, actor: snapshot.monthly.closedBy })), attendanceUiElement("p", action === "publish" ? "确认后按服务器提交时间立即生效。本人只能读取这一审核冻结版本。" : action === "withdraw" ? "撤回后旧版本的下一次读取被拒绝；请明确填写原因。" : "请核对下列冻结指标；保存时重新核验来源版本、职责与当前许可。"));
        const versions = attendanceElement("details"); versions.append(attendanceUiElement("summary", "版本核验"));
        // 完整版本值交给公共Form；不按业务固定字符数切片或决定摘要换行。
        const versionHost = attendanceElement("div"); versions.append(versionHost);
        attendanceReleaseVersionsForm = formComponent.mount(versionHost, { id: "AttendanceMonthlyReleaseVersions", fields: [
            { id: "freezeId", label: attendanceText("冻结主键"), value: String(data.review?.id ?? "—"), readOnly: true },
            { id: "sourceVersion", label: attendanceText("来源月结版本"), value: String(snapshot.sourceVersion), readOnly: true },
            { id: "freezeHash", label: attendanceText("冻结摘要"), value: String(data.review?.freezeHash ?? data.sourceHash), type: "textarea", readOnly: true }
        ] }); content.append(versions);
        const host = attendanceElement("div"); content.append(host);
        const form = attendanceElement("form", undefined, "selform-root"); form.dataset.attendanceCommand = `/api/attendance/monthlyrelease/${action}.htm`; form.dataset.attendanceReleaseForm = action;
        // 真实随机请求键只用于重复提交防护，窗口重试保留原键；不充当业务结果或身份。
        const payload = { monthlyId: data.monthly.id, requestKey: crypto.randomUUID() };
        if (action === "prepare-review") Object.assign(payload, { expectedSourceVersion: data.sourceVersion, expectedSourceHash: data.sourceHash });
        else Object.assign(payload, { freezeId: data.review.id, freezeHash: data.review.freezeHash, sourceVersion: data.review.sourceVersion });
        if (action === "approve-review") payload.expectedReviewRevision = data.review.revision;
        if (["publish", "withdraw"].includes(action)) payload.expectedPublicationRevision = data.publicationRevision;
        if (action === "withdraw") { payload.publicationId = data.publication.id; attendanceField(form, "撤回原因", "reason", "textarea", true); form.elements.namedItem("reason").maxLength = 2000; }
        const submit = attendanceButton(labels[action][1]); submit.type = "submit"; submit.setAttribute("data-tone", "primary");
        const cancel = attendanceButton("取消编辑", () => attendanceReleaseWindow?.close()); form.append(submit, cancel); content.append(form);
        attendanceReleaseWindow = windowComponent.mount(attendanceWindowHost, { id: "AttendanceMonthlyRelease", title: attendanceText(labels[action][0]), closeLabel: attendanceText("关闭月审核发布窗口"), messages: attendanceWindowMessages, content, showActions: false });
        const root = grid.create(host, { gridId: "AttendanceMonthlyFrozenItems", entity: "attendance", ariaLabel: attendanceText("冻结月报指标") });
        attendanceReleaseGrid = grid.mount(root, { select: attendancePageSizeOptions(), grid: { mode: "records", selectionMode: "NONE", idField: "id", horizontalScroll: true }, title: { text: attendanceText("冻结月报指标") }, column: { items: [["itemCode", "指标"], ["itemName", "指标名称"], ["itemValue", "值"]].map(([field, label]) => ({ field, label: attendanceText(label), width: 150 })) }, data: { items: snapshot.items.map(record => ({ ...record, itemName: attendanceDisplayValue("itemName", record.itemName) })) }, pagination: { mode: "LOCAL", currentPage: 1, pageSize: 20, totalCount: snapshot.items.length } });
        let pending = false;
        form.addEventListener("submit", async event => {
            event.preventDefault(); if (pending || epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch || !attendanceConfiguration?.[permission] || !form.reportValidity()) return;
            pending = true; submit.disabled = true; cancel.disabled = true; form.setAttribute("aria-busy", "true");
            try {
                const saved = await selAjax.request({ url: form.dataset.attendanceCommand, method: "POST", data: { ...payload, ...attendanceData(form) } });
                if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                const reloaded = await attendanceLoad(); if (reloaded && attendanceModule.code === "monthlyrelease") { await attendanceShowDetail(data.monthly.id); attendanceFeedback("月动作已保存并重新读取当前状态。"); } else attendanceFeedback("操作已保存，但结果未重新读取。请查询核验。", true);
                if (!saved.success) throw new Error("月动作返回无效。");
            } catch (error) {
                if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                attendanceReleaseWindow?.setFeedback(attendanceText(error.message), true); attendanceFeedback(error.message, true);
                try { const current = await selAjax.request({ url: "/api/attendance/access/configuration.htm" }); if (epoch === attendanceEpoch && !current.data?.[permission]) await attendanceCheckSession(); } catch { if (epoch === attendanceEpoch) await attendanceCheckSession(); }
            } finally { pending = false; form.setAttribute("aria-busy", "false"); if (form.isConnected) { submit.disabled = !attendanceConfiguration?.[permission]; cancel.disabled = false; } }
        });
        attendanceReleaseWindow.open();
    }
    // 当前单段批草稿/预览使用公共Grid实例，切换模块销毁。
    let attendanceBatchCommand = null;
    // 左树内容是固定业务模块目录，不是伪造员工/考勤记录，也不带授权或记录计数。
    function attendanceNavigationData() {
        const groups = [["teaching", "教学出勤", attendanceModules.filter(module => module.code === "classroom")], ["people", "员工与规则", attendanceModules.filter(module => ["person", "employee", "ruleconfig", "employeeworkrule", "shifttemplate", "employeeexternalmapping"].includes(module.code))],
            ["work", "排班与打卡", attendanceModules.filter(module => ["shiftschedule", "punchrawlog", "punchsourceconfig", "punchimportbatch"].includes(module.code))],
            ["results", "计算与报表", attendanceModules.filter(module => ["daily", "attendancecase", "monthly", "monthlyitem", "monthlyrelease"].includes(module.code))]];
        return { heading: attendanceText("考勤工作区"), ariaLabel: attendanceText("员工考勤模块"), summary: attendanceText("员工考勤与教学学生出勤分别管理。"),
            selectedId: attendanceModule?.code || "employee", expandLabelTemplate: attendanceText("展开{label}"), collapseLabelTemplate: attendanceText("收起{label}"), showCounts: false, draggable: false,
            items: groups.map(([id, label, modules]) => [id, label, !attendanceConfiguration?.canManage
                ? modules.filter(module => ["person", "classroom"].includes(module.code) || (module.code === "attendancecase" && (attendanceConfiguration?.canApprove || attendanceConfiguration?.employeeMapped))
                    || (module.code === "daily" && attendanceConfiguration?.employeeMapped)
                    || (module.code === "monthly" && attendanceConfiguration?.canReadOwnMonthly)
                    || (module.code === "monthlyrelease" && attendanceCanRelease())) : modules.filter(module => module.code !== "monthlyrelease" || attendanceCanRelease())])
                .filter(([, , modules]) => modules.length).map(([id, label, modules]) => ({ id, label: attendanceText(label), icon: "ri-folder-line", expanded: true,
                children: modules.map(module => ({ id: module.code, label: attendanceText(module.title), icon: "ri-file-list-3-line" })) })) };
    }
    // 公共标题动作由显式业务回调处理；页面不访问或改写组件样式和内部布局。
    function attendancePanelView() {
        return { title: { title: attendanceText("员工考勤"), subtitle: attendanceText("考勤工作区"), description: attendanceText("规则、排班与原始打卡，连接已保存的日次和月次结果。"),
            actions: [], statusTabs: [] },
            tree: attendanceNavigationData(), select: {} };
    }
    let attendanceModule = attendanceModules.find(module => module.code === "employee");
    let attendanceConfiguration = null;
    let attendanceGrid = null;
    let attendanceEpoch = 0;
    let attendanceDetailEpoch = 0;
    let attendanceOwnMonthlyGrid = null;
    let attendanceApprovalWindow = null;
    let attendanceApprovalGrid = null;
    let attendanceReleaseWindow = null;
    let attendanceReleaseGrid = null;
    let attendanceReleaseVersionsForm = null;
    // 表单目标只来自最新真实详情；待处理请求不能因重复点击重新发出。
    const attendanceCommandForms = new Map();
    let attendanceLastDiagnostic = "尚无错误记录。";
    let attendanceFeedbackArguments = null;
    const attendanceDrafts = new Map();
    let attendanceSelectorWindow = null;
    let attendanceSelectorGrid = null;
    let attendanceDiagnosticWindow = null;
    // 会话与诊断属于公共工具栏；overlay槽不占布局空间，窗口层级仍由公共Window负责。
    const attendanceSessionActions = formComponent.mount(panel.getComponent("AttendanceWorkspace", "selForm", "sessionActions"), {
        id: "AttendanceSessionActions", layout: "toolbar", actions: [
            { id: "reload", label: "重新核验会话" }, { id: "diagnostic", label: "诊断" }
        ], slots: [{ id: "overlay", layout: "overlay" }]
    });
    attendanceSessionActions.getAction("reload").addEventListener("click", () => attendanceCheckSession());
    attendanceSessionActions.getAction("diagnostic").addEventListener("click", () => attendanceOpenDiagnostic());
    const attendanceWindowHost = attendanceSessionActions.getSlot("overlay");
    // 现有公共背景控制器交给个性化控件组合，不自建皮肤或语言入口。
    const attendanceBackground = pageBackground.mount(selBase.query("[data-attendance-background]"), { defaults: { theme: "solid-light", overlay: 0, brightness: 100, blur: 0 } });
    let attendancePersonalization = null;
    const attendanceQuery = attendanceElement("form", undefined, "selform-root");
    attendanceQuery.dataset.selFormLayout = "toolbar";
    const attendanceGridHost = attendanceElement("div", undefined);
    const attendanceStateCard = attendanceElement("section", undefined, "selform-root");
    const attendanceStateTitle = attendanceUiElement("h2", "正在核验当前会话…");
    const attendanceStatus = attendanceElement("p"); attendanceStatus.setAttribute("data-attendance-status", ""); attendanceStatus.setAttribute("aria-live", "polite");
    const attendanceStateDescription = attendanceElement("p");
    attendanceStateCard.append(attendanceStateTitle, attendanceStatus, attendanceStateDescription);
    const attendanceDetailTitle = attendanceUiElement("h2", "记录详情");
    const attendanceDetail = attendanceElement("dl", undefined);
    const attendanceCommandHost = attendanceElement("div");
    const attendanceCommandActions = attendanceElement("nav");
    Object.assign(attendanceCommandActions.style, {display:"flex",flexWrap:"wrap",gap:"8px"});
    const attendanceContext = attendanceElement("p");
    attendanceRight.append(attendanceDetailTitle, attendanceContext, attendanceDetail);
    // 列表和Window均显示实际操作结果，失败不留在隐藏工作区。
    const attendanceOperationStatus = attendanceStatus; attendanceOperationStatus.setAttribute("data-attendance-operation-status", "");
    attendanceCenter.append(attendanceStateCard, attendanceQuery, attendanceCommandHost, attendanceGridHost);
    // 建立业务动作按钮；文本用于可访问名称，处理函数仅在用户点击时执行。
    function attendanceButton(text, handler) {
        const button = attendanceUiElement("button", text, "selform-action"); button.type = "button";
        if (handler) button.addEventListener("click", handler);
        return button;
    }
    // 向原生业务表单追加带标签字段；必填和正整数输入由浏览器约束，权限仍由后台核验。
    function attendanceField(form, label, name, type = "text", required = false) {
        if (["employeeId", "shiftTemplateId", "ruleId", "roundingRuleId"].includes(name)) return attendanceReferenceField(form, label, name, name === "employeeId" ? "employee" : name === "shiftTemplateId" ? "shifttemplate" : "ruleconfig");
        const field = attendanceElement("label", undefined, "selform-field"); field.append(attendanceUiElement("span", label));
        if (["actionType", "finalStatus"].includes(name)) {
            const select = attendanceElement("select"); select.name = name; select.required = required;
            const choices = name === "actionType" ? [["APPROVE", "通过并确认最终值"], ["RETURN", "退回补充"], ["REJECT", "驳回"]]
                : [["", "沿用当前状态"], ["NORMAL", "正常出勤"], ["LATE", "迟到"], ["EARLY_LEAVE", "早退"], ["ABSENCE", "缺勤"], ["MISSING_CLOCK_IN", "缺上班卡"], ["MISSING_CLOCK_OUT", "缺下班卡"], ["HOLIDAY_WORK", "休日出勤"]];
            choices.forEach(([value, text]) => { const option = attendanceUiElement("option", text); option.value = value; select.append(option); });
            field.append(select); form.append(field); return select;
        }
        if (["roundingMode", "autoBreakEnabled", "paidLeaveReminderEnabled", "activeFlag", "crossDay", "isActive", "overtimeEnabled", "nightWorkEnabled", "holidayWorkEnabled"].includes(name)) {
            const select = attendanceElement("select"); select.name = name; select.required = required;
            const choices = name === "roundingMode" ? [["NONE", "不舍入"], ["ROUND_DOWN", "向下舍入"], ["ROUND_UP", "向上舍入"], ["ROUND_NEAREST", "四舍五入"]] : [["0", "关闭"], ["1", "开启"]];
            choices.forEach(([value, text]) => { const option = attendanceUiElement("option", text); option.value = value; option.defaultSelected = value === ((["paidLeaveReminderEnabled", "activeFlag", "isActive"].includes(name)) ? "1" : (name === "roundingMode" ? "NONE" : "0")); select.append(option); });
            field.append(select); form.append(field); return select;
        }
        if (name === "punchType") {
            const select = attendanceElement("select"); select.name = name; select.required = required; select.setAttribute("aria-label", attendanceText(label)); select.dataset.attendanceAria = label;
            [["CLOCK_IN", "上班"], ["CLOCK_OUT", "下班"], ["BREAK_START", "休息开始"], ["BREAK_END", "休息结束"]].forEach(([value, text]) => {
                const option = attendanceUiElement("option", text); option.value = value; select.append(option);
            }); field.append(select); form.append(field); return select;
        }
        const input = attendanceElement(type === "textarea" ? "textarea" : "input"); input.name = name;
        if (type === "textarea") { input.rows = 8; input.maxLength = 1000000; }
        else input.type = type;
        input.required = required;
        if (type === "number") { input.min = name === "finalBreakMinutes" || name.endsWith("Minutes") || name.endsWith("Hours") ? "0" : "1"; input.step = "1"; }
        if (type === "time" && ["nightWorkStart", "nightWorkEnd", "startTime", "endTime"].includes(name)) input.step = "any";
        if (type === "checkbox") input.value = "true";
        field.append(input); form.append(field);
        if (type === "date") attendanceRefreshDates(form);
        return input;
    }
    // 更新唯一状态区及告警语义；输入真实请求信息，不把失败显示为已完成。
    function attendanceFeedback(message, error = false, parameters = null) {
        attendanceFeedbackArguments = parameters ? { message, error, parameters } : null;
        if (parameters) message = attendanceText(message, { ...parameters, object: attendanceText(parameters.object) });
        if (error) attendanceLastDiagnostic = message;
        const businessMessage = message.split(" · ")[0];
        const safeErrors = ["月发布账本尚未初始化，请联系管理员核验接入。", "月发布动作必须明确。", "当前月动作的独立许可尚未配置或已失效。", "月发布版本已变化，请重新读取。", "月冻结内容读取失败。", "月审核发布当前状态已核验。", "请求键已用于不同月动作，请重新核验。", "月结来源已变化，请正式重开核对后重新审核。", "月审核人必须不同于本次月结操作人。", "请先由另一位月审核人完成该冻结版本审核。", "原回执对应版本已失效，请重新读取当前状态。", "请先完成无阻断月结后再审核发布。", "缺少可核对的本次月结来源审计，不能发布历史推定版本。", "月动作的主键与版本参数必须有效。", "撤回原因必须明确填写。", "同一员工同一日期不能重复，请修改输入。", "批量排班输入无效，请检查请求键、员工、日期、模板修订及1001行上限。", "批量排班存在冲突，请重新预览并修改。", "请求键已用于不同排班内容，请返回修改并重新预览。", "当前日次已有活动处理单。", "考勤审批授权尚未配置。", "员工账号映射尚未核验。", "考勤记录不存在、失效或无权访问。", "审批补丁格式无效。", "请先选择真实记录。", "本人月报读取许可尚未核验。", "本人月快照不可访问。", "本人月报月份必须有效。", "处理单已更新，请刷新对比后再决定。", "计算规则配置已更新，请重新选择后再编辑。", "计算规则配置已被引用，请新建规则并明确关联生效日期。", "计算规则配置参数无效，请检查整数、开关、夜间时间和舍入方式。", "班次模板已更新，请重新选择后再编辑。", "班次模板已被排班引用，请新建模板并明确生效日期。", "班次模板参数无效，请检查时间、跨日、休息分钟和生效日期。", "班次结束时间必须晚于开始时间；夜班请明确选择跨日。", "休息分钟不能超过班次时段总分钟。", "新班次模板必须明确生效日期。", "班次模板在所选工作日期尚未生效。", "班次模板时区无效。", "班次模板仅保存本地时间，当前不支持模板时区换算。", "班次模板当前只支持单工作时段和休息分钟总量，不支持分段或重叠休息段。", "班次模板编号已存在，请使用独立新编号。", "班次模板已停用。", "该月份已结或已有效发布，请先正式重开月份后再修改。", "员工规则关联归属已变化，请刷新后再修改。", "月结范围已变化，请重新查询后再结月。", "员工规则关联必须选择真实员工。", "已结月快照不能直接重算，请先正式重开月份。", "所选规则修订已变化，请重新选择实际规则。", "请从真实列表选择员工和计算规则。", "结束日期不能早于生效日期。", "请选择员工并填写生效日期。"];
        const displayed = error && safeErrors.includes(businessMessage) ? businessMessage : error && !message.startsWith("有效期存在") && !["考勤接口不可用，记录尚未加载。", "尚未登录，请先登录统一认证。"].includes(message) && !message.includes("配置") ? "暂时无法完成此操作，请重试或查看诊断信息。" : message;
        attendanceStatus.dataset.attendanceText = displayed;
        attendanceStatus.textContent = attendanceText(displayed);
        attendanceStatus.setAttribute("role", error ? "alert" : "status");
        attendanceOperationStatus.dataset.attendanceText = displayed;
        attendanceOperationStatus.textContent = attendanceText(displayed);
        attendanceOperationStatus.setAttribute("role", error ? "alert" : "status");
        for (const command of [...attendanceCommandForms.values(), attendanceBatchCommand].filter(Boolean)) {
            if (command.window?.getState().open) {
                command.windowFeedback = {text:attendanceText(displayed),error};
                command.window.setFeedback(command.windowFeedback.text,error);
            }
        }
    }
    // 采集当前业务表单非空字段；没有员工映射或角色生成，后台覆盖租户和操作员。
    function attendanceData(form) { return Object.fromEntries(Array.from(new FormData(form)).filter(([, value]) => value !== "")); }
    // 所有共享表格复用同一三语分页配置，不修改SELUI默认值或内部节点。
    function attendancePageSizeOptions() { return { pageSize: { ariaLabel: attendanceText("每页显示行数"), options: [10, 20, 50, 100].map(size => ({ value: String(size), label: attendanceText("{size}行/页", { size }) })) } }; }
    // 仅改变展示：状态来自真实记录；员工名称缺失时明确保留员工编号，不推定姓名。
    function attendanceDisplayValue(field, value, record = {}) {
        if (field === "itemName") return attendanceText(value);
        if (field === "employeeId") return record.employeeName ? [record.employeeName, record.employeeNo].filter(Boolean).join(" · ") : `${attendanceText("员工")} ${value ?? "—"}`;
        const states = {
            closeStatus: {OPEN:"未结月",CLOSABLE:"可结月",CLOSED:"已结月",REOPENED:"已重开"},
            publicationStatus: {DRAFT:"草稿",PUBLISHED:"已发布",WITHDRAWN:"已撤回",ACTIVE:"有效",INVALIDATED:"已失效"},
            reviewStatus: {PENDING:"待审核",APPROVED:"已审核",INVALIDATED:"已失效"},
            attendanceStatus: {NORMAL:"正常",LATE:"迟到",EARLY_LEAVE:"早退",ABSENT:"缺勤",ABSENCE:"缺勤",MISSING_PUNCH:"缺卡",PAID_LEAVE:"有薪休假",REST:"休息",NO_SCHEDULE:"未排班"},
            approvalStatus: {NONE:"未申请",PENDING:"待审核",APPROVED:"已审核",REJECTED:"已拒绝"},
            processStatus: {PROCESSED:"已处理",PENDING:"待处理",FAILED:"处理失败"},
            punchType: {CLOCK_IN:"上班",CLOCK_OUT:"下班",BREAK_START:"休息开始",BREAK_END:"休息结束"},
            businessStatus: {ACTIVE:"在职",INACTIVE:"离职",NORMAL:"正常",LATE:"迟到",EARLY_LEAVE:"早退",ABSENT:"缺勤",ABSENCE:"缺勤",MISSING_PUNCH:"缺卡",PAID_LEAVE:"有薪休假",REST:"休息",NO_SCHEDULE:"未排班"},
            roundingMode: {NONE:"不舍入",ROUND_DOWN:"向下舍入",ROUND_UP:"向上舍入",ROUND_NEAREST:"四舍五入"},
            workRuleType: {STANDARD:"标准工时"}, shiftType: {DAY:"日班",REST:"休息",PAID_LEAVE:"有薪休假",SPECIAL_LEAVE:"特殊休假",ABSENCE:"缺勤"}
        };
        return states[field]?.[value] ? attendanceText(states[field][value]) : value;
    }
    // 把实际 CommonPageResult 投影为 SEL UI REMOTE 契约；保持当前后台页和 totalCount，不再筛选或截页。
    function attendancePayload(page, module = attendanceModule) {
        // 长逐行明细只在所选记录详情呈现；完整记录仍保留，列表列使用已实现的公共宽表能力。
        const columns = attendanceFields(module).filter(([field]) => !["resultJson", "patchPayloadJson"].includes(field))
            .map(([field, label]) => ({ field, label: attendanceText(label), width: field === "importKey" ? 210 : 150 }));
        return { grid: { mode: "records", selectionMode: "SINGLE", idField: "id", horizontalScroll: true, minTableWidth: 0 },
            select: attendancePageSizeOptions(),
            title: { text: module.title, messages: { selectProject: attendanceText("选择记录"), noResults: attendanceText("当前条件没有记录") } },
            column: { resizeLabelTemplate: attendanceText("调整 {label} 列宽"), title: attendanceText(module.title), ariaLabel: attendanceText(module.title), items: columns },
            data: { items: page.records.map(record => Object.fromEntries(Object.entries(record).map(([field, value]) => [field, attendanceDisplayValue(field, value, record)]))) }, pagination: { mode: "REMOTE", currentPage: page.pageNo, pageSize: page.pageSize, totalCount: page.totalCount,
                previousLabel: attendanceText("上一页"), nextLabel: attendanceText("下一页"), ariaLabel: attendanceText("记录分页"), summaryAll: attendanceText("当前 {visible} 条，共 {total} 条"), summaryFiltered: attendanceText("当前 {visible} 条，共 {total} 条") } };
    }
    // 自助月报只展示发布事实和本人汇总，管理月结字段不进入自助视图。
    function attendanceFields(module) {
        if (module.code !== "monthly" || attendanceConfiguration?.canManage) return module.fields;
        return [["yearMonth", "月份"], ["publicationStatus", "发布状态"], ["publishedAt", "发布时间"],
            ["effectiveAt", "生效时间"], ["totalWorkMinutes", "实际分钟"], ["scheduledDays", "计划天数"],
            ["attendanceDays", "出勤天数"], ["normalDays", "正常天数"], ["lateCount", "迟到次数"],
            ["earlyLeaveCount", "早退次数"], ["missingPunchCount", "缺卡次数"], ["absenceCount", "缺勤次数"],
            ["exceptionDays", "异常天数"], ["overtimeMinutes", "加班分钟"], ["legalOvertimeMinutes", "法定加班分钟"],
            ["nightWorkMinutes", "夜间分钟"], ["holidayWorkMinutes", "假日分钟"], ["paidLeaveDays", "有薪休假天数"], ["restDays", "休息天数"]];
    }
    // 公共 Grid 的生命周期由其 destroy 管理，业务不复制组件或修改内部节点。
    function attendanceClearOwnMonthlyMetrics() {
        attendanceOwnMonthlyGrid?.destroy(); attendanceOwnMonthlyGrid = null;
    }
    // 所选本人月快照的真实指标分页；固定 monthlyId，没有任意全表下载或原始 sourceJson。
    async function attendanceLoadOwnMonthlyMetrics(id, epoch, detailEpoch, pageNo = 1, pageSize = 20, binding = {}) {
        const page = await selAjax.request({ url: "/api/attendance/monthlyitem/ownedStore.htm", method: "POST", data: { monthlyId: id, pageNo, pageSize, ...binding } });
        if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
        if (!Array.isArray(page.records) || !Number.isFinite(Number(page.totalCount))) throw new Error("记录接口未返回有效分页结果。");
        const module = { code: "monthlyitem", title: "本人月报指标", fields: [["itemCode", "指标"], ["itemName", "指标名称"], ["itemValue", "值"]] };
        const payload = attendancePayload(page, module); payload.grid.selectionMode = "NONE";
        if (!attendanceOwnMonthlyGrid) {
            attendanceDetail.append(attendanceUiElement("p", "仅显示已发布并生效的本人月快照。"));
            const host = attendanceElement("div"); attendanceDetail.append(host);
            const root = grid.create(host, { gridId: "AttendanceOwnMonthlyMetrics", entity: "attendance", ariaLabel: attendanceText("本人月报指标") });
            attendanceOwnMonthlyGrid = grid.mount(root, payload);
            root.addEventListener("selGrid:queryChange", event => {
                attendanceLoadOwnMonthlyMetrics(id, epoch, detailEpoch, event.detail.pageNo, event.detail.pageSize, binding).catch(async error => {
                    if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                    attendanceClearOwnMonthlyMetrics(); attendanceDetail.replaceChildren(); attendanceFeedback(error.message, true);
                    await attendanceCheckSession();
                });
            });
        } else attendanceOwnMonthlyGrid.setLocale(payload);
    }
    // 可读范围由真实配置决定；本人仅日次及案件，审批仅案件，不授予管理CRUD。
    function attendanceCanRead(module) {
        if (module.code === "monthlyrelease") return attendanceCanRelease();
        return attendanceConfiguration?.canManage === true
            || (module.code === "monthly" && attendanceConfiguration?.canReadOwnMonthly === true)
            || (module.code === "attendancecase" && attendanceConfiguration?.canApprove === true)
            || (["daily", "attendancecase"].includes(module.code) && attendanceConfiguration?.employeeMapped === true);
    }
    // 不同权限使用已实现的独立服务入口；本人URL不携带或选择其他员工身份。
    function attendanceReadEndpoint(detail = false) {
        if (attendanceModule.code === "monthlyrelease") return detail ? "current" : "getStore";
        if (attendanceConfiguration?.canManage === true) return detail ? "getById" : "getStore";
        if (attendanceModule.code === "attendancecase" && attendanceConfiguration?.canApprove === true) return detail ? "reviewDetail" : "reviewStore";
        return detail ? "ownedDetail" : "ownedStore";
    }
    // 仅当前管理会话按本页真实员工主键读取安全显示名；去重并限制并发，不下载全目录或跨身份缓存姓名。
    async function attendanceResolveEmployees(page, epoch) {
        if (attendanceConfiguration?.canManage !== true) return page;
        const ids = [...new Set(page.records.filter(row => row.employeeId != null && !row.employeeName).map(row => String(row.employeeId)))];
        if (!ids.length) return page;
        if (ids.length > 100 || ids.some(id => !/^[1-9][0-9]*$/.test(id))) throw new Error(attendanceText("员工来源编号无效。"));
        const names = new Map();
        for (let start = 0; start < ids.length; start += 5) {
            await Promise.all(ids.slice(start, start + 5).map(async id => {
                const found = await selAjax.request({url:"/api/attendance/employee/getStore.htm",method:"POST",data:{id,pageNo:1,pageSize:1}});
                if (epoch !== attendanceEpoch) return;
                if (!Array.isArray(found.records) || found.records.length > 1 || Number(found.totalCount) !== found.records.length) throw new Error(attendanceText("员工来源查询结果无效。"));
                const row = found.records[0];
                if (!row) return;
                if (String(row.id) !== id || typeof row.employeeName !== "string" || typeof row.employeeNo !== "string") throw new Error(attendanceText("员工来源查询结果无效。"));
                names.set(id, {employeeName:row.employeeName,employeeNo:row.employeeNo});
            }));
            if (epoch !== attendanceEpoch) return page;
        }
        return {...page,records:page.records.map(row => ({...row,...names.get(String(row.employeeId))}))};
    }
    // 按当前模块和业务筛选请求真实后台页；过期响应丢弃，失败隐藏旧数据并告警，不生成假记录。
    async function attendanceLoad(pageNo = 1, pageSize = 20) {
        const epoch = ++attendanceEpoch;
        ++attendanceDetailEpoch; attendanceClearRelease(); attendanceClearOwnMonthlyMetrics(); attendanceDetail.replaceChildren();
        attendanceInvalidateCaseTarget();
        if (!attendanceCanRead(attendanceModule)) { attendanceFeedback("当前会话尚无已核验的考勤管理配置。", true); return; }
        const data = { ...attendanceData(attendanceQuery), pageNo, pageSize };
        attendanceFeedback("正在读取{object}…", false, { object: attendanceModule.title });
        attendanceGridHost.hidden = true;
        try {
            const page = await selAjax.request({ url: `/api/attendance/${attendanceModule.code}/${attendanceReadEndpoint()}.htm`, method: "POST", data });
            if (epoch !== attendanceEpoch) return;
            if (!Array.isArray(page.records) || !Number.isFinite(Number(page.totalCount))) throw new Error("记录接口未返回有效分页结果。");
            const displayedPage = await attendanceResolveEmployees(page, epoch);
            if (epoch !== attendanceEpoch) return;
            attendanceLastPage = displayedPage;
            const payload = attendancePayload(displayedPage);
            if (!attendanceGrid) {
                const root = grid.create(attendanceGridHost, { gridId: "AttendanceWorkspaceRecords", entity: "attendance", ariaLabel: attendanceModule.title });
                attendanceGrid = grid.mount(root, payload);
                if (!attendanceGrid) throw new Error("共享表格挂载失败。");
                root.addEventListener("selGrid:queryChange", event => attendanceLoad(event.detail.pageNo, event.detail.pageSize));
                root.addEventListener("selGrid:selectionChange", event => attendanceShowDetail(event.detail.selectedIds[0]));
            } else { attendanceGrid.setLocale(payload); }
            attendanceGridHost.hidden = false;
            if (attendanceModule.code === "monthly" && !attendanceConfiguration?.canManage && page.totalCount === 0) attendanceFeedback("暂无已发布并生效的本人月快照。");
            else attendanceFeedback("{object}已读取，共 {total} 条。", false, { object: attendanceModule.title, total: page.totalCount });
            return true;
        } catch (error) {
            if (epoch === attendanceEpoch) {
                attendanceLastPage = null; attendanceGrid?.destroy(); attendanceGrid = null;
                attendanceGridHost.replaceChildren(); attendanceFeedback(error.message, true);
                if (attendanceModule.code === "monthly" && !attendanceConfiguration?.canManage) await attendanceCheckSession();
            }
            return false;
        }
    }
    // 按共享选择事件主键读取真实同租户详情；模块切换后丢弃旧响应，仅月次提供已保存报表下载。
    async function attendanceShowDetail(id) {
        const epoch = attendanceEpoch;
        const detailEpoch = ++attendanceDetailEpoch;
        attendanceClearRelease(); attendanceClearOwnMonthlyMetrics(); attendanceBindingWindow?.destroy(); attendanceBindingWindow = null; attendanceDetail.replaceChildren();
        attendanceInvalidateCaseTarget();
        if (!id) return;
        try {
            const selected = attendanceLastPage?.records.find(row => String(row.id) === String(id));
            const bindings = attendanceModule.code === "monthly" && !attendanceConfiguration?.canManage ? attendancePublicationBinding(selected) : {};
            const result = await selAjax.request({ url: `/api/attendance/${attendanceModule.code}/${attendanceReadEndpoint(true)}.htm`, method: "POST", data: attendanceModule.code === "monthlyrelease" ? { monthlyId: id } : { id, ...bindings } });
            if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
            if (attendanceModule.code === "monthlyrelease") { attendanceRenderRelease(result.data, epoch, detailEpoch); return; }
            const detailPage = await attendanceResolveEmployees({records:[result.data]}, epoch);
            if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
            attendanceFields(attendanceModule).forEach(([field, label]) => {
                const line = attendanceElement("div"); line.append(attendanceUiElement("dt", label), attendanceElement("dd", attendanceDisplayValue(field, result.data[field], detailPage.records[0]) ?? "—")); attendanceDetail.append(line);
            });
            // 实际日次保存的规则主键是历史来源；没有命中规则时显著提示，不把零加班推定为正式审核结论。
            if (attendanceModule.code === "daily") {
                const warning = attendanceUiElement("p", result.data.appliedRuleId == null
                    ? "未配置生效规则：当前工时按历史兜底计算；零加班不代表已审核，请先核验规则来源。"
                    : "生效规则来自已保存日次：{ruleId}；修改当前关联不会自动改变这条历史快照。", undefined, { ruleId: result.data.appliedRuleId });
                warning.setAttribute("role", "status"); warning.dataset.attendanceRuleEvidence = result.data.appliedRuleId == null ? "MISSING" : "SAVED";
                attendanceDetail.prepend(warning);
            }
            if (attendanceModule.code === "employee" && attendanceConfiguration?.canManage) {
                attendanceDetail.append(attendanceButton("修改员工资料", () => {
                    attendancePrepareCommand("/api/attendance/employee/update.htm", {...result.data}, result.data);
                    attendanceOpenCommand("/api/attendance/employee/update.htm");
                }), attendanceButton("管理员工账号绑定", () => attendanceOpenBinding(result.data)));
            }
            if (attendanceModule.code === "shifttemplate" && attendanceConfiguration?.canManage) {
                attendanceDetail.append(attendanceButton("编辑所选班次模板", () => {
                    attendancePrepareCommand("/api/attendance/shifttemplate/update.htm", { ...result.data }, result.data);
                    attendanceOpenCommand("/api/attendance/shifttemplate/update.htm");
                }));
                attendanceDetail.append(attendanceUiElement("p", result.data.configurationProtected ? "班次模板已被排班引用，请新建模板并明确生效日期。" : "未引用模板可编辑；新模板须明确生效日期。"));
            }
            if (attendanceModule.code === "ruleconfig" && attendanceConfiguration?.canManage) {
                attendanceDetail.append(attendanceButton("编辑所选规则", () => {
                    attendancePrepareCommand("/api/attendance/ruleconfig/update.htm", { ...result.data }, result.data);
                    attendanceOpenCommand("/api/attendance/ruleconfig/update.htm");
                }));
                attendanceDetail.append(attendanceUiElement("p", result.data.configurationProtected ? "计算规则配置已被引用，请新建规则并明确关联生效日期。" : "未引用规则可编辑；保存须核对当前修订。"));
            }
            if (attendanceModule.code === "employeeworkrule" && attendanceConfiguration?.canManage) {
                const values = { ...result.data };
                for (const [field, entity] of [["employeeId", "employee"], ["ruleId", "ruleconfig"], ["roundingRuleId", "ruleconfig"]]) {
                    if (values[field] == null) continue;
                    const reference = await selAjax.request({ url: `/api/attendance/${entity}/getById.htm`, method: "POST", data: { id: values[field] } });
                    if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                    values[`${field}Label`] = attendanceReferenceLabel(entity, reference.data);
                    if (entity === "ruleconfig") values[`${field}Revision`] = reference.data.revision;
                }
                attendanceDetail.append(attendanceButton("编辑所选员工规则关联", () => {
                    attendancePrepareCommand("/api/attendance/employeeworkrule/update.htm", values, result.data);
                    attendanceOpenCommand("/api/attendance/employeeworkrule/update.htm");
                }));
                attendanceDetail.append(attendanceButton("继续排班", () => attendanceSelect(attendanceModules.find(module => module.code === "shiftschedule"))));
                attendanceDetail.append(attendanceUiElement("p", "关联保存不重算已保存日月。规则版本被引用后不能原地修改；关联有效期重叠沿用旧优先级。"));
            }
            if (attendanceModule.code === "attendancecase" && attendanceConfiguration?.canApprove) {
                // 审批只带入实际案件与已保存补丁，不伪造尚未开放给审批人的日次原值。
                attendancePrepareCommand("/api/attendance/attendancecase/action.htm", { id: result.data.id }, result.data);
                attendanceDetail.append(attendanceButton("审批所选处理单", () => {
                    attendancePrepareCommand("/api/attendance/attendancecase/action.htm", { id: result.data.id }, result.data);
                    attendanceOpenApproval();
                }));
            }
            if (attendanceModule.code === "daily" && !attendanceConfiguration?.canManage && attendanceConfiguration?.employeeMapped) {
                // 从实际本人所选日次发起申请；服务仍复核归属，页面不写审批或计算结果。
                attendanceDetail.append(attendanceButton("申请补卡", () => {
                    attendanceSelect(attendanceModules.find(module => module.code === "attendancecase"));
                    attendancePrepareCommand("/api/attendance/attendancecase/submit.htm", { attendanceDailyId: id }, result.data);
                    const field = attendanceCommandForms.get("/api/attendance/attendancecase/submit.htm")?.form.querySelector('[name="reasonText"]');
                    attendanceOpenCommand("/api/attendance/attendancecase/submit.htm"); field?.focus();
                }));
            }
            if (attendanceModule.code === "monthly" && attendanceConfiguration?.canManage) {
                attendanceDetail.append(attendanceButton("下载已保存月报 CSV", () => attendanceExport(id)));
            }
            if (attendanceModule.code === "monthly" && !attendanceConfiguration?.canManage) {
                await attendanceLoadOwnMonthlyMetrics(id, epoch, detailEpoch, 1, 20, attendancePublicationBinding(result.data));
            }
        } catch (error) {
            if (epoch === attendanceEpoch && detailEpoch === attendanceDetailEpoch) {
                attendanceClearOwnMonthlyMetrics(); attendanceDetail.replaceChildren(); attendanceFeedback(error.message, true);
                if (attendanceModule.code === "monthly" && !attendanceConfiguration?.canManage) await attendanceCheckSession();
            }
        }
    }
    // 审批编辑放入已登记公共Window，关闭和取消只隐藏窗口，不清除草稿或发业务请求。
    function attendanceOpenApproval() {
        const command = attendanceCommandForms.get("/api/attendance/attendancecase/action.htm");
        if (!command?.record) return;
        if (!attendanceApprovalWindow) {
            const content = attendanceElement("section", undefined, "selform-root");
            command.comparison = attendanceElement("div"); content.append(command.comparison, command.form);
            attendanceApprovalWindow = windowComponent.mount(attendanceWindowHost, { id: "AttendanceApprovalComparison", title: attendanceText("审批时间与规则对比"), closeLabel: attendanceText("关闭审批窗口"), messages: attendanceWindowMessages, content, showActions: false });
        }
        attendanceApprovalWindow.open(); attendancePreviewApproval();
    }
    // 当前编辑草稿只发给只读预览，时间/分钟/规则差异全部来自服务端真实算法。
    async function attendancePreviewApproval(explicit = false) {
        const command = attendanceCommandForms.get("/api/attendance/attendancecase/action.htm");
        if (!command?.record || !command.comparison) return;
        const epoch = attendanceEpoch; const recordId = command.record.id;
        const request = (command.previewRequest || 0) + 1; command.previewRequest = request;
        const patch = {}; const values = attendanceData(command.form);
        ["actualClockIn", "actualClockOut", "finalBreakMinutes", "finalStatus", "finalExceptionFlag"].forEach(field => { if (values[field] !== undefined) patch[field] = values[field]; });
        try {
            const result = await selAjax.request({ url: "/api/attendance/attendancecase/preview.htm", method: "POST", data: { id: recordId, revision: values.revision, patchPayloadJson: JSON.stringify(patch) } });
            if (epoch !== attendanceEpoch || request !== command.previewRequest || recordId !== command.record.id) return;
            const facts = result.data;
            if (explicit) { command.targetReady = true; command.submit.disabled = command.pending || !attendanceConfiguration?.canApprove; }
            const fields = [["actualClockIn", "上班时间", "finalClockIn"], ["actualClockOut", "下班时间", "finalClockOut"], ["actualBreakMinutes", "扣休分钟", "finalBreakMinutes"], ["actualWorkMinutes", "实际分钟"], ["normalWorkMinutes", "正常分钟"], ["overtimeMinutes", "加班分钟"], ["nightWorkMinutes", "夜间分钟"], ["appliedRuleId", "计算规则"]];
            const records = fields.map(([field, label, proposed]) => ({ id: field, field: attendanceText(label), before: facts.beforeAvailable ? String(facts.before?.[field] ?? "—") : attendanceText("申请时快照缺失"), current: String(facts.current?.[proposed || field] ?? facts.current?.[field] ?? "—"), proposed: String(facts.proposed?.[proposed || field] ?? "—") }));
            const rule = facts.rule || {};
            command.ruleExplanation = { id: facts.revision, code: rule.ruleCode || "—", name: rule.ruleName || "—", rounding: rule.roundingMode || "—", unit: rule.roundingUnitMinutes ?? "—", standard: rule.standardDailyMinutes ?? "—" };
            attendanceApprovalGrid?.destroy(); attendanceApprovalGrid = null; command.comparison.replaceChildren();
            const explanation = attendanceElement("p", attendanceText("修订：{revision}；规则：{code} {name}；舍入：{rounding}/{unit}；标准分钟：{standard}", { revision: facts.revision, ...command.ruleExplanation }));
            command.comparison.append(explanation, attendanceUiElement("p", "对比来自服务端计算，保存时重新核验并重算。"));
            const host = attendanceElement("div"); command.comparison.append(host);
            const root = grid.create(host, { gridId: "AttendanceApprovalDifferences", entity: "attendance", ariaLabel: attendanceText("审批时间与规则对比") });
            attendanceApprovalGrid = grid.mount(root, { select: attendancePageSizeOptions(), grid: { mode: "records", selectionMode: "NONE", idField: "id", horizontalScroll: true }, title: { text: attendanceText("审批时间与规则对比") }, column: { items: [["field", "字段"], ["before", "申请时"], ["current", "当前日次"], ["proposed", "服务端重算草稿"]].map(([field,label]) => ({ field, label: attendanceText(label), width: 150 })) }, data: { items: records }, pagination: { mode: "LOCAL", currentPage: 1, pageSize: 20, totalCount: records.length } });
        } catch (error) {
            if (epoch === attendanceEpoch && request === command.previewRequest) {
                attendanceApprovalGrid?.destroy(); attendanceApprovalGrid = null; command.comparison.replaceChildren(attendanceElement("p", error.message)); attendanceFeedback(error.message, true);
            }
        }
    }
    // 查询/取消选择/新的详情尚未返回时，旧审批目标不可继续使用；正在发送的请求不改写输入。
    function attendanceInvalidateCaseTarget() {
        const command = attendanceCommandForms.get("/api/attendance/attendancecase/action.htm");
        if (command && !command.pending) { command.targetReady = false; command.submit.disabled = true; command.form.elements.namedItem("id").value = ""; }
    }
    // 当前记录建立命令目标；切换案件清空上一案件草稿，不沿用别人的最终分钟。
    function attendancePrepareCommand(path, values, record) {
        const command = attendanceCommandForms.get(path);
        if (!command || command.pending) return;
        // 同一案件重新打开窗口保留草稿；切换不同案件才清理上一目标。
        if (command.record?.id !== record?.id || path === "/api/attendance/shifttemplate/update.htm" || path === "/api/attendance/employeeworkrule/update.htm") { command.form.reset(); attendanceDrafts.delete(command.draftKey); }
        if (path.endsWith("action.htm")) values = { ...values, revision: record.revision };
        Object.entries(values).forEach(([name, value]) => { const input = command.form.elements.namedItem(name); if (input) input.value = value == null ? "" : String(value); });
        command.form.querySelectorAll("[data-attendance-display]").forEach(input => { input.value = values[input.dataset.attendanceDisplay] || ""; });
        for (const field of ["ruleId", "roundingRuleId"]) { const input = command.form.elements.namedItem(field); if (input && values[`${field}Revision`] !== undefined) input.dataset.attendanceRevision = String(values[`${field}Revision`]); }
        if (record && command.context) {
            command.record = record;
            command.context.textContent = path === "/api/attendance/employee/update.htm"
                ? attendanceText("所选员工：{name}；编号：{code}", {name: record.employeeName, code: record.employeeNo}) : path === "/api/attendance/shifttemplate/update.htm"
                ? attendanceText("所选模板：{code}；修订：{revision}", { code: record.templateCode, revision: record.revision }) : path === "/api/attendance/ruleconfig/update.htm"
                ? attendanceText("所选规则：{code}；修订：{revision}", { code: record.ruleCode, revision: record.revision }) : path.includes("/employeeworkrule/") ? attendanceText("所选关联：{id}；生效：{start}；结束：{end}", { id: record.id, start: record.effectiveStartDate, end: record.effectiveEndDate || "—" }) : path.endsWith("action.htm")
                ? attendanceText("所选处理单：{id}；状态：{state}；申请说明：{reason}", { id: record.id, state: attendanceText(record.caseStatus), reason: record.reasonText || "—" })
                : attendanceText("所选日次：{id}；日期：{date}；实际分钟：{minutes}", { id: record.id, date: record.workDate, minutes: record.actualWorkMinutes });
        }
        if (path === "/api/attendance/shifttemplate/update.htm") command.form.elements.namedItem("effectiveFromDate").required = record?.effectiveFromDate != null;
        command.targetReady = !["/api/attendance/ruleconfig/update.htm", "/api/attendance/shifttemplate/update.htm"].includes(path) || record?.configurationProtected !== true;
        command.submit.disabled = !attendanceConfiguration?.[command.permission] || !command.targetReady;
        if (["/api/attendance/ruleconfig/update.htm", "/api/attendance/shifttemplate/update.htm"].includes(path)) {
            if (!command.targetReady) attendanceFeedback(path.includes("shifttemplate") ? "班次模板已被排班引用，请新建模板并明确生效日期。" : "计算规则配置已被引用，请新建规则并明确关联生效日期。", true);
            command.form.querySelectorAll("input, select, textarea").forEach(input => { input.disabled = !command.targetReady; });
        }
        attendanceRefreshDropdowns(command.form);
        command.form.dispatchEvent(new Event("input", { bubbles: true }));
    }
    // 取得服务端保存的月报 CSV 并下载；不在浏览器重新计算分钟，失败仅显示后台错误。
    async function attendanceExport(id) {
        try {
            const result = await selAjax.request({ url: "/api/attendance/report/monthly-export.htm", method: "POST", data: { id } });
            const file = new Blob(["\uFEFF", result.data.content], { type: "text/csv;charset=utf-8" });
            const url = URL.createObjectURL(file); const link = attendanceElement("a"); link.href = url; link.download = result.data.fileName; link.click(); URL.revokeObjectURL(url);
            attendanceFeedback("已下载持久化月次快照。");
        } catch (error) { attendanceFeedback(error.message, true); }
    }
    // 标准日期仍由原input提交；公开月历只提供选择、语言、焦点及释放，不重算业务日期。
    function attendanceRefreshDates(scope) {
        scope.querySelectorAll('input[type="date"]').forEach(input => {
            let controller = attendanceDates.get(input);
            const label = input.closest("label")?.querySelector("span");
            const text = attendanceText(label?.dataset.attendanceText || label?.textContent || input.name);
            if (!controller) {
                const host = attendanceElement("span", undefined, "seldatepicker-root");
                host.dataset.selDatePicker = ""; input.id ||= "attendanceDateField" + (++attendanceDateSequence);
                input.classList.add("seldatepicker-native");input.before(host);host.append(input);
                host.dataset.selDatePickerLabel = text;host.dataset.selDatePickerPlaceholder = "YYYY-MM-DD";
                controller = attendanceDatePicker.mount(host, {locale:attendanceLocale,messages:attendanceDateMessages});
                attendanceDates.set(input,controller);
                input.addEventListener("invalid", event => {event.preventDefault();controller.focus();controller.open();});
            }
            controller.setLocale({locale:attendanceLocale,messages:attendanceDateMessages,label:text,placeholder:"YYYY-MM-DD"});
            controller.refresh();
        });
    }
    // 保留原select及其表单归属；公共下拉显示菜单，原input草稿和排班预览监听继续生效。
    function attendanceRefreshDropdowns(form) {
        form.querySelectorAll("select").forEach(select => {
            let root = select.parentElement;
            if (!root.matches("[data-attendance-command-dropdown]")) {
                const label = select.closest("label")?.querySelector("span");
                root = attendanceElement("div", undefined, "seldropdown-root");
                root.setAttribute("data-sel-dropdown-menu", "");
                root.dataset.attendanceCommandDropdown = label?.dataset.attendanceText || label?.textContent || select.name;
                root.setAttribute("data-sel-dropdown-menu-current-template", "{label}：{value}");
                select.before(root); root.append(select);
                select.addEventListener("change", () => select.dispatchEvent(new Event("input", {bubbles:true})));
            }
            root.setAttribute("data-sel-dropdown-menu-label", attendanceText(root.dataset.attendanceCommandDropdown));
            attendanceDropdown.mount(root); attendanceDropdown.setLocale(select);
        });
        attendanceRefreshDates(form);
    }
    // 操作入口只收起原表单；每次显示一个业务窗口，不复制字段、监听或提交命令。
    function attendanceRegisterCommandWindow(title, path, form, actions, command) {
        command.title = title; command.path = path; command.actions = actions;
        command.key = path.replace(/\.htm$/, "").split("/").filter(Boolean).slice(-2)
            .flatMap(part=>part.split("-")).map(part=>part[0].toUpperCase()+part.slice(1)).join("");
        const parking = attendanceElement("section"); parking.hidden = true;parking.append(form);
        const launch = attendanceButton(title, () => attendanceOpenCommand(path));
        launch.dataset.attendanceOpenCommand = path;
        launch.setAttribute("data-tone", "primary");
        command.launch = launch;command.parking = parking;
        if (!command.selectedTarget) attendanceCommandActions.append(launch);
        attendanceCommandHost.append(parking); attendanceRefreshDropdowns(form);
    }
    // 原生业务表单保留唯一form关联，移到固定底栏的原保存按钮仍提交同一表单。
    function attendanceOpenCommand(path) {
        const command = path === "batchSchedule" ? attendanceBatchCommand : attendanceCommandForms.get(path);
        if (!command || !attendanceConfiguration?.[command.permission || "canManage"]) return;
        if (path === "/api/attendance/attendancecase/action.htm") {
            if (!command.record) {attendanceFeedback("请先选择真实记录。", true);return;}
            attendanceOpenApproval();return;
        }
        const all = [...attendanceCommandForms.values(), attendanceBatchCommand].filter(Boolean);
        if (all.some(other => other !== command && other.pending)) {attendanceFeedback("当前操作仍在处理中，请等待结果。", true);return;}
        for (const other of all) if (other !== command) other.window?.close();
        if (!command.window) {
            const content = attendanceElement("section", undefined, "selform-scroll-content"), footer = attendanceElement("nav");
            Object.assign(footer.style, {display:"flex",flexWrap:"wrap",gap:"8px"});
            const nativeFormId = "attendanceNativeCommand" + command.key + "Id";
            // 名为id的业务字段会遮蔽HTMLFormElement.id；用独立字符串关联底栏原按钮。
            command.form.setAttribute("id", nativeFormId);
            command.form.dataset.selFormLayout = "toolbar";command.form.classList.add("selform-surface-only");
            command.form.querySelector("h3").hidden = true;
            for (const action of command.actions) {action.setAttribute("form", nativeFormId);footer.append(action);}
            content.append(command.form);
            command.window = windowComponent.mount(attendanceWindowHost, {
                id: "selWindowAttendance" + command.key + "Id",
                title: attendanceText(command.title), content, footerContent: footer, rows: [],
                surface: "reading", headerLayout: "content", closeLabel: attendanceText("关闭操作窗口"), messages: attendanceWindowMessages
            });
            command.window.setDefaultGeometry(path.includes("/employee/")
                ? {width:720,height:500,minWidth:360,minHeight:360}
                : {width:800,height:740,minWidth:360,minHeight:480});
            command.window.setSubmitState({hidden:true});
        }
        attendanceRefreshDropdowns(command.form);
        command.window.setLocale({title: attendanceText(command.title) + (command.record?.id ? " · " + command.record.id : ""), closeLabel: attendanceText("关闭操作窗口"), messages: attendanceWindowMessages});
        command.window.setFeedback(command.windowFeedback?.text || "", command.windowFeedback?.error || false);
        const state = command.window.getState();if (!state.open || state.minimized) command.window.open();
    }
    // 切模块或身份时撤下窗口，旧结果仍受既有epoch校验，不得恢复上一人的表单。
    function attendanceDestroyCommandWindows() {
        for (const controller of attendanceDates.values()) controller.destroy();
        attendanceDates.clear();
        for (const command of [...attendanceCommandForms.values(),attendanceBatchCommand].filter(Boolean)) {
            command.form.querySelectorAll("select").forEach(select => attendanceDropdown.destroy(select));
            command.window?.destroy();
        }
    }
    // 装配专用业务命令表单；缺已核验管理配置时禁用保存，提交期间阻止重复点击并回读真实列表。
    function attendanceCommand(title, path, fields, permission = "canManage") {
        const form = attendanceElement("form", undefined, "selform-root"); form.append(attendanceUiElement("h3", title));
        form.dataset.attendanceCommand = path;
        fields.forEach(([label, name, type, required]) => attendanceField(form, label, name, type, required !== false));
        const selectedTarget = path === "/api/attendance/employee/update.htm" || path === "/api/attendance/employeeworkrule/update.htm" || path === "/api/attendance/shifttemplate/update.htm" || path === "/api/attendance/ruleconfig/update.htm" || path === "/api/attendance/attendancecase/action.htm" || (path === "/api/attendance/attendancecase/submit.htm" && permission === "employeeMapped");
        if (path === "/api/attendance/attendancecase/action.htm") {
            const revision = attendanceElement("input"); revision.type = "hidden"; revision.name = "revision"; form.append(revision);
            const preview = attendanceButton("刷新服务端对比", () => attendancePreviewApproval(true)); form.append(preview);
        }
        if (["/api/attendance/ruleconfig/update.htm", "/api/attendance/shifttemplate/update.htm"].includes(path)) {
            const revision = attendanceElement("input"); revision.type = "hidden"; revision.name = "revision"; form.append(revision);
            form.append(attendanceUiElement("p", path.includes("shifttemplate") ? "已引用模板不允许原地修改。请新建独立编号并明确生效日期。" : "已引用规则不允许原地修改。请新建独立编号并明确关联生效日期。"));
        }
        if (selectedTarget) {
            const target = form.elements.namedItem(path.endsWith("action.htm") || path.endsWith("ruleconfig/update.htm") || path.endsWith("shifttemplate/update.htm") || path.endsWith("employeeworkrule/update.htm") || path.endsWith("employee/update.htm") ? "id" : "attendanceDailyId"); target.readOnly = true;
            form.append(attendanceUiElement("p", "先从记录列表选择真实记录，再执行操作。"));
        }
        const context = selectedTarget ? attendanceElement("p") : null;
        if (context) { context.setAttribute("data-attendance-command-context", ""); form.append(context); }
        if (path === "/api/attendance/attendancecase/submit.htm" && permission === "employeeMapped") {
            // 员工补卡申请使用已有服务类型，不让本人界面编辑身份、审批人或管理员动作。
            const kind = attendanceElement("input"); kind.type = "hidden"; kind.name = "caseType"; kind.value = "PUNCH_CORRECTION"; form.append(kind);
        }
        const submit = attendanceButton("保存"); submit.setAttribute("data-tone", "primary"); submit.type = "submit"; submit.disabled = !attendanceConfiguration?.[permission];
        const draftKey = attendanceModule.code + ":" + path;
        const savedDraft = attendanceDrafts.get(draftKey) || {};
        Array.from(form.elements).forEach(input => {
            const key = input.name || input.dataset.attendanceDisplay;
            if (key && savedDraft[key] !== undefined) {
                if (input.type === "checkbox") input.checked = savedDraft[key] === "true";
                else input.value = savedDraft[key];
            }
        });
        if (path.includes("/ruleconfig/")) {
            const defaults = { autoBreakThresholdMinutes: "0", autoBreakDeductMinutes: "0", roundingUnitMinutes: "0", monthlyOvertimeAlertHours: "45", yearlyOvertimeAlertHours: "360" };
            Object.entries(defaults).forEach(([name, value]) => { const input = form.elements.namedItem(name); if (input) { input.defaultValue = value; if (savedDraft[name] === undefined) input.value = value; } });
        }
        if (path.includes("/shifttemplate/")) {
            for (const [name, value] of Object.entries({ scheduledBreakMinutes: "0", color: "BLUE" })) {
                const input = form.elements.namedItem(name); input.defaultValue = value; if (savedDraft[name] === undefined) input.value = value;
            }
        }
        if (path.includes("/employeeworkrule/")) form.append(attendanceButton("核验有效期关联", () => attendanceCheckAssociations(form)));
        form.addEventListener("input", () => {
            const values = attendanceData(form);
            form.querySelectorAll("[data-attendance-display]").forEach(input => { values[input.dataset.attendanceDisplay] = input.value; });
            attendanceDrafts.set(draftKey, values);
        });
        const command = { form, submit, draftKey, permission, context, selectedTarget, pending: false, targetReady: !selectedTarget };
        attendanceCommandForms.set(path, command); submit.disabled = !attendanceConfiguration?.[permission] || selectedTarget;
        const cancel = attendanceButton("取消编辑", () => {
            if (command.pending) return;
            if (path === "/api/attendance/attendancecase/action.htm") {
                attendanceApprovalWindow?.close(); attendanceFeedback("已取消编辑，未提交变更。"); return;
            }
            form.reset(); attendanceDrafts.delete(draftKey); command.targetReady = !selectedTarget;
            if (context) context.textContent = ""; command.record = null;
            submit.disabled = !attendanceConfiguration?.[permission] || !command.targetReady;
            command.window?.close(); attendanceFeedback("已取消编辑，未提交变更。");
        });
        form.append(submit, cancel); form.addEventListener("submit", async event => {
            event.preventDefault(); if (command.pending || !attendanceConfiguration?.[permission]) return;
            if (!command.targetReady) { attendanceFeedback("请先选择真实记录。", true); return; }
            if (!form.reportValidity()) return;
            if (path.includes("/employeeworkrule/")) {
                const values = attendanceData(form);
                if (!values.employeeId || !values.ruleId || !form.elements.namedItem("ruleId").dataset.attendanceRevision || (values.roundingRuleId && !form.elements.namedItem("roundingRuleId").dataset.attendanceRevision)) { attendanceFeedback("请从真实列表选择员工和计算规则。", true); return; }
                if (values.effectiveEndDate && values.effectiveEndDate < values.effectiveStartDate) { attendanceFeedback("结束日期不能早于生效日期。", true); return; }
            }
            const epoch = attendanceEpoch; const detailEpoch = attendanceDetailEpoch; const module = attendanceModule;
            command.pending = true; submit.disabled = true; cancel.disabled = true;
            attendanceApprovalWindow?.setFeedback("");
            form.setAttribute("aria-busy", "true");
            try {
                const data = attendanceData(form);
                if (path.includes("/shifttemplate/")) ["startTime", "endTime", "color", "effectiveFromDate"].forEach(field => { data[field] = form.elements.namedItem(field)?.value || ""; });
                if (path.includes("/ruleconfig/")) data.note = form.elements.namedItem("note")?.value || "";
                if (path === "/api/attendance/attendancecase/action.htm") {
                    const patch = {};
                    ["actualClockIn", "actualClockOut", "finalBreakMinutes", "finalStatus", "finalExceptionFlag"].forEach(field => {
                        if (data[field] !== undefined) patch[field] = data[field];
                        delete data[field];
                    });
                    data.patchPayloadJson = JSON.stringify(patch);
                }
                const request = { url: path, method: "POST", data };
                if (path.includes("/employeeworkrule/")) {
                    data.effectiveEndDate = form.elements.namedItem("effectiveEndDate").value || null;
                    data.roundingRuleId = form.elements.namedItem("roundingRuleId").value || null;
                    data.ruleNote = form.elements.namedItem("ruleNote").value;
                    data.ruleRevision = form.elements.namedItem("ruleId").dataset.attendanceRevision;
                    if (data.roundingRuleId) data.roundingRuleRevision = form.elements.namedItem("roundingRuleId").dataset.attendanceRevision;
                    delete request.data; request.jsonData = data;
                }
                const result = await selAjax.request(request);
                if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                attendanceDrafts.delete(draftKey); form.reset(); command.targetReady = !selectedTarget;
                command.window?.close();
                if (path === "/api/attendance/attendancecase/action.htm") attendanceApprovalWindow?.close();
                const read = await attendanceLoad();
                if (module !== attendanceModule) return;
                if (read && (path.includes("/ruleconfig/") || path.includes("/shifttemplate/") || path.includes("/employeeworkrule/")) && result.data?.id) await attendanceShowDetail(result.data.id);
                if (read && path === "/api/attendance/employee/update.htm" && command.record?.id) await attendanceShowDetail(command.record.id);
                if (read && result.data?.caseId) await attendanceShowDetail(result.data.caseId);
                // 成功后的结果来自实际写入及回读；新动作需明确重新选择，避免意外连续提交。
                command.targetReady = !selectedTarget;
                if (read) attendanceFeedback(attendanceText("操作已保存，状态：{state}。", { state: attendanceText(result.data?.caseStatus || "已保存") }));
                else attendanceFeedback("操作已保存，但结果未重新读取。请查询核验。", true);
            }
            catch (error) {
                if (epoch !== attendanceEpoch) return;
                if ((path === "/api/attendance/ruleconfig/update.htm" && error.message.includes("计算规则配置已更新")) || (path === "/api/attendance/shifttemplate/update.htm" && error.message.includes("班次模板已更新"))) command.targetReady = false;
                attendanceFeedback(error.message, true); attendanceApprovalWindow?.setFeedback(attendanceText(error.message), true);
                if (path === "/api/attendance/attendancecase/action.htm" && error.message.includes("处理单已更新")) {
                    // 保留选中案件与草稿，只刷新当前修订；旧请求不会自动重发。
                    try {
                        const fresh = await selAjax.request({ url: "/api/attendance/attendancecase/reviewDetail.htm", method: "POST", data: { id: command.record.id } });
                        if (epoch === attendanceEpoch) {
                            command.record = fresh.data; form.elements.namedItem("revision").value = String(fresh.data.revision);
                            command.targetReady = false;
                            command.context.textContent = attendanceText("所选处理单：{id}；状态：{state}；申请说明：{reason}", { id: fresh.data.id, state: attendanceText(fresh.data.caseStatus), reason: fresh.data.reasonText || "—" });
                            await attendancePreviewApproval(); attendanceFeedback(error.message, true); attendanceApprovalWindow?.setFeedback(attendanceText(error.message), true);
                        }
                    } catch (refreshError) { attendanceFeedback(refreshError.message, true); }
                }
                // 后端始终核验动作权限；失败后再读配置，撤权时销毁旧记录及表单，绝不前端赋权。
                try {
                    const current = await selAjax.request({ url: "/api/attendance/access/configuration.htm" });
                    if (epoch === attendanceEpoch && !current.data?.[permission]) await attendanceCheckSession();
                } catch { if (epoch === attendanceEpoch) await attendanceCheckSession(); }
            }
            finally { command.pending = false; form.removeAttribute("aria-busy"); cancel.disabled = false; submit.disabled = !attendanceConfiguration?.[permission] || !command.targetReady; }
        }); attendanceRegisterCommandWindow(title, path, form, [submit, cancel], command);
    }
    // 单段批排班是本域业务草稿，表单/对象选择/计划表由现有公共SELUI负责；不造排班器。
    function attendanceBatchSchedule() {
        const form = attendanceElement("form", undefined, "selform-root"); form.dataset.attendanceBatch = "";
        form.append(attendanceUiElement("h3", "批量排班"), attendanceUiElement("p", "选择员工、日期范围和一个班次模板。预览不授予权限，确认时重新核验；已有排班不会覆盖。"));
        const names = attendanceField(form, "所选员工", "employeeNames", "textarea", true); names.readOnly = true; names.rows = 3;
        const selected = new Map();
        const add = attendanceButton("添加员工", () => attendanceChooseObject("employee", row => {
            if (state.pending || state.plan || attendanceBatchCommand !== state) return;
            if (selected.has(String(row.id))) { attendanceFeedback("同一员工已选中，请勿重复添加。", true); return; }
            selected.set(String(row.id), row); names.value = Array.from(selected.values(), employee => `${employee.employeeName} · ${employee.employeeNo}`).join("\n"); invalidate();
        }));
        const clear = attendanceButton("清空员工", () => { if (state.pending || state.plan) return; selected.clear(); names.value = ""; invalidate(); });
        const employeeActions = attendanceElement("nav", undefined, "selform-actions"); employeeActions.append(add, clear); form.append(employeeActions);
        const from = attendanceField(form, "开始日期", "fromDate", "date", true);
        const to = attendanceField(form, "结束日期", "toDate", "date", true);
        const template = attendanceField(form, "班次模板", "shiftTemplateId", "text", true);
        const remark = attendanceField(form, "备注", "remark", "text", false); remark.maxLength = 500;
        const preview = attendanceButton("预览排班"); preview.type = "submit"; preview.setAttribute("data-tone", "primary");
        const modify = attendanceButton("返回修改", () => {
            if (state.pending) return;
            state.plan = null; state.payload = null; state.key = crypto.randomUUID(); state.completed = false;
            state.grid?.destroy(); state.grid = null; results.replaceChildren(); update(); from.focus(); attendanceFeedback("已返回修改，尚未提交变更。");
        });
        const confirm = attendanceButton("确认整批提交"); confirm.setAttribute("data-tone", "primary"); confirm.dataset.attendanceBatchConfirm = "";
        const actions = attendanceElement("nav", undefined, "selform-actions"); actions.append(preview, modify, confirm); form.append(actions);
        const results = attendanceElement("div"); results.dataset.attendanceBatchPreview = ""; form.append(results);
        const state = { form, grid: null, plan: null, payload: null, pending: false, completed: false, key: crypto.randomUUID(), renderPreview };
        attendanceBatchCommand = state;
        // 输入改变即废弃预览与旧键；网络失败重试不改变完整已冻结负载和稳定请求键。
        function invalidate() { if (state.pending || state.plan) return; state.payload = null; state.key = crypto.randomUUID(); update(); }
        // 模板/员工选择与日期输入只改变业务草稿，按钮门禁不是后台授权。
        function update() {
            const locked = state.pending || !!state.plan; const allowed = attendanceConfiguration?.canManage;
            form.querySelectorAll("input, select, textarea").forEach(input => { input.disabled = locked; });
            form.querySelectorAll("button").forEach(button => { button.disabled = locked || !allowed; });
            attendanceRefreshDropdowns(form);
            preview.disabled = locked || !allowed; modify.disabled = state.pending || !state.plan;
            confirm.disabled = state.pending || state.completed || !allowed || !state.plan || state.plan.some(row => row.conflictCode);
            form.setAttribute("aria-busy", String(state.pending));
        }
        // 计划及逐行冲突来自服务端，公共Grid本地分页展示完整结果，语言切换不再查询或丢草稿。
        function renderPreview() {
            if (!state.plan) return;
            const module = { code: "batchPreview", title: attendanceText("排班预览"), fields: [["employeeName", "姓名"], ["workDate", "工作日期"], ["templateName", "班次名称"], ["templateRevision", "配置修订"], ["scheduledStartTime", "计划开始"], ["scheduledEndTime", "计划结束"], ["scheduledBreakMinutes", "休息分钟"], ["conflict", "冲突说明"]] };
            const records = state.plan.map((row, index) => ({ ...row, id: index + 1, conflict: attendanceText(row.conflictMessage || "可创建") }));
            const payload = attendancePayload({ records, totalCount: records.length, pageNo: 1, pageSize: 20 }, module);
            payload.grid.selectionMode = "NONE"; payload.pagination.mode = "LOCAL";
            if (!state.grid) { const root = grid.create(results, { gridId: "AttendanceBatchSchedulePreview", entity: "attendance", ariaLabel: attendanceText("排班预览") }); state.grid = grid.mount(root, payload); }
            else state.grid.setLocale(payload);
        }
        form.addEventListener("input", invalidate);
        form.addEventListener("submit", async event => {
            event.preventDefault(); if (state.pending || state.plan || !attendanceConfiguration?.canManage || !form.reportValidity()) return;
            if (!selected.size || !template.value || from.value > to.value) { attendanceFeedback("请选择员工、班次模板和有效日期范围。", true); return; }
            const items = []; const first = new Date(`${from.value}T00:00:00Z`); const last = new Date(`${to.value}T00:00:00Z`);
            for (let date = first; date <= last; date = new Date(date.getTime() + 86400000)) {
                for (const employee of selected.values()) items.push({ employeeId: employee.id, workDate: date.toISOString().slice(0, 10), shiftTemplateId: template.value, remark: remark.value });
                if (items.length > 1001) { attendanceFeedback("批量排班最多1001行，请缩小员工或日期范围。", true); return; }
            }
            const epoch = attendanceEpoch; state.pending = true; update();
            try {
                const actual = await selAjax.request({ url: "/api/attendance/shifttemplate/getById.htm", method: "POST", data: { id: template.value } });
                items.forEach(item => { item.templateRevision = actual.data.revision; });
                const payload = { requestKey: state.key, items };
                const result = await selAjax.request({ url: "/api/attendance/schedule/previewBatch.htm", method: "POST", jsonData: payload });
                if (epoch !== attendanceEpoch || attendanceBatchCommand !== state) return;
                if (!Array.isArray(result.data)) throw new Error("排班预览返回无效。");
                state.payload = selFreeze(payload); state.plan = result.data; renderPreview();
                attendanceFeedback(state.plan.some(row => row.conflictCode) ? "预览存在冲突，请返回修改；整批尚未提交。" : "预览无冲突。请核对后确认，提交时仍会重新核验。");
            } catch (error) { if (epoch === attendanceEpoch) attendanceFeedback(error.message, true); }
            finally { state.pending = false; update(); }
        });
        confirm.addEventListener("click", async () => {
            if (state.pending || state.completed || !state.payload || !attendanceConfiguration?.canManage || state.plan.some(row => row.conflictCode)) return;
            const epoch = attendanceEpoch; state.pending = true; update();
            try {
                const result = await selAjax.request({ url: "/api/attendance/schedule/commitBatch.htm", method: "POST", jsonData: state.payload });
                if (epoch !== attendanceEpoch || attendanceBatchCommand !== state) return;
                state.completed = true; await attendanceLoad();
                attendanceFeedback(result.affectedRows === 0 ? "该批已提交，已返回原成功回执；未重复创建。" : "整批排班已保存。日月结果未自动重算，请查询核验。");
            } catch (error) {
                if (epoch !== attendanceEpoch) return;
                attendanceFeedback(error.message, true);
                // 失败保留完整负载/稳定键；若响应丢失但后台已提交，可再次确认取得原回执。
                try { const current = await selAjax.request({ url: "/api/attendance/access/configuration.htm" }); if (!current.data?.canManage) await attendanceCheckSession(); } catch { await attendanceCheckSession(); }
            } finally { state.pending = false; update(); }
        });
        attendanceRegisterCommandWindow("批量排班", "batchSchedule", form, [preview, modify, confirm], state); update();
    }
    // 切换模块时销毁旧 Grid 并清空筛选和详情；创建该模块的受控查询与命令，再读取第一页。
    function attendanceSelect(module) {
        attendanceDestroyCommandWindows();
        attendanceClearRelease();
        attendanceBindingWindow?.destroy(); attendanceBindingWindow = null;
        attendanceSelectorGrid?.destroy(); attendanceSelectorGrid = null; attendanceSelectorWindow?.destroy(); attendanceSelectorWindow = null;
        attendanceLastPage = null; attendanceSelectorPage = null; attendanceSelectorEntity = null;
        attendanceBatchCommand?.grid?.destroy(); attendanceBatchCommand = null;
        ++attendanceEpoch; ++attendanceDetailEpoch; attendanceApprovalWindow?.destroy(); attendanceApprovalWindow = null; attendanceApprovalGrid?.destroy(); attendanceApprovalGrid = null; attendanceCommandForms.clear(); attendanceModule = module; attendanceClearOwnMonthlyMetrics(); attendanceDetail.replaceChildren(); attendanceCommandActions.replaceChildren();attendanceCommandHost.replaceChildren();
        attendanceGrid?.destroy(); attendanceGrid = null; attendanceGridHost.replaceChildren(); attendanceGridHost.hidden = true;
        attendanceNavigation?.setSelectedId(module.code);
        attendanceWorkspaceTabs.setLocale({ items: [{ id: "workspace", label: attendanceText(module.title) }] });
        attendanceContext.dataset.attendanceText = "选择中央列表中的记录查看详情。";
        attendanceContext.textContent = attendanceText(attendanceContext.dataset.attendanceText);
        attendanceQuery.replaceChildren();
        if (module.code === "employee") attendanceField(attendanceQuery, "姓名包含", "employeeNameLike");
        else if (attendanceConfiguration?.canManage && !["ruleconfig", "shifttemplate", "monthlyitem", "punchsourceconfig", "punchimportbatch"].includes(module.code)) attendanceField(attendanceQuery, "员工", "employeeId", "number");
        if (["employeeexternalmapping", "punchsourceconfig", "punchimportbatch"].includes(module.code)) attendanceField(attendanceQuery, "来源标识", "sourceSystem");
        if (["daily", "shiftschedule"].includes(module.code)) attendanceField(attendanceQuery, "工作日期", "workDate", "date");
        if (["monthly", "monthlyrelease"].includes(module.code)) attendanceField(attendanceQuery, "月份（YYYY-MM）", "yearMonth");
        const actions = attendanceElement("nav", undefined, "selform-actions"); const query = attendanceButton("查询"); query.setAttribute("data-tone", "primary"); query.type = "submit"; query.disabled = !attendanceCanRead(module); actions.append(query, attendanceCommandActions); attendanceQuery.append(actions);
        if (module.code === "monthlyrelease") attendanceCommandHost.append(attendanceUiElement("p", "从记录列表选择月份，核对实际冻结内容后分别审核、发布或撤回。"));
        // 新空业务库通过真实员工新增接口开始；复用现有表单组件，不预置员工或身份绑定。
        if (attendanceConfiguration?.canManage && module.code === "employee") attendanceCommand("新建员工", "/api/attendance/employee/create.htm", [["员工编号", "employeeNo", "text"], ["姓名", "employeeName", "text"], ["雇用类型", "employmentType", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "employee") attendanceCommand("修改员工资料", "/api/attendance/employee/update.htm", [["员工记录主键", "id", "number"], ["姓名", "employeeName", "text"], ["雇用类型", "employmentType", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "shiftschedule") attendanceBatchSchedule();
        if (attendanceConfiguration?.canManage && module.code === "ruleconfig") {
            const fields = [["规则编号", "ruleCode", "text"], ["规则名称", "ruleName", "text"], ["标准日分钟", "standardDailyMinutes", "number"], ["标准周分钟", "standardWeeklyMinutes", "number"],
                ["自动扣休", "autoBreakEnabled", "text"], ["自动扣休阈值分钟", "autoBreakThresholdMinutes", "number"], ["自动扣休分钟", "autoBreakDeductMinutes", "number"],
                ["夜间开始", "nightWorkStart", "time"], ["夜间结束", "nightWorkEnd", "time"], ["舍入方式", "roundingMode", "text"], ["舍入分钟", "roundingUnitMinutes", "number"],
                ["月加班提醒小时", "monthlyOvertimeAlertHours", "number"], ["年加班提醒小时", "yearlyOvertimeAlertHours", "number"], ["有薪休假提醒", "paidLeaveReminderEnabled", "text"], ["规则启用", "activeFlag", "text"], ["备注", "note", "text", false]];
            attendanceCommand("新建计算规则", "/api/attendance/ruleconfig/create.htm", fields);
            attendanceCommand("编辑计算规则", "/api/attendance/ruleconfig/update.htm", [["规则记录主键", "id", "number"], ...fields]);
        }
        if (attendanceConfiguration?.canManage && module.code === "employeeworkrule") {
            const fields = [["员工", "employeeId", "number"], ["计算规则", "ruleId", "number"], ["工时规则类型", "workRuleType", "text"],
                ["标准日分钟", "standardDailyMinutes", "number"], ["标准周分钟", "standardWeeklyMinutes", "number"], ["加班计算", "overtimeEnabled", "text"],
                ["夜间计算", "nightWorkEnabled", "text"], ["假日计算", "holidayWorkEnabled", "text"], ["舍入规则", "roundingRuleId", "number", false],
                ["生效日期", "effectiveStartDate", "date"], ["结束日期", "effectiveEndDate", "date", false], ["关联备注", "ruleNote", "text", false]];
            attendanceCommand("新建员工规则关联", "/api/attendance/employeeworkrule/create.htm", fields);
            attendanceCommand("编辑员工规则关联", "/api/attendance/employeeworkrule/update.htm", [["关联记录主键", "id", "number"], ...fields]);
            attendanceCommandHost.prepend(attendanceUiElement("p", "请选择实际员工、规则版本和生效日期。标准分钟及开关须明确填写，不自动重算历史。"));
        }
        if (attendanceConfiguration?.canManage && module.code === "shifttemplate") {
            const fields = [["班次编号", "templateCode", "text"], ["班次名称", "templateName", "text"], ["班次类型", "shiftType", "text"], ["开始时间", "startTime", "time", false], ["结束时间", "endTime", "time", false], ["跨日", "crossDay", "text"], ["休息分钟总量", "scheduledBreakMinutes", "number"], ["显示颜色编码", "color", "text"], ["班次启用", "isActive", "text"], ["生效日期", "effectiveFromDate", "date"]];
            attendanceCommand("新建班次模板", "/api/attendance/shifttemplate/create.htm", fields);
            attendanceCommand("编辑班次模板", "/api/attendance/shifttemplate/update.htm", [["模板记录主键", "id", "number"], ...fields.map(field => field[1] === "effectiveFromDate" ? [...field, false] : field)]);
            attendanceCommandHost.prepend(attendanceUiElement("p", "模板保存单工作时段与休息分钟总量；休息、请假可不填写时间。跨午夜须明确跨日。分段和模板时区换算未支持。"));
        }
        if (attendanceConfiguration?.canManage && module.code === "shiftschedule") attendanceCommand("保存单日排班", "/api/attendance/schedule/save.htm", [["员工", "employeeId", "number"], ["班次模板", "shiftTemplateId", "number"], ["工作日期", "workDate", "date"]]);
        if (attendanceConfiguration?.canManage && module.code === "punchrawlog") attendanceCommand("管理补录打卡", "/api/attendance/punch/manual.htm", [["员工", "employeeId", "number"], ["打卡时间", "punchTime", "datetime-local"], ["打卡类型", "punchType", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "employeeexternalmapping") {
            attendanceCommand("登记待核准映射", "/api/attendance/employeeexternalmapping/register.htm", [["员工", "employeeId", "number"], ["来源标识", "sourceSystem", "text"], ["外部员工标识", "externalEmployeeId", "text"], ["外部员工编号", "externalEmployeeNo", "text", false]]);
            attendanceCommand("撤销映射", "/api/attendance/employeeexternalmapping/revoke.htm", [["映射记录主键", "id", "number"]]);
            attendanceCommand("核准唯一映射", "/api/attendance/employeeexternalmapping/verify.htm", [["映射记录主键", "id", "number"]]);
        }
        if (attendanceConfiguration?.canManage && module.code === "punchsourceconfig") attendanceCommand("登记CSV来源（外部连接停用）", "/api/attendance/punchsourceconfig/register.htm", [["来源标识", "sourceSystem", "text"], ["来源名称", "configName", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "punchimportbatch") attendanceCommand("导入CSV并保存批次", "/api/attendance/punch/importCsv.htm", [["来源标识", "sourceSystem", "text"], ["幂等批次键", "importKey", "text"], ["文件名", "fileName", "text", false], ["CSV文本（sourceEventId,externalEmployeeId,punchTime,punchType）", "csvText", "textarea"]]);
        if (["daily", "monthly", "monthlyrelease"].includes(module.code)) {
            const warning = attendanceUiElement("p", "规则来源须核验：未配置规则仍保留历史兜底算法；零加班、月结或发布状态不代表工时口径已审核。不得用当前规则覆盖历史快照。");
            warning.setAttribute("role", "status"); warning.dataset.attendanceRuleWarning = "true"; attendanceCommandHost.prepend(warning);
        }
        if (attendanceConfiguration?.canManage && module.code === "daily") attendanceCommand("计算并保存日次", "/api/attendance/calculation/daily.htm", [["员工", "employeeId", "number"], ["工作日期", "workDate", "date"]]);
        if (attendanceConfiguration?.canManage && module.code === "monthly") attendanceCommand("汇总并保存月次", "/api/attendance/calculation/monthly.htm", [["员工", "employeeId", "number"], ["月份（YYYY-MM）", "yearMonth", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "monthly") attendanceCommand("结当前整月", "/api/attendance/calculation/close-period.htm", [["月份（YYYY-MM）", "yearMonth", "text"]]);
        if (attendanceConfiguration?.canManage && module.code === "monthly") attendanceCommand("重开月次", "/api/attendance/monthly/reopen.htm", [["月次报表主键", "id", "number"], ["重开原因", "reason", "text"]]);
        if (module.code === "attendancecase") {
            if (attendanceConfiguration?.canManage) attendanceCommand("提交处理单", "/api/attendance/attendancecase/submit.htm", [["日次记录主键", "attendanceDailyId", "number"], ["处理单类型", "caseType", "text"], ["申请说明", "reasonText", "text", false]]);
            if (!attendanceConfiguration?.canManage && attendanceConfiguration?.employeeMapped) attendanceCommand("申请补卡", "/api/attendance/attendancecase/submit.htm", [["日次记录主键", "attendanceDailyId", "number"], ["申请说明", "reasonText", "text", false]], "employeeMapped");
            if (attendanceConfiguration?.canApprove) attendanceCommand("执行审批动作", "/api/attendance/attendancecase/action.htm", [["处理单主键", "id", "number"], ["审批动作", "actionType", "text"], ["最终上班时间", "actualClockIn", "datetime-local", false], ["最终下班时间", "actualClockOut", "datetime-local", false], ["最终休息分钟", "finalBreakMinutes", "number", false], ["最终出勤状态", "finalStatus", "text", false], ["保留异常标记", "finalExceptionFlag", "checkbox", false], ["审批说明", "comment", "text", false]], "canApprove");
        }
        attendanceRenderConnection();
        if (attendanceCanRead(module)) attendanceLoad();
    }
    panel.mount(attendancePanel, { view: attendancePanelView() });
    attendanceNavigation = tree.mount(attendancePanel, attendanceNavigationData());
    attendancePanel.addEventListener("selTree:select", event => {
        const module = attendanceModules.find(item => item.code === event.detail.id);
        if (module?.code === "classroom") {
            attendanceNavigation?.setSelectedId(attendanceModule.code);
            import('./attendanceClassrooms.mjs?v=20261106-history-paging3').then(owner=>{
                attendanceClassrooms??=owner.attendanceMountClassrooms(document.body,{locale:attendanceLocale,messages:attendanceWindowMessages});
                return attendanceClassrooms.open();
            }).catch(error=>attendanceFeedback(error.message,true));return;
        }
        if (module?.code === "person") {
            attendanceNavigation?.setSelectedId(attendanceModule.code);
            import('./attendancePeople.mjs?v=20261028-employee-picker1').then(owner=>{
                attendancePeople??=owner.attendanceMountPeople(document.body,{locale:attendanceLocale,canManage:()=>attendanceConfiguration?.canManage===true,chooseEmployee:(selected,onClose)=>attendanceChooseObject('employee',selected,{onClose})});
                return attendancePeople.open();
            }).catch(error=>attendanceFeedback(error.message,true));return;
        }
        if (module) attendanceSelect(module);
    });
    attendanceQuery.addEventListener("submit", event => { event.preventDefault(); attendanceLoad(); });
    // 连接状态以真实后端响应区分；拒绝/不可用不挂伪空 Grid，也不呈现可保存业务表单。
    function attendanceRenderConnection() {
        const messages = {
            checking: ["正在核验当前会话…", "正在连接考勤服务并验证实际会话。"],
            unavailable: ["考勤服务暂不可用", "当前页面无法连接考勤接口。记录尚未加载，不能查询、编辑或保存。"],
            anonymous: ["尚未登录", "请先登录统一认证，再重新核验会话。记录尚未加载。"],
            denied: ["考勤权限尚未核验", "当前账号未取得已核验的考勤管理权限。请联系授权负责人，记录尚未加载。"],
            ready: ["会话已验证", "可以查询实际记录；常用操作在列表上方，详情来自所选记录。"]
        };
        const [title, description] = messages[attendanceConnection];
        attendanceStateTitle.dataset.attendanceText = title; attendanceStateTitle.textContent = attendanceText(title);
        attendanceStateDescription.dataset.attendanceText = description; attendanceStateDescription.textContent = attendanceText(description);
        const allowed = attendanceConnection === "ready";
        // 已核验时只保留实际读取反馈；匿名、拒绝和连接故障仍显示完整状态说明。
        attendanceStateTitle.hidden = allowed; attendanceStateDescription.hidden = allowed;
        attendanceStateCard.className = allowed ? "" : "selform-root";
        attendanceQuery.hidden = !allowed; attendanceCommandHost.hidden = !allowed;
        attendanceGridHost.hidden = !allowed || !attendanceLastPage;
        attendanceRight.hidden = false;
        if (!allowed) {
            attendanceClearOwnMonthlyMetrics(); attendanceDetail.replaceChildren();
            attendanceContext.dataset.attendanceText = "当前模块的详情将在服务可用并选择真实记录后显示。";
            attendanceContext.textContent = attendanceText(attendanceContext.dataset.attendanceText);
            attendanceDetail.append(attendanceUiElement("h3", "本模块包含"));
            const fields = attendanceElement("ul");
            attendanceFields(attendanceModule).forEach(([, label]) => fields.append(attendanceUiElement("li", label)));
            attendanceDetail.append(fields);
        }
    }
    // 使用本域实际登录状态契约辨认匿名；404/连接/解析失败只表示接口不可用，不猜测已经登录。
    async function attendanceCheckSession() {
        const request = ++attendanceSessionEpoch;
        // 重新核验身份时清空草稿，防止上一会话的案件关联或最终值进入另一账号。
        attendanceDrafts.clear();
        ++attendanceEpoch; attendanceConfiguration = null; attendanceConnection = "checking";
        // 身份重新核验即撤回旧管理树，匿名或接口失败不会恢复未经核验的管理入口。
        attendanceNavigation?.setData(attendanceNavigationData());
        attendanceSelect(attendanceModule); attendanceRenderConnection(); attendanceFeedback("正在核验当前会话…");
        try {
            const status = await selAjax.request({ url: "/api/attendance/session/status.htm" });
            if (request !== attendanceSessionEpoch) return;
            if (typeof status.data?.authenticated !== "boolean") throw new Error("会话状态接口返回无效。");
            if (!status.data.authenticated) {
                attendanceConnection = "anonymous";
                attendanceFeedback("尚未登录，请先登录统一认证。"); attendanceRenderConnection(); return;
            }
            const result = await selAjax.request({ url: "/api/attendance/access/configuration.htm" });
            if (request !== attendanceSessionEpoch) return;
            if (!result.data || ["canManage", "canApprove", "employeeMapped", "canReadOwnMonthly", "canReviewMonthly", "canPublishMonthly", "canWithdrawMonthly"].some(field => typeof result.data[field] !== "boolean")
                    || (result.data.canReadOwnMonthly && !result.data.employeeMapped)
                    || (result.data.employeeMapped && (!Number.isSafeInteger(Number(result.data.employeeId)) || Number(result.data.employeeId) <= 0))) throw new Error("配置接口返回无效。");
            attendanceConfiguration = result.data;
            attendanceConnection = result.data.canManage || result.data.canApprove || result.data.employeeMapped || attendanceCanRelease() ? "ready" : "denied";
            if (!result.data.canManage && result.data.canApprove) attendanceModule = attendanceModules.find(module => module.code === "attendancecase");
            if (!result.data.canManage && !result.data.canApprove && result.data.employeeMapped
                    && !(attendanceModule.code === "monthly" && result.data.canReadOwnMonthly)) attendanceModule = attendanceModules.find(module => module.code === "daily");
            if (!result.data.canManage && !result.data.canApprove && !result.data.employeeMapped && attendanceCanRelease()) attendanceModule = attendanceModules.find(module => module.code === "monthlyrelease");
            attendanceNavigation?.setData(attendanceNavigationData());
            attendanceSelect(attendanceModule); attendanceRenderConnection();
            if (!result.data.canManage && !result.data.canApprove && !result.data.employeeMapped && !attendanceCanRelease()) attendanceFeedback("会话已验证；考勤管理配置尚未核验，请由授权负责人完成配置。", true);
        } catch (error) {
            if (request !== attendanceSessionEpoch) return;
            attendanceLastDiagnostic = error.message;
            attendanceConnection = "unavailable";
            attendanceFeedback(attendanceConnection === "anonymous" ? "尚未登录，请先登录统一认证。" : "考勤接口不可用，记录尚未加载。", true);
            attendanceRenderConnection();
        }
    }
    // 员工/班次引用通过可发现的真实列表选择；隐藏主键只承担请求关联，展示名称不进入权限判断。
    function attendanceReferenceField(form, label, name, entity) {
        const field = attendanceElement("label", undefined, "selform-field"); field.append(attendanceUiElement("span", label));
        const display = attendanceElement("input"); display.readOnly = true; display.dataset.attendanceDisplay = `${name}Label`;
        const value = attendanceElement("input"); value.type = "hidden"; value.name = name;
        const choose = attendanceButton(`选择${label}`, () => attendanceChooseObject(entity, row => {
            value.value = row.id; display.value = attendanceReferenceLabel(entity, row);
            if (entity === "ruleconfig") value.dataset.attendanceRevision = String(row.revision);
            value.dispatchEvent(new Event("input", { bubbles: true })); display.focus();
        }));
        const clear = attendanceButton("清除", () => { value.value = ""; delete value.dataset.attendanceRevision; display.value = ""; value.dispatchEvent(new Event("input", { bubbles: true })); });
        const actions = attendanceElement("nav", undefined, "selform-actions"); actions.append(choose, clear);
        field.append(display); form.append(field, value, actions); return value;
    }
    // 引用显示来自真实行；规则修订只用于辨识版本，不生成关联身份或替代后台核验。
    function attendanceReferenceLabel(entity, row) {
        return entity === "employee" ? `${row.employeeName} · ${row.employeeNo}` : entity === "ruleconfig"
            ? attendanceText("{code} · {name} · 修订{revision}", { code: row.ruleCode, name: row.ruleName, revision: row.revision }) : row.templateName;
    }
    // 分页核验当前员工真实有效期，沿用旧包含结束日与较晚日期/主键优先级；只读提示不制造新工资判定。
    async function attendanceCheckAssociations(form) {
        const epoch = attendanceEpoch; const detailEpoch = attendanceDetailEpoch; const values = attendanceData(form);
        if (!values.employeeId || !values.effectiveStartDate) { attendanceFeedback("请选择员工并填写生效日期。", true); return; }
        if (values.effectiveEndDate && values.effectiveEndDate < values.effectiveStartDate) { attendanceFeedback("结束日期不能早于生效日期。", true); return; }
        try {
            let pageNo = 1, count = 0, conflicts = 0, total;
            do {
                const page = await selAjax.request({ url: "/api/attendance/employeeworkrule/getStore.htm", method: "POST", data: { employeeId: values.employeeId, pageNo, pageSize: 100 } });
                if (epoch !== attendanceEpoch || detailEpoch !== attendanceDetailEpoch) return;
                if (!Array.isArray(page.records) || !Number.isFinite(Number(page.totalCount))) throw new Error("对象列表返回无效。");
                for (const row of page.records) if (String(row.id) !== values.id && row.effectiveStartDate <= (values.effectiveEndDate || "9999-12-31") && (row.effectiveEndDate || "9999-12-31") >= values.effectiveStartDate) ++conflicts;
                count += page.records.length; total = Number(page.totalCount); ++pageNo;
                if (count < total && page.records.length === 0) throw new Error("对象列表返回无效。");
            } while (count < total);
            attendanceFeedback(conflicts ? attendanceText("有效期存在{count}条重叠关联；旧计算按较晚生效日期、再较大主键选择。", { count: conflicts }) : "未发现当前员工的有效期重叠。此核验只读，保存仍由后台检查。", false);
        } catch (error) { if (epoch === attendanceEpoch && detailEpoch === attendanceDetailEpoch) attendanceFeedback(error.message, true); }
    }
    // 选定真实员工后在SELUI Window中显式管理绑定，只有目录选择的账号和只读真实修订可提交。
    function attendanceOpenBinding(employee) {
        attendanceBindingWindow?.destroy();
        const epoch = attendanceEpoch, detailEpoch = attendanceDetailEpoch;
        const content = attendanceElement("section"), form = attendanceElement("form", undefined, "selform-root");
        form.dataset.attendanceBinding = "true";
        form.append(attendanceElement("p", `${employee.employeeName} · ${employee.employeeNo}`), attendanceUiElement("p", "只绑定目录明确允许的账号；绑定不自动授予本人月报许可，不修改历史工时。"));
        const actionField = attendanceElement("label", undefined, "selform-field"); actionField.append(attendanceUiElement("span", "绑定动作"));
        const action = attendanceElement("select"); action.name = "action";
        for (const [value, label] of [["BIND", "绑定账号"], ["UNBIND", "解绑账号"]]) { const option = attendanceUiElement("option", label); option.value = value; action.append(option); }
        actionField.append(action); form.append(actionField);
        const accountLabel = attendanceElement("label", undefined, "selform-field"); accountLabel.append(attendanceUiElement("span", "已选择的账号"));
        const display = attendanceElement("input"); display.readOnly = true; display.name = "selectedAccountDisplay"; accountLabel.append(display); form.append(accountLabel);
        const choose = attendanceButton("选择允许的账号"), status = attendanceUiElement("p", "正在读取…"); status.setAttribute("role", "status");
        const save = attendanceButton("确认账号绑定操作"); save.type = "submit"; save.setAttribute("data-tone", "primary");
        const cancel = attendanceButton("取消编辑", () => currentWindow.close()); form.append(choose, status, save, cancel); content.append(form);
        attendanceBindingWindow = windowComponent.mount(attendanceWindowHost, { id: "AttendanceAccountBinding", title: attendanceText("管理员工账号绑定"), closeLabel: attendanceText("关闭账号绑定窗口"), messages: attendanceWindowMessages, content, showActions: false });
        const currentWindow = attendanceBindingWindow;
        const state = { request: 0, pending: false, available: false, selected: null, payload: null, completed: false };
        const current = () => epoch === attendanceEpoch && detailEpoch === attendanceDetailEpoch && attendanceBindingWindow === currentWindow;
        // 仅翻译已登记的后台说明，带请求号的原始错误保留诊断；未知说明原样显示，不推断目录状态。
        const message = key => { const raw = String(key), business = raw.split(" · ")[0], textKey = Object.hasOwn(attendanceMessages, business) ? business : raw; if (raw !== business) attendanceLastDiagnostic = raw; status.dataset.attendanceText = textKey; status.textContent = attendanceText(textKey); status.setAttribute("role", "status"); };
        const update = () => { choose.disabled = state.pending || !state.available; action.disabled = state.pending; save.disabled = state.pending || !state.payload || state.completed; form.setAttribute("aria-busy", String(state.pending)); };
        // 按当前动作读取服务端允许目录的一页；过期响应不恢复选择，目录缺失保留明确不可用状态。
        async function loadAvailability() {
            const request = ++state.request; state.available = false; state.payload = null; state.selected = null; state.completed = false; display.value = ""; update(); message("正在读取…");
            try {
                const page = await selAjax.request({ url: "/api/attendance/accountbinding/accounts.htm", method: "POST", data: { action: action.value, pageNo: 1, pageSize: 1 } });
                if (!current() || request !== state.request) return;
                if (!Array.isArray(page.records)) throw new Error("对象列表返回无效。");
                state.available = Number(page.totalCount) > 0; message(state.available ? "请选择目录允许的账号，再核对当前归属。" : "当前动作没有允许选择的账号。");
            } catch (error) { if (current() && request === state.request) { message(error.message); status.setAttribute("role", "alert"); } }
            finally { if (current() && request === state.request) update(); }
        }
        choose.addEventListener("click", () => {
            if (!current() || !state.available || state.pending) return;
            const selectedAction = action.value;
            attendanceChooseObject("account", async row => {
                if (!current() || selectedAction !== action.value) return;
                if (!Number.isSafeInteger(Number(row.id)) || Number(row.id) <= 0) { message("目录账号主键无法安全选择，请联系授权负责人核验。"); return; }
                const request = ++state.request; state.payload = null; state.completed = false; state.selected = row; display.value = `${row.displayName || row.id} · ${row.id}`; update(); message("正在读取…");
                try {
                    const result = await selAjax.request({ url: "/api/attendance/accountbinding/state.htm", method: "POST", data: { userId: row.id, action: selectedAction } });
                    if (!current() || request !== state.request || selectedAction !== action.value) return;
                    if (!Number.isSafeInteger(Number(result.data.bindingRevision)) || Number(result.data.bindingRevision) < 0) throw new Error("对象列表返回无效。");
                    const owned = Number(result.data.status) === 1;
                    if ((owned && String(result.data.employeeId) !== String(employee.id)) || (selectedAction === "UNBIND" && (!owned || String(result.data.employeeId) !== String(employee.id)))) { message("账号当前归属不匹配；请核验对应员工，不进行隐式换绑。"); return; }
                    state.payload = { userId: row.id, employeeId: employee.id, action: selectedAction, expectedRevision: Number(result.data.bindingRevision), requestKey: crypto.randomUUID() };
                    message(owned ? "当前账号已绑定本员工。解绑会立即撤销本人映射。" : "当前账号无活动绑定。确认后即时生效，不追加其他权限。");
                } catch (error) { if (current() && request === state.request) { message(error.message); status.setAttribute("role", "alert"); } }
                finally { if (current() && request === state.request) update(); }
            }, { action: selectedAction });
        });
        action.addEventListener("change", () => { attendanceSelectorWindow?.destroy(); attendanceSelectorWindow = null; attendanceSelectorGrid?.destroy(); attendanceSelectorGrid = null; loadAvailability(); });
        form.addEventListener("submit", async event => {
            event.preventDefault(); if (!current() || state.pending || !state.payload || state.completed) return;
            state.pending = true; update();
            try {
                const saved = await selAjax.request({ url: "/api/attendance/accountbinding/execute.htm", method: "POST", data: state.payload });
                if (!current()) return;
                state.completed = true;
                const reloaded = await selAjax.request({ url: "/api/attendance/accountbinding/state.htm", method: "POST", data: { userId: state.payload.userId, action: state.payload.action } });
                if (!current()) return;
                if (String(reloaded.data.bindingRevision) !== String(saved.data.bindingRevision)) throw new Error("绑定已保存，但当前状态已变化，请重新选择核验。");
                message("账号绑定操作已保存并重新读取。请在本人页面重新核验会话。");
            } catch (error) { if (current()) { message(state.completed ? "账号绑定已保存，但当前状态无法重新读取。请重新核验。" : error.message); status.setAttribute("role", "alert"); } }
            finally { state.pending = false; if (current()) update(); }
        });
        currentWindow.open(); update(); loadAvailability();
    }
    // 安全公开账号目录复用现有选择Window/Grid，不进入考勤表导航或通用账号CRUD。
    function attendanceSelectorModule(entity) {
        return entity === "account" ? { code: "account", title: "允许选择的账号", fields: [["id", "公开账号ID"], ["displayName", "账号显示名"], ["status", "目录启用状态"]] } : attendanceModules.find(item => item.code === entity);
    }
    // 对象选择独立放入 SEL UI Window，列表/搜索/分页全部从实际接口读取，错误不伪造空列表成功。
    function attendanceChooseObject(entity, selected, options = {}) {
        const previousSelector = attendanceSelectorWindow; attendanceSelectorWindow = null;
        attendanceSelectorGrid?.destroy(); previousSelector?.destroy(); attendanceSelectorGrid = null;
        attendanceSelectorEntity = entity;
        const module = attendanceSelectorModule(entity);
        const content = attendanceElement("section", undefined);
        const searchBar = attendanceElement("section", undefined, "selform-root");
        const keyword = attendanceField(searchBar, entity === "account" ? "公开账号ID（精确）" : entity === "employee" ? "姓名包含" : entity === "ruleconfig" ? "规则名称包含" : "班次名称包含", "keyword");
        const searchButton = attendanceButton("查询"); searchButton.setAttribute("data-tone", "primary"); searchBar.append(searchButton);
        const status = attendanceUiElement("p", "正在读取…"); status.setAttribute("role", "status");
        const results = attendanceElement("div", undefined); content.append(searchBar, status, results);
        attendanceSelectorWindow = windowComponent.mount(attendanceWindowHost, {
            id: `AttendanceObjectSelector${entity}`, title: attendanceText("选择{object}", { object: attendanceText(module.title) }), closeLabel: attendanceText("关闭对象选择窗口"), messages: attendanceWindowMessages, content, showActions: false
        });
        const selectorWindow = attendanceSelectorWindow, editorEpoch = attendanceEpoch;
        const parentCommand = [...attendanceCommandForms.values(),attendanceBatchCommand].filter(Boolean).find(command => command.window?.getState().open && !command.window.getState().minimized);
        parentCommand?.window.close();
        selectorWindow.getPageEditTarget().root.addEventListener("selWindow:close", () => {
            if (editorEpoch === attendanceEpoch && selectorWindow === attendanceSelectorWindow) { if (parentCommand?.window) attendanceOpenCommand(parentCommand.path); options.onClose?.(); }
        });
        selectorWindow.open();
        let request = 0; let records = [];
        // 当前窗口的真实查询；页码和后台总数原位交给 Grid，旧请求或已关闭实例不改变新选择窗口。
        async function attendanceLoadObjects(pageNo = 1, pageSize = 20) {
            const current = ++request; results.hidden = true; status.textContent = attendanceText("正在读取…");
            const data = { pageNo, pageSize };
            if (entity === "ruleconfig") { data.activeFlag = 1; data.deletedFlag = 0; }
            if (entity === "account") { data.action = options.action; data.accountIdExact = keyword.value.trim(); }
            else if (keyword.value.trim()) data[entity === "employee" ? "employeeNameLike" : entity === "ruleconfig" ? "ruleNameLike" : "templateNameLike"] = keyword.value.trim();
            try {
                const page = await selAjax.request({ url: entity === "account" ? "/api/attendance/accountbinding/accounts.htm" : `/api/attendance/${entity}/getStore.htm`, method: "POST", data });
                if (current !== request || selectorWindow !== attendanceSelectorWindow) return;
                if (!Array.isArray(page.records)) throw new Error("对象列表返回无效。");
                attendanceSelectorPage = page; records = page.records;
                const payload = attendancePayload(page, module);
                if (!attendanceSelectorGrid) {
                    const root = grid.create(results, { gridId: `AttendanceObjectRecords${entity}`, entity, ariaLabel: module.title });
                    attendanceSelectorGrid = grid.mount(root, payload);
                    root.addEventListener("selGrid:queryChange", event => attendanceLoadObjects(event.detail.pageNo, event.detail.pageSize));
                    root.addEventListener("selGrid:selectionChange", event => {
                        const row = records.find(item => String(item.id) === String(event.detail.selectedIds[0]));
                        if (row && selectorWindow === attendanceSelectorWindow) { selected(row); selectorWindow.close(); }
                    });
                } else attendanceSelectorGrid.setLocale(payload);
                results.hidden = false; status.textContent = attendanceText("共 {total} 条，请选择记录。", { total: page.totalCount });
            } catch (error) { if (current === request) { attendanceLastDiagnostic = error.message; status.dataset.attendanceText = "暂时无法读取对象列表，请重试。"; status.textContent = attendanceText("暂时无法读取对象列表，请重试。"); status.setAttribute("role", "alert"); } }
        }
        searchButton.addEventListener("click", () => attendanceLoadObjects());
        keyword.addEventListener("keydown", event => { if (event.key === "Enter") { event.preventDefault(); attendanceLoadObjects(); } });
        attendanceLoadObjects();
        // 宿主销毁关联编辑窗口时同步释放当前选择器，旧查询不回填其他窗口。
        return { destroy() { if (selectorWindow !== attendanceSelectorWindow) return; attendanceSelectorGrid?.destroy(); attendanceSelectorGrid = null; attendanceSelectorWindow = null; selectorWindow.destroy(); } };
    }
    // 业务文案只翻译明确键，不改变员工名称、主键、工时结果或后台诊断原文。
    function attendanceText(key, values = {}) {
        return Object.entries(values).reduce((text, [name, value]) => text.split(`{${name}}`).join(String(value)), attendanceMessages[key] || key);
    }
    // 显式业务文案节点登记原始键，语言刷新仅改 textContent，保留按钮与输入节点及草稿。
    function attendanceUiElement(tag, key, className, values = {}) {
        const element = attendanceElement(tag, attendanceText(key, values), className); element.dataset.attendanceText = key;
        if (Object.keys(values).length) element.dataset.attendanceTextValues = JSON.stringify(values);
        return element;
    }
    // 读取本域和公共 Window 的真实同源语言资源；原位刷新当前实际记录，语言切换不重新查询或丢弃焦点。
    async function attendanceChangeLocale(locale) {
        if(attendancePeople&&!attendancePeople.canLeave()){attendanceFeedback("请先保存或核对通用人员操作。",true);return false;}
        attendancePeople?.destroy();attendancePeople=null;
        attendanceClassrooms?.destroy();attendanceClassrooms=null;
        const epoch = ++attendanceLocaleEpoch;
        if (!["zh-CN", "ja-JP", "en-US"].includes(locale)) locale = "zh-CN";
        try {
            const [business, windowMessages, personalizationMessages, dateMessages] = await Promise.all([
                selAjax.json({ url: `./i18n/${locale}.json?v=20261028-employee-display1` }), selAjax.json({ url: `/sel/components/window/i18n/${locale}.json` }),
                selAjax.json({ url: `/sel/components/personalization/i18n/${locale}.json` }),
                selAjax.json({ url: `/sel/components/date-picker/i18n/${locale}.json` })
            ]);
            if (epoch !== attendanceLocaleEpoch) return;
            const focused = document.activeElement;
            attendanceLocale = locale; attendanceMessages = business.messages; attendanceWindowMessages = windowMessages; attendanceDateMessages = dateMessages;
            selBase.preference.set("selplat.attendance.locale", locale); document.documentElement.lang = locale;
            if (!attendancePersonalization) {
                attendancePersonalization = personalization.mount(selBase.query("[data-attendance-personalization]"), {
                    backgroundController: attendanceBackground,
                    messages: personalizationMessages,
                    pageEditor: { canEdit: false },
                    locale: { current: locale, onChange: attendanceChangeLocale }
                });
                if (!attendancePersonalization) throw new Error("公共个性化设置未能挂载。");
            } else {
                attendancePersonalization.setLocale({ locale, resource: personalizationMessages });
            }
            // 已选择记录的业务摘要翻译原位更新，不重置输入或把详情当权限来源。
            attendanceCommandForms.forEach((command, path) => {
                const record = command.record;
                if (record && command.context) command.context.textContent = path === "/api/attendance/employee/update.htm"
                ? attendanceText("所选员工：{name}；编号：{code}", {name: record.employeeName, code: record.employeeNo}) : path === "/api/attendance/shifttemplate/update.htm"
                    ? attendanceText("所选模板：{code}；修订：{revision}", { code: record.templateCode, revision: record.revision }) : path === "/api/attendance/ruleconfig/update.htm"
                    ? attendanceText("所选规则：{code}；修订：{revision}", { code: record.ruleCode, revision: record.revision }) : path.endsWith("action.htm")
                    ? attendanceText("所选处理单：{id}；状态：{state}；申请说明：{reason}", { id: record.id, state: attendanceText(record.caseStatus), reason: record.reasonText || "—" })
                    : attendanceText("所选日次：{id}；日期：{date}；实际分钟：{minutes}", { id: record.id, date: record.workDate, minutes: record.actualWorkMinutes });
            });
            for (const command of [...attendanceCommandForms.values(),attendanceBatchCommand].filter(Boolean)) {
                command.window?.setLocale({title:attendanceText(command.title)+(command.record?.id?" · "+command.record.id:""),closeLabel:attendanceText("关闭操作窗口"),messages:windowMessages});
            }
            attendanceBatchCommand?.renderPreview();
            attendanceHost.querySelectorAll("[data-attendance-text]").forEach(node => { node.textContent = attendanceText(node.dataset.attendanceText, node.dataset.attendanceTextValues ? JSON.parse(node.dataset.attendanceTextValues) : {}); });
            attendanceHost.querySelectorAll("[data-attendance-aria]").forEach(node => { node.setAttribute("aria-label", attendanceText(node.dataset.attendanceAria)); });
            for (const command of [...attendanceCommandForms.values(),attendanceBatchCommand].filter(Boolean)) attendanceRefreshDropdowns(command.form);
            attendanceRefreshDates(attendanceQuery);
            panel.setLocale(attendancePanel, { view: attendancePanelView(), sidebarResizeLabel: attendanceText("调整左侧区域宽度") });
            attendanceNavigation?.setLocale(attendanceNavigationData());
            attendanceWorkspaceTabs.setLocale({ items: [{ id: "workspace", label: attendanceText(attendanceModule.title) }] });
            // 工具栏原位翻译，不重建动作按钮或覆盖当前焦点。
            attendanceSessionActions.setLocale({ actions: { login: attendanceText("登录统一认证"), reload: attendanceText("重新核验会话"), diagnostic: attendanceText("诊断") } });
            attendanceReleaseVersionsForm?.setLocale({ fields: { freezeId: attendanceText("冻结主键"), sourceVersion: attendanceText("来源月结版本"), freezeHash: attendanceText("冻结摘要") } });
            if (attendanceGrid && attendanceLastPage) attendanceGrid.setLocale(attendancePayload(attendanceLastPage));
            if (attendanceFeedbackArguments) { const { message, error, parameters } = attendanceFeedbackArguments; attendanceFeedback(message, error, parameters); }
            if (attendanceSelectorGrid && attendanceSelectorPage) attendanceSelectorGrid.setLocale(attendancePayload(attendanceSelectorPage, attendanceSelectorModule(attendanceSelectorEntity)));
            attendanceApprovalWindow?.setLocale({ title: attendanceText("审批时间与规则对比"), closeLabel: attendanceText("关闭审批窗口"), messages: windowMessages });
            if (attendanceApprovalGrid && attendanceApprovalWindow) attendancePreviewApproval();
            attendanceDiagnosticWindow?.setLocale({ title: attendanceText("考勤诊断"), closeLabel: attendanceText("关闭诊断窗口"), messages: windowMessages });
            attendanceBindingWindow?.setLocale({ title: attendanceText("管理员工账号绑定"), closeLabel: attendanceText("关闭账号绑定窗口"), messages: windowMessages });
            if (attendanceSelectorWindow && attendanceSelectorEntity) attendanceSelectorWindow.setLocale({ title: attendanceText("选择{object}", { object: attendanceText(attendanceSelectorModule(attendanceSelectorEntity).title) }), closeLabel: attendanceText("关闭对象选择窗口"), messages: windowMessages });
            if (focused?.isConnected) focused.focus({ preventScroll: true });
            return true;
        } catch (error) { attendanceFeedback(error.message, true); return false; }
    }
    // 诊断独立挂入 SEL UI Window；只显示最近错误和当前业务位置，不展示账号凭据或主页面测试说明。
    function attendanceOpenDiagnostic() {
        attendanceDiagnosticWindow?.destroy();
        const content = attendanceElement("section", undefined, "selform-root");
        content.append(attendanceElement("p", attendanceText("当前位置：{object}", { object: attendanceText(attendanceModule.title) })), attendanceElement("p", attendanceLastDiagnostic));
        attendanceDiagnosticWindow = windowComponent.mount(attendanceWindowHost, {
            id: "AttendanceDiagnostics", title: attendanceText("考勤诊断"), closeLabel: attendanceText("关闭诊断窗口"), messages: attendanceWindowMessages, content, showActions: false
        });
        attendanceDiagnosticWindow.open();
    }
    attendancePanel.addEventListener("click", event => {
        const command = event.target.closest("[data-panel-command]")?.dataset.panelCommand;
        if (command === "diagnostic") attendanceOpenDiagnostic();
        if (command === "reload") attendanceCheckSession();
        if (command === "login") window.location.assign("/uniauth/login.html");
    });
    window.addEventListener('selplat:identityChanged', attendanceCheckSession);
    window.addEventListener('selplat:identityInvalidated',()=>{
        ++attendanceSessionEpoch;attendanceDrafts.clear();attendanceConfiguration=null;attendanceConnection="anonymous";
        attendanceNavigation?.setData(attendanceNavigationData());
        attendanceSelect(attendanceModule);attendanceRenderConnection();attendanceFeedback("尚未登录，请先登录统一认证。");
    });
    window.addEventListener('pagehide',()=>{attendanceDestroyCommandWindows();attendancePeople?.destroy();attendancePeople=null;
        attendanceClassrooms?.destroy();attendanceClassrooms=null;});
    attendanceChangeLocale(attendanceLocale).finally(attendanceCheckSession);
})();
