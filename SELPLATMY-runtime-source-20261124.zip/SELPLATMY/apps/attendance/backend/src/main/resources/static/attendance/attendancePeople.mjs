/** 通用考勤人员管理：SelUI Window/Form/Grid/Dropdown/Confirm；真实独立建档、版本修改与教学关联查询，原员工业务不变。 */
export function attendanceMountPeople(host,{locale='zh-CN',canManage=()=>false,chooseEmployee}={}){
 const selBase=window.sel;
 const {'core.element':element,'net.ajax':ajax,'components.window':windows,'components.form':forms,'components.grid':grids,'components.dropdownMenu':dropdown,'components.confirmDialog':confirmations}=selBase.require(['core.element','net.ajax','components.window','components.form','components.grid','components.dropdownMenu','components.confirmDialog']);
 const lifetime=new AbortController(),windowId='selWindowAttendancePeopleId';let active=null,disposed=false,opening=false,confirmation,referenceWindow;
 const tr=(zh,en,ja)=>locale==='en-US'?en:locale==='ja-JP'?ja:zh;
 const validId=v=>typeof v==='string'&&/^[1-9]\d{0,18}$/.test(v)&&BigInt(v)<=9223372036854775807n;
 const validVersion=v=>typeof v==='string'&&/^(0|[1-9]\d{0,18})$/.test(v)&&BigInt(v)<=9223372036854775807n;
 const kinds=[['STUDENT','学生','Student','学生'],['TEACHER','教师','Teacher','教師'],['STAFF','员工用途','Staff use','職員用途'],['OTHER','其他','Other','その他']];
 const states=[['ACTIVE','启用','Active','有効'],['INACTIVE','停用','Inactive','無効']];
 const kindLabel=v=>{const row=kinds.find(r=>r[0]===v);return row?tr(...row.slice(1)):v;};
 const stateLabel=v=>{const row=states.find(r=>r[0]===v);return row?tr(...row.slice(1)):v;};
 const live=s=>active===s&&!disposed&&!s.events.signal.aborted;
 const blocked=s=>s.busy||s.choosingEmployee||Boolean(s.intent)||s.storageFault;
 /** 只有原写入正文和真实已知回执进入本身份恢复区；名单与教学关系始终从后台读取。 */
 function persist(s,body,receipt=null){try{sessionStorage.setItem(s.storageKey,JSON.stringify({version:1,body,receipt}));}catch{s.storageFault=true;throw Error(tr('无法保存操作恢复材料，请检查浏览器存储。','Cannot persist recovery material. Check browser storage.','復元情報を保存できません。ブラウザーの保存領域を確認してください。'));}}
 function clearStored(s){try{sessionStorage.removeItem(s.storageKey);}catch{s.storageFault=true;throw Error(tr('无法清理恢复材料，请检查浏览器存储。','Cannot clear recovery material. Check browser storage.','復元情報を削除できません。ブラウザーの保存領域を確認してください。'));}}
 /** 公共Dropdown和Form同一禁用状态；未知结果锁住原正文，不换UUID或来源版本。 */
 function sync(s){
  const locked=blocked(s);s.query.setDisabled(locked);s.profile.setDisabled(locked);s.selects.forEach(input=>dropdown.refresh(input));
  s.tools.setActionState('new',{disabled:locked});s.tools.setActionState('edit',{disabled:locked||!s.selected});s.tools.setActionState('references',{disabled:locked||!s.selected});
  s.footer.setActionState('save',{hidden:s.view!=='edit',disabled:s.busy||s.storageFault||s.reviewRequired||(!s.intent&&!s.dirty)});
  s.footer.setLocale({actions:{save:s.receipt?tr('核对保存结果','Review saved result','保存結果を確認'):s.intent?tr('重试原保存','Retry original save','元の保存を再試行'):tr('保存','Save','保存')}});
  s.footer.setActionState('back',{hidden:s.view!=='edit',disabled:locked});s.footer.setActionState('close',{disabled:locked});s.window.setLoading(s.busy);
  s.listView.hidden=s.view!=='list';s.editView.hidden=s.view!=='edit';
  const eligible=['TEACHER','STAFF'].includes(s.profile.getField('personKind').value);s.employeeHost.hidden=!eligible&&!s.baseline?.employeeId&&!s.employeeChange;
  s.employee.setDisabled(locked||canManage()!==true);employeeSummary(s);
 }
 /** 只让当前身份窗口的回调更新状态，业务失败不伪造空成功。 */
 async function run(s,work){if(!live(s)||s.busy)return false;s.busy=true;sync(s);s.window.setFeedback('');try{return await work();}catch(error){if(live(s)&&error.name!=='AbortError')s.window.setFeedback(error.message,true);return false;}finally{if(live(s)){s.busy=false;sync(s);}}}
 async function call(s,path,input={},method='GET'){
  const result=await ajax.request({url:method==='GET'?'/api/attendance/person/'+path+'?'+new URLSearchParams(input):'/api/attendance/person/'+path,method,...(method==='POST'?{data:input}:{}),signal:s.events.signal});
  return path==='getStore.htm'?result:result.data;
 }
 /** 安全详情必须是原人员编号和精确版本，不把考勤人员解释为雇员或教学任职。 */
 function record(row,id){if(!row||!validId(row.id)||(id&&row.id!==id)||!validVersion(row.versionNo)||typeof row.personName!=='string'||typeof row.personNumber!=='string'||!kinds.some(k=>k[0]===row.personKind)||!states.some(k=>k[0]===row.personState)||(row.employeeId&&!validId(row.employeeId)))throw Error('ATTENDANCE_PERSON_RESULT_INVALID');return row;}
 /** 使用拥有方真实分页，翻页沿已确认查询，不把尚未提交的新搜索词混入后页。 */
 function render(s,page={records:[],pageNo:1,pageSize:20,totalCount:0}){
  s.rendering=true;try{s.grid.setLocale({grid:{mode:'records',idField:'id',selectionMode:'SINGLE',minTableWidth:0},title:{messages:{selectProject:tr('通用人员','People','人物管理')}},column:{resizeLabelTemplate:tr('调整 {label} 列宽','Resize {label} column','{label}列の幅を変更'),ariaLabel:tr('通用人员名单','People records','人物一覧'),emptyText:tr('没有符合条件的人员','No matching people','該当する人物はありません'),items:[{field:'personName',label:tr('姓名','Name','氏名')},{field:'personNumber',label:tr('人员编号','Person number','人物番号')},{field:'kindLabel',label:tr('用途','Use','用途')},{field:'stateLabel',label:tr('状态','State','状態')},{field:'employeeLabel',label:tr('原员工','Employee source','元の職員')}]},pagination:{mode:'REMOTE',visible:true,currentPage:page.pageNo,pageSize:20,totalCount:page.totalCount,ariaLabel:tr('人员分页','People pages','人物のページ'),previousLabel:tr('上一页','Previous page','前のページ'),nextLabel:tr('下一页','Next page','次のページ'),summaryAll:tr('共 {total} 人','{total} people','合計 {total} 人'),summaryFiltered:tr('共 {total} 人','{total} people','合計 {total} 人'),pageChangedMessage:tr('第 {page} 页','Page {page}','{page} ページ')},data:{items:page.records.map(row=>({...record(row),kindLabel:kindLabel(row.personKind),stateLabel:stateLabel(row.personState),employeeLabel:row.employeeId?tr('员工记录：','Employee record: ','職員レコード：')+row.employeeId:'—'})),selectedIds:s.selected?[s.selected.id]:[]}});}finally{s.rendering=false;}
 }
 async function load(s,pageNo=1,fresh=false){
  return run(s,async()=>{
   if(fresh){s.queryBody={};const name=s.query.getField('name').value.trim(),kind=s.query.getField('kind').value,state=s.query.getField('state').value;if(name)s.queryBody.personNameContainsIgnoreCase=name;if(kind)s.queryBody.personKind=kind;if(state)s.queryBody.personState=state;}
   s.rows=[];s.selected=null;render(s);sync(s);const page=await call(s,'getStore.htm',{...s.queryBody,pageNo,pageSize:20});if(!live(s))return false;
   if(!Array.isArray(page.records)||page.pageNo!==pageNo||page.pageSize!==20||!Number.isSafeInteger(page.totalCount)||page.totalCount<0)throw Error('ATTENDANCE_PERSON_RESULT_INVALID');s.rows=page.records.map(row=>record(row));s.pageNo=pageNo;render(s,page);return true;
  });
 }
 /** 以真实详情编辑；编号空白仅用于新增，实际自动编号从保存后详情读取。 */
 async function edit(s,id=null){
  if(blocked(s))return;await run(s,async()=>{const baseline=id?record(await call(s,'getById.htm',{id}),id):null;if(!live(s))return;s.baseline=baseline;s.reviewRequired=false;s.employeeChange=false;s.employeeChoice=null;s.employeeBaseline=null;s.employeeNeedsReview=false;s.profile.setValues(baseline||{personName:'',personNumber:'',personKind:'STUDENT',personState:'ACTIVE'});s.selects.forEach(input=>dropdown.refresh(input));s.view='edit';s.dirty=!baseline;
   // 重开仅读取原已保存员工的安全摘要；不将显示姓名视为一次员工关系变更。
   if(baseline?.employeeId&&canManage()===true){const response=await ajax.request({url:'/api/attendance/employee/person-reference.htm?'+new URLSearchParams({id:baseline.employeeId}),signal:s.events.signal});if(!live(s))return;const source=response.data;if(source?.id!==baseline.employeeId||typeof source.employeeName!=='string'||typeof source.employeeNo!=='string'||!/^[0-9a-f]{64}$/.test(source.sourceVersion))throw Error('ATTENDANCE_EMPLOYEE_REFERENCE_CHANGED');s.employeeBaseline=source;}
  });
 }
 /** 员工来源只显示实际已关联编号或本次核对摘要，不把查找输入当成已保存关系。 */
 function employeeSummary(s){const chosen=s.employeeChange?s.employeeChoice:s.employeeBaseline;const id=s.employeeChange?chosen?.id:s.baseline?.employeeId;const text=s.employeeNeedsReview?tr('员工编号尚未核对；请核对或保留原关联。','Review the employee ID or keep the existing link.','職員番号を確認するか元の関連を保持してください。'):id?[(chosen?.employeeName||tr('原员工','Employee','元の職員')),chosen?.employeeNo,id].filter(Boolean).join(' · ')+(s.employeeChange?tr('（待保存）',' (unsaved)','（未保存）'):''):s.employeeChange?tr('解除关联（待保存）','Unlink (unsaved)','関連解除（未保存）'):tr('未关联员工','No employee link','職員の関連なし');s.employee.setValues({employeeSummary:text});}
 /** 只按原员工公开安全接口核对主键；核对失败立即撤回先前候选，不改变已保存关系。 */
 async function reviewEmployee(s,id){if(blocked(s)||canManage()!==true)return;await run(s,async()=>{s.employeeChoice=null;s.employeeChange=false;s.employeeNeedsReview=true;if(!validId(id))throw Error(tr('请输入有效的原员工编号。','Enter a valid employee ID.','有効な職員番号を入力してください。'));
  const response=await ajax.request({url:'/api/attendance/employee/person-reference.htm?'+new URLSearchParams({id}),signal:s.events.signal});if(!live(s))return;const row=response.data;
  if(row?.id!==id||typeof row.employeeName!=='string'||typeof row.employeeNo!=='string'||!/^[0-9a-f]{64}$/.test(row.sourceVersion))throw Error('ATTENDANCE_EMPLOYEE_REFERENCE_CHANGED');s.employeeChoice=row;s.employeeChange=true;s.employeeNeedsReview=false;s.dirty=true;
 });}
 /** 放弃仅针对未发送草稿；结果未知和已知回执都必须核对，不以关闭冒充取消。 */
 async function discard(s){
  if(blocked(s))return false;if(s.dirty){confirmation??=confirmations.mount(host,{id:'selConfirmDialogAttendancePeopleId'});const approved=await confirmation.open({title:tr('放弃修改','Discard changes','変更を破棄'),message:tr('放弃当前尚未保存的人员资料？','Discard these unsaved person details?','未保存の人物情報を破棄しますか？'),confirmLabel:tr('放弃修改','Discard changes','変更を破棄'),cancelLabel:tr('继续编辑','Keep editing','編集を続ける')});if(!live(s)||approved!==true)return false;}
  s.dirty=false;s.view='list';sync(s);return true;
 }
 /** 原请求先持久再写入；已知回执只回读，丢响应刷新后仍沿原UUID重试。 */
 async function save(s){
  if(!live(s)||s.busy||s.storageFault||(!s.intent&&!s.dirty))return;
  if(!s.intent){
   const body={personName:s.profile.getField('personName').value.trim(),personNumber:s.profile.getField('personNumber').value.trim(),personKind:s.profile.getField('personKind').value,personState:s.profile.getField('personState').value,requestKey:crypto.randomUUID(),...(s.baseline?{id:s.baseline.id,expectedVersion:s.baseline.versionNo}:{})};
   if(s.employeeNeedsReview){s.window.setFeedback(tr('请先核对员工编号或保留原关联。','Review the employee ID or keep the original link.','職員番号を確認するか元の関連を保持してください。'),true);return;}
   if(s.employeeChange){body.employeeId=s.employeeChoice?.id||'0';if(s.employeeChoice)body.expectedEmployeeSourceVersion=s.employeeChoice.sourceVersion;}
   if(!body.personName){s.window.setFeedback(tr('请输入姓名。','Enter a name.','氏名を入力してください。'),true);return;}
   if(s.baseline&&(body.personKind!==s.baseline.personKind||body.personState!==s.baseline.personState)){
    confirmation??=confirmations.mount(host,{id:'selConfirmDialogAttendancePeopleId'});const approved=await confirmation.open({title:tr('确认人员状态变更','Confirm person state change','人物状態の変更を確認'),target:s.baseline.personName,message:tr('用途或启用状态变化会影响后续可选范围；原教学关联与历史保留，不删除员工或客户。','Changing use or state affects future selection. Existing links and history remain; employees and customers are preserved.','用途・有効状態の変更は今後の選択範囲に影響します。元の関連・履歴は保持され、職員・顧客は削除されません。'),confirmLabel:tr('确定保存','Confirm save','保存を確定'),cancelLabel:tr('取消','Cancel','キャンセル')});if(!live(s)||approved!==true)return;
   }
   if(s.employeeChange){confirmation??=confirmations.mount(host,{id:'selConfirmDialogAttendancePeopleId'});const approved=await confirmation.open({title:tr('确认员工关联变更','Confirm employee link change','職員の関連変更を確認'),target:body.personName,message:tr('保存本次员工关联。原员工资料、打卡和报表保留，不创建或删除员工。','Save this employee link. Employee details, punches and reports remain; no employee is created or deleted.','職員の関連を保存します。元の情報・打刻・帳票は保持し、職員の作成・削除は行いません。'),confirmLabel:tr('确定保存','Confirm save','保存を確定'),cancelLabel:tr('取消','Cancel','キャンセル')});if(!live(s)||approved!==true)return;}
   try{persist(s,body);s.intent=body;}catch(error){s.window.setFeedback(error.message,true);sync(s);return;}
  }
  const success=await run(s,async()=>{
   if(!s.receipt){
    try{const saved=await call(s,'save.htm',structuredClone(s.intent),'POST');if(!live(s))return false;if(!validId(saved?.id)||!validVersion(saved.versionNo)||(s.intent.id&&saved.id!==s.intent.id))throw Error('ATTENDANCE_PERSON_RESULT_INVALID');persist(s,s.intent,saved);s.receipt=saved;}
    catch(error){if(live(s)&&['ATTENDANCE_PERSON_INPUT_INVALID','ATTENDANCE_PERSON_VERSION_CONFLICT','ATTENDANCE_PERSON_REQUEST_CONFLICT','ATTENDANCE_PERSON_NUMBER_EXISTS','ATTENDANCE_PERSON_NOT_FOUND','ATTENDANCE_PERSON_HISTORY_LIMIT','ATTENDANCE_PERSON_ACCESS_DENIED','ATTENDANCE_PERSON_EMPLOYEE_OCCUPIED','ATTENDANCE_PERSON_EMPLOYEE_KIND_INVALID','ATTENDANCE_EMPLOYEE_REFERENCE_CHANGED','ATTENDANCE_MANAGEMENT_UNAVAILABLE'].includes(error.errorCode)){const original=s.intent;clearStored(s);s.intent=null;s.receipt=null;if(original.id){s.reviewRequired=true;s.baseline??={id:original.id,versionNo:original.expectedVersion};}if(original.employeeId&&original.employeeId!=='0'){s.employeeChoice=null;s.employeeChange=false;s.employeeNeedsReview=true;}if(s.reviewRequired)error.message+=' '+tr('请返回名单重新读取当前人员，再核对后保存。','Return to the list and reload this person before reviewing and saving.','一覧に戻り、この人物を再読込して確認後に保存してください。');}throw error;}
   }
   const saved=record(await call(s,'getById.htm',{id:s.receipt.id}),s.receipt.id);if(!live(s))return false;if(BigInt(saved.versionNo)<BigInt(s.receipt.versionNo))throw Error('ATTENDANCE_PERSON_RESULT_INVALID');
   clearStored(s);s.intent=null;s.receipt=null;s.dirty=false;s.view='list';return true;
  });
  if(live(s)&&success){const listed=await load(s,1);if(live(s)&&listed)s.window.setFeedback(tr('人员资料已保存并重新读取。','Person details saved and reloaded.','人物情報を保存し再読込しました。'));}
 }
 /** 销毁只撤回UI；已发送原请求继续由拥有方幂等处理，恢复材料保留。 */
 function close(force=false){const s=active;if(!s)return;if(!force&&(blocked(s)||s.dirty)){s.window.open();s.window.setFeedback(tr('请先保存、放弃草稿或核对原保存结果。','Save, discard the draft, or review the original save first.','保存・草稿の破棄・元の保存結果の確認を先に行ってください。'),true);return;}confirmation?.close();active=null;s.employeePicker?.destroy();s.events.abort();s.selects.forEach(input=>dropdown.destroy(input));s.grid.destroy();[s.query,s.tools,s.profile,s.employee,s.footer].forEach(f=>f.destroy());s.window.destroy();referenceWindow?.destroy();referenceWindow=null;}
 /** 所有选择器使用公共Dropdown，而非只隐藏原生select；布局只隐藏应用自己的视图区。 */
 function mountForm(s,host,id,fields,actions=[]){const form=forms.mount(host,{id,layout:'toolbar',fields,actions});for(const field of fields)if(field.type==='select'){const input=form.getField(field.id),shell=element('div',{className:'seldropdown-root',attributes:{'data-sel-dropdown-menu':'','data-sel-dropdown-menu-label':field.label,'data-sel-dropdown-menu-current-template':'{label}：{value}'}});input.before(shell);shell.append(input);dropdown.mount(shell);s.selects.push(input);}return form;}
 host.addEventListener('selWindow:close',event=>{if(event.detail?.id===windowId&&active&&!active.choosingEmployee)close();},{signal:lifetime.signal});
 window.addEventListener('beforeunload',event=>{if(active&&(blocked(active)||active.dirty)){event.preventDefault();event.returnValue='';}},{signal:lifetime.signal});
 for(const event of ['selplat:identityChanged','selplat:identityInvalidated','pagehide'])window.addEventListener(event,()=>close(true),{signal:lifetime.signal});
 return {canLeave(){return !active||(!blocked(active)&&!active.dirty);},destroy(){close(true);disposed=true;confirmation?.destroy();lifetime.abort();},async open(){
  if(disposed||opening)return;if(active){active.window.open();return;}
  opening=true;let identity;try{identity=await (await import('/platform/account-session-state.mjs?v=20261017-session-once1')).readPlatformSession();}finally{opening=false;}if(disposed||active)return;if(!Number.isSafeInteger(identity?.tenantId)||!Number.isSafeInteger(identity?.userId))throw Error('ATTENDANCE_PERSON_IDENTITY_REQUIRED');
  const s={events:new AbortController(),selects:[],rows:[],selected:null,baseline:null,busy:false,dirty:false,intent:null,receipt:null,storageFault:false,view:'list',queryBody:{},pageNo:1};active=s;s.storageKey='attendance.people.v1:'+identity.tenantId+':'+identity.userId;
  const content=element('section'),listView=element('section'),editView=element('section'),note=element('p',{text:tr('管理学生、教师等通用考勤人员。原员工档案、账号绑定、打卡和报表继续在原菜单办理；这里不代建雇员。','Manage general attendance people. Employee records, account links, punches and reports remain in their original menus; no employee is created here.','学生・教師などの勤怠人物を管理します。職員記録・アカウント連携・打刻・帳票は元のメニューにあり、ここでは職員を作成しません。')}),queryHost=element('div'),toolsHost=element('div'),gridHost=element('section'),profileHost=element('div'),footerHost=element('div');
  listView.append(queryHost,toolsHost,gridHost);editView.append(profileHost);s.employeeHost=element('section');editView.append(s.employeeHost);content.append(note,listView,editView);s.listView=listView;s.editView=editView;
  const options=rows=>rows.map(r=>({value:r[0],label:tr(...r.slice(1))}));
  s.query=mountForm(s,queryHost,'selFormAttendancePeopleQueryId',[{id:'name',label:tr('姓名包含','Name contains','氏名に含む'),maxLength:100},{id:'kind',label:tr('用途筛选','Filter use','用途絞り込み'),type:'select',options:[{value:'',label:tr('全部用途','All uses','すべての用途')},...options(kinds)]},{id:'state',label:tr('状态筛选','Filter state','状態絞り込み'),type:'select',options:[{value:'',label:tr('全部状态','All states','すべての状態')},...options(states)]}],[{id:'find',label:tr('查询','Search','検索')}]);
  s.tools=forms.mount(toolsHost,{id:'selFormAttendancePeopleToolsId',layout:'toolbar',actions:[{id:'new',label:tr('新增人员','Add person','人物を追加'),tone:'primary'},{id:'edit',label:tr('修改资料','Edit details','情報を編集')},{id:'references',label:tr('教学关联','Teaching links','教学の関連')}]});
  s.grid=grids.mount(grids.create(gridHost,{gridId:'selGridAttendancePeopleId'}),{title:{messages:{selectProject:'人物记录'}},grid:{mode:'records',idField:'id',selectionMode:'SINGLE'},column:{items:[]},pagination:{mode:'REMOTE',visible:true,currentPage:1,pageSize:20,totalCount:0},data:{items:[]}});
  s.profile=mountForm(s,profileHost,'selFormAttendancePeopleProfileId',[{id:'personName',label:tr('姓名','Name','氏名'),maxLength:100,required:true},{id:'personNumber',label:tr('人员编号（新增可留空）','Person number (optional for new)','人物番号（新規は省略可）'),maxLength:100},{id:'personKind',label:tr('用途','Use','用途'),type:'select',options:options(kinds)},{id:'personState',label:tr('状态','State','状態'),type:'select',options:options(states)}]);
  s.employee=mountForm(s,s.employeeHost,'selFormAttendancePeopleEmployeeId',[{id:'employeeSummary',label:tr('员工关联','Employee link','職員の関連'),readOnly:true}],[{id:'choose',label:tr('选择员工','Choose employee','職員を選択')},{id:'clear',label:tr('解除员工关联','Unlink employee','職員の関連を解除')},{id:'keep',label:tr('保留原关联','Keep original link','元の関連を保持')}]);
  s.footer=forms.mount(footerHost,{id:'selFormAttendancePeopleFooterId',layout:'toolbar',actions:[{id:'back',label:tr('返回名单','Back to list','一覧に戻る')},{id:'save',label:tr('保存','Save','保存'),tone:'primary'},{id:'close',label:tr('关闭','Close','閉じる')}]});
  s.window=windows.mount(host,{id:windowId,title:tr('通用人员','People','人物管理'),rows:[],headerLayout:'content',surface:'reading',content,footerContent:footerHost});s.window.setDefaultGeometry({width:1100,height:760,minWidth:380,minHeight:480});s.window.setSubmitState({hidden:true});
  try{const raw=sessionStorage.getItem(s.storageKey);if(raw){if(raw.length>16384)throw Error('Invalid recovery data');const saved=JSON.parse(raw),b=saved.body;
   if(saved.version!==1||!b||Object.keys(b).some(k=>!['id','expectedVersion','personName','personNumber','personKind','personState','requestKey','employeeId','expectedEmployeeSourceVersion'].includes(k))||typeof b.personName!=='string'||typeof b.personNumber!=='string'||!kinds.some(k=>k[0]===b.personKind)||!states.some(k=>k[0]===b.personState)||typeof b.requestKey!=='string'||!/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/.test(b.requestKey)||(b.id&&(!validId(b.id)||!validVersion(b.expectedVersion)))||(saved.receipt&&(!validId(saved.receipt.id)||!validVersion(saved.receipt.versionNo)||(b.id&&b.id!==saved.receipt.id))))throw Error('Invalid recovery data');
   if(b.employeeId===undefined&&b.expectedEmployeeSourceVersion!==undefined)throw Error('Invalid employee recovery data');
   if(b.employeeId!==undefined&&!(b.employeeId==='0'&&!b.expectedEmployeeSourceVersion||validId(b.employeeId)&&/^[0-9a-f]{64}$/.test(b.expectedEmployeeSourceVersion)))throw Error('Invalid employee recovery data');
   if(b.id)s.baseline={id:b.id,versionNo:b.expectedVersion};s.employeeChange=b.employeeId!==undefined;s.employeeChoice=b.employeeId&&b.employeeId!=='0'?{id:b.employeeId,sourceVersion:b.expectedEmployeeSourceVersion}:null;
   s.intent=b;s.receipt=saved.receipt;s.profile.setValues(b);s.dirty=true;s.view='edit';}}
  catch{s.storageFault=true;}
  s.query.getAction('find').addEventListener('click',()=>{if(!blocked(s))load(s,1,true);},{signal:s.events.signal});
  s.tools.getAction('new').addEventListener('click',()=>edit(s),{signal:s.events.signal});s.tools.getAction('edit').addEventListener('click',()=>{if(s.selected)edit(s,s.selected.id);},{signal:s.events.signal});
  s.tools.getAction('references').addEventListener('click',async()=>{if(blocked(s)||!s.selected||s.openingReferences)return;const targetId=s.selected.id;s.openingReferences=true;try{const owner=await import('/platform/teaching-person-references.mjs?v=20261027-references3');if(!live(s))return;referenceWindow??=owner.platformMountTeachingPersonReferences(host,{locale});await referenceWindow.open({target:'ATTENDANCE',targetId});}catch(error){if(live(s))s.window.setFeedback(error.message,true);}finally{if(live(s))s.openingReferences=false;}},{signal:s.events.signal});
  // 复用工作台原员工选择Window；取消保留草稿，选中后仍走拥有方版本核验，不用姓名推断关联。
  s.employee.getAction('choose').addEventListener('click',()=>{
   if(blocked(s)||canManage()!==true||typeof chooseEmployee!=='function')return;
   s.choosingEmployee=true;sync(s);s.window.close();
   const restore=()=>{if(live(s)){s.choosingEmployee=false;s.window.open();sync(s);}};
   try{s.employeePicker=chooseEmployee(row=>{if(!live(s))return;restore();const id=Number.isSafeInteger(row.id)?String(row.id):row.id;reviewEmployee(s,id);},restore);}catch(error){restore();s.window.setFeedback(error.message,true);}
  },{signal:s.events.signal});
  s.employee.getAction('clear').addEventListener('click',()=>{if(blocked(s)||canManage()!==true)return;s.employeeChoice=null;s.employeeChange=true;s.employeeNeedsReview=false;s.dirty=true;sync(s);},{signal:s.events.signal});
  s.employee.getAction('keep').addEventListener('click',()=>{if(blocked(s))return;s.employeeChoice=null;s.employeeChange=false;s.employeeNeedsReview=false;sync(s);},{signal:s.events.signal});
  for(const event of ['input','change'])s.profile.root.addEventListener(event,()=>{if(!blocked(s)){s.dirty=true;sync(s);}},{signal:s.events.signal});
  s.grid.root.addEventListener('selGrid:selectionChange',event=>{if(!live(s)||s.rendering)return;if(blocked(s)){s.rendering=true;try{s.grid.setSelectedIds(s.selected?[s.selected.id]:[]);}finally{s.rendering=false;}return;}const id=event.detail?.selectedIds?.[0];s.selected=s.rows.find(row=>row.id===id)||null;sync(s);},{signal:s.events.signal});
  s.grid.root.addEventListener('selGrid:queryChange',event=>{if(live(s)&&!blocked(s)&&event.detail?.reason==='page')load(s,event.detail.pageNo);},{signal:s.events.signal});
  s.footer.getAction('save').addEventListener('click',()=>save(s),{signal:s.events.signal});s.footer.getAction('back').addEventListener('click',async()=>{if(await discard(s))await load(s,s.pageNo);},{signal:s.events.signal});s.footer.getAction('close').addEventListener('click',async()=>{if(s.dirty&&!blocked(s)){if(!await discard(s))return;}close();},{signal:s.events.signal});
  render(s);sync(s);s.window.open();if(s.storageFault)s.window.setFeedback(tr('恢复材料不可用，已停止写入，请检查浏览器存储。','Recovery material unavailable. Writes are blocked; check browser storage.','復元情報が利用できないため書込を停止しました。保存領域を確認してください。'),true);else if(s.intent)s.window.setFeedback(tr('发现原保存请求，请核对结果或重试原保存。','Original save found. Review its result or retry it.','元の保存要求があります。結果の確認または元の保存の再試行を行ってください。'),true);else await load(s);
 }};
}
