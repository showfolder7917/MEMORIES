/* 2026-11-01：打卡与批次原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.punchsourceconfig.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendancePunchSourceConfig 表服务，管理查询复用公共 CRUD；写入仅走本域专用流程。 */
public interface AttendancePunchSourceConfigService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * @param input 来源键和名称，例如 CSV_A/人工CSV
   * @return enabled=0 新增结果；无秘密或外部请求。
   */
  CommonResult register(CommonParam input);

  /**
   * @param sourceSystem 例如 CSV_A
   * @return 实际来源记录；未登记拒绝，仅读。
   */
  CommonResult requireSource(String sourceSystem);

  /**
   * 在本域事务内锁定当前来源并在等待后重新核验管理身份。
   *
   * @param sourceSystem 例如 CSV_A
   * @return 真实已锁来源记录；无来源或权限撤销拒绝，锁由调用方事务释放。
   */
  CommonResult lockSource(String sourceSystem);
}
