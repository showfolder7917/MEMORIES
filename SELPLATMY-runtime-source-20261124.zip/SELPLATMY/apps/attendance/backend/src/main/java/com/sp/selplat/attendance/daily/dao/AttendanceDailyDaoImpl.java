package com.sp.selplat.attendance.daily.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceDaily，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceDailyDaoImpl extends AttendanceBaseDao implements AttendanceDailyDao {
    /**
     * 读取本表真实引用数量，不跨表、不排除历史软删除行。
     *
     * @param input 已核验范围例如 tenantId=81、id=8501
     * @return 实际COUNT例如1，无业务写入；SQL失败保留数据库异常
     */
    @Override
    public long countRuleReferences(com.sp.selplat.common.util.CommonParam input) {
        // 使用本域事务连接执行本表COUNT，避免公共查询缓存丢失新提交事实。
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.queryForObject(
                "SELECT COUNT(*) FROM AttendanceDaily WHERE tenantId=? AND appliedRuleId=?",
                Long.class,
                input.getParam("tenantId"),
                input.getParam("id"));
    }
}
