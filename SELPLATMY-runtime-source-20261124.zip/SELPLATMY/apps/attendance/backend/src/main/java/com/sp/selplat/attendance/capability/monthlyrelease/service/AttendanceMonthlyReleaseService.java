/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
package com.sp.selplat.attendance.capability.monthlyrelease.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 月审签发布完整能力，跨表只经所属服务，未初始化账本默认拒绝。 */
public interface AttendanceMonthlyReleaseService {

  /**
   * 实际月列表。
   *
   * @param input 分页/月筛选例如yearMonth=2026-09
   * @return 已核验独立角色可读列表，无身份授予
   */
  CommonPageResult getStore(CommonPageParam input);

  /**
   * 当前来源与冻结版本。
   *
   * @param input 实际monthlyId例如9301
   * @return 锁中实际来源/冻结/发布状态，仅读取
   */
  CommonResult current(CommonParam input);

  /**
   * 冻结待审核。
   *
   * @param input 明确来源版本/hash/requestKey
   * @return 实际不可变冻结，来源失配拒绝
   */
  CommonResult prepareReview(CommonParam input);

  /**
   * 不同月结人审签。
   *
   * @param input freezeId/hash/sourceVersion及修订/requestKey
   * @return 实际审签结果，同人/过期拒绝
   */
  CommonResult approveReview(CommonParam input);

  /**
   * 独立发布。
   *
   * @param input 同一已审签冻结及期望发布修订/requestKey
   * @return 服务器立即生效的实际发布，尾失败全回滚
   */
  CommonResult publish(CommonParam input);

  /**
   * 当前独立WITHDRAW撤回。
   *
   * @param input 当前发布ID/修订/冻结绑定与必填reason/requestKey
   * @return 实际撤回事实，旧回执不复活
   */
  CommonResult withdraw(CommonParam input);

  /**
   * 方法作用：HTTP读取独立角色所属月列表，原动作选择优先保持
   *
   * @param input 原分页/月条件，例如yearMonth2026-10
   * @return 原CommonPageResult，不授予发布或写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonPageResult readStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：HTTP读取原锁中来源/冻结/版本，不改成无锁观察
   *
   * @param input 原monthlyId，例如61000，客户端动作不参与选择
   * @return 原CommonResult含完整source/hash，锁到原外层事务结束
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readCurrent(com.sp.selplat.common.util.CommonParam input);
}
