/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
/* 2026-11-01：原预览/审批共享算法，HTTP仅选择明确纯读来源。 */
/* 2026-11-01：本人/审批四查询纯读，原提交/CAS/审计/预览保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.attendancecase.service.impl;

import com.sp.selplat.attendance.attendancecase.dao.AttendanceCaseDao;
import com.sp.selplat.attendance.attendancecase.service.AttendanceCaseService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceCase 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceCaseServiceImpl extends BaseServiceImpl<AttendanceCaseDao>
    implements AttendanceCaseService {

  // 真实统一认证会话；拒绝请求自行提交租户和操作员身份。
  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  // 每次查询或内部写入重新核验本域管理授权，不把界面显示当作授权。
  @Autowired private AttendanceAuthorizationService authorization;

  // 日次所属服务执行本人/审批归属核验及最终事实写入，不跨表访问DAO。
  @Autowired private com.sp.selplat.attendance.daily.service.AttendanceDailyService dailyResults;

  // 实际员工地点与部门由所属Service读取，不能信任请求元数据。
  @Autowired private com.sp.selplat.attendance.employee.service.AttendanceEmployeeService employees;

  @Autowired
  private com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService monthlyPeriods;

  // 案件不可改写审计的所属服务，真实身份重新核验后追加。
  @Autowired
  private com.sp.selplat.attendance.caseactionlog.service.AttendanceCaseActionLogService journals;

  // 排班和生效规则分别通过所属审批读取入口获取，管理权限不会隐式放行。
  @Autowired
  private com.sp.selplat.attendance.shiftschedule.service.AttendanceShiftScheduleService schedules;

  // 读取真实日期有效的员工规则关联，优先级与旧算法一致。
  @Autowired
  private com.sp.selplat.attendance.employeeworkrule.service.AttendanceEmployeeWorkRuleService
      assignments;

  // 启用规则配置只经独立审批读取入口获取，不写配置。
  @Autowired
  private com.sp.selplat.attendance.ruleconfig.service.AttendanceRuleConfigService ruleConfigs;

  // 审批重算只追加解释日志，不删除原始计算历史。
  @Autowired
  private com.sp.selplat.attendance.calclog.service.AttendanceCalcLogService calculationLogs;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 原始卡和派生快照通过本域专用流程写入，不能以通用 CRUD 修改工资/工时事实。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用方抛出后无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用对应打卡、计算或审批流程。");
  }

  /**
   * 把真实日次建成处理单，申请身份、员工、租户和角色从当前核验与日次产生。
   *
   * @param input 日次和说明，例如attendanceDailyId=100001、caseType=PUNCH_CORRECTION；忽略applicantId
   * @return
   *     实际CommonResult，例如data.caseId=100002、data.caseStatus=SUBMITTED、data.handlingStatus=IN_REVIEW
   *     异常或副作用示例：本人绑定/管理配置缺失、异租户或活动案件拒绝；三表同事务回滚。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult submit(CommonParam input) {
    Map<String, Long> identity;
    String role;
    boolean owned;
    try {
      identity = authorization.requireManagement();
      role = "MANAGER";
      owned = false;
    } catch (CommonBusinessException noManagement) {
      if (!"ATTENDANCE_MANAGEMENT_UNAVAILABLE".equals(noManagement.getErrorCode())) {
        throw noManagement;
      }
      identity = authorization.requireEmployeeBinding();
      role = "EMPLOYEE";
      owned = true;
    }
    String type =
        input.getParam("caseType") == null ? "" : input.getParam("caseType").toString().trim();
    if (type.isEmpty()) {
      throw new CommonBusinessException("ATTENDANCE_CASE_INPUT_INVALID", "处理单类型不能为空。");
    }
    CommonParam dailyKey = parameter("id", input.getParam("attendanceDailyId"));
    Map<String, Object> daily =
        row(owned ? dailyResults.getOwned(dailyKey) : dailyResults.getById(dailyKey));
    requireMutableDaily(daily);
    daily = row(owned ? dailyResults.getOwned(dailyKey) : dailyResults.getById(dailyKey));
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("attendanceDailyId", daily.get("id"));
    query.put("status", 1);
    java.util.List<Map<String, Object>> latest =
        getDao().getPageList(query, "id desc", 1, 1).getRecords();
    if (!latest.isEmpty()
        && com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.hasActiveCase(
            latest.get(0))) {
      throw new CommonBusinessException("ATTENDANCE_CASE_ACTIVE", "当前日次已有活动处理单。");
    }
    CommonParam created = new CommonParam();
    created.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> employee =
        row(employees.getForCase(parameter("id", daily.get("employeeId"))));
    created.putParam("employeeId", daily.get("employeeId"));
    for (String field : java.util.List.of("workplaceId", "departmentId")) {
      created.putParam(field, employee.get(field));
    }
    created.putParam("attendanceDailyId", daily.get("id"));
    created.putParam("caseType", type);
    created.putParam("caseStatus", "SUBMITTED");
    created.putParam("applicantId", identity.get("userId"));
    created.putParam("applicantRole", role);
    // 不沿用旧硬编码9001审批人；具体动作仍须真实独立APPROVER核验。
    created.putParam("currentApproverId", null);
    for (String field : java.util.List.of("reasonCategory", "reasonText", "expectedResolution")) {
      Object value = input.getParam(field);
      created.putParam(
          field, value == null || value.toString().isBlank() ? null : value.toString().trim());
    }
    created.putParam(
        "dailyBeforeJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(daily));
    created.putParam("revision", 0L);
    created.putParam("patchPayloadJson", "{}");
    created.putParam("submittedAt", java.time.LocalDateTime.now());
    super.insert(created);
    CommonParam dailyState = parameter("id", daily.get("id"));
    dailyState.putParam("action", "SUBMIT");
    dailyResults.applyCaseState(dailyState);
    writeJournal(
        created.getParam("id"),
        "SUBMIT",
        created.getParam("reasonText"),
        daily,
        Map.of("caseStatus", "SUBMITTED"));
    return buildSuccessResult(
        Map.of(
            "caseId",
            created.getParam("id"),
            "attendanceDailyId",
            daily.get("id"),
            "caseStatus",
            "SUBMITTED",
            "handlingStatus",
            "IN_REVIEW"),
        "处理单已提交。");
  }

  /**
   * 沿用旧APPROVE/RETURN/REJECT动作，不新增申请人不能自审或终态禁止动作的业务规则。
   *
   * @param input
   *     案件及补丁，例如id=100002、actionType=APPROVE、patchPayloadJson={actualClockOut:2026-10-04T18:45}
   * @return 实际CommonResult，例如data.caseStatus=APPROVED、data.handlingStatus=RESOLVED
   *     异常或副作用示例：仅管理角色、异租户、无效补丁拒绝；案件、日次指标、两类日志一同回滚。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult applyAction(CommonParam input) {
    Map<String, Long> identity = authorization.requireApproval();
    String action =
        input.getParam("actionType") == null
            ? ""
            : input.getParam("actionType").toString().trim().toUpperCase(java.util.Locale.ROOT);
    if (!java.util.Set.of("APPROVE", "RETURN", "REJECT").contains(action)) {
      throw new CommonBusinessException("ATTENDANCE_CASE_ACTION_INVALID", "处理单动作无效。");
    }
    Map<String, String> outcome =
        com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.caseOutcome(action);
    CommonParam caseKey = parameter("id", input.getParam("id"));
    caseKey.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> before = getDao().lockCase(caseKey);
    if (before == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    // 等待案件锁后重新读取许可；READ_COMMITTED下撤权不能沿用等待前授权。
    if (!identity.equals(authorization.requireApproval())) {
      throw staleCase();
    }
    Map<String, Object> lockedDaily =
        row(dailyResults.getForApproval(parameter("id", before.get("attendanceDailyId"))));
    requireMutableDaily(lockedDaily);
    long revision = expectedRevision(input);
    caseKey.putParam("revision", revision);
    if (((Number) before.get("revision")).longValue() != revision
        || getDao().claimRevision(caseKey) != 1) {
      throw staleCase();
    }
    Map<String, Object> daily =
        row(dailyResults.getForApproval(parameter("id", before.get("attendanceDailyId"))));
    Map<String, Object> patch = readPatch(input);
    if ("APPROVE".equals(action)) {
      approveDaily(daily, before.get("id"), patch, input.getParam("comment"));
    } else {
      CommonParam dailyState = parameter("id", daily.get("id"));
      dailyState.putParam("action", action);
      dailyResults.applyCaseState(dailyState);
    }
    CommonParam changed = parameter("id", before.get("id"));
    changed.putParam("tenantId", identity.get("tenantId"));
    changed.putParam("caseStatus", outcome.get("caseStatus"));
    changed.putParam("currentApproverId", identity.get("userId"));
    changed.putParam(
        "patchPayloadJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(patch));
    changed.putParam("approvedAt", "APPROVE".equals(action) ? java.time.LocalDateTime.now() : null);
    changed.putParam("rejectedAt", "REJECT".equals(action) ? java.time.LocalDateTime.now() : null);
    changed.putParam("lockedAt", null);
    changed.putParam("updatedAt", java.time.LocalDateTime.now());
    super.update(changed);
    writeJournal(
        before.get("id"), action, input.getParam("comment"), before, getDao().getById(caseKey));
    return buildSuccessResult(
        Map.of(
            "caseId",
            before.get("id"),
            "attendanceDailyId",
            daily.get("id"),
            "caseStatus",
            outcome.get("caseStatus"),
            "handlingStatus",
            outcome.get("handlingStatus"),
            "revision",
            revision + 1),
        "处理单动作已保存。");
  }

  /**
   * 根据实际排班和生效规则重算审批最终指标，仅最终字段覆盖，原始卡和原始扣休保留。
   *
   * @param daily 审批权限已核验的真实日次，例如businessStatus=NORMAL、actualClockOut=18:37
   * @param caseId 本次真实案件主键，例如100002
   * @param patch 已解析业务补丁，例如actualClockOut=2026-10-04T18:45
   * @param comment 审批说明，例如核对补卡 副作用示例：更新最终日次并追加APPROVED_PATCH解释，任一失败回滚，不创建权限配置。
   */
  private void approveDaily(
      Map<String, Object> daily, Object caseId, Map<String, Object> patch, Object comment) {
    Map<String, Object> resolved = resolveApproval(daily, patch);
    Map<String, Object> finalPatch = (Map<String, Object>) resolved.get("finalPatch");
    Map<String, Object> metrics = (Map<String, Object>) resolved.get("metrics");
    long employee = ((Number) daily.get("employeeId")).longValue();
    java.time.LocalDate date = java.time.LocalDate.parse(daily.get("workDate").toString());
    CommonParam approved = parameter("id", daily.get("id"));
    metrics.forEach(approved::putParam);
    finalPatch.forEach(approved::putParam);
    approved.putParam("approvedCaseId", caseId);
    approved.putParam("finalRemark", comment);
    approved.putParam(
        "exceptionFlag", Boolean.TRUE.equals(finalPatch.get("finalExceptionFlag")) ? 1 : 0);
    approved.putParam("calcMessage", "审批修改最终时间后已联动刷新增强分钟。");
    dailyResults.storeApproved(approved);
    CommonParam log = parameter("attendanceDailyId", daily.get("id"));
    log.putParam("employeeId", employee);
    log.putParam("workDate", date);
    log.putParam(
        "stepMessage",
        "审批修改最终时间后已刷新增强分钟：正常 "
            + metrics.get("normalWorkMinutes")
            + "，残业 "
            + metrics.get("overtimeMinutes")
            + "，深夜 "
            + metrics.get("nightWorkMinutes")
            + "。");
    Map<String, Object> payload = new java.util.LinkedHashMap<>(finalPatch);
    payload.put("dailyId", daily.get("id"));
    log.putParam("payloadJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(payload));
    calculationLogs.appendApproval(log);
  }

  /**
   * 通过所属审批入口选最新生效关联与启用规则，保持旧规则优先级和无命中回退。
   *
   * @param employee 实际日次员工，例如8801
   * @param date 实际业务日，例如2026-10-04
   * @return 实际规则Map，例如ruleId=8501、roundingUnitMinutes=15；无关联返回null，无写入
   */
  private Map<String, Object> approvalRule(long employee, java.time.LocalDate date) {
    return approvalRule(employee, date, false);
  }

  /**
   * 案件所属服务生成前后真实快照并追加不可改写审计，不取HTTP操作员。
   *
   * @param id 真实案件主键，例如100002
   * @param action 已校验动作，例如APPROVE
   * @param comment 说明，例如核对补卡
   * @param before 更新前真实行，例如caseStatus=SUBMITTED
   * @param after 更新后真实行，例如caseStatus=APPROVED 副作用示例：追加一条真实日志，外键/序列失败回滚本次案件与日次变更。
   */
  private void writeJournal(
      Object id,
      String action,
      Object comment,
      Map<String, Object> before,
      Map<String, Object> after) {
    CommonParam log = parameter("attendanceCaseId", id);
    log.putParam("actionType", action);
    log.putParam("actionComment", comment);
    log.putParam(
        "beforeSnapshotJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(before));
    log.putParam("afterSnapshotJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(after));
    journals.appendAction(log);
  }

  /**
   * 为所属表Service构造一个服务端明确字段，不复制请求身份。
   *
   * @param field 明确字段，例如id
   * @param value 实际字段值，例如100001
   * @return 独立CommonParam，例如{id:100001}；尚无数据库写入
   */
  private static CommonParam parameter(String field, Object value) {
    CommonParam result = new CommonParam();
    result.putParam(field, value);
    return result;
  }

  /**
   * 从完整所属服务结果读取实际行，无匹配返回null。
   *
   * @param result 实际CommonResult，例如data={id:100001,employeeId:8801}
   * @return 实际字符串键Map或null，无业务数据替身或写入
   */
  private static Map<String, Object> row(CommonResult result) {
    if (!(result.getData() instanceof Map<?, ?> data)) {
      return null;
    }
    Map<String, Object> fields = new java.util.LinkedHashMap<>();
    data.forEach((key, value) -> fields.put(String.valueOf(key), value));
    return fields;
  }

  /**
   * 转换真实JDBC或补丁时间为原最终时间算法所需LocalDateTime。
   *
   * @param value 例如Timestamp 2026-10-04 18:37:00或ISO补丁时间
   * @return 例如LocalDateTime 2026-10-04T18:37，缺失返回null；格式错误拒绝，无写入
   */
  private static java.time.LocalDateTime time(Object value) {
    if (value == null) {
      return null;
    }
    if (value instanceof java.sql.Timestamp timestamp) {
      return timestamp.toLocalDateTime();
    }
    if (value instanceof java.time.LocalDateTime local) {
      return local;
    }
    return java.time.LocalDateTime.parse(value.toString().replace(' ', 'T'));
  }

  /**
   * 按真实TENANT APPROVER权限读取同租户案件页，不提升通用CRUD权限。
   *
   * @param input 例如pageNo=1、pageSize=20、employeeId=8801；会话覆盖租户和启用状态
   * @return 真实CommonPageResult，例如totalCount=1、records[0].caseStatus=SUBMITTED
   *     异常或副作用示例：无独立审批配置拒绝；只读本表，无管理或跨表数据放行。
   */
  @Override
  public com.sp.selplat.common.util.CommonPageResult reviewStore(
      com.sp.selplat.common.util.CommonPageParam input) {
    return loadReviewStore(input, authorization.requireApproval());
  }

  /**
   * 审批查看处理单详情，租户来源与动作核验一致，管理角色不是前置要求。
   *
   * @param input 例如id=100002；忽略请求身份
   * @return 真实CommonResult，例如data.caseStatus=SUBMITTED；无行时拒绝，无写入
   */
  @Override
  public CommonResult reviewDetail(CommonParam input) {
    return loadReviewDetail(input, authorization.requireApproval());
  }

  /**
   * 本人查询只采用分页和本表业务筛选，重新覆盖会话租户/绑定员工，禁止请求放大范围。
   *
   * @param input 例如pageNo=1、pageSize=20、caseStatus=SUBMITTED
   * @return 真实CommonPageResult，例如records=[{id:100001,employeeId:8801}]、totalCount=1
   *     异常或副作用示例：绑定未核验或过期时拒绝，只读本表，不计算工时或提升权限。
   */
  @Override
  public CommonPageResult ownedStore(CommonPageParam input) {
    return loadOwnedStore(input, authorization.requireEmployeeBinding());
  }

  /**
   * 案件详情在本表实际读取后复核绑定员工，无管理员或审批动作放行。
   *
   * @param input 例如id=100002，employeeId=999会被忽略
   * @return 真实CommonResult，例如data.employeeId=8801、data.caseStatus=SUBMITTED
   *     异常或副作用示例：同租户另一员工、缺失或停用案件拒绝；本表只读。
   */
  @Override
  public CommonResult getOwned(CommonParam input) {
    return loadOwned(input, authorization.requireEmployeeBinding());
  }

  /**
   * 解析必填非负修订，客户端省略不能变成无条件审批。
   *
   * @param input 已认证审批参数例如 revision=0
   * @return 明确预期修订例如0 异常或副作用示例：缺失、小数或负数抛STALE，不写库。
   */
  private long expectedRevision(CommonParam input) {
    try {
      long revision =
          new java.math.BigDecimal(String.valueOf(input.getParam("revision"))).longValueExact();
      if (revision < 0) {
        throw new ArithmeticException("revision");
      }
      return revision;
    } catch (NumberFormatException | ArithmeticException invalidRevision) {
      throw staleCase();
    }
  }

  /**
   * @return 统一过期错误例如ATTENDANCE_CASE_STALE，需刷新对比后再决定，无写入副作用。
   */
  private CommonBusinessException staleCase() {
    return new CommonBusinessException("ATTENDANCE_CASE_STALE", "处理单已更新，请刷新对比后再决定。");
  }

  /**
   * 白名单解析请求草稿，客户端计算分钟/规则不能覆盖重算事实。
   *
   * @param input 草稿例如 patchPayloadJson={actualClockOut:2026-10-04T18:45}
   * @return 实际补丁Map例如actualClockOut=2026-10-04T18:45，无其他派生字段 异常或副作用示例：非法JSON抛PATCH_INVALID，只解析不写库。
   * @throws CommonBusinessException 审批补丁格式无效。
   */
  private Map<String, Object> readPatch(CommonParam input) {
    try {
      if (input.getParam("patchPayloadJson") == null
          || input.getParam("patchPayloadJson").toString().isBlank()) {
        return Map.of();
      }
      Map<String, Object> parsed =
          com.sp.selplat.common.util.JsonUtils.fromJson(
              input.getParam("patchPayloadJson").toString(),
              new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
                /* 保留原泛型协议，不改变读取或解析。 */
              });
      if (parsed == null) {
        return Map.of();
      }
      Map<String, Object> result = new java.util.LinkedHashMap<>();
      for (String field :
          java.util.List.of(
              "actualClockIn",
              "actualClockOut",
              "finalBreakMinutes",
              "finalStatus",
              "finalExceptionFlag")) {
        if (parsed.containsKey(field)) {
          result.put(field, parsed.get(field));
        }
      }
      return result;
    } catch (RuntimeException invalidPatch) {
      throw new CommonBusinessException("ATTENDANCE_CASE_PATCH_INVALID", "审批补丁格式无效。", invalidPatch);
    }
  }

  /**
   * 预览/保存共同使用当前实际日次、排班和生效规则，仅后者持久化。
   *
   * @param daily 实际日次例如actualClockOut=18:37、actualWorkMinutes=510
   * @param patch 白名单草稿例如actualClockOut=2026-10-04T18:45
   * @return
   *     实际算法结构例如finalPatch.finalClockOut=18:45、metrics.actualWorkMinutes=525、rule.roundingUnitMinutes=15
   *     异常或副作用示例：无审批权或无效补丁拒绝，查询规则并计算，无写入。
   */
  private Map<String, Object> resolveApproval(
      Map<String, Object> daily, Map<String, Object> patch) {
    return resolveApproval(daily, patch, false);
  }

  /**
   * 读取申请时真实日次快照、当前事实和同算法草稿结果，不保存日次或审计。
   *
   * @param input 案件/修订/草稿例如id=9501、revision=0、patchPayloadJson={actualClockOut:2026-10-04T18:45}
   * @return
   *     CommonResult.data例如caseId=9501、revision=0、before.actualWorkMinutes=510、proposed.actualWorkMinutes=525
   *     异常或副作用示例：修订过期、撤权、跨租户拒绝；旧记录缺历史快照明确null，绝不伪造。
   */
  @Override
  public CommonResult previewAction(CommonParam input) {
    return loadPreview(input, authorization.requireApproval(), false);
  }

  /**
   * 建单/审批在任何持久化前同步月结保护，案件CAS仍先锁案件再进入员工/月锁。
   *
   * @param daily 实际目标例如employeeId=8801/workDate=2026-09-10 异常或副作用示例：月份已结拒绝，案件新增、修订、日状态和日志均无部分提交。
   */
  private void requireMutableDaily(Map<String, Object> daily) {
    CommonParam scope = parameter("employeeId", daily.get("employeeId"));
    scope.putParam("workDate", daily.get("workDate"));
    monthlyPeriods.requireMutablePeriod(scope);
  }

  /**
   * 方法作用：共用原本人分页完整过滤/归属/正文与响应，不改写案件。
   *
   * @param input 原分页或主键，例如id9430
   * @param identity 原本人三坐标或审批身份，例如tenantId9
   * @return 原CommonPageResult，例如案件9430及原JSON文本
   * @throws CommonBusinessException 原归属或记录错误拒绝，无写入
   */
  private CommonPageResult loadOwnedStore(CommonPageParam input, Map<String, Long> identity) {
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("employeeId", identity.get("employeeId"));
    query.put("status", 1);
    // 本人筛选按白名单接收；客户端传入身份字段、操作员或状态不能影响范围。
    Object condition = input.getParam("caseStatus");
    if (condition != null && !condition.toString().isBlank()) {
      query.put("caseStatus", condition);
    }
    return getDao().getPageList(query, "id desc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：纯读原本人分页，实际查询完成后再核同一身份和资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonPageResult，不截断或重写持久正文
   * @throws CommonBusinessException 原资格撤回、改绑或归属失效拒绝旧结果，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readOwnedStore(CommonPageParam input) {
    var actor = authorization.requireReadEmployeeBinding();
    var result = loadOwnedStore(input, actor);
    confirmCaseRead(actor, false);
    return result;
  }

  /**
   * 方法作用：共用原本人详情完整过滤/归属/正文与响应，不改写案件。
   *
   * @param input 原分页或主键，例如id9430
   * @param identity 原本人三坐标或审批身份，例如tenantId9
   * @return 原CommonResult，例如案件9430及原JSON文本
   * @throws CommonBusinessException 原归属或记录错误拒绝，无写入
   */
  private CommonResult loadOwned(CommonParam input, Map<String, Long> identity) {
    CommonParam key = new CommonParam();
    key.putParam("id", input.getParam("id"));
    key.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> current = getDao().getById(key);
    if (current == null
        || !(current.get("employeeId") instanceof Number owner)
        || owner.longValue() != identity.get("employeeId")) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(current, "本人处理单已读取。");
  }

  /**
   * 方法作用：纯读原本人详情，实际查询完成后再核同一身份和资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonResult，不截断或重写持久正文
   * @throws CommonBusinessException 原资格撤回、改绑或归属失效拒绝旧结果，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readOwned(CommonParam input) {
    var actor = authorization.requireReadEmployeeBinding();
    var result = loadOwned(input, actor);
    confirmCaseRead(actor, false);
    return result;
  }

  /**
   * 方法作用：共用原审批分页完整过滤/归属/正文与响应，不改写案件。
   *
   * @param input 原分页或主键，例如id9430
   * @param identity 原本人三坐标或审批身份，例如tenantId9
   * @return 原CommonPageResult，例如案件9430及原JSON文本
   * @throws CommonBusinessException 原归属或记录错误拒绝，无写入
   */
  private CommonPageResult loadReviewStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：纯读原审批分页，实际查询完成后再核同一身份和资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonPageResult，不截断或重写持久正文
   * @throws CommonBusinessException 原资格撤回、改绑或归属失效拒绝旧结果，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readReviewStore(CommonPageParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadReviewStore(input, actor);
    confirmCaseRead(actor, true);
    return result;
  }

  /**
   * 方法作用：共用原审批详情完整过滤/归属/正文与响应，不改写案件。
   *
   * @param input 原分页或主键，例如id9430
   * @param identity 原本人三坐标或审批身份，例如tenantId9
   * @return 原CommonResult，例如案件9430及原JSON文本
   * @throws CommonBusinessException 原归属或记录错误拒绝，无写入
   */
  private CommonResult loadReviewDetail(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> current = getDao().getById(input);
    if (current == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(current, "审批案件已读取。");
  }

  /**
   * 方法作用：纯读原审批详情，实际查询完成后再核同一身份和资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonResult，不截断或重写持久正文
   * @throws CommonBusinessException 原资格撤回、改绑或归属失效拒绝旧结果，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readReviewDetail(CommonParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadReviewDetail(input, actor);
    confirmCaseRead(actor, true);
    return result;
  }

  /**
   * 方法作用：交付前复核本人绑定或独立审批，不把员工改绑误报成登录失效。
   *
   * @param actor 原身份/绑定，例如userId9102/tenantId9/employeeId7080
   * @param approval 审批true，本人false，由原服务方法固定选择
   * @throws CommonBusinessException 真身份变化401，员工归属变化沿原拒绝400，资格撤回沿原错误
   */
  private void confirmCaseRead(Map<String, Long> actor, boolean approval) {
    var current =
        approval ? authorization.requireReadApproval() : authorization.requireReadEmployeeBinding();
    if (!java.util.Objects.equals(actor.get("userId"), current.get("userId"))
        || !java.util.Objects.equals(actor.get("tenantId"), current.get("tenantId"))) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "处理单读取期间身份已变化。");
    }
    if (!approval
        && !java.util.Objects.equals(actor.get("employeeId"), current.get("employeeId"))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 方法作用：共用原审批预览完整流程，固定选择原或纯读来源，不接受客户端模式。
   *
   * @param input 原案件/修订/补丁，例如id9430/revision0
   * @param identity 原独立审批身份，例如tenantId9/userId9102
   * @param readOnly HTTP纯读true，原桥接预览false，仅服务器传入
   * @return 原before/current/proposed/rule/schedule完整结果
   * @throws CommonBusinessException 原资格/修订/补丁失败沿原拒绝，无保存/审计
   */
  private CommonResult loadPreview(
      CommonParam input, Map<String, Long> identity, boolean readOnly) {
    CommonParam key = parameter("id", input.getParam("id"));
    key.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> current = getDao().getById(key);
    if (current == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    if (((Number) current.get("revision")).longValue() != expectedRevision(input)) {
      throw staleCase();
    }
    Map<String, Object> daily =
        row(
            readOnly
                ? dailyResults.readForApproval(parameter("id", current.get("attendanceDailyId")))
                : dailyResults.getForApproval(parameter("id", current.get("attendanceDailyId"))));
    Map<String, Object> resolved = resolveApproval(daily, readPatch(input), readOnly);
    Map<String, Object> proposed =
        new java.util.LinkedHashMap<>((Map<String, Object>) resolved.get("metrics"));
    proposed.putAll((Map<String, Object>) resolved.get("finalPatch"));
    Map<String, Object> data = new java.util.LinkedHashMap<>();
    data.put("caseId", current.get("id"));
    data.put("revision", current.get("revision"));
    Object historical = current.get("dailyBeforeJson");
    data.put(
        "before",
        historical == null
            ? null
            : com.sp.selplat.common.util.JsonUtils.fromJson(
                historical.toString(),
                new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
                  /* 保留原泛型协议，不改变读取或解析。 */
                }));
    data.put("beforeAvailable", historical != null);
    data.put("current", daily);
    data.put("proposed", proposed);
    data.put("rule", resolved.get("rule"));
    data.put("schedule", resolved.get("schedule"));
    if (!identity.equals(
        readOnly ? authorization.requireReadApproval() : authorization.requireApproval())) {
      throw staleCase();
    }
    return buildSuccessResult(data, "审批差异已按服务端规则计算，尚未保存。");
  }

  /**
   * 方法作用：共用原最终补丁和日次计算算法，只选择来源读取路径。
   *
   * @param daily 原实际日次，例如actualWorkMinutes510
   * @param patch 原白名单草稿，例如actualClockOut18:45
   * @param readOnly HTTP纯读true，原审批保存false，由服务器决定
   * @return 原finalPatch/metrics/rule/schedule，例如最终525分钟
   * @throws CommonBusinessException 原算法或来源资格失败拒绝，无新增算法或保存
   */
  private Map<String, Object> resolveApproval(
      Map<String, Object> daily, Map<String, Object> patch, boolean readOnly) {
    Map<String, Object> businessDaily =
        com.sp.selplat.attendance.common.util.calculation.AttendanceCalculationSnapshotMapper
            .dailyForMonthly(daily);
    Map<String, Object> finalPatch =
        com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.approvalPatch(
            businessDaily, patch);
    long employee = ((Number) daily.get("employeeId")).longValue();
    java.time.LocalDate date = java.time.LocalDate.parse(daily.get("workDate").toString());
    CommonParam scheduleKey = parameter("employeeId", employee);
    scheduleKey.putParam("workDate", date);
    Map<String, Object> schedule =
        row(
            readOnly
                ? schedules.readFindForApproval(scheduleKey)
                : schedules.findForApproval(scheduleKey));
    Integer minutes =
        finalPatch.get("finalBreakMinutes") == null
            ? null
            : ((Number) finalPatch.get("finalBreakMinutes")).intValue();
    Map<String, Object> rule = approvalRule(employee, date, readOnly);
    Map<String, Object> metrics =
        com.sp.selplat.attendance.common.util.calculation.AttendanceDailyCalculator
            .calculateFromResolvedFinal(
                com.sp.selplat.attendance.common.util.calculation
                    .AttendanceCalculationSnapshotMapper.scheduleForCalculation(schedule),
                rule,
                time(finalPatch.get("finalClockIn")),
                time(finalPatch.get("finalClockOut")),
                minutes);
    Map<String, Object> result = new java.util.LinkedHashMap<>();
    result.put("finalPatch", finalPatch);
    result.put("metrics", metrics);
    result.put("rule", rule);
    result.put("schedule", schedule);
    return result;
  }

  /**
   * 方法作用：保留原1000分批、有效日期和同日最大ID选择及规则字段合并。
   *
   * @param employee 原日次员工，例如7080
   * @param date 原业务日，例如2026-10-21
   * @param readOnly HTTP纯读true，原写流程false，由服务器决定
   * @return 原有效规则Map，例如id12004/ruleId10041/roundingUnitMinutes15，无命中仍null
   * @throws CommonBusinessException 原审批来源失效拒绝，无引用或历史改写
   */
  private Map<String, Object> approvalRule(
      long employee, java.time.LocalDate date, boolean readOnly) {
    java.util.List<Map<String, Object>> rows = new java.util.ArrayList<>();
    int pageNo = 1;
    com.sp.selplat.common.util.CommonPageResult page;
    do {
      com.sp.selplat.common.util.CommonPageParam query =
          new com.sp.selplat.common.util.CommonPageParam();
      query.putParam("employeeId", employee);
      query.putParam("effectiveStartDateLe", date);
      query.setPageNo(pageNo++);
      query.setPageSize(1000);
      page = readOnly ? assignments.readForApproval(query) : assignments.getForApproval(query);
      rows.addAll(page.getRecords());
    } while ((long) (pageNo - 1) * 1000 < page.getTotalCount());
    Map<String, Object> assignment =
        rows.stream()
            .filter(
                candidate ->
                    candidate.get("effectiveEndDate") == null
                        || !java.time.LocalDate.parse(candidate.get("effectiveEndDate").toString())
                            .isBefore(date))
            .max(
                java.util.Comparator.<Map<String, Object>, String>comparing(
                        candidate -> candidate.get("effectiveStartDate").toString())
                    .thenComparingLong(candidate -> ((Number) candidate.get("id")).longValue()))
            .orElse(null);
    if (assignment == null) {
      return null;
    }
    Map<String, Object> rule = new java.util.LinkedHashMap<>(assignment);
    if (assignment.get("ruleId") != null) {
      CommonParam configKey = parameter("id", assignment.get("ruleId"));
      configKey.putParam("activeFlag", 1);
      configKey.putParam("deletedFlag", 0);
      Map<String, Object> config =
          row(
              readOnly
                  ? ruleConfigs.readFindForApproval(configKey)
                  : ruleConfigs.findForApproval(configKey));
      if (config != null) {
        for (String field :
            java.util.List.of(
                "ruleCode",
                "ruleName",
                "autoBreakEnabled",
                "autoBreakThresholdMinutes",
                "autoBreakDeductMinutes",
                "nightWorkStart",
                "nightWorkEnd",
                "roundingUnitMinutes",
                "roundingMode")) {
          rule.put(field, config.get(field));
        }
      }
    }
    return rule;
  }

  /**
   * 方法作用：纯读原审批差异，原helper末尾及四来源均复核独立资格。
   *
   * @param input 原案件/修订/草稿，例如id9430/revision0
   * @return 原完整差异，例如before510/proposed525，不保存案件或指标
   * @throws CommonBusinessException 原资格、修订、补丁或来源拒绝沿原错误，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readPreview(CommonParam input) {
    return loadPreview(input, authorization.requireReadApproval(), true);
  }

  /**
   * 方法作用：共用原案件管理完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonPageResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原案件管理完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原案件管理完整详情和租户过滤，不重算或修改快照。
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.id61000及原完整字段
   * @throws CommonBusinessException 异校、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：按原系统查看门槛读取案件管理表头，不授予管理或计算许可。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns原字段配置
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "案件映射读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
