package com.sp.selplat.attendance.punchimportbatch.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 固定拥有 AttendancePunchImportBatch，复用具名考勤模板和共享号段。 */
@Repository
public class AttendancePunchImportBatchDaoImpl extends AttendanceBaseDao
        implements AttendancePunchImportBatchDao { }
