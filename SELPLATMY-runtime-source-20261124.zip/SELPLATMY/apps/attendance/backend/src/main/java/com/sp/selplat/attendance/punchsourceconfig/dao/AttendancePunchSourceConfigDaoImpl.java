package com.sp.selplat.attendance.punchsourceconfig.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 固定拥有 AttendancePunchSourceConfig，复用具名考勤模板和共享号段。 */
@Repository
public class AttendancePunchSourceConfigDaoImpl extends AttendanceBaseDao
        implements AttendancePunchSourceConfigDao {
    /**
     * 使用本表固定 SQL 获取同来源行锁，事务连接仍由公共 Spring JDBC 管理。
     *
     * @param input 服务端已覆盖的租户和来源，例如 81/CSV_A
     * @return 来源主键，例如 100001；没有有效来源返回 null 异常或副作用示例：数据库等待/失败向上抛出；只锁本表，不执行外部请求。
     */
    @Override
    public Long lockSource(com.sp.selplat.common.util.CommonParam input) {
        org.springframework.jdbc.core.JdbcTemplate jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        java.util.List<Long> ids =
                jdbc.queryForList(
                        "SELECT id FROM AttendancePunchSourceConfig WHERE tenantId=? AND sourceSystem=? AND status=1 FOR UPDATE",
                        Long.class,
                        input.getParam("tenantId"),
                        input.getParam("sourceSystem"));
        return ids.isEmpty() ? null : ids.getFirst();
    }
}
