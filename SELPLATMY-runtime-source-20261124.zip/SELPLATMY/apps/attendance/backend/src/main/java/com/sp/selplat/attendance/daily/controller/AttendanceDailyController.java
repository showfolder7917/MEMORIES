/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：只覆盖四管理读取签名，其他原处理器保留。 */
package com.sp.selplat.attendance.daily.controller;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceConfigurationReadGateway;
import com.sp.selplat.attendance.daily.service.AttendanceDailyService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** 复用共通 Controller 序列化，表服务在真实认证后仍要求考勤业务授权。 */
@RestController
@RequestMapping("/api/attendance/daily")
public class AttendanceDailyController extends BaseController<AttendanceDailyService> {

  /**
   * 原样序列化本人实际分页，由服务核验当前会话与映射。
   *
   * @param input 例如pageNo=1、pageSize=20；请求身份不授权
   * @return 实际分页JSON，例如records=[{id:100001}]、totalCount=1；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("ownedStore.htm")
  public String ownedStore(com.sp.selplat.common.util.CommonPageParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(ownedReads.ownedStore(input));
  }

  /**
   * 原样序列化本人详情，服务复核实际归属，不能获取他人资源。
   *
   * @param input 例如id=100001；请求employeeId=999不参与权限选择
   * @return 完整JSON，例如success=true、data.employeeId=8801；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("ownedDetail.htm")
  public String ownedDetail(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(ownedReads.getOwned(input));
  }

  // 只转交原配置拥有方管理资格及来源核验，不开放内部行锁HTTP入口。
  private final AttendanceConfigurationReadGateway reads;

  /**
   * 方法作用：装配管理和本人两个固定读取合同，各自保留原拥有方资格。
   *
   * @param reads 原管理三读，例如真实管理分页
   * @param ownedReads 原本人两读，例如绑定员工7060日次 异常或副作用示例：构造不授权、不建立绑定或写入。
   */
  public AttendanceDailyController(
      @org.springframework.beans.factory.annotation.Qualifier("attendanceDailyReadGateway")
          AttendanceConfigurationReadGateway reads,
      @org.springframework.beans.factory.annotation.Qualifier("attendanceDailyOwnedReadGateway")
          com.sp.selplat.attendance.daily.service.AttendanceDailyOwnedReadGateway ownedReads) {
    this.reads = reads;
    this.ownedReads = ownedReads;
  }

  /**
   * 方法作用：保留原分页URL和GET/POST，委派固定只读网关。
   *
   * @param input 原CommonPageParam，例如pageNo1/pageSize20
   * @return 原分页JSON，不在Controller改变身份或条件
   */
  @Override
  @RequestMapping(
      value = "getStore.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.getStore(input));
  }

  /**
   * 方法作用：保留原详情URL和GET/POST，权限与租户判断仍由原配置拥有方完成。
   *
   * @param input 原精确主键，例如id8501
   * @return 原CommonResult JSON，无写入
   */
  @Override
  @RequestMapping(
      value = "getById.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.getById(input));
  }

  /**
   * 方法作用：保留原viewCode表头协议及默认语言。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原列配置JSON，不替换原配置来源
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "!tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumn(
      @RequestParam(name = "viewCode", defaultValue = "default") String viewCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    return JsonUtils.toJsonIgnoreNull(reads.getGridColumn(viewCode, locale));
  }

  /**
   * 方法作用：保留原tableCode响应形状，仍由原配置拥有方核实际表名。
   *
   * @param tableCode 原Grid唯一编码，例如table930001
   * @param locale 原语言，例如ja-JP
   * @return 原JSON，data中tableCode替代viewCode，无配置写入
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumnByTableCode(
      @RequestParam(name = "tableCode") String tableCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    CommonResult result = reads.getGridColumn(tableCode, locale);
    if (result.getData() instanceof java.util.Map<?, ?> original) {
      var data = new java.util.LinkedHashMap<String, Object>();
      original.forEach((key, value) -> data.put(String.valueOf(key), value));
      data.remove("viewCode");
      data.put("tableCode", tableCode);
      result.setData(data);
    }
    return JsonUtils.toJsonIgnoreNull(result);
  }

  private final com.sp.selplat.attendance.daily.service.AttendanceDailyOwnedReadGateway ownedReads;

  /**
   * 方法作用：保留原批量POST JSON协议，仅转交同一拥有方固定读取合同
   *
   * @param input 原JSON正文，例如items含62000和62001
   * @return 原完整JSON，例如success为true且data为原批量列表，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @org.springframework.web.bind.annotation.RequestMapping(
      value = "getByIds.htm",
      method = org.springframework.web.bind.annotation.RequestMethod.POST,
      produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
  public String getByIds(
      @org.springframework.web.bind.annotation.RequestBody
          com.sp.selplat.common.util.CommonBatchParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.getByIds(input));
  }
}
