package com.sp.selplat.attendance.employeeaccount.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceEmployeeAccount 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceEmployeeAccountDao extends BaseDao {
    /**
     * 锁定本表目标账户当前事实（含已解绑行），不读取账号目录。
     *
     * @param input 服务端tenantId=81及明确userId=8101
     * @return 当前绑定例如employeeId=8801/status=0，不存在null；锁保持到外层事务结束
     */
    java.util.Map<String, Object> lockBinding(com.sp.selplat.common.util.CommonParam input);

    /**
     * 查询本表员工活动唯一归属，仅在同员工锁内使用。
     *
     * @param input 服务端tenantId=81/employeeId=8801
     * @return 真实活动行列表例如[{userId:8101}]；只读，不推定权限
     */
    java.util.List<java.util.Map<String, Object>> activeOwners(
            com.sp.selplat.common.util.CommonParam input);
}
