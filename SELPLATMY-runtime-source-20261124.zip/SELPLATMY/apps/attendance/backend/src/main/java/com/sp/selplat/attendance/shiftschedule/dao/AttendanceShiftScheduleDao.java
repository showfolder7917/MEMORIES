package com.sp.selplat.attendance.shiftschedule.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceShiftSchedule 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceShiftScheduleDao extends BaseDao {
    /**
     * 读取本表保留的模板引用，不排除历史和软删除排班。
     *
     * @param input 已核验租户/模板主键例如tenantId=81、id=8901
     * @return 真实引用数量例如1，仅读本表，无业务写入
     */
    long countTemplateReferences(com.sp.selplat.common.util.CommonParam input);

    /**
     * 读取保留同员工同日冲突，不遗漏软删除唯一键行。
     *
     * @param input 受控employeeId=8801/workDate=2026-10-10
     * @return 真实行例如id=100001；不存在null，仅本表查询
     */
    java.util.Map<String, Object> findRetained(com.sp.selplat.common.util.CommonParam input);
}
