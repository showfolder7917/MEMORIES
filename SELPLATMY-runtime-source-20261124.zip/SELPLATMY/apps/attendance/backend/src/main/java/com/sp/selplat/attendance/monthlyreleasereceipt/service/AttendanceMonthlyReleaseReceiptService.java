/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.monthlyreleasereceipt.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceMonthlyReleaseReceipt单表账本所属服务，HTTP只走月发布能力，不开放通用写入。 */
public interface AttendanceMonthlyReleaseReceiptService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 所属能力查询真实账本。
   *
   * @param input 内部归属/动作例如monthlyId=9301/actionCode=PUBLISH
   * @return 同租户真实记录data或null，仅读取
   */
  CommonResult findFact(CommonParam input);

  /**
   * 所属能力读取本月实际历史。
   *
   * @param input 月主键及明确动作例如monthlyId=9301/actionCode=PUBLISH
   * @return 实际记录data列表，仅读取
   */
  CommonResult scanMonthly(CommonParam input);

  /**
   * 尾端真实写入账本。
   *
   * @param input 已核验事实例如monthlyId=9301/freezeHash=64位SHA
   * @return 公共发号真实新增记录，失败回滚
   */
  CommonResult storeFact(CommonParam input);
}
