package com.sp.selplat.attendance.accountbindingaudit.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 审计表Controller归属边界；不提供HTTP读写方法，只有专用绑定能力能追加不可变审计。 */
@RestController
@RequestMapping("/api/attendance/accountbindingaudit")
public class AttendanceAccountBindingAuditController {
    // 保留表所属边界；不开放通用审计HTTP接口。
}
