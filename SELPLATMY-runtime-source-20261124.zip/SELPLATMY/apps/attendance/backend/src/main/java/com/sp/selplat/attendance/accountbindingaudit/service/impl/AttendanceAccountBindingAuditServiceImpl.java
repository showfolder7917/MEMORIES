/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.accountbindingaudit.service.impl;

import com.sp.selplat.attendance.accountbindingaudit.dao.AttendanceAccountBindingAuditDao;
import com.sp.selplat.attendance.accountbindingaudit.service.AttendanceAccountBindingAuditService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/** 绑定审计只由已验证专用命令追加，未设置HTTP控制器，不修改历史事件或真实许可。 */
@Service
public class AttendanceAccountBindingAuditServiceImpl
        extends BaseServiceImpl<AttendanceAccountBindingAuditDao>
        implements AttendanceAccountBindingAuditService {
    // 真实会话覆盖本地审计租户及操作者，不接受客户端同名字段。
    @Autowired
    @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
    private CurrentSessionAccess session;

    /**
     * @return 当前schema真实账本存在例如false，缺表不初始化，无业务写入
     */
    @Override
    public boolean ready() {
        return getDao().ready();
    }

    /**
     * @param userId 已核验明确账号例如8104
     * @return 同租户真实审计列表例如[{revisionNo:1}]，只读
     */
    @Override
    public List<Map<String, Object>> events(long userId) {
        var identity = AttendanceAccessGuard.requireIdentity(session.current());
        var q = new CommonParam();
        q.putParam("tenantId", identity.get("tenantId"));
        q.putParam("userId", userId);
        return getDao().events(q);
    }

    /**
     * @param input 专用命令服务生成事件例如userId8104/revisionNo1
     * @return 真实CommonResult例如data.id100001，追加审计或SQL失败传播回滚，不自动建立号段
     */
    @Override
    public CommonResult append(CommonParam input) {
        return super.insert(input);
    }

    /**
     * @return 真实当前tenant例如81，匿名拒绝，不回退固定租户
     */
    @Override
    protected Long getCurrentTenantId() {
        return AttendanceAccessGuard.requireIdentity(session.current()).get("tenantId");
    }

    /**
     * @return 真实当前操作者例如8103，匿名拒绝，不读客户端字段
     */
    @Override
    protected Long getCurrentOperatorId() {
        return AttendanceAccessGuard.requireIdentity(session.current()).get("userId");
    }

    /**
     * @return 固定false，例如无目录或已绑定均返回false，不从登录名或目录查询推断管理员，无写入
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }
}
