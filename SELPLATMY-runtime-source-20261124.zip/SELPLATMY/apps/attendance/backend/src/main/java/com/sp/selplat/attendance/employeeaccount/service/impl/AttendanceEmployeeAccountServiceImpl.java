package com.sp.selplat.attendance.employeeaccount.service.impl;

import com.sp.selplat.attendance.employeeaccount.dao.AttendanceEmployeeAccountDao;
import com.sp.selplat.attendance.employeeaccount.service.AttendanceEmployeeAccountService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceEmployeeAccount 复用共通 DAO 泛型注入及 CRUD；在可信授权来源核准前拒绝全部业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceEmployeeAccountServiceImpl
        extends BaseServiceImpl<AttendanceEmployeeAccountDao>
        implements AttendanceEmployeeAccountService {
    // 身份读取由Host具名公共能力装配，HTTP模式不读本地权限账号。
    @Autowired @Qualifier("attendanceCurrentSessionAccess") private CurrentSessionAccess sessionService;

    // 生产没有权威目录bean时默认拒绝；测试只允许真实数据库支持的合成目录。
    @Autowired
    private org.springframework.beans.factory.ObjectProvider<
                    com.sp.selplat.attendance.capability.accountbinding.service
                            .AttendanceAccountDirectory>
            directories;

    // 只消费精确本租户管理配置，不从基类isAdmin或客户端角色推定。
    @Autowired
    private com.sp.selplat.attendance.accessgrant.service.AttendanceAccessGrantService grants;

    // 独立不可变审计通过所属服务读写；旧映射schema和普通启动保持原样。
    @Autowired
    private com.sp.selplat.attendance.accountbindingaudit.service
                    .AttendanceAccountBindingAuditService
            auditService;

    /**
     * 校验真实会话后拒绝尚未配置的管理权限。
     *
     * @return 校验真实身份后生成的管理能力未配置异常；不读写业务表
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无效身份首先拒绝，例如匿名请求
     */
    private com.sp.selplat.common.exception.CommonBusinessException managementRejected() {
        return AttendanceAccessGuard.unconfiguredManagement(sessionService.current());
    }

    /**
     * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
    }

    /**
     * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
     */
    @Override
    protected Long getCurrentTenantId() {
        return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
    }

    /**
     * @return 固定 false，例如即使登录名为 admin 仍返回 false；管理能力只读取已核验配置。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 在进入共通 getStore 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonPageResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 getById 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 getByIds 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 insert 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult insert(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 insertBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult insertBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 update 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult update(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 updateBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult updateBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 delete 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult delete(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 deleteBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult deleteBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 由真实当前会话查询已核验员工绑定，不创建默认绑定。
     *
     * @return 真实配置 Map，例如 employeeId=8801、userId=8101、tenantId=81；无匹配返回 null
     *     异常或副作用示例：例如匿名会话拒绝；只读取本人本租户配置，没有关联写入。
     */
    @Override
    public Map<String, Object> findCurrentBinding() {
        Map<String, Long> identity =
                AttendanceAccessGuard.requireIdentity(sessionService.current());
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("userId", identity.get("userId"));
        query.putParam("configurationStatus", "VERIFIED");
        query.putParam("status", 1);
        return getDao().getByQuery(query);
    }

    /**
     * 专用能力在员工锁内显式绑定/解绑，重验管理及目录精确动作，所有审计同事务保存。
     *
     * @param input 明确userId=8101/employeeId=8801/action=BIND/requestKey=B1/expectedRevision=0
     * @return
     *     真实安全CommonResult例如data={userId:8101,employeeId:8801,bindingRevision:1,status:1,replayed:false}
     *     异常示例：缺目录、权限撤销、唯一归属冲突、旧修订或旧schema拒绝且不追加审计。
     */
    @Override
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult applyBinding(CommonParam input) {
        // 身份来自实时安全概要；先验证管理角色，再核验目录的独立精确动作。
        var identity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        if (!com.sp.selplat.attendance.common.util.access.AttendanceGrantPolicy.allows(
                grants.findCurrentGrant("MANAGER"),
                identity,
                "MANAGER",
                java.time.LocalDateTime.now())) {
            throw bindingError("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
        }
        var directory = directories.getIfAvailable();
        if (directory == null) {
            throw bindingError("ATTENDANCE_ACCOUNT_DIRECTORY_UNAVAILABLE", "权威账号目录及绑定许可尚未接入。");
        }
        long userId = bindingId(input.getParam("userId")),
                employeeId = bindingId(input.getParam("employeeId"));
        String action = String.valueOf(input.getParam("action")),
                key = String.valueOf(input.getParam("requestKey"));
        if (!(input.getParam("requestKey") instanceof String)
                || !java.util.Set.of("BIND", "UNBIND").contains(action)
                || !key.matches("[A-Za-z0-9_-]{1,64}")) {
            throw bindingError("ATTENDANCE_BINDING_INPUT_INVALID", "请明确账号、员工、请求键及绑定修订。");
        }
        long expected;
        try {
            expected =
                    new java.math.BigDecimal(String.valueOf(input.getParam("expectedRevision")))
                            .longValueExact();
            if (expected < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException | ArithmeticException invalid) {
            throw bindingError("ATTENDANCE_BINDING_INPUT_INVALID", "请明确账号、员工、请求键及绑定修订。");
        }
        var fact =
                directory.requireAccount(
                        identity,
                        userId,
                        action.equals("BIND")
                                ? "BIND_EMPLOYEE_ACCOUNT"
                                : "UNBIND_EMPLOYEE_ACCOUNT");
        // 双端核对公开目录的真实数字归属及启用状态；不消费名称、email或凭据。
        if (fact == null
                || !(fact.get("userId") instanceof Number uid)
                || uid.longValue() != userId
                || !(fact.get("tenantId") instanceof Number tid)
                || tid.longValue() != identity.get("tenantId")
                || !(fact.get("status") instanceof Number active)
                || (action.equals("BIND") && active.intValue() != 1)
                || fact.get("directoryRevision") == null) {
            throw bindingError("ATTENDANCE_ACCOUNT_DIRECTORY_DENIED", "公开账号目录无法核验目标账号或精确许可。");
        }
        if (!auditService.ready()) {
            throw bindingError("ATTENDANCE_BINDING_SCHEMA_NOT_READY", "绑定审计结构尚未核验，不能修改历史映射。");
        }
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("userId", userId);
        query.putParam("employeeId", employeeId);
        var row = getDao().lockBinding(query);
        // 账户锁等待后重读目录及当前管理事实，撤销许可不会使用首次查询缓存放行。
        var currentIdentity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        if (!identity.equals(currentIdentity)
                || !com.sp.selplat.attendance.common.util.access.AttendanceGrantPolicy.allows(
                        grants.findCurrentGrant("MANAGER"),
                        currentIdentity,
                        "MANAGER",
                        java.time.LocalDateTime.now())) {
            throw bindingError("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
        }
        var currentFact =
                directory.requireAccount(
                        currentIdentity,
                        userId,
                        action.equals("BIND")
                                ? "BIND_EMPLOYEE_ACCOUNT"
                                : "UNBIND_EMPLOYEE_ACCOUNT");
        if (!fact.equals(currentFact)) {
            throw bindingError("ATTENDANCE_ACCOUNT_DIRECTORY_DENIED", "公开账号目录无法核验目标账号或精确许可。");
        }
        // 审计账本是真实修订与幂等来源；旧映射不补造历史审计。
        var audit = auditService.events(userId);
        long revision =
                audit.isEmpty() ? 0 : ((Number) audit.getLast().get("revisionNo")).longValue();
        String fingerprint = action + ":" + userId + ":" + employeeId + ":" + expected;
        // 历史请求键只可重放相同当前结果，解绑后的旧绑定回执不会重新生效。
        for (var entry : audit) {
            if (key.equals(entry.get("requestKey"))) {
                if (!fingerprint.equals(entry.get("fingerprint"))
                        || !(entry.get("revisionNo") instanceof Number receipt)
                        || receipt.longValue() != revision) {
                    throw bindingError("ATTENDANCE_BINDING_REQUEST_CONFLICT", "请求键或绑定结果已变化，请重新读取。");
                }
                if (row == null
                        || ((Number) row.get("employeeId")).longValue() != employeeId
                        || (action.equals("BIND")
                                ? (!"VERIFIED".equals(row.get("configurationStatus"))
                                        || ((Number) row.get("status")).intValue() != 1)
                                : (!"REVOKED".equals(row.get("configurationStatus"))
                                        || ((Number) row.get("status")).intValue() != 0))) {
                    throw bindingError("ATTENDANCE_BINDING_REQUEST_CONFLICT", "请求键或绑定结果已变化，请重新读取。");
                }
                return bindingResult(row, true, revision, entry);
            }
        }
        if (expected != revision) {
            throw bindingError("ATTENDANCE_BINDING_REVISION_CONFLICT", "绑定修订已变化，请刷新后再确认。");
        }
        boolean currentlyActive =
                row != null
                        && "VERIFIED".equals(row.get("configurationStatus"))
                        && ((Number) row.get("status")).intValue() == 1;
        if (currentlyActive && ((Number) row.get("employeeId")).longValue() != employeeId) {
            throw bindingError("ATTENDANCE_BINDING_OWNER_CONFLICT", "账号已有活动员工归属，请先显式解绑。");
        }
        if (action.equals("UNBIND") && !currentlyActive) {
            throw bindingError("ATTENDANCE_BINDING_OWNER_CONFLICT", "当前账号没有对应活动绑定。");
        }
        for (var owner : getDao().activeOwners(query)) {
            if (((Number) owner.get("userId")).longValue() != userId) {
                throw bindingError("ATTENDANCE_BINDING_OWNER_CONFLICT", "员工已有活动账号归属，请先显式解绑。");
            }
        }
        // 变更仅即时生效；不回填历史、不自动授予本人月报或其他角色。
        var now = java.time.LocalDateTime.now();
        long next = revision + 1;
        CommonParam save = new CommonParam();
        save.putParam("userId", userId);
        save.putParam("employeeId", employeeId);
        save.putParam("configurationStatus", action.equals("BIND") ? "VERIFIED" : "REVOKED");
        save.putParam("status", action.equals("BIND") ? 1 : 0);
        try {
            if (row == null) {
                super.insert(save);
            } else {
                save.putParam("id", row.get("id"));
                super.update(save);
            }
        } catch (org.springframework.dao.DataIntegrityViolationException conflict) {
            throw bindingError("ATTENDANCE_BINDING_OWNER_CONFLICT", "账号归属已被并发修改，请重新读取。");
        }
        // 当前映射和不可变审计同事务，尾审计失败全部回滚；只追加，不更新旧事件。
        CommonParam event = new CommonParam();
        event.putParam("userId", userId);
        event.putParam("employeeId", employeeId);
        event.putParam("revisionNo", next);
        event.putParam("requestKey", key);
        event.putParam("fingerprint", fingerprint);
        event.putParam("actionCode", action);
        event.putParam("effectiveAt", now);
        event.putParam("directoryRevision", String.valueOf(fact.get("directoryRevision")));
        event.putParam(
                "payloadJson",
                com.sp.selplat.common.util.JsonUtils.toJson(
                        Map.of(
                                "tenantId",
                                identity.get("tenantId"),
                                "operatorId",
                                identity.get("userId"),
                                "userId",
                                userId,
                                "employeeId",
                                employeeId,
                                "action",
                                action,
                                "effectiveAt",
                                now.toString(),
                                "directoryRevision",
                                fact.get("directoryRevision"),
                                "previousRevision",
                                revision,
                                "revision",
                                next)));
        auditService.append(event);
        // 审计尾INSERT也可能真实等待；返回前重验当前身份、管理许可和精确目录事实。
        var finalIdentity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        if (!identity.equals(finalIdentity)
                || !com.sp.selplat.attendance.common.util.access.AttendanceGrantPolicy.allows(
                        grants.findCurrentGrant("MANAGER"),
                        finalIdentity,
                        "MANAGER",
                        java.time.LocalDateTime.now())) {
            throw bindingError("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
        }
        var finalFact =
                directory.requireAccount(
                        finalIdentity,
                        userId,
                        action.equals("BIND")
                                ? "BIND_EMPLOYEE_ACCOUNT"
                                : "UNBIND_EMPLOYEE_ACCOUNT");
        if (!fact.equals(finalFact)) {
            throw bindingError("ATTENDANCE_ACCOUNT_DIRECTORY_DENIED", "公开账号目录无法核验目标账号或精确许可。");
        }
        return bindingResult(save.getParamMap(), false, next, event.getParamMap());
    }

    /**
     * 构建绑定安全回执，审计正文留独立账本，不输出目录凭据或猜测权限。
     *
     * @param row 当前真实保存行例如id=100001/employeeId=8801
     * @param replayed 相同当前回执重放例如true
     * @param revision 当前独立账本修订例如1
     * @param event 当前实际审计例如actionCode=BIND/effectiveAt=2026-10-04T09:00
     * @return CommonResult.data含真实userId/employeeId/revision/status/id及replayed，不授予本人月报许可
     */
    private CommonResult bindingResult(
            Map<String, Object> row, boolean replayed, long revision, Map<String, Object> event) {
        var data = new java.util.LinkedHashMap<String, Object>();
        for (String field :
                java.util.List.of("id", "userId", "employeeId", "configurationStatus", "status")) {
            if (row.get(field) != null) {
                data.put(field, row.get(field));
            }
        }
        data.put("bindingRevision", revision);
        data.put("replayed", replayed);
        data.put("effectiveAt", event.get("effectiveAt"));
        return buildSuccessResult(data, "员工账号绑定操作已保存。");
    }

    /**
     * owning员工锁内沿用真实管理和账本准入，仅检查现有双向候选。
     * @param userId 原安全目录BIND核验目标，例如8104
     * @param employeeId 外层能力已锁员工，例如8801
     * @return 当前绑定状态例如data.bindingRevision=0，不建立来源台账或新关系
     *     异常示例：员工已有其他活动账号时ATTENDANCE_MIGRATION_MAPPING_AMBIGUOUS，无写入。
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(
            transactionManager = "attendanceTransactionManager",
            propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
    public CommonResult migrationCandidateState(long userId, long employeeId) {
        CommonResult state = bindingState(userId);
        var identity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("employeeId", employeeId);
        var owners = getDao().activeOwners(query);
        if (owners.size() > 1 || (!owners.isEmpty()
                && ((Number) owners.getFirst().get("userId")).longValue() != userId)) {
            throw bindingError("ATTENDANCE_MIGRATION_MAPPING_AMBIGUOUS", "员工已有其他账号绑定，候选需复核。");
        }
        return state;
    }

    /**
     * 专用选择流程读取已允许目标的本租户最新绑定修订，不开放通用账户CRUD。
     *
     * @param userId 专用能力经目录核验的精确账号例如8104
     * @return 安全CommonResult例如data={userId:8104,bindingRevision:1,employeeId:8801,status:1}，无账号凭据
     *     异常示例：管理撤销或缺已核验审计账本拒绝；只持有短期本表读锁，无业务写入。
     */
    @Override
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult bindingState(long userId) {
        var identity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        if (!com.sp.selplat.attendance.common.util.access.AttendanceGrantPolicy.allows(
                grants.findCurrentGrant("MANAGER"),
                identity,
                "MANAGER",
                java.time.LocalDateTime.now())) {
            throw bindingError("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
        }
        if (!auditService.ready()) {
            throw bindingError("ATTENDANCE_BINDING_SCHEMA_NOT_READY", "绑定审计结构尚未核验，不能修改历史映射。");
        }
        var q = new CommonParam();
        q.putParam("tenantId", identity.get("tenantId"));
        q.putParam("userId", userId);
        var row = getDao().lockBinding(q);
        var events = auditService.events(userId);
        var data = new java.util.LinkedHashMap<String, Object>();
        data.put("userId", userId);
        data.put("bindingRevision", events.isEmpty() ? 0 : events.getLast().get("revisionNo"));
        data.put("status", row == null ? 0 : row.get("status"));
        if (row != null) {
            data.put("employeeId", row.get("employeeId"));
        }
        return buildSuccessResult(data, "员工账号当前绑定已读取。");
    }

    /**
     * 校验显式选择的正整数主键。
     *
     * @param value 请求精确主键例如8101，字符串整数允许，小数拒绝
     * @return 正long例如8101；无效抛输入错误，无写入
     */
    private long bindingId(Object value) {
        try {
            long id = new java.math.BigDecimal(String.valueOf(value)).longValueExact();
            if (id > 0) {
                return id;
            }
        } catch (NumberFormatException | ArithmeticException invalid) {
            /* 无合法主键不写库。 */
        }
        throw bindingError("ATTENDANCE_BINDING_INPUT_INVALID", "请明确账号、员工、请求键及绑定修订。");
    }

    /**
     * 构造安全绑定领域拒绝。
     *
     * @param code 明确错误例如ATTENDANCE_BINDING_OWNER_CONFLICT
     * @param message 安全文本例如账号已有活动归属
     * @return CommonBusinessException原码原文，不读写数据库
     */
    private com.sp.selplat.common.exception.CommonBusinessException bindingError(
            String code, String message) {
        return new com.sp.selplat.common.exception.CommonBusinessException(code, message);
    }
}
