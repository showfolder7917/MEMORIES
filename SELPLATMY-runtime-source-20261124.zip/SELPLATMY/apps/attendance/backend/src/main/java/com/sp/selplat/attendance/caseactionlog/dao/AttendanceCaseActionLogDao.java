package com.sp.selplat.attendance.caseactionlog.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceCaseActionLog 仅拥有本表公共查询与持久化，不跨表访问 DAO。 */
public interface AttendanceCaseActionLogDao extends BaseDao { }
