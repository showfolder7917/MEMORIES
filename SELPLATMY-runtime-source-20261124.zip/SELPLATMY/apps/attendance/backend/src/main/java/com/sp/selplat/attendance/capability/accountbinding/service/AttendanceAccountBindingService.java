package com.sp.selplat.attendance.capability.accountbinding.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 专用显式绑定能力，独立于通用CRUD；生产缺权威公开目录时拒绝。 */
public interface AttendanceAccountBindingService {
  /**
   * 只读核旧员工账号显式候选，复用原管理、BIND目录和现有绑定状态，不执行迁入。
   *
   * @param input
   *     例如mode=DRY_RUN/sourceSystem=ERP/sourceAccountId=24/sourceType=1/userId=8104/employeeId=8801/evidenceRef=review1
   * @return
   *     例如success=true,data={targetFactsVerified:true,mappingEvidenceVerified:false,writeEnabled:false}
   *     异常示例：匿名、异租户、停用账号、歧义现有绑定或缺目录拒绝，无身份/许可写入。
   */
  CommonResult migrationPreflight(CommonParam input);

  /**
   * 真实管理许可下锁定员工并即时绑定或解绑明确账号，禁止隐式接管或发放权限。
   *
   * @param input 明确employeeId=8801/userId=8101/action=BIND/requestKey=B1/expectedRevision=0
   * @return 真实CommonResult例如data.bindingRevision=1/replayed=false，失败全事务回滚
   */
  CommonResult execute(CommonParam input);

  /**
   * @param input 页码1/页大小20/action=BIND/loginNameExact为空
   * @return 实际安全CommonPageResult例如totalCount=1，缺目录拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonPageResult accounts(CommonParam input);

  /**
   * @param input 明确userId8104/actionBIND
   * @return 实际CommonResult例如data.bindingRevision=0/employeeId为空，精确目录许可及管理验证后只读
   */
  CommonResult state(CommonParam input);

  /**
   * 方法作用：明确读取原Accounts，前后核原管理和源角色，不提供绑定写许可。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检沿原七字段
   * @return 原com.sp.selplat.common.util.CommonPageResult，例如bindingRevision=0或原四字段安全分页
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原权限、目录或结构不满足拒绝，无写入
   */
  com.sp.selplat.common.util.CommonPageResult readAccounts(CommonParam input);

  /**
   * 方法作用：明确读取原State，前后核原管理和源角色，不提供绑定写许可。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检沿原七字段
   * @return 原CommonResult，例如bindingRevision=0或原四字段安全分页
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原权限、目录或结构不满足拒绝，无写入
   */
  CommonResult readState(CommonParam input);

  /**
   * 方法作用：明确读取原MigrationPreflight，前后核原管理和源角色，不提供绑定写许可。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检沿原七字段
   * @return 原CommonResult，例如bindingRevision=0或原四字段安全分页
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原权限、目录或结构不满足拒绝，无写入
   */
  CommonResult readMigrationPreflight(CommonParam input);
}
