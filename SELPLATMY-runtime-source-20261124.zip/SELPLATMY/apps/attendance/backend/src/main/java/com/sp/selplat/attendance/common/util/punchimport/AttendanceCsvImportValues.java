package com.sp.selplat.attendance.common.util.punchimport;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** CSV 解析、输入摘要与分类计数纯值工具；无身份推断、数据库、网络或原始数据持久化。 */
public final class AttendanceCsvImportValues {
    // 四种原始打卡类型沿用旧服务口径，不触发日月分钟计算。
    private static final Set<String> TYPES =
            Set.of("CLOCK_IN", "CLOCK_OUT", "BREAK_START", "BREAK_END");
    // 来源由批次指定，不从 CSV 任意字段选择租户、员工或授权。
    private static final Set<String> COLUMNS =
            Set.of(
                    "sourceEventId",
                    "externalEmployeeId",
                    "punchTime",
                    "punchType",
                    "deviceId",
                    "deviceName");

    /** 构造不可实例化纯值工具；例如不创建连接或保存原始请求。 */
    private AttendanceCsvImportValues() { }

    /**
     * 校验非空业务键，不改变大小写或把不同来源合并。
     *
     * @param value 来源键等原值，例如 CSV_A
     * @param maxLength 该数据库字段限制，例如 50
     * @return 去除边缘空白的业务键，例如 CSV_A
     * @throws IllegalArgumentException 空值、控制字符或超长时拒绝；无写入
     */
    public static String key(Object value, int maxLength) {
        String text = value == null ? "" : value.toString().trim();
        if (text.isEmpty()
                || text.length() > maxLength
                || text.chars().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException("INVALID_KEY");
        }
        return text;
    }

    /**
     * 对原始 UTF-8 CSV 生成确定性摘要；仅摘要用于幂等，不保存 CSV。
     *
     * @param csv 完整上传文本，例如四列标题和一行打卡
     * @return 64 位 SHA-256 十六进制摘要；同文本重复调用保持一致
     * @throws IllegalArgumentException 空文本或超过一百万字符时拒绝；无持久化
     * @throws IllegalStateException SHA-256 unavailable
     */
    public static String digest(String csv) {
        if (csv == null || csv.isBlank() || csv.length() > 1_000_000) {
            throw new IllegalArgumentException("INVALID_CSV_SIZE");
        }
        try {
            return HexFormat.of()
                    .formatHex(
                            MessageDigest.getInstance("SHA-256")
                                    .digest(csv.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 unavailable", impossible);
        }
    }

    /**
     * 解析引号、逗号、CRLF 和引号内换行，严格拒绝重复/未知标题和结构损坏。
     *
     * @param csv 四个必需列及可选设备列的文本，例如 sourceEventId,externalEmployeeId,punchTime,punchType
     * @return 数据行 Map 列表，例如
     *     [{sourceEventId:E1,externalEmployeeId:X1,punchTime:2026-10-03T09:00,punchType:CLOCK_IN}]
     * @throws IllegalArgumentException 未闭合引号、空数据、超过一万行或列数不一致时拒绝；不导入部分文件
     */
    public static List<Map<String, String>> parse(String csv) {
        digest(csv);
        List<List<String>> records = new ArrayList<>();
        List<String> record = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        boolean closed = false;
        // 末尾补一个记录结束符；原文件末尾换行不会产生额外业务记录。
        for (int index = 0; index <= csv.length(); index++) {
            char character = index == csv.length() ? '\n' : csv.charAt(index);
            if (quoted) {
                if (index == csv.length()) {
                    throw new IllegalArgumentException("UNCLOSED_CSV_QUOTE");
                }
                if (character == '"') {
                    if (index + 1 < csv.length() && csv.charAt(index + 1) == '"') {
                        field.append('"');
                        index++;
                    } else {
                        quoted = false;
                        closed = true;
                    }
                } else {
                    field.append(character);
                }
            } else if (character == ',' || character == '\n' || character == '\r') {
                record.add(field.toString());
                field.setLength(0);
                closed = false;
                if (character != ',') {
                    if (!(record.size() == 1 && record.getFirst().isEmpty())) {
                        records.add(record);
                    }
                    record = new ArrayList<>();
                    if (character == '\r'
                            && index + 1 < csv.length()
                            && csv.charAt(index + 1) == '\n') {
                        index++;
                    }
                    if (records.size() > 10_001) {
                        throw new IllegalArgumentException("CSV_ROW_LIMIT");
                    }
                }
            } else if (character == '"' && field.isEmpty() && !closed) {
                quoted = true;
            } else {
                if (closed || character == '"') {
                    throw new IllegalArgumentException("INVALID_CSV_QUOTE");
                }
                field.append(character);
            }
        }
        if (records.size() < 2) {
            throw new IllegalArgumentException("EMPTY_CSV");
        }
        List<String> header = new ArrayList<>(records.removeFirst());
        if (header.getFirst().startsWith("\ufeff")) {
            header.set(0, header.getFirst().substring(1));
        }
        if (new HashSet<>(header).size() != header.size()
                || !COLUMNS.containsAll(header)
                || !header.containsAll(
                        List.of("sourceEventId", "externalEmployeeId", "punchTime", "punchType"))) {
            throw new IllegalArgumentException("INVALID_CSV_HEADER");
        }
        List<Map<String, String>> rows = new ArrayList<>();
        for (List<String> values : records) {
            if (values.size() != header.size()) {
                throw new IllegalArgumentException("CSV_COLUMN_COUNT");
            }
            Map<String, String> row = new LinkedHashMap<>();
            for (int index = 0; index < header.size(); index++) {
                row.put(header.get(index), values.get(index));
            }
            rows.add(row);
        }
        return rows;
    }

    /**
     * 校验单行原始事实，格式错误逐行隔离，不推导员工或时区。
     *
     * @param row 已解析的一行，例如 punchType=CLOCK_IN、punchTime=2026-10-03T09:00
     * @return 安全原因代码；合法为 VALID，非法为 INVALID_PUNCH_ROW 异常或副作用示例：错误时间返回原因代码；不计算工时、不保存原始值。
     */
    public static String validateRow(Map<String, String> row) {
        try {
            key(row.get("sourceEventId"), 100);
            key(row.get("externalEmployeeId"), 100);
            LocalDateTime.parse(key(row.get("punchTime"), 40).replace(' ', 'T'));
            if (!TYPES.contains(key(row.get("punchType"), 30))) {
                return "INVALID_PUNCH_ROW";
            }
            if (row.getOrDefault("deviceId", "").length() > 100
                    || row.getOrDefault("deviceName", "").length() > 200) {
                return "INVALID_PUNCH_ROW";
            }
            return "VALID";
        } catch (RuntimeException invalid) {
            return "INVALID_PUNCH_ROW";
        }
    }

    /**
     * 按实际分类汇总批次；冲突包含在 unmatchedCount 中，额外计数只用于解释。
     *
     * @param outcomes 行结果，例如 [{processStatus:PROCESSED},{processStatus:CONFLICT}]
     * @return 总数与分类，例如
     *     totalCount=2、successCount=1、unmatchedCount=1、conflictCount=1、importStatus=PARTIAL
     * @throws IllegalArgumentException 未知分类拒绝；无数据库或工资值变化
     */
    public static Map<String, Object> summarize(List<Map<String, Object>> outcomes) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (String key :
                List.of(
                        "successCount",
                        "duplicateCount",
                        "unmatchedCount",
                        "conflictCount",
                        "errorCount",
                        "ignoredCount")) {
            result.put(key, 0);
        }
        for (Map<String, Object> row : outcomes) {
            String type = String.valueOf(row.get("processStatus"));
            String counter =
                    switch (type) {
                        case "PROCESSED" -> "successCount";
                        case "DUPLICATE" -> "duplicateCount";
                        case "UNMATCHED", "CONFLICT" -> "unmatchedCount";
                        case "ERROR" -> "errorCount";
                        case "IGNORED" -> "ignoredCount";
                        default -> throw new IllegalArgumentException("UNKNOWN_IMPORT_OUTCOME");
                    };
            result.put(counter, (Integer) result.get(counter) + 1);
            if (type.equals("CONFLICT")) {
                result.put("conflictCount", (Integer) result.get("conflictCount") + 1);
            }
        }
        result.put("totalCount", outcomes.size());
        result.put(
                "importStatus",
                (Integer) result.get("successCount") == outcomes.size() ? "COMPLETED" : "PARTIAL");
        return result;
    }

    /**
     * 发现文件内同事件键的不同事实，整组隔离，不依行顺序挑选第一条。
     *
     * @param rows CSV 行，例如 E1 两行具有不同 punchTime
     * @return 冲突事件集合，例如 [E1]；完全相同重复不在冲突集合 异常或副作用示例：无效行不参与事实比较；无数据库写入。
     */
    public static Set<String> conflictingEvents(List<Map<String, String>> rows) {
        Map<String, Map<String, String>> first = new LinkedHashMap<>();
        Set<String> conflicts = new HashSet<>();
        for (Map<String, String> row : rows) {
            if (!validateRow(row).equals("VALID")) {
                continue;
            }
            String event = key(row.get("sourceEventId"), 100);
            Map<String, String> fact = new LinkedHashMap<>();
            fact.put("externalEmployeeId", key(row.get("externalEmployeeId"), 100));
            fact.put(
                    "punchTime",
                    LocalDateTime.parse(row.get("punchTime").trim().replace(' ', 'T')).toString());
            fact.put("punchType", row.get("punchType").trim());
            Map<String, String> previous = first.putIfAbsent(event, fact);
            if (previous != null && !previous.equals(fact)) {
                conflicts.add(event);
            }
        }
        return conflicts;
    }
}
