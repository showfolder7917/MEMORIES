package com.sp.selplat.attendance.capability.schedulecommand.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 排班保存能力通过表服务协作，不拥有 DAO。 */
public interface AttendanceScheduleCommandService {
    /**
     * 保存同员工同工作日的模板排班，已有排班原位替换。
     *
     * @param input employeeId、shiftTemplateId、workDate、remark；不采纳客户端租户或展开时间
     * @return 实际持久化行，锁定或无管理配置时拒绝；仅写排班事实
     */
    CommonResult save(CommonParam input);

    /**
     * 只读服务端展开计划及逐行冲突，不授予提交权限。
     *
     * @param input requestKey=BATCH-001/items为完整行数组
     * @return CommonResult.data数组例如employeeId=8801/conflictCode为空；非法整体输入拒绝，无写库
     */
    CommonResult previewBatch(CommonParam input);

    /**
     * 重新校验完整请求并原子提交，预览结果非授权凭证。
     *
     * @param input requestKey=BATCH-001/items含templateRevision=0
     * @return 实际CommonResult.data数组/affectedRows=2；重复返回原回执0写入，任一失败整批回滚
     */
    CommonResult commitBatch(CommonParam input);
}
