package com.sp.selplat.attendance.monthlyreview.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceMonthlyReview仅拥有本表，租户复合关联交由真实约束保证。 */
public interface AttendanceMonthlyReviewDao extends BaseDao {
    /**
     * 本表锁后CAS。
     *
     * @param input 实际id/tenant/revision例如100001/81/0
     * @return 真实影响行数，0由服务拒绝，数据库异常传播
     */
    int compareState(com.sp.selplat.common.util.CommonParam input);
}
