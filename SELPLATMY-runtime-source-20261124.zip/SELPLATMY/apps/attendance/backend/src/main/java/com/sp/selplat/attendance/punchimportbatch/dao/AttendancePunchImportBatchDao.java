package com.sp.selplat.attendance.punchimportbatch.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendancePunchImportBatch 唯一本表 DAO 契约，不读取组织、账号或其他表。 */
public interface AttendancePunchImportBatchDao extends BaseDao { }
