package com.sp.selplat.attendance.capability.punchcommand.service.impl;

import com.sp.selplat.attendance.capability.punchcommand.service.AttendancePunchCommandService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.punchrawlog.service.AttendancePunchRawLogService;
import com.sp.selplat.attendance.employeeexternalmapping.service.AttendanceEmployeeExternalMappingService;
import com.sp.selplat.attendance.punchimportbatch.service.AttendancePunchImportBatchService;
import com.sp.selplat.attendance.punchsourceconfig.service.AttendancePunchSourceConfigService;
import com.sp.selplat.attendance.common.util.punchimport.AttendanceCsvImportValues;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 沿用旧管理补录的四类打卡和 PROCESSED 状态；原始事实保存后禁止通用修改。 */
@Service
public class AttendancePunchCommandServiceImpl implements AttendancePunchCommandService {
    private final AttendanceAuthorizationService authorization;
    private final AttendanceEmployeeService employees;
    private final AttendancePunchRawLogService punches;
    // 精确外部身份解析，不调用登录绑定或组织表。
    @Autowired private AttendanceEmployeeExternalMappingService mappings;
    // 本次创建的批次及幂等结果由独立表 Service 持久化。
    @Autowired private AttendancePunchImportBatchService batches;
    // 只核查安全来源登记，enabled=0 不阻止人工 CSV，也不授权网络连接。
    @Autowired private AttendancePunchSourceConfigService sources;

    /**
     * 装配表服务，不持有跨表 DAO。
     *
     * @param authorization 真实管理配置服务
     * @param employees 员工服务
     * @param punches 原始打卡服务；构造不执行数据库操作
     */
    public AttendancePunchCommandServiceImpl(
            AttendanceAuthorizationService authorization,
            AttendanceEmployeeService employees,
            AttendancePunchRawLogService punches) {
        this.authorization = authorization;
        this.employees = employees;
        this.punches = punches;
    }

    /**
     * 校验员工归属并保存旧四类管理补录事实，不计算工资或审批补卡。
     *
     * @param input 业务参数，例如 employeeId=8801、punchTime=2026-10-03T22:00:00、punchType=CLOCK_IN
     * @return 真实 CommonResult，例如 data.id=100001、data.processStatus=PROCESSED
     *     异常或副作用示例：例如未知打卡类型或缺管理配置拒绝；保存后原始事实不可直接修改。
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult receiveManual(CommonParam input) {
        Map<String, Long> identity = authorization.requireManagement();
        long employeeId;
        LocalDateTime time;
        String type;
        try {
            employeeId =
                    new BigDecimal(String.valueOf(input.getParam("employeeId"))).longValueExact();
            if (employeeId <= 0) {
                throw new IllegalArgumentException();
            }
            time =
                    LocalDateTime.parse(
                            String.valueOf(input.getParam("punchTime")).trim().replace(' ', 'T'));
            type = String.valueOf(input.getParam("punchType")).trim().toUpperCase(Locale.ROOT);
            if (!Set.of("CLOCK_IN", "CLOCK_OUT", "BREAK_START", "BREAK_END").contains(type)) {
                throw new IllegalArgumentException();
            }
        } catch (RuntimeException invalid) {
            throw new CommonBusinessException("ATTENDANCE_PUNCH_INPUT_INVALID", "员工、打卡时间或打卡类型无效。");
        }
        CommonParam employee = new CommonParam();
        employee.putParam("id", employeeId);
        employees.getById(employee);
        String note =
                input.getParam("note") == null ? "" : input.getParam("note").toString().trim();
        if (note.length() > 1000) {
            throw new CommonBusinessException("ATTENDANCE_PUNCH_INPUT_INVALID", "补录备注超过允许长度。");
        }
        CommonParam stored = new CommonParam();
        stored.putParam("employeeId", employeeId);
        stored.putParam("sourceSystem", "MANUAL");
        stored.putParam("sourceEventId", UUID.randomUUID().toString());
        stored.putParam("punchTime", time);
        stored.putParam("punchType", type);
        stored.putParam("deviceName", "管理员手动补录");
        stored.putParam("processStatus", "PROCESSED");
        stored.putParam(
                "rawPayload",
                JsonUtils.toJsonIgnoreNull(
                        Map.of(
                                "employeeId",
                                employeeId,
                                "operatorId",
                                identity.get("userId"),
                                "note",
                                note)));
        return punches.storeReceived(stored);
    }

    /**
     * 导入精确来源 CSV，分类结果、批次和原始事实同事务保存；不计算工资或工时。
     *
     * @param input 例如 sourceSystem=CSV_A、importKey=UPLOAD_001、csvText=四列一行打卡文本
     * @return 真实批次 CommonResult，例如 data.id=100001、successCount=1、importStatus=COMPLETED、resultJson
     *     含行号和打卡主键 异常或副作用示例：同键异摘要拒绝；持久化失败整批回滚；未匹配和冲突不绑定员工。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult importCsv(CommonParam input) {
        authorization.requireManagement();
        String source;
        String importKey;
        String digest;
        String fileName;
        List<Map<String, String>> rows;
        try {
            source = AttendanceCsvImportValues.key(input.getParam("sourceSystem"), 50);
            importKey = AttendanceCsvImportValues.key(input.getParam("importKey"), 100);
            String csv =
                    input.getParam("csvText") == null ? null : input.getParam("csvText").toString();
            digest = AttendanceCsvImportValues.digest(csv);
            rows = AttendanceCsvImportValues.parse(csv);
            fileName =
                    input.getParam("fileName") == null
                            ? "CSV_TEXT"
                            : AttendanceCsvImportValues.key(input.getParam("fileName"), 300);
        } catch (IllegalArgumentException invalid) {
            throw new CommonBusinessException("ATTENDANCE_CSV_INVALID", "CSV 结构、来源、幂等键或文件名无效。");
        }
        // 先等待真实来源锁，再读取幂等批次/映射；等待期间他人提交的事实必须可见。
        sources.lockSource(source);
        CommonParam batchKey = new CommonParam();
        batchKey.putParam("sourceSystem", source);
        batchKey.putParam("importKey", importKey);
        Map<String, Object> previous = resultRow(batches.findImport(batchKey));
        if (previous != null) {
            if (!digest.equals(previous.get("contentDigest"))) {
                throw new CommonBusinessException(
                        "ATTENDANCE_IMPORT_KEY_CONFLICT", "该幂等键已对应其他 CSV 内容，请核查后使用明确的新批次键。");
            }
            if (!Set.of("COMPLETED", "PARTIAL")
                    .contains(String.valueOf(previous.get("importStatus")))) {
                throw new CommonBusinessException(
                        "ATTENDANCE_IMPORT_IN_PROGRESS", "该批次尚未完成，请稍后重新核验。");
            }
            // 同键同内容返回已经持久化的结果，不随新映射重放旧文件。
            CommonParam id = new CommonParam();
            id.putParam("id", previous.get("id"));
            return batches.getById(id);
        }
        CommonParam begin = new CommonParam();
        begin.putParam("sourceSystem", source);
        begin.putParam("importKey", importKey);
        begin.putParam("contentDigest", digest);
        begin.putParam("fileName", fileName);
        Map<String, Object> batch = resultRow(batches.beginImport(begin));
        Object batchId = batch.get("id");
        List<Map<String, Object>> outcomes = new ArrayList<>();
        List<CommonParam> facts = new ArrayList<>();
        List<Map<String, Object>> storedOutcomes = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Set<String> conflictingEvents = AttendanceCsvImportValues.conflictingEvents(rows);
        for (int index = 0; index < rows.size(); index++) {
            Map<String, String> row = rows.get(index);
            Map<String, Object> outcome = new LinkedHashMap<>();
            outcome.put("rowNumber", index + 1);
            outcomes.add(outcome);
            if (!AttendanceCsvImportValues.validateRow(row).equals("VALID")) {
                outcome.put("processStatus", "ERROR");
                outcome.put("reasonCode", "INVALID_PUNCH_ROW");
                continue;
            }
            String event = AttendanceCsvImportValues.key(row.get("sourceEventId"), 100);
            String external = AttendanceCsvImportValues.key(row.get("externalEmployeeId"), 100);
            LocalDateTime time = LocalDateTime.parse(row.get("punchTime").trim().replace(' ', 'T'));
            String type = row.get("punchType").trim();
            if (conflictingEvents.contains(event)) {
                outcome.put("processStatus", "CONFLICT");
                outcome.put("reasonCode", "FILE_EVENT_FACT_CONFLICT");
                continue;
            }
            if (!seen.add(event)) {
                outcome.put("processStatus", "DUPLICATE");
                outcome.put("reasonCode", "FILE_EVENT_REPEATED");
                continue;
            }
            CommonParam eventKey = new CommonParam();
            eventKey.putParam("sourceSystem", source);
            eventKey.putParam("sourceEventId", event);
            Map<String, Object> existing = resultRow(punches.findScoped(eventKey));
            if (existing != null) {
                boolean same =
                        external.equals(existing.get("externalEmployeeId"))
                                && type.equals(existing.get("punchType"))
                                && time.equals(
                                        existing.get("punchTime")
                                                        instanceof java.sql.Timestamp stamp
                                                ? stamp.toLocalDateTime()
                                                : existing.get("punchTime"));
                outcome.put("processStatus", same ? "DUPLICATE" : "CONFLICT");
                outcome.put(
                        "reasonCode",
                        same ? "STORED_EVENT_REPEATED" : "STORED_EVENT_FACT_CONFLICT");
                outcome.put("punchId", existing.get("id"));
                continue;
            }
            CommonParam mappingKey = new CommonParam();
            mappingKey.putParam("sourceSystem", source);
            mappingKey.putParam("externalEmployeeId", external);
            Map<String, Object> mapping = resultRow(mappings.resolve(mappingKey));
            String resolution = String.valueOf(mapping.get("resolution"));
            String processStatus = resolution.equals("RESOLVED") ? "PROCESSED" : resolution;
            outcome.put("processStatus", processStatus);
            outcome.put(
                    "reasonCode",
                    resolution.equals("RESOLVED")
                            ? "EXACT_VERIFIED_MAPPING"
                            : "MAPPING_" + resolution);
            outcome.put("mappingMatchCount", mapping.get("matchCount"));
            CommonParam fact = new CommonParam();
            fact.putParam("sourceSystem", source);
            fact.putParam("sourceEventId", event);
            fact.putParam("externalEmployeeId", external);
            fact.putParam("punchTime", time);
            fact.putParam("punchType", type);
            fact.putParam(
                    "employeeId", resolution.equals("RESOLVED") ? mapping.get("employeeId") : null);
            fact.putParam("importBatchId", batchId);
            fact.putParam("processStatus", processStatus);
            fact.putParam(
                    "errorMessage", resolution.equals("RESOLVED") ? null : "MAPPING_" + resolution);
            fact.putParam("deviceId", row.get("deviceId"));
            fact.putParam("deviceName", row.get("deviceName"));
            fact.putParam("status", 1);
            facts.add(fact);
            storedOutcomes.add(outcome);
        }
        if (!facts.isEmpty()) {
            CommonBatchParam received = new CommonBatchParam();
            received.setItems(facts);
            punches.storeReceivedBatch(received);
            // 公共批量链路把各事实的新号段 ID 写回原参数，逐项关联行结果，不查询最后一条记录。
            for (int index = 0; index < facts.size(); index++) {
                storedOutcomes.get(index).put("punchId", facts.get(index).getParam("id"));
            }
        }
        CommonParam finish = new CommonParam();
        finish.setParamMap(AttendanceCsvImportValues.summarize(outcomes));
        finish.putParam("id", batchId);
        finish.putParam("resultJson", JsonUtils.toJsonIgnoreNull(outcomes));
        batches.finishImport(finish);
        CommonParam id = new CommonParam();
        id.putParam("id", batchId);
        return batches.getById(id);
    }

    /**
     * 取得表 Service 的真实 Map 结果，不合成数据库行。
     *
     * @param result 例如 CommonResult.data={id:100001} 或 null
     * @return 同一个真实 Map；无匹配返回 null 异常或副作用示例：异常结果结构抛 IllegalStateException，所属事务回滚。
     * @throws IllegalStateException Unexpected table service result
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> resultRow(CommonResult result) {
        if (result.getData() == null) {
            return null;
        }
        if (!(result.getData() instanceof Map<?, ?>)) {
            throw new IllegalStateException("Unexpected table service result");
        }
        return (Map<String, Object>) result.getData();
    }
}
