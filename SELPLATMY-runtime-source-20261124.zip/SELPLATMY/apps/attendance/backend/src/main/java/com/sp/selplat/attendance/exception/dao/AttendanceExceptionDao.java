package com.sp.selplat.attendance.exception.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceException 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceExceptionDao extends BaseDao { }
