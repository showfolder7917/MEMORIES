package com.sp.selplat.attendance.schedulebatch.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceScheduleBatch 唯一本表 DAO 契约，不读取组织、账号或其他表。 */
public interface AttendanceScheduleBatchDao extends BaseDao {
    /**
     * 只查本表真实操作者精确键。
     *
     * @param input 服务端tenantId=81/createdBy=8103/requestKey=BATCH-001
     * @return 实际行例如fingerprint为64位摘要，CLOB转真实字符串；不存在null
     */
    java.util.Map<String, Object> findReceipt(com.sp.selplat.common.util.CommonParam input);
}
