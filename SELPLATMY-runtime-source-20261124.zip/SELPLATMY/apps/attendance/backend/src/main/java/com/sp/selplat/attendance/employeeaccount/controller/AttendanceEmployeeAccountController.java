package com.sp.selplat.attendance.employeeaccount.controller;

import com.sp.selplat.attendance.employeeaccount.service.AttendanceEmployeeAccountService;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 复用共通 Controller 序列化，表服务在真实认证后仍要求考勤业务授权。 */
@RestController
@RequestMapping("/api/attendance/employeeaccount")
public class AttendanceEmployeeAccountController
        extends BaseController<AttendanceEmployeeAccountService> { }
