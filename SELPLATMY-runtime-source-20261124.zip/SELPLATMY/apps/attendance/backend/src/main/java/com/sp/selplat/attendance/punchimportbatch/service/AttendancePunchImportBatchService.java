/* 2026-11-01：打卡与批次原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.punchimportbatch.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendancePunchImportBatch 表服务，管理查询复用公共 CRUD；写入仅走本域专用流程。 */
public interface AttendancePunchImportBatchService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * @param input 例如 CSV_A/UPLOAD_001
   * @return 实际批次或 null；不写入。
   */
  CommonResult findImport(CommonParam input);

  /**
   * @param input 已校验的来源/幂等键/摘要
   * @return 本次新增批次 ID；唯一键冲突回滚。
   */
  CommonResult beginImport(CommonParam input);

  /**
   * @param input 本次 ID 与安全分类结果
   * @return PARTIAL/COMPLETED 更新结果；写本表。
   */
  CommonResult finishImport(CommonParam input);
}
