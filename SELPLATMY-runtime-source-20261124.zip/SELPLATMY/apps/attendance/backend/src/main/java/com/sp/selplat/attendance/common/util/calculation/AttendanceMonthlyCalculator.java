/*
 * 文件：AttendanceMonthlyCalculator.java
 * 修改：2026-10-03；迁移 SELATTENDANCE bdf84ebe9b30ac713f714df93c470f1b8f23d27f 的月聚合纯值部分。
 */
package com.sp.selplat.attendance.common.util.calculation;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/** 按旧月次口径汇总同一员工、同一月份的已持久化日次快照。 不查库、不月结、不改审批；最终时间总工时未应用取整的旧行为保留并需业务裁定。 */
public final class AttendanceMonthlyCalculator {
    private static final String CLOSE_STATUS_OPEN = "OPEN";
    private static final String CLOSE_STATUS_CLOSABLE = "CLOSABLE";
    private static final String CLOSE_STATUS_CLOSED = "CLOSED";
    private static final String CLOSE_STATUS_REOPENED = "REOPENED";

    /**
     * 将服务按员工、年月筛出的日次快照汇总成 15 个指标及其来源、月结阻塞原因。 CLOSED 的保护和 overwriteClosed 权限应由拥有事务的月次服务执行，本工具只保留状态。
     *
     * @param employeeRows 服务提供的同员工同月日次行，例如
     *     workDate=2026-07-03、actualWorkMinutes=510、handlingStatus=RESOLVED
     * @param existingCloseStatus DAO 原月次状态，例如 OPEN、CLOSED、REOPENED
     * @return Map，例如
     *     scheduledDays=1、totalWorkMinutes=510、overtimeMinutes=30、closeStatus=CLOSABLE、blockReasons=[]
     * @throws NumberFormatException 当持久化分钟为错误文本，例如 overtimeMinutes=invalid
     * @throws java.time.format.DateTimeParseException 当持久化日期格式错误，例如 workDate=invalid
     */
    public static Map<String, Object> aggregate(
            List<Map<String, Object>> employeeRows, String existingCloseStatus) {
        MonthlyAggregation aggregation = new MonthlyAggregation();
        for (Map<String, Object> row : employeeRows) {
            LocalDate workDate = localDateValue(mapValue(row, "workDate"));
            String effectiveStatus = resolveEffectiveStatus(row);
            String handlingStatus = stringValue(mapValue(row, "handlingStatus"));
            boolean exceptionFlag = booleanValue(mapValue(row, "exceptionFlag"));
            boolean lockedFlag = booleanValue(mapValue(row, "lockedFlag"));
            String workDayType = stringValue(mapValue(row, "workDayType"));

            if (mapValue(row, "shiftScheduleId") != null) {
                aggregation.scheduledDays += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("SCHEDULED_DAYS", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if (isAttendanceStatus(effectiveStatus)) {
                aggregation.attendanceDays += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("ATTENDANCE_DAYS", ignored -> new ArrayList<>())
                        .add(workDate + ":" + effectiveStatus);
            }
            if ("NORMAL".equals(effectiveStatus)) {
                aggregation.normalDays += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("NORMAL_DAYS", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if ("LATE".equals(effectiveStatus)) {
                aggregation.lateCount += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("LATE_COUNT", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if ("EARLY_LEAVE".equals(effectiveStatus)) {
                aggregation.earlyLeaveCount += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("EARLY_LEAVE_COUNT", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if ("MISSING_CLOCK_IN".equals(effectiveStatus)
                    || "MISSING_CLOCK_OUT".equals(effectiveStatus)) {
                aggregation.missingPunchCount += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("MISSING_PUNCH_COUNT", ignored -> new ArrayList<>())
                        .add(workDate + ":" + effectiveStatus);
            }
            if ("ABSENCE".equals(effectiveStatus)) {
                aggregation.absenceCount += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("ABSENCE_COUNT", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if (exceptionFlag || !"RESOLVED".equals(handlingStatus)) {
                aggregation.exceptionDays += 1;
                aggregation
                        .metricSources
                        .computeIfAbsent("EXCEPTION_DAYS", ignored -> new ArrayList<>())
                        .add(workDate + ":" + handlingStatus);
            }
            // 总工时优先根据最终确认后的打卡时间重算；若没有最终时间，再回退第四阶段已落库的工作分钟。
            int totalWorkMinutes = resolveDailyWorkMinutes(row);
            aggregation.totalWorkMinutes += totalWorkMinutes;
            aggregation
                    .metricSources
                    .computeIfAbsent("TOTAL_WORK_MINUTES", ignored -> new ArrayList<>())
                    .add(workDate + ":" + totalWorkMinutes);
            // 第四阶段已经产出了残业、法定外残业、深夜和休日分钟，这里直接按稳定日次结果聚合进月次层。
            int overtimeMinutes = intValue(mapValue(row, "overtimeMinutes"));
            aggregation.overtimeMinutes += overtimeMinutes;
            aggregation
                    .metricSources
                    .computeIfAbsent("OVERTIME_MINUTES", ignored -> new ArrayList<>())
                    .add(workDate + ":" + overtimeMinutes);
            int legalOvertimeMinutes = intValue(mapValue(row, "legalOvertimeMinutes"));
            aggregation.legalOvertimeMinutes += legalOvertimeMinutes;
            aggregation
                    .metricSources
                    .computeIfAbsent("LEGAL_OVERTIME_MINUTES", ignored -> new ArrayList<>())
                    .add(workDate + ":" + legalOvertimeMinutes);
            int nightWorkMinutes = intValue(mapValue(row, "nightWorkMinutes"));
            aggregation.nightWorkMinutes += nightWorkMinutes;
            aggregation
                    .metricSources
                    .computeIfAbsent("NIGHT_WORK_MINUTES", ignored -> new ArrayList<>())
                    .add(workDate + ":" + nightWorkMinutes);
            int holidayWorkMinutes = intValue(mapValue(row, "holidayWorkMinutes"));
            aggregation.holidayWorkMinutes += holidayWorkMinutes;
            aggregation
                    .metricSources
                    .computeIfAbsent("HOLIDAY_WORK_MINUTES", ignored -> new ArrayList<>())
                    .add(workDate + ":" + holidayWorkMinutes);
            if ("PAID_LEAVE".equals(workDayType) || "PAID_LEAVE".equals(effectiveStatus)) {
                aggregation.paidLeaveDays = aggregation.paidLeaveDays.add(BigDecimal.ONE);
                aggregation
                        .metricSources
                        .computeIfAbsent("PAID_LEAVE_DAYS", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            if ("REST".equals(workDayType) || "REST".equals(effectiveStatus)) {
                aggregation.restDays = aggregation.restDays.add(BigDecimal.ONE);
                aggregation
                        .metricSources
                        .computeIfAbsent("REST_DAYS", ignored -> new ArrayList<>())
                        .add(workDate.toString());
            }
            appendBlockReasons(
                    aggregation.blockReasons, workDate, handlingStatus, exceptionFlag, lockedFlag);
        }

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("scheduledDays", aggregation.scheduledDays);
        out.put("attendanceDays", aggregation.attendanceDays);
        out.put("normalDays", aggregation.normalDays);
        out.put("lateCount", aggregation.lateCount);
        out.put("earlyLeaveCount", aggregation.earlyLeaveCount);
        out.put("missingPunchCount", aggregation.missingPunchCount);
        out.put("absenceCount", aggregation.absenceCount);
        out.put("exceptionDays", aggregation.exceptionDays);
        out.put("totalWorkMinutes", aggregation.totalWorkMinutes);
        out.put("overtimeMinutes", aggregation.overtimeMinutes);
        out.put("legalOvertimeMinutes", aggregation.legalOvertimeMinutes);
        out.put("nightWorkMinutes", aggregation.nightWorkMinutes);
        out.put("holidayWorkMinutes", aggregation.holidayWorkMinutes);
        out.put("paidLeaveDays", aggregation.paidLeaveDays);
        out.put("restDays", aggregation.restDays);
        out.put("paidLeaveDays", aggregation.paidLeaveDays.setScale(2));
        out.put("restDays", aggregation.restDays.setScale(2));
        out.put("metricSources", aggregation.metricSources);
        out.put("blockReasons", aggregation.blockReasons);
        out.put("blockReasonCount", aggregation.blockReasons.size());
        out.put(
                "closeStatus",
                resolveCloseStatus(existingCloseStatus, aggregation.blockReasons.size()));
        return out;
    }

    /**
     * 按既有日次处理、异常及锁定标记向内存列表追加月结阻塞原因。
     *
     * @param reasons 当前月份阻塞原因列表，在内存中追加。
     * @param workDate 当前日次日期。
     * @param handlingStatus 日次处理状态。
     * @param exceptionFlag 日次异常标记。
     * @param lockedFlag 日次锁定标记。
     */
    private static void appendBlockReasons(
            List<Map<String, Object>> reasons,
            LocalDate workDate,
            String handlingStatus,
            boolean exceptionFlag,
            boolean lockedFlag) {
        if (!"RESOLVED".equals(handlingStatus)) {
            reasons.add(blockReason("UNRESOLVED_DAILY", workDate, "当日日次仍未处理完成"));
        }
        if (exceptionFlag) {
            reasons.add(blockReason("UNRESOLVED_EXCEPTION", workDate, "当日仍存在未闭环异常"));
        }
        if (exceptionFlag && !lockedFlag) {
            reasons.add(blockReason("UNLOCKED_EXCEPTION", workDate, "当日异常已处理但仍未锁定"));
        }
    }

    /**
     * 判断既有已出勤业务状态集合，不修改日次。
     *
     * @param status 既有日次业务状态。
     * @return 状态是否属于NORMAL、LATE、EARLY_LEAVE或HOLIDAY_WORK。
     */
    private static boolean isAttendanceStatus(String status) {
        return List.of("NORMAL", "LATE", "EARLY_LEAVE", "HOLIDAY_WORK").contains(status);
    }

    /**
     * 按既有月结状态及阻塞数量计算状态，不写数据库。
     *
     * @param existingCloseStatus 现有月结状态，CLOSED保持不变。
     * @param blockReasonCount 本次汇总得到的阻塞原因数量。
     * @return 既有月结状态决策结果；CLOSED保持，其他状态按阻塞数处理。
     */
    private static String resolveCloseStatus(String existingCloseStatus, int blockReasonCount) {
        if (CLOSE_STATUS_CLOSED.equals(existingCloseStatus)) {
            return CLOSE_STATUS_CLOSED;
        }
        if (CLOSE_STATUS_REOPENED.equals(existingCloseStatus)) {
            return blockReasonCount == 0 ? CLOSE_STATUS_REOPENED : CLOSE_STATUS_OPEN;
        }
        return blockReasonCount == 0 ? CLOSE_STATUS_CLOSABLE : CLOSE_STATUS_OPEN;
    }

    /**
     * 读取日次最终状态优先于原状态。
     *
     * @param row 来源或日次快照字段；不访问数据库。
     * @return 非空finalStatus优先，否则返回原status。
     */
    private static String resolveEffectiveStatus(Map<String, Object> row) {
        String finalStatus = stringValue(mapValue(row, "finalStatus"));
        return hasText(finalStatus) ? finalStatus : stringValue(mapValue(row, "status"));
    }

    /**
     * 按已有最终卡及休息字段计算非负工时，缺最终卡时读取实际工时。
     *
     * @param row 来源或日次快照字段；不访问数据库。
     * @return 完整最终时间减最终/实际休息的非负分钟；否则返回既有实际工时。
     */
    private static int resolveDailyWorkMinutes(Map<String, Object> row) {
        LocalDateTime finalClockIn = localDateTimeValue(mapValue(row, "finalClockIn"));
        LocalDateTime finalClockOut = localDateTimeValue(mapValue(row, "finalClockOut"));
        if (finalClockIn != null
                && finalClockOut != null
                && !finalClockOut.isBefore(finalClockIn)) {
            int breakMinutes =
                    intValue(
                            mapValue(row, "finalBreakMinutes") != null
                                    ? mapValue(row, "finalBreakMinutes")
                                    : mapValue(row, "actualBreakMinutes"));
            int workedMinutes =
                    (int) java.time.Duration.between(finalClockIn, finalClockOut).toMinutes()
                            - breakMinutes;
            return Math.max(workedMinutes, 0);
        }
        return intValue(mapValue(row, "actualWorkMinutes"));
    }

    /**
     * 按既有大小写及下划线兼容顺序读取字段，不修改来源。
     *
     * @param row 来源或日次快照字段；不访问数据库。
     * @param key 要读取的字段名，兼容已有键名大小写和下划线形式。
     * @return 按既有键名兼容顺序找到的值；无匹配返回null。
     */
    private static Object mapValue(Map<String, Object> row, String key) {
        if (row == null || key == null) {
            return null;
        }
        if (row.containsKey(key)) {
            return row.get(key);
        }
        String snakeKey = key.replaceAll("([a-z0-9])([A-Z])", "$1_$2").toLowerCase(Locale.ROOT);
        if (row.containsKey(snakeKey)) {
            return row.get(snakeKey);
        }
        String upperCamelKey = key.toUpperCase(Locale.ROOT);
        if (row.containsKey(upperCamelKey)) {
            return row.get(upperCamelKey);
        }
        String upperSnakeKey = snakeKey.toUpperCase(Locale.ROOT);
        if (row.containsKey(upperSnakeKey)) {
            return row.get(upperSnakeKey);
        }
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (entry.getKey() != null && entry.getKey().equalsIgnoreCase(key)) {
                return entry.getValue();
            }
        }
        return null;
    }

    /**
     * 把字段转换为分钟整数；null返回0，非法字符串沿用解析异常。
     *
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @return Number或字符串转换的int；null返回0，非法文本保留解析异常。
     */
    private static int intValue(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    /**
     * 读取字段文本，null转空串。
     *
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @return 值的字符串表示；null返回空串。
     */
    private static String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    /**
     * 读取或解析日期，不补猜缺失日期。
     *
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @return 已有或解析后的LocalDate；null返回null，非法文本保留解析异常。
     */
    private static LocalDate localDateValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDate localDate) {
            return localDate;
        }
        return LocalDate.parse(String.valueOf(value));
    }

    /**
     * 读取或解析日期时间，保留原空格转T兼容口径。
     *
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @return 已有或解析后的LocalDateTime；null返回null，字符串空格转换T。
     */
    private static LocalDateTime localDateTimeValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDateTime localDateTime) {
            return localDateTime;
        }
        return LocalDateTime.parse(String.valueOf(value).replace(' ', 'T'));
    }

    /**
     * 使用现有布尔/数字/字符串转换，不改变锁定或异常判定。
     *
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @return 既有布尔/数字/字符串规则转换结果；null返回false。
     */
    private static boolean booleanValue(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean bool) {
            return bool;
        }
        if (value instanceof Number number) {
            return number.intValue() != 0;
        }
        return Objects.equals("true", String.valueOf(value).toLowerCase(Locale.ROOT));
    }

    /**
     * 将旧 BlockReasonOut 转成 Map，保留日次日期、阻塞码和消息。
     *
     * @param code 算法阻塞码，例如 UNRESOLVED_DAILY
     * @param workDate 已持久化日次日期，例如 2026-07-03
     * @param message 旧业务说明，例如 当日日次仍未处理完成
     * @return Map，例如 blockCode=UNRESOLVED_DAILY、workDate=2026-07-03、blockMessage=当日日次仍未处理完成
     */
    private static Map<String, Object> blockReason(
            String code, LocalDate workDate, String message) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("blockCode", code);
        result.put("workDate", workDate);
        result.put("blockMessage", message);
        return result;
    }

    /**
     * 等价保留 StringUtils.hasText 的空白文本语义。
     *
     * @param value 旧算法状态文本，例如 NORMAL
     * @return 有非空白字符时 true，例如 NORMAL -> true
     */
    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    private static final class MonthlyAggregation {
        private Long employeeId;
        private Long workplaceId;
        private Long departmentId;
        private String employeeCode;
        private String employeeName;
        private String workplaceName;
        private String departmentName;
        private int scheduledDays;
        private int attendanceDays;
        private int normalDays;
        private int lateCount;
        private int earlyLeaveCount;
        private int missingPunchCount;
        private int absenceCount;
        private int exceptionDays;
        private int totalWorkMinutes;
        private int overtimeMinutes;
        private int legalOvertimeMinutes;
        private int nightWorkMinutes;
        private int holidayWorkMinutes;
        private BigDecimal paidLeaveDays = BigDecimal.ZERO;
        private BigDecimal restDays = BigDecimal.ZERO;
        private Map<String, List<String>> metricSources = new LinkedHashMap<>();
        private List<Map<String, Object>> blockReasons = new ArrayList<>();
    }
}
