/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：审批来源纯读接入，原保存/审批来源保护保持。 */
/* 2026-11-01：保留sortnum降序，同值固定id升序，避免分页依赖物理行次序。 */
/* 2026-11-01：原人员关联与排班纯读，原写/锁/事务算法保留。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.shiftschedule.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.shiftschedule.dao.AttendanceShiftScheduleDao;
import com.sp.selplat.attendance.shiftschedule.service.AttendanceShiftScheduleService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceShiftSchedule 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceShiftScheduleServiceImpl extends BaseServiceImpl<AttendanceShiftScheduleDao>
    implements AttendanceShiftScheduleService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    return super.delete(input);
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    return super.deleteBatch(input);
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    if (mutation && row.get("locked") instanceof Number locked && locked.intValue() != 0) {
      throw new CommonBusinessException("ATTENDANCE_SCHEDULE_LOCKED", "锁定排班不能直接修改。");
    }
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceShiftSchedule 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 客户端计算字段不能绕过员工/模板校验；无数据库副作用。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用者抛出且无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用经过模板校验的排班保存入口。");
  }

  /**
   * 只供本域专用能力保存已校验事实或计算快照，没有直接 HTTP 写入口。
   *
   * @param input 内部服务产生的本表字段，例如 employeeId=8801；不直接转发客户端派生值
   * @return 实际 CommonResult，例如 success=true、data.id=100001、data.tenantId=81；新增主键来自共享号段
   *     异常或副作用示例：缺管理配置或受保护状态时拒绝；例如已锁定记录不更新。本方法写入本域具名事务。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult storeScheduled(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    if (input.getParam("id") == null) {
      return super.insert(input);
    }
    requireRecord(input, true);
    return super.update(input);
  }

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批能力的受控字段，例如employeeId=8801、workDate=2026-10-04
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  @Override
  public CommonResult findForApproval(CommonParam criteria) {
    return loadApprovalSource(criteria, authorization.requireApproval());
  }

  /**
   * 模板保护由真实管理身份授权后读取本表保留引用。
   *
   * @param input 所属模板服务传入主键例如id=8901
   * @return 实际引用数例如1；无业务写入，缺可信许可拒绝
   */
  @Override
  public long countTemplateReferences(CommonParam input) {
    input.putParam("tenantId", requireManagement().get("tenantId"));
    return getDao().countTemplateReferences(input);
  }

  /**
   * 本租户保留日期事实，包括软删除行，读库无写入。
   *
   * @param input 能力白名单范围例如employeeId=8801/workDate=2026-10-10
   * @return 实际CommonResult.data.id=100001；不存在null，许可撤销拒绝
   */
  @Override
  public CommonResult findRetained(CommonParam input) {
    input.putParam("tenantId", requireManagement().get("tenantId"));
    return buildSuccessResult(getDao().findRetained(input), "排班冲突已查询。");
  }

  /**
   * 能力校验后再次核验每行权限和当前冲突，交公共batch写入。
   *
   * @param input 内部展开items例如employeeId=8801/workDate=2026-10-10
   * @return 真实公共CommonResult.data数组/affectedRows=2；约束失败整事务回滚
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult storeScheduledBatch(CommonBatchParam input) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", requireManagement().get("tenantId"));
      if (getDao().findRetained(item) != null) {
        throw new CommonBusinessException("ATTENDANCE_BATCH_CONFLICT", "批量排班存在冲突，请重新预览并修改。");
      }
    }
    return super.insertBatch(input);
  }

  /**
   * 方法作用：复用原本表COUNT查询，先后核真实只读管理资格，不修改永久引用。
   *
   * @param input 原所属配置编号，例如id8501，tenantId由服务端覆盖
   * @return 原真实保留引用数量，例如1，无数据写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格失效或换身份时拒绝旧计数
   */
  @Override
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public long countTemplateReferencesForRead(com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadManagement();
    input.putParam("tenantId", actor.get("tenantId"));
    long result = getDao().countTemplateReferences(input);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "引用读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原租户过滤与完整查询，不改变关联或锁定状态。
   *
   * @param input 原查询，例如id8410
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonPageResult，例如原记录或分页
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原租户过滤与完整查询，不改变关联或锁定状态。
   *
   * @param input 原查询，例如id8410
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonResult，例如原记录或分页
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原详情和真实租户校验，不修改或解锁关联记录。
   *
   * @param input 原主键，例如id8410或8210
   * @return 原完整详情，例如data.employeeId7020及原规则或排班字段
   * @throws CommonBusinessException 异校、失效、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：原配置和元数据表头沿系统查看门槛读取，不提升管理权限。
   *
   * @param viewCode 原表头编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns包含配置名称
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无配置写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "配置读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原审批来源完整过滤和返回，不锁定或标记引用。
   *
   * @param criteria 原来源条件，例如employeeId7080
   * @param identity 原已核审批身份，例如userId9102/tenantId9
   * @return 原CommonResult，例如原生效规则或排班
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原记录/来源错误沿原拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonResult loadApprovalSource(
      com.sp.selplat.common.util.CommonParam criteria, java.util.Map<String, Long> identity) {
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "审批计算来源已读取。");
  }

  /**
   * 方法作用：HTTP身份原审批来源只读，实际SELECT完成后重核资格。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原完整来源，不改变规则或快照
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原APPROVER失效/撤回或身份变化拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonResult readFindForApproval(
      com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadApprovalSource(input, actor);
    if (!actor.equals(authorization.requireReadApproval())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "审批来源读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
