/*
 * 修改记录：2026-10-09，月动作角色缺失沿用明确业务拒绝，避免不可空Set查询抛空指针。
 */
package com.sp.selplat.attendance.accessgrant.service.impl;

import com.sp.selplat.attendance.accessgrant.dao.AttendanceAccessGrantDao;
import com.sp.selplat.attendance.accessgrant.service.AttendanceAccessGrantService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceAccessGrant 复用共通 DAO 泛型注入及 CRUD；在可信授权来源核准前拒绝全部业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceAccessGrantServiceImpl extends BaseServiceImpl<AttendanceAccessGrantDao>
        implements AttendanceAccessGrantService {
    // 身份读取由Host具名公共能力装配，HTTP模式不读本地权限账号。
    @Autowired @Qualifier("attendanceCurrentSessionAccess") private CurrentSessionAccess sessionService;

    /**
     * 校验真实会话后拒绝尚未配置的管理权限。
     *
     * @return 校验真实身份后生成的管理能力未配置异常；不读写业务表
     * @throws com.sp.selplat.common.exception.CommonBusinessException 无效身份首先拒绝，例如匿名请求
     */
    private com.sp.selplat.common.exception.CommonBusinessException managementRejected() {
        return AttendanceAccessGuard.unconfiguredManagement(sessionService.current());
    }

    /**
     * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
     */
    @Override
    protected Long getCurrentOperatorId() {
        return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
    }

    /**
     * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
     */
    @Override
    protected Long getCurrentTenantId() {
        return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
    }

    /**
     * @return 固定 false，例如即使登录名为 admin 仍返回 false；管理能力只读取已核验配置。
     */
    @Override
    protected boolean isAdmin() {
        return false;
    }

    /**
     * 在进入共通 getStore 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonPageResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonPageResult getStore(CommonPageParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 getById 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult getById(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 getByIds 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult getByIds(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 insert 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult insert(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 insertBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult insertBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 update 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult update(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 updateBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult updateBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 delete 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    public CommonResult delete(CommonParam input) {
        throw managementRejected();
    }

    /**
     * 在进入共通 deleteBatch 前校验真实考勤管理权限。
     *
     * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
     * @return 共通 CommonResult；当前授权未配置，因此没有成功数据返回
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
     */
    @Override
    @OperationLog
    @Transactional(transactionManager = "attendanceTransactionManager")
    public CommonResult deleteBatch(CommonBatchParam input) {
        throw managementRejected();
    }

    /**
     * 由真实当前会话查询已核验 TENANT 角色记录，不接受请求身份。
     *
     * @param roleCode 调用能力确定的角色，例如 MANAGER 或 APPROVER
     * @return 真实配置 Map，例如 configurationStatus=VERIFIED、roleCode=MANAGER、tenantId=81；缺失或过期返回 null
     *     异常或副作用示例：例如部门范围不提升为全租户权限；仅本表查询，不发放授权。
     */
    @Override
    public Map<String, Object> findCurrentGrant(String roleCode) {
        Map<String, Long> identity =
                AttendanceAccessGuard.requireIdentity(sessionService.current());
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("userId", identity.get("userId"));
        query.putParam("configurationStatus", "VERIFIED");
        query.putParam("status", 1);
        if (!"MANAGER".equals(roleCode) && !"APPROVER".equals(roleCode)) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "ATTENDANCE_ACCESS_DENIED", "无效考勤授权类型。");
        }
        query.putParam("roleCode", roleCode);
        query.putParam("scopeCode", "TENANT");
        Map<String, Object> grant = getDao().findCurrentGrant(query);
        if (grant != null && grant.get("departmentId") != null) {
            return null;
        }
        if (grant != null && grant.get("expiresAt") != null) {
            java.time.LocalDateTime expiry =
                    java.time.LocalDateTime.parse(
                            String.valueOf(grant.get("expiresAt")).replace(' ', 'T'));
            if (!expiry.isAfter(java.time.LocalDateTime.now())) {
                return null;
            }
        }
        return grant;
    }

    /**
     * 按真实 Session 查询本人月报动作，不接受客户端角色或员工范围。
     *
     * @return 真实配置例如 roleCode=SELF_MONTHLY_READ、scopeCode=SELF、employeeId=8801；缺失返回 null
     *     异常或副作用示例：匿名拒绝，仅查询本表，不新增真实用户授权。
     */
    @Override
    public Map<String, Object> findCurrentMonthlyReadGrant() {
        Map<String, Long> identity =
                AttendanceAccessGuard.requireIdentity(sessionService.current());
        // 精确动作与范围由服务固定，不能把登录或管理角色当作本人月报许可。
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("userId", identity.get("userId"));
        query.putParam("configurationStatus", "VERIFIED");
        query.putParam("status", 1);
        query.putParam("roleCode", "SELF_MONTHLY_READ");
        query.putParam("scopeCode", "SELF");
        return getDao().getByQuery(query);
    }

    /**
     * 新动作读取独立配置，旧角色白名单与通用写拒绝不变。
     *
     * @param role 内部固定MONTHLY_REVIEW/PUBLISH/WITHDRAW
     * @return 当前真实tenant/user精确配置行或null，不生成许可 异常示例：任意其它角色拒绝，不读取其它租户配置。
     * @throws com.sp.selplat.common.exception.CommonBusinessException 缺角色例如null或不在白名单时返回
     *     ATTENDANCE_RELEASE_ACTION_INVALID，无数据写入或默认权限
     */
    @Override
    public Map<String, Object> findCurrentReleaseGrant(String role) {
        // 原白名单保持；缺角色与未知角色同样拒绝，不进入身份或配置查询。
        if (role == null
                || !java.util.Set.of("MONTHLY_REVIEW", "MONTHLY_PUBLISH", "MONTHLY_WITHDRAW")
                        .contains(role)) {
            throw new com.sp.selplat.common.exception.CommonBusinessException(
                    "ATTENDANCE_RELEASE_ACTION_INVALID", "月发布动作必须明确。");
        }
        var identity = AttendanceAccessGuard.requireIdentity(sessionService.current());
        CommonParam query = new CommonParam();
        query.putParam("tenantId", identity.get("tenantId"));
        query.putParam("userId", identity.get("userId"));
        query.putParam("roleCode", role);
        query.putParam("scopeCode", "TENANT");
        query.putParam("configurationStatus", "VERIFIED");
        query.putParam("status", 1);
        return getDao().getByQuery(query);
    }
}
