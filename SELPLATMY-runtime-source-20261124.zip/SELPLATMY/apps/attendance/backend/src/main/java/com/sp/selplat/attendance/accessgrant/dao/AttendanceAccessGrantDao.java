/* 2026-10-29：本域管理配置在原事务内持锁到提交，普通读取保持原合同。 */
package com.sp.selplat.attendance.accessgrant.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 只拥有AttendanceAccessGrant本表，不访问身份或员工表，不授予权限。 */
public interface AttendanceAccessGrantDao extends BaseDao {
  /**
   * 方法作用：MANAGER在原本域可写事务中按真实租户/用户持锁重读，其余查询复用原模板。
   *
   * @param query 原拥有方身份构建的查询，例如tenantId9/userId9102/MANAGER/TENANT
   * @return 本表真实配置，例如id8001/configurationStatusVERIFIED/status1；无行null
   * @throws com.sp.selplat.common.exception.CommonBusinessException 本域写事务不是读已提交时拒绝
   */
  Map<String, Object> findCurrentGrant(CommonParam query);
}
