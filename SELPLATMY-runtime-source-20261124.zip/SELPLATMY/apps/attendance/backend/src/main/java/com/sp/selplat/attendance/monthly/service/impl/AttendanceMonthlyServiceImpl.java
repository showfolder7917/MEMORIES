/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.monthly.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.monthly.dao.AttendanceMonthlyDao;
import com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceMonthly 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceMonthlyServiceImpl extends BaseServiceImpl<AttendanceMonthlyDao>
    implements AttendanceMonthlyService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  @Autowired private com.sp.selplat.attendance.employee.service.AttendanceEmployeeService employees;

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceMonthlyReleaseReady")
  private Boolean releaseReady;

  @Autowired
  private com.sp.selplat.attendance.monthlyreview.service.AttendanceMonthlyReviewService reviews;

  @Autowired
  private com.sp.selplat.attendance.monthlypublication.service.AttendanceMonthlyPublicationService
      publications;

  // 审计所属服务在同一考勤事务追加，不跨表使用日志 DAO，也不能修改旧日志。
  @Autowired
  private com.sp.selplat.attendance.monthlyactionlog.service.AttendanceMonthlyActionLogService
      actionLogs;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 原始卡和派生快照通过本域专用流程写入，不能以通用 CRUD 修改工资/工时事实。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用方抛出后无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用对应打卡、计算或审批流程。");
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceMonthly 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 只供本域专用能力保存已校验事实或计算快照，没有直接 HTTP 写入口。
   *
   * @param input 内部服务产生的本表字段，例如 employeeId=8801；不直接转发客户端派生值
   * @return 实际 CommonResult，例如 success=true、data.id=100001、data.tenantId=81；新增主键来自共享号段
   *     异常或副作用示例：缺管理配置或受保护状态时拒绝；例如已锁定记录不更新。本方法写入本域具名事务。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult storeCalculated(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    requireMutablePeriod(input);
    // 算法 metricSources/blockReasons 等解释字段由其他所属服务处理，不送入严格物理列写入。
    String trigger =
        "PRE_CLOSE".equals(input.getParam("internalTrigger")) ? "PRE_CLOSE" : "MANUAL_RECALCULATE";
    Map<String, Object> fields = new java.util.LinkedHashMap<>();
    java.util.Set<String> columns = getDao().getDbColumnsMap().keySet();
    input
        .getParamMap()
        .forEach(
            (key, value) -> {
              if (columns.contains(key)) {
                fields.put(key, value);
              }
            });
    input.setParamMap(fields);
    // 重算改变快照事实，必须撤下本人可见性，不能把客户端发布字段带入。
    input.putParam("publicationStatus", "DRAFT");
    input.putParam("publishedAt", null);
    input.putParam("effectiveAt", null);
    input.putParam("tenantId", identity.get("tenantId"));
    CommonResult saved;
    if (input.getParam("id") == null) {
      saved = super.insert(input);
    } else {
      requireRecord(input, true);
      Map<String, Object> current = getDao().getById(input);
      if ("CLOSED".equals(current.get("closeStatus"))) {
        throw new CommonBusinessException("ATTENDANCE_MONTHLY_CLOSED", "已关闭月次不能覆盖重算。");
      }
      saved = super.update(input);
    }
    CommonParam journal = new CommonParam();
    journal.putParam("monthlyId", input.getParam("id"));
    // 当前调用方是手动月次重算，保持旧系统 MANUAL_RECALCULATE 审计语义。
    journal.putParam("actionType", trigger);
    journal.putParam("actionComment", "月次计算快照已保存。");
    journal.putParam(
        "snapshotJson", com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(input.getParamMap()));
    // 日志约束失败应使本次月次写入一同回滚，不能以日志失败但业务成功收尾。
    actionLogs.appendAction(journal);
    return saved;
  }

  /**
   * 按旧反结语义重开真实月次，不新增必须先为 CLOSED 的业务限制，不重新计算分钟。
   *
   * @param input 目标和原因，例如 id=100001、reason=核对补卡；只采纳这两个字段
   * @return 实际 CommonResult，例如 data.closeStatus=REOPENED、data.reopenedBy=8101
   *     异常或副作用示例：无权限/空原因/异租户拒绝；状态和日志使用同一具名串行化事务。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult reopen(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    String reason = input.getParam("reason") == null ? null : input.getParam("reason").toString();
    com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.reopenOutcome(reason);
    CommonParam changed = new CommonParam();
    changed.putParam("id", input.getParam("id"));
    changed.putParam("tenantId", identity.get("tenantId"));
    requireRecord(changed, true);
    Map<String, Object> target = getDao().getById(changed);
    CommonParam employee = new CommonParam();
    employee.putParam("id", target.get("employeeId"));
    employees.lockForSchedule(employee);
    CommonParam period = new CommonParam();
    period.putParam("employeeId", target.get("employeeId"));
    period.putParam("tenantId", identity.get("tenantId"));
    getDao().lockEmployeePeriods(period);
    requireManagement();
    invalidateReleaseForReopen(target, reason);
    // 保留旧反结对结月字段的明确清空；客户端分钟、租户或操作员字段不会进入更新。
    changed.putParam("closeStatus", "REOPENED");
    // 反结后快照可变，不再作为已发布本人报表。
    changed.putParam("publicationStatus", "DRAFT");
    changed.putParam("publishedAt", null);
    changed.putParam("effectiveAt", null);
    changed.putParam("closedAt", null);
    changed.putParam("closedBy", null);
    changed.putParam("reopenedAt", java.time.LocalDateTime.now());
    changed.putParam("reopenedBy", identity.get("userId"));
    changed.putParam("remark", reason);
    changed.putParam("updatedAt", java.time.LocalDateTime.now());
    super.update(changed);
    CommonParam journal = new CommonParam();
    journal.putParam("monthlyId", changed.getParam("id"));
    journal.putParam("actionType", "REOPEN");
    journal.putParam("actionComment", reason);
    journal.putParam(
        "snapshotJson",
        com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(
            java.util.Map.of("monthlyId", changed.getParam("id"), "reason", reason)));
    actionLogs.appendAction(journal);
    return buildSuccessResult(getDao().getById(changed), "月次已重开。");
  }

  /**
   * 沿用旧范围月结整批预检，所有状态和审计使用真实批次而非单条写循环。
   *
   * @param input 内部已刷新事实的范围，例如 yearMonth=2026-10、scopeType=EMPLOYEE、scopeId=8801
   * @return 实际 CommonResult，例如 data.closedCount=1、data.blockedCount=0；空范围为0
   *     异常或副作用示例：混入OPEN/CLOSED或任一日志失败，所有批次及外层刷新事务回滚。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult closeScope(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    String month;
    try {
      month = java.time.YearMonth.parse(String.valueOf(input.getParam("yearMonth"))).toString();
    } catch (java.time.format.DateTimeParseException invalidMonth) {
      throw new CommonBusinessException("ATTENDANCE_CALCULATION_INPUT_INVALID", "结月月份必须有效。");
    }
    String scopeType =
        input.getParam("scopeType") == null
            ? "ALL"
            : input.getParam("scopeType").toString().trim().toUpperCase(java.util.Locale.ROOT);
    Map<String, Object> scope = new java.util.LinkedHashMap<>();
    scope.put("tenantId", identity.get("tenantId"));
    scope.put("status", 1);
    scope.put("deletedFlag", 0);
    scope.put("yearMonth", month);
    String scopeField =
        switch (scopeType) {
          case "WORKPLACE" -> "workplaceId";
          case "DEPARTMENT" -> "departmentId";
          case "EMPLOYEE" -> "employeeId";
          default -> null;
        };
    if (scopeField != null) {
      try {
        long scopeId =
            new java.math.BigDecimal(String.valueOf(input.getParam("scopeId"))).longValueExact();
        if (scopeId <= 0) {
          throw new ArithmeticException("scope");
        }
        scope.put(scopeField, scopeId);
      } catch (NumberFormatException | ArithmeticException invalidScope) {
        throw new CommonBusinessException("ATTENDANCE_CALCULATION_INPUT_INVALID", "结月范围必须有效。");
      }
    } else if (!java.util.Set.of("ALL", "TENANT").contains(scopeType)) {
      throw new CommonBusinessException("ATTENDANCE_CALCULATION_INPUT_INVALID", "结月范围必须明确。");
    }
    java.util.List<Map<String, Object>> rows = new java.util.ArrayList<>();
    int pageNo = 1;
    com.sp.selplat.common.util.CommonPageResult page;
    do {
      page = getDao().getPageList(scope, "id asc", pageNo++, 1000);
      rows.addAll(page.getRecords());
    } while ((long) (pageNo - 1) * 1000 < page.getTotalCount());
    java.util.Set<Long> lockedEmployees = new java.util.TreeSet<>();
    for (Map<String, Object> row : rows) {
      lockedEmployees.add(((Number) row.get("employeeId")).longValue());
    }
    for (Long employeeId : lockedEmployees) {
      CommonParam key = new CommonParam();
      key.putParam("id", employeeId);
      employees.lockForSchedule(key);
    }
    rows.clear();
    pageNo = 1;
    do {
      page = getDao().getPageList(scope, "id asc", pageNo++, 1000);
      rows.addAll(page.getRecords());
    } while ((long) (pageNo - 1) * 1000 < page.getTotalCount());
    for (Map<String, Object> row : rows) {
      if (!lockedEmployees.contains(((Number) row.get("employeeId")).longValue())) {
        throw new CommonBusinessException("ATTENDANCE_PERIOD_CHANGED", "月结范围已变化，请重新查询后再结月。");
      }
    }
    requireManagement();
    // 首先整体检查，后续1001条跨两组也不能在末项阻塞时提交第一组。
    com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.closableCount(
        rows.stream().map(row -> String.valueOf(row.get("closeStatus"))).toList());
    for (Map<String, Object> row : rows) {
      if (periodProtected(row)) {
        throw protectedPeriod();
      }
    }
    if (rows.isEmpty()) {
      return buildSuccessResult(Map.of("closedCount", 0, "blockedCount", 0), "当前范围无月次。");
    }
    java.time.LocalDateTime now = java.time.LocalDateTime.now();
    java.util.List<CommonParam> updates = new java.util.ArrayList<>();
    java.util.List<CommonParam> journals = new java.util.ArrayList<>();
    for (Map<String, Object> row : rows) {
      CommonParam changed = new CommonParam();
      changed.putParam("id", row.get("id"));
      changed.putParam("tenantId", identity.get("tenantId"));
      changed.putParam("closeStatus", "CLOSED");
      changed.putParam("closedAt", now);
      changed.putParam("closedBy", identity.get("userId"));
      changed.putParam("reopenedAt", null);
      changed.putParam("reopenedBy", null);
      changed.putParam("remark", input.getParam("comment"));
      changed.putParam("updatedAt", now);
      updates.add(changed);
      CommonParam journal = new CommonParam();
      journal.putParam("monthlyId", row.get("id"));
      journal.putParam("actionType", "CLOSE");
      journal.putParam("actionComment", input.getParam("comment"));
      journal.putParam(
          "snapshotJson",
          com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(
              Map.of("yearMonth", month, "scopeType", scopeType)));
      journals.add(journal);
    }
    CommonBatchParam batch = new CommonBatchParam();
    batch.setItems(updates);
    super.updateBatch(batch);
    CommonBatchParam auditBatch = new CommonBatchParam();
    auditBatch.setItems(journals);
    actionLogs.appendActions(auditBatch);
    return buildSuccessResult(Map.of("closedCount", rows.size(), "blockedCount", 0), "范围月结已保存。");
  }

  /**
   * 本人分页只查询已发布且已生效快照，忽略请求租户、员工、状态和排序。
   *
   * @param input 筛选例如 yearMonth=2026-10、pageNo=1、pageSize=20
   * @return 真实 CommonPageResult，例如
   *     records=[{id:9301,yearMonth:2026-10,totalWorkMinutes:510}]、totalCount=1
   *     异常或副作用示例：缺精确读取许可、非法月份或读取中映射变更时拒绝，只读库。
   */
  @Override
  public CommonPageResult ownedStore(CommonPageParam input) {
    return loadOwnedStore(input, authorization.requireMonthlySelfRead(), false);
  }

  /**
   * 验证本人详情的实际归属和发布事实，缺失与他人详情使用同一错误。
   *
   * @param input 主键例如 id=9301；仅采用正整数主键
   * @return CommonResult.data 例如 id=9301、yearMonth=2026-10、totalWorkMinutes=510
   *     异常或副作用示例：草稿、未来生效、停用、异租户或撤权拒绝，无读外泄和写入。
   */
  @Override
  public CommonResult getOwned(CommonParam input) {
    return loadOwned(input, authorization.requireMonthlySelfRead(), false);
  }

  /**
   * 将数据库快照投影为本人可读字段，不能透出月结管理数据。
   *
   * @param row 实际月快照例如 id=9301、tenantId=81、totalWorkMinutes=510
   * @return 白名单 Map 例如 {id:9301,yearMonth:2026-10,totalWorkMinutes:510}，不含 tenantId，无副作用
   */
  private Map<String, Object> selfSnapshot(Map<String, Object> row) {
    Map<String, Object> result = new java.util.LinkedHashMap<>();
    for (String field :
        java.util.List.of(
            "id",
            "employeeId",
            "yearMonth",
            "publicationStatus",
            "publishedAt",
            "effectiveAt",
            "scheduledDays",
            "attendanceDays",
            "normalDays",
            "lateCount",
            "earlyLeaveCount",
            "missingPunchCount",
            "absenceCount",
            "exceptionDays",
            "totalWorkMinutes",
            "overtimeMinutes",
            "legalOvertimeMinutes",
            "nightWorkMinutes",
            "holidayWorkMinutes",
            "paidLeaveDays",
            "restDays")) {
      result.put(field, row.get(field));
    }
    return result;
  }

  /**
   * 验证真实发布时间已到，缺失或格式错误保持拒绝。
   *
   * @param value 数据库时间例如 Timestamp.valueOf("2026-10-01 08:00:00")
   * @param now 服务端当前时间例如 LocalDateTime.now()
   * @return 非空且不晚于 now 返回 true；未来或无法解析为 false，无副作用
   */
  private boolean effectiveTime(Object value, java.time.LocalDateTime now) {
    if (value == null) {
      return false;
    }
    try {
      java.time.LocalDateTime time =
          value instanceof java.time.LocalDateTime actual
              ? actual
              : java.time.LocalDateTime.parse(value.toString().replace(' ', 'T'));
      return !time.isAfter(now);
    } catch (java.time.format.DateTimeParseException invalidTime) {
      return false;
    }
  }

  /**
   * 月结果/日结果统一在员工锁和当前月行锁后拒绝已结或有效发布月份。
   *
   * @param input 内部真实范围例如employeeId=8801/workDate=2026-09-10
   *     异常或副作用示例：受保护抛ATTENDANCE_PERIOD_PROTECTED；要求正式重开，无自动改日期或状态。
   */
  @Override
  public void requireMutablePeriod(CommonParam input) {
    String month =
        input.getParam("yearMonth") != null
            ? java.time.YearMonth.parse(String.valueOf(input.getParam("yearMonth"))).toString()
            : java.time.YearMonth.from(
                    java.time.LocalDate.parse(String.valueOf(input.getParam("workDate"))))
                .toString();
    CommonParam employee = new CommonParam();
    employee.putParam("id", input.getParam("employeeId"));
    Map<?, ?> row = (Map<?, ?>) employees.lockForResult(employee).getData();
    CommonParam scope = new CommonParam();
    scope.putParam("tenantId", row.get("tenantId"));
    scope.putParam("employeeId", row.get("id"));
    for (Map<String, Object> period : getDao().lockEmployeePeriods(scope)) {
      if (month.equals(period.get("yearMonth")) && periodProtected(period)) {
        throw protectedPeriod();
      }
    }
  }

  /**
   * 关联仅读取当前管理身份下锁中的CLOSED或有效发布月份。
   *
   * @param input 服务内部employeeId=8801，客户端tenantId不生效
   * @return 实际CommonResult.data例如[{yearMonth:2026-09}]，无保护月为空列表
   *     异常或副作用示例：等待后许可撤销拒绝；保留员工和本表行锁，不写业务事实。
   */
  @Override
  public CommonResult protectedPeriods(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    CommonParam employee = new CommonParam();
    employee.putParam("id", input.getParam("employeeId"));
    employees.lockForSchedule(employee);
    input.putParam("tenantId", identity.get("tenantId"));
    return buildSuccessResult(
        getDao().lockEmployeePeriods(input).stream().filter(this::periodProtected).toList(),
        "保护月份已核验。");
  }

  /**
   * 已结始终保护，有效发布沿用本人读取的启用/时间事实。
   *
   * @param row 真实月行例如closeStatus=CLOSED或publicationStatus=PUBLISHED
   * @return CLOSED为true；未到生效时间的非CLOSED行不伪造为有效发布 异常或副作用示例：只按数据库事实判断，无状态或工时更新。
   */
  private boolean periodProtected(Map<String, Object> row) {
    java.time.LocalDateTime now = java.time.LocalDateTime.now();
    return "CLOSED".equals(row.get("closeStatus"))
        || ("PUBLISHED".equals(row.get("publicationStatus"))
            && row.get("status") instanceof Number status
            && status.intValue() == 1
            && row.get("deletedFlag") instanceof Number deleted
            && deleted.intValue() == 0
            && effectiveTime(row.get("publishedAt"), now)
            && effectiveTime(row.get("effectiveAt"), now));
  }

  /**
   * 统一要求正式重开而不替用户改月结、工资或发布状态。
   *
   * @return 明确业务异常例如ATTENDANCE_PERIOD_PROTECTED 异常或副作用示例：调用方抛出后整笔本域事务回滚，没有自动重开。
   */
  private CommonBusinessException protectedPeriod() {
    return new CommonBusinessException("ATTENDANCE_PERIOD_PROTECTED", "该月份已结或已有效发布，请先正式重开月份后再修改。");
  }

  /**
   * 独立月动作先锁真实员工再读取本月当前事实，不能绕过租户。
   *
   * @param input 能力固定id/actionCode例如9301/PUBLISH
   * @return 锁中的实际月行data，实际状态由能力预检 异常示例：等待后撤权/所属失效拒绝；外层需具名事务。
   */
  @Override
  public CommonResult lockForRelease(CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    return loadReleaseLocked(input, authorization.requireReleaseAction(action), false);
  }

  /**
   * 旧月字段仅投影当前发布；来源分钟/结月版本不在SET字段。
   *
   * @param input 内部id/actionCode与服务器时间例如9301/PUBLISH
   * @return 实际月行，发布与账本/CAS/审计/回执同外层事务 异常示例：没有独立动作拒绝，不接受HTTP直接CRUD发布。
   */
  @Override
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult markRelease(CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    if (!java.util.Set.of("PUBLISH", "WITHDRAW").contains(action)) {
      throw new CommonBusinessException("ATTENDANCE_RELEASE_ACTION_INVALID", "月发布动作必须明确。");
    }
    var identity = authorization.requireReleaseAction(action);
    lockForRelease(input);
    CommonParam row = new CommonParam();
    row.putParam("id", input.getParam("id"));
    row.putParam("tenantId", identity.get("tenantId"));
    boolean published = "PUBLISH".equals(action);
    row.putParam("publicationStatus", published ? "PUBLISHED" : "DRAFT");
    row.putParam("publishedAt", published ? input.getParam("serverTime") : null);
    row.putParam("effectiveAt", published ? input.getParam("serverTime") : null);
    super.update(row);
    return buildSuccessResult(getDao().getById(row), "月发布投影已保存。");
  }

  /**
   * 正式重开强制同事务失效账本，原管理角色未被授予独立WITHDRAW。
   *
   * @param target 已锁中的实际月行例如id=9301
   * @param reason 正式重开必填原因例如核对异常 副作用示例：清当前指针并CAS失效历史；任何失败使原reopen/审计一起回滚。
   */
  private void invalidateReleaseForReopen(Map<String, Object> target, String reason) {
    if (!releaseReady) {
      return;
    }
    CommonParam scope = new CommonParam();
    scope.putParam("actionCode", "REOPEN");
    scope.putParam("activeMonthlyId", target.get("id"));
    var publication = (Map<?, ?>) publications.findFact(scope).getData();
    if (publication != null) {
      CommonParam changed = new CommonParam();
      changed.putParam("actionCode", "REOPEN");
      changed.putParam("id", publication.get("id"));
      changed.putParam("revision", publication.get("revision"));
      changed.putParam("reason", reason);
      publications.advance(changed);
    }
    var review = (Map<?, ?>) reviews.findFact(scope).getData();
    if (review != null) {
      CommonParam changed = new CommonParam();
      changed.putParam("actionCode", "REOPEN");
      changed.putParam("id", review.get("id"));
      changed.putParam("revision", review.get("revision"));
      changed.putParam("reason", reason);
      reviews.advance(changed);
    }
  }

  /**
   * 新账本月返回同一不可变冻结投影；无账本历史的旧只读合同保持兼容。
   *
   * @param monthlyRow 当前本人实际月行例如9301/CLOSED/PUBLISHED
   * @param identity 已核验本人身份例如8101/81/8801
   * @param input 旧链接可含publicationId/publicationRevision/freezeHash，失配拒绝
   * @return 本人白名单冻结月字段和冻结指标，不透出closedBy/内部sourceJson 异常示例：撤回/重开/旧修订/映射变化拒绝；实际冻结正文未被月行替换。
   * @throws CommonBusinessException 本人月快照不可访问。
   */
  private Map<String, Object> ownedProjection(
      Map<String, Object> monthlyRow, Map<String, Long> identity, CommonParam input) {
    return ownedProjection(monthlyRow, identity, input, false);
  }

  /**
   * 正文按与冻结写入相同的UTF8 SHA256验证。
   *
   * @param payload 实际不可变正文
   * @param expected 实际发布绑定摘要
   * @return 正文未被篡改才为true，仅读取
   * @throws IllegalStateException JVM缺标准SHA256算法时失败
   */
  private boolean validFrozenPayload(String payload, String expected) {
    try {
      return expected.equals(
          java.util.HexFormat.of()
              .formatHex(
                  java.security.MessageDigest.getInstance("SHA-256")
                      .digest(payload.getBytes(java.nio.charset.StandardCharsets.UTF_8))));
    } catch (java.security.NoSuchAlgorithmException unavailable) {
      throw new IllegalStateException(unavailable);
    }
  }

  /**
   * 独立动作本租户月列表。
   *
   * @param input 分页/月及内部actionCode例如PUBLISH
   * @return 所属DAO实际分页，仅读取
   * @throws CommonBusinessException 无精确动作拒绝
   */
  @Override
  public CommonPageResult releaseStore(CommonPageParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    return loadReleaseStore(input, authorization.requireReleaseAction(action), false);
  }

  /**
   * 方法作用：共用原本人月报/指标完整过滤、投影与分页，不重算或保存
   *
   * @param input 原分页/主键，例如id9601
   * @param identity 已核本人三坐标，例如tenantId9/userId9102/employeeId7080
   * @param readOnly 服务器固定HTTP true，原桥接false
   * @return 原完整分页，例如totalCount2
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonPageResult loadOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input,
      java.util.Map<String, Long> identity,
      boolean readOnly) {
    java.time.LocalDateTime now = java.time.LocalDateTime.now();
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    // 公开月快照与月结是两种事实，关闭草稿也不可作为本人报表。
    query.put("tenantId", identity.get("tenantId"));
    query.put("employeeId", identity.get("employeeId"));
    query.put("status", 1);
    query.put("deletedFlag", 0);
    query.put("publicationStatus", "PUBLISHED");
    query.put("publishedAtLe", now);
    query.put("effectiveAtLe", now);
    Object requestedMonth = input.getParam("yearMonth");
    if (requestedMonth != null && !requestedMonth.toString().isBlank()) {
      try {
        query.put("yearMonth", java.time.YearMonth.parse(requestedMonth.toString()).toString());
      } catch (java.time.format.DateTimeParseException invalidMonth) {
        throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_INPUT_INVALID", "本人月报月份必须有效。");
      }
    }
    CommonPageResult page =
        getDao()
            .getPageList(
                query,
                "yearMonth desc, id desc",
                input.getPageNo(),
                Math.min(input.getPageSize(), 100));
    // 仅返回本人汇总字段，行政操作人、内部阻塞、组织信息不进入自助响应。
    page.setRecords(
        page.getRecords().stream()
            .map(row -> ownedProjection(row, identity, new CommonParam(), readOnly))
            .toList());
    if (!identity.equals(
        (readOnly
            ? authorization.requireReadMonthlySelf()
            : authorization.requireMonthlySelfRead()))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    return page;
  }

  /**
   * 方法作用：HTTP本人月报纯读，原绑定与月报独立许可前后核验
   *
   * @param input 原分页/主键，例如id9601/monthlyId9601
   * @return 原分页，例如两项冻结指标，不含内部sourceJson
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonPageResult readOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input) {
    var actor = authorization.requireReadMonthlySelf();
    var result = loadOwnedStore(input, actor, true);
    if (!actor.equals(authorization.requireReadMonthlySelf())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    return result;
  }

  /**
   * 方法作用：共用原本人月报/指标完整过滤、投影与分页，不重算或保存
   *
   * @param input 原分页/主键，例如id9601
   * @param identity 已核本人三坐标，例如tenantId9/userId9102/employeeId7080
   * @param readOnly 服务器固定HTTP true，原桥接false
   * @return 原完整月快照，例如totalWorkMinutes525
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonResult loadOwned(
      com.sp.selplat.common.util.CommonParam input,
      java.util.Map<String, Long> identity,
      boolean readOnly) {
    CommonParam key = new CommonParam();
    try {
      long id = new java.math.BigDecimal(String.valueOf(input.getParam("id"))).longValueExact();
      if (id <= 0) {
        throw new ArithmeticException("id");
      }
      key.putParam("id", id);
    } catch (NumberFormatException | ArithmeticException invalidId) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    key.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> row = getDao().getById(key);
    java.time.LocalDateTime now = java.time.LocalDateTime.now();
    // NULL 发布时间和未来生效不满足发布条件，不能从 CLOSED 推导发布。
    if (row == null
        || !(row.get("employeeId") instanceof Number employee)
        || employee.longValue() != identity.get("employeeId")
        || !(row.get("status") instanceof Number status)
        || status.intValue() != 1
        || !(row.get("deletedFlag") instanceof Number deleted)
        || deleted.intValue() != 0
        || !"PUBLISHED".equals(row.get("publicationStatus"))
        || !effectiveTime(row.get("publishedAt"), now)
        || !effectiveTime(row.get("effectiveAt"), now)
        || !identity.equals(
            (readOnly
                ? authorization.requireReadMonthlySelf()
                : authorization.requireMonthlySelfRead()))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    return buildSuccessResult(ownedProjection(row, identity, input, readOnly), "本人已发布月快照已读取。");
  }

  /**
   * 方法作用：HTTP本人月报纯读，原绑定与月报独立许可前后核验
   *
   * @param input 原分页/主键，例如id9601/monthlyId9601
   * @return 原本人快照，例如publicationRevision3，无管理字段
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonResult readOwned(
      com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadMonthlySelf();
    var result = loadOwned(input, actor, true);
    if (!actor.equals(authorization.requireReadMonthlySelf())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    return result;
  }

  /**
   * 方法作用：共用原冻结摘要、当前指针和白名单投影，只固定选择原/纯读来源
   *
   * @param monthlyRow 原月行，例如id9601/totalWorkMinutes999
   * @param identity 原本人三坐标，例如employeeId7080
   * @param input 原链接修订/摘要，例如publicationRevision3
   * @param readOnly 服务器固定HTTP true，原桥接false
   * @return 原不可变快照，例如totalWorkMinutes525和原items；旧无历史仍原投影
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  private Map<String, Object> ownedProjection(
      Map<String, Object> monthlyRow,
      Map<String, Long> identity,
      CommonParam input,
      boolean readOnly) {
    if (!releaseReady) {
      return selfSnapshot(monthlyRow);
    }
    CommonParam history = new CommonParam();
    history.putParam("actionCode", "READ_SELF");
    history.putParam("monthlyId", monthlyRow.get("id"));
    history.putParam("includeInactiveHistory", Boolean.TRUE);
    var facts =
        (java.util.List<?>)
            (readOnly ? reviews.readOwnedHistory(history) : reviews.scanMonthly(history)).getData();
    if (facts.isEmpty()) {
      return selfSnapshot(monthlyRow);
    }
    CommonParam current = new CommonParam();
    current.putParam("actionCode", "READ_SELF");
    current.putParam("activeMonthlyId", monthlyRow.get("id"));
    var publication =
        (Map<?, ?>)
            (readOnly ? publications.readOwnedFact(current) : publications.findFact(current))
                .getData();
    if (publication == null || !"ACTIVE".equals(publication.get("publicationStatus"))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    for (var pair :
        java.util.Map.of(
                "publicationId",
                "id",
                "publicationRevision",
                "revision",
                "freezeHash",
                "freezeHash")
            .entrySet()) {
      if (input.getParam(pair.getKey()) != null
          && !String.valueOf(input.getParam(pair.getKey()))
              .equals(String.valueOf(publication.get(pair.getValue())))) {
        throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
      }
    }
    CommonParam frozen = new CommonParam();
    frozen.putParam("actionCode", "READ_SELF");
    frozen.putParam("id", publication.get("freezeId"));
    var review =
        (Map<?, ?>) (readOnly ? reviews.readOwnedFact(frozen) : reviews.findFact(frozen)).getData();
    if (review == null
        || !"APPROVED".equals(review.get("reviewStatus"))
        || !publication.get("freezeHash").equals(review.get("freezeHash"))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    if (!validFrozenPayload(
        String.valueOf(review.get("payloadJson")), String.valueOf(publication.get("freezeHash")))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    var payload =
        com.sp.selplat.common.util.JsonUtils.fromJson(
            String.valueOf(review.get("payloadJson")),
            new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
              /* 保留原泛型协议，不改变读取或解析。 */
            });
    var frozenMonth =
        com.sp.selplat.common.util.JsonUtils.fromJson(
            com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(payload.get("monthly")),
            new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
              /* 保留原泛型协议，不改变读取或解析。 */
            });
    var value = selfSnapshot(frozenMonth);
    value.put("publicationStatus", "PUBLISHED");
    value.put("publishedAt", publication.get("publishedAt"));
    value.put("effectiveAt", publication.get("effectiveAt"));
    value.put("publicationId", publication.get("id"));
    value.put("publicationRevision", publication.get("revision"));
    value.put("freezeId", review.get("id"));
    value.put("freezeHash", review.get("freezeHash"));
    value.put("sourceVersion", review.get("sourceVersion"));
    var items =
        com.sp.selplat.common.util.JsonUtils.fromJson(
            com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(payload.get("items")),
            new com.fasterxml.jackson.core.type.TypeReference<
                java.util.List<Map<String, Object>>>() {
              /* 保留原泛型协议，不改变读取或解析。 */
            });
    value.put(
        "items",
        items.stream()
            .map(
                row -> {
                  Map<String, Object> publicItem = new java.util.LinkedHashMap<>();
                  for (String field :
                      java.util.List.of(
                          "id", "monthlyId", "itemCode", "itemName", "itemValue", "itemOrder")) {
                    publicItem.put(field, row.get(field));
                  }
                  return publicItem;
                })
            .toList());
    var checked =
        (Map<?, ?>)
            (readOnly ? publications.readOwnedFact(current) : publications.findFact(current))
                .getData();
    if (checked == null
        || !publication.get("id").equals(checked.get("id"))
        || !publication.get("revision").equals(checked.get("revision"))
        || !identity.equals(
            (readOnly
                ? authorization.requireReadMonthlySelf()
                : authorization.requireMonthlySelfRead()))) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_DENIED", "本人月快照不可访问。");
    }
    return value;
  }

  /**
   * 方法作用：共用原月报完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonPageResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原月报完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原月报完整详情和租户过滤，不重算或修改快照。
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.id61000及原完整字段
   * @throws CommonBusinessException 异校、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：按原系统查看门槛读取月报表头，不授予管理或计算许可。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns原字段配置
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "月报读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原独立月动作完整查询与结果
   *
   * @param input 原所属坐标，例如id61000/actionCodePREPARE_REVIEW
   * @param identity 原已核独立身份，例如tenantId9/userId9102
   * @param pure 服务器固定HTTP true，原public路径false
   * @return 原完整分页，原过滤/锁不替换
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private com.sp.selplat.common.util.CommonPageResult loadReleaseStore(
      com.sp.selplat.common.util.CommonPageParam input,
      java.util.Map<String, Long> identity,
      boolean pure) {
    String action = String.valueOf(input.getParam("actionCode"));
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("status", 1);
    query.put("deletedFlag", 0);
    if (input.getParam("yearMonth") != null
        && !String.valueOf(input.getParam("yearMonth")).isBlank()) {
      query.put(
          "yearMonth",
          java.time.YearMonth.parse(String.valueOf(input.getParam("yearMonth"))).toString());
    }
    var result =
        getDao()
            .getPageList(
                query,
                "yearMonth desc, id desc",
                input.getPageNo(),
                Math.min(input.getPageSize(), 100));
    if (pure) {
      authorization.requireReadReleaseAction(action);
    } else {
      authorization.requireReleaseAction(action);
    }
    return result;
  }

  /**
   * 方法作用：HTTP独立动作来源纯读，实际查询后重核同一精确许可
   *
   * @param input 内部坐标和实际动作，例如id61000/PREPARE_REVIEW
   * @return 原完整分页，只查询,无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonPageResult readReleaseStore(
      com.sp.selplat.common.util.CommonPageParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadReleaseStore(input, actor, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原独立月动作完整查询及真实锁顺序
   *
   * @param input 原所属坐标，例如id61000/actionCodePREPARE_REVIEW
   * @param identity 原已核独立身份，例如tenantId9/userId9102
   * @param pure 服务器固定HTTP true，原public路径false
   * @return 原完整来源，原过滤/锁不替换
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private com.sp.selplat.common.util.CommonResult loadReleaseLocked(
      com.sp.selplat.common.util.CommonParam input,
      java.util.Map<String, Long> identity,
      boolean pure) {
    String action = String.valueOf(input.getParam("actionCode"));
    CommonParam key = new CommonParam();
    key.putParam("tenantId", identity.get("tenantId"));
    key.putParam("id", input.getParam("id"));
    var initial = getDao().getById(key);
    if (initial == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    CommonParam employee = new CommonParam();
    employee.putParam("id", initial.get("employeeId"));
    employee.putParam("actionCode", action);
    if (pure) {
      employees.readLockForRelease(employee);
    } else {
      employees.lockForRelease(employee);
    }
    CommonParam period = new CommonParam();
    period.putParam("tenantId", identity.get("tenantId"));
    period.putParam("employeeId", initial.get("employeeId"));
    getDao().lockEmployeePeriods(period);
    var actual = getDao().getById(key);
    if (actual == null
        || !identity.equals(
            (pure
                ? authorization.requireReadReleaseAction(action)
                : authorization.requireReleaseAction(action)))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(actual, "当前月动作事实已锁定。");
  }

  /**
   * 方法作用：HTTP独立动作来源读锁，必须加入原外层事务
   *
   * @param input 内部坐标和实际动作，例如id61000/PREPARE_REVIEW
   * @return 原完整结果，只查询/持锁直到调用者事务结束,无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public com.sp.selplat.common.util.CommonResult readLockForRelease(
      com.sp.selplat.common.util.CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadReleaseLocked(input, actor, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
