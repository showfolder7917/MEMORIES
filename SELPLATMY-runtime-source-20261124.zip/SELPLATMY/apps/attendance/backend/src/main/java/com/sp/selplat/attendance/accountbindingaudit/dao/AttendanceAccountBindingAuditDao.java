package com.sp.selplat.attendance.accountbindingaudit.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;

import java.util.List;
import java.util.Map;

/** 绑定审计所属DAO仅查询自己的已核验账本，不读取账号凭据或其他表。 */
public interface AttendanceAccountBindingAuditDao extends BaseDao {
    /**
     * 判断本表是否已显式安装，缺表不建立默认数据。
     *
     * @return 真实schema内存在账本例如true，未安装false；只读metadata
     */
    boolean ready();

    /**
     * 实时读取目标账号全部不可变审计，以修订升序避免旧事务缓存。
     *
     * @param input 服务端tenantId=81/userId=8104
     * @return 实际列表例如[{revisionNo:1,actionCode:BIND}]，只读不创建审计
     */
    List<Map<String, Object>> events(CommonParam input);
}
