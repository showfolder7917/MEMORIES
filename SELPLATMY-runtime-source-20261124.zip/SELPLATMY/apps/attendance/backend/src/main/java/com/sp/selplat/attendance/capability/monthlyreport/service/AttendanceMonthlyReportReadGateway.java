/* 2026-11-01：原保存月报CSV固定只读合同。 */
package com.sp.selplat.attendance.capability.monthlyreport.service;

/** 原管理CSV导出只读边界，不含计算/发布/本人权限推导。 */
public interface AttendanceMonthlyReportReadGateway {
  /**
   * 方法作用：读取原已保存管理快照的CSV，不传递事务或写回调
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.format=CSV/原content，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult export(com.sp.selplat.common.util.CommonParam input);
}
