package com.sp.selplat.attendance.common.util.report;

import java.util.List;
import java.util.Map;

/** 只导出已计算月次快照字段，不重新取整、换算工资或将分钟变成未经确认的工资工时。 */
public final class AttendanceMonthlyCsv {
    private static final List<String> COLUMNS =
            List.of(
                    "employeeId",
                    "yearMonth",
                    "scheduledDays",
                    "attendanceDays",
                    "normalDays",
                    "lateCount",
                    "earlyLeaveCount",
                    "missingPunchCount",
                    "absenceCount",
                    "exceptionDays",
                    "totalWorkMinutes",
                    "overtimeMinutes",
                    "legalOvertimeMinutes",
                    "nightWorkMinutes",
                    "holidayWorkMinutes",
                    "paidLeaveDays",
                    "restDays",
                    "closeStatus",
                    "blockReasonCount");

    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceMonthlyCsv() {
        // 静态格式工具不保存跨请求数据。
    }

    /**
     * 将经表服务权限校验取得的月次快照导出为 UTF-8 CSV 文本，所有单元格引用并转义。
     *
     * @param snapshot 实际 AttendanceMonthly 行，例如 employeeId=8101、totalWorkMinutes=510
     * @return CSV，例如 employeeId/yearMonth 表头和一行分钟值，使用 CRLF；不包含密码、原始卡或审批快照
     * @throws IllegalArgumentException 快照为空时拒绝；此方法不查询数据库，不证明业务授权
     */
    public static String render(Map<String, Object> snapshot) {
        if (snapshot == null) {
            throw new IllegalArgumentException("月次快照不能为空");
        }
        StringBuilder content = new StringBuilder();
        appendRow(content, COLUMNS.stream().map(value -> (Object) value).toList());
        appendRow(content, COLUMNS.stream().map(snapshot::get).toList());
        return content.toString();
    }

    /**
     * 追加一行稳定列顺序的 CSV，文本中的公式前缀加单引号防止表格软件执行。
     *
     * @param content 当前文本缓冲，例如已有表头
     * @param cells 按固定列顺序的值，例如员工主键 8101、年月 2026-07 副作用示例：写入引用字符串及 CRLF，不修改原记录。
     */
    private static void appendRow(StringBuilder content, List<Object> cells) {
        for (int index = 0; index < cells.size(); index++) {
            if (index != 0) {
                content.append(',');
            }
            Object value = cells.get(index);
            String text = value == null ? "" : String.valueOf(value);
            String leading = text.stripLeading();
            if (!(value instanceof Number)
                    && !leading.isEmpty()
                    && "=+-@".indexOf(leading.charAt(0)) >= 0) {
                text = "'" + text;
            }
            content.append('"').append(text.replace("\"", "\"\"")).append('"');
        }
        content.append("\r\n");
    }
}
