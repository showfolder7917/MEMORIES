/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.attendancecase.controller;

import com.sp.selplat.attendance.attendancecase.service.AttendanceCaseService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceConfigurationReadGateway;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** AttendanceCase 查询复用共享序列化；身份、归属与授权由服务复核，通用写入始终拒绝。 */
@RestController
@RequestMapping("/api/attendance/attendancecase")
public class AttendanceCaseController extends BaseController<AttendanceCaseService> {

  /**
   * 透传建单业务参数并原样序列化完整Service结果，不能设置申请身份。
   *
   * @param input 例如attendanceDailyId=100001、caseType=PUNCH_CORRECTION
   * @return 实际JSON，例如success=true、data.caseStatus=SUBMITTED；失败由共享处理层返回
   *     异常或副作用示例：无真实权限或重复案件拒绝，写入全由所属事务完成。
   */
  @org.springframework.web.bind.annotation.PostMapping("submit.htm")
  public String submit(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(getService().submit(input));
  }

  /**
   * 透传批准/退回/驳回参数并原样序列化完整Service结果。
   *
   * @param input 例如id=100002、actionType=RETURN、comment=补充说明
   * @return 实际JSON，例如success=true、data.caseStatus=RETURNED；不拼装前端成功状态
   *     异常或副作用示例：管理配置不自动授予审批权限，失败由共享处理层返回。
   */
  @org.springframework.web.bind.annotation.PostMapping("action.htm")
  public String applyAction(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(getService().applyAction(input));
  }

  /**
   * 原样序列化审批案件分页，不在Controller构造或过滤业务记录。
   *
   * @param input 例如pageNo=1、pageSize=20
   * @return 真实分页JSON，例如records=[{id:100002}]、totalCount=1；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("reviewStore.htm")
  public String reviewStore(com.sp.selplat.common.util.CommonPageParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.reviewStore(input));
  }

  /**
   * 原样序列化真实审批案件详情，不附加管理授权。
   *
   * @param input 例如id=100002
   * @return 完整JSON，例如success=true、data.caseStatus=SUBMITTED；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("reviewDetail.htm")
  public String reviewDetail(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.reviewDetail(input));
  }

  /**
   * 原样序列化本人实际分页，由服务核验当前会话与映射。
   *
   * @param input 例如pageNo=1、pageSize=20；请求身份不授权
   * @return 实际分页JSON，例如records=[{id:100001}]、totalCount=1；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("ownedStore.htm")
  public String ownedStore(com.sp.selplat.common.util.CommonPageParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.ownedStore(input));
  }

  /**
   * 原样序列化本人详情，服务复核实际归属，不能获取他人资源。
   *
   * @param input 例如id=100001；请求employeeId=999不参与权限选择
   * @return 完整JSON，例如success=true、data.employeeId=8801；无写入
   */
  @org.springframework.web.bind.annotation.PostMapping("ownedDetail.htm")
  public String ownedDetail(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.getOwned(input));
  }

  /**
   * 完整序列化服务端差异预览，Controller不计算工资或设置审批身份。
   *
   * @param input 主键、修订和草稿例如id=9501、revision=0
   * @return 实际JSON例如success=true、data.proposed.actualWorkMinutes=525 异常或副作用示例：撤权/过期拒绝，没有业务写入。
   */
  @org.springframework.web.bind.annotation.PostMapping("preview.htm")
  public String previewAction(com.sp.selplat.common.util.CommonParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(reads.previewAction(input));
  }

  private final com.sp.selplat.attendance.attendancecase.service.AttendanceCaseReadGateway reads;

  /**
   * 方法作用：装配原案件四读取，不提供写入替代。
   *
   * @param reads Host具名原本人/审批适配，例如HTTP资格复核路径 异常或副作用示例：构造不建立角色、许可或案件。
   * @param managementReads 原管理固定网关，例如HTTP复核路径，不创建资格
   */
  public AttendanceCaseController(
      @org.springframework.beans.factory.annotation.Qualifier("attendanceCaseReadGateway")
          com.sp.selplat.attendance.attendancecase.service.AttendanceCaseReadGateway reads,
      @org.springframework.beans.factory.annotation.Qualifier("attendanceCaseManagementReadGateway")
          AttendanceConfigurationReadGateway managementReads) {
    this.reads = reads;
    this.managementReads = managementReads;
  }

  private final AttendanceConfigurationReadGateway managementReads;

  /**
   * 方法作用：保留原分页URL和GET/POST，委派固定只读网关。
   *
   * @param input 原CommonPageParam，例如pageNo1/pageSize20
   * @return 原分页JSON，不在Controller改变身份或条件
   */
  @Override
  @RequestMapping(
      value = "getStore.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getStore(input));
  }

  /**
   * 方法作用：保留原详情URL和GET/POST，权限与租户判断仍由原配置拥有方完成。
   *
   * @param input 原精确主键，例如id8501
   * @return 原CommonResult JSON，无写入
   */
  @Override
  @RequestMapping(
      value = "getById.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getById(input));
  }

  /**
   * 方法作用：保留原viewCode表头协议及默认语言。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原列配置JSON，不替换原配置来源
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "!tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumn(
      @RequestParam(name = "viewCode", defaultValue = "default") String viewCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getGridColumn(viewCode, locale));
  }

  /**
   * 方法作用：保留原tableCode响应形状，仍由原配置拥有方核实际表名。
   *
   * @param tableCode 原Grid唯一编码，例如table930001
   * @param locale 原语言，例如ja-JP
   * @return 原JSON，data中tableCode替代viewCode，无配置写入
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumnByTableCode(
      @RequestParam(name = "tableCode") String tableCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    CommonResult result = managementReads.getGridColumn(tableCode, locale);
    if (result.getData() instanceof java.util.Map<?, ?> original) {
      var data = new java.util.LinkedHashMap<String, Object>();
      original.forEach((key, value) -> data.put(String.valueOf(key), value));
      data.remove("viewCode");
      data.put("tableCode", tableCode);
      result.setData(data);
    }
    return JsonUtils.toJsonIgnoreNull(result);
  }

  /**
   * 方法作用：保留原批量POST JSON协议，仅转交同一拥有方固定读取合同
   *
   * @param input 原JSON正文，例如items含62000和62001
   * @return 原完整JSON，例如success为true且data为原批量列表，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @org.springframework.web.bind.annotation.RequestMapping(
      value = "getByIds.htm",
      method = org.springframework.web.bind.annotation.RequestMethod.POST,
      produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
  public String getByIds(
      @org.springframework.web.bind.annotation.RequestBody
          com.sp.selplat.common.util.CommonBatchParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(managementReads.getByIds(input));
  }
}
