package com.sp.selplat.attendance.capability.calculationcommand.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 计算能力只协调所属表服务，不拥有 DAO 或私有 HTTP DTO。 */
public interface AttendanceCalculationCommandService {
    /**
     * @param input employeeId 与 workDate；
     * @return 真实持久化日次快照；受保护记录拒绝，同事务更新异常与步骤。
     */
    CommonResult daily(CommonParam input);

    /**
     * @param input employeeId 与 yearMonth；
     * @return 真实持久化月次快照；已结月拒绝，同事务更新指标来源。
     */
    CommonResult monthly(CommonParam input);

    /**
     * 刷新真实业务日及月次后整批月结，服务端决定范围与审计身份。
     *
     * @param input 年月与可选范围，例如yearMonth=2026-10、scopeType=EMPLOYEE、scopeId=8801
     * @return 例如data.closedCount=1；任一阻塞全部拒绝，保留已审批日次 异常或副作用示例：缺管理配置或刷新失败时回滚；真实数据库并发验收尚待执行。
     */
    CommonResult closePeriod(CommonParam input);
}
