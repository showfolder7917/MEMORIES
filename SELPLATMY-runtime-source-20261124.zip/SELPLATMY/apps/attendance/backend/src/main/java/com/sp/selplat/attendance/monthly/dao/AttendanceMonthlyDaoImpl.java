package com.sp.selplat.attendance.monthly.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceMonthly，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceMonthlyDaoImpl extends AttendanceBaseDao implements AttendanceMonthlyDao {
    /**
     * 员工锁之后读取并锁住本表当前月状态，保留历史CLOSED行也参与保护。
     *
     * @param input 所属服务的可信范围例如tenantId=81/employeeId=8801
     * @return 真实行例如[{id:9301,yearMonth:2026-09,closeStatus:CLOSED}]
     *     异常或副作用示例：数据库异常原样传播；只锁本表，不跨表或造状态。
     */
    @Override
    public java.util.List<java.util.Map<String, Object>> lockEmployeePeriods(
            com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.queryForList(
                "SELECT * FROM AttendanceMonthly WHERE tenantId=? AND employeeId=? ORDER BY yearMonth,id FOR UPDATE",
                input.getParam("tenantId"),
                input.getParam("employeeId"));
    }
}
