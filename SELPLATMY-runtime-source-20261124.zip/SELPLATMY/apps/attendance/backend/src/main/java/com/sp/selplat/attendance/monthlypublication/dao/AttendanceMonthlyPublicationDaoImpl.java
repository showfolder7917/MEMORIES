package com.sp.selplat.attendance.monthlypublication.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** AttendanceMonthlyPublication绑定本域数据源和公共模板，差异SQL只涉及本表。 */
@Repository
public class AttendanceMonthlyPublicationDaoImpl extends AttendanceBaseDao
        implements AttendanceMonthlyPublicationDao {

    /**
     * 原子失效当前指针与发布修订，不修改被引用冻结。
     *
     * @param input 服务端id/tenant/revision和目标状态例如WITHDRAWN
     * @return 实际更新1；零行是冲突，SQL失败传播 副作用示例：发布历史保留；NULL当前指针释放复合唯一约束。
     */
    @Override
    public int compareState(com.sp.selplat.common.util.CommonParam input) {
        return new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource())
                .update(
                        "UPDATE AttendanceMonthlyPublication SET"
                            + " publicationStatus=?,activeMonthlyId=NULL,revision=revision+1,"
                            + "invalidatedBy=?,invalidatedAt=?,invalidationReason=?,updatedAt=?"
                            + " WHERE tenantId=? AND id=? AND revision=? AND"
                            + " publicationStatus='ACTIVE' AND activeMonthlyId=monthlyId",
                        input.getParam("targetState"),
                        input.getParam("actorId"),
                        input.getParam("now"),
                        input.getParam("reason"),
                        input.getParam("now"),
                        input.getParam("tenantId"),
                        input.getParam("id"),
                        input.getParam("revision"));
    }
}
