/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.monthlyactionlog.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.monthlyactionlog.dao.AttendanceMonthlyActionLogDao;
import com.sp.selplat.attendance.monthlyactionlog.service.AttendanceMonthlyActionLogService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceMonthlyActionLog 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceMonthlyActionLogServiceImpl
    extends BaseServiceImpl<AttendanceMonthlyActionLogDao>
    implements AttendanceMonthlyActionLogService {

  // 真实统一认证会话；拒绝请求自行提交租户和操作员身份。
  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  // 每次查询或内部写入重新核验本域管理授权，不把界面显示当作授权。
  @Autowired private AttendanceAuthorizationService authorization;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 原始卡和派生快照通过本域专用流程写入，不能以通用 CRUD 修改工资/工时事实。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用方抛出后无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用对应打卡、计算或审批流程。");
  }

  /**
   * 追加已由所属动作服务构造的真实审计记录，覆盖客户端操作员、角色、租户和主键。
   *
   * @param input 内部动作事实，例如 monthlyId=100001、actionType=MANUAL_RECALCULATE、actionComment=核对完成
   * @return 实际 CommonResult，例如 success=true、data.id=100001、data.operatorId=8101
   *     异常或副作用示例：缺核验权限或父记录归属外键不符时拒绝；在本域事务追加，不更新或删除旧日志。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult appendAction(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    CommonParam journal = new CommonParam();
    // 白名单只收动作服务的业务事实，所有审计身份由本次真实会话生成。
    for (String field :
        java.util.List.of("monthlyId", "actionType", "actionComment", "snapshotJson")) {
      journal.putParam(field, input.getParam(field));
    }
    if (journal.getParam("monthlyId") == null
        || journal.getParam("actionType") == null
        || journal.getParam("actionType").toString().isBlank()) {
      throw new CommonBusinessException("ATTENDANCE_AUDIT_FACT_REQUIRED", "审计关联与动作不能为空。");
    }
    journal.putParam("tenantId", identity.get("tenantId"));
    journal.putParam("operatorId", identity.get("userId"));
    journal.putParam("createdAt", java.time.LocalDateTime.now());
    return super.insert(journal);
  }

  /**
   * 将已校验月结事实预处理为本表批量参数，不循环调用单条新增。
   *
   * @param records 真实月结事实，例如 items=[{monthlyId:100001,actionType:CLOSE}]
   * @return 公共真实批量结果，例如 affectedRows=1、data[0].operatorId=8101
   *     异常或副作用示例：缺核验权限/事实/父记录时拒绝；任一数据库失败回滚全部审计。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult appendActions(CommonBatchParam records) {
    Map<String, Long> identity = requireManagement();
    java.util.List<CommonParam> prepared = new java.util.ArrayList<>();
    for (CommonParam fact : records.getItems()) {
      if (fact.getParam("monthlyId") == null || !"CLOSE".equals(fact.getParam("actionType"))) {
        throw new CommonBusinessException("ATTENDANCE_AUDIT_FACT_REQUIRED", "月结审计关联与动作必须有效。");
      }
      CommonParam journal = new CommonParam();
      for (String field :
          java.util.List.of("monthlyId", "actionType", "actionComment", "snapshotJson")) {
        journal.putParam(field, fact.getParam(field));
      }
      journal.putParam("tenantId", identity.get("tenantId"));
      journal.putParam("operatorId", identity.get("userId"));
      journal.putParam("createdAt", java.time.LocalDateTime.now());
      prepared.add(journal);
    }
    CommonBatchParam batch = new CommonBatchParam();
    batch.setItems(prepared);
    return super.insertBatch(batch);
  }

  /**
   * 来源版本只采用真实本表最后月结审计，不补造历史闭期版本。
   *
   * @param input 所属能力monthlyId/actionCode例如9301/PUBLISH
   * @return 最新真实CLOSE行data或null，没有副作用 异常示例：缺精确许可拒绝，无跨表DAO或历史审计写入。
   */
  @Override
  public CommonResult releaseSource(CommonParam input) {
    return loadReleaseSource(
        input,
        authorization.requireReleaseAction(String.valueOf(input.getParam("actionCode"))),
        false);
  }

  /**
   * 审签/发布/撤回追加真实操作者审计，不修改旧日志。
   *
   * @param input 内部monthlyId/actionCode/快照例如9301/PUBLISH
   * @return 公共super真实日志行，和尾回执同事务 异常示例：尾约束失败使指针/CAS/回执一起回滚；无新身份许可。
   */
  @Override
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult appendReleaseAction(CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    var identity = authorization.requireReleaseAction(action);
    CommonParam row = new CommonParam();
    for (String field : java.util.List.of("monthlyId", "actionComment", "snapshotJson")) {
      row.putParam(field, input.getParam(field));
    }
    row.putParam("tenantId", identity.get("tenantId"));
    row.putParam("operatorId", identity.get("userId"));
    row.putParam("actionType", action);
    return super.insert(row);
  }

  /**
   * 方法作用：共用原月操作日志完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonPageResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原月操作日志完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原月操作日志完整详情和租户过滤，不重算或修改快照。
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.id61000及原完整字段
   * @throws CommonBusinessException 异校、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：按原系统查看门槛读取月操作日志表头，不授予管理或计算许可。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns原字段配置
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "月报读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原独立月动作完整查询与结果
   *
   * @param input 原所属坐标，例如id61000/actionCodePREPARE_REVIEW
   * @param identity 原已核独立身份，例如tenantId9/userId9102
   * @param pure 服务器固定HTTP true，原public路径false
   * @return 原完整来源，原过滤/锁不替换
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private com.sp.selplat.common.util.CommonResult loadReleaseSource(
      com.sp.selplat.common.util.CommonParam input,
      java.util.Map<String, Long> identity,
      boolean pure) {
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("monthlyId", input.getParam("monthlyId"));
    query.put("actionType", "CLOSE");
    query.put("status", 1);
    query.put("deletedFlag", 0);
    var rows = getDao().getPageList(query, "id desc", 1, 1).getRecords();
    if (pure) {
      authorization.requireReadReleaseAction(String.valueOf(input.getParam("actionCode")));
    } else {
      authorization.requireReleaseAction(String.valueOf(input.getParam("actionCode")));
    }
    return buildSuccessResult(rows.isEmpty() ? null : rows.getFirst(), "真实月结来源已读取。");
  }

  /**
   * 方法作用：HTTP独立动作来源纯读，实际查询后重核同一精确许可
   *
   * @param input 内部坐标和实际动作，例如id61000/PREPARE_REVIEW
   * @return 原完整结果，只查询,无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonResult readReleaseSource(
      com.sp.selplat.common.util.CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadReleaseSource(input, actor, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
