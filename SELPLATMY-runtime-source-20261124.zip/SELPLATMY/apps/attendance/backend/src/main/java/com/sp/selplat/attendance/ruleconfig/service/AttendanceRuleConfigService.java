/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
package com.sp.selplat.attendance.ruleconfig.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceRuleConfig 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceRuleConfigService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批能力的受控字段，例如employeeId=8801、workDate=2026-10-04
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  CommonResult findForApproval(CommonParam criteria);

  /**
   * 关联写事务中锁定启用规则并永久记录曾引用事实。
   *
   * @param input 员工规则所属Service的引用例如id=8501
   * @return 实际规则CommonResult.data例如revision=0；异租户或失效拒绝，保护标志随事务回滚
   */
  CommonResult lockForReference(CommonParam input);

  /**
   * 方法作用：原审批来源纯读，前后核同一APPROVER及真实身份。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原来源结果，无匹配沿原空结果，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格撤回或身份变化拒绝旧结果
   */
  com.sp.selplat.common.util.CommonResult readFindForApproval(
      com.sp.selplat.common.util.CommonParam input);
}
