/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.caseactionlog.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceCaseActionLog 真实表服务；管理查询默认拒绝，通用写入/更新/删除不可修改审批与审计事实。 */
public interface AttendanceCaseActionLogService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 案件所属动作追加不可改写的真实审计；操作员及角色来自本次核验。
   *
   * @param input 内部事实，例如attendanceCaseId=100001、actionType=APPROVE、beforeSnapshotJson为旧状态
   * @return 实际CommonResult，例如data.operatorId=8101、data.operatorRole=APPROVER
   *     异常或副作用示例：无相应管理/本人绑定/审批配置时拒绝；外键或序列失败回滚。
   */
  CommonResult appendAction(com.sp.selplat.common.util.CommonParam input);
}
