/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/*
 * 修改记录：2026-10-09，复用月次详情原有成功Map或抛异常合同，移除重复不可达失败结果判断。
 */
package com.sp.selplat.attendance.capability.monthlyreport.service.impl;

import com.sp.selplat.attendance.capability.monthlyreport.service.AttendanceMonthlyReportService;
import com.sp.selplat.attendance.common.util.report.AttendanceMonthlyCsv;
import com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

/** 导出从真实月次表服务取值；不接受请求体伪造月次快照，不调用纯算法重算已保存结果。 */
@Service
public class AttendanceMonthlyReportServiceImpl implements AttendanceMonthlyReportService {

  private final AttendanceMonthlyService monthlyService;

  /**
   * 装配唯一月次服务。
   *
   * @param monthlyService 真实 AttendanceMonthlyServiceImpl，例如在读取前执行考勤授权检查 执行示例：后续 export
   *     复用真实月次查询，不创建替身或数据库连接。
   */
  public AttendanceMonthlyReportServiceImpl(AttendanceMonthlyService monthlyService) {
    this.monthlyService = monthlyService;
  }

  /**
   * 读取已保存月次快照导出 CSV，不采纳客户端快照或重新计算分钟。
   *
   * @param input 已保存月次主键，例如 id=100001
   * @return 真实 CommonResult，例如 data.format=CSV、data.fileName=attendance-monthly.csv、data.content
   *     为已保存指标 CSV 异常或副作用示例：例如无权访问或快照缺失拒绝；仅查询，无业务表写入。
   */
  @Override
  public CommonResult export(CommonParam input) {
    return loadExport(input, false);
  }

  /**
   * 方法作用：共用原保存月报CSV正文/编码和响应，仅选择详情读取路径
   *
   * @param input 原主键，例如61000
   * @param readOnly HTTP固定true，原桥接false，不来自请求
   * @return 原CSV CommonResult，含原fileName/mediaType/content，不重算
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonResult loadExport(CommonParam input, boolean readOnly) {
    // 原月次详情先核验权限和归属，共通详情只返回实际Map；缺失/失效原异常直接传播。
    Map<?, ?> row =
        (Map<?, ?>)
            (readOnly ? monthlyService.readById(input) : monthlyService.getById(input)).getData();
    Map<String, Object> snapshot = new LinkedHashMap<>();
    row.forEach((key, value) -> snapshot.put(String.valueOf(key), value));
    Map<String, Object> data = new LinkedHashMap<>();
    data.put("format", "CSV");
    data.put("mediaType", "text/csv;charset=UTF-8");
    data.put("fileName", "attendance-monthly.csv");
    data.put("content", AttendanceMonthlyCsv.render(snapshot));
    CommonResult result = new CommonResult();
    result.setSuccess(true);
    result.setModuleCode("attendance");
    result.setData(data);
    result.setMsg("月次快照已导出。");
    return result;
  }

  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.attendance.capability.accessconfiguration.service
          .AttendanceAuthorizationService
      authorization;

  /**
   * 方法作用：读取原保存快照并输出完整CSV，交付前重核同一管理身份
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.fileName=attendance-monthly.csv，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readExport(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadExport(input, true);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月报导出期间身份已变化。");
    }
    return result;
  }
}
