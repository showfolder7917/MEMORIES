package com.sp.selplat.attendance.accountbindingaudit.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

import java.util.List;
import java.util.Map;

/** 无HTTP CRUD入口的内部绑定审计合同，专用能力先核验精确目录及本表写权限。 */
public interface AttendanceAccountBindingAuditService
        extends com.sp.selplat.common.service.BaseService {
    /**
     * @return 真实表已安装例如true；缺表false，不执行DDL或授权
     */
    boolean ready();

    /**
     * @param userId 服务端明确账号例如8104
     * @return 本租户实际审计列表例如revisionNo1，无写入
     */
    List<Map<String, Object>> events(long userId);

    /**
     * @param input 已核验绑定事件例如revisionNo1/actionCodeBIND
     * @return 同事务实际CommonResult例如data.id=100001，失败抛出回滚，禁止生成默认许可
     */
    CommonResult append(CommonParam input);
}
