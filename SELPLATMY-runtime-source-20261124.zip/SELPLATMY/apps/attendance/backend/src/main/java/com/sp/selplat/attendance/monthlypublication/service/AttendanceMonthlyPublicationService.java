/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
package com.sp.selplat.attendance.monthlypublication.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceMonthlyPublication单表账本所属服务，HTTP只走月发布能力，不开放通用写入。 */
public interface AttendanceMonthlyPublicationService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 所属能力查询真实账本。
   *
   * @param input 内部归属/动作例如monthlyId=9301/actionCode=PUBLISH
   * @return 同租户真实记录data或null，仅读取
   */
  CommonResult findFact(CommonParam input);

  /**
   * 所属能力读取本月实际历史。
   *
   * @param input 月主键及明确动作例如monthlyId=9301/actionCode=PUBLISH
   * @return 实际记录data列表，仅读取
   */
  CommonResult scanMonthly(CommonParam input);

  /**
   * 尾端真实写入账本。
   *
   * @param input 已核验事实例如monthlyId=9301/freezeHash=64位SHA
   * @return 公共发号真实新增记录，失败回滚
   */
  CommonResult storeFact(CommonParam input);

  /**
   * CAS推进状态或失效，不改冻结内容。
   *
   * @param input 实际主键/期望修订例如id=100001/revision=0
   * @return 实际当前记录，零行冲突拒绝且回滚
   */
  CommonResult advance(CommonParam input);

  /**
   * 方法作用：本人冻结来源纯读，固定READ_SELF，不提供发布动作选择
   *
   * @param input 内部月/冻结主键，例如monthlyId9601/id9900
   * @return 原真实账本CommonResult，例如冻结正文或历史列表，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult readOwnedFact(
      com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：按原独立月动作读取真实账本，与SELF路径分开
   *
   * @param input 内部id/月/动作，例如activeMonthlyId61000/PUBLISH
   * @return 原CommonResult.data或null，完整正文不变
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readReleaseFact(
      com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：原独立月动作来源读取，保留原完整范围及分页
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readReleaseHistory(
      com.sp.selplat.common.util.CommonParam input);
}
