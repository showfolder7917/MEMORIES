package com.sp.selplat.attendance.exception.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceException，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceExceptionDaoImpl extends AttendanceBaseDao
        implements AttendanceExceptionDao { }
