package com.sp.selplat.attendance.common.util.schedule;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.LinkedHashMap;
import java.util.Map;

/** 仅展开旧排班模板日期；不推断工时、工资或补卡审批。 */
public final class AttendanceScheduleRuntime {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceScheduleRuntime() { }

    /**
     * 展开旧模板字段，跨日结束日期加一天，空时间仍为空。
     *
     * @param date 工作日期，例如 2026-10-03
     * @param template 服务端读取的模板，例如 startTime=22:00、endTime=06:00、crossDay=1
     * @param remark 备注，例如 夜班；去首尾空白，无持久化副作用
     * @return 持久化字段，例如 scheduledEndTime=2026-10-04T06:00，不重新计算应出勤分钟
     * @throws java.time.format.DateTimeParseException 无效模板时间时拒绝
     */
    public static Map<String, Object> expand(
            LocalDate date, Map<String, Object> template, String remark) {
        Map<String, Object> row = new LinkedHashMap<>();
        String start = text(template.get("startTime"));
        String end = text(template.get("endTime"));
        Object cross = template.get("crossDay");
        boolean crossDay =
                Boolean.TRUE.equals(cross) || cross instanceof Number n && n.intValue() == 1;
        row.put("scheduledStartTime", start == null ? null : date.atTime(LocalTime.parse(start)));
        row.put(
                "scheduledEndTime",
                end == null
                        ? null
                        : (crossDay ? date.plusDays(1) : date).atTime(LocalTime.parse(end)));
        row.put(
                "scheduledBreakMinutes",
                template.get("scheduledBreakMinutes") == null
                        ? 0
                        : template.get("scheduledBreakMinutes"));
        String type = text(template.get("shiftType"));
        row.put(
                "workDayType",
                type == null
                        ? "WORKDAY"
                        : switch (type) {
                            case "REST", "PAID_LEAVE", "SPECIAL_LEAVE", "ABSENCE" -> type;
                            default -> "WORKDAY";
                        });
        row.put("remark", text(remark));
        return row;
    }

    /**
     * @param value 字段值例如空串；
     * @return 去空白文本或 null，无业务状态改变。
     */
    private static String text(Object value) {
        if (value == null || value.toString().trim().isEmpty()) {
            return null;
        }
        return value.toString().trim();
    }
}
