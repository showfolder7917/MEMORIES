package com.sp.selplat.attendance.daily.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceDaily 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceDailyDao extends BaseDao {
    /**
     * 查询本表保留的规则引用，包括软删除行，保护历史参数。
     *
     * @param input 服务端租户/规则主键例如 tenantId=81、id=8501
     * @return 真实引用数量例如1；只读本表，无写入副作用
     */
    long countRuleReferences(com.sp.selplat.common.util.CommonParam input);
}
