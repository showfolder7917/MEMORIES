package com.sp.selplat.attendance.capability.calculationcommand.service.impl;

import com.sp.selplat.attendance.capability.calculationcommand.service.AttendanceCalculationCommandService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.employeeworkrule.service.AttendanceEmployeeWorkRuleService;
import com.sp.selplat.attendance.ruleconfig.service.AttendanceRuleConfigService;
import com.sp.selplat.attendance.shiftschedule.service.AttendanceShiftScheduleService;
import com.sp.selplat.attendance.punchrawlog.service.AttendancePunchRawLogService;
import com.sp.selplat.attendance.daily.service.AttendanceDailyService;
import com.sp.selplat.attendance.exception.service.AttendanceExceptionService;
import com.sp.selplat.attendance.calclog.service.AttendanceCalcLogService;
import com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService;
import com.sp.selplat.attendance.monthlyitem.service.AttendanceMonthlyItemService;
import com.sp.selplat.attendance.common.util.calculation.AttendanceDailyCalculator;
import com.sp.selplat.attendance.common.util.calculation.AttendanceMonthlyCalculator;
import com.sp.selplat.attendance.common.util.calculation.AttendanceCalculationSnapshotMapper;
import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

/** 读取真实同租户输入，沿用旧业务日筛选和日/月公式，事务写入快照及来源。 */
@Service
public class AttendanceCalculationCommandServiceImpl
        implements AttendanceCalculationCommandService {
    // 平台当前身份与管理能力入口；统一动作授权迁移前不扩大配置模型。
    private final AttendanceAuthorizationService authorizationService;
    // 员工所属服务，负责员工存在及真实租户归属。
    private final AttendanceEmployeeService employeeService;
    // 员工生效规则关联服务，不直接访问关联表 DAO。
    private final AttendanceEmployeeWorkRuleService workRuleAssignments;
    // 规则所属服务，读取已启用配置，不改变旧工时口径。
    private final AttendanceRuleConfigService ruleConfigs;
    // 排班所属服务，读取当前员工业务日的真实计划。
    private final AttendanceShiftScheduleService shiftSchedules;
    // 原始打卡所属服务，按旧业务日边界读取已处理记录。
    private final AttendancePunchRawLogService rawPunches;
    // 日次快照所属服务，执行审批和锁定保护。
    private final AttendanceDailyService dailyResults;
    // 日次异常所属服务，在同一考勤事务替换异常集合。
    private final AttendanceExceptionService dailyExceptions;
    // 计算解释日志所属服务，与日次快照原子保存。
    private final AttendanceCalcLogService calculationLogs;
    // 月次快照所属服务，保护已结月结果。
    private final AttendanceMonthlyService monthlyResults;
    // 月次指标所属服务，批量保存指标及其来源。
    private final AttendanceMonthlyItemService monthlyMetrics;

    /**
     * 装配各表所属服务，绝不跨表访问 DAO。
     *
     * @param authorizationService 当前真实管理配置
     * @param employeeService 员工表服务
     * @param workRuleAssignments 员工规则关联表服务
     * @param ruleConfigs 规则表服务
     * @param shiftSchedules 排班表服务
     * @param rawPunches 原始打卡表服务
     * @param dailyResults 日次表服务
     * @param dailyExceptions 异常表服务
     * @param calculationLogs 计算步骤表服务
     * @param monthlyResults 月次表服务
     * @param monthlyMetrics 月次指标表服务；构造不读写数据库
     */
    public AttendanceCalculationCommandServiceImpl(
            AttendanceAuthorizationService authorizationService,
            AttendanceEmployeeService employeeService,
            AttendanceEmployeeWorkRuleService workRuleAssignments,
            AttendanceRuleConfigService ruleConfigs,
            AttendanceShiftScheduleService shiftSchedules,
            AttendancePunchRawLogService rawPunches,
            AttendanceDailyService dailyResults,
            AttendanceExceptionService dailyExceptions,
            AttendanceCalcLogService calculationLogs,
            AttendanceMonthlyService monthlyResults,
            AttendanceMonthlyItemService monthlyMetrics) {
        this.authorizationService = authorizationService;
        this.employeeService = employeeService;
        this.workRuleAssignments = workRuleAssignments;
        this.ruleConfigs = ruleConfigs;
        this.shiftSchedules = shiftSchedules;
        this.rawPunches = rawPunches;
        this.dailyResults = dailyResults;
        this.dailyExceptions = dailyExceptions;
        this.calculationLogs = calculationLogs;
        this.monthlyResults = monthlyResults;
        this.monthlyMetrics = monthlyMetrics;
    }

    /**
     * 沿用旧日次公式，原子保存主快照、异常和计算步骤。
     *
     * @param input 业务参数，例如 employeeId=8801、workDate=2026-10-04；忽略客户端工时字段
     * @return 真实 CommonResult，例如 data.actualWorkMinutes=510、data.actualBreakMinutes=60
     *     异常或副作用示例：例如已审批日次拒绝重算；数据库失败回滚本域三表写入。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = Isolation.READ_COMMITTED)
    public CommonResult daily(CommonParam input) {
        authorizationService.requireManagement();
        long employeeId = requirePositiveId(input.getParam("employeeId"));
        LocalDate date;
        try {
            date = LocalDate.parse(String.valueOf(input.getParam("workDate")));
        } catch (RuntimeException invalidDate) {
            throw invalidCalculationInput();
        }
        employeeService.lockForSchedule(parameterWithField("id", employeeId));
        CommonParam period = parameterWithField("employeeId", employeeId);
        period.putParam("workDate", date);
        CommonParam scope = parameterWithField("employeeId", employeeId);
        scope.putParam("workDate", date);
        Map<String, Object> schedule = readResultRow(shiftSchedules.findScoped(scope));
        Map<String, Object> existing = readResultRow(dailyResults.findScoped(scope));
        if (com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules
                .isDailyRecalculationProtected(existing)) {
            throw new CommonBusinessException("ATTENDANCE_DAILY_PROTECTED", "审批中或已锁定日次不能重算。");
        }
        monthlyResults.requireMutablePeriod(period);
        CommonParam punchScope = parameterWithField("employeeId", employeeId);
        // 沿用旧 CAST(punch_time AS DATE)=workDate：跨日卡筛选差异须业务核准后再调整。
        punchScope.putParam("punchTimeGe", date.atStartOfDay());
        punchScope.putParam("punchTimeLt", date.plusDays(1).atStartOfDay());
        punchScope.putParam("processStatus", "PROCESSED");
        List<Map<String, Object>> punchRows = readAllScopedPages(rawPunches, punchScope);
        Map<String, Object> calculated =
                AttendanceDailyCalculator.calculateFromPunches(
                        AttendanceCalculationSnapshotMapper.scheduleForCalculation(schedule),
                        punchRows,
                        applicableRule(employeeId, date));
        CommonParam stored = parameterWithField("employeeId", employeeId);
        stored.putParam("workDate", date);
        stored.putParam("calculationResult", calculated);
        if (existing != null) {
            stored.putParam("id", existing.get("id"));
        }
        CommonResult saved = dailyResults.storeCalculated(stored);
        long dailyId = requirePositiveId(readResultRow(saved).get("id"));
        CommonParam associated = parameterWithField("employeeId", employeeId);
        associated.putParam("workDate", date);
        associated.putParam("attendanceDailyId", dailyId);
        List<CommonParam> exceptionRows = new ArrayList<>();
        for (Object value : (List<?>) calculated.get("exceptions")) {
            CommonParam record = new CommonParam();
            record.setParamMap(copyStringFields((Map<?, ?>) value));
            record.putParam("businessStatus", "OPEN");
            record.putParam("resolved", 0);
            exceptionRows.add(record);
        }
        dailyExceptions.replaceForDaily(associated, batchOfRecords(exceptionRows));
        List<CommonParam> logRows = new ArrayList<>();
        int step = 1;
        for (Object message : (List<?>) calculated.get("logs")) {
            CommonParam record = parameterWithField("triggerType", "MANUAL");
            record.putParam("calcStatus", "SUCCESS");
            record.putParam("stepName", "STEP_" + step++);
            record.putParam("stepMessage", message);
            record.putParam(
                    "payloadJson",
                    JsonUtils.toJsonIgnoreNull(
                            Map.of(
                                    "status",
                                    calculated.get("status"),
                                    "workDate",
                                    date.toString())));
            logRows.add(record);
        }
        calculationLogs.replaceForDaily(associated, batchOfRecords(logRows));
        return dailyResults.getById(parameterWithField("id", dailyId));
    }

    /**
     * 沿用旧月次取值，原子保存主快照与十五指标来源。
     *
     * @param input 业务参数，例如 employeeId=8801、yearMonth=2026-10；忽略客户端指标值
     * @return 真实 CommonResult，例如 data.totalWorkMinutes=510、data.closeStatus=OPEN 异常或副作用示例：例如 CLOSED
     *     月次拒绝重算；本域事务保存快照，不授予月结审批。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = Isolation.READ_COMMITTED)
    public CommonResult monthly(CommonParam input) {
        return calculateMonthly(input, "MANUAL_RECALCULATE");
    }

    /**
     * 为手动重算或结月前刷新复用相同公式及指标来源，触发类型由所属能力确定。
     *
     * @param input 已核验员工与年月，例如employeeId=8801、yearMonth=2026-10
     * @param trigger 服务端常量，例如PRE_CLOSE；不读取HTTP触发字段
     * @return 真实CommonResult，例如data.totalWorkMinutes=510；失败由外层事务回滚
     * @throws CommonBusinessException 已结月快照不能直接重算，请先正式重开月份。
     */
    private CommonResult calculateMonthly(CommonParam input, String trigger) {
        authorizationService.requireManagement();
        long employeeId = requirePositiveId(input.getParam("employeeId"));
        YearMonth month;
        try {
            month = YearMonth.parse(String.valueOf(input.getParam("yearMonth")));
        } catch (RuntimeException invalidMonth) {
            throw invalidCalculationInput();
        }
        Map<String, Object> employee =
                readResultRow(
                        employeeService.lockForSchedule(parameterWithField("id", employeeId)));
        CommonParam lookup = parameterWithField("employeeId", employeeId);
        lookup.putParam("yearMonth", month.toString());
        Map<String, Object> existing = readResultRow(monthlyResults.findScoped(lookup));
        if (existing != null && "CLOSED".equals(existing.get("closeStatus"))) {
            throw new CommonBusinessException("ATTENDANCE_MONTHLY_CLOSED", "已结月快照不能直接重算，请先正式重开月份。");
        }
        try {
            monthlyResults.requireMutablePeriod(lookup);
        } catch (CommonBusinessException blocked) {
            // 等待月锁后仍保留既有月重算CLOSED错误码，未有效发布的状态不会伪装为已结。
            if ("ATTENDANCE_PERIOD_PROTECTED".equals(blocked.getErrorCode())) {
                Map<String, Object> current = readResultRow(monthlyResults.findScoped(lookup));
                if (current != null && "CLOSED".equals(current.get("closeStatus"))) {
                    throw new CommonBusinessException(
                            "ATTENDANCE_MONTHLY_CLOSED", "已结月快照不能直接重算，请先正式重开月份。");
                }
            }
            throw blocked;
        }
        CommonParam dayScope = parameterWithField("employeeId", employeeId);
        dayScope.putParam("workDateGe", month.atDay(1));
        dayScope.putParam("workDateLe", month.atEndOfMonth());
        List<Map<String, Object>> dayRows =
                readAllScopedPages(dailyResults, dayScope).stream()
                        .map(AttendanceCalculationSnapshotMapper::dailyForMonthly)
                        .toList();
        Map<String, Object> aggregated =
                AttendanceMonthlyCalculator.aggregate(
                        dayRows,
                        existing == null ? "OPEN" : String.valueOf(existing.get("closeStatus")));
        CommonParam stored = new CommonParam();
        stored.setParamMap(aggregated);
        stored.putParam("employeeId", employeeId);
        stored.putParam("yearMonth", month.toString());
        stored.putParam("internalTrigger", trigger);
        stored.putParam("workplaceId", employee.get("workplaceId"));
        stored.putParam("departmentId", employee.get("departmentId"));
        if (existing != null) {
            stored.putParam("id", existing.get("id"));
        }
        CommonResult saved = monthlyResults.storeCalculated(stored);
        long monthlyId = requirePositiveId(readResultRow(saved).get("id"));
        List<CommonParam> metrics = new ArrayList<>();
        Map<?, ?> sources = (Map<?, ?>) aggregated.get("metricSources");
        String[][] definitions = {
            {"SCHEDULED_DAYS", "scheduledDays", "排班天数"},
            {"ATTENDANCE_DAYS", "attendanceDays", "出勤天数"},
            {"NORMAL_DAYS", "normalDays", "正常天数"},
            {"LATE_COUNT", "lateCount", "迟到次数"},
            {"EARLY_LEAVE_COUNT", "earlyLeaveCount", "早退次数"},
            {"MISSING_PUNCH_COUNT", "missingPunchCount", "缺卡次数"},
            {"ABSENCE_COUNT", "absenceCount", "缺勤次数"},
            {"EXCEPTION_DAYS", "exceptionDays", "异常天数"},
            {"TOTAL_WORK_MINUTES", "totalWorkMinutes", "总工时(分钟)"},
            {"OVERTIME_MINUTES", "overtimeMinutes", "残业分钟数"},
            {"LEGAL_OVERTIME_MINUTES", "legalOvertimeMinutes", "法定外残业分钟数"},
            {"NIGHT_WORK_MINUTES", "nightWorkMinutes", "深夜劳动分钟数"},
            {"HOLIDAY_WORK_MINUTES", "holidayWorkMinutes", "休日出勤分钟数"},
            {"PAID_LEAVE_DAYS", "paidLeaveDays", "有休日数"},
            {"REST_DAYS", "restDays", "休息日数"}
        };
        int order = 1;
        for (String[] definition : definitions) {
            CommonParam metric = parameterWithField("itemCode", definition[0]);
            metric.putParam("itemName", definition[2]);
            metric.putParam("itemValue", String.valueOf(aggregated.get(definition[1])));
            metric.putParam("itemOrder", order++);
            metric.putParam(
                    "sourceJson",
                    JsonUtils.toJsonIgnoreNull(
                            sources.containsKey(definition[0])
                                    ? sources.get(definition[0])
                                    : List.of()));
            metrics.add(metric);
        }
        monthlyMetrics.replaceForMonthly(
                parameterWithField("monthlyId", monthlyId), batchOfRecords(metrics));
        return monthlyResults.getById(parameterWithField("id", monthlyId));
    }

    /**
     * 按旧规则命中优先级选择生效关联；LEFT JOIN 未命中启用规则时仍保留员工规则字段。
     *
     * @param employeeId 已核验的员工
     * @param date 业务日
     * @return 原计算器规则映射或 null；不设置新的分钟默认值，不写库
     */
    private Map<String, Object> applicableRule(long employeeId, LocalDate date) {
        CommonParam query = parameterWithField("employeeId", employeeId);
        query.putParam("effectiveStartDateLe", date);
        Map<String, Object> assignment =
                readAllScopedPages(workRuleAssignments, query).stream()
                        .filter(
                                assignmentRow ->
                                        assignmentRow.get("effectiveEndDate") == null
                                                || !LocalDate.parse(
                                                                assignmentRow
                                                                        .get("effectiveEndDate")
                                                                        .toString())
                                                        .isBefore(date))
                        .max(
                                Comparator.<Map<String, Object>, String>comparing(
                                                assignmentRow ->
                                                        assignmentRow
                                                                .get("effectiveStartDate")
                                                                .toString())
                                        .thenComparingLong(
                                                assignmentRow ->
                                                        requirePositiveId(assignmentRow.get("id"))))
                        .orElse(null);
        if (assignment == null) {
            return null;
        }
        Map<String, Object> rule = new LinkedHashMap<>(assignment);
        if (assignment.get("ruleId") != null) {
            CommonParam configQuery = parameterWithField("id", assignment.get("ruleId"));
            configQuery.putParam("activeFlag", 1);
            configQuery.putParam("deletedFlag", 0);
            Map<String, Object> config = readResultRow(ruleConfigs.findScoped(configQuery));
            if (config != null) {
                for (String key :
                        List.of(
                                "ruleCode",
                                "ruleName",
                                "autoBreakEnabled",
                                "autoBreakThresholdMinutes",
                                "autoBreakDeductMinutes",
                                "nightWorkStart",
                                "nightWorkEnd",
                                "roundingUnitMinutes",
                                "roundingMode")) {
                    rule.put(key, config.get(key));
                }
            }
        }
        return rule;
    }

    /**
     * 分页读取所属服务的真实结果，不在本层访问 DAO 或重新计算工时。
     *
     * @param service Spring 注入的表所属服务，例如 AttendanceDailyService；
     * @param scope 受控查询字段；
     * @return 所有后台页原始行，不二次分页或改工时，无写入。
     */
    private static List<Map<String, Object>> readAllScopedPages(
            BaseService service, CommonParam scope) {
        List<Map<String, Object>> rows = new ArrayList<>();
        int pageNo = 1;
        CommonPageResult page;
        do {
            CommonPageParam query = new CommonPageParam();
            query.setParamMap(scope.getParamMap());
            query.setPageNo(pageNo++);
            query.setPageSize(1000);
            page = service.getStore(query);
            rows.addAll(page.getRecords());
        } while ((long) (pageNo - 1) * 1000 < page.getTotalCount());
        return rows;
    }

    /**
     * 校验业务输入必须是可精确转换的正整数，不猜测默认员工。
     *
     * @param value 业务输入主键，例如 Long 8801；
     * @return 正整数；无效值拒绝，无写入副作用。
     */
    private static long requirePositiveId(Object value) {
        try {
            long parsedId = new BigDecimal(String.valueOf(value)).longValueExact();
            if (parsedId > 0) {
                return parsedId;
            }
        } catch (RuntimeException invalidId) {
            // 不推断固定员工或操作员，无效值由下方共通参数错误拒绝。
        }
        throw invalidCalculationInput();
    }

    /**
     * 建立只包含服务端明确字段的业务参数，不复制请求身份。
     *
     * @param key 服务端受控字段名，例如 employeeId；
     * @param value 字段值；
     * @return 独立参数对象，不复制客户端身份。
     */
    private static CommonParam parameterWithField(String key, Object value) {
        CommonParam result = new CommonParam();
        result.putParam(key, value);
        return result;
    }

    /**
     * 将算法记录转换为共通批量参数，由所属服务完成真实批次写入。
     *
     * @param records 算法结果转换后的记录集合，例如一条 itemCode=TOTAL_WORK_MINUTES；
     * @return 真正批量参数，不使用单条写循环。
     */
    private static CommonBatchParam batchOfRecords(List<CommonParam> records) {
        CommonBatchParam batch = new CommonBatchParam();
        batch.setItems(records);
        return batch;
    }

    /**
     * 从完整服务结果读取数据库行；无行返回 null，不伪造默认记录。
     *
     * @param result 所属表服务结果，例如 data={id:100001,employeeId:8801}；
     * @return 字符串字段行或 null，无写入副作用。
     */
    private static Map<String, Object> readResultRow(CommonResult result) {
        return result.getData() instanceof Map<?, ?> data ? copyStringFields(data) : null;
    }

    /**
     * 转为字符串字段键并保持值不变，不改写来源对象。
     *
     * @param source 表结果或算法映射，例如 {actualWorkMinutes:510}；
     * @return 不修改原值的字段映射，无副作用。
     */
    private static Map<String, Object> copyStringFields(Map<?, ?> source) {
        Map<String, Object> result = new LinkedHashMap<>();
        source.forEach((key, value) -> result.put(String.valueOf(key), value));
        return result;
    }

    /**
     * 构建业务参数拒绝异常，不附带其他租户资源信息。
     *
     * @return 共通业务异常，例如 errorCode=ATTENDANCE_CALCULATION_INPUT_INVALID；返回对象尚未抛出。
     */
    private static CommonBusinessException invalidCalculationInput() {
        return new CommonBusinessException(
                "ATTENDANCE_CALCULATION_INPUT_INVALID", "员工与计算日期/月必须有效。");
    }

    /**
     * 沿用旧排班与PROCESSED原始卡日期并集准备日次，再聚合真实员工月份，最后整体月结。
     *
     * @param input 年月与范围，例如yearMonth=2026-10、scopeType=EMPLOYEE、scopeId=8801；忽略客户端分钟
     * @return 所属月次服务完整结果，例如data.closedCount=1、data.blockedCount=0
     *     异常或副作用示例：权限、刷新、状态、批量或日志失败回滚；已审批日次保留最终值。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = Isolation.READ_COMMITTED)
    public CommonResult closePeriod(CommonParam input) {
        authorizationService.requireManagement();
        YearMonth month;
        try {
            month = YearMonth.parse(String.valueOf(input.getParam("yearMonth")));
        } catch (java.time.format.DateTimeParseException invalidMonth) {
            throw invalidCalculationInput();
        }
        String type =
                input.getParam("scopeType") == null
                        ? "ALL"
                        : input.getParam("scopeType")
                                .toString()
                                .trim()
                                .toUpperCase(java.util.Locale.ROOT);
        if (!java.util.Set.of("ALL", "TENANT", "WORKPLACE", "DEPARTMENT", "EMPLOYEE")
                .contains(type)) {
            throw invalidCalculationInput();
        }
        Long scopeId =
                java.util.Set.of("WORKPLACE", "DEPARTMENT", "EMPLOYEE").contains(type)
                        ? requirePositiveId(input.getParam("scopeId"))
                        : null;
        CommonParam employeeScope = new CommonParam();
        // 保留旧PRE_CLOSE的范围：WORKPLACE/DEPARTMENT限制准备；EMPLOYEE只限制最后结月范围。
        if ("WORKPLACE".equals(type)) {
            employeeScope.putParam("workplaceId", scopeId);
        }
        if ("DEPARTMENT".equals(type)) {
            employeeScope.putParam("departmentId", scopeId);
        }
        java.util.Set<Long> employees = new java.util.HashSet<>();
        for (Map<String, Object> employee : readAllScopedPages(employeeService, employeeScope)) {
            employees.add(requirePositiveId(employee.get("id")));
        }
        // 所有准备员工先数值升序取得同一写入锁，避免按日期交叉锁造成多员工死锁。
        java.util.Set<Long> protectedEmployees = new java.util.HashSet<>();
        for (Long employee : new java.util.TreeSet<>(employees)) {
            employeeService.lockForSchedule(parameterWithField("id", employee));
            Object protectedData =
                    monthlyResults
                            .protectedPeriods(parameterWithField("employeeId", employee))
                            .getData();
            for (Object value : (java.util.List<?>) protectedData) {
                if (month.toString().equals(((Map<?, ?>) value).get("yearMonth"))) {
                    protectedEmployees.add(employee);
                }
            }
        }
        CommonParam dates = parameterWithField("workDateGe", month.atDay(1));
        dates.putParam("workDateLe", month.atEndOfMonth());
        java.util.Map<String, CommonParam> targets = new java.util.TreeMap<>();
        for (Map<String, Object> schedule : readAllScopedPages(shiftSchedules, dates)) {
            long employee = requirePositiveId(schedule.get("employeeId"));
            if (employees.contains(employee)) {
                String date = schedule.get("workDate").toString();
                CommonParam target = parameterWithField("employeeId", employee);
                target.putParam("workDate", date);
                targets.put(date + ":" + employee, target);
            }
        }
        CommonParam punches = parameterWithField("punchTimeGe", month.atDay(1).atStartOfDay());
        punches.putParam("punchTimeLt", month.plusMonths(1).atDay(1).atStartOfDay());
        punches.putParam("processStatus", "PROCESSED");
        for (Map<String, Object> punch : readAllScopedPages(rawPunches, punches)) {
            if (punch.get("employeeId") == null) {
                continue;
            }
            long employee = requirePositiveId(punch.get("employeeId"));
            if (employees.contains(employee)) {
                String date = String.valueOf(punch.get("punchTime")).substring(0, 10);
                CommonParam target = parameterWithField("employeeId", employee);
                target.putParam("workDate", date);
                targets.put(date + ":" + employee, target);
            }
        }
        for (CommonParam target : targets.values()) {
            if (protectedEmployees.contains(requirePositiveId(target.getParam("employeeId")))) {
                continue;
            }
            // 已受保护日次在调用事务写入前跳过，避免捕获异常后外层月结仍被标记rollback-only。
            Map<String, Object> existingDaily = readResultRow(dailyResults.findScoped(target));
            if (com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules
                    .isDailyRecalculationProtected(existingDaily)) {
                continue;
            }
            // 并发状态改变及其他写入失败继续传播，日次所属服务保留最终写入前的事实校验。
            daily(target);
        }
        java.util.Set<Long> monthEmployees = new java.util.TreeSet<>();
        for (Map<String, Object> day : readAllScopedPages(dailyResults, dates)) {
            long employee = requirePositiveId(day.get("employeeId"));
            if (employees.contains(employee)) {
                monthEmployees.add(employee);
            }
        }
        for (Long employee : monthEmployees) {
            CommonParam lookup = parameterWithField("employeeId", employee);
            lookup.putParam("yearMonth", month.toString());
            Map<String, Object> existing = readResultRow(monthlyResults.findScoped(lookup));
            // 旧预结不覆盖CLOSED，稍后的整批预检会拒绝该范围里的已结月次。
            if (!protectedEmployees.contains(employee)
                    && (existing == null || !"CLOSED".equals(existing.get("closeStatus")))) {
                calculateMonthly(lookup, "PRE_CLOSE");
            }
        }
        CommonParam closing = parameterWithField("yearMonth", month.toString());
        closing.putParam("scopeType", type);
        closing.putParam("scopeId", scopeId);
        closing.putParam("comment", input.getParam("comment"));
        return monthlyResults.closeScope(closing);
    }
}
