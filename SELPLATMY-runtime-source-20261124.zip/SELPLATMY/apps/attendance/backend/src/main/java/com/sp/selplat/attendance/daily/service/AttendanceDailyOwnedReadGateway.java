/* 2026-11-01：本人日次两查询合同，管理和写入不在此范围。 */
package com.sp.selplat.attendance.daily.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 原本人日次公开读取合同；Host只选择原桥接或本域纯读，不暴露认证锁、DAO或写命令。 */
public interface AttendanceDailyOwnedReadGateway {
  /**
   * 方法作用：读取实际绑定员工的原日次分页，不采纳客户端员工或租户范围。
   *
   * @param input 原分页和workDate，例如pageNo1/pageSize20/workDate2026-10-21
   * @return 原完整分页，例如records含id8340/employeeId7060、totalCount1
   */
  CommonPageResult ownedStore(CommonPageParam input);

  /**
   * 方法作用：读取原本人日次详情，真实归属由本域核验。
   *
   * @param input 原主键，例如id8340；employeeId请求字段不能授予权限
   * @return 原CommonResult，例如success为true/data.employeeId7060，异员工沿原拒绝
   */
  CommonResult getOwned(CommonParam input);
}
