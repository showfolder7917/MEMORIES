/* 通用人员本表持久化合同；2026-10-26。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.attendance.person.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/**
 * 复用公共CRUD，仅增加租户行锁与版本更新。
 */
public interface AttendancePersonDao extends BaseDao {

  /**
   * 方法作用：锁定真实当前租户人员，包括已停用人员以保留维护能力。
   * @param input 可信范围，例如tenantId81/id100000
   * @return 真实返回示例：本表行id100000/versionNo0；不存在为null。
   * 异常或副作用示例：没有考勤事务拒绝，不锁其他表。
   */
  Map<String, Object> lockScoped(CommonParam input);

  /**
   * 方法作用：按原版本更新资料和追加审计。
   * @param input 已规范本表列，例如id100000/tenantId81/expectedVersion0/personName小禾
   * @return 真实返回示例：1；0代表没有覆盖新版本。
   * 异常或副作用示例：编号唯一冲突由数据库拒绝，调用者事务回滚。
   */
  int updateVersion(CommonParam input);
}
