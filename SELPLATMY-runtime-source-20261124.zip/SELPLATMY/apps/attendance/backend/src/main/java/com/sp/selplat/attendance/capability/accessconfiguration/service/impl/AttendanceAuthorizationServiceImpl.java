/* 2026-11-01：原本人配置状态HTTP读取，保留原计算、独立资格与无本域事务合同。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-10-27：沿已有公开身份刷新及统一认证错误合同补齐锁后核验。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service.impl;

import com.sp.selplat.attendance.accessgrant.service.AttendanceAccessGrantService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.common.util.access.AttendanceGrantPolicy;
import com.sp.selplat.attendance.employeeaccount.service.AttendanceEmployeeAccountService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.authorization.ApplicationEntryAccess;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.util.CommonResult;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/** 消费本域VERIFIED配置及本次受角色锁保护的既有租户管理员；独立审批和月发布不继承。 */
@Service
public class AttendanceAuthorizationServiceImpl implements AttendanceAuthorizationService {

  @org.springframework.beans.factory.annotation.Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceMonthlyReleaseReady")
  private Boolean releaseReady;

  private final CurrentSessionAccess session;

  private final AttendanceAccessGrantService grants;

  private final AttendanceEmployeeAccountService accounts;

  // 只在持有原身份和角色锁的实际工作范围内补充租户管理员，不替代独立审批。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.attendance.capability.accessconfiguration.service
          .AttendanceTenantManagementExecution
      managementExecution;

  // 只读入口仍核原固定系统角色；不将本地配置当作系统开通事实。
  @org.springframework.beans.factory.annotation.Autowired
  @Qualifier("attendanceApplicationEntryAccess")
  private org.springframework.beans.factory.ObjectProvider<ApplicationEntryAccess> readEntries;

  /**
   * 注入真实会话和两个配置表服务，不持有 DAO，也不创建默认角色或映射。
   *
   * @param session Host具名attendanceCurrentSessionAccess，例如原权限桥接或真实HTTP查询
   * @param grants 本域真实授权配置服务，PUBLIC CRUD 永远默认拒绝
   * @param accounts 本域真实账号映射服务，PUBLIC CRUD 永远默认拒绝 执行示例：后续检查读取真实数据库，无配置写入副作用。
   */
  public AttendanceAuthorizationServiceImpl(
      @Qualifier("attendanceCurrentSessionAccess") CurrentSessionAccess session,
      AttendanceAccessGrantService grants,
      AttendanceEmployeeAccountService accounts) {
    this.session = session;
    this.grants = grants;
    this.accounts = accounts;
  }

  /**
   * 读取真实当前账号的配置状态，不创建授权或映射。
   *
   * @return CommonResult，例如
   *     data={userId:8101,tenantId:81,canManage:false,canApprove:false,employeeMapped:false,configurationWritable:false}
   *     异常或副作用示例：例如匿名请求抛身份错误；只查询本域两个配置表，无配置写入。
   */
  @Override
  public CommonResult currentConfiguration() {
    Map<String, Object> data = new LinkedHashMap<>(identity());
    data.put(
        "canManage",
        managementExecution.isAdministrator()
            || AttendanceGrantPolicy.allows(
                grants.findCurrentGrant("MANAGER"),
                castIdentity(data),
                "MANAGER",
                java.time.LocalDateTime.now()));
    data.put(
        "canApprove",
        AttendanceGrantPolicy.allows(
            grants.findCurrentGrant("APPROVER"),
            castIdentity(data),
            "APPROVER",
            java.time.LocalDateTime.now()));
    Map<String, Object> binding = accounts.findCurrentBinding();
    data.put("employeeMapped", AttendanceGrantPolicy.mapped(binding, castIdentity(data)));
    if (AttendanceGrantPolicy.mapped(binding, castIdentity(data))) {
      data.put("employeeId", binding.get("employeeId"));
    }
    // 新动作必须同时有真实映射与精确员工范围许可，不向已有账号自动发放。
    boolean canReadOwnMonthly = false;
    if (AttendanceGrantPolicy.mapped(binding, castIdentity(data))) {
      Map<String, Long> employeeIdentity =
          Map.of(
              "userId",
              (Long) data.get("userId"),
              "tenantId",
              (Long) data.get("tenantId"),
              "employeeId",
              ((Number) binding.get("employeeId")).longValue());
      canReadOwnMonthly =
          AttendanceGrantPolicy.allowsMonthlySelfRead(
              grants.findCurrentMonthlyReadGrant(),
              employeeIdentity,
              java.time.LocalDateTime.now());
    }
    data.put("canReadOwnMonthly", canReadOwnMonthly);
    data.put(
        "canReviewMonthly",
        releaseReady
            && AttendanceGrantPolicy.allowsRelease(
                grants.findCurrentReleaseGrant("MONTHLY_REVIEW"),
                castIdentity(data),
                "MONTHLY_REVIEW",
                java.time.LocalDateTime.now()));
    data.put(
        "canPublishMonthly",
        releaseReady
            && AttendanceGrantPolicy.allowsRelease(
                grants.findCurrentReleaseGrant("MONTHLY_PUBLISH"),
                castIdentity(data),
                "MONTHLY_PUBLISH",
                java.time.LocalDateTime.now()));
    data.put(
        "canWithdrawMonthly",
        releaseReady
            && AttendanceGrantPolicy.allowsRelease(
                grants.findCurrentReleaseGrant("MONTHLY_WITHDRAW"),
                castIdentity(data),
                "MONTHLY_WITHDRAW",
                java.time.LocalDateTime.now()));
    data.put("monthlyReleaseReady", releaseReady);
    data.put("configurationWritable", false);
    CommonResult result = new CommonResult();
    result.setSuccess(true);
    result.setModuleCode("attendance");
    result.setData(data);
    result.setMsg("考勤本人配置已读取。");
    return result;
  }

  /**
   * 验证原MANAGER配置或本次管理员持锁范围，不从名称或请求角色推断权限。
   *
   * @return 真实身份 Map，例如 {userId:8101,tenantId:81} 异常或副作用示例：例如空配置/PENDING 抛
   *     ATTENDANCE_MANAGEMENT_UNAVAILABLE，无业务写入。
   */
  @Override
  public Map<String, Long> requireManagement() {
    Map<String, Long> identity = identity();
    if (!managementExecution.protects(identity)
        && !AttendanceGrantPolicy.allows(
            grants.findCurrentGrant("MANAGER"),
            identity,
            "MANAGER",
            java.time.LocalDateTime.now())) {
      throw new CommonBusinessException("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
    }
    return identity;
  }

  /**
   * 方法作用：只读入口核真实身份与原attendance角色，拒绝读取期间换校或换号。
   *
   * @return 当前身份主键，例如userId9101/tenantId9，不建立线程写入保护
   * @throws CommonBusinessException 无角色或身份变化拒绝，不发放许可
   */
  @Override
  public Map<String, Long> requireReadIdentity() {
    var actor = identity();
    var qualified =
        AttendanceAccessGuard.requireIdentity(readEntries.getObject().requireCurrentEntry());
    if (!actor.equals(qualified) || !actor.equals(identity())) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "只读资格核验期间身份已变化。");
    }
    return actor;
  }

  /**
   * 方法作用：只读管理资格复用原管理员事实及原MANAGER配置，不冒充原持锁保护范围。
   *
   * @return 原有效身份，例如userId9102/tenantId9，不能用于写入授权
   * @throws CommonBusinessException 管理资格缺失或撤销沿原ATTENDANCE_MANAGEMENT_UNAVAILABLE拒绝，无配置写入
   */
  @Override
  public Map<String, Long> requireReadManagement() {
    var actor = requireReadIdentity();
    if (!managementExecution.isAdministrator()
        && !AttendanceGrantPolicy.allows(
            grants.findCurrentGrant("MANAGER"), actor, "MANAGER", java.time.LocalDateTime.now())) {
      throw new CommonBusinessException("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
    }
    if (!actor.equals(identity())) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "只读资格核验期间身份已变化。");
    }
    return actor;
  }

  /**
   * 验证独立审批配置，管理角色不能替代审批角色。
   *
   * @return 真实身份 Map，例如 {userId:8102,tenantId:81} 异常或副作用示例：例如只有 MANAGER 配置时抛
   *     ATTENDANCE_APPROVAL_UNAVAILABLE，无业务写入。
   */
  @Override
  public Map<String, Long> requireApproval() {
    Map<String, Long> identity = identity();
    if (!AttendanceGrantPolicy.allows(
        grants.findCurrentGrant("APPROVER"), identity, "APPROVER", java.time.LocalDateTime.now())) {
      throw new CommonBusinessException("ATTENDANCE_APPROVAL_UNAVAILABLE", "考勤审批授权尚未配置。");
    }
    return identity;
  }

  /**
   * 读取当前账号已核验的员工绑定，不假设 userId=employeeId。
   *
   * @return 真实身份 Map，例如 {userId:8101,tenantId:81,employeeId:8801} 异常或副作用示例：例如缺映射或异租户时抛
   *     ATTENDANCE_EMPLOYEE_MAPPING_REQUIRED，无写入。
   */
  @Override
  public Map<String, Long> requireEmployeeBinding() {
    Map<String, Long> identity = identity();
    Map<String, Object> binding = accounts.findCurrentBinding();
    if (!AttendanceGrantPolicy.mapped(binding, identity)
        || !(binding.get("employeeId") instanceof Number employeeId)
        || employeeId.longValue() <= 0) {
      throw new CommonBusinessException("ATTENDANCE_EMPLOYEE_MAPPING_REQUIRED", "员工账号映射尚未核验。");
    }
    return Map.of(
        "userId",
        identity.get("userId"),
        "tenantId",
        identity.get("tenantId"),
        "employeeId",
        employeeId.longValue());
  }

  /**
   * 读取本服务构建结果里的已认证身份，不接收请求 Map。
   *
   * @param data 本服务当前配置结果，含真实 userId/tenantId
   * @return 两个身份主键，例如 userId=8101、tenantId=81，无副作用
   */
  private Map<String, Long> castIdentity(Map<String, Object> data) {
    return Map.of("userId", (Long) data.get("userId"), "tenantId", (Long) data.get("tenantId"));
  }

  /**
   * @return 只由实时真实账号概要生成的 userId/tenantId；匿名抛身份错误，无写入副作用。
   */
  private Map<String, Long> identity() {
    // 管理入口也用于锁后复核，不能重用等待前的请求身份快照。
    return AttendanceAccessGuard.requireIdentity(session.revalidateCurrent());
  }

  /**
   * 读取实时员工绑定后核验精确许可，不从登录或 MANAGER 角色推断。
   *
   * @return 已核验身份例如 {userId:8101,tenantId:81,employeeId:8801} 异常或副作用示例：映射缺失或许可撤回拒绝，无任何账户授权变更。
   */
  @Override
  public Map<String, Long> requireMonthlySelfRead() {
    Map<String, Long> identity = requireEmployeeBinding();
    if (!AttendanceGrantPolicy.allowsMonthlySelfRead(
        grants.findCurrentMonthlyReadGrant(), identity, java.time.LocalDateTime.now())) {
      throw new CommonBusinessException("ATTENDANCE_MONTHLY_READ_UNAVAILABLE", "本人月报读取许可尚未核验。");
    }
    return identity;
  }

  /**
   * 独立动作在每次调用实时验证，不让MANAGER/APPROVER自动获得发布。
   *
   * @param action 内部动作例如PREPARE_REVIEW/APPROVE_REVIEW/PUBLISH/WITHDRAW
   * @return 本次真实tenant/user；不初始化身份或许可 异常示例：旧库缺账本或精确许可撤销，锁等待后也必须拒绝。
   */
  @Override
  public Map<String, Long> requireReleaseAction(String action) {
    if (!releaseReady) {
      throw new CommonBusinessException(
          "ATTENDANCE_RELEASE_NOT_INITIALIZED", "月发布账本尚未初始化，请联系管理员核验接入。");
    }
    String role =
        switch (action) {
          case "PREPARE_REVIEW", "APPROVE_REVIEW" -> "MONTHLY_REVIEW";
          case "PUBLISH" -> "MONTHLY_PUBLISH";
          case "WITHDRAW" -> "MONTHLY_WITHDRAW";
          default ->
              throw new CommonBusinessException("ATTENDANCE_RELEASE_ACTION_INVALID", "月发布动作必须明确。");
        };
    var current = identity();
    if (!AttendanceGrantPolicy.allowsRelease(
        grants.findCurrentReleaseGrant(role), current, role, java.time.LocalDateTime.now())) {
      throw new CommonBusinessException(
          "ATTENDANCE_RELEASE_PERMISSION_REQUIRED", "当前月动作的独立许可尚未配置或已失效。");
    }
    return current;
  }

  /**
   * 方法作用：以原系统角色及真实会话包住原VERIFIED绑定读取，不授予管理或写权限。
   *
   * @return 原身份和员工三坐标，例如userId9102/tenantId9/employeeId7060
   * @throws CommonBusinessException 原映射失效沿原错误；绑定核验中换校换号拒绝，无写入
   */
  @Override
  public Map<String, Long> requireReadEmployeeBinding() {
    var actor = requireReadIdentity();
    var binding = requireEmployeeBinding();
    // 绑定必须属于同一真实主体，不能混合两次身份读取。
    if (!java.util.Objects.equals(actor.get("userId"), binding.get("userId"))
        || !java.util.Objects.equals(actor.get("tenantId"), binding.get("tenantId"))
        || !actor.equals(requireReadIdentity())) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "员工绑定核验期间身份已变化。");
    }
    return binding;
  }

  /**
   * 方法作用：以原真实身份/系统角色包住原独立APPROVER政策，不沿管理员或MANAGER放行。
   *
   * @return 原身份两坐标，例如userId9102/tenantId9
   * @throws CommonBusinessException 原审批许可缺失/失效沿原错误，身份变化拒绝，无写入
   */
  @Override
  public Map<String, Long> requireReadApproval() {
    var actor = requireReadIdentity();
    var qualified = requireApproval();
    if (!actor.equals(qualified) || !actor.equals(requireReadIdentity())) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "审批读取核验期间身份已变化。");
    }
    return actor;
  }

  /**
   * 方法作用：读取原本人月报许可前后核源角色和真实主体，复用原绑定及SELF_MONTHLY_READ政策
   *
   * @return 原三坐标，例如userId9102/tenantId9/employeeId7080，无新授权
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  @Override
  public java.util.Map<String, Long> requireReadMonthlySelf() {
    var actor = requireReadIdentity();
    var own = requireMonthlySelfRead();
    if (!java.util.Objects.equals(actor.get("userId"), own.get("userId"))
        || !java.util.Objects.equals(actor.get("tenantId"), own.get("tenantId"))
        || !actor.equals(requireReadIdentity())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "本人月报核验期间身份已变化。");
    }
    return own;
  }

  /**
   * 方法作用：复用原独立动作政策并核同一源角色/身份，不创建许可
   *
   * @param action 原固定动作，例如PREPARE_REVIEW；其他原不支持动作仍拒绝
   * @return 原独立身份两坐标，例如userId9102/tenantId9
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  public java.util.Map<String, Long> requireReadReleaseAction(String action) {
    var actor = requireReadIdentity();
    var qualified = requireReleaseAction(action);
    if (!actor.equals(qualified) || !actor.equals(requireReadIdentity())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作资格核验期间身份已变化。");
    }
    return qualified;
  }

  /**
   * 方法作用：重复原完整状态计算并核同一身份及源角色，拒绝交付读取期间变化的显示资格。
   *
   * @return 原CommonResult，例如data={userId:9101,tenantId:9,canManage:false,canApprove:true,
   *     employeeMapped:false,canReadOwnMonthly:false,canReviewMonthly:false,canPublishMonthly:false,
   *     canWithdrawMonthly:false,monthlyReleaseReady:false,configurationWritable:false}。
   * @throws CommonBusinessException 原身份或系统角色失效沿原错误，状态变化拒绝；不新建事务或授予写权限
   */
  @Override
  public CommonResult readCurrentConfiguration() {
    var actor = requireReadIdentity();
    var first = currentConfiguration();
    var second = currentConfiguration();
    if (!actor.equals(requireReadIdentity())) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "本人配置读取期间身份已变化。");
    }
    if (!java.util.Objects.equals(first.getData(), second.getData())) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "本人配置读取期间资格已变化，请重新读取。");
    }
    return second;
  }
}
