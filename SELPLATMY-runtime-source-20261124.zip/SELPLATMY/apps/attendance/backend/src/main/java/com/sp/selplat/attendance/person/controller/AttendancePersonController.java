/* 通用考勤人员具名HTTP入口；2026-10-26。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.attendance.person.controller;

import com.sp.selplat.attendance.person.service.AttendancePersonService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 本接口只维护通用人员，不开放员工、签到、计费或权限写入。
 */
@RestController
@RequestMapping("/api/attendance/person")
public class AttendancePersonController {

  // 完整业务结果、租户及版本验证均由本表服务负责。
  private final AttendancePersonService service;

  /**
   * 方法作用：绑定实际人员服务。
   * @param service 实际AttendancePersonServiceImpl
   * 异常或副作用示例：仅绑定依赖，不建立默认人员。
   */
  public AttendancePersonController(AttendancePersonService service) {
    this.service = service;
  }

  /**
   * 方法作用：序列化当前租户人员页。
   * @param input 前端分页，例如pageNo1/pageSize20/personKindSTUDENT
   * @return 真实返回示例：records含id100000/personName小禾，totalCount1。
   * 异常或副作用示例：匿名或客户端租户覆盖拒绝；不公开变更历史。
   */
  @GetMapping("getStore.htm")
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(service.getStore(input));
  }

  /**
   * 方法作用：序列化当前租户精确人员详情。
   * @param input HTTP选择，例如id100000
   * @return 真实返回示例：success=true/data={id:"100000",personName:小禾,versionNo:"0"}。
   * 异常或副作用示例：无当前租户记录拒绝，不返回其他租户信息。
   */
  @GetMapping("getById.htm")
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.getById(input));
  }

  /**
   * 方法作用：序列化人员新增或版本保存结果。
   * @param input HTTP候选，例如personName小禾/personKindSTUDENT/personStateACTIVE/requestKeyUUID
   * @return 真实返回示例：success=true/data={id:"100000",versionNo:"0",replay:false}。
   * 异常或副作用示例：非法编号、旧版或异内容重试由服务拒绝，零部分保存。
   */
  @PostMapping("save.htm")
  public String save(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.save(input));
  }
}
