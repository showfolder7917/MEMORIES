package com.sp.selplat.attendance.employeeaccount.service;

import com.sp.selplat.common.service.BaseService;
import java.util.Map;

/** AttendanceEmployeeAccount 表级服务，业务授权未核准时拒绝数据读取和变更。 */
public interface AttendanceEmployeeAccountService extends BaseService {
    /**
     * 仅按真实当前会话查询已核验配置；不接受请求身份，也不配置权限。
     *
     * @return 本人本租户 VERIFIED 启用记录，例如 userId=8101；缺失返回 null 异常示例：匿名或租户失效时拒绝；无写入副作用。
     */
    Map<String, Object> findCurrentBinding();

    /**
     * 内部绑定能力在员工锁和精确目录许可核验后执行本表显式命令；通用CRUD继续拒绝。
     *
     * @param input 明确userId=8101/employeeId=8801/action=BIND/requestKey=B1/expectedRevision=0
     * @return 真实CommonResult例如data.bindingRevision=1；重复请求不追加审计，冲突及旧库缺列拒绝
     */
    com.sp.selplat.common.util.CommonResult applyBinding(
            com.sp.selplat.common.util.CommonParam input);

    /**
     * 在拥有方员工锁内核既有双向归属，不能把另一个账号的员工接管为迁移候选。
     * @param userId 已经原BIND目录核验的目标，例如8104
     * @param employeeId owning员工锁内明确候选，例如8801
     * @return 现有绑定状态例如data.bindingRevision=0；歧义拒绝，无写入
     *     异常示例：管理配置失效或已有其他活动归属拒绝，不授予目录访问。
     */
    com.sp.selplat.common.util.CommonResult migrationCandidateState(long userId, long employeeId);

    /**
     * @param userId 精确目录允许的账号例如8104
     * @return 本租户实际安全CommonResult例如data.bindingRevision=1/employeeId=8801，缺管理或审计账本拒绝，无写入
     */
    com.sp.selplat.common.util.CommonResult bindingState(long userId);
}
