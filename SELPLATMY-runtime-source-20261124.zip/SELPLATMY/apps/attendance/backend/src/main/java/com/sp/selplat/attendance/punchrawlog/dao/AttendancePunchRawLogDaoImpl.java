/* 2026-11-01：原始打卡正文读取转换本表真实CLOB，不改变导入或共享序列化。 */
package com.sp.selplat.attendance.punchrawlog.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.exception.CommonSystemException;
import com.sp.selplat.common.util.CommonPageResult;
import java.util.Map;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendancePunchRawLog，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendancePunchRawLogDaoImpl extends AttendanceBaseDao
    implements AttendancePunchRawLogDao {

  /**
   * 方法作用：复用原SQL和分页，仅把本表rawPayload的真实CLOB字符转成文本。
   *
   * @param values 原拥有方筛选，例如tenantId9/status1
   * @param orderBy 原受控排序，例如sortnum desc id asc
   * @param pageNo 实际页码，例如1
   * @param pageSize 原页大小，例如20
   * @return 原CommonPageResult，例如records=[{id:73000,rawPayload:"{}"}]、totalCount=1
   * @throws CommonSystemException 真实正文读取失败保留cause；不返回驱动对象或空成功
   */
  @Override
  public CommonPageResult getPageList(
      Map<String, Object> values, String orderBy, Integer pageNo, Integer pageSize) {
    // 原权限范围、计数和顺序保留；getByQuery及租户详情也沿此原查询入口。
    var page = super.getPageList(values, orderBy, pageNo, pageSize);
    page.setRecords(page.getRecords().stream().map(this::readBodyText).toList());
    return page;
  }

  /**
   * 方法作用：只复制本行并读取rawPayload字符，字符串、空串及null原样保留。
   *
   * @param source 原JDBC行，例如id73000/rawPayload为内容{}的Clob
   * @return 原字段副本，例如rawPayload为字符串"{}"；无行保持null
   * @throws CommonSystemException SQLException或长度溢出保留原原因，不写数据库
   */
  private Map<String, Object> readBodyText(Map<String, Object> source) {
    if (source == null) {
      return null;
    }
    var row = new java.util.LinkedHashMap<String, Object>(source);
    if (row.get("rawPayload") instanceof java.sql.Clob text) {
      try {
        // 原始正文逐字符保留，不解析、不截断、不生成替代JSON。
        row.put("rawPayload", text.getSubString(1, Math.toIntExact(text.length())));
      } catch (java.sql.SQLException | ArithmeticException failure) {
        throw new CommonSystemException(
            "ATTENDANCE_RAW_LOG_READ_FAILED", "原始打卡正文读取失败，请稍后重试。", failure);
      }
    }
    return row;
  }
}
