package com.sp.selplat.attendance.employee.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceEmployee，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceEmployeeDaoImpl extends AttendanceBaseDao implements AttendanceEmployeeDao {
    /**
     * 仅锁本表启用员工，等待后读取数据库当前已提交事实。
     *
     * @param input 服务端覆盖范围例如tenantId=81/id=8801
     * @return 实际员工行例如businessStatus=ACTIVE；不存在null，无跨表查询
     */
    @Override
    public java.util.Map<String, Object> lockForSchedule(
            com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceEmployee WHERE tenantId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.getFirst();
    }
}
