/* 2026-11-01：本人配置状态固定读取网关，无配置或权限写入口。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service;

import com.sp.selplat.common.util.CommonResult;

/** 只读取本人原完整资格状态，不接受客户端身份、角色或动态动作。 */
@FunctionalInterface
public interface AttendanceConfigurationStatusReadGateway {
  /**
   * 方法作用：选择原桥接查询或经过源角色/状态重核的本人读取。
   *
   * @return 原CommonResult，例如data.canManage=false、configurationWritable=false。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 身份、角色或配置读取期间变化拒绝，无写入
   */
  CommonResult current();
}
