/* 2026-10-29：固定能力只公开本人原请求的只读最小状态，无创建或终止写路由。 */
package com.sp.selplat.attendance.capability.employeecreatecommand.controller;

import com.sp.selplat.attendance.capability.employeecreatecommand.service.AttendanceEmployeeCreateCommandService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 统一认证/角色拦截器及原Service本人归属同时核验，不提供匿名或业务写入面。 */
@RestController
@RequestMapping("/api/attendance/employee-create-command")
public class AttendanceEmployeeCreateCommandController {
  // 仅固定能力拥有方，不访问DAO。
  private final AttendanceEmployeeCreateCommandService service;

  /**
   * 方法作用：装配原固定能力只读状态，不授权或写业务。
   *
   * @param service 固定能力原服务
   */
  public AttendanceEmployeeCreateCommandController(AttendanceEmployeeCreateCommandService service) {
    this.service = service;
  }

  /**
   * 方法作用：本人只读原键最小状态，不返回原正文、结果或写许可。
   *
   * @param input 仅原requestKey规范UUID
   * @return 实际状态CommonResult，例如PREPARED
   */
  @PostMapping("status.htm")
  public CommonResult status(CommonParam input) {
    return service.status(input);
  }
}
