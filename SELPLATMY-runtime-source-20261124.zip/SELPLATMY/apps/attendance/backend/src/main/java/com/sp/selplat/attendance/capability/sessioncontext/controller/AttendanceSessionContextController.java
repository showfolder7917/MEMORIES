/* 2026-10-27：显式保留匿名登录状态查询，业务身份及其他接口继续要求统一认证。 */
package com.sp.selplat.attendance.capability.sessioncontext.controller;

import com.sp.selplat.attendance.capability.sessioncontext.service.AttendanceSessionContextService;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.web.identity.CommonAnonymousAccess;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只序列化服务结果，业务身份与权限不在 Controller 判断。 */
@RestController
@RequestMapping("/api/attendance/session")
public class AttendanceSessionContextController {
    // 状态仅由实际会话服务读取，不接受请求中的用户或租户。
    private final AttendanceSessionContextService service;

    /**
     * 装配考勤会话服务。
     *
     * @param service 真实 AttendanceSessionContextServiceImpl 执行示例：路由调用唯一服务，无额外副作用。
     */
    public AttendanceSessionContextController(AttendanceSessionContextService service) {
        this.service = service;
    }

    /**
     * 返回当前考勤会话上下文。
     *
     * @return JSON，例如 success=true、data={userId:7,tenantId:2,canManage:false}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 未登录或账号失效，由共通处理器响应
     */
    @GetMapping("current.htm")
    public String current() {
        return JsonUtils.toJsonIgnoreNull(service.current());
    }

    /**
     * 序列化匿名可读取的实际登录状态，不将身份缺失异常误显示为服务故障。
     *
     * @return JSON，例如 {"success":true,"data":{"authenticated":false},"msg":"登录状态已读取。"}
     *     异常或副作用示例：服务故障仍交共通处理器，不开放业务权限或返回用户信息。
     */
    @CommonAnonymousAccess("仅返回实际登录状态布尔值，不开放业务身份或权限")
    @GetMapping("status.htm")
    public String status() {
        return JsonUtils.toJsonIgnoreNull(service.status());
    }
}
