/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
package com.sp.selplat.attendance.capability.monthlyrelease.controller;

import com.sp.selplat.attendance.capability.monthlyrelease.service.AttendanceMonthlyReleaseService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 所有响应原样序列化真实能力结果，Controller不赋身份/冻结/分钟/发布状态。 */
@RestController
@RequestMapping("/api/attendance/monthlyrelease")
public class AttendanceMonthlyReleaseController {

  private final AttendanceMonthlyReleaseService service;

  /**
   * 方法作用：保留原写能力并装配独立两读，不创建权限或业务。
   *
   * @param service 原真实月动作Service
   * @param reads 原具名两读网关，例如bridge或HTTP；构造无读写副作用
   */
  public AttendanceMonthlyReleaseController(
      AttendanceMonthlyReleaseService service,
      @org.springframework.beans.factory.annotation.Qualifier("attendanceMonthlyReleaseReadGateway")
          com.sp.selplat.attendance.capability.monthlyrelease.service
                  .AttendanceMonthlyReleaseReadGateway
              reads) {
    this.service = service;
    this.reads = reads;
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("getStore.htm")
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.getStore(input));
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("current.htm")
  public String current(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.current(input));
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("prepare-review.htm")
  public String prepareReview(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.prepareReview(input));
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("approve-review.htm")
  public String approveReview(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.approveReview(input));
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("publish.htm")
  public String publish(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.publish(input));
  }

  /**
   * 透传实际月动作。
   *
   * @param input 业务参数例如monthlyId=9301
   * @return 完整真实JSON，失败经共通异常层拒绝，Controller无数据写入
   */
  @PostMapping("withdraw.htm")
  public String withdraw(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.withdraw(input));
  }

  private final com.sp.selplat.attendance.capability.monthlyrelease.service
          .AttendanceMonthlyReleaseReadGateway
      reads;
}
