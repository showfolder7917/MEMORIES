package com.sp.selplat.attendance.employeeaccount.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceEmployeeAccount，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceEmployeeAccountDaoImpl extends AttendanceBaseDao
        implements AttendanceEmployeeAccountDao {
    /**
     * 真实JDBC锁中读取当前已提交账户绑定，避开事务查询缓存。
     *
     * @param input 服务端tenantId=81/userId=8101
     * @return 实际行例如bindingRevision=1；无行null，不跨表读取目录
     */
    @Override
    public java.util.Map<String, Object> lockBinding(com.sp.selplat.common.util.CommonParam input) {
        // 同用户数据库唯一键配合行锁，禁止两个员工同时接管一个活动账户。
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceEmployeeAccount WHERE tenantId=? AND userId=? FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("userId"));
        return rows.isEmpty() ? null : rows.getFirst();
    }

    /**
     * 读取同员工当前已提交活动归属；员工锁由专用能力持有。
     *
     * @param input 真实tenantId=81/employeeId=8801
     * @return 实际列表例如[{userId:8101}]，空列表表示无活动绑定，无写入
     */
    @Override
    public java.util.List<java.util.Map<String, Object>> activeOwners(
            com.sp.selplat.common.util.CommonParam input) {
        // 仅本表SQL，查询结果不得由客户端身份或名称构造。
        return new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource())
                .queryForList(
                        "SELECT * FROM AttendanceEmployeeAccount WHERE tenantId=? AND employeeId=? AND status=1 AND configurationStatus='VERIFIED'",
                        input.getParam("tenantId"),
                        input.getParam("employeeId"));
    }
}
