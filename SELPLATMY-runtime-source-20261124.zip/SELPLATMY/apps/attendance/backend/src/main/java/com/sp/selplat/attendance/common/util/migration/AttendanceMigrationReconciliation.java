package com.sp.selplat.attendance.common.util.migration;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** 对经显式迁移台账投影的纯值做逐字段对账，只返回字段名和差异原因。 不读原始数据、不访问数据库、不执行迁移、不推断租户/账号/员工主键映射或工资公式。 */
public final class AttendanceMigrationReconciliation {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceMigrationReconciliation() {
        // 无持久化状态，不记录人员数据或凭据。
    }

    /**
     * 对显式映射中的每个字段核对缺失、null 和真实数值/时间语义，并报告遗漏来源字段。
     *
     * @param sourceProjection 经核准ID台账投影的来源纯值，例如 {status:NORMAL,actual_work_minutes:510}
     * @param targetSnapshot 隔离验收目标纯值，例如 {businessStatus:NORMAL,actualWorkMinutes:510}
     * @param fieldMapping 已核准字段映射，例如 {status:businessStatus,actual_work_minutes:actualWorkMinutes}
     * @return 相同返回 []；工时不同例如
     *     [{sourceField:actual_work_minutes,targetField:actualWorkMinutes,reason:VALUE_DIFFERENCE}]
     * @throws IllegalArgumentException 任一输入缺失时拒绝；不把缺失记录当作已对账，不输出字段值
     */
    public static List<Map<String, String>> reconcile(
            Map<String, Object> sourceProjection,
            Map<String, Object> targetSnapshot,
            Map<String, String> fieldMapping) {
        if (sourceProjection == null || targetSnapshot == null || fieldMapping == null) {
            throw new IllegalArgumentException("对账需要实际投影、目标快照和明确字段映射");
        }
        List<Map<String, String>> differences = new ArrayList<>();
        // 来源遗漏字段也必须显式列出，不能以仅比较共同字段掩盖数据损失。
        for (String sourceField : sourceProjection.keySet()) {
            if (!fieldMapping.containsKey(sourceField)) {
                differences.add(difference(sourceField, "", "UNMAPPED_SOURCE_FIELD"));
            }
        }
        for (Map.Entry<String, String> mapping : fieldMapping.entrySet()) {
            String sourceField = mapping.getKey();
            String targetField = mapping.getValue();
            if (sourceField == null
                    || targetField == null
                    || sourceField.isBlank()
                    || targetField.isBlank()) {
                throw new IllegalArgumentException("字段映射名称不能为空");
            }
            if (!sourceProjection.containsKey(sourceField)) {
                differences.add(difference(sourceField, targetField, "SOURCE_FIELD_MISSING"));
            } else if (!targetSnapshot.containsKey(targetField)) {
                differences.add(difference(sourceField, targetField, "TARGET_FIELD_MISSING"));
            } else if (!sameValue(
                    sourceProjection.get(sourceField), targetSnapshot.get(targetField))) {
                differences.add(difference(sourceField, targetField, "VALUE_DIFFERENCE"));
            }
        }
        return List.copyOf(differences);
    }

    /**
     * 按明确台账键逐行对账，报告来源缺行、目标多行、重复键及逐字段差异。
     *
     * @param sources 已经核准ID台账投影的来源，例如[{tenant_id:81,id:100001,minutes:525}]
     * @param targets 实际目标快照，例如[{tenantId:81,id:100001,actualWorkMinutes:525}]
     * @param fields 已核准映射，例如{tenant_id:tenantId,id:id,minutes:actualWorkMinutes}
     * @param sourceKeyFields 明确来源复合键，例如[tenant_id,id]；不自动把员工号或账号当主键
     * @return
     *     完全一致返回[]；缺行例如[{sourceRow:1,targetRow:0,sourceField:record,targetField:record,reason:TARGET_RECORD_MISSING}]
     *     异常或副作用示例：没有完整键映射时拒绝；只返回位置和字段名，不输出人员值、不搬数据、不修改分钟。
     * @throws IllegalArgumentException 批量对账需要实际快照和明确复合键台账；台账键字段必须有明确来源及目标映射
     */
    public static List<Map<String, String>> reconcileBatch(
            List<Map<String, Object>> sources,
            List<Map<String, Object>> targets,
            Map<String, String> fields,
            List<String> sourceKeyFields) {
        if (sources == null
                || targets == null
                || fields == null
                || sourceKeyFields == null
                || sourceKeyFields.isEmpty()) {
            throw new IllegalArgumentException("批量对账需要实际快照和明确复合键台账");
        }
        // 完整键映射必须先核准；缺失不能猜测为id或默许相同租户。
        for (String field : sourceKeyFields) {
            if (field == null
                    || field.isBlank()
                    || fields.get(field) == null
                    || fields.get(field).isBlank()) {
                throw new IllegalArgumentException("台账键字段必须有明确来源及目标映射");
            }
        }
        List<Map<String, String>> differences = new ArrayList<>();
        Map<List<Object>, Integer> targetIndex = new java.util.LinkedHashMap<>();
        for (int index = 0; index < targets.size(); index++) {
            List<Object> key =
                    ledgerKey(
                            targets.get(index), sourceKeyFields.stream().map(fields::get).toList());
            if (key == null) {
                differences.add(
                        batchDifference(
                                0, index + 1, "record", "record", "TARGET_KEY_FIELD_MISSING"));
            } else if (targetIndex.putIfAbsent(key, index) != null) {
                differences.add(
                        batchDifference(0, index + 1, "record", "record", "DUPLICATE_TARGET_KEY"));
            }
        }
        java.util.Set<List<Object>> sourceKeys = new java.util.HashSet<>();
        java.util.Set<Integer> matchedTargets = new java.util.HashSet<>();
        for (int index = 0; index < sources.size(); index++) {
            List<Object> key = ledgerKey(sources.get(index), sourceKeyFields);
            if (key == null) {
                differences.add(
                        batchDifference(
                                index + 1, 0, "record", "record", "SOURCE_KEY_FIELD_MISSING"));
                continue;
            }
            if (!sourceKeys.add(key)) {
                differences.add(
                        batchDifference(index + 1, 0, "record", "record", "DUPLICATE_SOURCE_KEY"));
                continue;
            }
            Integer target = targetIndex.get(key);
            if (target == null) {
                differences.add(
                        batchDifference(index + 1, 0, "record", "record", "TARGET_RECORD_MISSING"));
                continue;
            }
            matchedTargets.add(target);
            // 逐行调用同一实际比较器，字段遗漏、null、最终工时及原始卡差异均不可忽略。
            for (Map<String, String> difference :
                    reconcile(sources.get(index), targets.get(target), fields)) {
                differences.add(
                        batchDifference(
                                index + 1,
                                target + 1,
                                difference.get("sourceField"),
                                difference.get("targetField"),
                                difference.get("reason")));
            }
        }
        // 目标额外行也阻断对账，不能仅统计成功配对而隐藏多迁/重复迁入。
        for (int index = 0; index < targets.size(); index++) {
            if (!matchedTargets.contains(index)) {
                differences.add(
                        batchDifference(0, index + 1, "record", "record", "TARGET_ONLY_RECORD"));
            }
        }
        return List.copyOf(differences);
    }

    /**
     * 核准台账键仅规范数字包装，不转换业务字符串或猜测账号/员工映射；缺键返回null。
     *
     * @return 仅规范数字包装的有序键列表；缺行、缺键或非法数字返回null。
     * @param row 来源或日次快照字段；不访问数据库。
     * @param fields 已经明确核准的复合键字段顺序。
     */
    private static List<Object> ledgerKey(Map<String, Object> row, List<String> fields) {
        if (row == null) {
            return null;
        }
        List<Object> key = new ArrayList<>();
        for (String field : fields) {
            Object value = row.get(field);
            if (value == null) {
                return null;
            }
            if (value instanceof Number number) {
                try {
                    value = new BigDecimal(number.toString()).stripTrailingZeros();
                } catch (NumberFormatException invalidNumber) {
                    return null;
                }
            }
            key.add(value);
        }
        return List.copyOf(key);
    }

    /**
     * 输出1起始行位置和差异分类；0表示无对应行，不输出台账键值或业务数据。
     *
     * @return 来源/目标行号、字段名和差异码，不含业务字段值。
     * @param source 字段来源Map；在差异报告中则为1起始来源行号，0表示无行。
     * @param target 1起始目标行号，0表示无对应行。
     * @param sourceField 来源字段名，不包含来源业务值。
     * @param targetField 目标字段名，不包含目标业务值。
     * @param reason 既有差异分类码。
     */
    private static Map<String, String> batchDifference(
            int source, int target, String sourceField, String targetField, String reason) {
        return Map.of(
                "sourceRow",
                Integer.toString(source),
                "targetRow",
                Integer.toString(target),
                "sourceField",
                sourceField,
                "targetField",
                targetField,
                "reason",
                reason);
    }

    /**
     * 只规范 JDBC 数字包装和 Timestamp 表示，不修复金额/工时差异，不转换业务字符串。
     *
     * @return 仅对数字包装和Timestamp表示规范后是否相同。
     * @param expected 待比较来源值，只规范已有JDBC数字及Timestamp表示。
     * @param actual 待比较目标值。
     */
    private static boolean sameValue(Object expected, Object actual) {
        if (expected instanceof Number && actual instanceof Number) {
            try {
                return new BigDecimal(expected.toString())
                                .compareTo(new BigDecimal(actual.toString()))
                        == 0;
            } catch (NumberFormatException invalidNumber) {
                return false;
            }
        }
        Object sourceTime = expected instanceof Timestamp time ? time.toLocalDateTime() : expected;
        Object targetTime = actual instanceof Timestamp time ? time.toLocalDateTime() : actual;
        return Objects.equals(sourceTime, targetTime);
    }

    /**
     * 输出稳定差异分类和字段名，避免把员工历史数据或凭据写入对账报告。
     *
     * @return 来源字段、目标字段和既有差异分类组成的Map。
     * @param sourceField 来源字段名，不包含来源业务值。
     * @param targetField 目标字段名，不包含目标业务值。
     * @param reason 既有差异分类码。
     */
    private static Map<String, String> difference(
            String sourceField, String targetField, String reason) {
        return Map.of("sourceField", sourceField, "targetField", targetField, "reason", reason);
    }
}
