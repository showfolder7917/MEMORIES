package com.sp.selplat.attendance.capability.accessconfiguration.controller;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceConfigurationStatusReadGateway;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 仅查询本人配置状态，无赋权、审批角色设置或映射写入接口。 */
@RestController
@RequestMapping("/api/attendance/access")
public class AttendanceAccessConfigurationController {
  private final AttendanceConfigurationStatusReadGateway service;

  /**
   * 装配真实授权能力。
   *
   * @param service 原本人配置固定读取网关，例如桥接原查询或HTTP身份读取 副作用示例：只保存服务引用，不修改用户或配置。
   */
  public AttendanceAccessConfigurationController(
      @org.springframework.beans.factory.annotation.Qualifier(
              "attendanceConfigurationStatusReadGateway")
          AttendanceConfigurationStatusReadGateway service) {
    this.service = service;
  }

  /**
   * @return 本人配置 CommonResult JSON，例如 canManage=false；匿名拒绝，无写入副作用。
   */
  @GetMapping("configuration.htm")
  public String current() {
    return JsonUtils.toJsonIgnoreNull(service.current());
  }
}
