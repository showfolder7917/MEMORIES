package com.sp.selplat.attendance.capability.accountbinding.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;

/**
 * 考勤唯一只读桥接端口，方法与owner冻结UniauthAccountDirectoryService同形。
 * owner只装配一个委托bean，禁止另造公共接口、认证DAO、权限事实或普通page兜底。
 * LIST与短选择动作必须在权威COUNT/page前裁决；目录读取不替代executeAuthorized写屏障。
 */
public interface AttendancePublicAccountDirectoryProvider {
    /**
     * 委托owner selectionPage，服务器核验真实Session/组织/完整候选集资格与许可revision。
     *
     * @param input 仅{action:BIND,pageNo:1,pageSize:20,accountIdExact:8104}，精确ID可省略
     * @return success且data={items:[五个公共字段],totalCount:1,pageNo:1,pageSize:20}
     *     异常或副作用示例：身份/范围/许可/资格/版本无法证明则拒绝；只读，无写回调。
     */
    CommonResult selectionPage(CommonParam input);

    /**
     * 委托owner按同一短动作与资格规则实时复核目标；identity必须与真实Session一致。
     *
     * @param identity 实际Session身份，例如{userId:8103,tenantId:81}，禁止请求身份
     * @param id 正整数公开账号，例如8104
     * @param action 仅BIND或UNBIND；不能传长动作或LIST当选择授权
     * @return 仅id/displayName/status/tenantId/directoryRevision五个公共字段
     *     异常或副作用示例：撤权/跨范围/版本漂移拒绝，不授予权限或读取凭据。
     */
    Map<String, Object> requireSelectionAccount(Map<String, Long> identity, long id, String action);
}
