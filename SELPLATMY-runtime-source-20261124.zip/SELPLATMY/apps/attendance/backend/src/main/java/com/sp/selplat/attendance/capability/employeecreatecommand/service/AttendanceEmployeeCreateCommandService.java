/* 2026-10-29：固定员工新增的同键请求、独立尝试和实际业务回执，不提供网络回调。 */
package com.sp.selplat.attendance.capability.employeecreatecommand.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 原employee聚合的固定命令；当前桥接实际执行，HTTP部署仍由原能力门禁拒绝。 */
public interface AttendanceEmployeeCreateCommandService
    extends com.sp.selplat.common.service.integration.EmployeeCreateAttemptOutcomeAccess {
  /**
   * 方法作用：原管理保护下新增员工，员工SQL和本次回执同事务；同键成功重放不再写员工。
   *
   * @param input 固定requestKey及原业务字段，例如employeeNo T001/employeeName林老师/employmentType FULL_TIME
   * @return 原新增CommonResult，例如data.id100000；不是权限凭证
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无权、正文冲突或旧尝试未决拒绝
   */
  CommonResult createBridge(CommonParam input);

  /**
   * 方法作用：同一本人读取原请求最小实际状态，不返回员工正文或持久原结果。
   *
   * @param input 仅原requestKey规范UUID，不接收actor
   * @return 最小状态，例如stateCode COMMITTED/employeeId100000/businessCommitted true
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名、外层事务或原键不属于本人拒绝
   */
  CommonResult status(CommonParam input);

  /**
   * 方法作用：锁原请求槽后终止指定未提交尝试；已提交则只回读，不按超时假装回滚。
   *
   * @param input 原requestKey及服务器attemptKey，不接受新状态或主键
   * @return 实际状态，例如ABORTED或COMMITTED；不授予员工创建权
   * @throws com.sp.selplat.common.exception.CommonBusinessException 旧尝试错配或身份范围变化拒绝
   */
  CommonResult abortAttempt(CommonParam input);
}
