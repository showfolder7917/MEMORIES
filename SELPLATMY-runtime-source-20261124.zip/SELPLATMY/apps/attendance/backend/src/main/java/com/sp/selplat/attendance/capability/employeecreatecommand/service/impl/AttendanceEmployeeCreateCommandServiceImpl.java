/* 2026-10-29：原员工桥接固定命令的私有请求槽、独立尝试和原子回执。 */
package com.sp.selplat.attendance.capability.employeecreatecommand.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceTenantManagementExecution;
import com.sp.selplat.attendance.capability.employeecreatecommand.service.AttendanceEmployeeCreateCommandService;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.employeecreateattempt.service.AttendanceEmployeeCreateAttemptService;
import com.sp.selplat.attendance.employeecreaterequest.service.AttendanceEmployeeCreateRequestService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.identity.LocalIdentityCommitSupport;
import com.sp.selplat.common.support.CommonHashSupport;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

/** 本employee聚合编排自己的两个私有存储及原员工Service，不读取权限表或发放HTTP写许可。 */
@Service
public class AttendanceEmployeeCreateCommandServiceImpl
    implements AttendanceEmployeeCreateCommandService {
  // 字段及长度沿原员工表，私有身份、审计、主键及尝试参数不能由正文注入。
  private static final Map<String, Integer> TEXT =
      Map.ofEntries(
          Map.entry("employeeNo", 50),
          Map.entry("employeeName", 100),
          Map.entry("employmentType", 30),
          Map.entry("employeeNameKana", 100),
          Map.entry("gender", 20),
          Map.entry("email", 100),
          Map.entry("phone", 50),
          Map.entry("businessStatus", 30));
  private static final Set<String> OTHER =
      Set.of("requestKey", "workplaceId", "departmentId", "hireDate", "resignDate", "sortnum");
  // 两个私有本表拥有方，DAO各自只访问一表。
  private final AttendanceEmployeeCreateRequestService requests;
  private final AttendanceEmployeeCreateAttemptService attempts;
  // 原员工持久化和管理保护保持其原职责，不用请求角色代替。
  private final AttendanceEmployeeService employees;
  private final AttendanceAuthorizationService authorization;
  private final AttendanceTenantManagementExecution management;
  // 原Host具名身份与部署能力，不在业务层判断URL或HTTP配置。
  private final CurrentSessionAccess identities;
  private final LocalIdentityCommitSupport localCommit;
  // 各表独立原号段和原考勤事务。
  private final TransactionTemplate transaction;
  private final TransactionTemplate business;

  /**
   * 方法作用：绑定本聚合原拥有方和考勤事务，不初始化业务或授予权限。
   *
   * @param requests 原私有请求DAO，例如AttendanceEmployeeCreateRequestServiceImpl
   * @param attempts 原私有尝试DAO，例如AttendanceEmployeeCreateAttemptServiceImpl
   * @param employees 原员工公开服务，例如AttendanceEmployeeServiceImpl
   * @param authorization 原管理资格服务
   * @param management 原真正提交保护执行器
   * @param identities Host具名attendanceCurrentSessionAccess
   * @param localCommit 原部署前提，HTTP仍拒绝本地回调
   * @param manager 原attendanceTransactionManager，不接权限库事务
   */
  public AttendanceEmployeeCreateCommandServiceImpl(
      AttendanceEmployeeCreateRequestService requests,
      AttendanceEmployeeCreateAttemptService attempts,
      AttendanceEmployeeService employees,
      AttendanceAuthorizationService authorization,
      AttendanceTenantManagementExecution management,
      @Qualifier("attendanceCurrentSessionAccess") CurrentSessionAccess identities,
      @Qualifier("attendanceLocalIdentityCommitSupport") LocalIdentityCommitSupport localCommit,
      @Qualifier("attendanceTransactionManager") PlatformTransactionManager manager) {
    this.requests = requests;
    this.attempts = attempts;
    this.employees = employees;
    this.authorization = authorization;
    this.management = management;
    this.identities = identities;
    this.localCommit = localCommit;
    transaction = new TransactionTemplate(manager);
    transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
    business = new TransactionTemplate(manager);
    business.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
    business.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
  }

  /**
   * 方法作用：先记录不可变请求与新尝试，再由原角色/管理保护原子提交员工和两表回执。
   *
   * @param input 原固定业务正文及规范UUID，例如T001/林老师/FULL_TIME
   * @return 原员工新增CommonResult，已提交重放返回原结果，不重复员工SQL
   * @throws CommonBusinessException 无部署支持、无权、正文冲突或未决拒绝，无假成功
   */
  @Override
  public CommonResult createBridge(CommonParam input) {
    outsideTransaction();
    localCommit.requireSupported();
    var actor = qualifiedActor();
    String key = key(input),
        payload = payload(input),
        hash = CommonHashSupport.sha256("ATTENDANCE_EMPLOYEE_CREATE:v1\n" + payload);
    Map<String, Object> request;
    try {
      request = transaction.execute(state -> record(actor, key, payload, hash));
    } catch (DataIntegrityViolationException conflict) {
      // 唯一约束竞争必须在失败事务退出后回读；不能在已失败连接内补造成功。
      request = transaction.execute(state -> existing(actor, key, payload, hash, true));
    }
    long requestId = number(request.get("id"));
    var selected = transaction.execute(state -> prepare(actor, key, payload, hash));
    if ("COMMITTED".equals(selected.get("stateCode"))) {
      same(actor, qualifiedActor());
      return result(selected);
    }
    if (!Boolean.TRUE.equals(selected.get("fresh"))) {
      throw failure("ATTENDANCE_EMPLOYEE_REQUEST_UNRESOLVED", "原员工新增请求仍有未决尝试，请先核对原结果。");
    }
    long attemptId = number(selected.get("id"));
    String attemptKey = String.valueOf(selected.get("attemptKey"));
    // 原管理执行器持资格到实际提交；本业务模板只加入原考勤事务，未保护HTTP不能进入。
    return management.execute(
        () ->
            business.execute(
                state -> {
                  requests.requireTransaction();
                  var locked = existing(actor, key, payload, hash, true);
                  if (number(locked.get("id")) != requestId
                      || number(locked.get("currentAttemptId")) != attemptId) {
                    throw conflict();
                  }
                  var attempt = attempts.find(actor.get("tenantId"), attemptId, true);
                  validAttempt(locked, attempt);
                  if (!"PREPARED".equals(attempt.get("stateCode"))
                      || !attemptKey.equals(attempt.get("attemptKey"))) {
                    throw conflict();
                  }
                  same(actor, qualifiedActor());
                  var values = JsonUtils.fromJson(payload, Map.class);
                  var employee = new CommonParam();
                  for (var entry : values.entrySet()) {
                    if (!(entry instanceof Map.Entry<?, ?> item)
                        || !(item.getKey() instanceof String name)) {
                      throw conflict();
                    }
                    employee.putParam(name, item.getValue());
                  }
                  var created = employees.insert(employee);
                  if (created == null
                      || !created.isSuccess()
                      || !(created.getData() instanceof Map<?, ?> data)) {
                    throw conflict();
                  }
                  long employeeId = number(data.get("id"));
                  var receipt = update(actor, attempt);
                  receipt.putParam("attemptKey", attemptKey);
                  receipt.putParam("employeeId", employeeId);
                  receipt.putParam("resultJson", JsonUtils.toJsonIgnoreNull(created));
                  receipt.putParam(
                      "receiptHash",
                      CommonHashSupport.sha256(hash + ":" + attemptKey + ":" + employeeId));
                  if (attempts.commit(receipt) != 1) {
                    throw conflict();
                  }
                  advance(actor, locked, attempt, "COMMITTED");
                  // 普通本域MANAGER和身份同样在实际提交前回源；管理员仍由原外层角色最后核验。
                  TransactionSynchronizationManager.registerSynchronization(
                      new TransactionSynchronization() {
                        /**
                         * 方法作用：本域真正提交前重核原管理资格和同一真实主体。
                         *
                         * @param readOnly 原考勤事务false
                         * @throws CommonBusinessException 提交前资格或身份变化回滚员工及回执
                         */
                        @Override
                        public void beforeCommit(boolean readOnly) {
                          same(actor, qualifiedActor());
                        }
                      });
                  return created;
                }));
  }

  /**
   * 方法作用：真实本人在独立已提交读事务中读取最小状态，不能把本事务未提交回执当结果。
   *
   * @param input 仅原requestKey，不接受正文或身份
   * @return 原真实最小状态，例如COMMITTED/employeeId100000，不返回姓名
   * @throws CommonBusinessException 身份、键、范围或外层事务错误拒绝
   */
  @Override
  public CommonResult status(CommonParam input) {
    fields(input, Set.of("requestKey"));
    outsideTransaction();
    var actor = actor();
    String key = key(input);
    return transaction.execute(
        state -> metadata(actor, requests.find(actor.get("accountId"), key, true)));
  }

  /**
   * 方法作用：同本人锁原槽并终止指定原尝试，已提交只回读，不能靠查不到回执释放保护。
   *
   * @param input 原requestKey/attemptKey，不接受新状态
   * @return 实际ABORTED或COMMITTED最小投影，无员工SQL
   * @throws CommonBusinessException 旧尝试或范围错配拒绝，状态不会倒退
   */
  @Override
  public CommonResult abortAttempt(CommonParam input) {
    fields(input, Set.of("requestKey", "attemptKey"));
    outsideTransaction();
    var actor = actor();
    String key = key(input), attemptKey = uuid(input.getParam("attemptKey"));
    return transaction.execute(
        state -> {
          var request = requests.find(actor.get("accountId"), key, true);
          own(actor, request);
          var attempt = current(actor, request, true);
          if (attempt == null || !attemptKey.equals(attempt.get("attemptKey"))) {
            throw conflict();
          }
          if ("PREPARED".equals(attempt.get("stateCode"))) {
            var row = update(actor, attempt);
            row.putParam("attemptKey", attemptKey);
            if (attempts.abort(row) != 1) {
              throw conflict();
            }
          }
          return metadata(actor, request);
        });
  }

  /**
   * 方法作用：仅可信源服务坐标在独立考勤事务中确认原历史尝试，不依赖用户Session或旧角色允许值。
   *
   * @param coordinates 源已持久绑定的完整坐标，例如学校9/请求100000/尝试100001/序号1
   * @return 实际终态，例如ABORTED/confirmedTerminal true，COMMITTED另含原员工主键及回执摘要
   * @throws CommonBusinessException 缺失、错配、未知状态或外层事务拒绝；生产无表单路由
   */
  @Override
  public CommonResult resolve(
      com.sp.selplat.common.service.integration.EmployeeCreateAttemptOutcomeAccess
              .AttemptCoordinates
          coordinates) {
    outsideTransaction();
    if (coordinates == null
        || coordinates.tenantId() <= 0
        || coordinates.userId() <= 0
        || coordinates.accountId() <= 0
        || coordinates.requestId() <= 0
        || coordinates.attemptId() <= 0
        || coordinates.attemptNo() <= 0
        || coordinates.commandHash() == null
        || !coordinates.commandHash().matches("[0-9a-f]{64}")) {
      throw conflict();
    }
    String key = uuid(coordinates.requestKey()), attemptKey = uuid(coordinates.attemptKey());
    var owner =
        Map.of(
            "tenantId",
            coordinates.tenantId(),
            "userId",
            coordinates.userId(),
            "accountId",
            coordinates.accountId());
    // 服务间坐标只定位，不授权新业务；所有结论仍来自原槽锁及原持久尝试。
    return transaction.execute(
        state -> {
          var request = requests.find(coordinates.accountId(), key, true);
          own(owner, request);
          if (number(request.get("id")) != coordinates.requestId()
              || !coordinates.commandHash().equals(request.get("commandHash"))) {
            throw conflict();
          }
          var attempt = attempts.find(coordinates.tenantId(), coordinates.attemptId(), true);
          if (attempt == null
              || number(attempt.get("requestId")) != coordinates.requestId()
              || number(attempt.get("attemptNo")) != coordinates.attemptNo()
              || !attemptKey.equals(attempt.get("attemptKey"))) {
            throw conflict();
          }
          String outcome = String.valueOf(attempt.get("stateCode"));
          if ("PREPARED".equals(outcome)) {
            // 仅仍为当前尝试的原PREPARED可终止；同锁下使迟到原执行永久拒绝。
            if (number(request.get("currentAttemptId")) != coordinates.attemptId()) {
              throw conflict();
            }
            validAttempt(request, attempt);
            var update = update(owner, attempt);
            update.putParam("attemptKey", attemptKey);
            if (attempts.abort(update) != 1) {
              throw conflict();
            }
            attempt = attempts.find(coordinates.tenantId(), coordinates.attemptId(), true);
            outcome = String.valueOf(attempt.get("stateCode"));
          }
          if (!Set.of("ABORTED", "COMMITTED").contains(outcome)) {
            throw conflict();
          }
          var data = new LinkedHashMap<String, Object>();
          data.put("protocolVersion", "1");
          data.put("clientCode", "attendance");
          data.put("commandCode", "ATTENDANCE_EMPLOYEE_CREATE");
          data.put("requestKey", key);
          data.put("commandHash", coordinates.commandHash());
          owner.forEach((name, value) -> data.put(name, value.toString()));
          data.put("requestId", Long.toString(coordinates.requestId()));
          data.put("attemptId", Long.toString(coordinates.attemptId()));
          data.put("attemptKey", attemptKey);
          data.put("attemptNo", Long.toString(coordinates.attemptNo()));
          data.put("stateCode", outcome);
          data.put("confirmedTerminal", true);
          data.put("permissionGranted", false);
          data.put("businessCommitted", "COMMITTED".equals(outcome));
          if ("COMMITTED".equals(outcome)) {
            if (number(request.get("currentAttemptId")) != coordinates.attemptId()) {
              throw conflict();
            }
            validAttempt(request, attempt);
            long employee = number(attempt.get("employeeId"));
            String receipt =
                CommonHashSupport.sha256(
                    coordinates.commandHash() + ":" + attemptKey + ":" + employee);
            if (!receipt.equals(attempt.get("receiptHash")) || !result(attempt).isSuccess()) {
              throw conflict();
            }
            data.put("employeeId", Long.toString(employee));
            data.put("receiptHash", receipt);
          }
          var result = new CommonResult();
          result.setSuccess(true);
          result.setData(data);
          return result;
        });
  }

  /**
   * 方法作用：独立事务记录固定正文，原键换学校、成员或正文均拒绝。
   *
   * @param actor 原真实三主键，例如9/9101/9101
   * @param key 原UUID
   * @param payload 原规范业务JSON，不记录日志
   * @param hash 原版本摘要
   * @return 原私有请求行，例如RECORDED
   */
  private Map<String, Object> record(
      Map<String, Long> actor, String key, String payload, String hash) {
    var old = requests.find(actor.get("accountId"), key, true);
    if (old != null) {
      return existing(actor, key, payload, hash, true);
    }
    var row = new CommonParam();
    row.putParam("id", requests.newId());
    actor.forEach(row::putParam);
    row.putParam("lastOperateUserId", actor.get("userId"));
    row.putParam("requestKey", key);
    row.putParam("payloadJson", payload);
    row.putParam("commandHash", hash);
    if (requests.insert(row) != 1) {
      throw conflict();
    }
    same(actor, qualifiedActor());
    return existing(actor, key, payload, hash, true);
  }

  /**
   * 方法作用：请求槽锁内创建独立新尝试；已有PREPARED不重执行，旧历史不覆盖。
   *
   * @param actor 原真实主体
   * @param key 原UUID
   * @param payload 原规范正文
   * @param hash 原摘要
   * @return 实际尝试及本次fresh标志，例如PREPARED/fresh true
   */
  private Map<String, Object> prepare(
      Map<String, Long> actor, String key, String payload, String hash) {
    same(actor, qualifiedActor());
    var request = existing(actor, key, payload, hash, true);
    var old = current(actor, request, true);
    if (old != null && !"ABORTED".equals(old.get("stateCode"))) {
      var copy = new LinkedHashMap<>(old);
      copy.put("fresh", false);
      return copy;
    }
    if (!"RECORDED".equals(request.get("stateCode"))) {
      throw conflict();
    }
    var row = new CommonParam();
    row.putParam("id", attempts.newId());
    row.putParam("tenantId", actor.get("tenantId"));
    row.putParam("lastOperateUserId", actor.get("userId"));
    row.putParam("requestId", request.get("id"));
    row.putParam("attemptNo", Math.addExact(numberOrZero(request.get("attemptNo")), 1));
    row.putParam("attemptKey", UUID.randomUUID().toString());
    if (attempts.insert(row) != 1) {
      throw conflict();
    }
    var created = attempts.find(actor.get("tenantId"), number(row.getParam("id")), true);
    advance(actor, request, created, "RECORDED");
    var copy = new LinkedHashMap<>(created);
    copy.put("fresh", true);
    return copy;
  }

  /**
   * 方法作用：只经本表原键回读并核不可变正文与真实本人。
   *
   * @param actor 原真实主体
   * @param key 原UUID
   * @param payload 原规范正文
   * @param hash 原摘要
   * @param locking 原考勤事务内true
   * @return 本表原行，不能借其他学校同键
   */
  private Map<String, Object> existing(
      Map<String, Long> actor, String key, String payload, String hash, boolean locking) {
    var row = requests.find(actor.get("accountId"), key, locking);
    own(actor, row);
    if (!payload.equals(row.get("payloadJson")) || !hash.equals(row.get("commandHash"))) {
      throw conflict();
    }
    return row;
  }

  /**
   * 方法作用：核原请求所属的实际当前尝试，不拼接其他请求回执。
   *
   * @param actor 原真实主体
   * @param request 本表实际请求行
   * @param locking 已持原槽锁true
   * @return 原当前尝试，例如PREPARED；尚无尝试null
   */
  private Map<String, Object> current(
      Map<String, Long> actor, Map<String, Object> request, boolean locking) {
    if (request.get("currentAttemptId") == null) {
      return null;
    }
    var attempt =
        attempts.find(actor.get("tenantId"), number(request.get("currentAttemptId")), locking);
    validAttempt(request, attempt);
    return attempt;
  }

  /**
   * 方法作用：原学校、父请求、当前尝试号必须完全对应。
   *
   * @param request 原私有请求
   * @param attempt 原本表尝试
   * @throws CommonBusinessException 错位或缺记录拒绝，不返回回执
   */
  private void validAttempt(Map<String, Object> request, Map<String, Object> attempt) {
    if (attempt == null
        || number(attempt.get("requestId")) != number(request.get("id"))
        || number(attempt.get("tenantId")) != number(request.get("tenantId"))
        || number(attempt.get("attemptNo")) != number(request.get("attemptNo"))
        || "COMMITTED".equals(request.get("stateCode"))
            != "COMMITTED".equals(attempt.get("stateCode"))) {
      throw conflict();
    }
  }

  /**
   * 方法作用：只推进本请求指向自己刚建立或已提交的实际尝试。
   *
   * @param actor 原主体
   * @param request 原已锁请求
   * @param attempt 原尝试
   * @param stateCode 服务器固定RECORDED或COMMITTED
   * @throws CommonBusinessException 原修订或指针变化拒绝，同事务回滚
   */
  private void advance(
      Map<String, Long> actor,
      Map<String, Object> request,
      Map<String, Object> attempt,
      String stateCode) {
    var row = update(actor, request);
    row.putParam("currentAttemptId", attempt.get("id"));
    row.putParam("attemptNo", attempt.get("attemptNo"));
    row.putParam("stateCode", stateCode);
    if (requests.advance(row) != 1) {
      throw conflict();
    }
  }

  /**
   * 方法作用：只构造本表CAS实际定位，不带业务正文或客户端actor。
   *
   * @param actor 原主体
   * @param record 原持久行
   * @return 原CommonParam，例如id100000/tenant9/expectedRevision0
   */
  private CommonParam update(Map<String, Long> actor, Map<String, Object> record) {
    var row = new CommonParam();
    row.putParam("id", record.get("id"));
    row.putParam("tenantId", actor.get("tenantId"));
    row.putParam("expectedRevision", record.get("revision"));
    row.putParam("lastOperateUserId", actor.get("userId"));
    return row;
  }

  /**
   * 方法作用：最小投影来自独立已提交事务；不输出私有正文、结果或身份。
   *
   * @param actor 原实际本人
   * @param request 原请求行
   * @return 原实际状态，例如COMMITTED/businessCommitted true/employeeId字符串
   */
  private CommonResult metadata(Map<String, Long> actor, Map<String, Object> request) {
    own(actor, request);
    var attempt = current(actor, request, true);
    var data = new LinkedHashMap<String, Object>();
    data.put("requestKey", request.get("requestKey"));
    data.put("requestId", request.get("id").toString());
    data.put("permissionGranted", false);
    data.put("stateCode", attempt == null ? "RECORDED" : attempt.get("stateCode"));
    data.put("businessCommitted", attempt != null && "COMMITTED".equals(attempt.get("stateCode")));
    if (attempt != null) {
      data.put("attemptKey", attempt.get("attemptKey"));
      data.put("attemptNo", attempt.get("attemptNo").toString());
      if (attempt.get("employeeId") != null) {
        data.put("employeeId", attempt.get("employeeId").toString());
        data.put("receiptHash", attempt.get("receiptHash"));
      }
    }
    var result = new CommonResult();
    result.setSuccess(true);
    result.setData(data);
    return result;
  }

  /**
   * 方法作用：只回放原已提交成功结果，不将PREPARED当成功。
   *
   * @param attempt 原COMMITTED尝试
   * @return 原完整新增CommonResult，JSON业务形状不变
   * @throws CommonBusinessException 原持久结果损坏或失败时拒绝，不重新员工SQL
   */
  private CommonResult result(Map<String, Object> attempt) {
    var result = JsonUtils.fromJson(String.valueOf(attempt.get("resultJson")), CommonResult.class);
    if (result == null || !result.isSuccess()) {
      throw conflict();
    }
    return result;
  }

  /**
   * 方法作用：当前原管理资格前后与真实三主键一致，不从显示名称推导资格。
   *
   * @return 原主体，例如tenantId9/userId9101/accountId9101
   * @throws CommonBusinessException 原管理资格或主体变更拒绝
   */
  private Map<String, Long> qualifiedActor() {
    var actor = actor();
    var managed = authorization.requireReadManagement();
    if (!actor.get("tenantId").equals(managed.get("tenantId"))
        || !actor.get("userId").equals(managed.get("userId"))) {
      throw conflict();
    }
    same(actor, actor());
    return actor;
  }

  /**
   * 方法作用：只读Host具名真实当前身份，不接受业务参数覆盖主体。
   *
   * @return 三个原Long主键，例如9/9101/9101
   * @throws CommonBusinessException 缺少真实身份拒绝
   */
  private Map<String, Long> actor() {
    var result = identities.revalidateCurrent();
    if (result == null || !result.isSuccess() || !(result.getData() instanceof Map<?, ?> data)) {
      throw conflict();
    }
    var actor = new LinkedHashMap<String, Long>();
    for (String field : Set.of("tenantId", "userId", "accountId")) {
      if (!(data.get(field) instanceof Long id) || id <= 0) {
        throw conflict();
      }
      actor.put(field, id);
    }
    return Map.copyOf(actor);
  }

  /**
   * 方法作用：核请求仅属于原同账号同学校同本地成员，不能沿同键换校。
   *
   * @param actor 原主体
   * @param request 本表原行
   * @throws CommonBusinessException 原键缺失或真实归属不符拒绝
   */
  private void own(Map<String, Long> actor, Map<String, Object> request) {
    if (request == null
        || actor.entrySet().stream().anyMatch(e -> !e.getValue().equals(request.get(e.getKey())))) {
      throw conflict();
    }
  }

  /**
   * 方法作用：前后实际主键必须一致，不能继承另一请求或学校。
   *
   * @param before 原实际主体
   * @param after 原拥有方重核主体
   * @throws CommonBusinessException 主体变化拒绝
   */
  private void same(Map<String, Long> before, Map<String, Long> after) {
    if (!before.equals(after)) {
      throw conflict();
    }
  }

  /**
   * 方法作用：固定v1原业务字段规范化，不接受主键、身份或协议状态。
   *
   * @param input 规范UUID及原员工业务字段
   * @return 有序业务JSON，例如employeeNo T001/employeeName林老师/employmentType FULL_TIME
   * @throws CommonBusinessException 未知、过长、非法日期或数值拒绝，不生成请求记录
   */
  private String payload(CommonParam input) {
    var values = new TreeMap<String, Object>();
    for (var entry : input.getParamMap().entrySet()) {
      String field = entry.getKey();
      Object value = entry.getValue();
      if (TEXT.containsKey(field)) {
        if (!(value instanceof String text) || text.length() > TEXT.get(field)) {
          throw conflict();
        }
        values.put(field, text);
      } else if ("hireDate".equals(field) || "resignDate".equals(field)) {
        if (value != null && !String.valueOf(value).isBlank()) {
          try {
            values.put(field, LocalDate.parse(String.valueOf(value)).toString());
          } catch (java.time.DateTimeException failure) {
            throw conflict();
          }
        }
      } else if ("workplaceId".equals(field) || "departmentId".equals(field)) {
        if (value != null && !String.valueOf(value).isBlank()) {
          try {
            values.put(field, Long.parseLong(String.valueOf(value)));
          } catch (NumberFormatException failure) {
            throw conflict();
          }
        }
      } else if ("sortnum".equals(field)) {
        try {
          var decimal = new BigDecimal(String.valueOf(value)).stripTrailingZeros();
          if (decimal.scale() > 2 || decimal.precision() - decimal.scale() > 8) {
            throw conflict();
          }
          values.put(field, decimal);
        } catch (NumberFormatException failure) {
          throw conflict();
        }
      } else if (!OTHER.contains(field)) {
        throw conflict();
      }
    }
    for (String field : Set.of("employeeNo", "employeeName", "employmentType")) {
      if (!(values.get(field) instanceof String text) || text.isBlank()) {
        throw conflict();
      }
    }
    values.putIfAbsent("businessStatus", "ACTIVE");
    values.putIfAbsent("sortnum", BigDecimal.ZERO);
    return JsonUtils.toJsonIgnoreNull(values);
  }

  /**
   * 方法作用：仅接受服务器规范UUID，不用traceId或任意编号代替幂等键。
   *
   * @param input 原固定参数
   * @return 规范UUID文本
   * @throws CommonBusinessException 缺失或非规范拒绝
   */
  private String key(CommonParam input) {
    if (input == null) {
      throw conflict();
    }
    return uuid(input.getParam("requestKey"));
  }

  /**
   * 方法作用：严格规范UUID，不接受大小写变体或缩短格式。
   *
   * @param value 原请求或尝试键
   * @return 原规范UUID，例如标准36字符文本
   * @throws CommonBusinessException 原键无效拒绝
   */
  private String uuid(Object value) {
    try {
      String text = String.valueOf(value);
      if (!UUID.fromString(text).toString().equals(text)) {
        throw conflict();
      }
      return text;
    } catch (IllegalArgumentException failure) {
      throw conflict();
    }
  }

  /**
   * 方法作用：状态/恢复入口只接固定字段，不接受动态表、状态或actor。
   *
   * @param input 原参数
   * @param fields 固定字段集合，例如requestKey/attemptKey
   * @throws CommonBusinessException 缺少或额外字段拒绝
   */
  private void fields(CommonParam input, Set<String> fields) {
    if (input == null || !input.getParamMap().keySet().equals(fields)) {
      throw conflict();
    }
  }

  /**
   * 方法作用：请求记录和恢复不嵌入未知外层事务，防止错序锁或读取未提交成功。
   *
   * @throws CommonBusinessException 已有外层事务拒绝
   */
  private void outsideTransaction() {
    if (TransactionSynchronizationManager.isActualTransactionActive()) {
      throw failure("ATTENDANCE_EMPLOYEE_REQUEST_TRANSACTION_REQUIRED", "员工请求需要独立考勤事务。");
    }
  }

  /**
   * 方法作用：无损读持久正主键。
   *
   * @param value 原Long或规范整数字符串，例如100000
   * @return 正Long，例如100000
   * @throws CommonBusinessException 非正主键或溢出拒绝
   */
  private long number(Object value) {
    long id = numberOrZero(value);
    if (id == 0) {
      throw conflict();
    }
    return id;
  }

  /**
   * 方法作用：读原非负修订或尝试号，不接受小数。
   *
   * @param value 原整数字段，例如0
   * @return 无损非负Long
   * @throws CommonBusinessException 负值或溢出拒绝
   */
  private long numberOrZero(Object value) {
    try {
      long id = Long.parseLong(String.valueOf(value));
      if (id < 0) {
        throw conflict();
      }
      return id;
    } catch (NumberFormatException failure) {
      throw conflict();
    }
  }

  /**
   * @return 固定冲突错误，不输出正文、姓名或他人记录
   */
  private CommonBusinessException conflict() {
    return failure("ATTENDANCE_EMPLOYEE_REQUEST_CONFLICT", "员工新增请求的正文、身份或尝试状态不一致。");
  }

  /**
   * 方法作用：只组安全业务错误，不打印正文或凭据。
   *
   * @param code 服务器固定错误码
   * @param message 固定安全提示
   * @return 原公共业务异常，例如请求未决
   */
  private CommonBusinessException failure(String code, String message) {
    return new CommonBusinessException(code, message);
  }
}
