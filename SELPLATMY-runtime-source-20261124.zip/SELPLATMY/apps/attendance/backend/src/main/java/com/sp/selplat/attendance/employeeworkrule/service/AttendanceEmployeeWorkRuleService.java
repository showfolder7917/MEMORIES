/* 2026-11-01：复用原考勤配置纯读合同，写和关联保护不变。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
package com.sp.selplat.attendance.employeeworkrule.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceEmployeeWorkRule 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceEmployeeWorkRuleService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批日的规则条件，例如employeeId=8801、effectiveStartDateLe=2026-10-04、pageNo=1
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  com.sp.selplat.common.util.CommonPageResult getForApproval(
      com.sp.selplat.common.util.CommonPageParam criteria);

  /**
   * 管理配置保护只读取本表规则引用，不开放独立HTTP入口。
   *
   * @param input 当前规则主键例如 id=8501；租户由真实会话覆盖
   * @return 真实引用数量例如1，无业务写入；缺管理许可拒绝
   */
  long countRuleReferences(CommonParam input);

  /**
   * 方法作用：仅供已核原配置读取完整保留引用，不进入管理提交回调。
   *
   * @param input 原所属配置编号，例如id8501，租户由真实身份覆盖
   * @return 原本表全部历史引用数量，例如1，包含软删除行
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原只读管理资格无效时拒绝，无引用写入
   */
  long countRuleReferencesForRead(com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：原审批来源纯读，前后核同一APPROVER及真实身份。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原来源分页，无匹配沿原空结果，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格撤回或身份变化拒绝旧结果
   */
  com.sp.selplat.common.util.CommonPageResult readForApproval(
      com.sp.selplat.common.util.CommonPageParam input);
}
