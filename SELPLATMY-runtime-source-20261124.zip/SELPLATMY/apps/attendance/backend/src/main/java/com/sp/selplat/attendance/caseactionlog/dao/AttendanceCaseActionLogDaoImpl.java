/* 2026-11-01：原案件审计双快照仅读实际CLOB字符，不改审计追加或共享序列化。 */
package com.sp.selplat.attendance.caseactionlog.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.exception.CommonSystemException;
import com.sp.selplat.common.util.CommonPageResult;
import java.util.Map;
import org.springframework.stereotype.Repository;

/** AttendanceCaseActionLog 使用本域私有数据源和共享模板，表名来自实际类名，不读取请求表名。 */
@Repository
public class AttendanceCaseActionLogDaoImpl extends AttendanceBaseDao
    implements AttendanceCaseActionLogDao {

  /**
   * 复用真实公共分页SQL，再把本表案件前后快照CLOB映射为实际JSON文本；默认排序入口也委托此方法。
   *
   * @param queryColumnValueMap 服务端范围，例如tenantId=81、employeeId=8801、status=1
   * @param orderBy 已有公共排序，例如id desc
   * @param pageNo 实际页码，例如1
   * @param pageSize 实际页大小，例如20
   * @return 实际CommonPageResult，例如records=[{id:76000,beforeSnapshotJson:"{}"}]、totalCount=1
   *     异常或副作用示例：CLOB读取失败保留真实原因并抛系统异常；只读，不改变总数或排序。
   */
  @Override
  public CommonPageResult getPageList(
      Map<String, Object> queryColumnValueMap, String orderBy, Integer pageNo, Integer pageSize) {
    // 原公共SQL/分页/权限筛选结果保持；仅转换本表JSON文本，不暴露驱动对象。
    CommonPageResult page = super.getPageList(queryColumnValueMap, orderBy, pageNo, pageSize);
    page.setRecords(page.getRecords().stream().map(this::readBodyText).toList());
    return page;
  }

  /**
   * 将本表beforeSnapshotJson的实际CLOB内容复制成字符串，不解析或重写业务JSON。
   *
   * @param row 真实JDBC行，例如id=76000、beforeSnapshotJson为内容{}的H2 Clob
   * @return 独立字段副本例如{id:76000,beforeSnapshotJson:"{}"}；null仍为null
   * @throws CommonSystemException 实际SQLException/长度溢出时保留cause并拒绝读取；不写数据库
   */
  private Map<String, Object> readBodyText(Map<String, Object> row) {
    // 无匹配必须保持原公共查询合同，不生成空记录。
    if (row == null) {
      return null;
    }
    Map<String, Object> fields = new java.util.LinkedHashMap<>(row);
    for (String field : java.util.List.of("beforeSnapshotJson", "afterSnapshotJson")) {
      if (fields.get(field) instanceof java.sql.Clob text) {
        try {
          // JDBC实际字符内容原样返回；驱动对象及其stream/trace字段不属于业务响应。
          fields.put(field, text.getSubString(1, Math.toIntExact(text.length())));
        } catch (java.sql.SQLException | ArithmeticException failure) {
          throw new CommonSystemException(
              "ATTENDANCE_CASE_LOG_READ_FAILED", "案件审计内容读取失败，请稍后重试。", failure);
        }
      }
    }
    return fields;
  }
}
