package com.sp.selplat.attendance.employee.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceEmployee 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceEmployeeDao extends BaseDao {
    /**
     * 排班能力逐员工取得真实当前行，统一空日期与已有日期写入串行。
     *
     * @param input 已核验管理范围的员工主键例如id=8801
     * @return 实际员工例如data.employeeName=隔离员工甲；不存在或许可撤销拒绝，锁本员工到事务结束
     */
    java.util.Map<String, Object> lockForSchedule(com.sp.selplat.common.util.CommonParam input);
}
