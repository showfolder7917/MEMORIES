/* 2026-10-29：仅本人只读状态，保留统一认证/角色拦截器，不提供写路由。 */
package com.sp.selplat.attendance.employeecreateattempt.controller;

import com.sp.selplat.attendance.employeecreateattempt.service.AttendanceEmployeeCreateAttemptService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 原统一身份及角色入口继续核验，本表Service另核真实本人归属。 */
@RestController
@RequestMapping("/api/attendance/employee-create-attempts")
public class AttendanceEmployeeCreateAttemptController {
  // 只消费本表公开服务，无DAO或跨表查询。
  private final AttendanceEmployeeCreateAttemptService service;

  /**
   * 方法作用：装配本表只读拥有方，不授权。
   *
   * @param service 本表原服务
   */
  public AttendanceEmployeeCreateAttemptController(AttendanceEmployeeCreateAttemptService service) {
    this.service = service;
  }

  /**
   * 方法作用：本人只读最小状态，身份和角色仍由原统一入口核验。
   *
   * @param input 仅原UUID字段
   * @return 原最小状态CommonResult，不返回正文或写能力
   */
  @PostMapping("current.htm")
  public CommonResult current(CommonParam input) {
    return service.current(input);
  }
}
