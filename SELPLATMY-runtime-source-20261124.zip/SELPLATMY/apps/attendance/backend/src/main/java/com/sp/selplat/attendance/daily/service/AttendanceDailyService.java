/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
package com.sp.selplat.attendance.daily.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceDaily 表级服务：默认CRUD要求管理配置，本人读取使用独立已核验绑定，不授予变更权限。 */
public interface AttendanceDailyService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用业务能力提交服务端校验/计算的快照；没有 HTTP 直接调用入口。
   *
   * @param input 服务端计算/接收字段，例如 employeeId=8801，不能直接转发客户端派生分钟
   * @return 实际号段及持久化结果 CommonResult 异常或副作用示例：拒绝受保护状态；真实本域事务写入该表，不直接访问其他表。
   */
  CommonResult storeCalculated(CommonParam input);

  /**
   * 读取真实会话员工映射对应的本人资源，没有独立通用 CRUD 放行。
   *
   * @param input 资源主键，例如 id=100001；请求员工/租户字段不参与权限选择
   * @return 真实本人资源；缺已核验映射或异员工时拒绝，无写入副作用
   */
  CommonResult getOwned(CommonParam input);

  /**
   * @param input 日次主键；
   * @return 已核验 TENANT APPROVER 的真实日次；缺独立审批配置拒绝，无写入。
   */
  CommonResult getForApproval(CommonParam input);

  /**
   * 处理真实建单/退回/驳回对应日次状态，不改工时。
   *
   * @param input 内部案件事实，例如id=100001、action=RETURN；身份须独立核验
   * @return 例如data.approvalStatus=RETURNED；同租户所属真实日次，无伪造记录
   *     异常或副作用示例：SUBMIT允许管理或本人已核验绑定，其余须审批配置；失败回滚。
   */
  CommonResult applyCaseState(CommonParam input);

  /**
   * 保存已由旧最终时间公式算出的审批指标与最终字段，保持原始打卡不变。
   *
   * @param input 内部算法事实，例如id=100001、approvedCaseId=100002、finalBreakMinutes=60
   * @return 真实最终日次，例如data.actualWorkMinutes=525、data.approvalStatus=APPROVED
   *     异常或副作用示例：缺独立审批配置或来源时拒绝；本表写入随外层案件事务回滚。
   */
  CommonResult storeApproved(CommonParam input);

  /**
   * 按当前已核验绑定读取本人资源分页，租户/员工均由服务覆盖。
   *
   * @param input 浏览器分页及日期条件，例如pageNo=1、pageSize=20；忽略employeeId=999和tenantId=82
   * @return 实际CommonPageResult，例如records=[{id:100001,employeeId:8801}]、totalCount=1
   *     异常或副作用示例：匿名或未核验绑定拒绝，仅所属表查询，不开放管理动作。
   */
  com.sp.selplat.common.util.CommonPageResult ownedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 管理配置保护只读取本表规则引用，不开放独立HTTP入口。
   *
   * @param input 当前规则主键例如 id=8501；租户由真实会话覆盖
   * @return 真实引用数量例如1，无业务写入；缺管理许可拒绝
   */
  long countRuleReferences(CommonParam input);

  /**
   * 方法作用：仅供已核原配置读取完整保留引用，不进入管理提交回调。
   *
   * @param input 原所属配置编号，例如id8501，租户由真实身份覆盖
   * @return 原本表全部历史引用数量，例如1，包含软删除行
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原只读管理资格无效时拒绝，无引用写入
   */
  long countRuleReferencesForRead(com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：HTTP身份本人纯读入口，查询前后均核原绑定。
   *
   * @param input 原分页，例如pageNo1/workDate2026-10-21
   * @return 原完整分页，例如本人记录8340/totalCount1，不改原排序
   */
  com.sp.selplat.common.util.CommonPageResult readOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：HTTP身份本人详情纯读，不能用客户端员工号更换归属。
   *
   * @param input 原主键，例如id8340
   * @return 原CommonResult，例如data.employeeId7060，异员工拒绝无写入
   */
  CommonResult readOwned(CommonParam input);

  /**
   * 方法作用：原审批来源纯读，前后核同一APPROVER及真实身份。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原来源结果，无匹配沿原空结果，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格撤回或身份变化拒绝旧结果
   */
  com.sp.selplat.common.util.CommonResult readForApproval(
      com.sp.selplat.common.util.CommonParam input);
}
