package com.sp.selplat.attendance.punchsourceconfig.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendancePunchSourceConfig 唯一本表 DAO 契约，不读取组织、账号或其他表。 */
public interface AttendancePunchSourceConfigDao extends BaseDao {
    /**
     * 在调用方真实事务中锁定本表来源行；不读取员工或其他应用表。
     *
     * @param input 服务端租户和精确来源，例如 tenantId=81、sourceSystem=CSV_A
     * @return 已锁定来源 ID，例如 100001；不存在返回 null 异常或副作用示例：等待同来源事务完成，锁持续到所属事务结束；无业务字段更新。
     */
    Long lockSource(com.sp.selplat.common.util.CommonParam input);
}
