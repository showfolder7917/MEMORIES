/*
 * 文件：AttendanceAccessGuard.java
 * 修改：2026-10-03；为未来正式考勤服务提供默认拒绝的服务端身份与归属判断候选。
 */
package com.sp.selplat.attendance.common.util.access;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonResult;
import java.math.BigDecimal;
import java.util.Map;

/**
 * 只判断真实 Uniauth current 返回与服务端持久化归属的匹配，不读请求身份、不授予管理权限。 调用方必须直接调用
 * UniauthSessionService.current()，不能将请求 JSON 构造成 sessionResult。 本工具不替代认证、DAO 的租户 SQL
 * 条件、行锁或已核准的员工与审批权限关联。
 */
public final class AttendanceAccessGuard {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceAccessGuard() {
        // 静态判定工具不保存请求间状态。
    }

    /**
     * 从 Uniauth 当前会话的成功返回中读取已认证用户和租户；不接受字符串或缺失主键。
     *
     * @param sessionResult 考勤服务直接调用 UniauthSessionService.current() 的结果， 例如
     *     success=true、data={userId:7,tenantId:2}，禁止来自请求绑定
     * @return 仅含服务端身份的 Map，例如 {userId:7,tenantId:2}；不复制 loginName 或推断角色
     * @throws CommonBusinessException 无有效身份时抛 ATTENDANCE_IDENTITY_REQUIRED， 例如 success=false、缺
     *     tenantId 或 userId=0
     */
    public static Map<String, Long> requireIdentity(CommonResult sessionResult) {
        if (sessionResult == null
                || !sessionResult.isSuccess()
                || !(sessionResult.getData() instanceof Map<?, ?> profile)) {
            throw identityRequired();
        }
        long userId = positiveId(profile.get("userId"));
        long tenantId = positiveId(profile.get("tenantId"));
        if (userId == 0 || tenantId == 0) {
            throw identityRequired();
        }
        // 身份只来自服务端安全概要，不接收 Header、operatorId、tenantId 等请求参数。
        return Map.of("userId", userId, "tenantId", tenantId);
    }

    /**
     * 在读取或变更已存在资源前比较数据库资源租户，不假设按主键查询已经隔离租户。
     *
     * @param sessionResult 真实 Uniauth current 结果，例如 userId=7、tenantId=2
     * @param persistedTenantId 服务端从目标资源数据库行读取的 tenantId，例如 2；不能来自请求
     * @return 已认证身份 Map，例如 {userId:7,tenantId:2}，供拥有事务的服务继续加租户 SQL 条件
     * @throws CommonBusinessException 归属缺失或异租户抛 ATTENDANCE_ACCESS_DENIED， 例如已认证 tenantId=2 而目标
     *     tenantId=3；不返回目标资源信息
     */
    public static Map<String, Long> requireTenantResource(
            CommonResult sessionResult, Object persistedTenantId) {
        Map<String, Long> identity = requireIdentity(sessionResult);
        long tenantId = positiveId(persistedTenantId);
        if (tenantId == 0 || tenantId != identity.get("tenantId")) {
            throw accessDenied();
        }
        return identity;
    }

    /**
     * 自助操作额外验证服务端已核准的用户归属，缺映射时拒绝，绝不假设 employeeId=userId。
     *
     * @param sessionResult 真实 Uniauth current 结果，例如 userId=7、tenantId=2
     * @param persistedTenantId 服务端目标行所属租户，例如 2
     * @param mappedOwnerUserId 服务端经已核准身份映射得到的 Uniauth 用户主键，例如 7； 旧员工表目前没有此映射，缺失传 null 并拒绝，禁止把原
     *     applicantId 直接当认证用户主键
     * @return 已认证身份 Map，例如 {userId:7,tenantId:2}，只证明同租户同用户归属
     * @throws CommonBusinessException 无可信映射或跨用户抛 ATTENDANCE_ACCESS_DENIED， 例如
     *     mappedOwnerUserId=null 或 8；不授予任何管理员例外
     */
    public static Map<String, Long> requireOwnedResource(
            CommonResult sessionResult, Object persistedTenantId, Object mappedOwnerUserId) {
        Map<String, Long> identity = requireTenantResource(sessionResult, persistedTenantId);
        long ownerUserId = positiveId(mappedOwnerUserId);
        if (ownerUserId == 0 || ownerUserId != identity.get("userId")) {
            throw accessDenied();
        }
        return identity;
    }

    /**
     * 在尚无已核准管理/审批授权来源时默认拒绝管理动作，不发明角色或使用基类 isAdmin。
     *
     * @param sessionResult 真实 Uniauth current 结果，例如 userId=7、tenantId=2
     * @throws CommonBusinessException 匿名抛身份错误，认证后抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE； 例如
     *     loginName=admin 也不会获准审批、规则管理或月结 副作用示例：本方法始终拒绝，调用方不得写入数据库、审批日志或发放权限
     */
    public static void rejectUnconfiguredManagement(CommonResult sessionResult) {
        throw unconfiguredManagement(sessionResult);
    }

    /**
     * 校验真实身份并构造未配置管理能力的拒绝结果，调用方必须抛出该异常。
     *
     * @param sessionResult 实际认证current结果，例如userId=7、tenantId=2
     * @return ATTENDANCE_MANAGEMENT_UNAVAILABLE业务异常；不读写考勤业务表
     * @throws CommonBusinessException 匿名或无效身份先抛身份错误，例如未登录请求
     */
    public static CommonBusinessException unconfiguredManagement(CommonResult sessionResult) {
        requireIdentity(sessionResult);
        return new CommonBusinessException("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
    }

    /**
     * 将真实数据库数字主键转换为正 long，拒绝小数、溢出或客户端字符串主键。
     *
     * @param value 服务端数字值，例如 Long 7 或 BigDecimal 7
     * @return 正主键例如 7；无效值例如 7.5、null、字符串 "7" 返回 0
     */
    private static long positiveId(Object value) {
        if (!(value instanceof Number number)) {
            return 0;
        }
        try {
            long result = new BigDecimal(number.toString()).longValueExact();
            return result > 0 ? result : 0;
        } catch (NumberFormatException | ArithmeticException exception) {
            // 数值异常不回落到租户或操作员 1，按没有可信身份/归属处理。
            return 0;
        }
    }

    /**
     * 构建统一身份缺失错误，不回传账号信息。
     *
     * @return 公共业务异常，errorCode=ATTENDANCE_IDENTITY_REQUIRED
     */
    private static CommonBusinessException identityRequired() {
        return new CommonBusinessException("ATTENDANCE_IDENTITY_REQUIRED", "当前请求未建立有效考勤身份。");
    }

    /**
     * 构建统一归属拒绝错误，不泄露资源属于哪个用户或租户。
     *
     * @return 公共业务异常，errorCode=ATTENDANCE_ACCESS_DENIED
     */
    private static CommonBusinessException accessDenied() {
        return new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "无权访问当前考勤资源。");
    }
}
