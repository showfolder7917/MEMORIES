/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.attendancecase.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceCase 真实表服务；管理查询默认拒绝，通用写入/更新/删除不可修改审批与审计事实。 */
public interface AttendanceCaseService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 真实管理人员或已绑定本人对实际日次建单，拒绝已有活动案件。
   *
   * @param input 业务事实，例如attendanceDailyId=100001、caseType=PUNCH_CORRECTION、reasonText=补充时间
   * @return 例如data.caseId=100002、data.caseStatus=SUBMITTED；申请人不由请求决定
   *     异常或副作用示例：缺身份/归属/重复案件拒绝；案件、日次状态和日志同事务保存。
   */
  CommonResult submit(CommonParam input);

  /**
   * 独立APPROVER核验后执行通过/退回/驳回，批准时复用旧最终分钟公式。
   *
   * @param input 例如id=100002、actionType=APPROVE、patchPayloadJson含actualClockOut=2026-10-04T18:45
   * @return 例如data.caseStatus=APPROVED、data.handlingStatus=RESOLVED；完整结果来自Service
   *     异常或副作用示例：未知动作或来源异常拒绝；案件、最终日次和两类审计全部回滚。
   */
  CommonResult applyAction(CommonParam input);

  /**
   * 独立TENANT APPROVER查询真实处理单范围，不能读取其他业务表或获得管理CRUD。
   *
   * @param input 例如pageNo=1、pageSize=20、employeeId=8801；租户由会话覆盖
   * @return 实际CommonPageResult，例如records=[{id:100002,caseStatus:SUBMITTED}]、totalCount=1
   *     异常或副作用示例：缺审批配置拒绝；仅读取处理单，无授权写入。
   */
  com.sp.selplat.common.util.CommonPageResult reviewStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 独立APPROVER读取真实案件详情，不需要管理角色。
   *
   * @param input 例如id=100002；请求租户不作为访问来源
   * @return 真实CommonResult，例如data.caseStatus=SUBMITTED；无匹配拒绝，无写入
   */
  CommonResult reviewDetail(CommonParam input);

  /**
   * 按当前已核验绑定读取本人资源分页，租户/员工均由服务覆盖。
   *
   * @param input 浏览器分页及日期条件，例如pageNo=1、pageSize=20；忽略employeeId=999和tenantId=82
   * @return 实际CommonPageResult，例如records=[{id:100001,employeeId:8801}]、totalCount=1
   *     异常或副作用示例：匿名或未核验绑定拒绝，仅所属表查询，不开放管理动作。
   */
  com.sp.selplat.common.util.CommonPageResult ownedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 获取本人绑定员工的处理单详情，不要求或授予审批角色。
   *
   * @param input 实际案件主键，例如id=100002；请求employeeId不参与归属核验
   * @return 完整CommonResult，例如data.caseStatus=SUBMITTED；异员工拒绝，无写入
   */
  CommonResult getOwned(CommonParam input);

  /**
   * 只读真实申请/当前日次及服务端计算草稿差异。
   *
   * @param input 主键、修订、补丁例如id=9501、revision=0
   * @return 实际CommonResult例如data.proposed.actualWorkMinutes=525 异常或副作用示例：过期或缺独立审批许可拒绝，不写业务或日志。
   */
  CommonResult previewAction(CommonParam input);

  /**
   * 方法作用：HTTP身份本人分页显式纯读，交付前复核原资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原分页含records/totalCount，无写入
   */
  com.sp.selplat.common.util.CommonPageResult readOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：HTTP身份本人详情显式纯读，交付前复核原资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonResult含data.caseStatus，无写入
   */
  CommonResult readOwned(CommonParam input);

  /**
   * 方法作用：HTTP身份审批分页显式纯读，交付前复核原资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原分页含records/totalCount，无写入
   */
  com.sp.selplat.common.util.CommonPageResult readReviewStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：HTTP身份审批详情显式纯读，交付前复核原资格。
   *
   * @param input 原分页或主键，例如id9430
   * @return 原CommonResult含data.caseStatus，无写入
   */
  CommonResult readReviewDetail(CommonParam input);

  /**
   * 方法作用：HTTP身份审批预览纯读，复用原算法及四来源完整资格。
   *
   * @param input 原案件/修订/草稿，例如id9430/revision0
   * @return 原审批差异CommonResult，例如proposed.actualWorkMinutes525
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格/修订/草稿失效沿原错误，无写入
   */
  CommonResult readPreview(CommonParam input);
}
