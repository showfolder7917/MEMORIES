package com.sp.selplat.attendance.common.util.access;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

/** 只核验服务端已查询配置，不查库、不写角色，不从请求身份或名称推断权限。 */
public final class AttendanceGrantPolicy {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceGrantPolicy() {
        // 无请求间状态。
    }

    /**
     * 核验本人本租户已确认配置及明确角色/范围，管理不自动获得审批权。
     *
     * @param row 表服务查询的真实配置行，例如 VERIFIED/MANAGER/TENANT；无配置传 null
     * @param identity 真实会话概要中的 userId/tenantId，例如 8101/81
     * @param role 明确业务需求 MANAGER 或 APPROVER，不能来自请求任意角色
     * @param now 服务端实际当前时间，例如 LocalDateTime.now()
     * @return 配置完整且未到期为 true；PENDING、部门范围、缺失、停用或身份变化为 false
     */
    public static boolean allows(
            Map<String, Object> row, Map<String, Long> identity, String role, LocalDateTime now) {
        if (!verified(row, identity)
                || !("MANAGER".equals(role) || "APPROVER".equals(role))
                || !role.equals(row.get("roleCode"))
                || !"TENANT".equals(row.get("scopeCode"))
                || row.get("departmentId") != null
                || now == null) {
            return false;
        }
        if (row.get("expiresAt") == null) {
            return true;
        }
        try {
            LocalDateTime expiry =
                    row.get("expiresAt") instanceof LocalDateTime time
                            ? time
                            : LocalDateTime.parse(
                                    String.valueOf(row.get("expiresAt")).replace(' ', 'T'));
            return expiry.isAfter(now);
        } catch (java.time.format.DateTimeParseException exception) {
            return false;
        }
    }

    /**
     * 核验显式员工绑定，不假设员工主键等于账号主键。
     *
     * @param row 当前账号的真实配置行，例如 userId=8101、employeeId=8801
     * @param identity 真实 Session 的 userId/tenantId，例如 8101/81
     * @return VERIFIED 启用且员工主键为正数返回 true；缺映射返回 false，无副作用
     */
    public static boolean mapped(Map<String, Object> row, Map<String, Long> identity) {
        return verified(row, identity) && number(row.get("employeeId")) > 0;
    }

    /**
     * 验证基本配置状态及账号归属。
     *
     * @param row 服务端配置行，例如 configurationStatus=VERIFIED、status=1
     * @param identity 本次捕获的真实用户和租户
     * @return 状态与身份完全匹配为 true；不接受名称、字符串身份或小数主键，无副作用
     */
    private static boolean verified(Map<String, Object> row, Map<String, Long> identity) {
        return row != null
                && identity != null
                && "VERIFIED".equals(row.get("configurationStatus"))
                && number(row.get("status")) == 1
                && number(row.get("tenantId")) > 0
                && number(row.get("userId")) > 0
                && identity.get("tenantId") != null
                && identity.get("userId") != null
                && number(row.get("tenantId")) == identity.get("tenantId")
                && number(row.get("userId")) == identity.get("userId");
    }

    /**
     * 读取数据库整数值，拒绝缺失、溢出、字符串或小数。
     *
     * @param value 真实数字，例如 Long 81
     * @return 整数值例如 81，无效值返回 0，无副作用
     */
    private static long number(Object value) {
        if (!(value instanceof Number number)) {
            return 0;
        }
        try {
            return new BigDecimal(number.toString()).longValueExact();
        } catch (NumberFormatException | ArithmeticException exception) {
            return 0;
        }
    }

    /**
     * 验证本人月报精确许可、租户、账号和已绑定员工完全一致。
     *
     * @param row 真实配置，例如 SELF_MONTHLY_READ/SELF、employeeId=8801
     * @param identity 真实 Session 和员工绑定，例如 userId=8101、tenantId=81、employeeId=8801
     * @param now 服务端当前时间，例如 LocalDateTime.now()
     * @return 完整已核验且未过期返回 true；登录或管理许可单独存在为 false，无写入
     */
    public static boolean allowsMonthlySelfRead(
            Map<String, Object> row, Map<String, Long> identity, LocalDateTime now) {
        // 显式员工范围必须与实时映射一致，部门许可不能提升为本人许可。
        if (!verified(row, identity)
                || !"SELF_MONTHLY_READ".equals(row.get("roleCode"))
                || !"SELF".equals(row.get("scopeCode"))
                || row.get("departmentId") != null
                || identity.get("employeeId") == null
                || number(row.get("employeeId")) <= 0
                || number(row.get("employeeId")) != identity.get("employeeId")
                || now == null) {
            return false;
        }
        if (row.get("expiresAt") == null) {
            return true;
        }
        try {
            LocalDateTime expiry =
                    row.get("expiresAt") instanceof LocalDateTime time
                            ? time
                            : LocalDateTime.parse(
                                    String.valueOf(row.get("expiresAt")).replace(' ', 'T'));
            return expiry.isAfter(now);
        } catch (java.time.format.DateTimeParseException invalidExpiry) {
            return false;
        }
    }

    /**
     * 精确核验三种新增动作，旧管理/审批判定不扩张。
     *
     * @param row 所属真实配置例如MONTHLY_PUBLISH/TENANT/VERIFIED
     * @param identity 当前真实userId/tenantId例如8104/81
     * @param role 内部固定角色例如MONTHLY_PUBLISH
     * @param now 服务器当前时间
     * @return 完整有效精确许可为true，缺失/过期/员工或部门范围为false，无写入
     */
    public static boolean allowsRelease(
            Map<String, Object> row, Map<String, Long> identity, String role, LocalDateTime now) {
        if (!verified(row, identity)
                || !java.util.Set.of("MONTHLY_REVIEW", "MONTHLY_PUBLISH", "MONTHLY_WITHDRAW")
                        .contains(role)
                || !role.equals(row.get("roleCode"))
                || !"TENANT".equals(row.get("scopeCode"))
                || row.get("departmentId") != null
                || row.get("employeeId") != null
                || now == null) {
            return false;
        }
        if (row.get("expiresAt") == null) {
            return true;
        }
        try {
            return LocalDateTime.parse(String.valueOf(row.get("expiresAt")).replace(' ', 'T'))
                    .isAfter(now);
        } catch (java.time.format.DateTimeParseException invalid) {
            return false;
        }
    }
}
