/* 2026-11-01：本人状态HTTP读取保留事务外查询和最小投影，返回前复核角色身份。 */
/* 2026-10-29：本表私有拥有方；原内部写仅由固定编排在原业务事务调用。 */
package com.sp.selplat.attendance.employeecreaterequest.service.impl;

import com.sp.selplat.attendance.employeecreaterequest.dao.AttendanceEmployeeCreateRequestDao;
import com.sp.selplat.attendance.employeecreaterequest.service.AttendanceEmployeeCreateRequestService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.sequence.SequenceGenerator;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/** 本表唯一Service；本人状态仅读最小投影，不包含私文或业务写授权。 */
@Service
public class AttendanceEmployeeCreateRequestServiceImpl
    implements AttendanceEmployeeCreateRequestService {
  // 本表原DAO与独立号段，不访问其他工程表。
  private final AttendanceEmployeeCreateRequestDao dao;
  private final SequenceGenerator sequence;
  // 本人身份只来自Host具名原会话。
  private final CurrentSessionAccess identities;

  // 原状态查询仍核固定系统入口，延迟取既有Bean以保持原编排装配。
  @org.springframework.beans.factory.annotation.Autowired
  @Qualifier("attendanceApplicationEntryAccess")
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.common.service.authorization.ApplicationEntryAccess>
      readEntries;

  /**
   * 方法作用：绑定本表拥有方，不写SQL或权限。
   *
   * @param dao 本表原DAO
   * @param sequence 原独立号段
   * @param identities Host具名真实身份
   */
  public AttendanceEmployeeCreateRequestServiceImpl(
      AttendanceEmployeeCreateRequestDao dao,
      SequenceGenerator sequence,
      @Qualifier("attendanceCurrentSessionAccess") CurrentSessionAccess identities) {
    this.dao = dao;
    this.sequence = sequence;
    this.identities = identities;
  }

  /**
   * 方法作用：仅分配本表原独立技术主键。
   *
   * @return 实际正Long，例如100000
   */
  @Override
  public long newId() {
    return sequence.getSequence(dao.getIdSequenceDefinition()).get("id");
  }

  /**
   * 方法作用：原固定事务内仅新增本表，不开放HTTP写。
   *
   * @param input 原本表参数，例如id100000/tenant9
   * @return 实际影响行数，例如1
   */
  @Override
  public int insert(CommonParam input) {
    return dao.insert(input);
  }

  /** 方法作用：仅委派原事务校验，无写入。 */
  @Override
  public void requireTransaction() {
    dao.requireTransaction();
  }

  /**
   * 方法作用：固定编排只访问本表实际拥有方，不转为HTTP写或权限。
   *
   * @param accountId 原实际账号，例如9101
   * @param key 原UUID
   * @param locking 原考勤事务内true
   * @return 本表原行，无行null
   */
  @Override
  public Map<String, Object> find(long accountId, String key, boolean locking) {
    return dao.find(accountId, key, locking);
  }

  /**
   * 方法作用：固定编排只访问本表实际拥有方，不转为HTTP写或权限。
   *
   * @param input 本表原定位及修订，例如id100000/expectedRevision0
   * @return 原实际影响行数，例如1，CAS不符0
   */
  @Override
  public int advance(CommonParam input) {
    return dao.advance(input);
  }

  /**
   * 方法作用：独立已提交读取只返回真实本人最小状态。
   *
   * @param input 原UUID字段，不接受正文或身份
   * @return 实际状态，例如PREPARED，不返回原结果
   * @throws CommonBusinessException 身份、参数或外层事务不符合时拒绝
   */
  @Override
  public CommonResult current(CommonParam input) {
    if (org.springframework.transaction.support.TransactionSynchronizationManager
        .isActualTransactionActive()) {
      throw denied();
    }
    var actor = readActor();
    if (input == null || !input.getParamMap().keySet().equals(java.util.Set.of("requestKey"))) {
      throw denied();
    }
    var row = dao.find(actor.get("accountId"), uuid(input.getParam("requestKey")), false);
    own(actor, row);
    // 已读状态只有当前同一主体且仍有原入口角色时才能交付。
    if (!actor.equals(readActor())) {
      throw denied();
    }
    return safe(row);
  }

  /**
   * 方法作用：只从本表原主键核真实本人，输入主键本身不授权。
   *
   * @param id 来自原持久尝试的父请求主键，例如100000
   * @return 同本人私有原行，不向HTTP或日志输出
   */
  @Override
  public Map<String, Object> requireOwn(long id) {
    var actor = actor();
    var input = new CommonParam();
    input.putParam("id", id);
    input.putParam("tenantId", actor.get("tenantId"));
    var row = dao.getById(input);
    own(actor, row);
    return row;
  }

  /**
   * 方法作用：实际三主键必须完全匹配本表真实归属。
   *
   * @param actor 原实际身份
   * @param row 本表原行
   * @throws CommonBusinessException 原行缺失或错位拒绝
   */
  private void own(Map<String, Long> actor, Map<String, Object> row) {
    if (row == null
        || actor.entrySet().stream().anyMatch(e -> !e.getValue().equals(row.get(e.getKey())))) {
      throw denied();
    }
  }

  /**
   * 方法作用：只读原Host真实身份，业务参数不能覆盖。
   *
   * @return 三个原Long坐标，例如9/9101/9101
   * @throws CommonBusinessException 匿名或原身份损坏拒绝
   */
  private Map<String, Long> actor() {
    var result = identities.revalidateCurrent();
    if (result == null || !result.isSuccess() || !(result.getData() instanceof Map<?, ?> data)) {
      throw denied();
    }
    var actor = new java.util.LinkedHashMap<String, Long>();
    for (String field : java.util.Set.of("tenantId", "userId", "accountId")) {
      if (!(data.get(field) instanceof Long id) || id <= 0) {
        throw denied();
      }
      actor.put(field, id);
    }
    return Map.copyOf(actor);
  }

  /**
   * 方法作用：只投影本表技术状态，不附带业务正文或写令牌。
   *
   * @param row 本表原实际行
   * @return 原CommonResult，例如data.id字符串/stateCode RECORDED
   */
  private CommonResult safe(Map<String, Object> row) {
    var result = new CommonResult();
    result.setSuccess(true);
    result.setData(Map.of("id", row.get("id").toString(), "stateCode", row.get("stateCode")));
    return result;
  }

  /**
   * 方法作用：仅规范UUID可定位本表键。
   *
   * @param value 原UUID字段
   * @return 原规范UUID文本
   * @throws CommonBusinessException 非规范输入拒绝
   */
  private String uuid(Object value) {
    try {
      String text = String.valueOf(value);
      if (!java.util.UUID.fromString(text).toString().equals(text)) {
        throw denied();
      }
      return text;
    } catch (IllegalArgumentException failure) {
      throw denied();
    }
  }

  /**
   * @return 固定不泄露归属的原业务错误，无写入
   */
  private CommonBusinessException denied() {
    return new CommonBusinessException("ATTENDANCE_EMPLOYEE_REQUEST_CONFLICT", "员工请求记录不存在或无权访问。");
  }

  /**
   * 方法作用：本人状态查询前后核原真实身份和固定系统角色，不创建事务或写许可。
   *
   * @return 实际本人三坐标，例如tenantId9/userId9102/accountId9102
   * @throws CommonBusinessException 原角色失效沿入口拒绝；身份变化仍不泄露私有状态
   */
  private Map<String, Long> readActor() {
    var before = actor();
    var result = readEntries.getObject().requireCurrentEntry();
    if (result == null
        || !result.isSuccess()
        || !(result.getData() instanceof Map<?, ?> data)
        || before.entrySet().stream()
            .anyMatch(entry -> !entry.getValue().equals(data.get(entry.getKey())))
        || !before.equals(actor())) {
      throw denied();
    }
    return before;
  }
}
