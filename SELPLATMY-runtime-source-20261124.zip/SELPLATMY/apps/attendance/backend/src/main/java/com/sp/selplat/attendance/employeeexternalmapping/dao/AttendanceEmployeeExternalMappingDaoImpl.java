package com.sp.selplat.attendance.employeeexternalmapping.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 固定拥有 AttendanceEmployeeExternalMapping，复用具名考勤模板和共享号段。 */
@Repository
public class AttendanceEmployeeExternalMappingDaoImpl extends AttendanceBaseDao
        implements AttendanceEmployeeExternalMappingDao { }
