/*
 * 文件：AttendanceDailyCalculator.java
 * 修改：2026-10-03；从 SELATTENDANCE dev bdf84ebe9b30ac713f714df93c470f1b8f23d27f 迁移 Map 边界。
 * 修改：2026-10-10；实际休息只扣有效出勤区间交集，重叠休息不重复扣除。
 * 不执行数据库操作、审批或工资金额计算。
 */
package com.sp.selplat.attendance.common.util.calculation;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.Objects;

/**
 * 第七阶段日次规则共享计算器。
 *
 * <p>负责把原始打卡初算与审批后 final 结果重算统一到同一套分钟口径里，避免两条链路各自维护一份规则算法。
 */
public final class AttendanceDailyCalculator {

    // 法定休日使用统一常量，避免日次、月次和预警层出现多种拼写。
    static final String HOLIDAY_TYPE_LEGAL = "LEGAL_HOLIDAY";
    // 所定休日使用统一常量，保证休日工时统计口径一致。
    static final String HOLIDAY_TYPE_SCHEDULED = "SCHEDULED_HOLIDAY";

    /**
     * 按旧 phase7-v1 规则计算日次，保留休息、取整、深夜、休日、缺卡和迟到优先级。 只接受已由 DAO 按业务日筛选并排序的有效卡；不负责规则生效查询、身份或持久化。
     *
     * @param schedule 排班快照 Map，例如 startTime=2026-07-03T09:00、endTime=2026-07-03T18:30；无排班传 null
     * @param punches 已处理并按时间排序的有效卡，例如 punchType=CLOCK_IN、punchTime=2026-07-03T09:00
     * @param applicableRule 按员工业务日命中的规则，例如 standardDailyMinutes=480、autoBreakDeductMinutes=60
     * @return 全字段结果 Map，例如 actualWorkMinutes=510、overtimeMinutes=30、status=NORMAL、exceptions=[]
     * @throws NumberFormatException 当规则分钟字段为无效文本，例如 standardDailyMinutes=invalid
     */
    public static Map<String, Object> calculateFromPunches(
            Map<String, Object> schedule,
            List<Map<String, Object>> punches,
            Map<String, Object> applicableRule) {
        CalculationResult result = buildBaseResult(schedule, applicableRule);
        result.logs.add(
                schedule == null
                        ? "当天没有排班快照，按无排班逻辑进入计算。"
                        : "已读取当天排班快照："
                                + defaultText(
                                        stringValue(readMapValue(schedule, "label")), "未命名班次"));
        result.logs.add("当天有效打卡数量为 " + punches.size() + " 条。");
        if (result.appliedRuleId != null) {
            result.logs.add(
                    "已命中正式规则："
                            + defaultText(
                                    result.appliedRuleName,
                                    stringValue(readMapValue(applicableRule, "ruleCode")))
                            + "。");
        } else {
            result.logs.add("当天未命中正式规则，按排班基础口径继续计算。");
        }

        Map<String, Object> firstClockIn = null;
        Map<String, Object> lastClockOut = null;
        List<Map<String, Object>> breakStarts = new ArrayList<>();
        List<Map<String, Object>> breakEnds = new ArrayList<>();
        for (Map<String, Object> punch : punches) {
            // 上班卡统一挑最早一条，确保迟到和工作起点都基于同一标准。
            if (Objects.equals("CLOCK_IN", stringValue(readMapValue(punch, "punchType")))) {
                if (firstClockIn == null
                        || dateTimeValue(readMapValue(punch, "punchTime"))
                                .isBefore(dateTimeValue(readMapValue(firstClockIn, "punchTime")))) {
                    firstClockIn = punch;
                }
            } else if (Objects.equals("CLOCK_OUT", stringValue(readMapValue(punch, "punchType")))) {
                // 下班卡统一挑最晚一条，避免中途误打卡把全天工时截短。
                if (lastClockOut == null
                        || dateTimeValue(readMapValue(punch, "punchTime"))
                                .isAfter(dateTimeValue(readMapValue(lastClockOut, "punchTime")))) {
                    lastClockOut = punch;
                }
            } else if (Objects.equals(
                    "BREAK_START", stringValue(readMapValue(punch, "punchType")))) {
                // 休息开始单独收集，后续与休息结束配对成净工作区间。
                breakStarts.add(punch);
            } else if (Objects.equals("BREAK_END", stringValue(readMapValue(punch, "punchType")))) {
                // 休息结束单独收集，保持休息计算与打卡顺序解耦。
                breakEnds.add(punch);
            }
        }
        result.actualClockIn =
                firstClockIn == null
                        ? null
                        : dateTimeValue(readMapValue(firstClockIn, "punchTime"));
        result.actualClockOut =
                lastClockOut == null
                        ? null
                        : dateTimeValue(readMapValue(lastClockOut, "punchTime"));
        List<TimeRange> breakRanges = buildBreakRanges(breakStarts, breakEnds);
        result.actualBreakMinutes = calculateBreakMinutes(
                breakRanges, result.actualClockIn, result.actualClockOut);
        result.finalBreakMinutes =
                resolveFinalBreakMinutes(
                        result.actualClockIn,
                        result.actualClockOut,
                        result.actualBreakMinutes,
                        applicableRule);
        result.actualWorkMinutes =
                roundMinutes(
                        calculateActualWorkMinutes(
                                result.actualClockIn,
                                result.actualClockOut,
                                result.finalBreakMinutes),
                        applicableRule);
        appendBasePresenceLogs(result);

        if (schedule == null && !punches.isEmpty()) {
            result.status = "NO_SCHEDULE";
            result.exceptionFlag = true;
            result.calcMessage = "无排班但存在有效打卡。";
            result.exceptions.add(
                    new ExceptionPlan("NO_SCHEDULE_PUNCH", "WARN", "当天没有排班，但检测到有效打卡记录。", "查看原始打卡"));
            result.logs.add("由于没有排班但存在打卡，因此判定为无排班出勤。");
            return toMap(result);
        }

        if (schedule != null && punches.isEmpty()) {
            result.status = "ABSENCE";
            result.exceptionFlag = true;
            result.absenceMinutes = result.scheduledWorkMinutes;
            result.calcMessage = "有排班但没有有效打卡。";
            result.exceptions.add(
                    new ExceptionPlan(
                            "SCHEDULE_NO_PUNCH", "ERROR", "当天有排班，但没有有效打卡，按缺勤处理。", "去打卡记录页处理"));
            result.logs.add("当天有排班但没有有效打卡，因此按缺勤处理。");
            return toMap(result);
        }

        if (schedule != null && result.actualClockIn == null && result.actualClockOut != null) {
            result.status = "MISSING_CLOCK_IN";
            result.exceptionFlag = true;
            result.calcMessage = "缺少上班卡。";
            result.exceptions.add(
                    new ExceptionPlan("MISSING_CLOCK_IN", "ERROR", "只找到下班卡，缺少上班卡。", "去打卡记录页处理"));
            result.logs.add("只找到下班卡，没有上班卡，因此判定为缺上班卡。");
            return toMap(result);
        }

        if (schedule != null && result.actualClockIn != null && result.actualClockOut == null) {
            result.status = "MISSING_CLOCK_OUT";
            result.exceptionFlag = true;
            result.lateMinutes =
                    calculateLateMinutes(result.actualClockIn, result.scheduledStartTime);
            result.calcMessage = "缺少下班卡。";
            result.exceptions.add(
                    new ExceptionPlan("MISSING_CLOCK_OUT", "ERROR", "只找到上班卡，缺少下班卡。", "去打卡记录页处理"));
            result.logs.add("只找到上班卡，没有下班卡，因此判定为缺下班卡。");
            return toMap(result);
        }

        if (schedule != null && result.actualClockIn != null && result.actualClockOut != null) {
            applyCompletedWorkMetrics(
                    result,
                    applicableRule,
                    buildWorkRanges(result.actualClockIn, result.actualClockOut, breakRanges),
                    true);
            return toMap(result);
        }

        result.status = "NORMAL";
        result.exceptionFlag = false;
        result.calcMessage = "未命中异常分支。";
        result.logs.add("未命中任何异常分支，按正常结果收口。");
        return toMap(result);
    }

    /**
     * 使用已审批最终时间重算分钟，保留旧审批算法；不执行审批或覆盖调用方最终状态。 审批后没有逐段休息信息，深夜仍按最终完整区间计算，这是旧口径而非新业务决定。
     *
     * @param schedule DAO 排班快照，例如 startTime=2026-07-03T09:00；无排班传 null
     * @param applicableRule DAO 生效规则，例如 standardDailyMinutes=480、overtimeEnabled=true
     * @param finalClockIn 已审批上班时间，例如 2026-07-03T09:00
     * @param finalClockOut 已审批下班时间，例如 2026-07-03T18:30
     * @param finalBreakMinutes 已审批扣休分钟，例如 60
     * @return 全字段结果 Map，例如 actualWorkMinutes=510、overtimeMinutes=30、exceptionFlag=false
     * @throws NumberFormatException 当规则数字无法解析，例如 roundingUnitMinutes=invalid
     */
    public static Map<String, Object> calculateFromResolvedFinal(
            Map<String, Object> schedule,
            Map<String, Object> applicableRule,
            LocalDateTime finalClockIn,
            LocalDateTime finalClockOut,
            Integer finalBreakMinutes) {
        CalculationResult result = buildBaseResult(schedule, applicableRule);
        result.actualClockIn = finalClockIn;
        result.actualClockOut = finalClockOut;
        result.actualBreakMinutes = intValue(finalBreakMinutes);
        result.finalBreakMinutes = intValue(finalBreakMinutes);
        result.actualWorkMinutes =
                roundMinutes(
                        calculateActualWorkMinutes(
                                finalClockIn, finalClockOut, result.finalBreakMinutes),
                        applicableRule);
        // 审批后没有逐段休息区间，只能按最终上下班重建一个总工作区间，再用统一口径计算深夜与休日。
        List<TimeRange> resolvedWorkRanges =
                finalClockIn != null && finalClockOut != null && finalClockOut.isAfter(finalClockIn)
                        ? List.of(new TimeRange(finalClockIn, finalClockOut))
                        : List.of();
        applyCompletedWorkMetrics(result, applicableRule, resolvedWorkRanges, false);
        return toMap(result);
    }

    /**
     * 统一初始化一份可复用的计算结果对象，确保初算与审批后重算使用相同的基础字段来源。
     *
     * @return 带排班、适用规则来源及空日志/异常列表的独立计算对象。
     * @param schedule 当日排班字段；null表示无排班。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static CalculationResult buildBaseResult(
            Map<String, Object> schedule, Map<String, Object> applicableRule) {
        CalculationResult result = new CalculationResult();
        result.logs = new ArrayList<>();
        result.exceptions = new ArrayList<>();
        result.workDayType =
                schedule == null
                        ? "NO_SCHEDULE"
                        : defaultText(
                                stringValue(readMapValue(schedule, "workDayType")), "WORKDAY");
        result.shiftScheduleId =
                schedule == null ? null : longValue(readMapValue(schedule, "shiftScheduleId"));
        result.scheduledStartTime =
                schedule == null ? null : dateTimeValue(readMapValue(schedule, "startTime"));
        result.scheduledEndTime =
                schedule == null ? null : dateTimeValue(readMapValue(schedule, "endTime"));
        result.scheduledBreakMinutes =
                schedule == null ? 0 : intValue(intValue(readMapValue(schedule, "breakMinutes")));
        result.scheduledWorkMinutes = calculateScheduledWorkMinutes(schedule);
        result.appliedRuleId = longValue(readMapValue(applicableRule, "ruleId"));
        result.appliedRuleName = stringValue(readMapValue(applicableRule, "ruleName"));
        return result;
    }

    /**
     * 完整上下班场景下统一计算迟到、早退、深夜、休日和残业，避免初算与审批后重算分叉维护。
     *
     * @param result 本次计算结果对象，日志或分钟字段在当前内存对象中更新。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     * @param workRanges 扣除休息后的实际工作区间。
     * @param allowAttendanceExceptions 是否按初算口径记录出勤异常；审批重算传false。
     */
    private static void applyCompletedWorkMetrics(
            CalculationResult result,
            Map<String, Object> applicableRule,
            List<TimeRange> workRanges,
            boolean allowAttendanceExceptions) {
        result.lateMinutes = calculateLateMinutes(result.actualClockIn, result.scheduledStartTime);
        result.earlyLeaveMinutes =
                calculateEarlyLeaveMinutes(result.actualClockOut, result.scheduledEndTime);
        result.nightWorkMinutes = calculateNightWorkMinutes(workRanges, applicableRule);
        result.holidayType = resolveHolidayType(result.workDayType);
        if (result.holidayType != null) {
            result.status = "HOLIDAY_WORK";
            result.exceptionFlag = allowAttendanceExceptions;
            result.holidayWorkMinutes = result.actualWorkMinutes;
            result.overtimeMinutes = result.actualWorkMinutes;
            result.legalOvertimeMinutes =
                    Objects.equals(HOLIDAY_TYPE_LEGAL, result.holidayType)
                            ? result.actualWorkMinutes
                            : 0;
            result.normalWorkMinutes = 0;
            if (allowAttendanceExceptions) {
                result.calcMessage = "休息日存在有效打卡。";
                result.exceptions.add(
                        new ExceptionPlan("HOLIDAY_WORK", "WARN", "休息日检测到有效打卡。", "查看原始打卡"));
                result.logs.add("当前工作日类型命中 " + result.holidayType + "，因此把当天全部工时记入休日出勤。");
            }
            return;
        }
        int standardDailyMinutes =
                resolveStandardDailyMinutes(result.scheduledWorkMinutes, applicableRule);
        result.normalWorkMinutes = Math.min(result.actualWorkMinutes, standardDailyMinutes);
        result.overtimeMinutes =
                calculateOvertimeMinutes(
                        result.actualWorkMinutes, standardDailyMinutes, applicableRule);
        result.legalOvertimeMinutes = result.overtimeMinutes;
        if (allowAttendanceExceptions && result.lateMinutes > 0) {
            result.status = "LATE";
            result.exceptionFlag = true;
            result.calcMessage = "实际上班晚于计划开始。";
            result.exceptions.add(
                    new ExceptionPlan(
                            "LATE",
                            "WARN",
                            "实际上班时间晚于计划开始 " + result.lateMinutes + " 分钟。",
                            "查看原始打卡"));
            result.logs.add("实际上班时间晚于计划开始 " + result.lateMinutes + " 分钟，因此判定为迟到。");
            if (result.earlyLeaveMinutes > 0) {
                result.exceptions.add(
                        new ExceptionPlan(
                                "EARLY_LEAVE",
                                "WARN",
                                "实际下班时间早于计划结束 " + result.earlyLeaveMinutes + " 分钟。",
                                "查看原始打卡"));
                result.logs.add("同时检测到早退 " + result.earlyLeaveMinutes + " 分钟。");
            }
            return;
        }
        if (allowAttendanceExceptions && result.earlyLeaveMinutes > 0) {
            result.status = "EARLY_LEAVE";
            result.exceptionFlag = true;
            result.calcMessage = "实际下班早于计划结束。";
            result.exceptions.add(
                    new ExceptionPlan(
                            "EARLY_LEAVE",
                            "WARN",
                            "实际下班时间早于计划结束 " + result.earlyLeaveMinutes + " 分钟。",
                            "查看原始打卡"));
            result.logs.add("实际下班时间早于计划结束 " + result.earlyLeaveMinutes + " 分钟，因此判定为早退。");
            return;
        }
        result.status = "NORMAL";
        result.exceptionFlag = false;
        result.calcMessage =
                allowAttendanceExceptions ? "按完整上下班卡生成正常日次结果。" : "审批修改最终时间后已按统一规则刷新结果。";
        if (allowAttendanceExceptions) {
            result.logs.add(
                    "规则计算结果：正常工时 "
                            + result.normalWorkMinutes
                            + " 分钟，残业 "
                            + result.overtimeMinutes
                            + " 分钟，深夜 "
                            + result.nightWorkMinutes
                            + " 分钟。");
            result.logs.add("已取得完整上下班卡，且无迟到早退，因此判定为正常。");
        }
    }

    /**
     * 统一记录初始出勤识别结果，避免日志口径在两套算法之间漂移。
     *
     * @param result 本次计算结果对象，日志或分钟字段在当前内存对象中更新。
     */
    private static void appendBasePresenceLogs(CalculationResult result) {
        if (result.actualClockIn != null) {
            result.logs.add("已选中最早上班卡：" + result.actualClockIn);
        }
        if (result.actualClockOut != null) {
            result.logs.add("已选中最晚下班卡：" + result.actualClockOut);
        }
        if (result.finalBreakMinutes > result.actualBreakMinutes) {
            result.logs.add("人工休息不足时已按正式规则补足自动休息至 " + result.finalBreakMinutes + " 分钟。");
        } else {
            result.logs.add("当天最终休息分钟为 " + result.finalBreakMinutes + " 分钟。");
        }
    }

    /**
     * 计算计划工时分钟，用于缺勤、标准工时和后续残业判断。
     *
     * @return 起止时间跨度减计划休息的非负分钟；无完整排班返回0。
     * @param schedule 当日排班字段；null表示无排班。
     */
    private static Integer calculateScheduledWorkMinutes(Map<String, Object> schedule) {
        if (schedule == null
                || dateTimeValue(readMapValue(schedule, "startTime")) == null
                || dateTimeValue(readMapValue(schedule, "endTime")) == null) {
            return 0;
        }
        return Math.max(
                0,
                (int)
                                Duration.between(
                                                dateTimeValue(readMapValue(schedule, "startTime")),
                                                dateTimeValue(readMapValue(schedule, "endTime")))
                                        .toMinutes()
                        - intValue(intValue(readMapValue(schedule, "breakMinutes"))));
    }

    /**
     * 把休息开始和结束打卡收口成成对区间，供自动休息、深夜交集和净工作区间共用。
     *
     * @return 起止有效的休息配对区间，按开始时间排序。
     * @param breakStarts 休息开始卡列表，按现有列表顺序配对。
     * @param breakEnds 休息结束卡列表，按现有列表顺序配对。
     */
    private static List<TimeRange> buildBreakRanges(
            List<Map<String, Object>> breakStarts, List<Map<String, Object>> breakEnds) {
        int pairCount = Math.min(breakStarts.size(), breakEnds.size());
        List<TimeRange> ranges = new ArrayList<>();
        for (int index = 0; index < pairCount; index++) {
            LocalDateTime start = dateTimeValue(readMapValue(breakStarts.get(index), "punchTime"));
            LocalDateTime end = dateTimeValue(readMapValue(breakEnds.get(index), "punchTime"));
            if (start == null || end == null || !end.isAfter(start)) {
                continue;
            }
            ranges.add(new TimeRange(start, end));
        }
        ranges.sort(Comparator.comparing(TimeRange::start));
        return ranges;
    }

    /**
     * 休息只扣有效出勤区间的交集，复用净工作区间合并口径以免重叠休息重复扣除。
     *
     * @param breakRanges 原始打卡配对区间，例如19:00至21:00，不改写原始打卡。
     * @param actualClockIn 最早真实上班卡，例如2026-10-04T09:00。
     * @param actualClockOut 最晚真实下班卡，例如2026-10-04T18:45。
     * @return 实际休息分钟，例如下班后19:00至21:00返回0；18:00至19:30返回45。
     * 副作用示例：缺任一上下班卡时保留既有休息配对分钟供缺卡展示，无数据库写入。
     */
    private static Integer calculateBreakMinutes(
            List<TimeRange> breakRanges,
            LocalDateTime actualClockIn,
            LocalDateTime actualClockOut) {
        if (actualClockIn == null || actualClockOut == null) {
            // 缺卡还没有完整有效出勤区间，保留原展示信息并由原缺卡分支处理。
            int totalMinutes = 0;
            for (TimeRange breakRange : breakRanges) {
                totalMinutes += breakRange.minutes();
            }
            return totalMinutes;
        }
        // 同一净工作区间同时用于休息扣除和深夜交集，区间外或重叠休息不能多扣工时。
        int workMinutes = 0;
        for (TimeRange workRange : buildWorkRanges(actualClockIn, actualClockOut, breakRanges)) {
            workMinutes += workRange.minutes();
        }
        int spanMinutes = Math.max(0, (int) Duration.between(actualClockIn, actualClockOut).toMinutes());
        return Math.max(0, spanMinutes - workMinutes);
    }

    /**
     * 自动休息优先保留人工休息；只有不足阈值时才补足到规则要求的最小扣休分钟。
     *
     * @return 既有人工或规则自动补足后的休息分钟，不改变阈值。
     * @param actualClockIn 实际或审批最终上班时间；null表示缺卡。
     * @param actualClockOut 实际或审批最终下班时间；null表示缺卡。
     * @param actualBreakMinutes 人工休息分钟；null按既有零值转换。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static Integer resolveFinalBreakMinutes(
            LocalDateTime actualClockIn,
            LocalDateTime actualClockOut,
            Integer actualBreakMinutes,
            Map<String, Object> applicableRule) {
        int manualBreakMinutes = intValue(actualBreakMinutes);
        if (actualClockIn == null || actualClockOut == null) {
            return manualBreakMinutes;
        }
        if (!booleanValue(readMapValue(applicableRule, "autoBreakEnabled"))) {
            return manualBreakMinutes;
        }
        int thresholdMinutes = intValue(readMapValue(applicableRule, "autoBreakThresholdMinutes"));
        int deductMinutes = intValue(readMapValue(applicableRule, "autoBreakDeductMinutes"));
        if (thresholdMinutes <= 0 || deductMinutes <= 0) {
            return manualBreakMinutes;
        }
        int attendanceSpanMinutes =
                Math.max(0, (int) Duration.between(actualClockIn, actualClockOut).toMinutes());
        if (attendanceSpanMinutes < thresholdMinutes) {
            return manualBreakMinutes;
        }
        return Math.max(manualBreakMinutes, deductMinutes);
    }

    /**
     * 计算实际工时分钟，只有完整上下班区间时才输出有效值。
     *
     * @return 完整上下班跨度减休息的非负分钟；缺任一时间返回0。
     * @param actualClockIn 实际或审批最终上班时间；null表示缺卡。
     * @param actualClockOut 实际或审批最终下班时间；null表示缺卡。
     * @param breakMinutes 扣除的休息分钟；null按零处理。
     */
    private static Integer calculateActualWorkMinutes(
            LocalDateTime actualClockIn, LocalDateTime actualClockOut, Integer breakMinutes) {
        if (actualClockIn == null || actualClockOut == null) {
            return 0;
        }
        return Math.max(
                0,
                (int) Duration.between(actualClockIn, actualClockOut).toMinutes()
                        - intValue(breakMinutes));
    }

    /**
     * 工作区间先减去休息区间，后续深夜交集和休日工时都统一基于这些净工作区间计算。
     *
     * @return 扣除有效休息后的净工作区间；起止缺失或无正跨度返回空列表。
     * @param actualClockIn 实际或审批最终上班时间；null表示缺卡。
     * @param actualClockOut 实际或审批最终下班时间；null表示缺卡。
     * @param breakRanges 已配对休息区间。
     */
    private static List<TimeRange> buildWorkRanges(
            LocalDateTime actualClockIn,
            LocalDateTime actualClockOut,
            List<TimeRange> breakRanges) {
        List<TimeRange> workRanges = new ArrayList<>();
        if (actualClockIn == null
                || actualClockOut == null
                || !actualClockOut.isAfter(actualClockIn)) {
            return workRanges;
        }
        LocalDateTime cursor = actualClockIn;
        for (TimeRange breakRange : breakRanges) {
            if (!breakRange.end().isAfter(cursor)) {
                continue;
            }
            if (breakRange.start().isAfter(actualClockOut)) {
                break;
            }
            LocalDateTime segmentEnd =
                    breakRange.start().isBefore(actualClockOut)
                            ? breakRange.start()
                            : actualClockOut;
            if (segmentEnd.isAfter(cursor)) {
                workRanges.add(new TimeRange(cursor, segmentEnd));
            }
            if (breakRange.end().isAfter(cursor)) {
                cursor =
                        breakRange.end().isAfter(actualClockOut)
                                ? actualClockOut
                                : breakRange.end();
            }
        }
        if (actualClockOut.isAfter(cursor)) {
            workRanges.add(new TimeRange(cursor, actualClockOut));
        }
        return workRanges;
    }

    /**
     * 深夜工时按配置时段逐日求交集，兼容 22:00-05:00 这种跨日夜勤窗口。
     *
     * @return 净工作区间与已配置深夜窗口逐日交集分钟；未启用返回0。
     * @param workRanges 扣除休息后的实际工作区间。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static Integer calculateNightWorkMinutes(
            List<TimeRange> workRanges, Map<String, Object> applicableRule) {
        if (!booleanValue(readMapValue(applicableRule, "nightWorkEnabled"))
                || workRanges.isEmpty()) {
            return 0;
        }
        LocalTime nightStart =
                parseLocalTime(readMapValue(applicableRule, "nightWorkStart"), LocalTime.of(22, 0));
        LocalTime nightEnd =
                parseLocalTime(readMapValue(applicableRule, "nightWorkEnd"), LocalTime.of(5, 0));
        int totalMinutes = 0;
        for (TimeRange workRange : workRanges) {
            LocalDate cursorDate = workRange.start().toLocalDate().minusDays(1);
            LocalDate endDate = workRange.end().toLocalDate();
            while (!cursorDate.isAfter(endDate)) {
                LocalDateTime nightWindowStart = LocalDateTime.of(cursorDate, nightStart);
                LocalDateTime nightWindowEnd = LocalDateTime.of(cursorDate, nightEnd);
                if (!nightEnd.isAfter(nightStart)) {
                    nightWindowEnd = nightWindowEnd.plusDays(1);
                }
                totalMinutes +=
                        overlapMinutes(
                                workRange.start(),
                                workRange.end(),
                                nightWindowStart,
                                nightWindowEnd);
                cursorDate = cursorDate.plusDays(1);
            }
        }
        return totalMinutes;
    }

    /**
     * 休日类型先按班次的工作日分类判断，把法定休日和所定休日沉淀成两档常量。
     *
     * @return 法定/所定休日既有分类常量；未知或空类型返回null。
     * @param workDayType 排班工作日类型字符串。
     */
    private static String resolveHolidayType(String workDayType) {
        if (!hasText(workDayType)) {
            return null;
        }
        String normalized = workDayType.trim().toUpperCase(Locale.ROOT);
        if (Objects.equals("LEGAL_HOLIDAY", normalized)
                || Objects.equals("STATUTORY_HOLIDAY", normalized)) {
            return HOLIDAY_TYPE_LEGAL;
        }
        if (Objects.equals("REST", normalized)
                || Objects.equals("OFF", normalized)
                || Objects.equals("HOLIDAY", normalized)
                || Objects.equals("SCHEDULED_HOLIDAY", normalized)) {
            return HOLIDAY_TYPE_SCHEDULED;
        }
        return null;
    }

    /**
     * 工作日标准工时优先按正式规则读取，未配置时回落到排班计划工时。
     *
     * @return 正数规则标准工时；否则回退非负计划工时。
     * @param scheduledWorkMinutes 计划工时分钟，无排班按零处理。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static int resolveStandardDailyMinutes(
            Integer scheduledWorkMinutes, Map<String, Object> applicableRule) {
        int standardDailyMinutes = intValue(readMapValue(applicableRule, "standardDailyMinutes"));
        if (standardDailyMinutes > 0) {
            return standardDailyMinutes;
        }
        return Math.max(0, intValue(scheduledWorkMinutes));
    }

    /**
     * 第一版残业先按超出规则标准工时的分钟数计算，并尊重员工规则里的残业开关。
     *
     * @return 开启残业时超出非负标准工时的分钟；未开启返回0。
     * @param actualWorkMinutes 实际工时分钟。
     * @param standardDailyMinutes 标准日工时分钟，负数按零参与残业判断。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static Integer calculateOvertimeMinutes(
            Integer actualWorkMinutes,
            int standardDailyMinutes,
            Map<String, Object> applicableRule) {
        if (!booleanValue(readMapValue(applicableRule, "overtimeEnabled"))) {
            return 0;
        }
        return Math.max(0, intValue(actualWorkMinutes) - Math.max(0, standardDailyMinutes));
    }

    /**
     * 取整规则统一落在分钟层，保持前后端和导出结果看到的是同一套分钟值。
     *
     * @return 按现有ROUND_UP/ROUND_DOWN/ROUND_NEAREST处理的分钟；配置无效返回原值。
     * @param minutes 待按规则取整的分钟值。
     * @param applicableRule 当前适用规则字段；保留既有缺规则回退口径。
     */
    private static Integer roundMinutes(Integer minutes, Map<String, Object> applicableRule) {
        int originalMinutes = intValue(minutes);
        int unitMinutes = intValue(readMapValue(applicableRule, "roundingUnitMinutes"));
        String roundingMode = stringValue(readMapValue(applicableRule, "roundingMode"));
        if (originalMinutes <= 0 || unitMinutes <= 0 || !hasText(roundingMode)) {
            return originalMinutes;
        }
        double base = (double) originalMinutes / unitMinutes;
        return switch (roundingMode) {
            case "ROUND_UP" -> (int) Math.ceil(base) * unitMinutes;
            case "ROUND_DOWN" -> (int) Math.floor(base) * unitMinutes;
            case "ROUND_NEAREST" -> (int) Math.round(base) * unitMinutes;
            default -> originalMinutes;
        };
    }

    /**
     * 统一计算两个时间窗交集分钟，避免深夜等算法各写一套边界判断。
     *
     * @return 两个时间窗交集分钟，无正交集返回0。
     * @param startA 第一个时间窗开始。
     * @param endA 第一个时间窗结束。
     * @param startB 第二个时间窗开始。
     * @param endB 第二个时间窗结束。
     */
    private static int overlapMinutes(
            LocalDateTime startA, LocalDateTime endA, LocalDateTime startB, LocalDateTime endB) {
        LocalDateTime overlapStart = startA.isAfter(startB) ? startA : startB;
        LocalDateTime overlapEnd = endA.isBefore(endB) ? endA : endB;
        if (!overlapEnd.isAfter(overlapStart)) {
            return 0;
        }
        return (int) Duration.between(overlapStart, overlapEnd).toMinutes();
    }

    /**
     * 统一解析 HH:mm 规则时间，解析失败时直接回到默认值，避免脏规则把整次重算打断。
     *
     * @return 解析后的LocalTime；空值或解析失败返回默认值。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @param defaultValue 空值或时间解析失败时使用的默认值。
     */
    private static LocalTime parseLocalTime(Object value, LocalTime defaultValue) {
        String text = stringValue(value);
        if (!hasText(text)) {
            return defaultValue;
        }
        try {
            return LocalTime.parse(text);
        } catch (DateTimeParseException error) {
            return defaultValue;
        }
    }

    /**
     * 计算迟到分钟，只有计划开始和实际上班同时存在时才有效。
     *
     * @return 实际上班晚于计划开始的分钟，缺时间或未晚到返回0。
     * @param actualClockIn 实际或审批最终上班时间；null表示缺卡。
     * @param scheduledStartTime 排班计划开始时间。
     */
    private static Integer calculateLateMinutes(
            LocalDateTime actualClockIn, LocalDateTime scheduledStartTime) {
        if (actualClockIn == null
                || scheduledStartTime == null
                || !actualClockIn.isAfter(scheduledStartTime)) {
            return 0;
        }
        return (int) Duration.between(scheduledStartTime, actualClockIn).toMinutes();
    }

    /**
     * 计算早退分钟，只有计划结束和实际下班同时存在时才有效。
     *
     * @return 实际下班早于计划结束的分钟，缺时间或未早退返回0。
     * @param actualClockOut 实际或审批最终下班时间；null表示缺卡。
     * @param scheduledEndTime 排班计划结束时间。
     */
    private static Integer calculateEarlyLeaveMinutes(
            LocalDateTime actualClockOut, LocalDateTime scheduledEndTime) {
        if (actualClockOut == null
                || scheduledEndTime == null
                || !actualClockOut.isBefore(scheduledEndTime)) {
            return 0;
        }
        return (int) Duration.between(actualClockOut, scheduledEndTime).toMinutes();
    }

    /**
     * 对可能为空的文本做统一默认值回填。
     *
     * @return 去除首尾空白后的非空文本；否则返回默认文本。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     * @param defaultValue 空值或时间解析失败时使用的默认值。
     */
    private static String defaultText(String value, String defaultValue) {
        String normalized = value == null ? "" : value.trim();
        return hasText(normalized) ? normalized : defaultValue;
    }

    /**
     * 把任意对象安全转成 long，供规则主键等字段稳定回读。
     *
     * @return Number或字符串转换的Long；null返回null，非法文本保留解析异常。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     */
    private static Long longValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Number number) {
            return number.longValue();
        }
        return Long.parseLong(String.valueOf(value));
    }

    /**
     * 把任意对象安全转成 int，供分钟计算复用。
     *
     * @return Number或字符串转换的int；null返回0，非法文本保留解析异常。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     */
    private static int intValue(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number number) {
            return number.intValue();
        }
        return Integer.parseInt(String.valueOf(value));
    }

    /**
     * 把任意对象安全转成字符串，供规则字段和日志分支复用。
     *
     * @return 值的字符串表示；null返回空串。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     */
    private static String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value);
    }

    /**
     * 兼容数据库里 TINYINT、BOOLEAN 和字符串三种布尔返回值。
     *
     * @return 既有布尔/数字/字符串规则转换结果；null返回false。
     * @param value 待转换的字段值；null沿用本方法已有回退。
     */
    private static boolean booleanValue(Object value) {
        if (value == null) {
            return false;
        }
        if (value instanceof Boolean booleanValue) {
            return booleanValue;
        }
        if (value instanceof Number numberValue) {
            return numberValue.intValue() != 0;
        }
        String text = stringValue(value);
        return Objects.equals("true", text.toLowerCase(Locale.ROOT)) || Objects.equals("1", text);
    }

    /**
     * 兼容 SQL Map 键名大小写差异，避免规则字段因驱动差异读不到。
     *
     * @return 首个匹配键对应值；来源或键缺失以及无匹配均返回null。
     * @param source 字段来源Map；在差异报告中则为1起始来源行号，0表示无行。
     * @param preferredKey 首选字段名，按原样/大写/小写依次查找。
     */
    private static Object readMapValue(Map<String, Object> source, String preferredKey) {
        if (source == null || preferredKey == null) {
            return null;
        }
        if (source.containsKey(preferredKey)) {
            return source.get(preferredKey);
        }
        String upperKey = preferredKey.toUpperCase(Locale.ROOT);
        if (source.containsKey(upperKey)) {
            return source.get(upperKey);
        }
        String lowerKey = preferredKey.toLowerCase(Locale.ROOT);
        if (source.containsKey(lowerKey)) {
            return source.get(lowerKey);
        }
        return null;
    }

    // 聚合一次日次计算产出的所有字段和解释信息，供初算和审批后重算共享。
    static final class CalculationResult {
        Long shiftScheduleId;
        String workDayType;
        LocalDateTime scheduledStartTime;
        LocalDateTime scheduledEndTime;
        Integer scheduledBreakMinutes;
        Integer scheduledWorkMinutes;
        LocalDateTime actualClockIn;
        LocalDateTime actualClockOut;
        Integer actualBreakMinutes = 0;
        Integer finalBreakMinutes = 0;
        Integer actualWorkMinutes = 0;
        Integer lateMinutes = 0;
        Integer earlyLeaveMinutes = 0;
        Integer absenceMinutes = 0;
        Integer normalWorkMinutes = 0;
        Integer overtimeMinutes = 0;
        Integer legalOvertimeMinutes = 0;
        Integer nightWorkMinutes = 0;
        Integer holidayWorkMinutes = 0;
        String holidayType;
        Long appliedRuleId;
        String appliedRuleName;
        String status;
        Boolean exceptionFlag = false;
        String calcMessage;
        List<String> logs;
        List<ExceptionPlan> exceptions;
    }

    // 用统一的开始结束时间表达工作区间和休息区间，便于深夜交集和工时扣减复用。
    private record TimeRange(LocalDateTime start, LocalDateTime end) {

        /**
         * 计算本时间区间的非负分钟，不改变原始时间。
         *
         * @return 当前开始/结束跨度的非负分钟。
         */
        private int minutes() {
            return Math.max(0, (int) Duration.between(start, end).toMinutes());
        }
    }

    // 记录一条异常计划，供重算后统一写入异常表。
    record ExceptionPlan(
            String exceptionType, String exceptionLevel, String message, String suggestedAction) { }

    /**
     * 转换一次计算结果，不引入业务私有 HTTP DTO，也不读写数据库。
     *
     * @param result 原算法内部结果，例如 actualWorkMinutes=510、overtimeMinutes=30
     * @return 全字段 Map，例如 status=NORMAL、actualWorkMinutes=510、overtimeMinutes=30
     */
    private static Map<String, Object> toMap(CalculationResult result) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("shiftScheduleId", result.shiftScheduleId);
        out.put("workDayType", result.workDayType);
        out.put("scheduledStartTime", result.scheduledStartTime);
        out.put("scheduledEndTime", result.scheduledEndTime);
        out.put("scheduledBreakMinutes", result.scheduledBreakMinutes);
        out.put("scheduledWorkMinutes", result.scheduledWorkMinutes);
        out.put("actualClockIn", result.actualClockIn);
        out.put("actualClockOut", result.actualClockOut);
        out.put("actualBreakMinutes", result.actualBreakMinutes);
        out.put("finalBreakMinutes", result.finalBreakMinutes);
        out.put("actualWorkMinutes", result.actualWorkMinutes);
        out.put("lateMinutes", result.lateMinutes);
        out.put("earlyLeaveMinutes", result.earlyLeaveMinutes);
        out.put("absenceMinutes", result.absenceMinutes);
        out.put("normalWorkMinutes", result.normalWorkMinutes);
        out.put("overtimeMinutes", result.overtimeMinutes);
        out.put("legalOvertimeMinutes", result.legalOvertimeMinutes);
        out.put("nightWorkMinutes", result.nightWorkMinutes);
        out.put("holidayWorkMinutes", result.holidayWorkMinutes);
        out.put("holidayType", result.holidayType);
        out.put("appliedRuleId", result.appliedRuleId);
        out.put("appliedRuleName", result.appliedRuleName);
        out.put("status", result.status);
        out.put("exceptionFlag", result.exceptionFlag);
        out.put("calcMessage", result.calcMessage);
        out.put("logs", result.logs);
        List<Map<String, Object>> exceptions = new ArrayList<>();
        for (ExceptionPlan exception : result.exceptions) {
            exceptions.add(
                    Map.of(
                            "exceptionType",
                            exception.exceptionType(),
                            "exceptionLevel",
                            exception.exceptionLevel(),
                            "message",
                            exception.message(),
                            "suggestedAction",
                            exception.suggestedAction()));
        }
        out.put("exceptions", exceptions);
        return out;
    }

    /**
     * 将排班与打卡 Map 中的数据库时间转成无时区业务时间，保留旧算法时区边界。
     *
     * @param value DAO 时间值，例如 2026-07-03T09:00；null 表示缺卡
     * @return LocalDateTime，例如 2026-07-03T09:00；null 保持 null
     * @throws java.time.format.DateTimeParseException 当时间文本无法解析，例如 invalid-date
     */
    private static LocalDateTime dateTimeValue(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof LocalDateTime dateTime) {
            return dateTime;
        }
        if (value instanceof java.sql.Timestamp timestamp) {
            return timestamp.toLocalDateTime();
        }
        return LocalDateTime.parse(String.valueOf(value).replace(' ', 'T'));
    }

    /**
     * 等价替换 Spring StringUtils.hasText 的字符串判定，计算器不依赖容器。
     *
     * @param value 排班或规则文本，例如 WORKDAY
     * @return 非空白返回 true，例如 WORKDAY -> true；空格 -> false
     */
    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
