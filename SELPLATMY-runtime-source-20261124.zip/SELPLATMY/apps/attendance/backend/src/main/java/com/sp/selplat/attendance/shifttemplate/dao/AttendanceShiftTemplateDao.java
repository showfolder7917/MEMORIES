package com.sp.selplat.attendance.shifttemplate.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceShiftTemplate 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceShiftTemplateDao extends BaseDao {
    /**
     * 当前模板编辑与排班引用共用真实行锁。
     *
     * @param input 服务端租户/主键例如81/8901
     * @return 实际行例如revision=0、crossDay=1；无匹配null，仅行锁不写数据
     */
    java.util.Map<String, Object> lockTemplate(com.sp.selplat.common.util.CommonParam input);

    /**
     * 在真实排班事务标记曾引用保护，不修改时间或计算字段。
     *
     * @param input 已锁定范围例如tenantId=81、id=8901
     * @return 实际影响数例如1；随同源事务回滚，无历史结果写入
     */
    int markReferenced(com.sp.selplat.common.util.CommonParam input);
}
