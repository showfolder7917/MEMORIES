/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：考勤本域原配置纯读合同，不包含执行许可或写回调。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 原配置拥有方提供完整读取，资格、租户和引用算法仍由本域维护。 */
public interface AttendanceConfigurationReadAccess {

  /**
   * 方法作用：读取真实管理范围分页，交付前重核资格。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原分页，例如records及totalCount4，无写入
   */
  CommonPageResult readStore(CommonPageParam input);

  /**
   * 方法作用：读取原详情和保留引用保护事实，不提供修改许可。
   *
   * @param input 原主键，例如id8501
   * @return 原详情，例如data.configurationProtected为true
   */
  CommonResult readById(CommonParam input);

  /**
   * 方法作用：复用原配置及元数据表头，保持语言和查看资格。
   *
   * @param viewCode 原编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns包含配置名称
   */
  CommonResult readGridColumn(String viewCode, String locale);

  /**
   * 方法作用：读取原批量详情并在交付前重核资格，保持原逐项归属及顺序
   *
   * @param input 原JSON items，例如62000、62001、62000
   * @return 原CommonResult.data三行，空批返回空列表，不提供写能力
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult readByIds(
      com.sp.selplat.common.util.CommonBatchParam input);
}
