/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
/* 2026-11-01：打卡与批次原管理读取HTTP接入，原写保护保持。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 文件：AttendanceTenantManagementAspect.java；职责：原管理服务在事务前接既有租户管理员；2026-10-27。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceTenantManagementExecution;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.Set;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/** 仅原考勤管理拥有方进入角色提交保护，独立审批和发布检查仍在原Service内执行。 */
@Aspect
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 100)
public class AttendanceTenantManagementAspect {

  // 仅显式审计的员工纯读方法不进入本地提交回调；它们自己执行前后只读资格检查。
  private static final Set<java.lang.reflect.Method> READS =
      Set.of(
          configurationRead(
              com.sp.selplat.attendance.capability.accountbinding.service.impl
                  .AttendanceAccountBindingServiceImpl.class,
              "readAccounts",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.capability.accountbinding.service.impl
                  .AttendanceAccountBindingServiceImpl.class,
              "readState",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.capability.accountbinding.service.impl
                  .AttendanceAccountBindingServiceImpl.class,
              "readMigrationPreflight",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employee.service.impl.AttendanceEmployeeServiceImpl.class,
              "readLockForAccountBinding",
              com.sp.selplat.common.util.CommonParam.class),
          readMethod("readStore", com.sp.selplat.common.util.CommonPageParam.class),
          readMethod("readById", com.sp.selplat.common.util.CommonParam.class),
          readMethod("readPersonReference", com.sp.selplat.common.util.CommonParam.class),
          readMethod("readGridColumn", String.class, String.class),
          configurationRead(
              com.sp.selplat.attendance.ruleconfig.service.impl.AttendanceRuleConfigServiceImpl
                  .class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.ruleconfig.service.impl.AttendanceRuleConfigServiceImpl
                  .class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.ruleconfig.service.impl.AttendanceRuleConfigServiceImpl
                  .class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.shifttemplate.service.impl
                  .AttendanceShiftTemplateServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.shifttemplate.service.impl
                  .AttendanceShiftTemplateServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.shifttemplate.service.impl
                  .AttendanceShiftTemplateServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "countRuleReferencesForRead",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "countRuleReferencesForRead",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "countTemplateReferencesForRead",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.exception.service.impl.AttendanceExceptionServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.exception.service.impl.AttendanceExceptionServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.exception.service.impl.AttendanceExceptionServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.calclog.service.impl.AttendanceCalcLogServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.calclog.service.impl.AttendanceCalcLogServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.calclog.service.impl.AttendanceCalcLogServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readOwnedStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readOwned",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readOwnedStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readOwned",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readReviewStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readReviewDetail",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readPreview",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readForApproval",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "readFindForApproval",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "readForApproval",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.ruleconfig.service.impl.AttendanceRuleConfigServiceImpl
                  .class,
              "readFindForApproval",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readOwnedStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readOwned",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readOwnedStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readOwnedFact",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readOwnedHistory",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readOwnedFact",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyactionlog.service.impl
                  .AttendanceMonthlyActionLogServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyactionlog.service.impl
                  .AttendanceMonthlyActionLogServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyactionlog.service.impl
                  .AttendanceMonthlyActionLogServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreleasereceipt.service.impl
                  .AttendanceMonthlyReleaseReceiptServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreleasereceipt.service.impl
                  .AttendanceMonthlyReleaseReceiptServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreleasereceipt.service.impl
                  .AttendanceMonthlyReleaseReceiptServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.capability.monthlyrelease.service.impl
                  .AttendanceMonthlyReleaseServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.capability.monthlyrelease.service.impl
                  .AttendanceMonthlyReleaseServiceImpl.class,
              "readCurrent",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readReleaseStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readLockForRelease",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employee.service.impl.AttendanceEmployeeServiceImpl.class,
              "readLockForRelease",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readReleaseItems",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyactionlog.service.impl
                  .AttendanceMonthlyActionLogServiceImpl.class,
              "readReleaseSource",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readReleaseFact",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readReleaseFact",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readReleaseHistory",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchsourceconfig.service.impl
                  .AttendancePunchSourceConfigServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchsourceconfig.service.impl
                  .AttendancePunchSourceConfigServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchsourceconfig.service.impl
                  .AttendancePunchSourceConfigServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.punchrawlog.service.impl.AttendancePunchRawLogServiceImpl
                  .class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchrawlog.service.impl.AttendancePunchRawLogServiceImpl
                  .class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchrawlog.service.impl.AttendancePunchRawLogServiceImpl
                  .class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.punchimportbatch.service.impl
                  .AttendancePunchImportBatchServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchimportbatch.service.impl
                  .AttendancePunchImportBatchServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchimportbatch.service.impl
                  .AttendancePunchImportBatchServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.schedulebatch.service.impl
                  .AttendanceScheduleBatchServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.schedulebatch.service.impl
                  .AttendanceScheduleBatchServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.schedulebatch.service.impl
                  .AttendanceScheduleBatchServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.caseactionlog.service.impl
                  .AttendanceCaseActionLogServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.caseactionlog.service.impl
                  .AttendanceCaseActionLogServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.caseactionlog.service.impl
                  .AttendanceCaseActionLogServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.employeeexternalmapping.service.impl
                  .AttendanceEmployeeExternalMappingServiceImpl.class,
              "readStore",
              com.sp.selplat.common.util.CommonPageParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeexternalmapping.service.impl
                  .AttendanceEmployeeExternalMappingServiceImpl.class,
              "readById",
              com.sp.selplat.common.util.CommonParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeexternalmapping.service.impl
                  .AttendanceEmployeeExternalMappingServiceImpl.class,
              "readGridColumn",
              String.class,
              String.class),
          configurationRead(
              com.sp.selplat.attendance.attendancecase.service.impl.AttendanceCaseServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.calclog.service.impl.AttendanceCalcLogServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.caseactionlog.service.impl
                  .AttendanceCaseActionLogServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.daily.service.impl.AttendanceDailyServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.employee.service.impl.AttendanceEmployeeServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeexternalmapping.service.impl
                  .AttendanceEmployeeExternalMappingServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.employeeworkrule.service.impl
                  .AttendanceEmployeeWorkRuleServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.exception.service.impl.AttendanceExceptionServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthly.service.impl.AttendanceMonthlyServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyactionlog.service.impl
                  .AttendanceMonthlyActionLogServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyitem.service.impl.AttendanceMonthlyItemServiceImpl
                  .class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlypublication.service.impl
                  .AttendanceMonthlyPublicationServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreleasereceipt.service.impl
                  .AttendanceMonthlyReleaseReceiptServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.monthlyreview.service.impl
                  .AttendanceMonthlyReviewServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchimportbatch.service.impl
                  .AttendancePunchImportBatchServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchrawlog.service.impl.AttendancePunchRawLogServiceImpl
                  .class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.punchsourceconfig.service.impl
                  .AttendancePunchSourceConfigServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.ruleconfig.service.impl.AttendanceRuleConfigServiceImpl
                  .class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.schedulebatch.service.impl
                  .AttendanceScheduleBatchServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.shiftschedule.service.impl
                  .AttendanceShiftScheduleServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class),
          configurationRead(
              com.sp.selplat.attendance.shifttemplate.service.impl
                  .AttendanceShiftTemplateServiceImpl.class,
              "readByIds",
              com.sp.selplat.common.util.CommonBatchParam.class));

  // 固定拥有方清单，不接收客户端类名、动作或角色；人员自有事务另在save接入。
  private static final Set<String> OWNERS =
      Set.of(
          "AttendanceCaseServiceImpl",
          "AttendanceCalcLogServiceImpl",
          "AttendanceAccountBindingServiceImpl",
          "AttendancePunchCommandServiceImpl",
          "AttendanceScheduleCommandServiceImpl",
          "AttendanceCalculationCommandServiceImpl",
          "AttendanceCaseActionLogServiceImpl",
          "AttendanceDailyServiceImpl",
          "AttendanceEmployeeServiceImpl",
          "AttendanceEmployeeExternalMappingServiceImpl",
          "AttendanceEmployeeWorkRuleServiceImpl",
          "AttendanceExceptionServiceImpl",
          "AttendanceMonthlyServiceImpl",
          "AttendanceMonthlyActionLogServiceImpl",
          "AttendanceMonthlyItemServiceImpl",
          "AttendanceMonthlyPublicationServiceImpl",
          "AttendanceMonthlyReleaseReceiptServiceImpl",
          "AttendanceMonthlyReviewServiceImpl",
          "AttendanceMonthlyReleaseServiceImpl",
          "AttendancePunchImportBatchServiceImpl",
          "AttendancePunchRawLogServiceImpl",
          "AttendancePunchSourceConfigServiceImpl",
          "AttendanceRuleConfigServiceImpl",
          "AttendanceScheduleBatchServiceImpl",
          "AttendanceShiftScheduleServiceImpl",
          "AttendanceShiftTemplateServiceImpl");

  // 共享原角色事务执行器，不自行创建资格、连接或Spring事务。
  private final AttendanceTenantManagementExecution execution;

  /**
   * 方法作用：绑定本域执行范围，切面不持有业务DAO。
   *
   * @param execution 本域真实执行器，例如管理员原员工保存保护 异常或副作用示例：构造不授权、不打开事务。
   */
  public AttendanceTenantManagementAspect(AttendanceTenantManagementExecution execution) {
    this.execution = execution;
  }

  /**
   * 方法作用：在原事务Advice之前包住固定管理Service，普通账号及其他Service保持原路径。
   *
   * @param invocation 实际代理调用，例如AttendanceEmployeeServiceImpl.insert
   * @return 真实返回示例：原CommonResult或原CommonPageResult，不改变接口JSON。
   * @throws Throwable 原业务错误原样传播；真实提交失败不返回成功
   * @throws com.sp.selplat.common.exception.CommonBusinessException 未显式接入的独立提交操作拒绝
   *     异常或副作用示例：管理角色到期撤销本域SQL，审批缺资格仍由原Service拒绝。
   */
  @Around("execution(public * com.sp.selplat.attendance..service.impl.*.*(..))")
  public Object protect(ProceedingJoinPoint invocation) throws Throwable {
    if (!OWNERS.contains(invocation.getTarget().getClass().getSimpleName())) {
      return invocation.proceed();
    }
    var method =
        org.springframework.aop.support.AopUtils.getMostSpecificMethod(
            ((org.aspectj.lang.reflect.MethodSignature) invocation.getSignature()).getMethod(),
            invocation.getTarget().getClass());
    if (READS.contains(method)) {
      return invocation.proceed();
    }
    var transaction =
        org.springframework.core.annotation.AnnotatedElementUtils.findMergedAnnotation(
            method, org.springframework.transaction.annotation.Transactional.class);
    // 原内部行锁必须已经处于调用者事务中，不能因租户管理员接入把MANDATORY变成新的入口。
    if (transaction != null
        && transaction.propagation()
            == org.springframework.transaction.annotation.Propagation.MANDATORY) {
      return invocation.proceed();
    }
    // 自行挂起或提前提交的拥有方必须像Person一样显式接入，不得被通用外层事务误保护。
    if (transaction != null
        && (transaction.propagation()
                == org.springframework.transaction.annotation.Propagation.REQUIRES_NEW
            || transaction.propagation()
                == org.springframework.transaction.annotation.Propagation.NOT_SUPPORTED)
        && execution.isAdministrator()) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "ATTENDANCE_MANAGEMENT_TRANSACTION_INVALID", "该考勤操作需要明确的独立提交保护。");
    }
    try {
      return execution.execute(
          () -> {
            try {
              return invocation.proceed();
            } catch (RuntimeException | Error failure) {
              throw failure;
            } catch (Throwable failure) {
              // Supplier不支持受检异常；只暂存原异常以便事务回滚，外层立即解包原类型。
              throw new UndeclaredThrowableException(failure);
            }
          });
    } catch (UndeclaredThrowableException failure) {
      throw failure.getUndeclaredThrowable();
    }
  }

  /**
   * 方法作用：固定原员工只读签名，签名变化即拒绝装配，不能靠方法名前缀放行。
   *
   * @param name 固定服务方法，例如readStore
   * @param parameters 固定DTO类型，例如CommonPageParam
   * @return 实际EmployeeServiceImpl方法，不接受客户端类名或方法名
   * @throws IllegalStateException 方法删除或签名不符时阻断，不落回未经审计的方法
   */
  private static java.lang.reflect.Method readMethod(String name, Class<?>... parameters) {
    try {
      return com.sp.selplat.attendance.employee.service.impl.AttendanceEmployeeServiceImpl.class
          .getMethod(name, parameters);
    } catch (NoSuchMethodException failure) {
      throw new IllegalStateException("员工只读合同与实际方法不一致。", failure);
    }
  }

  /**
   * 方法作用：只解析本次明确配置读取签名，不按前缀或控制器包放行。
   *
   * @param owner 原固定拥有方，例如AttendanceRuleConfigServiceImpl.class
   * @param name 固定纯读名称，例如readStore
   * @param parameters 原精确参数，例如CommonPageParam.class
   * @return 实际公开方法，例如readStore(CommonPageParam)
   * @throws IllegalStateException 原签名漂移时拒绝启动，不放宽匹配
   */
  private static java.lang.reflect.Method configurationRead(
      Class<?> owner, String name, Class<?>... parameters) {
    try {
      return owner.getMethod(name, parameters);
    } catch (NoSuchMethodException failure) {
      throw new IllegalStateException("考勤配置只读合同与源码不一致。", failure);
    }
  }
}
