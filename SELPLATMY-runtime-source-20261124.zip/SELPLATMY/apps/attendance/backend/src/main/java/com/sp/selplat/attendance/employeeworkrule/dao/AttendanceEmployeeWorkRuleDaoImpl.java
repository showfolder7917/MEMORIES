package com.sp.selplat.attendance.employeeworkrule.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceEmployeeWorkRule，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceEmployeeWorkRuleDaoImpl extends AttendanceBaseDao
        implements AttendanceEmployeeWorkRuleDao {
    /**
     * 读取本表真实引用数量，不跨表、不排除历史软删除行。
     *
     * @param input 已核验范围例如 tenantId=81、id=8501
     * @return 实际COUNT例如1，无业务写入；SQL失败保留数据库异常
     */
    @Override
    public long countRuleReferences(com.sp.selplat.common.util.CommonParam input) {
        // 使用本域事务连接执行本表COUNT，避免公共查询缓存丢失新提交事实。
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.queryForObject(
                "SELECT COUNT(*) FROM AttendanceEmployeeWorkRule WHERE tenantId=? AND (ruleId=? OR roundingRuleId=?)",
                Long.class,
                input.getParam("tenantId"),
                input.getParam("id"),
                input.getParam("id"));
    }

    /**
     * 员工共享锁内直接读取本表当前关联，不使用等待前缓存。
     *
     * @param input 已核验范围例如tenantId=81/employeeId=8801
     * @return 实际关联列表例如[{id:8401,ruleId:8501}]，不存在为空 异常或副作用示例：只查询本表启用关联，无写入或跨表DAO。
     */
    @Override
    public java.util.List<java.util.Map<String, Object>> currentEmployeeAssignments(
            com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.queryForList(
                "SELECT * FROM AttendanceEmployeeWorkRule WHERE tenantId=? AND employeeId=? AND status=1 ORDER BY effectiveStartDate,id",
                input.getParam("tenantId"),
                input.getParam("employeeId"));
    }
}
