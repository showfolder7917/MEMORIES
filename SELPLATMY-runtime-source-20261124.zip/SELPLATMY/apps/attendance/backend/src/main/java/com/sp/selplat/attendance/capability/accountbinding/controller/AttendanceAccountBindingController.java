package com.sp.selplat.attendance.capability.accountbinding.controller;

import com.sp.selplat.attendance.capability.accountbinding.service.AttendanceAccountBindingService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 只透传显式绑定命令，不将请求中的身份、状态或角色当作许可。 */
@RestController
@RequestMapping("/api/attendance/accountbinding")
public class AttendanceAccountBindingController {
  // 专用能力持有本域事务与真实许可校验。
  private final AttendanceAccountBindingService service;

  // 三读取按同一考勤身份模式选择；原execute继续独立写保护。
  private final com.sp.selplat.attendance.capability.accountbinding.service
          .AttendanceAccountBindingReadGateway
      reads;

  /**
   * 装配显式绑定能力。
   *
   * @param reads 固定三读取网关，例如原桥接或HTTP身份读取，不提供写许可
   * @param service 真实AttendanceAccountBindingServiceImpl 副作用示例：只保存依赖，不授予权限。
   */
  public AttendanceAccountBindingController(
      AttendanceAccountBindingService service,
      @org.springframework.beans.factory.annotation.Qualifier("attendanceAccountBindingReadGateway")
          com.sp.selplat.attendance.capability.accountbinding.service
                  .AttendanceAccountBindingReadGateway
              reads) {
    this.service = service;
    this.reads = reads;
  }

  /**
   * 只序列化旧员工账号显式关联的现有目录核验，不添加绑定或角色。
   *
   * @param input 明确候选，例如sourceAccountId=24/sourceType=1/userId=8104/employeeId=8801/mode=DRY_RUN
   * @return
   *     例如success=true,data={writeEnabled:false,mappingEvidenceVerified:false,targetFactsVerified:true}
   *     异常示例：无管理或目标BIND目录许可拒绝，未查真实旧账号。
   */
  @PostMapping("migrationPreflight.htm")
  public String migrationPreflight(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.migrationPreflight(input));
  }

  /**
   * 透传共通参数并返回完整安全业务结果。
   *
   * @param input userId=8101/employeeId=8801/action=BIND/requestKey=B1/expectedRevision=0
   * @return 完整JSON例如success=true/data.bindingRevision=1；缺权威目录返回明确拒绝
   */
  @PostMapping("execute.htm")
  public String execute(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.execute(input));
  }

  /**
   * 仅恢复非分页解析器排除的原始分页两项，数值校验仍由本域服务严格执行。
   *
   * @param input 实际pageNo1/pageSize20/actionBIND
   * @param request 原始form/query例如pageNo=2/pageSize=1；不恢复actor/tenant/org
   * @return 完整安全分页JSON例如records=[{id:8105,displayName:公开账号}],totalCount=2；无写入
   * @throws CommonBusinessException 分页多值拒绝INPUT_INVALID，非法值由服务拒绝而非默认成功
   */
  @PostMapping("accounts.htm")
  public String accounts(CommonParam input, HttpServletRequest request) {
    for (String field : java.util.List.of("pageNo", "pageSize")) {
      var values = request.getParameterValues(field);
      if (values != null) {
        if (values.length != 1) {
          throw new CommonBusinessException(
              "ATTENDANCE_ACCOUNT_DIRECTORY_INPUT_INVALID", "账号目录分页参数无效。");
        }
        input.putParam(field, values[0]);
      }
    }
    return JsonUtils.toJsonIgnoreNull(reads.accounts(input));
  }

  /**
   * @param input 选择的精确账号userId8104/actionBIND
   * @return 完整CommonResult JSON例如data.bindingRevision=1，当前目录许可验证后只读
   */
  @PostMapping("state.htm")
  public String state(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(reads.state(input));
  }
}
