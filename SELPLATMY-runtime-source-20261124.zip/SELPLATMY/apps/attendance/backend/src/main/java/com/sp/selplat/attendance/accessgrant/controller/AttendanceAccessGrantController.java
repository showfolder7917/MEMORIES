package com.sp.selplat.attendance.accessgrant.controller;

import com.sp.selplat.attendance.accessgrant.service.AttendanceAccessGrantService;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 复用共通 Controller 序列化，表服务在真实认证后仍要求考勤业务授权。 */
@RestController
@RequestMapping("/api/attendance/accessgrant")
public class AttendanceAccessGrantController extends BaseController<AttendanceAccessGrantService> { }
