package com.sp.selplat.attendance.capability.schedulecommand.controller;

import com.sp.selplat.attendance.capability.schedulecommand.service.AttendanceScheduleCommandService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Controller 仅透传共通参数和序列化完整服务结果。 */
@RestController
@RequestMapping("/api/attendance/schedule")
public class AttendanceScheduleCommandController {
    private final AttendanceScheduleCommandService service;

    /**
     * @param service 专用排班服务，构造不读写数据库。
     */
    public AttendanceScheduleCommandController(AttendanceScheduleCommandService service) {
        this.service = service;
    }

    /**
     * @param input 员工、模板、工作日期；
     * @return 完整 CommonResult JSON，例如 data.employeeId=8801、data.workDate=2026-10-04；缺配置或无效输入拒绝。
     */
    @PostMapping("save.htm")
    public String save(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.save(input));
    }

    /**
     * 只透传完整共通请求到真实只读预览。
     *
     * @param input requestKey=BATCH-001/items含employeeId=8801/workDate=2026-10-10
     * @return 完整CommonResult JSON，例如data数组内employeeId=8801/conflictCode为空；无写库，缺许可拒绝
     */
    @PostMapping("previewBatch.htm")
    public String previewBatch(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.previewBatch(input));
    }

    /**
     * 只透传完整确认请求，不把预览状态转为授权。
     *
     * @param input requestKey=BATCH-001/items含templateRevision=0
     * @return 实际CommonResult JSON例如affectedRows=2；任一冲突或末尾SQL失败全回滚
     */
    @PostMapping("commitBatch.htm")
    public String commitBatch(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.commitBatch(input));
    }
}
