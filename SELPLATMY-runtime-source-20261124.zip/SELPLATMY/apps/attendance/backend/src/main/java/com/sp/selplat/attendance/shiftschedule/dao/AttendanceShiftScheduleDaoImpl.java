package com.sp.selplat.attendance.shiftschedule.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceShiftSchedule，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceShiftScheduleDaoImpl extends AttendanceBaseDao
        implements AttendanceShiftScheduleDao {
    /**
     * 查询本表保留的模板引用，包括未开始和历史日期。
     *
     * @param input 所属服务核验范围例如tenantId=81、id=8901
     * @return 实际COUNT例如1；无业务写入，SQL失败保留数据库原因
     */
    @Override
    public long countTemplateReferences(com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.queryForObject(
                "SELECT COUNT(*) FROM AttendanceShiftSchedule WHERE tenantId=? AND"
                    + " shiftTemplateId=?",
                Long.class,
                input.getParam("tenantId"),
                input.getParam("id"));
    }

    /**
     * 当前提交事实直接查询，不使用预览或锁前公共缓存。
     *
     * @param input 服务端tenantId=81/employeeId=8801/workDate=2026-10-10
     * @return 实际同日保留行或相邻日期重叠启用行例如id=100001/status=1；无记录null，仅读本表
     */
    @Override
    public java.util.Map<String, Object> findRetained(
            com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceShiftSchedule WHERE tenantId=? AND employeeId=?"
                            + " AND (workDate=? OR (status=1 AND scheduledStartTime<? AND"
                            + " scheduledEndTime>?)) ORDER BY workDate LIMIT 1",
                        input.getParam("tenantId"),
                        input.getParam("employeeId"),
                        input.getParam("workDate"),
                        input.getParam("scheduledEndTime"),
                        input.getParam("scheduledStartTime"));
        return rows.isEmpty() ? null : rows.getFirst();
    }
}
