/* 2026-10-29：本表私有存储拥有方，不将内部写方法映射HTTP。 */
package com.sp.selplat.attendance.employeecreaterequest.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;

/** 本表唯一Service，公开状态只限真实本人最小投影。 */
public interface AttendanceEmployeeCreateRequestService {
  /**
   * 方法作用：原独立号段只分配本表技术主键。
   *
   * @return 正Long，例如100000，不创建业务
   */
  long newId();

  /**
   * 方法作用：固定编排在原本域事务内新增本表，不开放Controller写入。
   *
   * @param input 服务器本表原参数，例如id100000/tenant9
   * @return 实际新增行数，例如1
   */
  int insert(CommonParam input);

  /** 方法作用：验证原考勤可写读已提交事务，不执行写入。 */
  void requireTransaction();

  /**
   * 方法作用：真实本人只读最小状态，不返回正文、原结果或写能力。
   *
   * @param input 原requestKey或attemptKey规范UUID
   * @return 原CommonResult，例如data.id字符串/stateCode PREPARED
   */
  CommonResult current(CommonParam input);

  /**
   * 方法作用：固定编排只访问本表实际拥有方，不转为HTTP写或权限。
   *
   * @param accountId 原实际账号，例如9101
   * @param key 原UUID
   * @param locking 原考勤事务内true
   * @return 本表原行，无行null
   */
  Map<String, Object> find(long accountId, String key, boolean locking);

  /**
   * 方法作用：固定编排只访问本表实际拥有方，不转为HTTP写或权限。
   *
   * @param input 本表原定位及修订，例如id100000/expectedRevision0
   * @return 原实际影响行数，例如1，CAS不符0
   */
  int advance(CommonParam input);

  /**
   * 方法作用：尝试拥有方只通过本表核父请求是否属于真实当前本人。
   *
   * @param id 来自实际持久行的requestId，例如100000
   * @return 同本人原本表行，不向HTTP输出正文
   */
  Map<String, Object> requireOwn(long id);
}
