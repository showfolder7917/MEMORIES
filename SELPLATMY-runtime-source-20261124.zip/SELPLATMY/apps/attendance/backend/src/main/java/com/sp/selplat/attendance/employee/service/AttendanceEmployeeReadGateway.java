/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-10-29：员工原页面的固定只读入口，Host选择原持锁读取或远端资格复核。 */
package com.sp.selplat.attendance.employee.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 只声明稳定读DTO；不包含Service反射、回调、任意表名或写方法。 */
public interface AttendanceEmployeeReadGateway {

  /**
   * 方法作用：读取原员工管理页，真实租户及管理资格由拥有方确定。
   *
   * @param input 原分页候选，例如pageNo1/pageSize20，不接受它决定身份
   * @return 原分页CommonPageResult，例如records含员工7001、totalCount2，无写入
   */
  CommonPageResult getStore(CommonPageParam input);

  /**
   * 方法作用：读取原同租户员工详情，不改变原记录投影。
   *
   * @param input 原精确主键，例如id7001
   * @return 原CommonResult，例如data.employeeName林老师；无记录或异租户沿原拒绝，无写入
   */
  CommonResult getById(CommonParam input);

  /**
   * 方法作用：读取原人员关联所需的员工安全来源。
   *
   * @param input 原精确主键，例如id7001
   * @return 原4字段摘要，例如id/employeeNo/employeeName/sourceVersion，不含电话或工资，无写入
   */
  CommonResult personReference(CommonParam input);

  /**
   * 方法作用：读取原配置或元数据表头，保持原语言和列结构。
   *
   * @param viewCode 原viewCode或tableCode，例如table930001
   * @param locale 原页面语言，例如zh-CN
   * @return 原CommonResult，例如data.columns含employeeName中文列，不查询其他业务表或写配置
   */
  CommonResult getGridColumn(String viewCode, String locale);

  /**
   * 方法作用：委派原批量详情，不接收表名、Service名或执行回调
   *
   * @param input 原批量主键，例如items含62000和62001
   * @return 原CommonResult及完整data列表，不增删记录或改变顺序
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult getByIds(
      com.sp.selplat.common.util.CommonBatchParam input);
}
