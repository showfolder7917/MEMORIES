/* 修改记录：2026-10-29 私有员工新增请求槽及尝试回执只补空结构和独立缺号段。 */
package com.sp.selplat.attendance.common.persistence;

import com.sp.selplat.common.db.datasource.BaseDataSourceContext;
import com.sp.selplat.common.db.sequence.CommonSequenceSegmentDao;
import com.sp.selplat.common.db.sequence.CommonSequenceSegmentDaoImpl;
import com.sp.selplat.common.db.sequence.model.CommonSequenceSegmentRange;
import com.sp.selplat.common.db.template.BaseTemplateDao;
import com.sp.selplat.common.db.template.BaseTemplateMapper;
import com.sp.selplat.common.exception.CommonSystemException;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.sql.DataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.transaction.SpringManagedTransactionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

/** 考勤私有 H2、模板与事务边界；不创建 Primary，不改变 Host 的默认数据源。 */
@Configuration(proxyBeanMethods = false)
@PropertySource("classpath:attendance-module.properties")
public class AttendancePersistenceConfiguration {
    // 所有业务schema来自固定白名单，canonical号段在本轮可加载schema之后仅补缺。
    private static final String CANONICAL_SEQUENCES =
            "db/attendance/sql/data-CommonSequenceSegment.sql";
    private static final String[] RESOURCES = {
        "db/attendance/sql/schema-CommonSequenceSegment.sql",
        "db/attendance/sql/schema-AttendanceEmployee.sql",
        "db/attendance/sql/schema-AttendanceEmployeeCreateRequest.sql",
        "db/attendance/sql/schema-AttendanceEmployeeCreateAttempt.sql",
        "db/attendance/sql/schema-AttendancePerson.sql",
        "db/attendance/sql/schema-AttendanceEmployeeWorkRule.sql",
        "db/attendance/sql/schema-AttendanceRuleConfig.sql",
        "db/attendance/sql/schema-AttendanceShiftTemplate.sql",
        "db/attendance/sql/schema-AttendanceShiftSchedule.sql",
        "db/attendance/sql/schema-AttendanceScheduleBatch.sql",
        "db/attendance/sql/schema-AttendancePunchRawLog.sql",
        "db/attendance/sql/schema-AttendanceEmployeeExternalMapping.sql",
        "db/attendance/sql/schema-AttendancePunchSourceConfig.sql",
        "db/attendance/sql/schema-AttendancePunchImportBatch.sql",
        "db/attendance/sql/schema-AttendanceDaily.sql",
        "db/attendance/sql/schema-AttendanceMonthly.sql",
        "db/attendance/sql/schema-AttendanceMonthlyItem.sql",
        "db/attendance/sql/schema-AttendanceEmployeeAccount.sql",
        "db/attendance/sql/schema-AttendanceAccessGrant.sql",
        "db/attendance/sql/schema-AttendanceException.sql",
        "db/attendance/sql/schema-AttendanceCalcLog.sql",
        "db/attendance/sql/schema-AttendanceCase.sql",
        "db/attendance/sql/schema-AttendanceCaseActionLog.sql",
        "db/attendance/sql/schema-AttendanceMonthlyActionLog.sql"
    };

    /**
     * @return 标准连接池参数，例如 poolName=AttendancePool；此时尚不连接数据库。
     */
    @Bean("attendanceHikariConfig")
    @ConfigurationProperties(prefix = "attendance.datasource")
    public HikariConfig attendanceHikariConfig() {
        return new HikariConfig();
    }

    /**
     * 创建项目连接池并按固定白名单初始化空结构及号段元数据。
     *
     * @param config 项目 properties 或隔离测试参数，例如 jdbc:h2:mem:attendance_test
     * @return 具名连接池，默认文件是 private/production/db/attendance/attendance.mv.db
     * @throws CommonSystemException 路径、连接池或 SQL 失败时关闭池并抛 ATTENDANCE_DATABASE_INITIALIZATION_FAILED
     */
    @Bean(name = "attendanceDataSource", destroyMethod = "close")
    public HikariDataSource attendanceDataSource(
            @Qualifier("attendanceHikariConfig") HikariConfig config) {
        HikariDataSource pool = null;
        try {
            // 在目录创建/连接之前校验secret；只有调用者显式命名的隔离mem可空密码。
            requireConfiguredPassword(config);
            // 显式隔离 URL 优先；没有配置时只定位本应用权威文件路径。
            if (config.getJdbcUrl() == null || config.getJdbcUrl().isBlank()) {
                Path current = Path.of(System.getProperty("user.dir")).toAbsolutePath().normalize();
                while (current != null
                        && !(Files.isRegularFile(current.resolve("settings.gradle"))
                                && Files.isDirectory(current.resolve("apps/attendance")))) {
                    current = current.getParent();
                }
                if (current == null) {
                    throw new IllegalStateException("无法定位 SELPLAT 工程根");
                }
                Path directory = current.resolve("private/production/db/attendance");
                Files.createDirectories(directory);
                config.setJdbcUrl(
                        "jdbc:h2:file:"
                                + directory.resolve("attendance")
                                + ";MODE=MySQL;DATABASE_TO_UPPER=false");
            }
            pool = new HikariDataSource(config);
            boolean releaseAllowed =
                    !tableExists(pool, "AttendanceMonthly")
                            || tableExists(pool, "AttendanceMonthlyReview");
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
            for (String resource : RESOURCES) {
                populator.addScript(new ClassPathResource(resource));
            }
            if (releaseAllowed) {
                for (String name :
                        java.util.List.of(
                                "schema-AttendanceMonthlyReview.sql",
                                "schema-AttendanceMonthlyPublication.sql",
                                "schema-AttendanceMonthlyReleaseReceipt.sql")) {
                    populator.addScript(new ClassPathResource("db/attendance/sql/" + name));
                }
            }
            // canonical完整补缺所有技术号段，不启用已有禁用行；旧库缺账本仍不加账本或授予动作。
            populator.addScript(new ClassPathResource(CANONICAL_SEQUENCES));
            populator.execute(pool);
            return pool;
        } catch (Exception exception) {
            if (pool != null) {
                pool.close();
            }
            throw new CommonSystemException(
                    "ATTENDANCE_DATABASE_INITIALIZATION_FAILED", "考勤数据库初始化失败。", exception);
        }
    }

    /**
     * 拒绝未提供已解析secret的文件/外部池，检查发生在任何数据库/目录写入之前。
     *
     * @param config 当前真实绑定参数，例如显式jdbc:h2:mem:attendance_isolated可空密码
     *     异常示例：默认URL、file/tcp池的null/空白/未解析占位密码抛错，不生成或记录密码。
     * @throws IllegalStateException 非隔离内存考勤数据库必须提供环境密码。
     */
    private static void requireConfiguredPassword(HikariConfig config) {
        String url = config.getJdbcUrl();
        boolean isolatedMemory =
                url != null && url.matches("jdbc:h2:mem:[A-Za-z0-9][A-Za-z0-9._-]*(;.*)?");
        String password = config.getPassword();
        if (!isolatedMemory
                && (password == null || password.isBlank() || password.contains("${"))) {
            throw new IllegalStateException("非隔离内存考勤数据库必须提供环境密码。");
        }
    }

    /**
     * 绑定同源公共 MyBatis 模板，避免批量和单条操作跨数据库。
     *
     * @param dataSource 具名考勤数据源，例如隔离 attendance_test 库
     * @return 真实私有 Mapper、JDBC 与数据源组合；无业务记录写入
     */
    @Bean("attendanceBaseDataSourceContext")
    public BaseDataSourceContext attendanceBaseDataSourceContext(
            @Qualifier("attendanceDataSource") DataSource dataSource) {
        org.apache.ibatis.session.Configuration configuration =
                new org.apache.ibatis.session.Configuration();
        configuration.setEnvironment(
                new Environment("attendance", new SpringManagedTransactionFactory(), dataSource));
        configuration.addMapper(BaseTemplateMapper.class);
        SqlSessionTemplate template =
                new SqlSessionTemplate(new SqlSessionFactoryBuilder().build(configuration));
        return new BaseDataSourceContext(
                dataSource,
                new BaseTemplateDao(template.getMapper(BaseTemplateMapper.class), dataSource));
    }

    /**
     * 供本域 DAO 的受控差异查询使用私有 JDBC。
     *
     * @param dataSource 具名考勤数据源
     * @return 同源 JdbcTemplate，例如不会读取 UniauthUser 表；无写入副作用
     */
    @Bean("attendanceJdbcTemplate")
    public JdbcTemplate attendanceJdbcTemplate(
            @Qualifier("attendanceDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    /**
     * 创建本域原子事务边界。
     *
     * @param dataSource 具名考勤数据源
     * @return 考勤事务管理器，例如排班、计算与月次项目写入可整批回滚
     */
    @Bean("attendanceTransactionManager")
    public PlatformTransactionManager attendanceTransactionManager(
            @Qualifier("attendanceDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    /**
     * 为同一考勤数据库的号段领取保留独立连接，避免业务池全部占用时续段等不到连接。
     *
     * @param config 已绑定的本域真实连接参数，例如 jdbc:h2:mem:attendance_sequence_fixture；不增加权限或新数据库
     * @param initializedBusinessDataSource 已完成路径解析与结构初始化的真实业务池，例如 AttendancePool；用作初始化依赖
     * @return 同库独立小连接池，例如 AttendanceSequencePool/max=2；仅号段 DAO 使用 异常或副作用示例：连接配置无效时由 Hikari
     *     抛错；不初始化业务表、账号或权限。
     */
    @Bean(name = "attendanceSequenceDataSource", destroyMethod = "close")
    public HikariDataSource attendanceSequenceDataSource(
            @Qualifier("attendanceHikariConfig") HikariConfig config,
            @Qualifier("attendanceDataSource") DataSource initializedBusinessDataSource) {
        // 业务池已先完成默认路径解析和空结构初始化；复制相同URL、账号、schema及驱动，不开第二业务库。
        HikariConfig sequenceConfig = new HikariConfig();
        config.copyStateTo(sequenceConfig);
        sequenceConfig.setPoolName("AttendanceSequencePool");
        sequenceConfig.setMaximumPoolSize(2);
        sequenceConfig.setMinimumIdle(1);
        return new HikariDataSource(sequenceConfig);
    }

    /**
     * 将号段事务绑定同库专属连接池，使提交只推进游标，不提交外层业务数据。
     *
     * @param dataSource 真实 AttendanceSequencePool，例如与 AttendancePool 同一个隔离 H2
     * @return 具名号段事务管理器，例如独立领取后游标保留、原始卡事务仍可回滚 异常或副作用示例：不创建默认事务管理器，不改变其他应用的数据源选择。
     */
    @Bean("attendanceSequenceTransactionManager")
    public PlatformTransactionManager attendanceSequenceTransactionManager(
            @Qualifier("attendanceSequenceDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    /**
     * 在本域 Bean 扩展中独立提交公共号段领取，保留公共发号与SQL算法，不依赖注解自调用代理。
     *
     * @param dataSource 同库号段专属连接池，例如 AttendanceSequencePool；业务记录仍由 AttendancePool 持有
     * @param transactionManager 同源具名号段事务管理器，例如 attendanceSequenceTransactionManager
     * @return 唯一本域号段 DAO，例如 AttendanceDailyId 领取后即提交；业务失败可留下间隙，绝不回退重用ID
     *     异常或副作用示例：领取失败仍传播原异常；外层1001条约束失败回滚业务数据，已领取游标不回滚。
     */
    @Bean("attendanceCommonSequenceSegmentDao")
    public CommonSequenceSegmentDao attendanceCommonSequenceSegmentDao(
            @Qualifier("attendanceSequenceDataSource") DataSource dataSource,
            @Qualifier("attendanceSequenceTransactionManager")
                    PlatformTransactionManager transactionManager) {
        // 显式模板保证每次真正领取经过独立事务，不受同类方法自调用或Spring代理形态影响。
        TransactionTemplate allocation = new TransactionTemplate(transactionManager);
        allocation.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        allocation.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
        return new CommonSequenceSegmentDaoImpl(dataSource) {
            /**
             * 只为真实公共领取调用建立独立提交边界；不更改公共游标乐观锁或内存缓存算法。
             *
             * @param seqCode 实际本域表号段，例如 AttendancePunchRawLogId
             * @return 公共DAO真实区间，例如 startId=100001/endId=101000；竞争未领取返回null
             *     异常或副作用示例：领取失败异常传播；成功时仅CommonSequenceSegment游标永久推进，允许间隙。
             */
            @Override
            public CommonSequenceSegmentRange allocateNextRange(String seqCode) {
                return allocation.execute(status -> super.allocateNextRange(seqCode));
            }
        };
    }

    /**
     * 按真实元数据判断账本可用，不启动旧用户库迁移。
     *
     * @param pool 同源实际连接池例如AttendancePool
     * @param name 固定表名例如AttendanceMonthlyReview
     * @return 表确实存在为true；不存在为false，仅元数据查询
     * @throws java.sql.SQLException 元数据查询失败，启动失败而非假装就绪
     */
    private static boolean tableExists(DataSource pool, String name) throws java.sql.SQLException {
        try (var connection = pool.getConnection();
                var tables =
                        connection
                                .getMetaData()
                                .getTables(null, null, name, new String[] {"TABLE"})) {
            return tables.next();
        }
    }

    /**
     * 从实际三账本结构得到能力开关，旧库缺结构不授予动作。
     *
     * @param pool 实际attendanceDataSource
     * @return 例如新空隔离库三表齐备为true，旧库缺账本为false，不创建记录或许可
     * @throws java.sql.SQLException 元数据失败不能提供能力
     */
    @Bean("attendanceMonthlyReleaseReady")
    public Boolean attendanceMonthlyReleaseReady(@Qualifier("attendanceDataSource") DataSource pool)
            throws java.sql.SQLException {
        return tableExists(pool, "AttendanceMonthlyReview")
                && tableExists(pool, "AttendanceMonthlyPublication")
                && tableExists(pool, "AttendanceMonthlyReleaseReceipt");
    }
}
