package com.sp.selplat.attendance.schedulebatch.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 固定拥有 AttendanceScheduleBatch，复用具名考勤模板和共享号段。 */
@Repository
public class AttendanceScheduleBatchDaoImpl extends AttendanceBaseDao
        implements AttendanceScheduleBatchDao {
    /**
     * 同事务连接直接读已提交成功事实，不复用锁前缓存。
     *
     * @param input 服务授权后固定范围例如tenantId=81/createdBy=8103/requestKey=BATCH-001
     * @return 实际回执行例如rowCount=2；未匹配null，仅查本表
     */
    @Override
    public java.util.Map<String, Object> findReceipt(com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceScheduleBatch WHERE tenantId=? AND createdBy=? AND requestKey=? AND status=1",
                        input.getParam("tenantId"),
                        input.getParam("createdBy"),
                        input.getParam("requestKey"));
        return rows.isEmpty() ? null : readReceiptText(rows.getFirst());
    }

    /**
     * 真实公共分页保持筛选/总数/排序，只转换本表回执CLOB。
     *
     * @param values 服务端范围例如tenantId=81/requestKey=BATCH-001
     * @param orderBy 公共排序例如id desc
     * @param pageNo 实际页码1
     * @param pageSize 实际页大小20
     * @return CommonPageResult.records例如[{id:100001,resultJson:"[]"}]，totalCount=1；无写库
     */
    @Override
    public com.sp.selplat.common.util.CommonPageResult getPageList(
            java.util.Map<String, Object> values,
            String orderBy,
            Integer pageNo,
            Integer pageSize) {
        var page = super.getPageList(values, orderBy, pageNo, pageSize);
        page.setRecords(page.getRecords().stream().map(this::readReceiptText).toList());
        return page;
    }

    /**
     * 真实公共主键查询转换持久化回执，不暴露驱动stream。
     *
     * @param input 已授权主键例如id=100001/tenantId=81
     * @return 真实行例如resultJson="[]"；无匹配null，仅查本表
     */
    @Override
    public java.util.Map<String, Object> getById(com.sp.selplat.common.util.CommonParam input) {
        return readReceiptText(super.getById(input));
    }

    /**
     * 真实公共批读取保持实际顺序并转换CLOB。
     *
     * @param input 已授权items例如id=100001/tenantId=81
     * @return 实际列表例如[{id:100001,resultJson:"[]"}]；不合成数据，无写库
     */
    @Override
    public java.util.List<java.util.Map<String, Object>> getByIds(
            com.sp.selplat.common.util.CommonBatchParam input) {
        return super.getByIds(input).stream().map(this::readReceiptText).toList();
    }

    /**
     * 复制本表回执实际CLOB字符，不改内容或事务缓存。
     *
     * @param source 真实JDBC行例如id=100001/resultJson为H2 Clob
     * @return 实际副本resultJson="[]"；null保持null，无写库
     * @throws com.sp.selplat.common.exception.CommonSystemException 真实SQL/长度失败保留原因，不返回驱动对象
     */
    private java.util.Map<String, Object> readReceiptText(java.util.Map<String, Object> source) {
        if (source == null) {
            return null;
        }
        var row = new java.util.LinkedHashMap<String, Object>(source);
        if (row.get("resultJson") instanceof java.sql.Clob clob) {
            try {
                row.put("resultJson", clob.getSubString(1, Math.toIntExact(clob.length())));
            } catch (java.sql.SQLException | ArithmeticException error) {
                throw new com.sp.selplat.common.exception.CommonSystemException(
                        "ATTENDANCE_BATCH_RECEIPT_READ_FAILED", "批量排班回执读取失败。", error);
            }
        }
        return row;
    }
}
