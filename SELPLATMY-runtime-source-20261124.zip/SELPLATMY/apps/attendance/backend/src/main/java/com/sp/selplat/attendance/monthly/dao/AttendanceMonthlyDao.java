package com.sp.selplat.attendance.monthly.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceMonthly 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceMonthlyDao extends BaseDao {
    /**
     * 锁本员工全部保留月快照，当前读取避免等待前状态或查询缓存放行。
     *
     * @param input 已核验范围例如tenantId=81/employeeId=8801
     * @return 实际月行列表例如yearMonth=2026-09/closeStatus=CLOSED 异常或副作用示例：仅本表FOR UPDATE，无跨表查询或写入。
     */
    java.util.List<java.util.Map<String, Object>> lockEmployeePeriods(
            com.sp.selplat.common.util.CommonParam input);
}
