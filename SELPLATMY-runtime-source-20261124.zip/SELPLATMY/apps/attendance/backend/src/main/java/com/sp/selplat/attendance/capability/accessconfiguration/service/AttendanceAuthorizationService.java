/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service;

import com.sp.selplat.common.util.CommonResult;
import java.util.Map;

/** 考勤消费真实会话、本域已核验配置及受保护的既有租户管理员，不创建角色或账号映射。 */
public interface AttendanceAuthorizationService {

  /**
   * @return 当前本人配置，例如 canManage=false；匿名抛身份错误，无配置写入。
   */
  CommonResult currentConfiguration();

  /**
   * @return 原VERIFIED MANAGER或本次角色持锁范围核验的userId/tenantId；两者均无则拒绝，无授权写入。
   */
  Map<String, Long> requireManagement();

  /**
   * 方法作用：只读业务显式核当前身份及固定attendance系统入口，不增加管理员门槛。
   *
   * @return 实际身份主键，例如userId9102/tenantId9；不返回写许可或线程保护范围
   * @throws com.sp.selplat.common.exception.CommonBusinessException 身份变化或无系统角色时拒绝，无权限写入
   */
  Map<String, Long> requireReadIdentity();

  /**
   * 方法作用：只读管理操作核原管理员资格或本域已核MANAGER配置，不提供持锁写范围。
   *
   * @return 当前真实身份，例如userId9101/tenantId9；查询前后须各自调用，不作为写许可
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格缺失、撤回或身份变化时拒绝，无配置写入
   */
  Map<String, Long> requireReadManagement();

  /**
   * @return 经 VERIFIED/TENANT/APPROVER 配置核验的 userId/tenantId；管理角色不自动具有审批权。
   */
  Map<String, Long> requireApproval();

  /**
   * 取得真实会话的员工映射，缺配置默认拒绝。
   *
   * @return userId、tenantId、employeeId，例如 8101、81、8801
   * @throws com.sp.selplat.common.exception.CommonBusinessException 未核验、缺失或失效时拒绝
   */
  Map<String, Long> requireEmployeeBinding();

  /**
   * 实时验证本人映射与精确月报读取动作，不能读他人或获得管理能力。
   *
   * @return 真实身份例如 {userId:8101,tenantId:81,employeeId:8801} 异常或副作用示例：缺可信许可抛
   *     ATTENDANCE_MONTHLY_READ_UNAVAILABLE，无写入。
   */
  Map<String, Long> requireMonthlySelfRead();

  /**
   * 核验独立月动作，不从旧角色推导。
   *
   * @param action 内部固定动作例如PUBLISH
   * @return 实际userId/tenantId，缺动作或账本拒绝，不授予许可
   */
  Map<String, Long> requireReleaseAction(String action);

  /**
   * 方法作用：本人纯读核原系统角色、当前身份及已核绑定，不创建提交保护。
   *
   * @return 当前三坐标，例如userId9102/tenantId9/employeeId7060
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺角色/绑定或身份变化拒绝，无写入
   */
  java.util.Map<String, Long> requireReadEmployeeBinding();

  /**
   * 方法作用：审批纯读核原系统角色与独立APPROVER，不创建写入保护。
   *
   * @return 原userId/tenantId，例如9102/9
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺独立审批配置或角色变化拒绝，无写入
   */
  java.util.Map<String, Long> requireReadApproval();

  /**
   * 方法作用：以原系统角色包住原本人月报精确许可，不由管理角色推导
   *
   * @return 本人身份三坐标，例如userId9102/tenantId9/employeeId7080，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  java.util.Map<String, Long> requireReadMonthlySelf();

  /**
   * 方法作用：原精确月动作许可前后包源角色/同一真实主体，不从管理或本人资格推导
   *
   * @param action 服务器选定原四动作，例如PREPARE_REVIEW/PUBLISH/WITHDRAW
   * @return 真实userId/tenantId，例如9102/9，无新权限事实
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  java.util.Map<String, Long> requireReadReleaseAction(String action);

  /**
   * 方法作用：读取原本人配置并复核同一主体、原系统角色及完整独立资格状态。
   *
   * @return 原CommonResult，例如data.canManage=false/canApprove=true/configurationWritable=false。
   * @throws com.sp.selplat.common.exception.CommonBusinessException 角色、身份或配置读取期间变化拒绝，无配置写入
   */
  CommonResult readCurrentConfiguration();
}
