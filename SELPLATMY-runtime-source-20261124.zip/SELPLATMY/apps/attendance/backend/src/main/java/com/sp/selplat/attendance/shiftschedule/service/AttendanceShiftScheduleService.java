/* 2026-11-01：复用原考勤配置纯读合同，写和关联保护不变。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
package com.sp.selplat.attendance.shiftschedule.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceShiftSchedule 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceShiftScheduleService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 由专用排班能力传入已校验的员工、模板及展开时间，没有独立 HTTP 写入口。
   *
   * @param input 服务端排班字段，例如 employeeId=8801、workDate=2026-10-03
   * @return 真实持久化结果；锁定或异租户记录拒绝，写入本域事务
   */
  CommonResult storeScheduled(CommonParam input);

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批能力的受控字段，例如employeeId=8801、workDate=2026-10-04
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  CommonResult findForApproval(CommonParam criteria);

  /**
   * 模板保护只经所属表服务读取保留的真实排班引用，无HTTP入口。
   *
   * @param input 模板主键例如id=8901，租户由Session覆盖
   * @return 实际引用数例如1；缺管理配置拒绝，仅读库无业务写入
   */
  long countTemplateReferences(CommonParam input);

  /**
   * 读取保留同员工同日冲突，不遗漏软删除唯一键行。
   *
   * @param input 受控employeeId=8801/workDate=2026-10-10
   * @return 实际CommonResult.data.id=100001；不存在null，仅当前租户查询
   */
  CommonResult findRetained(com.sp.selplat.common.util.CommonParam input);

  /**
   * 专用批提交预处理事实后交公共真实JDBC batch。
   *
   * @param input 服务端展开的全部行例如items含employeeId=8801/workDate=2026-10-10
   * @return 实际CommonResult.data数组及affectedRows=2；末项SQL失败整批回滚
   */
  CommonResult storeScheduledBatch(com.sp.selplat.common.util.CommonBatchParam input);

  /**
   * 方法作用：仅供已核原配置读取完整保留引用，不进入管理提交回调。
   *
   * @param input 原所属配置编号，例如id8501，租户由真实身份覆盖
   * @return 原本表全部历史引用数量，例如1，包含软删除行
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原只读管理资格无效时拒绝，无引用写入
   */
  long countTemplateReferencesForRead(com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：原审批来源纯读，前后核同一APPROVER及真实身份。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原来源结果，无匹配沿原空结果，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格撤回或身份变化拒绝旧结果
   */
  com.sp.selplat.common.util.CommonResult readFindForApproval(
      com.sp.selplat.common.util.CommonParam input);
}
