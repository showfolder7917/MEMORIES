package com.sp.selplat.attendance.employeeworkrule.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceEmployeeWorkRule 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceEmployeeWorkRuleDao extends BaseDao {
    /**
     * 查询本表保留的规则引用，包括软删除行，保护历史参数。
     *
     * @param input 服务端租户/规则主键例如 tenantId=81、id=8501
     * @return 真实引用数量例如1；只读本表，无写入副作用
     */
    long countRuleReferences(com.sp.selplat.common.util.CommonParam input);

    /**
     * 读取本员工全部当前启用关联，供保护月写前/写后真实选择比较。
     *
     * @param input 服务端tenantId=81/employeeId=8801
     * @return 实际行列表，例如id=8401/effectiveStartDate=2026-01-01，无跨表读取
     *     异常或副作用示例：真实JDBC当前事实，纯本表只读，没有模拟选择结果。
     */
    java.util.List<java.util.Map<String, Object>> currentEmployeeAssignments(
            com.sp.selplat.common.util.CommonParam input);
}
