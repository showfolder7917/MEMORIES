/* 2026-11-01：账号绑定三读取HTTP接入，共用原算法并保留原事务锁和写保护。 */
/** 修改记录：2026-10-09，缺请求先保留真实管理身份检查，再返回明确输入错误，避免四入口空指针。 */
package com.sp.selplat.attendance.capability.accountbinding.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.capability.accountbinding.service.AttendanceAccountBindingService;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.employeeaccount.service.AttendanceEmployeeAccountService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 在本域事务内按员工串行绑定，仅所属表服务写入；不接触Uniauth认证内部DAO。 */
@Service
public class AttendanceAccountBindingServiceImpl implements AttendanceAccountBindingService {
  // 真实管理、员工和映射各由所属服务核验；能力不跨表DAO。
  private final AttendanceAuthorizationService authorization;
  private final AttendanceEmployeeService employees;
  private final AttendanceEmployeeAccountService accounts;

  // 可选权威公开目录；缺配置默认拒绝，不读取认证内部账号接口。
  @org.springframework.beans.factory.annotation.Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.attendance.capability.accountbinding.service.AttendanceAccountDirectory>
      directories;

  /**
   * 装配专用绑定的真实服务链。
   *
   * @param authorization 当前管理许可，例如VERIFIED/MANAGER/TENANT
   * @param employees 当前真实员工表服务
   * @param accounts 当前映射及目录许可校验服务 副作用示例：仅保存依赖，构造不授予角色或写库。
   */
  public AttendanceAccountBindingServiceImpl(
      AttendanceAuthorizationService authorization,
      AttendanceEmployeeService employees,
      AttendanceEmployeeAccountService accounts) {
    this.authorization = authorization;
    this.employees = employees;
    this.accounts = accounts;
  }

  /**
   * 核明确旧员工候选的现有目标资格；不以旧ID/pin/用户名推导，不创建历史关联。
   *
   * @param input
   *     七个词法字段，例如mode=DRY_RUN/sourceSystem=ERP/sourceAccountId=24/sourceType=1/userId=8104/employeeId=8801/evidenceRef=r1
   * @return
   *     例如success=true,data={targetFactsVerified:true,mappingEvidenceVerified:false,writeEnabled:false,typedImportBlocked:true}
   *     异常示例：缺管理、停用或越租户目录、现有绑定其他员工拒绝，调用前后不写入业务/审计/号段。
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult migrationPreflight(CommonParam input) {
    return loadMigrationPreflight(input, authorization.requireManagement(), false);
  }

  /**
   * 方法作用：共用原migrationPreflight完整算法，仅按明确读取模式重核资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104
   * @param identity 原管理身份，例如tenantId81/userId8103
   * @param readOnly true只查询资格，false保持原持锁管理入口
   * @return 原CommonResult完整结构；例如绑定修订0或原安全分页
   * @throws CommonBusinessException 原目录、管理或锁中事实失效拒绝，不执行绑定写入
   */
  private CommonResult loadMigrationPreflight(
      CommonParam input, java.util.Map<String, Long> identity, boolean readOnly) {
    // 已真实核验管理身份后拒绝缺请求，不以空指针继续读取员工、目录或映射。
    if (input == null) {
      throw migrationInvalid();
    }
    var values = input.getParamMap();
    var fields =
        java.util.Set.of(
            "mode",
            "sourceSystem",
            "sourceAccountId",
            "sourceType",
            "userId",
            "employeeId",
            "evidenceRef");
    if (values.size() != fields.size()
        || !values.keySet().containsAll(fields)
        || !"DRY_RUN".equals(values.get("mode"))
        || !"1".equals(values.get("sourceType"))) {
      throw migrationInvalid();
    }
    for (String field : fields) {
      if (!(values.get(field) instanceof String text)
          || text.isBlank()
          || text.length() > 128
          || text.codePoints().anyMatch(Character::isISOControl)) {
        throw migrationInvalid();
      }
    }
    long userId = migrationId(values.get("userId")),
        employeeId = migrationId(values.get("employeeId"));
    CommonParam criteria = new CommonParam();
    criteria.putParam("id", employeeId);
    var employee =
        (readOnly
            ? employees.readLockForAccountBinding(criteria)
            : employees.lockForSchedule(criteria));
    if (!(employee.getData() instanceof java.util.Map<?, ?> row)
        || !"ACTIVE".equals(row.get("businessStatus"))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "员工候选不存在、失效或无权核验。");
    }
    CommonParam selection = new CommonParam();
    selection.putParam("userId", userId);
    selection.putParam("action", "BIND");
    // 原只读state即时重核安全目录BIND资格；不使用其许可读取CRM负责人或生成旧账号。
    if (readOnly) {
      loadState(selection, identity, true);
    } else {
      state(selection);
    }
    var result = accounts.migrationCandidateState(userId, employeeId);
    if (!(result.getData() instanceof java.util.Map<?, ?> binding)
        || !identity.equals(management(readOnly))) {
      throw migrationInvalid();
    }
    if (binding.get("employeeId") != null
        && positiveUser(binding.get("employeeId")) != employeeId
        && ((Number) binding.get("status")).intValue() == 1) {
      throw new CommonBusinessException(
          "ATTENDANCE_MIGRATION_MAPPING_AMBIGUOUS", "账号已有其他员工绑定，候选需复核。");
    }
    var data = new java.util.LinkedHashMap<String, Object>();
    data.put("sourceTable", "authority_user");
    data.put("sourceAccountId", values.get("sourceAccountId"));
    data.put("userId", userId);
    data.put("employeeId", employeeId);
    data.put("bindingRevision", binding.get("bindingRevision"));
    data.put("targetFactsVerified", true);
    data.put("mappingEvidenceVerified", false);
    data.put("writeEnabled", false);
    data.put("typedImportBlocked", true);
    data.put("requiredEvidence", java.util.List.of("REVIEWED_OLD_ACCOUNT_TO_USER_EMPLOYEE_LEDGER"));
    CommonResult report = new CommonResult();
    report.setSuccess(true);
    report.setData(data);
    return report;
  }

  /**
   * 核新主键规范，避免01/1或浮点造成歧义候选。
   *
   * @param value 明确目标主键，例如8104
   * @return 正long例如8104；溢出/非规范值拒绝，不猜旧新关系
   */
  private long migrationId(Object value) {
    try {
      if (value instanceof String text && text.matches("[1-9][0-9]{0,18}")) {
        return Long.parseLong(text);
      }
    } catch (NumberFormatException overflow) {
      throw migrationInvalid();
    }
    throw migrationInvalid();
  }

  /**
   * @return 安全业务拒绝ATTENDANCE_MIGRATION_INPUT_INVALID；不包含账号线索或原始字段 副作用示例：非法候选中止，不保存映射。
   */
  private CommonBusinessException migrationInvalid() {
    return new CommonBusinessException("ATTENDANCE_MIGRATION_INPUT_INVALID", "员工旧新关联声明无效，需明确复核。");
  }

  /**
   * 同员工行锁保证一个员工只有一个活动账户；映射唯一键保证一个账户只有一个员工。
   *
   * @param input 明确employeeId=8801/userId=8101/action=UNBIND/requestKey=U1/expectedRevision=1
   * @return 真实CommonResult例如data.status=0/bindingRevision=2；重复请求不追加审计
   *     异常示例：员工异租户/停用、管理撤销、无目录或精确许可拒绝且零写入。
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult execute(CommonParam input) {
    // 前后重新查询实际管理许可，等待期间撤权不能使用旧响应放行。
    var identity = authorization.requireManagement();
    // 已真实核验管理身份后拒绝缺请求，不以空指针继续读取员工、目录或映射。
    if (input == null) {
      throw invalidDirectory();
    }
    CommonParam lock = new CommonParam();
    lock.putParam("id", input.getParam("employeeId"));
    var result = employees.lockForSchedule(lock);
    if (!(result.getData() instanceof java.util.Map<?, ?> row)
        || !"ACTIVE".equals(row.get("businessStatus"))
        || !identity.equals(authorization.requireManagement())) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return accounts.applyBinding(input);
  }

  /**
   * 服务端精确许可范围内分页安全公开账号，所有输出列白名单且逐目标再核验目录事实。
   *
   * @param input 例如action=BIND/pageNo=1/pageSize=20/accountIdExact=8104，客户端租户无效
   * @return 实际CommonPageResult例如records=[{id:8104,displayName:公开显示名,status:1}],totalCount=1
   *     异常示例：目录缺失、越权/错误分页/不一致响应拒绝，不抓整库或返回凭据及email。
   */
  @Override
  public com.sp.selplat.common.util.CommonPageResult accounts(CommonParam input) {
    return loadAccounts(input, authorization.requireManagement(), false);
  }

  /**
   * 方法作用：共用原accounts完整算法，仅按明确读取模式重核资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104
   * @param identity 原管理身份，例如tenantId81/userId8103
   * @param readOnly true只查询资格，false保持原持锁管理入口
   * @return 原com.sp.selplat.common.util.CommonPageResult完整结构；例如绑定修订0或原安全分页
   * @throws CommonBusinessException 原目录、管理或锁中事实失效拒绝，不执行绑定写入
   */
  private com.sp.selplat.common.util.CommonPageResult loadAccounts(
      CommonParam input, java.util.Map<String, Long> identity, boolean readOnly) {
    // 已真实核验管理身份后拒绝缺请求，不以空指针继续读取员工、目录或映射。
    if (input == null) {
      throw invalidDirectory();
    }
    var directory = directory();
    String action = directoryAction(input);
    int pageNo = pageValue(input.getParam("pageNo"), 1, Integer.MAX_VALUE),
        pageSize = pageValue(input.getParam("pageSize"), 20, 100);
    String exact =
        input.getParam("accountIdExact") == null
            ? ""
            : String.valueOf(input.getParam("accountIdExact")).trim();
    if (input.getParam("loginNameExact") != null || exact.length() > 20) {
      throw invalidDirectory();
    }
    var page = directory.searchAccounts(identity, action, pageNo, pageSize, exact);
    if (page == null
        || page.getRecords() == null
        || page.getRecords().size() > pageSize
        || page.getTotalCount() < page.getRecords().size()
        || !Integer.valueOf(pageNo).equals(page.getPageNo())
        || !Integer.valueOf(pageSize).equals(page.getPageSize())) {
      throw invalidDirectory();
    }
    var records = new java.util.ArrayList<java.util.Map<String, Object>>();
    var ids = new java.util.HashSet<Long>();
    for (var row : page.getRecords()) {
      long userId = positiveUser(row.get("id"));
      var fact = directory.requireAccount(identity, userId, action);
      if (!ids.add(userId)
          || fact == null
          || !(fact.get("tenantId") instanceof Number tenant)
          || tenant.longValue() != identity.get("tenantId")
          || positiveUser(fact.get("userId")) != userId
          || !(fact.get("status") instanceof Number status)
          || (action.equals("BIND_EMPLOYEE_ACCOUNT") && status.intValue() != 1)
          || fact.get("directoryRevision") == null
          || !java.util.Objects.equals(row.get("directoryRevision"), fact.get("directoryRevision"))
          || !(row.get("displayName") instanceof String display)
          || display.length() > 200
          || !java.util.Objects.equals(display, fact.get("displayName"))
          || (!exact.isEmpty() && positiveUser(exact) != userId)) {
        throw invalidDirectory();
      }
      // 只投影公开白名单。即使适配器添加了内部列也不会进入分页JSON或Grid。
      var safe = new java.util.LinkedHashMap<String, Object>();
      safe.put("id", userId);
      safe.put("tenantId", identity.get("tenantId"));
      safe.put("displayName", display);
      safe.put("status", status.intValue());
      safe.put("directoryRevision", fact.get("directoryRevision"));
      records.add(safe);
    }
    if (!identity.equals(management(readOnly))) {
      throw invalidDirectory();
    }
    var result = new com.sp.selplat.common.util.CommonPageResult();
    result.setRecords(records);
    result.setTotalCount(page.getTotalCount());
    result.setPageNo(pageNo);
    result.setPageSize(pageSize);
    return result;
  }

  /**
   * 已选择公开账号的只读当前绑定，目标必须再经精确目录动作核验。
   *
   * @param input 例如userId=8104/action=UNBIND，客户端身份和员工范围不能扩权
   * @return 实际CommonResult例如data.bindingRevision=1/employeeId=8801，缺目录/账本拒绝
   */
  @Override
  public CommonResult state(CommonParam input) {
    return loadState(input, authorization.requireManagement(), false);
  }

  /**
   * 方法作用：共用原state完整算法，仅按明确读取模式重核资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104
   * @param identity 原管理身份，例如tenantId81/userId8103
   * @param readOnly true只查询资格，false保持原持锁管理入口
   * @return 原CommonResult完整结构；例如绑定修订0或原安全分页
   * @throws CommonBusinessException 原目录、管理或锁中事实失效拒绝，不执行绑定写入
   */
  private CommonResult loadState(
      CommonParam input, java.util.Map<String, Long> identity, boolean readOnly) {
    // 已真实核验管理身份后拒绝缺请求，不以空指针继续读取员工、目录或映射。
    if (input == null) {
      throw invalidDirectory();
    }
    long userId = positiveUser(input.getParam("userId"));
    var fact = directory().requireAccount(identity, userId, directoryAction(input));
    if (fact == null
        || !(fact.get("tenantId") instanceof Number tenant)
        || tenant.longValue() != identity.get("tenantId")
        || positiveUser(fact.get("userId")) != userId) {
      throw invalidDirectory();
    }
    var result = accounts.bindingState(userId);
    if (!identity.equals(management(readOnly))) {
      throw invalidDirectory();
    }
    if (!fact.equals(directory().requireAccount(identity, userId, directoryAction(input)))) {
      throw invalidDirectory();
    }
    return result;
  }

  /**
   * @return 实际公开目录bean，例如测试SQL目录；缺生产适配器抛明确Unavailable，无写入
   * @throws CommonBusinessException 生产目录未装配时拒绝，例如ATTENDANCE_ACCOUNT_DIRECTORY_UNAVAILABLE
   */
  private com.sp.selplat.attendance.capability.accountbinding.service.AttendanceAccountDirectory
      directory() {
    var directory = directories.getIfAvailable();
    if (directory == null) {
      throw new CommonBusinessException(
          "ATTENDANCE_ACCOUNT_DIRECTORY_UNAVAILABLE", "权威账号目录及绑定许可尚未接入。");
    }
    return directory;
  }

  /**
   * @param input 明确action=BIND或UNBIND
   * @return 精确目录动作例如BIND_EMPLOYEE_ACCOUNT，不允许任意角色请求，无写入
   */
  private String directoryAction(CommonParam input) {
    return switch (String.valueOf(input.getParam("action"))) {
      case "BIND" -> "BIND_EMPLOYEE_ACCOUNT";
      case "UNBIND" -> "UNBIND_EMPLOYEE_ACCOUNT";
      default -> throw invalidDirectory();
    };
  }

  /**
   * @param value 真实正整数例如8104
   * @return 正long例如8104，无效输入拒绝，无写入
   */
  private long positiveUser(Object value) {
    try {
      long id = new java.math.BigDecimal(String.valueOf(value)).longValueExact();
      if (id > 0) {
        return id;
      }
    } catch (NumberFormatException | ArithmeticException invalid) {
      /* 无有效目标不读目录。 */
    }
    throw invalidDirectory();
  }

  /**
   * @param value 页参数例如20
   * @param fallback 缺省页大小例如20
   * @param max 最大值例如100
   * @return 已校验整数例如20，无效拒绝，无写入
   */
  private int pageValue(Object value, int fallback, int max) {
    if (value == null) {
      return fallback;
    }
    try {
      int result = new java.math.BigDecimal(String.valueOf(value)).intValueExact();
      if (result > 0 && result <= max) {
        return result;
      }
    } catch (NumberFormatException | ArithmeticException invalid) {
      /* 不允许小数、溢出或无限下载。 */
    }
    throw invalidDirectory();
  }

  /**
   * @return 安全CommonBusinessException例如ATTENDANCE_ACCOUNT_DIRECTORY_INPUT_INVALID，不回传内部资料
   */
  private CommonBusinessException invalidDirectory() {
    return new CommonBusinessException(
        "ATTENDANCE_ACCOUNT_DIRECTORY_INPUT_INVALID", "账号目录分页参数或公开事实无效。");
  }

  /**
   * 方法作用：读取原Accounts合同并在原事务交付前重核同一主体、系统角色与管理资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检使用原七字段DRY_RUN
   * @return 原com.sp.selplat.common.util.CommonPageResult，例如安全分页或bindingRevision=0，不产生绑定记录
   * @throws CommonBusinessException 原管理、目录、审计结构或目标资格失效沿原错误拒绝
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonPageResult readAccounts(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadAccounts(input, actor, true);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw invalidDirectory();
    }
    return result;
  }

  /**
   * 方法作用：读取原State合同并在原事务交付前重核同一主体、系统角色与管理资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检使用原七字段DRY_RUN
   * @return 原CommonResult，例如安全分页或bindingRevision=0，不产生绑定记录
   * @throws CommonBusinessException 原管理、目录、审计结构或目标资格失效沿原错误拒绝
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readState(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadState(input, actor, true);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw invalidDirectory();
    }
    return result;
  }

  /**
   * 方法作用：读取原MigrationPreflight合同并在原事务交付前重核同一主体、系统角色与管理资格。
   *
   * @param input 原业务参数，例如action=BIND/userId=8104；预检使用原七字段DRY_RUN
   * @return 原CommonResult，例如安全分页或bindingRevision=0，不产生绑定记录
   * @throws CommonBusinessException 原管理、目录、审计结构或目标资格失效沿原错误拒绝
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readMigrationPreflight(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadMigrationPreflight(input, actor, true);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw invalidDirectory();
    }
    return result;
  }

  /**
   * 方法作用：原管理算法仅在明确纯读入口切换为读取资格重核，不建立写入保护。
   *
   * @param readOnly true为本次明确读入口，false为原桥接管理入口
   * @return 原身份两坐标，例如tenantId81/userId8103
   * @throws CommonBusinessException 原管理资格或源角色失效拒绝，无配置写入
   */
  private java.util.Map<String, Long> management(boolean readOnly) {
    return readOnly ? authorization.requireReadManagement() : authorization.requireManagement();
  }
}
