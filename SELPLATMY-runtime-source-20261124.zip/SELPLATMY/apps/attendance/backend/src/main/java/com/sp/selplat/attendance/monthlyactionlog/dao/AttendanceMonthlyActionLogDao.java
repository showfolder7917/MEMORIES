package com.sp.selplat.attendance.monthlyactionlog.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceMonthlyActionLog 仅拥有本表公共查询与持久化，不跨表访问 DAO。 */
public interface AttendanceMonthlyActionLogDao extends BaseDao { }
