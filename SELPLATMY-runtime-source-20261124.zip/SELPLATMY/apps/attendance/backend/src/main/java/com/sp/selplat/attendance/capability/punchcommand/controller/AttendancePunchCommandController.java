package com.sp.selplat.attendance.capability.punchcommand.controller;

import com.sp.selplat.attendance.capability.punchcommand.service.AttendancePunchCommandService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Controller 只透传业务参数，不选择员工或认证身份。 */
@RestController
@RequestMapping("/api/attendance/punch")
public class AttendancePunchCommandController {
    private final AttendancePunchCommandService service;

    /**
     * @param service 管理补录服务；构造不写数据库。
     */
    public AttendancePunchCommandController(AttendancePunchCommandService service) {
        this.service = service;
    }

    /**
     * @param input 员工、打卡时间、类型与备注；
     * @return 完整 CommonResult JSON，例如 data.punchType=CLOCK_IN、data.sourceType=MANUAL；不改写服务结果。
     */
    @PostMapping("manual.htm")
    public String receiveManual(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.receiveManual(input));
    }

    /**
     * 透传 CSV 专用业务参数，身份和批次 ID 均由服务端产生。
     *
     * @param input 例如 sourceSystem=CSV_A、importKey=UPLOAD_001、csvText=四列CSV
     * @return 完整 CommonResult JSON，例如 data.importStatus=PARTIAL、data.resultJson 为逐行安全分类
     *     异常或副作用示例：同幂等键异文本拒绝；不接触外部连接或运行旧 SQL。
     */
    @PostMapping("importCsv.htm")
    public String importCsv(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.importCsv(input));
    }
}
