package com.sp.selplat.attendance.capability.sessioncontext.service;

import com.sp.selplat.common.util.CommonResult;

/** 考勤会话能力不落库，不继承默认 CRUD 或其固定管理员判定。 */
public interface AttendanceSessionContextService {
    /**
     * 读取真实会话对应的考勤安全上下文，不接受客户端身份参数。
     *
     * @return CommonResult，例如 data={userId:7,tenantId:2,canManage:false}
     * @throws com.sp.selplat.common.exception.CommonBusinessException 未登录或无有效租户时拒绝
     */
    CommonResult current();

    /**
     * 查询实际登录状态供匿名页面呈现，不授予考勤读写权限。
     *
     * @return 例如 {success:true,data:{authenticated:false}}；真实有效会话返回 authenticated=true
     *     异常或副作用示例：数据库故障继续抛出，不把服务异常当成匿名；无写入。
     */
    CommonResult status();
}
