package com.sp.selplat.attendance.attendancecase.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceCase 仅拥有本表公共查询与持久化，不跨表访问 DAO。 */
public interface AttendanceCaseDao extends BaseDao {
    /**
     * 锁定真实同租户启用案件并读取当前提交事实，绕开预锁查询缓存。
     *
     * @param input 实际身份主键例如 id=9501、tenantId=81
     * @return 实际案件Map例如 revision=0、caseStatus=SUBMITTED；缺失返回null
     *     异常或副作用示例：SQL等待/失败向上抛出，仅锁本表，持锁到业务事务结束。
     */
    java.util.Map<String, Object> lockCase(com.sp.selplat.common.util.CommonParam input);

    /**
     * 在同事务按租户/主键/启用/修订比较递增，不能无条件覆盖另一审批员。
     *
     * @param input 服务端核验参数例如 id=9501、tenantId=81、revision=0
     * @return 实际影响数例如1成功，0表示修订过期 异常或副作用示例：递增随日次/案件/审计一起回滚，不发放权限。
     */
    int claimRevision(com.sp.selplat.common.util.CommonParam input);
}
