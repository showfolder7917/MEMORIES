package com.sp.selplat.attendance.calclog.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceCalcLog 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceCalcLogService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用计算能力原子替换本日当前批次，旧批次软删除留存；没有 HTTP 直接调用入口。
   *
   * @param scope 服务端 dailyId、employeeId、workDate
   * @param records 真实算法产物共通批量参数，例如两条异常或五条计算步骤
   * @return 本表真实批量保存结果；缺管理配置或关联时拒绝，拥有本域事务
   */
  CommonResult replaceForDaily(
      CommonParam scope, com.sp.selplat.common.util.CommonBatchParam records);

  /**
   * 独立审批能力追加最终值重算解释，不删除原初算日志。
   *
   * @param input 内部日次事实，例如attendanceDailyId=100001、employeeId=8801、workDate=2026-10-04
   * @return 实际日志CommonResult，例如data.triggerType=APPROVED_PATCH、data.stepName=FINAL_PATCH_RECALC
   *     异常或副作用示例：缺审批配置或事实时拒绝；随审批事务追加，失败回滚。
   */
  CommonResult appendApproval(CommonParam input);
}
