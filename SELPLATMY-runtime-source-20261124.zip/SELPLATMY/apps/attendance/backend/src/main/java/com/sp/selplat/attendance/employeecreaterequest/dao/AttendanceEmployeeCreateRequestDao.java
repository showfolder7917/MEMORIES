/* 2026-10-29：固定员工新增私有持久表，不提供通用HTTP修改。 */
package com.sp.selplat.attendance.employeecreaterequest.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 只操作本表，固定请求编排由原employee聚合服务拥有。 */
public interface AttendanceEmployeeCreateRequestDao extends BaseDao {
  /**
   * 方法作用：验证原考勤可写读已提交事务，禁止自动提交或外域冒充。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无正确本域事务拒绝，不执行SQL
   */
  void requireTransaction();

  /**
   * 方法作用：按原全局账号及稳定请求键查询本表，锁模式持至原事务完成。
   *
   * @param accountId 原真实账号，例如9101
   * @param key 规范UUID，例如服务器原请求键
   * @param locking 已有考勤事务true，纯读false
   * @return 本表原行，例如stateCode RECORDED；无行null，不读取员工
   */
  Map<String, Object> find(long accountId, String key, boolean locking);

  /**
   * 方法作用：在原请求槽锁内用原修订推进当前尝试或记录已提交，不改不可变正文和主体。
   *
   * @param input 原定位及新状态，例如id100000/tenant9/expectedRevision0/currentAttemptId100001
   * @return 原CAS影响行数，例如1，竞争变化0
   */
  int advance(CommonParam input);
}
