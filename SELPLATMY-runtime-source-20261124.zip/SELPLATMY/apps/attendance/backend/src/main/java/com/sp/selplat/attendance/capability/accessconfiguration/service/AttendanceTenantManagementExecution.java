/* 文件：AttendanceTenantManagementExecution.java；职责：消费既有租户管理员并保护考勤实际提交；2026-10-27。 */
package com.sp.selplat.attendance.capability.accessconfiguration.service;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.exception.CommonSystemException;
import com.sp.selplat.common.service.authorization.TenantAdministratorStatus;
import com.sp.selplat.common.service.identity.LocalIdentityCommitSupport;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.service.authorization.LocalTenantAdministratorExecution;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 只保护考勤拥有方操作，不创建角色或考勤Grant，也不替代独立审批及月发布资格。 */
@Component
public class AttendanceTenantManagementExecution {
  // 真实认证拥有方提供角色、账号锁和提交前到期核验。
  private final LocalTenantAdministratorExecution roles;
  // 展示资格走统一只读合同，不能将远端标志提升为本地持锁证据。
  private final TenantAdministratorStatus administrators;
  // 真正执行任何管理回调前核部署是否具备原本地提交保护。
  private final LocalIdentityCommitSupport localCommit;
  // 本域实际事务管理器，不能借用认证库或其他业务事务。
  private final PlatformTransactionManager manager;
  // 标记仅存在于本次受保护同步提交期间，不能从HTTP或本地缓存提供。
  private final ThreadLocal<Map<String, Object>> protectedRole = new ThreadLocal<>();

  /**
   * 方法作用：装配原角色拥有方及考勤事务，不初始化资格。
   *
   * @param roles Host具名原管理员本地提交，例如已有TENANT_ADMIN任命100000
   * @param administrators Host具名attendanceTenantAdministratorStatus，例如原资格桥接或HTTP
   * @param localCommit Host具名attendanceLocalIdentityCommitSupport，HTTP不允许本地管理回调
   * @param manager 实际attendanceTransactionManager，例如独立AttendancePool 异常或副作用示例：构造只保留已有依赖，不创建管理员或人员。
   */
  public AttendanceTenantManagementExecution(
      @Qualifier("attendanceLocalTenantAdministratorExecution") LocalTenantAdministratorExecution roles,
      @Qualifier("attendanceTenantAdministratorStatus") TenantAdministratorStatus administrators,
      @Qualifier("attendanceLocalIdentityCommitSupport") LocalIdentityCommitSupport localCommit,
      @Qualifier("attendanceTransactionManager") PlatformTransactionManager manager) {
    this.roles = roles;
    this.administrators = administrators;
    this.localCommit = localCommit;
    this.manager = manager;
  }

  /**
   * 方法作用：只读当前真实任命，供配置页显示本租户管理入口。
   *
   * @return 真实返回示例：当前有效TENANT_ADMIN为true，无角色或到期为false。 异常或副作用示例：匿名沿统一身份错误拒绝，不写入授权。
   */
  public boolean isAdministrator() {
    try {
      var result = administrators.currentAdministrator();
      if (result == null
          || !result.isSuccess()
          || !(result.getData() instanceof Map<?, ?> state)
          || !(state.get("administratorActive") instanceof Boolean)) {
        throw new CommonSystemException(
            "PLATFORM_INTEGRATION_RESPONSE_INVALID",
            "管理员资格响应不符合合同。",
            new IllegalStateException("Administrator status contract is invalid"));
      }
      return Boolean.TRUE.equals(state.get("administratorActive"));
    } catch (CommonBusinessException failure) {
      // 这里只选择可选管理员路径；不替代普通账号原来的案件、本人月报或会话拒绝合同。
      if ("UNIAUTH_IDENTITY_REQUIRED".equals(failure.getErrorCode())
          || "UNIAUTH_AUTHORIZATION_ACTOR_MISMATCH".equals(failure.getErrorCode())) {
        return false;
      }
      throw failure;
    }
  }

  /**
   * 方法作用：在原管理裁决处验证本次角色锁工作范围和真实身份，不把预检当提交许可。
   *
   * @param identity 当前会话解析的身份，例如tenantId1/userId101000
   * @return 真实返回示例：本次保护范围且角色未变为true；范围外为false。 异常或副作用示例：角色到期或身份变化返回false，无授权和业务写入。
   */
  public boolean protects(Map<String, Long> identity) {
    var role = protectedRole.get();
    return role != null
        && role.equals(roles.currentEvidence())
        && String.valueOf(role.get("tenantId")).equals(String.valueOf(identity.get("tenantId")))
        && String.valueOf(role.get("userId")).equals(String.valueOf(identity.get("userId")));
  }

  /**
   * 方法作用：让已有租户管理员沿认证锁覆盖本域真正提交，普通账号继续执行原资格检查。
   *
   * @param operation 原拥有方限定字段及资源的调用，例如原employee.insert或person.store
   * @param <T> 原服务的返回类型，例如CommonResult或CommonPageResult
   * @return 真实返回示例：原success=true/data.id100000，或原分页对象；不另造业务回执。
   * @throws CommonBusinessException 外部事务、内部提前挂起或角色失效时拒绝并回滚 异常或副作用示例：角色提交前到期时人员、审计及UUID一起回滚，不写角色表。
   */
  public <T> T execute(Supplier<T> operation) {
    localCommit.requireSupported();
    if (protectedRole.get() != null) {
      // 内部MANDATORY调用只复用同一真实考勤事务；NOT_SUPPORTED不能绕出提交保护。
      if (!(manager instanceof DataSourceTransactionManager jdbc)
          || !TransactionSynchronizationManager.isActualTransactionActive()
          || !TransactionSynchronizationManager.hasResource(jdbc.getDataSource())) {
        throw new CommonBusinessException(
            "ATTENDANCE_MANAGEMENT_TRANSACTION_INVALID", "考勤管理操作需要保持原业务事务。");
      }
      return operation.get();
    }
    if (!isAdministrator()) {
      return operation.get();
    }
    return executeAdministrator(operation);
  }

  /**
   * 方法作用：明确要求管理员的原操作不允许在角色失效后回退成普通执行。
   *
   * @param operation 原拥有方实际操作，例如Person保存及员工来源核对
   * @param <T> 原返回类型，例如CommonResult
   * @return 真实返回示例：提交后的原人员回执id100000/versionNo0。 异常或副作用示例：角色在身份互斥等待期间失效时拒绝，零业务提交。
   */
  public <T> T executeAdministrator(Supplier<T> operation) {
    localCommit.requireSupported();
    if (protectedRole.get() != null) {
      return execute(operation);
    }
    var value = new AtomicReference<T>();
    try {
      roles.executeWithCurrentRole(
          manager,
          () -> {
            protectedRole.set(roles.currentEvidence());
            T actual = operation.get();
            value.set(actual);
            if (actual instanceof CommonResult result) {
              return result;
            }
            // 分页和内部值仍返回原对象，成功容器只适配既有角色执行合同。
            var outcome = new CommonResult();
            outcome.setSuccess(true);
            outcome.setData(actual);
            return outcome;
          });
      return value.get();
    } finally {
      // 包含所有beforeCommit与认证锁释放，异常、回滚和线程复用均不保留旧范围。
      protectedRole.remove();
    }
  }
}
