/* 2026-11-01：打卡与批次原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.schedulebatch.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 批量排班回执所属服务，通用写入口拒绝，只保存专用提交产生的成功事实。 */
public interface AttendanceScheduleBatchService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 查询当前真实操作者的精确请求键，不以最新回执替代。
   *
   * @param input 能力的请求键，例如requestKey=BATCH-001
   * @return 实际回执例如data.rowCount=2；不存在data=null，仅查询
   */
  CommonResult findReceipt(CommonParam input);

  /**
   * 保存成功尾回执，与全部排班共享事务。
   *
   * @param input 能力产生的完整指纹/结果，例如requestKey=BATCH-001、rowCount=2
   * @return 实际回执data.id=100001；尾SQL失败传播并回滚整个提交
   */
  CommonResult storeReceipt(CommonParam input);
}
