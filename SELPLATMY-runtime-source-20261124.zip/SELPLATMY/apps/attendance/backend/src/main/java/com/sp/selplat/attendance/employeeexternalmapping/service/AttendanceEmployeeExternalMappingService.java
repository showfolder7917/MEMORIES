/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.employeeexternalmapping.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceEmployeeExternalMapping 表服务，管理查询复用公共 CRUD；写入仅走本域专用流程。 */
public interface AttendanceEmployeeExternalMappingService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 登记精确映射。
   *
   * @param input 例如 CSV_A/X1/8801
   * @return PENDING 新增结果；无账号写入。
   */
  CommonResult register(CommonParam input);

  /**
   * 明确核准唯一映射。
   *
   * @param input 例如 id=100001
   * @return VERIFIED 结果；重复键拒绝。
   */
  CommonResult verify(CommonParam input);

  /**
   * 只解析单一核准键。
   *
   * @param input 例如 CSV_A/X1
   * @return RESOLVED/UNMATCHED/CONFLICT 明细；无写入。
   */
  CommonResult resolve(CommonParam input);

  /**
   * 撤销有冲突或错误的精确映射，不删历史打卡或解绑账号。
   *
   * @param input 本租户映射主键，例如 id=100001
   * @return 真实 REVOKED 更新结果；无权限时拒绝，无部分写入。
   */
  CommonResult revoke(CommonParam input);
}
