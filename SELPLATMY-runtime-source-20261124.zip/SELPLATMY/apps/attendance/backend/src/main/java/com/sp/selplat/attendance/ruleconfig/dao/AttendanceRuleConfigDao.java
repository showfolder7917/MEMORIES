package com.sp.selplat.attendance.ruleconfig.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceRuleConfig 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendanceRuleConfigDao extends BaseDao {
    /**
     * 用真实事务连接锁定本表启用规则。
     *
     * @param input 服务端租户/主键例如81/8501
     * @return 当前实际行含revision=0，无匹配null；仅行锁，无数据写入
     */
    java.util.Map<String, Object> lockRule(com.sp.selplat.common.util.CommonParam input);

    /**
     * 标记本表曾被真实关联引用，不递增编辑修订。
     *
     * @param input 已锁定主键/租户例如8501/81
     * @return 实际影响数例如1；随调用方事务回滚，不修改计算参数
     */
    int markReferenced(com.sp.selplat.common.util.CommonParam input);
}
