/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 修改记录：2026-10-27，原员工供通用人员稳定编号复用，读写边界及管理资格保持。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.attendance.employee.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.employee.dao.AttendanceEmployeeDao;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceEmployee 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceEmployeeServiceImpl extends BaseServiceImpl<AttendanceEmployeeDao>
    implements AttendanceEmployeeService {

  @Autowired
  @Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 方法作用：纯只读资格路径复用原分页，查询后重新核资格，不进入本地提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原分页，例如tenant9员工7001；资格撤销拒绝而不输出记录
   */
  @Override
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯只读资格路径复用原同租户详情查询，输出前再核管理资格。
   *
   * @param input 原主键，例如id7001
   * @return 原详情CommonResult，例如employeeName林老师，无写入
   */
  @Override
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯只读表头复用原ReferenceData及元数据解析，保持原系统入口门槛。
   *
   * @param viewCode 原viewCode或tableCode，例如table930001
   * @param locale 原语言，例如zh-CN
   * @return 原表头CommonResult，例如columns含员工姓名；不写表头配置
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：两条授权路径共用原租户与软删除覆盖，避免HTTP另写查询规则。
   *
   * @param input 原分页候选，例如客户端tenantId10仍由真实tenant9覆盖
   * @param actor 原资格拥有方身份，例如tenant9/user9101
   * @return 原DAO分页，例如本租户2条；只修改本次查询条件，不写数据库
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> actor) {
    input.putParam("tenantId", actor.get("tenantId"));
    input.putParam("status", 1);
    // 原sortnum相同也按唯一主键排序，防止真实相邻页重复同一员工。
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc, id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：两条授权路径共用原精确详情与租户检查，不改变投影。
   *
   * @param input 原主键，例如id7001
   * @param actor 真实身份，例如tenant9/user9101
   * @return 原详情CommonResult；无记录沿原错误拒绝，无写入
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> actor) {
    input.putParam("tenantId", actor.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：只读结果返回前核同一主体及原资格，不能将旧资格结果交给新学校。
   *
   * @param actor 查询前真实身份，例如tenant9/user9101
   * @param management 员工数据true，原表头只需系统入口false
   * @throws CommonBusinessException 身份或资格变化时拒绝，不返回已经读取的记录
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "员工读取期间身份已变化。");
    }
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    return super.insert(input);
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    return super.insertBatch(input);
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    return super.update(input);
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    return super.updateBatch(input);
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    return super.delete(input);
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    return super.deleteBatch(input);
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceEmployee 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 按真实员工映射读取本人资源。
   *
   * @param input 本域能力传入的资源主键，例如 id=100001；请求租户和员工字段不能授予权限
   * @return 真实 CommonResult，例如 success=true、data.id=100001、data.tenantId=81
   *     异常或副作用示例：例如缺员工映射、缺审批配置或异员工时拒绝；仅真实本表查询，无写入。
   */
  @Override
  public CommonResult getOwned(CommonParam input) {
    Map<String, Long> identity = authorization.requireEmployeeBinding();
    input.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> row = getDao().getById(input);
    if (row == null
        || !(row.get("id") instanceof Number owner)
        || owner.longValue() != identity.get("employeeId")) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(row, "本人员工资源已读取。");
  }

  /**
   * 读取建单真实员工归属，来源与旧日次JOIN员工字段一致，不用请求地点/部门。
   *
   * @param input 真实日次员工主键，例如id=8801
   * @return 实际CommonResult，例如data.employeeNo=TEST-81、data.workplaceId=1；没有写入
   *     异常或副作用示例：非管理用户只可读取已核验绑定本人，异员工/缺失配置拒绝。
   */
  @Override
  public CommonResult getForCase(CommonParam input) {
    Map<String, Long> identity;
    boolean owned = false;
    try {
      identity = authorization.requireManagement();
    } catch (CommonBusinessException unavailable) {
      if (!"ATTENDANCE_MANAGEMENT_UNAVAILABLE".equals(unavailable.getErrorCode())) {
        throw unavailable;
      }
      identity = authorization.requireEmployeeBinding();
      owned = true;
    }
    input.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> employee = getDao().getById(input);
    if (employee == null
        || (owned
            && (!(employee.get("id") instanceof Number id)
                || id.longValue() != identity.get("employeeId")))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(employee, "建单员工归属已读取。");
  }

  /**
   * 实际员工锁后重验管理许可，不使用先前查询缓存放行。
   *
   * @param input 能力的员工主键例如id=8801
   * @return 当前真实员工data.employeeName=隔离员工甲；等待撤权或异租户拒绝，无业务写入
   */
  @Override
  public CommonResult lockForSchedule(CommonParam input) {
    return loadScheduleLock(input, requireManagement(), false);
  }

  /**
   * 方法作用：账号预检同一原事务内保持员工锁，等待后重核原管理资格及源角色。
   *
   * @param input 原员工主键，例如id8801；不接受客户端租户选择
   * @return 原完整员工CommonResult，例如data.employeeName林老师
   * @throws CommonBusinessException 无外层事务、资格撤销或员工归属不符拒绝，零业务写入
   */
  @Override
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public CommonResult readLockForAccountBinding(CommonParam input) {
    return loadScheduleLock(input, authorization.requireReadManagement(), true);
  }

  /**
   * 方法作用：共用原排班员工锁SQL与结果，纯读额外重核同一主体。
   *
   * @param input 原员工主键，例如id8801
   * @param actor 原管理身份，例如tenantId81/userId8103
   * @param readOnly true为账号预检读取，false保持原排班路径
   * @return 原完整员工CommonResult，例如data.id8801
   * @throws CommonBusinessException 原员工不存在、归属不符或管理撤销拒绝，无业务写入
   */
  private CommonResult loadScheduleLock(
      CommonParam input, java.util.Map<String, Long> actor, boolean readOnly) {
    input.putParam("tenantId", actor.get("tenantId"));
    var row = getDao().lockForSchedule(input);
    var current = readOnly ? authorization.requireReadManagement() : requireManagement();
    if (readOnly && !actor.equals(current)) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(row, "排班员工已核验。");
  }

  /**
   * 用既有员工行串行化日月写入和关联，覆盖月报尚不存在时的并发空档。
   *
   * @param input 所属服务的真实员工主键例如id=8801；租户由当前许可覆盖
   * @return 锁中实际员工例如data.id=8801、data.tenantId=81 异常或副作用示例：本人传8803或等待撤权拒绝；仅持有本表行锁到事务结束。
   */
  @Override
  public CommonResult lockForResult(CommonParam input) {
    Map<String, Long> identity = resultIdentity();
    input.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> employee = getDao().lockForSchedule(input);
    Map<String, Long> current = resultIdentity();
    if (!identity.equals(current)
        || employee == null
        || (identity.containsKey("employeeId")
            && ((Number) employee.get("id")).longValue() != identity.get("employeeId"))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(employee, "日月员工锁已核验。");
  }

  /**
   * 仅沿用既有管理、审批、本人绑定合同，不提升角色或新建许可。
   *
   * @return 实际身份例如tenantId=81/userId=8102；本人身份另含employeeId 异常或副作用示例：所有既有许可均缺失时拒绝，仅读所属授权服务。
   */
  private Map<String, Long> resultIdentity() {
    try {
      return authorization.requireManagement();
    } catch (CommonBusinessException absent) {
      if (!"ATTENDANCE_MANAGEMENT_UNAVAILABLE".equals(absent.getErrorCode())) {
        throw absent;
      }
    }
    try {
      return authorization.requireApproval();
    } catch (CommonBusinessException absent) {
      if (!"ATTENDANCE_APPROVAL_UNAVAILABLE".equals(absent.getErrorCode())) {
        throw absent;
      }
    }
    return authorization.requireEmployeeBinding();
  }

  /**
   * 新月动作复用员工互斥，不借管理许可放行。
   *
   * @param input 内部实际id/actionCode例如8801/PUBLISH
   * @return 锁中实际员工data，仅读本表直到外层事务结束 异常示例：等待后撤权/归属变化拒绝，无权限配置写入。
   */
  @Override
  public CommonResult lockForRelease(CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    return loadReleaseLocked(input, authorization.requireReleaseAction(action), false);
  }

  /**
   * 方法作用：沿原管理资格读取员工稳定摘要，前后复核实际来源，不按姓名查找。
   *
   * @param input 明确主键，例如id8801
   * @return 真实返回示例：data.id="8801"/employeeNo="T001"/sourceVersion为64位SHA256。
   *     异常或副作用示例：失效、异租户或无管理资格拒绝，零写入。
   */
  @Override
  @OperationLog
  public CommonResult personReference(CommonParam input) {
    return loadPersonReference(input, requireManagement(), false);
  }

  /**
   * 方法作用：纯只读资格读取原安全员工来源，沿原行内容摘要及前后来源复核。
   *
   * @param input 原主键，例如id7001
   * @return 原4字段摘要，无电话或工资，无写入
   */
  @Override
  public CommonResult readPersonReference(CommonParam input) {
    return loadPersonReference(input, authorization.requireReadManagement(), true);
  }

  /**
   * 方法作用：原持锁与远端资格读取共用同一来源摘要、字段白名单及实际行比较。
   *
   * @param input 原精确主键，例如id7001
   * @param identity 查询前真实身份，例如tenant9/user9101
   * @param readOnly 纯资格读取true；原管理持锁读取false
   * @return 原安全4字段CommonResult；来源或资格变动拒绝，无写入
   */
  private CommonResult loadPersonReference(
      CommonParam input, Map<String, Long> identity, boolean readOnly) {
    personReferenceKeys(input, java.util.Set.of("id"));
    var selected = new CommonParam();
    selected.putParam("id", personReferenceId(input.getParam("id")));
    selected.putParam("tenantId", identity.get("tenantId"));
    var before = getDao().getById(selected);
    var safe = personReferenceProjection(before);
    var current = readOnly ? authorization.requireReadManagement() : requireManagement();
    if (!identity.equals(current) || !before.equals(getDao().getById(selected))) {
      throw personReferenceChanged();
    }
    return buildSuccessResult(safe, "原员工关联来源已读取。");
  }

  /**
   * 方法作用：持原员工行锁到调用方考勤事务提交，并按真实当前行核对所见摘要。
   *
   * @param input 服务间原主键及摘要，例如id8801/expectedSourceVersion64位SHA256
   * @return 真实返回示例：安全员工摘要，包含id、employeeNo、employeeName和sourceVersion。
   *     异常或副作用示例：没有考勤事务、来源变化或等待后失权拒绝，不修改员工。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public CommonResult lockPersonReference(CommonParam input) {
    var identity = requireManagement();
    personReferenceKeys(input, java.util.Set.of("id", "expectedSourceVersion"));
    var selected = new CommonParam();
    selected.putParam("id", personReferenceId(input.getParam("id")));
    selected.putParam("tenantId", identity.get("tenantId"));
    var row = getDao().lockForSchedule(selected);
    var safe = personReferenceProjection(row);
    if (!safe.get("sourceVersion").equals(input.getParam("expectedSourceVersion"))
        || !identity.equals(requireManagement())) {
      throw personReferenceChanged();
    }
    return buildSuccessResult(safe, "原员工关联来源已锁定核验。");
  }

  /**
   * 方法作用：保留完整原行作为变更摘要依据，仅公开关联必要信息。
   *
   * @param row 原员工实际行，例如tenant81/id8801/businessStatusACTIVE
   * @return 真实返回示例：{id:"8801",employeeNo:"T001",employeeName:"林老师",sourceVersion:64位摘要}。
   *     异常或副作用示例：已离职、软删除或不存在拒绝；不复制员工到人员表。
   */
  private static Map<String, Object> personReferenceProjection(Map<String, Object> row) {
    if (row == null
        || row.isEmpty()
        || !"1".equals(String.valueOf(row.get("status")))
        || !"ACTIVE".equals(row.get("businessStatus"))) {
      throw personReferenceChanged();
    }
    String hash =
        com.sp.selplat.common.support.CommonHashSupport.sha256(
            com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(new java.util.TreeMap<>(row)));
    return Map.of(
        "id",
        row.get("id").toString(),
        "employeeNo",
        row.get("employeeNo"),
        "employeeName",
        row.get("employeeName"),
        "sourceVersion",
        hash);
  }

  /**
   * 方法作用：关联输入仅接受明确字段，不能覆盖当前租户或管理身份。
   *
   * @param input 原候选，例如id8801
   * @param allowed 固定id或id与expectedSourceVersion 异常或副作用示例：tenantId、名字猜测或未知字段拒绝，不访问全表。
   */
  private static void personReferenceKeys(CommonParam input, java.util.Set<String> allowed) {
    if (input == null || !allowed.containsAll(input.getParamMap().keySet())) {
      throw personReferenceChanged();
    }
  }

  /**
   * 方法作用：解析无损正员工主键。
   *
   * @param value 前端编号，例如"8801"
   * @return 真实返回示例：8801L。 异常或副作用示例：小数、负数、前导零或溢出拒绝。
   */
  private static long personReferenceId(Object value) {
    try {
      String text = String.valueOf(value);
      if (!text.matches("[1-9][0-9]{0,18}")) {
        throw personReferenceChanged();
      }
      return Long.parseLong(text);
    } catch (NumberFormatException invalid) {
      throw personReferenceChanged();
    }
  }

  /**
   * 方法作用：统一关联来源变化拒绝，不泄露他校员工信息。
   *
   * @return 真实返回示例：ATTENDANCE_EMPLOYEE_REFERENCE_CHANGED业务异常。 异常或副作用示例：调用方事务回滚，不自动查同名替代。
   */
  private static CommonBusinessException personReferenceChanged() {
    return new CommonBusinessException(
        "ATTENDANCE_EMPLOYEE_REFERENCE_CHANGED", "员工来源已变化、不可关联或无权访问，请重新核对。");
  }

  /**
   * 方法作用：共用原独立月动作完整查询及真实锁顺序
   *
   * @param input 原所属坐标，例如id61000/actionCodePREPARE_REVIEW
   * @param identity 原已核独立身份，例如tenantId9/userId9102
   * @param pure 服务器固定HTTP true，原public路径false
   * @return 原完整来源，原过滤/锁不替换
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private com.sp.selplat.common.util.CommonResult loadReleaseLocked(
      com.sp.selplat.common.util.CommonParam input,
      java.util.Map<String, Long> identity,
      boolean pure) {
    String action = String.valueOf(input.getParam("actionCode"));
    input.putParam("tenantId", identity.get("tenantId"));
    var row = getDao().lockForSchedule(input);
    if (row == null
        || !identity.equals(
            (pure
                ? authorization.requireReadReleaseAction(action)
                : authorization.requireReleaseAction(action)))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(row, "月动作员工锁已核验。");
  }

  /**
   * 方法作用：HTTP独立动作来源读锁，必须加入原外层事务
   *
   * @param input 内部坐标和实际动作，例如id61000/PREPARE_REVIEW
   * @return 原完整结果，只查询/持锁直到调用者事务结束,无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      propagation = org.springframework.transaction.annotation.Propagation.MANDATORY)
  public com.sp.selplat.common.util.CommonResult readLockForRelease(
      com.sp.selplat.common.util.CommonParam input) {
    String action = String.valueOf(input.getParam("actionCode"));
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadReleaseLocked(input, actor, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
