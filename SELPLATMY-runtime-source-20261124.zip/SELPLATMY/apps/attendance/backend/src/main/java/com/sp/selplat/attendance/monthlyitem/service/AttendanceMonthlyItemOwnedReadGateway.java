/* 2026-11-01：本域原本人月报固定读取合同。 */
package com.sp.selplat.attendance.monthlyitem.service;

/** 原本人月报固定只读合同，由Host选择原桥接或纯读，不含发布写。 */
public interface AttendanceMonthlyItemOwnedReadGateway {
  /**
   * 方法作用：读取原本人已发布月或指标分页，不含管理及写动作
   *
   * @param input 原分页，例如pageNo1/monthlyId9601
   * @return 原CommonPageResult，例如totalCount2，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  com.sp.selplat.common.util.CommonPageResult ownedStore(
      com.sp.selplat.common.util.CommonPageParam input);
}
