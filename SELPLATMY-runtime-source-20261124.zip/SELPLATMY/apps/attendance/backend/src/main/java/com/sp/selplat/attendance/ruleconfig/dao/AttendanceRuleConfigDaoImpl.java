package com.sp.selplat.attendance.ruleconfig.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceRuleConfig，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceRuleConfigDaoImpl extends AttendanceBaseDao
        implements AttendanceRuleConfigDao {
    /**
     * 在编辑与新关联之间串行锁定本表真实行。
     *
     * @param input 已核验范围例如tenantId=81、id=8501
     * @return 实际当前字段例如revision=0；不存在null，无业务写入
     */
    @Override
    public java.util.Map<String, Object> lockRule(com.sp.selplat.common.util.CommonParam input) {
        // READ_COMMITTED下每次读取当前提交事实，不复用公共查询缓存。
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceRuleConfig WHERE tenantId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.getFirst();
    }

    /**
     * 永久保护已引用规则，不触碰历史日次或工时公式。
     *
     * @param input 当前规则范围例如tenantId=81、id=8501
     * @return 实际UPDATE影响数例如1；本域事务失败时回滚保护标志
     */
    @Override
    public int markReferenced(com.sp.selplat.common.util.CommonParam input) {
        // 必须在锁持有期间由所属Service调用，客户端没有设置标志的权限。
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.update(
                "UPDATE AttendanceRuleConfig SET referenceLocked=1 WHERE tenantId=? AND id=? AND status=1",
                input.getParam("tenantId"),
                input.getParam("id"));
    }
}
