/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：审批来源纯读接入，原保存/审批来源保护保持。 */
/* 2026-11-01：保留sortnum降序，同值固定id升序，避免分页依赖物理行次序。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.ruleconfig.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.ruleconfig.dao.AttendanceRuleConfigDao;
import com.sp.selplat.attendance.ruleconfig.service.AttendanceRuleConfigService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceRuleConfig 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceRuleConfigServiceImpl extends BaseServiceImpl<AttendanceRuleConfigDao>
    implements AttendanceRuleConfigService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  // 延迟取得所属服务，避免既有员工关联→规则依赖形成启动循环；不访问跨表DAO。
  @Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.attendance.employeeworkrule.service.AttendanceEmployeeWorkRuleService>
      workRules;

  @Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.attendance.daily.service.AttendanceDailyService>
      dailyResults;

  // 计算参数白名单；技术修订、引用保护及审计字段只由服务端写入。
  private static final java.util.List<String> CONFIG_FIELDS =
      java.util.List.of(
          "ruleCode",
          "ruleName",
          "standardDailyMinutes",
          "standardWeeklyMinutes",
          "autoBreakEnabled",
          "autoBreakThresholdMinutes",
          "autoBreakDeductMinutes",
          "nightWorkStart",
          "nightWorkEnd",
          "roundingUnitMinutes",
          "roundingMode",
          "monthlyOvertimeAlertHours",
          "yearlyOvertimeAlertHours",
          "paidLeaveReminderEnabled",
          "activeFlag",
          "note");

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement(), false);
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insert(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    prepareCreate(input);
    return super.insert(input);
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult insertBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      prepareCreate(item);
    }
    return super.insertBatch(input);
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    prepareMutation(input, true);
    return super.update(input);
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    for (CommonParam item : ordered(input)) {
      prepareMutation(item, true);
    }
    return super.updateBatch(input);
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    prepareMutation(input, false);
    return super.delete(input);
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    for (CommonParam item : ordered(input)) {
      prepareMutation(item, false);
    }
    return super.deleteBatch(input);
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceRuleConfig 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批能力的受控字段，例如employeeId=8801、workDate=2026-10-04
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  @Override
  public CommonResult findForApproval(CommonParam criteria) {
    return loadApprovalSource(criteria, authorization.requireApproval());
  }

  /**
   * 关联写入在真实规则锁内标记永久保护；已有规则读取不修改计算字段。
   *
   * @param input 所属员工关联服务传入例如id=8501
   * @return 实际规则字段例如revision=0、referenceLocked=1；失效或异租户拒绝，保护标志随事务回滚
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult lockForReference(CommonParam input) {
    input.putParam("tenantId", requireManagement().get("tenantId"));
    // 所属DAO的当前锁查询与编辑共用同一行锁；等待后重新核验许可。
    Map<String, Object> row = getDao().lockRule(input);
    requireManagement();
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    if (getDao().markReferenced(input) != 1) {
      throw new CommonBusinessException("ATTENDANCE_RULE_STALE", "计算规则配置已更新，请重新选择后再编辑。");
    }
    row.put("referenceLocked", 1);
    return buildSuccessResult(row, "规则引用已保护。");
  }

  /**
   * 读取当前规则是否曾被保留关联或日次引用，不访问其他表DAO。
   *
   * @param input 服务端范围例如id=8501、tenantId=81
   * @param row 实际当前规则例如referenceLocked=0
   * @return 实际任一引用存在true，无引用false；仅读库，缺可信许可拒绝
   */
  private boolean isReferenced(CommonParam input, Map<String, Object> row) {
    return isReferenced(input, row, false);
  }

  /**
   * 全部归属预检后按固定主键顺序取得批量锁，重复主键拒绝。
   *
   * @param input 实际批量例如items=[{id:8502,revision:0},{id:8501,revision:0}]
   * @return 同一参数项按主键排序的副本；无写入，重复主键抛配置参数错误
   */
  private java.util.List<CommonParam> ordered(CommonBatchParam input) {
    var items = new java.util.ArrayList<>(input.getItems());
    items.sort(
        java.util.Comparator.comparingLong(
            item ->
                new java.math.BigDecimal(String.valueOf(item.getParam("id"))).longValueExact()));
    var seen = new java.util.HashSet<String>();
    for (CommonParam item : items) {
      if (!seen.add(
          String.valueOf(
              new java.math.BigDecimal(String.valueOf(item.getParam("id"))).longValueExact()))) {
        throw invalid();
      }
    }
    return items;
  }

  /**
   * 锁内核对修订、永久引用及真实参数，再交公共CRUD写入。
   *
   * @param input 来自管理表单例如id=8502、revision=0、ruleName=日班规则
   * @param update true编辑计算配置、false软删除；不修改任何历史结果 副作用示例：成功参数修订变1；过期、被引用、非法参数拒绝整个事务。
   * @throws CommonBusinessException
   *     考勤记录不存在、失效或无权访问。；计算规则配置已更新，请重新选择后再编辑。；计算规则配置已被引用，请新建规则并明确关联生效日期。
   */
  private void prepareMutation(CommonParam input, boolean update) {
    Map<String, Object> row = getDao().lockRule(input);
    requireManagement();
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    long expected;
    try {
      expected =
          new java.math.BigDecimal(String.valueOf(input.getParam("revision"))).longValueExact();
    } catch (NumberFormatException | ArithmeticException bad) {
      throw new CommonBusinessException("ATTENDANCE_RULE_STALE", "计算规则配置已更新，请重新选择后再编辑。");
    }
    if (expected < 0 || expected != ((Number) row.get("revision")).longValue()) {
      throw new CommonBusinessException("ATTENDANCE_RULE_STALE", "计算规则配置已更新，请重新选择后再编辑。");
    }
    // 任意保留引用（含历史、未来和软删除）禁止原地重写；新版本须新编号并显式设关联生效边界。
    if (isReferenced(input, row)) {
      throw new CommonBusinessException("ATTENDANCE_RULE_REFERENCED", "计算规则配置已被引用，请新建规则并明确关联生效日期。");
    }
    Map<String, Object> values = new java.util.LinkedHashMap<>(row);
    input
        .getParamMap()
        .forEach(
            (key, value) -> {
              if (CONFIG_FIELDS.contains(key)) {
                values.put(key, value);
              }
            });
    if (update) {
      validateConfiguration(values);
    }
    Object id = input.getParam("id"), tenant = input.getParam("tenantId");
    input.getParamMap().clear();
    input.putParam("id", id);
    input.putParam("tenantId", tenant);
    input.putParam("revision", Math.addExact(expected, 1));
    if (update) {
      for (String field : CONFIG_FIELDS) {
        input.putParam(field, values.get(field));
      }
    }
  }

  /**
   * 创建规则仅接收白名单字段，填DDL已有缺省值；不接受技术版本/保护标志伪造。
   *
   * @param input 表单实际配置例如ruleCode=DAY-V2、standardDailyMinutes=480
   *     副作用示例：参数revision=0、referenceLocked=0；非法值抛明确业务错误且不写表。
   */
  private void prepareCreate(CommonParam input) {
    Map<String, Object> values = new java.util.LinkedHashMap<>();
    input
        .getParamMap()
        .forEach(
            (key, value) -> {
              if (CONFIG_FIELDS.contains(key)) {
                values.put(key, value);
              }
            });
    for (String field :
        java.util.List.of(
            "autoBreakEnabled",
            "autoBreakThresholdMinutes",
            "autoBreakDeductMinutes",
            "roundingUnitMinutes")) {
      values.putIfAbsent(field, 0);
    }
    values.putIfAbsent("roundingMode", "NONE");
    values.putIfAbsent("monthlyOvertimeAlertHours", 45);
    values.putIfAbsent("yearlyOvertimeAlertHours", 360);
    values.putIfAbsent("paidLeaveReminderEnabled", 1);
    values.putIfAbsent("activeFlag", 1);
    validateConfiguration(values);
    input.setParamMap(values);
    input.putParam("revision", 0);
    input.putParam("referenceLocked", 0);
  }

  /**
   * 校验DDL范围和旧算法明确支持的参数，不新增工资/工时政策。
   *
   * @param values 完整配置例如roundingMode=ROUND_DOWN、roundingUnitMinutes=15
   *     副作用示例：整数规范为实际int；负数、小数、未知模式/无效时间拒绝，无数据写入。
   */
  private void validateConfiguration(Map<String, Object> values) {
    for (String field : java.util.List.of("ruleCode", "ruleName")) {
      Object value = values.get(field);
      int limit = field.equals("ruleCode") ? 50 : 200;
      if (!(value instanceof CharSequence)
          || value.toString().isBlank()
          || value.toString().length() > limit) {
        throw invalid();
      }
    }
    if (values.get("note") != null
        && (!(values.get("note") instanceof CharSequence)
            || values.get("note").toString().length() > 500)) {
      throw invalid();
    }
    for (String field :
        java.util.List.of(
            "standardDailyMinutes",
            "standardWeeklyMinutes",
            "autoBreakEnabled",
            "autoBreakThresholdMinutes",
            "autoBreakDeductMinutes",
            "roundingUnitMinutes",
            "monthlyOvertimeAlertHours",
            "yearlyOvertimeAlertHours",
            "paidLeaveReminderEnabled",
            "activeFlag")) {
      try {
        // 仅INT非负、开关0/1；0的旧语义保持，不发明法定上限或扣休政策。
        Object value = values.get(field);
        int number =
            value == null && field.equals("roundingUnitMinutes")
                ? 0
                : new java.math.BigDecimal(String.valueOf(value)).intValueExact();
        if (number < 0
            || (java.util.List.of("autoBreakEnabled", "paidLeaveReminderEnabled", "activeFlag")
                    .contains(field)
                && number > 1)) {
          throw invalid();
        }
        values.put(field, number);
      } catch (NumberFormatException | ArithmeticException bad) {
        throw invalid();
      }
    }
    for (String field : java.util.List.of("nightWorkStart", "nightWorkEnd")) {
      Object value = values.get(field);
      try {
        if (!(value instanceof CharSequence) || value.toString().length() > 20) {
          throw invalid();
        }
        java.time.LocalTime.parse(value.toString());
      } catch (java.time.format.DateTimeParseException bad) {
        throw invalid();
      }
    }
    if (values.get("roundingMode") != null
        && !(values.get("roundingMode") instanceof CharSequence)) {
      throw invalid();
    }
    String mode =
        values.get("roundingMode") == null ? "NONE" : values.get("roundingMode").toString();
    if (mode.isBlank()) {
      mode = "NONE";
    }
    if (!java.util.Set.of("NONE", "ROUND_UP", "ROUND_DOWN", "ROUND_NEAREST").contains(mode)) {
      throw invalid();
    }
    if (!mode.equals("NONE") && (Integer) values.get("roundingUnitMinutes") <= 0) {
      throw invalid();
    }
    values.put("roundingMode", mode);
  }

  /**
   * @return 明确配置参数错误例如ATTENDANCE_RULE_INVALID；不包含原始数据，无持久化副作用。
   */
  private CommonBusinessException invalid() {
    return new CommonBusinessException("ATTENDANCE_RULE_INVALID", "计算规则配置参数无效，请检查整数、开关、夜间时间和舍入方式。");
  }

  /**
   * 方法作用：共用原租户范围与查询投影，不新增业务规则。
   *
   * @param input 原查询，例如id8501
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonPageResult，例如原配置行及引用保护
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原租户范围与查询投影，不新增业务规则。
   *
   * @param input 原查询，例如id8501
   * @param identity 原已核资格，例如tenantId9
   * @param readOnly 仅新HTTP纯读时true，原桥接false
   * @return 原完整CommonResult，例如原配置行及引用保护
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity, boolean readOnly) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    CommonResult result = super.getById(input);
    // 真正所属服务核对所有保留引用，页面得到保护事实但不获得修改权。
    ((Map<String, Object>) result.getData())
        .put(
            "configurationProtected",
            isReferenced(input, (Map<String, Object>) result.getData(), readOnly));
    return result;
  }

  /**
   * 方法作用：同一永久引用算法仅选择原持锁或纯读资格，保留全部历史行。
   *
   * @param input 原编号，例如id8501
   * @param row 原本表行，例如referenceLocked0
   * @param readOnly 仅纯读路径true
   * @return 原任一保留引用存在true，不生成引用
   */
  private boolean isReferenced(CommonParam input, Map<String, Object> row, boolean readOnly) {
    // 本表永久标记先保护新引用；旧库未记录标记时由实际保留行补足。
    return ((Number) row.get("referenceLocked")).intValue() != 0
        || (readOnly
                ? workRules.getObject().countRuleReferencesForRead(input)
                : workRules.getObject().countRuleReferences(input))
            > 0
        || (readOnly
                ? dailyResults.getObject().countRuleReferencesForRead(input)
                : dailyResults.getObject().countRuleReferences(input))
            > 0;
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原详情与全部保留引用检查，不获得修改许可。
   *
   * @param input 原主键，例如id8501
   * @return 原完整详情，例如configurationProtected为true或false
   * @throws CommonBusinessException 异租户、缺记录或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor, true);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：原配置和元数据表头沿系统查看门槛读取，不提升管理权限。
   *
   * @param viewCode 原表头编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns包含配置名称
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无配置写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "配置读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原审批来源完整过滤和返回，不锁定或标记引用。
   *
   * @param criteria 原来源条件，例如employeeId7080
   * @param identity 原已核审批身份，例如userId9102/tenantId9
   * @return 原CommonResult，例如原生效规则或排班
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原记录/来源错误沿原拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonResult loadApprovalSource(
      com.sp.selplat.common.util.CommonParam criteria, java.util.Map<String, Long> identity) {
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "审批计算来源已读取。");
  }

  /**
   * 方法作用：HTTP身份原审批来源只读，实际SELECT完成后重核资格。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原完整来源，不改变规则或快照
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原APPROVER失效/撤回或身份变化拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonResult readFindForApproval(
      com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadApprovalSource(input, actor);
    if (!actor.equals(authorization.requireReadApproval())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "审批来源读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
