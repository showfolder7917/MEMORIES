/* 2026-11-01：原独立月动作固定两读合同，不包含发布或回调。 */
package com.sp.selplat.attendance.capability.monthlyrelease.service;

/** 仅原月列表和锁中当前来源，由Host选择身份运输，算法及锁属于本域。 */
public interface AttendanceMonthlyReleaseReadGateway {
  /**
   * 方法作用：读取原独立角色月列表
   *
   * @param input 原月份分页，例如2026-10
   * @return 原CommonPageResult，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonPageResult getStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：读取原锁中来源及版本
   *
   * @param input 原monthlyId，例如61000
   * @return 原CommonResult，例如sourceVersion63000，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult current(com.sp.selplat.common.util.CommonParam input);
}
