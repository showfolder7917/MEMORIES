/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
/* 2026-10-27：沿已有公开身份刷新及统一认证错误合同补齐锁后核验。 */
package com.sp.selplat.attendance.capability.accountbinding.service.impl;

import com.sp.selplat.attendance.capability.accountbinding.service.AttendanceAccountDirectory;
import com.sp.selplat.attendance.capability.accountbinding.service.AttendancePublicAccountDirectoryProvider;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

/** 只读公共目录到本域SPI转换，缺owner provider默认拒绝；禁止登录名/凭据字段转发。 */
@Service
public class AttendancePublicAccountDirectoryAdapter implements AttendanceAccountDirectory {
    private final CurrentSessionAccess sessions;
    private final ObjectProvider<AttendancePublicAccountDirectoryProvider> providers;

    /**
     * 装配真实Session和可选owner公共provider，不装配认证内部DAO或权限事实表。
     *
     * @param sessions Host具名公共身份查询，例如强制刷新返回当前81/8103
     * @param providers 可选只读provider，当前生产缺失时抛UNAVAILABLE而非返回空成功
     */
    public AttendancePublicAccountDirectoryAdapter(
            @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
                    CurrentSessionAccess sessions,
            ObjectProvider<AttendancePublicAccountDirectoryProvider> providers) {
        this.sessions = sessions;
        this.providers = providers;
    }

    /**
     * 核验当前身份、固定动作和公共事实，转换id为本域userId；不接受请求字段作为身份。
     *
     * @param identity 上层已核验的服务端userId/tenantId，必须与fresh Session一致
     * @param targetUserId 正整数公开账号，例如8104
     * @param action 固定BIND_EMPLOYEE_ACCOUNT或UNBIND_EMPLOYEE_ACCOUNT
     * @return 仅本域公共事实，例如userId8104/tenantId81/status1/directoryRevision rev2
     *     异常或副作用示例：provider缺失/撤权/事实漂移拒绝，零业务写入。
     */
    @Override
    public Map<String, Object> requireAccount(
            Map<String, Long> identity, long targetUserId, String action) {
        var actor = current(identity);
        requireAction(action);
        if (targetUserId <= 0) {
            throw invalid();
        }
        var fact =
                project(
                        provider()
                                .requireSelectionAccount(actor, targetUserId, shortAction(action)),
                        actor,
                        action);
        if (((Number) fact.get("userId")).longValue() != targetUserId) {
            throw invalid();
        }
        current(actor);
        return fact;
    }

    /**
     * 将公共LIST分页映射为固定五列，保留服务端COUNT/页码；快照由上层逐目标require再核验。
     *
     * @param identity 已核验的服务端身份，例如81/8103，前后与fresh Session比较
     * @param action 固定选择动作BIND_EMPLOYEE_ACCOUNT或UNBIND_EMPLOYEE_ACCOUNT
     * @param pageNo 1起始页码例如2
     * @param pageSize 限制1至100，例如20
     * @param accountIdExact 明确公开ID字符串例如8104；空表示分页，不传登录名/显示名筛选
     * @return 仅id/displayName/status/tenantId/directoryRevision的公共分页；无权限不伪造空成功
     */
    @Override
    public CommonPageResult searchAccounts(
            Map<String, Long> identity,
            String action,
            int pageNo,
            int pageSize,
            String accountIdExact) {
        var actor = current(identity);
        requireAction(action);
        if (pageNo < 1 || pageSize < 1 || pageSize > 100) {
            throw invalid();
        }
        Long exact =
                accountIdExact == null || accountIdExact.isBlank()
                        ? null
                        : positive(accountIdExact);
        var input = new CommonParam();
        input.putParam("action", shortAction(action));
        input.putParam("pageNo", pageNo);
        input.putParam("pageSize", pageSize);
        if (exact != null) {
            input.putParam("accountIdExact", exact);
        }
        var page = publicPage(provider().selectionPage(input));
        if (page == null
                || page.getRecords() == null
                || page.getRecords().size() > pageSize
                || page.getTotalCount() < page.getRecords().size()
                || !Integer.valueOf(pageNo).equals(page.getPageNo())
                || !Integer.valueOf(pageSize).equals(page.getPageSize())) {
            throw invalid();
        }
        long offset = (pageNo - 1L) * pageSize;
        long expectedRows = Math.min(pageSize, Math.max(0, page.getTotalCount() - offset));
        if (page.getRecords().size() != expectedRows
                || (exact != null && page.getTotalCount() > 1)) {
            throw invalid();
        }
        var safe = new java.util.ArrayList<Map<String, Object>>();
        var ids = new java.util.HashSet<Long>();
        for (var row : page.getRecords()) {
            var fact = project(row, actor, action);
            long id = ((Number) fact.get("userId")).longValue();
            if (!ids.add(id) || (exact != null && id != exact)) {
                throw invalid();
            }
            var output = new LinkedHashMap<>(fact);
            output.remove("userId");
            output.put("id", id);
            safe.add(Map.copyOf(output));
        }
        current(actor);
        var result = new CommonPageResult();
        result.setRecords(safe);
        result.setPageNo(pageNo);
        result.setPageSize(pageSize);
        result.setTotalCount(page.getTotalCount());
        return result;
    }

    /**
     * 只取五个公共字段，规范整数包装；不遍历或复制provider额外私有字段。
     *
     * @param row 公共事实，例如id8104/tenantId81/status1/revision rev2
     * @param actor 当前真实身份81/8103，用服务端租户核对归属
     * @param action 当前固定BIND/UNBIND动作
     * @return 不可变本域公共事实，id转换为userId，原revision作为不透明字符串保留
     */
    private Map<String, Object> project(
            Map<String, Object> row, Map<String, Long> actor, String action) {
        if (row == null
                || !(row.get("id") instanceof Number)
                || !(row.get("tenantId") instanceof Number)) {
            throw invalid();
        }
        long id = positive(row.get("id")), tenant = positive(row.get("tenantId"));
        if (tenant != actor.get("tenantId") || !(row.get("status") instanceof Number state)) {
            throw invalid();
        }
        int status;
        try {
            status = new BigDecimal(state.toString()).intValueExact();
        } catch (NumberFormatException | ArithmeticException invalidState) {
            throw invalid();
        }
        if ((status != 0 && status != 1)
                || (action.equals("BIND_EMPLOYEE_ACCOUNT") && status != 1)
                || !(row.get("displayName") instanceof String display)
                || display.length() > 200) {
            throw invalid();
        }
        Object rawRevision = row.get("directoryRevision");
        String revision;
        if (rawRevision instanceof Number number) {
            try {
                var numeric = new BigDecimal(number.toString()).stripTrailingZeros();
                if (numeric.signum() < 0 || numeric.scale() > 0) {
                    throw invalid();
                }
                revision = numeric.toPlainString();
            } catch (NumberFormatException invalidNumber) {
                throw invalid();
            }
        } else if (rawRevision instanceof String value
                && !value.isBlank()
                && value.length() <= 128
                && value.equals(value.trim())) {
            revision = value;
        } else {
            throw invalid();
        }
        return Map.of(
                "userId",
                id,
                "tenantId",
                tenant,
                "status",
                status,
                "displayName",
                display,
                "directoryRevision",
                revision);
    }

    /**
     * 每次实际Session读取身份并与上层身份一致，不缓存或接受客户端actor。
     *
     * @param expected 上层真实身份例如tenant81/user8103
     * @return fresh Session仅userId/tenantId
     * @throws CommonBusinessException 身份漂移抛目录拒绝；无业务写入
     */
    private Map<String, Long> current(Map<String, Long> expected) {
        var actual = AttendanceAccessGuard.requireIdentity(sessions.revalidateCurrent());
        if (!actual.equals(expected)) {
            throw new CommonBusinessException(
                    "ATTENDANCE_ACCOUNT_DIRECTORY_DENIED", "公开账号目录当前身份不一致。");
        }
        return actual;
    }

    /**
     * @return owner公共provider；缺失抛UNAVAILABLE，不猜URL或在本域造权限源
     * @throws CommonBusinessException 公共provider未配置时默认拒绝
     */
    private AttendancePublicAccountDirectoryProvider provider() {
        var candidates = providers.orderedStream().toList();
        var provider = candidates.size() == 1 ? candidates.getFirst() : null;
        if (provider == null) {
            throw new CommonBusinessException(
                    "ATTENDANCE_ACCOUNT_DIRECTORY_UNAVAILABLE", "权威公共账号目录provider尚未接入。");
        }
        return provider;
    }

    /**
     * 严格读取owner冻结data四项；不把普通records分页或失败data当成功。
     *
     * @param response owner selectionPage返回，例如success=true/data.items为公共列表
     * @return 实际公共页映射为本域CommonPageResult，COUNT保留不事后过滤或重算
     * @throws CommonBusinessException 失败或字段/类型/数值无效默认拒绝，无业务写入
     */
    private CommonPageResult publicPage(CommonResult response) {
        if (response == null) {
            throw invalid();
        }
        if (!response.isSuccess()) {
            String code = response.getErrorCode();
            if (java.util.Set.of(
                            "UNIAUTH_IDENTITY_REQUIRED",
                            "UNIAUTH_ACCOUNT_DIRECTORY_INPUT_INVALID",
                            "UNIAUTH_ACCOUNT_DIRECTORY_UNAVAILABLE",
                            "UNIAUTH_ACCOUNT_DIRECTORY_DENIED")
                    .contains(code == null ? "" : code)) {
                throw new CommonBusinessException(code, "公共账号目录无法证明当前选择范围。");
            }
            throw invalid();
        }
        if (!(response.getData() instanceof Map<?, ?> data)
                || !data.keySet()
                        .equals(java.util.Set.of("items", "totalCount", "pageNo", "pageSize"))
                || !(data.get("items") instanceof java.util.List<?> items)) {
            throw invalid();
        }
        var rows = new java.util.ArrayList<Map<String, Object>>();
        for (var item : items) {
            if (!(item instanceof Map<?, ?> row)
                    || !row.keySet()
                            .equals(
                                    java.util.Set.of(
                                            "id",
                                            "displayName",
                                            "status",
                                            "tenantId",
                                            "directoryRevision"))) {
                throw invalid();
            }
            var safe = new LinkedHashMap<String, Object>();
            for (var field : row.entrySet()) {
                safe.put((String) field.getKey(), field.getValue());
            }
            rows.add(safe);
        }
        var page = new CommonPageResult();
        page.setRecords(rows);
        page.setTotalCount(nonnegative(data.get("totalCount")));
        long number = nonnegative(data.get("pageNo")), size = nonnegative(data.get("pageSize"));
        if (number < 1 || number > Integer.MAX_VALUE || size < 1 || size > 100) {
            throw invalid();
        }
        page.setPageNo((int) number);
        page.setPageSize((int) size);
        return page;
    }

    /**
     * @param value owner数字值，例如COUNT 2；字符串/小数/负数/溢出拒绝
     * @return 精确非负long，例如2；不截断或回落默认COUNT
     */
    private long nonnegative(Object value) {
        if (value instanceof Number number) {
            try {
                long exact = new BigDecimal(number.toString()).longValueExact();
                if (exact >= 0) {
                    return exact;
                }
            } catch (NumberFormatException | ArithmeticException invalidNumber) {
                // 数值无效按合同拒绝。
            }
        }
        throw invalid();
    }

    /**
     * @param action 上层固定长动作，例如BIND_EMPLOYEE_ACCOUNT；客户端不可指定任意动作
     * @return owner唯一短动作BIND或UNBIND，LIST始终由owner固定裁决
     */
    private String shortAction(String action) {
        requireAction(action);
        return action.equals("BIND_EMPLOYEE_ACCOUNT") ? "BIND" : "UNBIND";
    }

    /**
     * @param action 仅固定BIND/UNBIND选择动作，其他值拒绝
     */
    private void requireAction(String action) {
        if (!"BIND_EMPLOYEE_ACCOUNT".equals(action) && !"UNBIND_EMPLOYEE_ACCOUNT".equals(action)) {
            throw invalid();
        }
    }

    /**
     * @param value 明确正整数公开ID，例如8104；小数/溢出/缺失拒绝
     * @return 精确long，无同数字身份映射或租户回退
     */
    private long positive(Object value) {
        try {
            long id = new BigDecimal(String.valueOf(value)).longValueExact();
            if (id > 0) {
                return id;
            }
        } catch (NumberFormatException | ArithmeticException invalidNumber) {
            // 拒绝非法ID，不改写为0或默认身份。
        }
        throw invalid();
    }

    /**
     * @return 统一公共字段/分页无效错误，不在消息中泄露字段值。
     */
    private CommonBusinessException invalid() {
        return new CommonBusinessException(
                "ATTENDANCE_ACCOUNT_DIRECTORY_INPUT_INVALID", "公开账号目录分页或安全事实无效。");
    }
}
