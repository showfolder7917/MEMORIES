/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.monthlyreview.controller;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceConfigurationReadGateway;
import com.sp.selplat.attendance.monthlyreview.service.AttendanceMonthlyReviewService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** 账本管理历史复用共通Controller；所有通用变更在所属Service拒绝，只能经独立月动作能力写入。 */
@RestController
@RequestMapping("/api/attendance/monthlyreview")
public class AttendanceMonthlyReviewController
    extends BaseController<AttendanceMonthlyReviewService> {

  private final AttendanceConfigurationReadGateway managementReads;

  /**
   * 方法作用：装配原管理查询，其他原处理器及写保护保留。
   *
   * @param managementReads 原具名管理网关，例如bridge或HTTP；构造不读写业务
   */
  public AttendanceMonthlyReviewController(
      @org.springframework.beans.factory.annotation.Qualifier("attendanceMonthlyReviewReadGateway")
          AttendanceConfigurationReadGateway managementReads) {
    this.managementReads = managementReads;
  }

  /**
   * 方法作用：保留原分页URL和GET/POST，委派固定只读网关。
   *
   * @param input 原CommonPageParam，例如pageNo1/pageSize20
   * @return 原分页JSON，不在Controller改变身份或条件
   */
  @Override
  @RequestMapping(
      value = "getStore.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getStore(input));
  }

  /**
   * 方法作用：保留原详情URL和GET/POST，权限与租户判断仍由原配置拥有方完成。
   *
   * @param input 原精确主键，例如id8501
   * @return 原CommonResult JSON，无写入
   */
  @Override
  @RequestMapping(
      value = "getById.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getById(input));
  }

  /**
   * 方法作用：保留原viewCode表头协议及默认语言。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原列配置JSON，不替换原配置来源
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "!tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumn(
      @RequestParam(name = "viewCode", defaultValue = "default") String viewCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getGridColumn(viewCode, locale));
  }

  /**
   * 方法作用：保留原tableCode响应形状，仍由原配置拥有方核实际表名。
   *
   * @param tableCode 原Grid唯一编码，例如table930001
   * @param locale 原语言，例如ja-JP
   * @return 原JSON，data中tableCode替代viewCode，无配置写入
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumnByTableCode(
      @RequestParam(name = "tableCode") String tableCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    CommonResult result = managementReads.getGridColumn(tableCode, locale);
    if (result.getData() instanceof java.util.Map<?, ?> original) {
      var data = new java.util.LinkedHashMap<String, Object>();
      original.forEach((key, value) -> data.put(String.valueOf(key), value));
      data.remove("viewCode");
      data.put("tableCode", tableCode);
      result.setData(data);
    }
    return JsonUtils.toJsonIgnoreNull(result);
  }

  /**
   * 方法作用：保留原批量POST JSON协议，仅转交同一拥有方固定读取合同
   *
   * @param input 原JSON正文，例如items含62000和62001
   * @return 原完整JSON，例如success为true且data为原批量列表，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @org.springframework.web.bind.annotation.RequestMapping(
      value = "getByIds.htm",
      method = org.springframework.web.bind.annotation.RequestMethod.POST,
      produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
  public String getByIds(
      @org.springframework.web.bind.annotation.RequestBody
          com.sp.selplat.common.util.CommonBatchParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(managementReads.getByIds(input));
  }
}
