package com.sp.selplat.attendance.capability.calculationcommand.controller;

import com.sp.selplat.attendance.capability.calculationcommand.service.AttendanceCalculationCommandService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Controller 只透传计算参数并序列化完整服务返回。 */
@RestController
@RequestMapping("/api/attendance/calculation")
public class AttendanceCalculationCommandController {
    private final AttendanceCalculationCommandService service;

    /**
     * @param service 本域日月计算能力；构造不读写数据库。
     */
    public AttendanceCalculationCommandController(AttendanceCalculationCommandService service) {
        this.service = service;
    }

    /**
     * @param input 员工与业务日；
     * @return 共通结果 JSON，例如
     *     {"success":true,"data":{"actualWorkMinutes":510},"msg":"详情查询完成。"}；统一序列化完整服务返回。
     */
    @PostMapping("daily.htm")
    public String daily(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.daily(input));
    }

    /**
     * @param input 员工与年月；
     * @return 共通结果 JSON，例如
     *     {"success":true,"data":{"totalWorkMinutes":510,"closeStatus":"OPEN"},"msg":"详情查询完成。"}；完整结构由服务负责。
     */
    @PostMapping("monthly.htm")
    public String monthly(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.monthly(input));
    }

    /**
     * 原样序列化结月能力的完整结果，不计算或拼装成功数。
     *
     * @param input 范围表单，例如yearMonth=2026-10、scopeType=ALL
     * @return 例如JSON success=true、data.closedCount=1；异常由共享处理层返回 异常或副作用示例：存在OPEN月次时整批拒绝；写入由本域能力事务完成。
     */
    @PostMapping("close-period.htm")
    public String closePeriod(CommonParam input) {
        return JsonUtils.toJsonIgnoreNull(service.closePeriod(input));
    }
}
