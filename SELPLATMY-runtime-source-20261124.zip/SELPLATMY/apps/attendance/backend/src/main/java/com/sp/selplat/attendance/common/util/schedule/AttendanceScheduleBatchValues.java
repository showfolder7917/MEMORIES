package com.sp.selplat.attendance.common.util.schedule;

import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.exception.CommonSystemException;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 单段批请求的无状态白名单、规范化与完整业务负载指纹；不读库、不作授权。 */
public final class AttendanceScheduleBatchValues {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceScheduleBatchValues() { }

    /**
     * 规范化全部业务项，重复员工日期明确拒绝，顺序不改变业务含义。
     *
     * @param input
     *     请求例如requestKey=BATCH-001/items=[{employeeId:8801,workDate:2026-10-10,shiftTemplateId:8901,templateRevision:0}]
     * @return
     *     真实规范化列表例如[{employeeId:8801,workDate:2026-10-10,shiftTemplateId:8901,templateRevision:0,remark:""}]；不写库
     * @throws CommonBusinessException 未知字段、重复日期、空项、超过1001或无效值明确拒绝
     */
    public static List<Map<String, Object>> items(CommonParam input) {
        if (!Set.of("requestKey", "items").containsAll(input.getParamMap().keySet())) {
            throw invalid();
        }
        key(input.getParam("requestKey"));
        if (!(input.getParam("items") instanceof List<?> rows)
                || rows.isEmpty()
                || rows.size() > 1001) {
            throw invalid();
        }
        List<Map<String, Object>> result = new ArrayList<>();
        Set<String> dates = new HashSet<>();
        for (Object value : rows) {
            if (!(value instanceof Map<?, ?> row)
                    || !Set.of(
                                    "employeeId",
                                    "workDate",
                                    "shiftTemplateId",
                                    "templateRevision",
                                    "remark")
                            .containsAll(row.keySet())) {
                throw invalid();
            }
            Map<String, Object> item = new LinkedHashMap<>();
            long employee = integer(row.get("employeeId"), true);
            LocalDate date;
            try {
                date = LocalDate.parse(String.valueOf(row.get("workDate")));
            } catch (RuntimeException error) {
                throw invalid();
            }
            if (!dates.add(employee + "/" + date)) {
                throw new CommonBusinessException(
                        "ATTENDANCE_BATCH_DUPLICATE", "同一员工同一日期不能重复，请修改输入。");
            }
            Object rawRemark = row.get("remark");
            if (rawRemark != null && !(rawRemark instanceof String)) {
                throw invalid();
            }
            String remark = rawRemark == null ? "" : rawRemark.toString().trim();
            if (remark.length() > 500) {
                throw invalid();
            }
            // 所有影响计划的输入都进入固定顺序映射，不采纳派生分钟/身份/历史主键。
            item.put("employeeId", employee);
            item.put("workDate", date.toString());
            item.put("shiftTemplateId", integer(row.get("shiftTemplateId"), true));
            item.put("templateRevision", integer(row.get("templateRevision"), false));
            item.put("remark", remark);
            result.add(item);
        }
        result.sort(
                Comparator.<Map<String, Object>, Long>comparing(row -> (Long) row.get("employeeId"))
                        .thenComparing(row -> row.get("workDate").toString()));
        return result;
    }

    /**
     * 请求键采用明确非空安全字符，不接受自动生成的服务端随机替代键。
     *
     * @param value 请求例如BATCH-001
     * @return 同一稳定键BATCH-001；非法值拒绝，无写库
     */
    public static String key(Object value) {
        if (!(value instanceof String key) || !key.matches("[A-Za-z0-9_-]{1,100}")) {
            throw invalid();
        }
        return key;
    }

    /**
     * 数值输入精确解析，拒绝小数、溢出及负版本。
     *
     * @param value 客户端例如8801或0
     * @param positive 主键true/修订false
     * @return 精确long例如8801；非法抛业务错误，无写库
     */
    private static long integer(Object value, boolean positive) {
        try {
            long number = new BigDecimal(String.valueOf(value)).longValueExact();
            if (number >= (positive ? 1 : 0)) {
                return number;
            }
        } catch (RuntimeException invalidNumber) {
            /* 统一业务输入错误。 */
        }
        throw invalid();
    }

    /**
     * 完整规范化业务负载摘要，不以预览结果或请求键替代。
     *
     * @param rows 全部规范化业务行例如employeeId=8801/workDate=2026-10-10/templateRevision=0
     * @return SHA256实际64位小写十六进制摘要；不持久化
     * @throws CommonSystemException 算法不可用失败，不使用不完整后备指纹
     */
    public static String fingerprint(List<Map<String, Object>> rows) {
        try {
            return HexFormat.of()
                    .formatHex(
                            java.security.MessageDigest.getInstance("SHA-256")
                                    .digest(
                                            JsonUtils.toJson(rows)
                                                    .getBytes(
                                                            java.nio.charset.StandardCharsets
                                                                    .UTF_8)));
        } catch (java.security.NoSuchAlgorithmException error) {
            throw new CommonSystemException(
                    "ATTENDANCE_BATCH_FINGERPRINT_FAILED", "批量排班指纹生成失败。", error);
        }
    }

    /**
     * 核验服务读取的当前模板版本、启用状态与显式日期，不从预览授权。
     *
     * @param item 本次行例如templateRevision=0/workDate=2026-10-10
     * @param template 当前真实行例如revision=0/isActive=1/effectiveFromDate=2026-10-10
     *     执行示例：修订变化抛ATTENDANCE_TEMPLATE_STALE，日期前拒绝，无业务写入。
     * @throws CommonBusinessException 班次模板已更新，请重新选择后再编辑。；班次模板已停用。；班次模板在所选工作日期尚未生效。
     */
    public static void validateTemplate(Map<String, Object> item, Map<String, Object> template) {
        if (!(template.get("revision") instanceof Number rev)
                || rev.longValue() != ((Number) item.get("templateRevision")).longValue()) {
            throw new CommonBusinessException("ATTENDANCE_TEMPLATE_STALE", "班次模板已更新，请重新选择后再编辑。");
        }
        if (!(template.get("isActive") instanceof Number active) || active.intValue() != 1) {
            throw new CommonBusinessException("ATTENDANCE_TEMPLATE_INACTIVE", "班次模板已停用。");
        }
        if (template.get("effectiveFromDate") != null
                && LocalDate.parse(item.get("workDate").toString())
                        .isBefore(LocalDate.parse(template.get("effectiveFromDate").toString()))) {
            throw new CommonBusinessException(
                    "ATTENDANCE_TEMPLATE_NOT_EFFECTIVE", "班次模板在所选工作日期尚未生效。");
        }
    }

    /**
     * 读取标准服务结果中的实际字段映射。
     *
     * @param result 当前表服务例如data={id:8801,tenantId:81}
     * @return 实际字段字符串键映射例如id=8801；无行拒绝，无写库
     */
    public static Map<String, Object> row(CommonResult result) {
        if (!(result.getData() instanceof Map<?, ?> map)) {
            throw invalid();
        }
        Map<String, Object> row = new LinkedHashMap<>();
        map.forEach((key, value) -> row.put(String.valueOf(key), value));
        return row;
    }

    /**
     * 使用实际单段展开时刻检测同员工批内重叠，恰好相接允许，REST空时段不占时间。
     *
     * @param plans 按员工/日期排序的真实展开行，例如employeeId=8801/start为2026-10-10T09:00/end为次日18:00
     * @return 重叠后续行的员工/日期键例如8801/2026-10-11；仅读传入值，不计算工资、不写库
     */
    public static Set<String> intervalConflicts(List<Map<String, Object>> plans) {
        Set<String> conflicts = new HashSet<>();
        Map<Long, Map<String, Object>> previous = new HashMap<>();
        for (var row : plans) {
            if (row.get("scheduledStartTime") == null || row.get("scheduledEndTime") == null) {
                continue;
            }
            long employee = ((Number) row.get("employeeId")).longValue();
            var old = previous.get(employee);
            if (old != null
                    && time(row.get("scheduledStartTime"))
                            .isBefore(time(old.get("scheduledEndTime")))
                    && time(row.get("scheduledEndTime"))
                            .isAfter(time(old.get("scheduledStartTime")))) {
                conflicts.add(employee + "/" + row.get("workDate"));
            }
            if (old == null
                    || time(row.get("scheduledEndTime"))
                            .isAfter(time(old.get("scheduledEndTime")))) {
                previous.put(employee, row);
            }
        }
        return conflicts;
    }

    /**
     * 展开区间由旧公共运行时产生的LocalDateTime，不接受请求时刻伪造。
     *
     * @param value 实际展开例如2026-10-10T09:00
     * @return 本地时刻2026-10-10T09:00；非法内部契约失败，无写库
     */
    private static java.time.LocalDateTime time(Object value) {
        return (java.time.LocalDateTime) value;
    }

    /**
     * @return 安全输入错误ATTENDANCE_BATCH_INPUT_INVALID，不包含租户其他记录。
     */
    private static CommonBusinessException invalid() {
        return new CommonBusinessException(
                "ATTENDANCE_BATCH_INPUT_INVALID", "批量排班输入无效，请检查请求键、员工、日期、模板修订及1001行上限。");
    }
}
