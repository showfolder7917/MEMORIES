package com.sp.selplat.attendance.capability.accountbinding.service;

import java.util.Map;

/** 消费Uniauth安全公开目录的本域适配及精确许可；无生产实现时考勤绑定默认拒绝，禁止认证内部凭据查询。 */
public interface AttendanceAccountDirectory {
    /**
     * 精确核验当前操作人对本租户目标账户的绑定动作及有效账号，不按email或姓名猜测。
     *
     * @param identity 真实会话例如tenantId=81/userId=8103
     * @param targetUserId 明确选择的公开账号主键例如8101
     * @param action 固定动作例如BIND_EMPLOYEE_ACCOUNT或UNBIND_EMPLOYEE_ACCOUNT
     * @return 安全目录事实例如{userId:8101,tenantId:81,status:1,directoryRevision:2}，不得含凭据
     *     异常示例：账号失效、异租户、目录不可用或精确许可撤销立即拒绝；只读且不授予许可。
     */
    Map<String, Object> requireAccount(
            Map<String, Long> identity, long targetUserId, String action);

    /**
     * 在目录服务端按精确操作者/动作许可过滤后分页，只返回允许展示的公开账号字段。
     *
     * @param identity 真实当前会话例如tenantId=81/userId=8103
     * @param action 固定动作例如BIND_EMPLOYEE_ACCOUNT；UNBIND可显示停用但仍获精确许可的账号
     * @param pageNo 已校验页码例如1
     * @param pageSize 已校验1至100例如20，禁止全库下载或客户端扩大范围
     * @param accountIdExact 明确公开ID精确筛选例如8104；空字符串表示许可范围内分页
     * @return
     *     实际CommonPageResult例如records=[{id:8104,tenantId:81,displayName:测试审核人,status:1,directoryRevision:0}],totalCount=1
     *     异常示例：目录不可用或无精确目录访问权限拒绝；COUNT同样仅计允许账号，不含密码/email或内部资料。
     */
    com.sp.selplat.common.util.CommonPageResult searchAccounts(
            Map<String, Long> identity,
            String action,
            int pageNo,
            int pageSize,
            String accountIdExact);
}
