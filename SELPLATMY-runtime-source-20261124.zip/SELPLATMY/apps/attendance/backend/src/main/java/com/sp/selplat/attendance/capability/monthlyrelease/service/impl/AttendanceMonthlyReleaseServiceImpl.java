/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
package com.sp.selplat.attendance.capability.monthlyrelease.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.capability.monthlyrelease.service.AttendanceMonthlyReleaseService;
import com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService;
import com.sp.selplat.attendance.monthlyactionlog.service.AttendanceMonthlyActionLogService;
import com.sp.selplat.attendance.monthlyitem.service.AttendanceMonthlyItemService;
import com.sp.selplat.attendance.monthlypublication.service.AttendanceMonthlyPublicationService;
import com.sp.selplat.attendance.monthlyreleasereceipt.service.AttendanceMonthlyReleaseReceiptService;
import com.sp.selplat.attendance.monthlyreview.service.AttendanceMonthlyReviewService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 月审签发布协调实际所属服务，员工→月锁→账本CAS/审计/尾回执共享具名事务。 */
@Service
public class AttendanceMonthlyReleaseServiceImpl implements AttendanceMonthlyReleaseService {

  @Autowired private AttendanceAuthorizationService authorization;

  @Autowired private AttendanceMonthlyService monthly;

  @Autowired private AttendanceMonthlyItemService items;

  @Autowired private AttendanceMonthlyActionLogService logs;

  @Autowired private AttendanceMonthlyReviewService reviews;

  @Autowired private AttendanceMonthlyPublicationService publications;

  @Autowired private AttendanceMonthlyReleaseReceiptService receipts;

  /**
   * 实际独立角色列表。
   *
   * @param input 月/分页例如2026-09/1/20
   * @return 所属月服务实际分页，缺精确角色拒绝
   */
  @Override
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, readAction(), false);
  }

  /**
   * 锁中显示真实来源/当前冻结/发布。
   *
   * @param input 月主键例如9301
   * @return 实际状态，未结来源为null，仅读取
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult current(CommonParam input) {
    return loadCurrent(input, readAction(), false);
  }

  /**
   * 冻结精确当前来源。
   *
   * @param input 来源版本/hash/requestKey例如monthlyId=9301
   * @return 实际冻结行及尾回执，改变或失败全回滚
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult prepareReview(CommonParam input) {
    return execute(input, "PREPARE_REVIEW");
  }

  /**
   * 审签本人看到的精确冻结。
   *
   * @param input freezeId/hash/sourceVersion/期望修订例如freezeId=100001
   * @return 实际APPROVED，reviewer=closedBy拒绝
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult approveReview(CommonParam input) {
    return execute(input, "APPROVE_REVIEW");
  }

  /**
   * 独立PUBLISH引用已审核冻结。
   *
   * @param input 当前冻结绑定及发布修订例如expectedPublicationRevision=0
   * @return 实际ACTIVE发布立即服务器生效，任何尾失败回滚
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult publish(CommonParam input) {
    return execute(input, "PUBLISH");
  }

  /**
   * 独立WITHDRAW原子失效当前指针。
   *
   * @param input 当前发布/冻结版本及必填reason例如publicationId=100001
   * @return 实际WITHDRAWN，不能以原回执复活
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult withdraw(CommonParam input) {
    return execute(input, "WITHDRAW");
  }

  /**
   * 锁后统一处理来源、幂等、职责/CAS，所有状态/审计/尾回执同事务。
   *
   * @param input 仅消费本动作允许业务字段例如monthlyId=9301/requestKey=TEST-01
   * @param action Controller固定动作例如PUBLISH，不消费请求角色/租户/操作者
   * @return 实际所属表结果，有效同指纹重放才返回原回执 异常示例：旧来源、独立许可失效、尾SQL失败全部回滚，无半发布。
   */
  private CommonResult execute(CommonParam input, String action) {
    var identity = authorization.requireReleaseAction(action);
    long id = positive(input.getParam("monthlyId"));
    String key = requestKey(input.getParam("requestKey"));
    String reason = "WITHDRAW".equals(action) ? reason(input.getParam("reason")) : null;
    var actual = lock(id, action);
    var scoped = scope(id, action);
    Map<String, Object> request = new TreeMap<>();
    request.put("monthlyId", id);
    request.put("action", action);
    request.put("reason", reason);
    for (String field :
        "PREPARE_REVIEW".equals(action)
            ? List.of("expectedSourceVersion", "expectedSourceHash")
            : List.of(
                "freezeId",
                "freezeHash",
                "sourceVersion",
                "expectedReviewRevision",
                "expectedPublicationRevision",
                "publicationId")) {
      if (input.getParam(field) != null) {
        request.put(field, String.valueOf(input.getParam(field)));
      }
    }
    String fingerprint = digest(JsonUtils.toJsonIgnoreNull(request));
    var receiptKey = scope(id, action);
    receiptKey.putParam("requestKey", key);
    var receipt = fact(receipts.findFact(receiptKey));
    if (receipt != null && !"CLOSED".equals(actual.get("closeStatus"))) {
      throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
    }
    var live = source(actual, action);
    long version = positive(live.get("sourceVersion"));
    String payload = JsonUtils.toJsonIgnoreNull(live), hash = digest(payload);
    if (receipt != null) {
      if (!fingerprint.equals(receipt.get("fingerprint"))) {
        throw refused("ATTENDANCE_RELEASE_KEY_REUSED", "请求键已用于不同月动作，请重新核验。");
      }
      return replay(receipt, action, id, version, hash);
    }
    Map<String, Object> freeze = fact(reviews.findFact(currentScope(id, action)));
    Map<String, Object> result;
    Map<String, Object> publication = null;
    if ("PREPARE_REVIEW".equals(action)) {
      if (positive(input.getParam("expectedSourceVersion")) != version
          || !hash.equals(input.getParam("expectedSourceHash"))) {
        throw refused("ATTENDANCE_RELEASE_SOURCE_CHANGED", "月结来源已变化，请正式重开核对后重新审核。");
      }
      if (freeze == null) {
        var prepared = scope(id, action);
        prepared.putParam("employeeId", actual.get("employeeId"));
        prepared.putParam("sourceVersion", version);
        prepared.putParam("freezeHash", hash);
        prepared.putParam("payloadJson", payload);
        prepared.putParam("activeMonthlyId", id);
        prepared.putParam("reviewStatus", "PENDING");
        prepared.putParam("revision", 0L);
        freeze = fact(reviews.storeFact(prepared));
      } else {
        verifyFreeze(freeze, input, version, hash, false);
      }
      result = freeze;
    } else {
      verifyFreeze(freeze, input, version, hash, true);
      if ("APPROVE_REVIEW".equals(action)) {
        if (positive(actual.get("closedBy")) == identity.get("userId")) {
          throw refused("ATTENDANCE_RELEASE_REVIEWER_CONFLICT", "月审核人必须不同于本次月结操作人。");
        }
        if (!"PENDING".equals(freeze.get("reviewStatus"))
            || nonnegative(input.getParam("expectedReviewRevision"))
                != nonnegative(freeze.get("revision"))) {
          throw refused("ATTENDANCE_RELEASE_STALE", "月发布版本已变化，请重新读取。");
        }
        var change = scope(id, action);
        change.putParam("id", freeze.get("id"));
        change.putParam("revision", freeze.get("revision"));
        freeze = fact(reviews.advance(change));
        result = freeze;
      } else if ("PUBLISH".equals(action)) {
        if (!"APPROVED".equals(freeze.get("reviewStatus"))
            || positive(freeze.get("reviewedBy")) == positive(actual.get("closedBy"))) {
          throw refused("ATTENDANCE_RELEASE_REVIEW_REQUIRED", "请先由另一位月审核人完成该冻结版本审核。");
        }
        long revision = latestRevision(scoped);
        if (nonnegative(input.getParam("expectedPublicationRevision")) != revision
            || fact(publications.findFact(currentScope(id, action))) != null) {
          throw refused("ATTENDANCE_RELEASE_STALE", "月发布版本已变化，请重新读取。");
        }
        var release = scope(id, action);
        for (String field : List.of("employeeId", "sourceVersion", "freezeHash")) {
          release.putParam(field, freeze.get(field));
        }
        release.putParam("freezeId", freeze.get("id"));
        release.putParam("activeMonthlyId", id);
        release.putParam("publicationStatus", "ACTIVE");
        release.putParam("revision", revision + 1);
        var now = java.time.LocalDateTime.now();
        release.putParam("publishedAt", now);
        release.putParam("effectiveAt", now);
        publication = fact(publications.storeFact(release));
        var projection = monthlyKey(id, action);
        projection.putParam("serverTime", now);
        monthly.markRelease(projection);
        result = publication;
      } else {
        publication = fact(publications.findFact(currentScope(id, action)));
        if (publication == null
            || positive(input.getParam("publicationId")) != positive(publication.get("id"))
            || nonnegative(input.getParam("expectedPublicationRevision"))
                != nonnegative(publication.get("revision"))
            || positive(publication.get("freezeId")) != positive(freeze.get("id"))) {
          throw refused("ATTENDANCE_RELEASE_STALE", "月发布版本已变化，请重新读取。");
        }
        var change = scope(id, action);
        change.putParam("id", publication.get("id"));
        change.putParam("revision", publication.get("revision"));
        change.putParam("reason", reason);
        publication = fact(publications.advance(change));
        change.putParam("id", freeze.get("id"));
        change.putParam("revision", freeze.get("revision"));
        reviews.advance(change);
        monthly.markRelease(monthlyKey(id, action));
        result = publication;
      }
    }
    // 审计先写、回执为尾项，约束失败必须回滚前面的CAS/指针和投影。
    var audit = scope(id, action);
    audit.putParam("actionComment", reason);
    audit.putParam(
        "snapshotJson",
        JsonUtils.toJsonIgnoreNull(
            Map.of(
                "freezeId",
                freeze.get("id"),
                "freezeHash",
                hash,
                "sourceVersion",
                version,
                "result",
                result)));
    logs.appendReleaseAction(audit);
    var saved = scope(id, action);
    saved.putParam("employeeId", actual.get("employeeId"));
    saved.putParam("requestKey", key);
    saved.putParam("fingerprint", fingerprint);
    saved.putParam("freezeId", freeze.get("id"));
    saved.putParam("sourceVersion", version);
    saved.putParam("freezeHash", hash);
    saved.putParam("publicationId", publication == null ? null : publication.get("id"));
    saved.putParam("resultRevision", result.get("revision"));
    saved.putParam("resultJson", JsonUtils.toJsonIgnoreNull(result));
    receipts.storeFact(saved);
    if (!identity.equals(authorization.requireReleaseAction(action))) {
      throw refused("ATTENDANCE_RELEASE_PERMISSION_REQUIRED", "当前月动作的独立许可尚未配置或已失效。");
    }
    return success(result);
  }

  /**
   * 回执只可重放仍有效的同一结果，撤回结果也不能误称新版本已撤。
   *
   * @param receipt 真实同actor/action/month/key回执
   * @param action 当前精确动作例如PUBLISH
   * @param id 锁中真实月主键
   * @param version 当前真实CLOSE来源版本
   * @param hash 当前规范化来源hash
   * @return 原真实结果；失效、来源或指针变化拒绝，无写入
   */
  private CommonResult replay(
      Map<String, Object> receipt, String action, long id, long version, String hash) {
    if (version != positive(receipt.get("sourceVersion"))
        || !hash.equals(receipt.get("freezeHash"))) {
      throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
    }
    var selected = scope(id, action);
    selected.putParam("id", receipt.get("freezeId"));
    var freeze = fact(reviews.findFact(selected));
    var current = fact(publications.findFact(currentScope(id, action)));
    if (freeze == null
        || version != positive(freeze.get("sourceVersion"))
        || !hash.equals(freeze.get("freezeHash"))
        || !hash.equals(digest(String.valueOf(freeze.get("payloadJson"))))) {
      throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
    }
    if ("PUBLISH".equals(action)) {
      if (freeze == null
          || !"APPROVED".equals(freeze.get("reviewStatus"))
          || !String.valueOf(freeze.get("activeMonthlyId")).equals(String.valueOf(id))
          || current == null
          || !String.valueOf(current.get("id")).equals(String.valueOf(receipt.get("publicationId")))
          || nonnegative(current.get("revision")) != nonnegative(receipt.get("resultRevision"))) {
        throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
      }
    } else if ("WITHDRAW".equals(action)) {
      var key = scope(id, action);
      key.putParam("id", receipt.get("publicationId"));
      var old = fact(publications.findFact(key));
      if (current != null
          || old == null
          || !"WITHDRAWN".equals(old.get("publicationStatus"))
          || nonnegative(old.get("revision")) != nonnegative(receipt.get("resultRevision"))
          || latestRevision(scope(id, action)) != nonnegative(old.get("revision"))) {
        throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
      }
    } else if (freeze == null
        || !String.valueOf(freeze.get("activeMonthlyId")).equals(String.valueOf(id))
        || "INVALIDATED".equals(freeze.get("reviewStatus"))
        || nonnegative(freeze.get("revision")) != nonnegative(receipt.get("resultRevision"))) {
      throw refused("ATTENDANCE_RELEASE_RECEIPT_EXPIRED", "原回执对应版本已失效，请重新读取当前状态。");
    }
    authorization.requireReleaseAction(action);
    return success(
        JsonUtils.fromJson(
            String.valueOf(receipt.get("resultJson")),
            new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
              /* 保留原冻结正文的完整泛型结构。 */
            }));
  }

  /**
   * 真实CLOSE版本与所有当前指标规范化冻结，不能由客户端送分钟/工资结果。
   *
   * @param actual 锁中实际月行例如9301/CLOSED
   * @param action 精确当前动作例如PUBLISH
   * @return 规范化monthly/items/sourceVersion实际内容，仅读取 异常示例：缺审计、同人来源、缺指标、有阻断或未结拒绝，不能补造历史版本。
   */
  private Map<String, Object> source(Map<String, Object> actual, String action) {
    return source(actual, action, false);
  }

  /**
   * 精确冻结绑定核对。
   *
   * @param freeze 实际当前冻结
   * @param input 明确id/hash/version
   * @param version 实际来源
   * @param hash 实际来源摘要
   * @param explicit 是否必需请求冻结ID
   * @throws CommonBusinessException 失配/内容改动拒绝，不写入
   */
  private void verifyFreeze(
      Map<String, Object> freeze, CommonParam input, long version, String hash, boolean explicit) {
    if (freeze == null
        || positive(freeze.get("sourceVersion")) != version
        || !hash.equals(freeze.get("freezeHash"))
        || !hash.equals(digest(String.valueOf(freeze.get("payloadJson"))))
        || "INVALIDATED".equals(freeze.get("reviewStatus"))) {
      throw refused("ATTENDANCE_RELEASE_SOURCE_CHANGED", "月结来源已变化，请正式重开核对后重新审核。");
    }
    if (explicit
        && (positive(input.getParam("freezeId")) != positive(freeze.get("id"))
            || positive(input.getParam("sourceVersion")) != version
            || !hash.equals(input.getParam("freezeHash")))) {
      throw refused("ATTENDANCE_RELEASE_STALE", "月发布版本已变化，请重新读取。");
    }
  }

  /**
   * 真实发布历史最大修订。
   *
   * @param scope 已授权实际月范围
   * @return 实际最大revision；无历史为0，不占号或写入
   */
  private long latestRevision(CommonParam scope) {
    return latestRevision(scope, false);
  }

  /**
   * 当前独立读取角色。
   *
   * @return 当前真实已配置动作，三者均无许可拒绝，不授予角色
   */
  private String readAction() {
    var configuration = (Map<?, ?>) authorization.currentConfiguration().getData();
    if (Boolean.TRUE.equals(configuration.get("canReviewMonthly"))) {
      return "PREPARE_REVIEW";
    }
    if (Boolean.TRUE.equals(configuration.get("canPublishMonthly"))) {
      return "PUBLISH";
    }
    if (Boolean.TRUE.equals(configuration.get("canWithdrawMonthly"))) {
      return "WITHDRAW";
    }
    throw refused("ATTENDANCE_RELEASE_PERMISSION_REQUIRED", "当前月动作的独立许可尚未配置或已失效。");
  }

  /**
   * 月行实际锁。
   *
   * @param id 正实际月ID
   * @param action 固定动作
   * @return 锁中实际data行，无固定业务返回
   */
  private Map<String, Object> lock(long id, String action) {
    return lock(id, action, false);
  }

  /**
   * 内部所属查询参数。
   *
   * @param id 实际月ID
   * @param action 明确动作
   * @return 仅monthlyId/actionCode，不拷请求身份
   */
  private CommonParam scope(long id, String action) {
    CommonParam value = new CommonParam();
    value.putParam("monthlyId", id);
    value.putParam("actionCode", action);
    return value;
  }

  /**
   * 月表主键参数。
   *
   * @param id 实际月ID
   * @param action 明确动作
   * @return 仅id/actionCode，租户由所属服务验证
   */
  private CommonParam monthlyKey(long id, String action) {
    CommonParam value = new CommonParam();
    value.putParam("id", id);
    value.putParam("actionCode", action);
    return value;
  }

  /**
   * 唯一当前指针查询。
   *
   * @param id 实际月ID
   * @param action 明确动作
   * @return 精确activeMonthlyId范围，仅读取
   */
  private CommonParam currentScope(long id, String action) {
    CommonParam value = new CommonParam();
    value.putParam("activeMonthlyId", id);
    value.putParam("actionCode", action);
    return value;
  }

  /**
   * 实际Service行读取。
   *
   * @param result 所属服务实际结果
   * @return 实际Map或null，无改写
   */
  private Map<String, Object> fact(CommonResult result) {
    if (result.getData() == null) {
      return null;
    }
    return JsonUtils.fromJson(
        JsonUtils.toJsonIgnoreNull(result.getData()),
        new com.fasterxml.jackson.core.type.TypeReference<Map<String, Object>>() {
          /* 保留原冻结正文的完整泛型结构。 */
        });
  }

  /**
   * 正整数校验。
   *
   * @param value 显式主键/来源例如9301
   * @return 正Long，空/小数拒绝，无默认身份
   */
  private long positive(Object value) {
    long actual = nonnegative(value);
    if (actual == 0) {
      throw refused("ATTENDANCE_RELEASE_INPUT_INVALID", "月动作的主键与版本参数必须有效。");
    }
    return actual;
  }

  /**
   * 非负修订校验。
   *
   * @param value 显式修订例如0
   * @return 精确非负Long，NULL/小数/溢出拒绝
   */
  private long nonnegative(Object value) {
    try {
      long number = new java.math.BigDecimal(String.valueOf(value)).longValueExact();
      if (number < 0) {
        throw new ArithmeticException("revision");
      }
      return number;
    } catch (NumberFormatException | ArithmeticException invalid) {
      throw refused("ATTENDANCE_RELEASE_INPUT_INVALID", "月动作的主键与版本参数必须有效。");
    }
  }

  /**
   * 显式幂等键校验。
   *
   * @param value 用户明确键例如REVIEW-01
   * @return trim后1至100字符，缺失拒绝，不生成默认键
   */
  private String requestKey(Object value) {
    String key = value == null ? "" : value.toString().trim();
    if (key.isEmpty() || key.length() > 100) {
      throw refused("ATTENDANCE_RELEASE_INPUT_INVALID", "月动作的主键与版本参数必须有效。");
    }
    return key;
  }

  /**
   * 必填撤回原因。
   *
   * @param value 用户明确原因
   * @return 非空最多2000字符，缺失拒绝，无状态写入
   */
  private String reason(Object value) {
    String reason = value == null ? "" : value.toString().trim();
    if (reason.isEmpty() || reason.length() > 2000) {
      throw refused("ATTENDANCE_RELEASE_REASON_REQUIRED", "撤回原因必须明确填写。");
    }
    return reason;
  }

  /**
   * 标准SHA256。
   *
   * @param text 规范化真实冻结/请求UTF8
   * @return 64位十六进制摘要，无业务写入
   * @throws IllegalStateException JVM缺标准算法时失败
   */
  private String digest(String text) {
    try {
      return java.util.HexFormat.of()
          .formatHex(
              java.security.MessageDigest.getInstance("SHA-256")
                  .digest(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    } catch (java.security.NoSuchAlgorithmException missing) {
      throw new IllegalStateException(missing);
    }
  }

  /**
   * 共通响应只封装实际事实。
   *
   * @param data 真实保存/读取结果
   * @return 完整CommonResult，无虚构业务记录
   */
  private CommonResult success(Object data) {
    CommonResult result = new CommonResult();
    result.setSuccess(true);
    result.setModuleCode("attendance");
    result.setData(data);
    result.setMsg("月审核发布当前状态已核验。");
    return result;
  }

  /**
   * 统一业务拒绝。
   *
   * @param code 本域明确错误码
   * @param message 可翻译真实拒绝说明
   * @return 实际异常，由共通层响应，不持久化
   */
  private CommonBusinessException refused(String code, String message) {
    return new CommonBusinessException(code, message);
  }

  /**
   * 方法作用：共用原月列表参数覆盖及分页，仅选择原或HTTP资格来源
   *
   * @param input 原分页，例如pageNo1
   * @param action 原服务器选定精确动作，例如PREPARE_REVIEW
   * @param pure HTTP true，原bridge false
   * @return 原CommonPageResult，原筛选/上限/排序保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private CommonPageResult loadStore(CommonPageParam input, String action, boolean pure) {
    input.putParam("actionCode", action);
    return (pure ? monthly.readReleaseStore(input) : monthly.releaseStore(input));
  }

  /**
   * 方法作用：共用原员工/月锁中当前来源与版本完整观察，不生成替代结果
   *
   * @param input 原monthlyId，例如61000
   * @param action 原服务器选定动作，例如PREPARE_REVIEW
   * @param pure HTTP true，原bridge false
   * @return 原monthly/review/publication/source/hash完整CommonResult
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private CommonResult loadCurrent(CommonParam input, String action, boolean pure) {
    long id = positive(input.getParam("monthlyId"));
    var actual = lock(id, action, pure);
    var scope = scope(id, action);
    var freeze =
        fact(
            (pure
                ? reviews.readReleaseFact(currentScope(id, action))
                : reviews.findFact(currentScope(id, action))));
    var published =
        fact(
            (pure
                ? publications.readReleaseFact(currentScope(id, action))
                : publications.findFact(currentScope(id, action))));
    Map<String, Object> data = new LinkedHashMap<>();
    data.put("monthly", actual);
    data.put("review", freeze);
    data.put("publication", published);
    data.put("publicationRevision", latestRevision(scope, pure));
    if ("CLOSED".equals(actual.get("closeStatus"))) {
      var source = source(actual, action, pure);
      data.put("sourceVersion", source.get("sourceVersion"));
      data.put("sourceHash", digest(JsonUtils.toJsonIgnoreNull(source)));
      data.put("source", source);
    }
    if (pure) {
      authorization.requireReadReleaseAction(action);
    } else {
      authorization.requireReleaseAction(action);
    }
    return success(data);
  }

  /**
   * 方法作用：共用原月行锁入口及返回，员工和所属月份锁仍在拥有方
   *
   * @param id 原正主键，例如61000
   * @param action 原精确动作，例如PREPARE_REVIEW
   * @param pure HTTP true，原bridge false
   * @return 实际锁中的原月行Map，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private Map<String, Object> lock(long id, String action, boolean pure) {
    return fact(
        (pure
            ? monthly.readLockForRelease(monthlyKey(id, action))
            : monthly.lockForRelease(monthlyKey(id, action))));
  }

  /**
   * 方法作用：共用原CLOSE来源、指标规范化及摘要输入，不复制或重算工时
   *
   * @param actual 原锁中月行，例如61000/CLOSED
   * @param action 原精确动作，例如PREPARE_REVIEW
   * @param pure HTTP true，原写和bridge false
   * @return 原规范化monthly/items/sourceVersion，原拒绝完整保留
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private Map<String, Object> source(Map<String, Object> actual, String action, boolean pure) {
    if (!"CLOSED".equals(actual.get("closeStatus"))
        || nonnegative(actual.get("blockReasonCount")) != 0
        || nonnegative(actual.get("deletedFlag")) != 0) {
      throw refused("ATTENDANCE_RELEASE_CLOSED_REQUIRED", "请先完成无阻断月结后再审核发布。");
    }
    long id = positive(actual.get("id"));
    var query = scope(id, action);
    var closed = fact((pure ? logs.readReleaseSource(query) : logs.releaseSource(query)));
    if (closed == null || positive(closed.get("operatorId")) != positive(actual.get("closedBy"))) {
      throw refused("ATTENDANCE_RELEASE_SOURCE_REQUIRED", "缺少可核对的本次月结来源审计，不能发布历史推定版本。");
    }
    var metrics =
        JsonUtils.fromJson(
            JsonUtils.toJsonIgnoreNull(
                (pure ? items.readReleaseItems(query) : items.releaseItems(query)).getData()),
            new com.fasterxml.jackson.core.type.TypeReference<List<Map<String, Object>>>() {
              /* 保留原冻结正文的完整泛型结构。 */
            });
    if (metrics.isEmpty()) {
      throw refused("ATTENDANCE_RELEASE_SOURCE_REQUIRED", "缺少可核对的本次月结来源审计，不能发布历史推定版本。");
    }
    Map<String, Object> month = new TreeMap<>();
    for (String field :
        List.of(
            "id",
            "tenantId",
            "employeeId",
            "yearMonth",
            "workplaceId",
            "departmentId",
            "closedBy",
            "closedAt",
            "closeStatus",
            "blockReasonCount",
            "scheduledDays",
            "attendanceDays",
            "normalDays",
            "lateCount",
            "earlyLeaveCount",
            "missingPunchCount",
            "absenceCount",
            "exceptionDays",
            "totalWorkMinutes",
            "overtimeMinutes",
            "legalOvertimeMinutes",
            "nightWorkMinutes",
            "holidayWorkMinutes",
            "paidLeaveDays",
            "restDays")) {
      month.put(field, actual.get(field));
    }
    List<Map<String, Object>> frozenItems = new ArrayList<>();
    for (var row : metrics) {
      Map<String, Object> item = new TreeMap<>();
      for (String field :
          List.of(
              "id",
              "tenantId",
              "monthlyId",
              "itemCode",
              "itemName",
              "itemValue",
              "itemOrder",
              "sourceJson")) {
        item.put(field, row.get(field));
      }
      frozenItems.add(item);
    }
    Map<String, Object> result = new TreeMap<>();
    result.put("monthly", month);
    result.put("items", frozenItems);
    result.put("sourceVersion", positive(closed.get("id")));
    return result;
  }

  /**
   * 方法作用：共用原全部发布历史最大修订选择及分批来源，不占号
   *
   * @param scope 原monthlyId/actionCode，例如61000/PREPARE_REVIEW
   * @param pure HTTP true，原bridge或写false
   * @return 原最大revision，例如1006，空历史0
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  private long latestRevision(CommonParam scope, boolean pure) {
    long latest = 0;
    for (Object entry :
        (List<?>)
            (pure ? publications.readReleaseHistory(scope) : publications.scanMonthly(scope))
                .getData()) {
      latest = Math.max(latest, nonnegative(((Map<?, ?>) entry).get("revision")));
    }
    return latest;
  }

  /**
   * 方法作用：原优先动作下HTTP独立月列表，前后核同一精确角色与主体
   *
   * @param input 原月份/分页，例如2026-10/pageNo1
   * @return 原完整CommonPageResult，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    authorization.requireReadIdentity();
    String action = readAction();
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadStore(input, action, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：HTTP保留员工→所属月份真实锁和原当前来源事务，不授予任何写
   *
   * @param input 原monthlyId，例如61000；请求动作不控制分支
   * @return 原CommonResult/sourceHash，锁仅随本次本域事务释放
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readCurrent(CommonParam input) {
    authorization.requireReadIdentity();
    String action = readAction();
    var actor = authorization.requireReadReleaseAction(action);
    var result = loadCurrent(input, action, true);
    if (!actor.equals(authorization.requireReadReleaseAction(action))) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "月动作读取期间身份已变化。");
    }
    return result;
  }
}
