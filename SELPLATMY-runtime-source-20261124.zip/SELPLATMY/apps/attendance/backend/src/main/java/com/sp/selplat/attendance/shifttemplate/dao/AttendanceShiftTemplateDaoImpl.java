package com.sp.selplat.attendance.shifttemplate.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;

/** 从类名固定解析 AttendanceShiftTemplate，通过私有数据源和共通模板持久化，不接受请求表名。 */
@Repository
public class AttendanceShiftTemplateDaoImpl extends AttendanceBaseDao
        implements AttendanceShiftTemplateDao {
    /**
     * 真实事务连接读取当前模板，避免锁前公共查询缓存。
     *
     * @param input 已核验范围例如tenantId=81、id=8901
     * @return 实际当前行例如revision=0；不存在null，仅锁本表不跨表
     */
    @Override
    public java.util.Map<String, Object> lockTemplate(
            com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        // 编辑和关联使用相同锁顺序；等待后读已提交事实。
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceShiftTemplate WHERE tenantId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : rows.getFirst();
    }

    /**
     * 只记录本表曾引用事实，不回写已有排班/日月结果。
     *
     * @param input 已锁定范围例如tenantId=81、id=8901
     * @return 实际UPDATE数例如1；同源业务失败时标记一并回滚
     */
    @Override
    public int markReferenced(com.sp.selplat.common.util.CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.update(
                "UPDATE AttendanceShiftTemplate SET referenceLocked=1 WHERE tenantId=? AND id=? AND status=1",
                input.getParam("tenantId"),
                input.getParam("id"));
    }
}
