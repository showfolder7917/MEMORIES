/* 2026-11-01：原账号绑定三读取固定网关，原执行写入口不进入本合同。 */
package com.sp.selplat.attendance.capability.accountbinding.service;

import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 仅选择原桥接或明确HTTP身份读取，不承载写命令或动态方法。 */
public interface AttendanceAccountBindingReadGateway {
  /**
   * 方法作用：读取原安全候选完整分页。
   *
   * @param input 原action与分页，例如BIND/pageNo1/pageSize20
   * @return 原四字段分页，例如totalCount1；缺管理或目录资格拒绝，无写入
   */
  CommonPageResult accounts(CommonParam input);

  /**
   * 方法作用：读取已允许目标当前绑定并重核目录事实。
   *
   * @param input 原目标，例如userId8104/actionUNBIND
   * @return 原CommonResult，例如data.bindingRevision1；缺原MANAGER或审计结构拒绝，无写入
   */
  CommonResult state(CommonParam input);

  /**
   * 方法作用：持原员工与绑定锁核七字段迁移候选，不执行迁入。
   *
   * @param input 原七字段，例如modeDRY_RUN/userId8104/employeeId8801
   * @return 原CommonResult，例如data.writeEnabled=false；歧义或资格失效拒绝，无写入
   */
  CommonResult migrationPreflight(CommonParam input);
}
