/* 2026-10-29：本表固定请求SQL和原考勤事务保护，不访问其他表或权限工程。 */
package com.sp.selplat.attendance.employeecreateattempt.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.ConnectionHolder;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 只操作AttendanceEmployeeCreateAttempt本表；状态编排不在DAO内授权。 */
@Repository
public class AttendanceEmployeeCreateAttemptDaoImpl extends AttendanceBaseDao
    implements AttendanceEmployeeCreateAttemptDao {
  /**
   * 方法作用：原号段新增本表记录也必须在同域真实事务，不能自动提交元数据。
   *
   * @param row 原本表参数，例如id100000/tenantId9
   * @return 原真实新增行数，例如1
   * @throws CommonBusinessException 缺原可写事务拒绝，无部分写入
   */
  @Override
  public int insert(CommonParam row) {
    requireTransaction();
    return super.insert(row);
  }

  /**
   * 方法作用：复用实际原连接的可写读已提交状态，不新建数据源或替代事务。
   *
   * @throws CommonBusinessException 无本域事务、只读或旧快照时拒绝
   */
  @Override
  public void requireTransaction() {
    writeJdbc();
  }

  /**
   * 方法作用：仅以本表所属原考勤连接执行写和行锁，持锁至原事务结束。
   *
   * @return 原同源JdbcTemplate，例如实际attendanceDataSource事务连接
   * @throws CommonBusinessException 本域连接和事务状态不满足要求时拒绝
   */
  private JdbcTemplate writeJdbc() {
    var source = getDataSourceContext().getDataSource();
    var target =
        source instanceof TransactionAwareDataSourceProxy proxy
            ? proxy.getTargetDataSource()
            : source;
    Object resource = TransactionSynchronizationManager.getResource(target);
    if (!TransactionSynchronizationManager.isActualTransactionActive()
        || TransactionSynchronizationManager.isCurrentTransactionReadOnly()
        || !(resource instanceof ConnectionHolder holder)) {
      throw transactionRequired();
    }
    try {
      var connection = holder.getConnection();
      if (connection.getAutoCommit()
          || connection.isReadOnly()
          || connection.getTransactionIsolation() != Connection.TRANSACTION_READ_COMMITTED) {
        throw transactionRequired();
      }
    } catch (SQLException failure) {
      throw new CommonBusinessException(
          "ATTENDANCE_EMPLOYEE_REQUEST_TRANSACTION_REQUIRED", "员工请求记录需要原考勤读已提交事务。", failure);
    }
    return new JdbcTemplate(source);
  }

  /**
   * @return 原事务拒绝错误，例如ATTENDANCE_EMPLOYEE_REQUEST_TRANSACTION_REQUIRED，不写任何表
   */
  private CommonBusinessException transactionRequired() {
    return new CommonBusinessException(
        "ATTENDANCE_EMPLOYEE_REQUEST_TRANSACTION_REQUIRED", "员工请求记录需要原考勤可写事务。");
  }

  /**
   * 方法作用：只读本表指定原学校和尝试，行锁不离开原考勤事务。
   *
   * @param tenantId 原学校，例如9
   * @param id 原尝试主键，例如100001
   * @param locking 原事务内true
   * @return 本表原行，例如PREPARED；无行null
   */
  @Override
  public Map<String, Object> find(long tenantId, long id, boolean locking) {
    var rows =
        (locking ? writeJdbc() : new JdbcTemplate(getDataSource()))
            .queryForList(
                "SELECT * FROM AttendanceEmployeeCreateAttempt WHERE tenantId=? AND id=? AND"
                    + " status=1"
                    + (locking ? " FOR UPDATE" : ""),
                tenantId,
                id);
    return rows.isEmpty() ? null : rows.getFirst();
  }

  /**
   * 方法作用：只把当前实际PREPARED尝试改成ABORTED，不覆盖已提交或其他尝试。
   *
   * @param row 原定位及修订，例如id100001/attemptKey原UUID
   * @return 实际更新1，已终止/提交或修订变化0
   */
  @Override
  public int abort(CommonParam row) {
    return writeJdbc()
        .update(
            "UPDATE AttendanceEmployeeCreateAttempt SET"
                + " stateCode='ABORTED',revision=revision+1,updatedAt=CURRENT_TIMESTAMP,lastOperateUserId=?"
                + " WHERE tenantId=? AND id=? AND attemptKey=? AND revision=? AND"
                + " stateCode='PREPARED' AND status=1",
            row.getParam("lastOperateUserId"),
            row.getParam("tenantId"),
            row.getParam("id"),
            row.getParam("attemptKey"),
            row.getParam("expectedRevision"));
  }

  /**
   * 方法作用：同事务写真实员工回执，数据库外键拒绝不存在或异校员工。
   *
   * @param row 原结果及定位，例如employeeId100000/receiptHash64位SHA256
   * @return 实际更新1，终止或修订变化0
   */
  @Override
  public int commit(CommonParam row) {
    return writeJdbc()
        .update(
            "UPDATE AttendanceEmployeeCreateAttempt SET stateCode='COMMITTED',employeeId=?,"
                + "resultJson=?,receiptHash=?,revision=revision+1,updatedAt=CURRENT_TIMESTAMP,lastOperateUserId=?"
                + " WHERE tenantId=? AND id=? AND attemptKey=? AND revision=? AND"
                + " stateCode='PREPARED' AND status=1",
            row.getParam("employeeId"),
            row.getParam("resultJson"),
            row.getParam("receiptHash"),
            row.getParam("lastOperateUserId"),
            row.getParam("tenantId"),
            row.getParam("id"),
            row.getParam("attemptKey"),
            row.getParam("expectedRevision"));
  }
}
