/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.capability.monthlyreport.controller;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.JsonUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** 报表 Controller 只序列化 Service 完整结果。 */
@RestController
@RequestMapping("/api/attendance/report")
public class AttendanceMonthlyReportController {

  private final com.sp.selplat.attendance.capability.monthlyreport.service
          .AttendanceMonthlyReportReadGateway
      service;

  /**
   * 装配报表服务。
   *
   * @param service Host固定原导出网关，例如bridge或HTTP纯读；仅保存引用，不读库或修改报表字段。
   */
  public AttendanceMonthlyReportController(
      @org.springframework.beans.factory.annotation.Qualifier("attendanceMonthlyReportReadGateway")
          com.sp.selplat.attendance.capability.monthlyreport.service
                  .AttendanceMonthlyReportReadGateway
              service) {
    this.service = service;
  }

  /**
   * 导出已保存的月次快照。
   *
   * @param input 月次主键，例如 id=100001
   * @return 共通 JSON，例如 data.format=CSV；授权未配置时返回共通业务错误
   * @throws com.sp.selplat.common.exception.CommonBusinessException 未授权或月次不存在时拒绝
   */
  @PostMapping("monthly-export.htm")
  public String export(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(service.export(input));
  }
}
