/* 2026-10-29：固定员工新增私有持久表，不提供通用HTTP修改。 */
package com.sp.selplat.attendance.employeecreateattempt.dao;

import com.sp.selplat.common.db.dao.BaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;

/** 只操作本表，固定请求编排由原employee聚合服务拥有。 */
public interface AttendanceEmployeeCreateAttemptDao extends BaseDao {
  /**
   * 方法作用：验证原考勤可写读已提交事务，禁止自动提交或外域冒充。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 无正确本域事务拒绝，不执行SQL
   */
  void requireTransaction();

  /**
   * 方法作用：按原学校和实际尝试主键查询本表，不读取请求正文。
   *
   * @param tenantId 原学校，例如9
   * @param id 原尝试主键，例如100001
   * @param locking 原考勤事务内true
   * @return 本表原行，例如PREPARED；无行null
   */
  Map<String, Object> find(long tenantId, long id, boolean locking);

  /**
   * 方法作用：原请求槽锁内终止指定尝试，已经提交的行不会被改成ABORTED。
   *
   * @param input 原定位及修订，例如id100001/attemptKey UUID/expectedRevision0
   * @return 原PREPARED更新1，否则0
   */
  int abort(CommonParam input);

  /**
   * 方法作用：与员工SQL同事务记录原成功结果及实际员工主键。
   *
   * @param input 原尝试及结果，例如employeeId100000/resultJson原CommonResult
   * @return 原PREPARED更新1，否则0
   */
  int commit(CommonParam input);
}
