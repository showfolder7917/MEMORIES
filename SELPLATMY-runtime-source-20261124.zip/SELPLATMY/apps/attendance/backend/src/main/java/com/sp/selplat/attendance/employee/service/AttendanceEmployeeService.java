/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 修改记录：2026-10-27，通用人员可明确复用原员工，保持原管理裁决。 */
package com.sp.selplat.attendance.employee.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceEmployee 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceEmployeeService extends BaseService {

  /**
   * 方法作用：经前后资格复核读取原员工分页，不启动本地角色提交回调。
   *
   * @param input 原分页候选，例如pageNo1/pageSize20
   * @return 原分页记录，例如tenant9员工7001；资格撤回时拒绝，不写入
   */
  com.sp.selplat.common.util.CommonPageResult readStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：只读原精确详情，前后复核本系统管理资格。
   *
   * @param input 原主键，例如id7001
   * @return 原CommonResult，例如data.employeeName林老师；资格或归属不符拒绝，无写入
   */
  CommonResult readById(CommonParam input);

  /**
   * 方法作用：只读原员工安全来源，前后复核管理资格及原员工版本。
   *
   * @param input 原主键，例如id7001
   * @return 原4字段安全摘要，例如id/employeeNo/employeeName/sourceVersion，无写入
   */
  CommonResult readPersonReference(CommonParam input);

  /**
   * 方法作用：只读原表头配置，保持原登录及系统角色要求，不提升为管理资格。
   *
   * @param viewCode 原viewCode或tableCode，例如table930001
   * @param locale 原语言，例如ja-JP
   * @return 原表头CommonResult，例如columns含姓名列，无配置写入
   */
  CommonResult readGridColumn(String viewCode, String locale);

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 读取真实会话员工映射对应的本人资源，没有独立通用 CRUD 放行。
   *
   * @param input 资源主键，例如 id=100001；请求员工/租户字段不参与权限选择
   * @return 真实本人资源；缺已核验映射或异员工时拒绝，无写入副作用
   */
  CommonResult getOwned(CommonParam input);

  /**
   * 建单能力读取真实员工地点/部门；已核验管理范围或本人绑定均重新校验。
   *
   * @param input 真实日次员工主键，例如id=8801；不接受请求租户选择
   * @return 实际员工CommonResult，例如data.workplaceId=1；本人绑定不允许读取其他员工 异常或副作用示例：缺核验配置或归属不符拒绝；仅查询，无权限扩展。
   */
  CommonResult getForCase(CommonParam input);

  /**
   * 排班能力逐员工取得真实当前行，统一空日期与已有日期写入串行。
   *
   * @param input 已核验管理范围的员工主键例如id=8801
   * @return 实际员工例如data.employeeName=隔离员工甲；不存在或许可撤销拒绝，锁本员工到事务结束
   */
  CommonResult lockForSchedule(com.sp.selplat.common.util.CommonParam input);

  /**
   * 日月写入统一锁真实员工；仅既有管理、审批或本人绑定可进入内部锁合同。
   *
   * @param input 受控员工主键例如id=8801，不接受客户端租户或新动作许可
   * @return 当前员工例如data.tenantId=81；本人只能锁本人，锁保持至外层事务结束 异常或副作用示例：等待后撤权或员工失效拒绝；无业务字段写入、无HTTP新入口。
   */
  CommonResult lockForResult(CommonParam input);

  /**
   * 新月动作仅锁所属员工。
   *
   * @param input 内部id与actionCode例如8801/PUBLISH
   * @return 锁中实际员工，等待后精确动作重验，无许可拒绝
   */
  CommonResult lockForRelease(CommonParam input);

  /**
   * 方法作用：按原考勤管理资格读取可关联员工安全摘要及实际来源摘要，不创建通用人员。
   *
   * @param input 明确本租户员工编号，例如id8801
   * @return 真实返回示例：data={id:"8801",employeeNo:"T001",employeeName:"林老师",sourceVersion:64位摘要}。
   *     异常或副作用示例：无原管理资格、跨租户或员工已离职拒绝，零写入。
   */
  CommonResult personReference(CommonParam input);

  /**
   * 方法作用：通用人员保存事务内锁原员工并重核所见摘要及实际管理资格。
   *
   * @param input 本域服务间候选，例如id8801/expectedSourceVersion64位摘要
   * @return 真实返回示例：同一员工安全摘要；不返回电话、工资或打卡资料。 异常或副作用示例：必须处于考勤事务，员工变化或管理资格撤回拒绝并回滚关联。
   */
  CommonResult lockPersonReference(CommonParam input);

  /**
   * 方法作用：原独立月动作来源读锁，保留员工与所属月份互斥
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readLockForRelease(
      com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：读取原批量详情并在交付前重核资格，保持原逐项归属及顺序
   *
   * @param input 原JSON items，例如62000、62001、62000
   * @return 原CommonResult.data三行，空批返回空列表，不提供写能力
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult readByIds(
      com.sp.selplat.common.util.CommonBatchParam input);

  /**
   * 方法作用：账号绑定预检原事务内读取并保持员工锁，不沿月发布动作授权。
   *
   * @param input 原员工主键，例如id8801；租户由当前管理身份覆盖
   * @return 原完整员工CommonResult，例如employeeName林老师；锁保持至外层事务结束
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺管理或员工失效拒绝，无业务写入
   */
  CommonResult readLockForAccountBinding(CommonParam input);
}
