package com.sp.selplat.attendance.accessgrant.service;

import com.sp.selplat.common.service.BaseService;
import java.util.Map;

/** AttendanceAccessGrant 表级服务，业务授权未核准时拒绝数据读取和变更。 */
public interface AttendanceAccessGrantService extends BaseService {
    /**
     * 仅按真实当前会话查询已核验配置；不接受请求身份，也不配置权限。
     *
     * @param roleCode 明确管理 MANAGER 或审批 APPROVER，不能来自客户端赋权
     * @return 本人本租户 VERIFIED 启用记录，例如 userId=8101；缺失返回 null 异常示例：匿名或租户失效时拒绝；无写入副作用。
     */
    Map<String, Object> findCurrentGrant(String roleCode);

    /**
     * 读取本人月报精确动作许可，不赋权或替代员工映射。
     *
     * @return 真实 SELF_MONTHLY_READ/SELF 配置，例如 employeeId=8801；缺许可返回 null 异常或副作用示例：匿名拒绝，只读本表。
     */
    Map<String, Object> findCurrentMonthlyReadGrant();

    /**
     * 仅读取当前账号精确月动作配置。
     *
     * @param role 白名单例如MONTHLY_PUBLISH
     * @return 真实所属配置或null，不新建许可
     */
    java.util.Map<String, Object> findCurrentReleaseGrant(String role);
}
