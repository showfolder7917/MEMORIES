/* 2026-11-01：打卡与批次原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.punchrawlog.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendancePunchRawLog 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendancePunchRawLogService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * CSV 能力整批写入已经分类的原始事实，禁止通用 HTTP 批量入口。
   *
   * @param input 内部事实列表，例如两条 PROCESSED/UNMATCHED 打卡及本次 importBatchId
   * @return 实际批量 CommonResult，含每条共享号段 id 和 affectedRows 异常或副作用示例：唯一事件约束失败回滚所属导入事务；不计算日月分钟。
   */
  com.sp.selplat.common.util.CommonResult storeReceivedBatch(
      com.sp.selplat.common.util.CommonBatchParam input);

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用业务能力提交服务端校验/计算的快照；没有 HTTP 直接调用入口。
   *
   * @param input 服务端计算/接收字段，例如 employeeId=8801，不能直接转发客户端派生分钟
   * @return 实际号段及持久化结果 CommonResult 异常或副作用示例：拒绝受保护状态；真实本域事务写入该表，不直接访问其他表。
   */
  CommonResult storeReceived(CommonParam input);
}
