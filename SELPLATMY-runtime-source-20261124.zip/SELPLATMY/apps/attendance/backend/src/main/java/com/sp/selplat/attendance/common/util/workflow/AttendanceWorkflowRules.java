package com.sp.selplat.attendance.common.util.workflow;

import com.sp.selplat.common.exception.CommonBusinessException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 旧补卡审批和月结规则的纯值投影，供后续所属 Service 复用。 不认证用户、不授予权限、不访问 DAO、不开放 HTTP 动作；返回值不是已提交的数据库结果。 来源为旧
 * AttendanceCaseServiceImpl 与 AttendanceMonthlyServiceImpl，不新增工资或工时判定。
 */
public final class AttendanceWorkflowRules {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceWorkflowRules() {
        // 无请求间状态，不维护审批人或权限配置。
    }

    /**
     * 读取日次真实状态，沿用既有审批中、已审批和锁定记录不可重算的判定。
     *
     * @param daily 所属日次服务查询的事实，例如 {approvalStatus:APPROVED,lockedFlag:0}；不存在传null
     * @return 例如APPROVED返回true，null或NONE且未锁定返回false 副作用示例：纯值判断，无数据库变化；写入服务仍需重查当前事实，不能仅凭预检查放行。
     */
    public static boolean isDailyRecalculationProtected(Map<String, Object> daily) {
        // 不存在的日次允许按真实排班和原始卡创建，既有受保护状态必须保留最终事实。
        return daily != null
                && (java.util.Set.of("SUBMITTED", "RETURNED", "APPROVED", "LOCKED")
                                .contains(String.valueOf(daily.get("approvalStatus")))
                        || java.util.Set.of("IN_REVIEW", "LOCKED")
                                .contains(String.valueOf(daily.get("handlingStatus")))
                        || daily.get("lockedFlag") instanceof Number locked
                                && locked.intValue() != 0);
    }

    /**
     * 沿用旧详情页可用动作，表达业务状态而非访问权限。
     *
     * @param caseStatus 所属 Service 读取的案件状态，例如 SUBMITTED；未知或 null 返回空列表
     * @return 例如 SUBMITTED 返回 [APPROVE,RETURN,REJECT]，APPROVED 返回 []
     *     副作用示例：没有持久化；调用方必须另行通过平台授权和实时事务状态复核。
     */
    public static List<String> availableCaseActions(String caseStatus) {
        // 原详情页仅给已提交和已退回单据展示三个审批动作。
        return "SUBMITTED".equals(caseStatus) || "RETURNED".equals(caseStatus)
                ? List.of("APPROVE", "RETURN", "REJECT")
                : List.of();
    }

    /**
     * 沿用旧重复建单判定，只有驳回或取消单据允许重新申请。
     *
     * @param latest 最近真实案件行，例如 {caseStatus:REJECTED}；不存在传 null 或空映射
     * @return 例如 REJECTED 返回 false，APPROVED 返回 true；既有行缺状态仍返回 true 副作用示例：纯状态判断不能代替数据库并发唯一约束或锁内复查。
     */
    public static boolean hasActiveCase(Map<String, Object> latest) {
        if (latest == null || latest.isEmpty()) {
            return false;
        }
        String caseStatus =
                latest.get("caseStatus") == null ? "" : latest.get("caseStatus").toString();
        // 保留旧未知非空状态也视为活动单据的保守行为，不默认为可新建。
        return !"REJECTED".equals(caseStatus) && !"CANCELLED".equals(caseStatus);
    }

    /**
     * 投影旧提交、通过、退回和驳回后案件与日次的状态组合。
     *
     * @param action 由已授权 Service 确定的动作，例如 APPROVE；仅 trim 和大小写规范化
     * @return APPROVE 例如 {caseStatus:APPROVED,approvalStatus:APPROVED,handlingStatus:RESOLVED}
     * @throws CommonBusinessException 未知动作例如 DELETE 被拒绝；不执行数据库更新或动作日志
     */
    public static Map<String, String> caseOutcome(String action) {
        // 只投影原方法的状态结果，不把客户端动作名称当作授权。
        String normalized = action == null ? "" : action.trim().toUpperCase(Locale.ROOT);
        return switch (normalized) {
            case "SUBMIT" -> state("SUBMITTED", "IN_REVIEW");
            case "APPROVE" -> state("APPROVED", "RESOLVED");
            case "RETURN" -> state("RETURNED", "IN_REVIEW");
            case "REJECT" -> state("REJECTED", "UNHANDLED");
            default ->
                    throw new CommonBusinessException("ATTENDANCE_CASE_ACTION_INVALID", "处理单动作无效。");
        };
    }

    /**
     * 沿用旧审批补丁字段和缺省值，解析最终时间，不计算或改写工资分钟。
     *
     * @param daily 所属 Service 的真实日次业务快照，例如 actualBreakMinutes=60、status=LATE
     * @param patch 已授权 Service 校验的补丁，例如 actualClockOut=2026-05-18T18:45:00；null 等同空补丁
     * @return 例如
     *     {finalClockIn:null,finalClockOut:2026-05-18T18:45,finalBreakMinutes:60,finalStatus:LATE,finalExceptionFlag:false}
     * @throws CommonBusinessException 日次缺失或时间/整数格式无效时拒绝；输出包含 null，不创建审批记录
     */
    public static Map<String, Object> approvalPatch(
            Map<String, Object> daily, Map<String, Object> patch) {
        if (daily == null) {
            throw new CommonBusinessException("ATTENDANCE_DAILY_REQUIRED", "审批需要实际日次快照。");
        }
        Map<String, Object> input = patch == null ? Map.of() : patch;
        try {
            // 旧补丁 actualClockIn/Out 映射到 final 字段；未填写则沿用实际时间。
            Map<String, Object> result = new LinkedHashMap<>();
            result.put(
                    "finalClockIn",
                    optionalTime(input.get("actualClockIn"), daily.get("actualClockIn")));
            result.put(
                    "finalClockOut",
                    optionalTime(input.get("actualClockOut"), daily.get("actualClockOut")));
            Object minutes = input.get("finalBreakMinutes");
            result.put(
                    "finalBreakMinutes",
                    blank(minutes)
                            ? daily.get("actualBreakMinutes")
                            : minutes instanceof Number number
                                    ? number.intValue()
                                    : Integer.parseInt(minutes.toString()));
            String oldStatus =
                    blank(daily.get("status")) ? "NORMAL" : daily.get("status").toString().trim();
            result.put(
                    "finalStatus",
                    blank(input.get("finalStatus"))
                            ? oldStatus
                            : input.get("finalStatus").toString().trim());
            Object exception = input.get("finalExceptionFlag");
            // 保留旧 false 缺省和数字非零含义，不从历史异常标志自动推断审批结果。
            result.put(
                    "finalExceptionFlag",
                    !blank(exception)
                            && (exception instanceof Boolean flag
                                    ? flag
                                    : exception instanceof Number number
                                            ? number.intValue() != 0
                                            : List.of("true", "1")
                                                    .contains(
                                                            exception
                                                                    .toString()
                                                                    .toLowerCase(Locale.ROOT))));
            return result;
        } catch (RuntimeException invalidValue) {
            throw new CommonBusinessException(
                    "ATTENDANCE_CASE_PATCH_INVALID", "审批补丁格式无效。", invalidValue);
        }
    }

    /**
     * 沿用旧月结整批预检：任一记录不是可结或已重开就拒绝整批。
     *
     * @param statuses 已刷新且锁内复核的范围状态，例如 [CLOSABLE,REOPENED]；null 表示事实缺失
     * @return 可结记录数量，例如上述列表返回 2；原空范围返回 0
     * @throws CommonBusinessException 例如 [CLOSABLE,OPEN] 整批拒绝，不保存前一条或创建日志
     */
    public static int closableCount(List<String> statuses) {
        if (statuses == null
                || statuses.stream()
                        .anyMatch(
                                status ->
                                        !"CLOSABLE".equals(status) && !"REOPENED".equals(status))) {
            throw new CommonBusinessException("ATTENDANCE_MONTHLY_BLOCKED", "当前范围仍存在不可月结记录。");
        }
        // 只返回预检计数；真实批量更新、日志和回滚必须由所属表 Service 完成。
        return statuses.size();
    }

    /**
     * 沿用旧重开必须提供原因的输入约束，保留原文本，不发明新状态或权限限制。
     *
     * @param reason 已授权 Service 的重开原因，例如 need-adjustment；空白拒绝
     * @return 例如 {closeStatus:REOPENED,reason:need-adjustment}
     * @throws CommonBusinessException 原因缺失时拒绝；不会清除真实 closedAt 或写动作日志
     */
    public static Map<String, String> reopenOutcome(String reason) {
        if (reason == null || reason.isBlank()) {
            throw new CommonBusinessException("ATTENDANCE_REOPEN_REASON_REQUIRED", "重开原因不能为空。");
        }
        return Map.of("closeStatus", "REOPENED", "reason", reason);
    }

    /**
     * 组成旧案件/审批/处理状态三字段，状态字符串不接收用户角色。
     *
     * @param status 原方法确定的案件状态，例如 RETURNED
     * @param handling 原方法确定的日次处理状态，例如 IN_REVIEW
     * @return 例如 {caseStatus:RETURNED,approvalStatus:RETURNED,handlingStatus:IN_REVIEW}，无写入
     */
    private static Map<String, String> state(String status, String handling) {
        return Map.of("caseStatus", status, "approvalStatus", status, "handlingStatus", handling);
    }

    /**
     * 解析旧 ISO 日期时间补丁，缺失保持原实际时间。
     *
     * @param value 原补丁时间值，例如 2026-05-18T18:45:00
     * @param fallback 原日次实际时间，例如 LocalDateTime 2026-05-18T18:00
     * @return 例如 LocalDateTime 2026-05-18T18:45；空白返回原值，无副作用
     */
    private static Object optionalTime(Object value, Object fallback) {
        return blank(value) ? fallback : LocalDateTime.parse(value.toString());
    }

    /**
     * 沿用旧可选字段 hasText 判定，不把数字 0 视为空值。
     *
     * @param value 原补丁值，例如空白字符串或整数 0
     * @return 空白返回 true、整数 0 返回 false；无副作用
     */
    private static boolean blank(Object value) {
        return value == null || value.toString().isBlank();
    }
}
