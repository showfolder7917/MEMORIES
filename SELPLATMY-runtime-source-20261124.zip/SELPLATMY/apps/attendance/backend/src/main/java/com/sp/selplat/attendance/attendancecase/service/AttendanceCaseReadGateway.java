/* 2026-11-01：处理单本人、独立审批及差异预览五读取，提交/审批写不在本合同。 */
package com.sp.selplat.attendance.attendancecase.service;

import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 原处理单及预览五读取的稳定本域合同；本人绑定和独立审批的规则仍由原拥有方决定。 */
public interface AttendanceCaseReadGateway {

  /**
   * 方法作用：读取本人绑定员工的原处理单页，不采纳请求身份。
   *
   * @param input 原分页和caseStatus，例如pageNo1/caseStatusSUBMITTED
   * @return 原完整分页，例如records含9430/employeeId7080、totalCount1
   */
  CommonPageResult ownedStore(CommonPageParam input);

  /**
   * 方法作用：读取本人原处理单详情，保留持久正文和归属拒绝。
   *
   * @param input 原主键，例如id9430
   * @return 原CommonResult，例如data.employeeId7080/patchPayloadJson为原JSON字符串
   */
  CommonResult getOwned(CommonParam input);

  /**
   * 方法作用：沿独立APPROVER读取原租户案件页，不授予管理或本人权限。
   *
   * @param input 原分页与业务筛选，例如employeeId7081/pageNo1
   * @return 原完整分页，例如records含9432/totalCount1
   */
  CommonPageResult reviewStore(CommonPageParam input);

  /**
   * 方法作用：沿原独立审批资格读取本租户处理单详情。
   *
   * @param input 原主键，例如id9432
   * @return 原CommonResult，例如data.caseStatus为RETURNED，无写入
   */
  CommonResult reviewDetail(CommonParam input);

  /**
   * 方法作用：读取原服务端审批差异，不提交日次或处理单。
   *
   * @param input 原案件主键/修订/草稿，例如id9430/revision0/actualClockOut18:45
   * @return 原完整CommonResult，含before/current/proposed/rule/schedule，无写入
   */
  CommonResult previewAction(CommonParam input);
}
