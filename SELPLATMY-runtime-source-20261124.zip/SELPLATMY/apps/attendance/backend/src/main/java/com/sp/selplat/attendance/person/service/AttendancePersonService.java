/* 通用考勤人员档案；2026-10-26，学生不建成员工。 */
package com.sp.selplat.attendance.person.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 通用人员独立维护；员工雇佣、班次、账号和审批仍由原业务负责。 */
public interface AttendancePersonService extends BaseService {
    /**
     * 方法作用：保存人员资料及完整变更历史，不创建员工、账号或签到。
     * @param input 前端业务候选，例如personName小禾/personKindSTUDENT/personStateACTIVE/requestKey规范UUID
     * @return 真实返回示例：data={id:"100000",versionNo:"0",replay:false}。
     * 异常或副作用示例：跨租户、旧版、重复编号或同键异内容拒绝；停用不删除历史。
     */
    CommonResult save(CommonParam input);
}
