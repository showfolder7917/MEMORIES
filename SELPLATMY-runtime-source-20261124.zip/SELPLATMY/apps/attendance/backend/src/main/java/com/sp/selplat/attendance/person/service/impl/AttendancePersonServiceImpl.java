/* 通用人员版本保存与租户目录；2026-10-27，原员工权限及雇佣流程保持原归属。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.attendance.person.service.impl;

import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.person.dao.AttendancePersonDao;
import com.sp.selplat.attendance.person.service.AttendancePersonService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.identity.LocalIdentityCommitSupport;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.support.CommonHashSupport;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.service.identity.LocalIdentityLockAccess;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;

/** 通用人员按有效租户管理；管理员关联员工复用受保护原流程，独立人员不自动变成员工。 */
@Service
public class AttendancePersonServiceImpl extends BaseServiceImpl<AttendancePersonDao>
    implements AttendancePersonService {

  // 人员原独立保存按原模板；租户管理员关联员工时改用角色持锁的真正提交范围。
  @org.springframework.beans.factory.annotation.Autowired
  private com.sp.selplat.attendance.capability.accessconfiguration.service
          .AttendanceTenantManagementExecution
      managementExecution;

  // 原保存身份锁只用于同进程真实提交，不跨HTTP传递Supplier。
  private final LocalIdentityLockAccess sessions;

  // 读取通过Host具名公共能力，原租户范围及锁后身份复核仍由本Service拥有。
  private final CurrentSessionAccess identities;

  // 内部教学联动也必须具备本地提交保护，不能因不走Controller而绕回本地写入。
  private final LocalIdentityCommitSupport localCommit;

  // 人员与追加历史使用同一考勤事务。
  private final TransactionTemplate transaction;

  // 原员工及其管理资格由原拥有方核验；普通姓名同步不会取得员工管理能力。
  private final com.sp.selplat.attendance.employee.service.AttendanceEmployeeService employees;

  private final com.sp.selplat.attendance.capability.accessconfiguration.service
          .AttendanceAuthorizationService
      authorization;

  // 用途不产生登录角色，学生不是雇员。
  private static final Set<String> KINDS = Set.of("STUDENT", "TEACHER", "STAFF", "OTHER");

  /**
   * 方法作用：装配真实会话及具名事务；DAO复用公共泛型绑定。
   *
   * @param sessions Host具名原本地身份锁，例如原Session互斥
   * @param identities Host具名attendanceCurrentSessionAccess，例如原桥接或真实HTTP读取
   * @param localCommit Host具名attendanceLocalIdentityCommitSupport，只声明部署前提，不授予权限
   * @param manager attendanceTransactionManager，例如独立内存考勤库管理器
   * @param employees 原员工拥有方，例如明确员工8801的读取与锁
   * @param authorization 原员工管理资格，不因通用人员身份而放行HR操作 异常或副作用示例：不创建人员、员工或管理许可。
   */
  public AttendancePersonServiceImpl(
      @Qualifier("attendanceLocalIdentityLockAccess") LocalIdentityLockAccess sessions,
      @Qualifier("attendanceCurrentSessionAccess") CurrentSessionAccess identities,
      @Qualifier("attendanceLocalIdentityCommitSupport") LocalIdentityCommitSupport localCommit,
      @Qualifier("attendanceTransactionManager") PlatformTransactionManager manager,
      com.sp.selplat.attendance.employee.service.AttendanceEmployeeService employees,
      com.sp.selplat.attendance.capability.accessconfiguration.service
              .AttendanceAuthorizationService
          authorization) {
    this.employees = employees;
    this.authorization = authorization;
    this.sessions = sessions;
    this.identities = identities;
    this.localCommit = localCommit;
    transaction = new TransactionTemplate(manager);
    transaction.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    transaction.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
  }

  /**
   * 方法作用：读取当前租户真实人员页，停用项仍可供核对和恢复。
   *
   * @param input 分页及白名单条件，例如pageNo1/pageSize20/personKindSTUDENT
   * @return 真实返回示例：records含id100000/personName小禾/versionNo0，totalCount1。
   *     异常或副作用示例：未知过滤、超过100页长或偏移溢出拒绝，零写入。
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    var actor = identity();
    keys(input, Set.of("personNameContainsIgnoreCase", "personKind", "personState"));
    if (input.getPageSize() > 100
        || (long) (input.getPageNo() - 1) * input.getPageSize() > Integer.MAX_VALUE) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    var q = new LinkedHashMap<String, Object>();
    q.put("tenantId", actor.get("tenantId"));
    q.put("status", 1);
    for (String field : List.of("personNameContainsIgnoreCase", "personKind", "personState")) {
      if (input.getParam(field) != null) {
        String value = text(input.getParam(field), 100, false);
        if (field.equals("personKind") && !KINDS.contains(value)) {
          throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
        }
        if (field.equals("personState") && !Set.of("ACTIVE", "INACTIVE").contains(value)) {
          throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
        }
        if (!value.isEmpty()) {
          q.put(field, value);
        }
      }
    }
    var page =
        getDao().getPageList(q, "sortnum desc id asc", input.getPageNo(), input.getPageSize());
    page.setRecords(page.getRecords().stream().map(this::projection).toList());
    unchanged(actor);
    return page;
  }

  /**
   * 方法作用：按稳定主键读取本租户安全详情，隐藏原请求和历史原文。
   *
   * @param input HTTP候选，例如id100000
   * @return 真实返回示例：data={id:"100000",personNumber:"P100000",personKind:STUDENT,versionNo:"0"}。
   *     异常或副作用示例：异租户或无记录统一拒绝，不泄露其他租户详情。
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    var actor = identity();
    keys(input, Set.of("id"));
    var record = getDao().getById(scoped(actor, positive(input.getParam("id"))));
    if (record == null || record.isEmpty()) {
      throw failure("ATTENDANCE_PERSON_NOT_FOUND");
    }
    unchanged(actor);
    return buildSuccessResult(projection(record), "人员详情读取完成。");
  }

  /**
   * 方法作用：保存人员资料和完整审计，身份切换互斥期间沿原UUID处理。
   *
   * @param input 前端业务候选，例如personName小禾/personKindSTUDENT/personStateACTIVE/requestKeyUUID
   * @return 真实返回示例：data={id:"100000",versionNo:"0",replay:false}。
   *     异常或副作用示例：旧版、同键异内容、失效租户或重复编号拒绝；不新增员工或签到。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      propagation = Propagation.NOT_SUPPORTED)
  public CommonResult save(CommonParam input) {
    // 部署前提先于身份、正文及任何SQL，内部同步不能绕过尚未迁移的提交合同。
    localCommit.requireSupported();
    var actor = identity();
    var p = normalize(input);
    var content = new TreeMap<String, Object>(p.getParamMap());
    content.remove("requestKey");
    String hash = CommonHashSupport.sha256(JsonUtils.toJsonIgnoreNull(content));
    if (managementExecution.isAdministrator()) {
      return saveAttempt(actor, p, hash, true);
    }
    return sessions.executeWithCurrentIdentityLock(
        () -> {
          unchanged(actor);
          return saveAttempt(actor, p, hash, false);
        });
  }

  /**
   * 方法作用：选定原身份保护或角色保护后执行同一保存及原冲突回读，不重复进入身份互斥。
   *
   * @param actor 本次已解析的真实身份，例如tenant981/user9811
   * @param p 原规范正文，例如personKindTEACHER/employeeId100000/requestKeyUUID
   * @param hash 原正文64位摘要，重试不得换正文
   * @param administrator true明确要求原角色持锁提交，false保留原身份及事务模板
   * @return 真实返回示例：原人员id100001/versionNo0/replayfalse。 异常或副作用示例：来源冲突、角色失效或编号占用拒绝，失败事务不能复用。
   */
  private CommonResult saveAttempt(
      Map<String, Long> actor, CommonParam p, String hash, boolean administrator) {
    try {
      if (administrator) {
        return managementExecution.executeAdministrator(() -> store(actor, p, hash));
      }
      return transaction.execute(state -> store(actor, p, hash));
    } catch (DataIntegrityViolationException conflict) {
      // 并发冲突后离开失败事务，只读原UUID及占用状态，保留原回执恢复合同。
      unchanged(actor);
      if (p.getParam("id") == null) {
        var first = creation(actor, p.getParam("requestKey"));
        if (first != null) {
          return replay(first, hash);
        }
      }
      if (p.getParam("employeeId") != null && revision(p.getParam("employeeId")) > 0) {
        java.util.function.Supplier<CommonResult> review =
            () -> {
              authorization.requireManagement();
              var reference = new CommonParam();
              reference.putParam("tenantId", actor.get("tenantId"));
              reference.putParam("employeeId", p.getParam("employeeId"));
              var occupied = getDao().getByQuery(reference);
              if (occupied != null
                  && !occupied.isEmpty()
                  && !String.valueOf(occupied.get("id")).equals(String.valueOf(p.getParam("id")))) {
                throw failure("ATTENDANCE_PERSON_EMPLOYEE_OCCUPIED");
              }
              throw failure("ATTENDANCE_PERSON_NUMBER_EXISTS");
            };
        return administrator ? managementExecution.executeAdministrator(review) : review.get();
      }
      throw failure("ATTENDANCE_PERSON_NUMBER_EXISTS");
    }
  }

  /**
   * 方法作用：实际考勤事务内追加人员版本，不改变稳定主键和首次请求。
   *
   * @param actor 原真实身份，例如tenant81/user8103
   * @param p 规范正文，例如personName小禾/personKindSTUDENT/personStateACTIVE
   * @param hash 规范SHA256，例如64位文本
   * @return 真实返回示例：data.versionNo1/replayfalse。 异常或副作用示例：锁后身份、版本或唯一约束变化时整体回滚。
   */
  private CommonResult store(Map<String, Long> actor, CommonParam p, String hash) {
    unchanged(actor);
    long id, next;
    Long employeeId = null;
    var events = new ArrayList<Map<String, Object>>();
    Map<String, Object> before = Map.of();
    var row = new CommonParam();
    row.putParam("tenantId", actor.get("tenantId"));
    row.putParam("lastOperateUserId", actor.get("userId"));
    if (p.getParam("id") == null) {
      var first = creation(actor, p.getParam("requestKey"));
      if (first != null) {
        return replay(first, hash);
      }
      id = getSequence().get("id");
      next = 0;
      row.putParam("code", "AttendancePerson_" + id);
      row.putParam("creationRequestKey", p.getParam("requestKey"));
      row.putParam("creationHash", hash);
      row.putParam("status", 1);
      row.putParam("sortnum", 0);
    } else {
      id = positive(p.getParam("id"));
      var prior = getDao().lockScoped(scoped(actor, id));
      unchanged(actor);
      if (prior == null) {
        throw failure("ATTENDANCE_PERSON_NOT_FOUND");
      }
      events = history(prior.get("changeHistoryJson"));
      for (var event : events) {
        if (p.getParam("requestKey").equals(event.get("requestKey"))) {
          if (!hash.equals(event.get("payloadHash"))) {
            throw failure("ATTENDANCE_PERSON_REQUEST_CONFLICT");
          }
          return receipt(id, revision(event.get("versionNo")), true);
        }
      }
      long version = revision(prior.get("versionNo"));
      if (version != revision(p.getParam("expectedVersion")) || version == Long.MAX_VALUE) {
        throw failure("ATTENDANCE_PERSON_VERSION_CONFLICT");
      }
      next = version + 1;
      row.putParam("expectedVersion", version);
      before = projection(prior);
      if (prior.get("employeeId") != null) {
        employeeId = positive(prior.get("employeeId"));
      }
    }
    // 未提供关联字段时保留旧关系；只有明确关联或解除才调用原员工管理裁决。
    if (p.getParamMap().containsKey("employeeId")) {
      authorization.requireManagement();
      long selected = revision(p.getParam("employeeId"));
      if (selected == 0) {
        employeeId = null;
      } else {
        var selectedEmployee = new CommonParam();
        selectedEmployee.putParam("id", selected);
        selectedEmployee.putParam(
            "expectedSourceVersion", p.getParam("expectedEmployeeSourceVersion"));
        employees.lockPersonReference(selectedEmployee);
        employeeId = selected;
      }
    }
    if (employeeId != null && !Set.of("TEACHER", "STAFF").contains(p.getParam("personKind"))) {
      throw failure("ATTENDANCE_PERSON_EMPLOYEE_KIND_INVALID");
    }
    row.putParam("employeeId", employeeId);
    if (events.size() >= 2000) {
      throw failure("ATTENDANCE_PERSON_HISTORY_LIMIT");
    }
    String number = p.getParam("personNumber").toString();
    if (number.isEmpty()) {
      number = "P" + id;
    }
    row.putParam("id", id);
    row.putParam("personNumber", number);
    row.putParam("numberKey", number.toLowerCase(Locale.ROOT));
    row.putParam("versionNo", next);
    for (String field : List.of("personName", "personKind", "personState")) {
      row.putParam(field, p.getParam(field));
    }
    var event = new LinkedHashMap<String, Object>();
    event.put("requestKey", p.getParam("requestKey"));
    event.put("payloadHash", hash);
    event.put("versionNo", next);
    event.put("actorUserId", actor.get("userId").toString());
    event.put("recordedAt", Instant.now().toString());
    event.put("before", before);
    event.put(
        "after",
        Map.of(
            "personNumber",
            number,
            "personName",
            p.getParam("personName"),
            "personKind",
            p.getParam("personKind"),
            "personState",
            p.getParam("personState")));
    var after = new LinkedHashMap<String, Object>((Map<String, Object>) event.get("after"));
    after.put("employeeId", employeeId);
    event.put("after", after);
    events.add(event);
    row.putParam("changeHistoryJson", JsonUtils.toJsonIgnoreNull(events));
    int count = p.getParam("id") == null ? getDao().insert(row) : getDao().updateVersion(row);
    if (count != 1) {
      throw failure("ATTENDANCE_PERSON_VERSION_CONFLICT");
    }
    if (p.getParamMap().containsKey("employeeId")) {
      authorization.requireManagement();
    }
    unchanged(actor);
    return receipt(id, next, false);
  }

  /**
   * 方法作用：只按本租户原UUID识别创建重试，不能按姓名合并。
   *
   * @param actor 真实身份，例如tenant81/user8103
   * @param key 规范创建UUID，例如12345678-1234-4234-8234-123456789abc
   * @return 真实返回示例：原行id100000；未建立null。 异常或副作用示例：只读本表，不创建关系。
   */
  private Map<String, Object> creation(Map<String, Long> actor, Object key) {
    var p = new CommonParam();
    p.putParam("tenantId", actor.get("tenantId"));
    p.putParam("creationRequestKey", key);
    p.putParam("status", 1);
    var row = getDao().getByQuery(p);
    return row == null || row.isEmpty() ? null : row;
  }

  /**
   * 方法作用：原创建摘要相同才返回首次版本。
   *
   * @param row 原行，例如id100000/creationHash64位文本
   * @param hash 规范摘要，例如与原创建相同
   * @return 真实返回示例：data.versionNo0/replaytrue。 异常或副作用示例：不同正文重用原UUID拒绝，不覆盖原资料。
   */
  private CommonResult replay(Map<String, Object> row, String hash) {
    if (!hash.equals(row.get("creationHash"))) {
      throw failure("ATTENDANCE_PERSON_REQUEST_CONFLICT");
    }
    return receipt(positive(row.get("id")), 0, true);
  }

  /**
   * 方法作用：组装精确文本编号和版本。
   *
   * @param id 实际人员主键，例如100000
   * @param version 首次结果版本，例如0
   * @param replay 是否重放，例如true
   * @return 真实返回示例：data={id:"100000",versionNo:"0",replay:true}。 异常或副作用示例：不创建员工、账号或考勤结果。
   */
  private CommonResult receipt(long id, long version, boolean replay) {
    return buildSuccessResult(
        Map.of("id", Long.toString(id), "versionNo", Long.toString(version), "replay", replay),
        "人员资料已保存。");
  }

  /**
   * 方法作用：只公开人员必要投影，不暴露审计UUID。
   *
   * @param row 实际本表行，例如id100000/personName小禾
   * @return 真实返回示例：id/code/personNumber/personName/personKind/personState/versionNo为原真实文本。
   *     异常或副作用示例：纯映射，不修改DAO记录。
   */
  private Map<String, Object> projection(Map<String, Object> row) {
    var safe = new LinkedHashMap<String, Object>();
    for (String field :
        List.of(
            "id", "code", "personNumber", "personName", "personKind", "personState", "versionNo")) {
      safe.put(field, row.get(field).toString());
    }
    if (row.get("employeeId") != null) {
      safe.put("employeeId", row.get("employeeId").toString());
    }
    return safe;
  }

  /**
   * 方法作用：取得原Session最新有效账号、成员和租户。
   *
   * @return 真实返回示例：tenantId81/userId8103。 异常或副作用示例：停用租户或匿名由原会话服务拒绝，不创建默认身份。
   */
  private Map<String, Long> identity() {
    return AttendanceAccessGuard.requireIdentity(identities.revalidateCurrent());
  }

  /**
   * 方法作用：锁后和提交前核身份未切换。
   *
   * @param actor 原真实身份，例如tenant81/user8103 异常或副作用示例：切换账号或学校拒绝，并由本域事务回滚。
   */
  private void unchanged(Map<String, Long> actor) {
    if (!actor.equals(identity())) {
      throw failure("ATTENDANCE_PERSON_IDENTITY_CHANGED");
    }
  }

  /**
   * 方法作用：将可信身份与实际主键组成范围条件。
   *
   * @param actor 原身份，例如tenant81/user8103
   * @param id 精确主键，例如100000
   * @return 真实返回示例：CommonParam{tenantId:81,id:100000}。 异常或副作用示例：不使用客户端tenantId。
   */
  private static CommonParam scoped(Map<String, Long> actor, long id) {
    var p = new CommonParam();
    p.putParam("tenantId", actor.get("tenantId"));
    p.putParam("id", id);
    return p;
  }

  /**
   * 方法作用：规范白名单、用途和原UUID。
   *
   * @param input HTTP候选，例如personName小禾/personKindSTUDENT/personStateACTIVE/requestKeyUUID
   * @return 真实返回示例：规范CommonParam含personNumber空串，由服务器生成P100000。 异常或副作用示例：非法用途、原版本、UUID或身份覆盖字段拒绝。
   */
  private static CommonParam normalize(CommonParam input) {
    keys(
        input,
        Set.of(
            "id",
            "expectedVersion",
            "requestKey",
            "personNumber",
            "personName",
            "personKind",
            "personState",
            "employeeId",
            "expectedEmployeeSourceVersion"));
    var p = new CommonParam();
    String key = text(input.getParam("requestKey"), 36, true);
    try {
      if (!UUID.fromString(key).toString().equals(key)) {
        throw new IllegalArgumentException("UUID");
      }
    } catch (IllegalArgumentException invalid) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    p.putParam("requestKey", key);
    p.putParam("personNumber", text(input.getParam("personNumber"), 100, false));
    p.putParam("personName", text(input.getParam("personName"), 100, true));
    String kind = text(input.getParam("personKind"), 30, true),
        state = text(input.getParam("personState"), 30, true);
    if (!KINDS.contains(kind) || !Set.of("ACTIVE", "INACTIVE").contains(state)) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    p.putParam("personKind", kind);
    p.putParam("personState", state);
    if (input.getParam("id") != null) {
      p.putParam("id", positive(input.getParam("id")));
      p.putParam("expectedVersion", revision(input.getParam("expectedVersion")));
    } else if (input.getParam("expectedVersion") != null) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    if (input.getParamMap().containsKey("employeeId")) {
      long employee = revision(input.getParam("employeeId"));
      p.putParam("employeeId", employee);
      if (employee > 0) {
        String hash = text(input.getParam("expectedEmployeeSourceVersion"), 64, true);
        if (!hash.matches("[0-9a-f]{64}")) {
          throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
        }
        p.putParam("expectedEmployeeSourceVersion", hash);
      } else if (input.getParam("expectedEmployeeSourceVersion") != null) {
        throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
      }
    } else if (input.getParam("expectedEmployeeSourceVersion") != null) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    return p;
  }

  /**
   * 方法作用：检查本操作字段白名单。
   *
   * @param input 原输入，例如id100000
   * @param allowed 明确字段，例如id 异常或副作用示例：出现tenantId/operatorId即拒绝，不查全库。
   */
  private static void keys(CommonParam input, Set<String> allowed) {
    if (input == null || !allowed.containsAll(input.getParamMap().keySet())) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
  }

  /**
   * 方法作用：解析非负精确版本，不接受小数或溢出。
   *
   * @param value 原版本，例如"0"
   * @return 真实返回示例：0L。 异常或副作用示例：非法文本、缺失或负数拒绝。
   */
  private static long revision(Object value) {
    try {
      String s = String.valueOf(value);
      if (!s.matches("0|[1-9][0-9]{0,18}")) {
        throw new NumberFormatException();
      }
      return Long.parseLong(s);
    } catch (NumberFormatException invalid) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
  }

  /**
   * 方法作用：解析稳定正主键。
   *
   * @param value 候选，例如"100000"
   * @return 真实返回示例：100000L。 异常或副作用示例：0、负数、小数、缺失或溢出拒绝。
   */
  private static long positive(Object value) {
    long id = revision(value);
    if (id == 0) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    return id;
  }

  /**
   * 方法作用：去除字段首尾空格并拒绝控制字符。
   *
   * @param value 前端字段，例如小禾
   * @param max 最大长度，例如100
   * @param required 是否必填，例如姓名true
   * @return 真实返回示例：小禾；未提供可选编号为空字符串。 异常或副作用示例：空白必填项、超长或控制字符拒绝，不截断编号。
   */
  private static String text(Object value, int max, boolean required) {
    if (value == null && !required) {
      return "";
    }
    if (!(value instanceof String s)) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    s = s.strip();
    if (s.length() > max
        || (required && s.isEmpty())
        || s.codePoints().anyMatch(Character::isISOControl)) {
      throw failure("ATTENDANCE_PERSON_INPUT_INVALID");
    }
    return s;
  }

  /**
   * 方法作用：完整读取追加审计，损坏内容不能变成首次保存。
   *
   * @param raw 已保存JSON，例如包含UUID和versionNo0的事件列表
   * @return 真实返回示例：可追加的原事件列表。 异常或副作用示例：损坏数据传播错误，不重置审计。
   */
  @SuppressWarnings("unchecked")
  private static ArrayList<Map<String, Object>> history(Object raw) {
    return new ArrayList<>(
        (List<Map<String, Object>>) (List<?>) JsonUtils.fromJson(raw.toString(), List.class));
  }

  /**
   * 方法作用：构造安全业务拒绝。
   *
   * @param code 明确错误，例如ATTENDANCE_PERSON_VERSION_CONFLICT
   * @return 真实返回示例：带上述错误码的CommonBusinessException。 异常或副作用示例：不包含其他租户详情或凭据。
   */
  private static CommonBusinessException failure(String code) {
    return new CommonBusinessException(code, "人员操作未完成，请核对输入、租户状态或重新读取最新版本。");
  }

  /**
   * 方法作用：取得真实租户。
   *
   * @return 真实返回示例：81；匿名拒绝，无写入。
   */
  @Override
  protected Long getCurrentTenantId() {
    return identity().get("tenantId");
  }

  /**
   * 方法作用：取得真实操作人。
   *
   * @return 真实返回示例：8103；匿名拒绝，无写入。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return identity().get("userId");
  }

  /**
   * 方法作用：不隐式授予管理员身份。
   *
   * @return 真实返回示例：false，无权限写入。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 方法作用：关闭无版本通用写和删除，只能具名保存或停用。
   *
   * @param input 通用候选，例如id100000 异常或副作用示例：明确拒绝，不删除历史。
   */
  @Override
  protected void applyCurrentIdentity(CommonParam input) {
    throw failure("ATTENDANCE_PERSON_NAMED_SAVE_REQUIRED");
  }

  /**
   * 方法作用：关闭未设计的批量读取，使用租户分页或详情。
   *
   * @param input 通用候选，例如items含id100000
   * @return 真实返回示例：无成功返回。 异常或副作用示例：拒绝未知范围，不返回其他租户记录。
   */
  @Override
  public CommonResult getByIds(CommonBatchParam input) {
    throw failure("ATTENDANCE_PERSON_ACCESS_DENIED");
  }
}
