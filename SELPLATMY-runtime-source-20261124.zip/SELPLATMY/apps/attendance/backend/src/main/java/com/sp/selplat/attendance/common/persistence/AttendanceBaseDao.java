package com.sp.selplat.attendance.common.persistence;

import com.sp.selplat.common.db.dao.BaseDaoImpl;
import com.sp.selplat.common.db.template.model.CommonTemplateUpdate;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.exception.CommonBusinessException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.sp.selplat.common.db.datasource.BaseDataSourceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/** 所有考勤业务表绑定同一考勤私有数据源，不读取 Uniauth 或其他应用业务表。 */
public abstract class AttendanceBaseDao extends BaseDaoImpl {
    private BaseDataSourceContext context;

    /**
     * 绑定实际考勤连接池及同源模板。
     *
     * @param context 具名 attendanceBaseDataSourceContext，例如连接隔离 attendance_test 库 副作用示例：只保存由 Spring
     *     装配的上下文，不执行 SQL。
     */
    @Autowired
    protected final void setAttendanceContext(
            @Qualifier("attendanceBaseDataSourceContext") BaseDataSourceContext context) {
        this.context = context;
    }

    /**
     * @return 考勤同源上下文，例如 attendanceDataSource 与其私有 BaseTemplateDao。
     */
    @Override
    protected final BaseDataSourceContext getDataSourceContext() {
        return context;
    }

    /**
     * 按 id 和服务端 tenantId 查询启用记录，主键不自动意味着租户授权。
     *
     * @param query 原业务参数，例如 id=100001、tenantId=81
     * @return 同租户启用记录；无匹配返回 null，不读取其他租户详情
     * @throws CommonBusinessException 缺少正主键/租户时拒绝，无写入副作用
     */
    @Override
    public Map<String, Object> getById(CommonParam query) {
        requireKeys(query);
        CommonParam scoped = new CommonParam();
        scoped.putParam("id", query.getParam("id"));
        scoped.putParam("tenantId", query.getParam("tenantId"));
        scoped.putParam("status", 1);
        return getByQuery(scoped);
    }

    /**
     * 所有批量详情都逐项使用真实租户条件，任一缺失或异租户即拒绝，不返回部分业务数据。
     *
     * @param query 已由服务覆盖租户的批量主键，例如 items=[{id:100001,tenantId:81}]
     * @return 同租户真实行，例如一条 Daily 快照；不替换或伪造查询结果
     * @throws CommonBusinessException 任一目标不存在或不属于当前租户时拒绝，无写入副作用
     */
    @Override
    public List<Map<String, Object>> getByIds(CommonBatchParam query) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (CommonParam item : query.getItems()) {
            Map<String, Object> row = getById(item);
            if (row == null) {
                throw denied();
            }
            rows.add(row);
        }
        return rows;
    }

    /**
     * 复用公共模板生成 id+tenantId 条件，tenantId 永远不进入 SET，避免跨租户移动记录。
     *
     * @param input 服务端身份已覆盖的更新参数，例如 id=100001、tenantId=81、remark=说明
     * @return 实际影响行数 1
     * @throws CommonBusinessException 零行或异常行数拒绝，调用方事务必须回滚；不泄露其他租户行
     */
    @Override
    public int update(CommonParam input) {
        requireKeys(input);
        Map<String, Object> values = buildDbColumnValueMap(input);
        Object id = values.remove("id");
        Object tenant = values.remove("tenantId");
        CommonTemplateUpdate update = new CommonTemplateUpdate();
        update.setTableName(getTableName());
        // 此处为租户条件组合，不更改物理主键或一表一号段定义。
        update.setIdColumns(List.of("id", "tenantId"));
        update.setIdValues(List.of(id, tenant));
        update.setColumnValueMap(values);
        int count = getBaseTemplateDao().updateByIds(update);
        if (count != 1) {
            throw denied();
        }
        return count;
    }

    /**
     * 复用共享模板的真实 JDBC batch，每组最多 1000，WHERE 同时绑定 id 与 tenantId。
     *
     * @param input 服务端租户已覆盖的批量项，例如 1001 条同租户更新
     * @return 全部真实影响行数；没有业务项返回 0
     * @throws CommonBusinessException 任一目标失效或异租户时拒绝；拥有本域事务的 Service 回滚全部分组
     */
    @Override
    public int updateBatch(CommonBatchParam input) {
        input.getItems().forEach(this::requireKeys);
        int count = 0;
        for (int start = 0; start < input.getItems().size(); start += 1000) {
            List<CommonParam> group =
                    input.getItems()
                            .subList(start, Math.min(start + 1000, input.getItems().size()));
            count +=
                    getBaseTemplateDao()
                            .updateBatchByIds(
                                    getTableName(),
                                    List.of("id", "tenantId"),
                                    getDbColumnsMap(),
                                    group);
        }
        if (count != input.getItems().size()) {
            throw denied();
        }
        return count;
    }

    /**
     * 校验服务端绑定的租户和目标主键，不接受小数、缺失或溢出。
     *
     * @param input 共通 DAO 参数，例如 id=100001、tenantId=81
     * @throws CommonBusinessException 不合法时拒绝，尚未访问数据库
     */
    private void requireKeys(CommonParam input) {
        if (input == null) {
            throw denied();
        }
        for (String key : List.of("id", "tenantId")) {
            try {
                if (new java.math.BigDecimal(String.valueOf(input.getParam(key))).longValueExact()
                        <= 0) {
                    throw denied();
                }
            } catch (NumberFormatException | ArithmeticException exception) {
                throw denied();
            }
        }
    }

    /**
     * @return 不披露目标归属的公共业务异常，例如 ATTENDANCE_ACCESS_DENIED，无副作用。
     */
    private CommonBusinessException denied() {
        return new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
}
