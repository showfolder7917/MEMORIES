/* 通用人员租户锁和CAS；2026-10-26。 */
/* 修改记录：2026-10-27，CAS一并保存员工关联编号，未明确变更时由人员拥有方保留原关系。 */
/* 2026-10-27：规范空白、控制体及异常说明；原业务表达式、字符串与分支已逐份核对。 */
package com.sp.selplat.attendance.person.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.util.CommonParam;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * 本表固定参数化SQL，不直接查询学生、员工或CRM。
 */
@Repository
public class AttendancePersonDaoImpl extends AttendanceBaseDao implements AttendancePersonDao {

  // 与考勤公共CRUD共享同一池及事务连接。
  private final JdbcTemplate jdbc;

  /**
   * 方法作用：绑定实际考勤模板，不新建连接池。
   * @param jdbc attendanceJdbcTemplate，例如独立内存考勤库模板
   * 异常或副作用示例：只保留依赖，不执行SQL。
   */
  public AttendancePersonDaoImpl(@Qualifier("attendanceJdbcTemplate") JdbcTemplate jdbc) {
    this.jdbc = jdbc;
  }

  /**
   * 方法作用：本域事务中按真实租户和主键取锁。
   * @param input 已核主键，例如tenantId81/id100000
   * @return 真实返回示例：人员完整行；未命中null。
   * 异常或副作用示例：缺少本源事务拒绝，零业务写入。
   */
  @Override
  public Map<String, Object> lockScoped(CommonParam input) {
    requireTransaction();
    var rows =
        jdbc.queryForList(
            "SELECT * FROM AttendancePerson WHERE tenantId=? AND id=? AND status=1 FOR UPDATE",
            input.getParam("tenantId"),
            input.getParam("id"));
    return rows.isEmpty() ? null : rows.get(0);
  }

  /**
   * 方法作用：CAS变更本表资料、状态与历史，不改首次创建请求。
   * @param input 本表值，例如id100000/tenantId81/expectedVersion0/personStateINACTIVE
   * @return 真实返回示例：1；旧版本为0。
   * 异常或副作用示例：没有考勤事务或违反唯一约束拒绝，不写其他业务表。
   */
  @Override
  public int updateVersion(CommonParam input) {
    requireTransaction();
    return jdbc.update(
        "UPDATE AttendancePerson SET personNumber=?,numberKey=?,personName=?,personKind=?,personState=?,employeeId=?,"
            + "changeHistoryJson=?,lastOperateUserId=?,versionNo=versionNo+1,updatedAt=CURRENT_TIMESTAMP "
            + "WHERE tenantId=? AND id=? AND status=1 AND versionNo=?",
        input.getParam("personNumber"),
        input.getParam("numberKey"),
        input.getParam("personName"),
        input.getParam("personKind"),
        input.getParam("personState"),
        input.getParam("employeeId"),
        input.getParam("changeHistoryJson"),
        input.getParam("lastOperateUserId"),
        input.getParam("tenantId"),
        input.getParam("id"),
        input.getParam("expectedVersion"));
  }

  /**
   * 方法作用：拒绝无考勤事务锁和CAS；副作用示例：缺实际绑定连接时抛错，不开启自动提交写。
   *
   * @throws IllegalStateException 未处于原考勤事务时拒绝，例如脱离事务直接执行版本更新。
   */
  private void requireTransaction() {
    if (!TransactionSynchronizationManager.isActualTransactionActive()
        || !TransactionSynchronizationManager.hasResource(jdbc.getDataSource())) {
      throw new IllegalStateException("Attendance person transaction required");
    }
  }
}
