/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
package com.sp.selplat.attendance.shifttemplate.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceShiftTemplate 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceShiftTemplateService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用排班能力在同事务锁定模板、核验生效日期并保护曾引用事实。
   *
   * @param input 当前模板和明确工作日期例如id=8901、workDate=2026-10-03
   * @return 实际CommonResult.data包含startTime=22:00、revision=0；不跨表DAO、不写历史结果
   *     异常或副作用示例：未生效/停用/失效或权限撤销拒绝；引用标记随排班回滚。
   */
  CommonResult lockForSchedule(CommonParam input);
}
