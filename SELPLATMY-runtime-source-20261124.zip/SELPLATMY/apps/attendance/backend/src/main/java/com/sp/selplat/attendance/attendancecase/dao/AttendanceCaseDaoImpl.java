package com.sp.selplat.attendance.attendancecase.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import org.springframework.stereotype.Repository;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.exception.CommonSystemException;
import java.util.List;
import java.util.Map;

/** AttendanceCase 使用本域私有数据源和共享模板，表名来自实际类名，不读取请求表名。 */
@Repository
public class AttendanceCaseDaoImpl extends AttendanceBaseDao implements AttendanceCaseDao {
    /**
     * 复用真实公共分页SQL，再把本表审批补丁CLOB映射为实际JSON文本；默认排序入口也委托此方法。
     *
     * @param queryColumnValueMap 服务端范围，例如tenantId=81、employeeId=8801、status=1
     * @param orderBy 已有公共排序，例如id desc
     * @param pageNo 实际页码，例如1
     * @param pageSize 实际页大小，例如20
     * @return 实际CommonPageResult，例如records=[{id:100001,patchPayloadJson:"{}"}]、totalCount=1
     *     异常或副作用示例：CLOB读取失败保留真实原因并抛系统异常；只读，不改变总数或排序。
     */
    @Override
    public CommonPageResult getPageList(
            Map<String, Object> queryColumnValueMap,
            String orderBy,
            Integer pageNo,
            Integer pageSize) {
        // 原公共SQL/分页/权限筛选结果保持；仅转换本表JSON文本，不暴露驱动对象。
        CommonPageResult page = super.getPageList(queryColumnValueMap, orderBy, pageNo, pageSize);
        page.setRecords(page.getRecords().stream().map(this::readCaseText).toList());
        return page;
    }

    /**
     * 复用公共主键查询，管理/本人/审批及审计读取获得同一实际字符串字段。
     *
     * @param queryIn 所属服务已经核验的范围，例如id=100001、tenantId=81
     * @return 真实行例如{id:100001,patchPayloadJson:"{}"}；无匹配仍为null
     *     异常或副作用示例：真实CLOB读取失败返回系统异常，未发出新增或更新SQL。
     */
    @Override
    public Map<String, Object> getById(CommonParam queryIn) {
        // 查询仍由公共DAO按真实参数执行；副本转换不污染事务查询缓存。
        return readCaseText(super.getById(queryIn));
    }

    /**
     * 复用公共批量读取和原有记录顺序，防止批量JSON响应仍泄漏CLOB驱动对象。
     *
     * @param queryIn 已核验的主键列表，例如items=[{id:100001,tenantId:81}]
     * @return 实际行列表例如[{id:100001,patchPayloadJson:"{}"}]；没有记录返回空列表
     *     异常或副作用示例：CLOB读取失败抛系统异常；不提升管理或本人授权。
     */
    @Override
    public List<Map<String, Object>> getByIds(CommonBatchParam queryIn) {
        // 真实公共批量结果逐行映射，仅本表字段转换，无伪造记录。
        return super.getByIds(queryIn).stream().map(this::readCaseText).toList();
    }

    /**
     * 将本表patchPayloadJson的实际CLOB内容复制成字符串，不解析或重写业务JSON。
     *
     * @param row 真实JDBC行，例如id=100001、patchPayloadJson为内容{}的H2 Clob
     * @return 独立字段副本例如{id:100001,patchPayloadJson:"{}"}；null仍为null
     * @throws CommonSystemException 实际SQLException/长度溢出时保留cause并拒绝读取；不写数据库
     */
    private Map<String, Object> readCaseText(Map<String, Object> row) {
        // 无匹配必须保持原公共查询合同，不生成空记录。
        if (row == null) {
            return null;
        }
        Map<String, Object> fields = new java.util.LinkedHashMap<>(row);
        for (String field : java.util.List.of("patchPayloadJson", "dailyBeforeJson")) {
            if (fields.get(field) instanceof java.sql.Clob text) {
                try {
                    // JDBC实际字符内容原样返回；驱动对象及其stream/trace字段不属于业务响应。
                    fields.put(field, text.getSubString(1, Math.toIntExact(text.length())));
                } catch (java.sql.SQLException | ArithmeticException failure) {
                    throw new CommonSystemException(
                            "ATTENDANCE_CASE_READ_FAILED", "处理单内容读取失败，请稍后重试。", failure);
                }
            }
        }
        return fields;
    }

    /**
     * 用事务连接锁真实案件并读当前修订，不复用锁前缓存快照。
     *
     * @param input 服务端归属例如 id=9501、tenantId=81
     * @return 真实当前行例如 revision=0、caseStatus=SUBMITTED；无匹配null 异常或副作用示例：数据库等待/失败抛出，只有本表行锁，无业务写入。
     */
    @Override
    public Map<String, Object> lockCase(CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        var rows =
                jdbc.queryForList(
                        "SELECT * FROM AttendanceCase WHERE tenantId=? AND id=? AND status=1 FOR UPDATE",
                        input.getParam("tenantId"),
                        input.getParam("id"));
        return rows.isEmpty() ? null : readCaseText(rows.getFirst());
    }

    /**
     * 精确比较修订递增，影响数零由所属Service拒绝整个动作。
     *
     * @param input 服务端主键/租户/预期修订例如 9501/81/0
     * @return 实际UPDATE影响数例如1成功或0过期 异常或副作用示例：同业务事务递增，后续审计失败会回滚到0。
     */
    @Override
    public int claimRevision(CommonParam input) {
        var jdbc =
                new org.springframework.jdbc.core.JdbcTemplate(
                        getDataSourceContext().getDataSource());
        return jdbc.update(
                "UPDATE AttendanceCase SET revision=revision+1 WHERE tenantId=? AND id=? AND status=1 AND revision=?",
                input.getParam("tenantId"),
                input.getParam("id"),
                input.getParam("revision"));
    }
}
