/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.monthlyreview.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.exception.CommonSystemException;
import com.sp.selplat.common.util.CommonPageResult;
import java.util.Map;
import org.springframework.stereotype.Repository;

/** AttendanceMonthlyReview绑定本域数据源和公共模板，差异SQL只涉及本表。 */
@Repository
public class AttendanceMonthlyReviewDaoImpl extends AttendanceBaseDao
    implements AttendanceMonthlyReviewDao {

  /**
   * 仅CAS修改审签状态/失效事实，不SET payload/source/hash。
   *
   * @param input 服务端id/tenant/revision和目标状态例如APPROVED
   * @return 实际更新1；状态/修订失配返回0，SQL失败传播 副作用示例：冻结内容永不更新，外层月事务持有员工/月锁。
   */
  @Override
  public int compareState(com.sp.selplat.common.util.CommonParam input) {
    var jdbc =
        new org.springframework.jdbc.core.JdbcTemplate(getDataSourceContext().getDataSource());
    if ("APPROVED".equals(input.getParam("targetState"))) {
      return jdbc.update(
          "UPDATE AttendanceMonthlyReview SET"
              + " reviewStatus='APPROVED',revision=revision+1,reviewedBy=?,reviewedAt=?,updatedAt=?"
              + " WHERE tenantId=? AND id=? AND revision=? AND reviewStatus='PENDING' AND"
              + " activeMonthlyId=monthlyId",
          input.getParam("actorId"),
          input.getParam("now"),
          input.getParam("now"),
          input.getParam("tenantId"),
          input.getParam("id"),
          input.getParam("revision"));
    }
    return jdbc.update(
        "UPDATE AttendanceMonthlyReview SET"
            + " reviewStatus='INVALIDATED',activeMonthlyId=NULL,revision=revision+1,invalidatedAt=?,invalidationReason=?,updatedAt=?"
            + " WHERE tenantId=? AND id=? AND revision=? AND reviewStatus IN ('PENDING','APPROVED')"
            + " AND activeMonthlyId=monthlyId",
        input.getParam("now"),
        input.getParam("reason"),
        input.getParam("now"),
        input.getParam("tenantId"),
        input.getParam("id"),
        input.getParam("revision"));
  }

  /**
   * 方法作用：复用原SQL和分页，仅把本表payloadJson的真实CLOB字符转成文本。
   *
   * @param values 原拥有方筛选，例如tenantId9/status1
   * @param orderBy 原受控排序，例如sortnum desc id asc
   * @param pageNo 实际页码，例如1
   * @param pageSize 原页大小，例如20
   * @return 原CommonPageResult，例如records=[{id:62000,payloadJson:"{}"}]、totalCount=1
   * @throws CommonSystemException 真实正文读取失败保留cause；不返回驱动对象或空成功
   */
  @Override
  public CommonPageResult getPageList(
      Map<String, Object> values, String orderBy, Integer pageNo, Integer pageSize) {
    // 原权限范围、计数和顺序保留；getByQuery及租户详情也沿此原查询入口。
    var page = super.getPageList(values, orderBy, pageNo, pageSize);
    page.setRecords(page.getRecords().stream().map(this::readBodyText).toList());
    return page;
  }

  /**
   * 方法作用：只复制本行并读取payloadJson字符，字符串、空串及null原样保留。
   *
   * @param source 原JDBC行，例如id62000/payloadJson为内容{}的Clob
   * @return 原字段副本，例如payloadJson为字符串"{}"；无行保持null
   * @throws CommonSystemException SQLException或长度溢出保留原原因，不写数据库
   */
  private Map<String, Object> readBodyText(Map<String, Object> source) {
    if (source == null) {
      return null;
    }
    var row = new java.util.LinkedHashMap<String, Object>(source);
    if (row.get("payloadJson") instanceof java.sql.Clob text) {
      try {
        // 原始正文逐字符保留，不解析、不截断、不生成替代JSON。
        row.put("payloadJson", text.getSubString(1, Math.toIntExact(text.length())));
      } catch (java.sql.SQLException | ArithmeticException failure) {
        throw new CommonSystemException(
            "ATTENDANCE_RELEASE_READ_FAILED", "月报正文读取失败，请稍后重试。", failure);
      }
    }
    return row;
  }
}
