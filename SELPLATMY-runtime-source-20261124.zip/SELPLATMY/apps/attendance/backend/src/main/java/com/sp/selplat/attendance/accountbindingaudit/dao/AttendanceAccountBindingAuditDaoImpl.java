package com.sp.selplat.attendance.accountbindingaudit.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.util.CommonParam;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/** 只在显式已核验schema内消费独立绑定审计，不自动DDL或跨表查询。 */
@Repository
public class AttendanceAccountBindingAuditDaoImpl extends AttendanceBaseDao
        implements AttendanceAccountBindingAuditDao {
    /**
     * 查询当前schema真实账本存在性，不猜名字或默认初始化。
     *
     * @return 真实存在例如true，旧库缺表false；无写入
     */
    @Override
    public boolean ready() {
        return new JdbcTemplate(getDataSourceContext().getDataSource())
                        .queryForObject(
                                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE"
                                        + " TABLE_SCHEMA=SCHEMA() AND"
                                        + " TABLE_NAME='AttendanceAccountBindingAudit'",
                                Integer.class)
                == 1;
    }

    /**
     * 同本地员工/账号锁内读取当前已提交审计，包含历史失效事件供幂等核验。
     *
     * @param input 真实tenantId=81/userId=8104
     * @return 实际审计列表例如revisionNo1/BIND，空列表表示没有被记录过的命令，无写入
     */
    @Override
    public List<Map<String, Object>> events(CommonParam input) {
        return new JdbcTemplate(getDataSourceContext().getDataSource())
                .queryForList(
                        "SELECT * FROM AttendanceAccountBindingAudit WHERE tenantId=? AND userId=?"
                                + " ORDER BY revisionNo",
                        input.getParam("tenantId"),
                        input.getParam("userId"));
    }
}
