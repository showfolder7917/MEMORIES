/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.monthlyactionlog.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceMonthlyActionLog 真实表服务；管理查询默认拒绝，通用写入/更新/删除不可修改审批与审计事实。 */
public interface AttendanceMonthlyActionLogService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 专用动作能力追加审计，通用CRUD不能建立或改写记录。
   *
   * @param input 所属服务产生的事实，例如 monthlyId=100001、actionType=MANUAL_RECALCULATE
   * @return 实际CommonResult，例如 success=true、data.operatorId=8101；无权限时拒绝，失败回滚本域事务
   */
  CommonResult appendAction(CommonParam input);

  /**
   * 原子追加同次月结的全部动作事实，复用公共号段与真实 JDBC batch。
   *
   * @param records 内部事实，例如1001条 monthlyId、actionType=CLOSE；身份由本次会话覆盖
   * @return 实际 CommonResult，例如 affectedRows=1001；不更新或删除历史审计 异常或副作用示例：缺权限、缺父记录或任一约束失败，拥有者事务回滚全部分组。
   */
  CommonResult appendActions(com.sp.selplat.common.util.CommonBatchParam records);

  /**
   * 独立月动作读取真实最后CLOSE审计作为来源版本。
   *
   * @param input monthlyId/actionCode例如9301/PUBLISH
   * @return 实际最新CLOSE行或null，仅读本表
   */
  CommonResult releaseSource(CommonParam input);

  /**
   * 独立月动作同事务追加审计。
   *
   * @param input 当前事实及actionCode例如monthlyId=9301/PUBLISH
   * @return 公共super实际新增行，失败传播回滚，不授予管理权限
   */
  CommonResult appendReleaseAction(CommonParam input);

  /**
   * 方法作用：原独立月动作来源读取，保留原完整范围及分页
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readReleaseSource(
      com.sp.selplat.common.util.CommonParam input);
}
