/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
package com.sp.selplat.attendance.monthlyitem.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceMonthlyItem 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceMonthlyItemService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用业务能力提交服务端校验/计算的快照；没有 HTTP 直接调用入口。
   *
   * @param scope 真实月次主键，例如 monthlyId=100001
   * @param records 算法产生的指标批次，旧批次软删除留存，不从客户端取得指标
   * @return 实际号段及持久化结果 CommonResult 异常或副作用示例：拒绝受保护状态；真实本域事务写入该表，不直接访问其他表。
   */
  CommonResult replaceForMonthly(
      CommonParam scope, com.sp.selplat.common.util.CommonBatchParam records);

  /**
   * 读取本人已发布并生效月快照或该快照指标，服务端固定归属和分页上限。
   *
   * @param input 分页筛选，例如 pageNo=1、pageSize=20；指标必须 monthlyId=9301
   * @return 真实 CommonPageResult，例如 records=[{id:9301}]、totalCount=1，无管理字段
   *     异常或副作用示例：缺精确许可或指标目标不归本人时拒绝，只读库。
   */
  com.sp.selplat.common.util.CommonPageResult ownedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 月审签从所属服务完整读取真实指标。
   *
   * @param input 内部monthlyId/actionCode例如9301/PUBLISH
   * @return 实际完整指标data列表，仅读本表，缺许可拒绝
   */
  CommonResult releaseItems(CommonParam input);

  /**
   * 方法作用：原本人月报纯读，交付前重核真实身份与精确许可
   *
   * @param input 原分页或月主键，例如id9601/monthlyId9601
   * @return 原完整CommonPageResult，例如records含本人冻结指标
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  com.sp.selplat.common.util.CommonPageResult readOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：原独立月动作来源读取，保留原完整范围及分页
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readReleaseItems(
      com.sp.selplat.common.util.CommonParam input);
}
