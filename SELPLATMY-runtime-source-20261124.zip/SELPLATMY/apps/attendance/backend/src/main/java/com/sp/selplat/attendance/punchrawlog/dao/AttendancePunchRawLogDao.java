package com.sp.selplat.attendance.punchrawlog.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendancePunchRawLog 只拥有本表公共 CRUD，不跨表读取身份或业务记录。 */
public interface AttendancePunchRawLogDao extends BaseDao { }
