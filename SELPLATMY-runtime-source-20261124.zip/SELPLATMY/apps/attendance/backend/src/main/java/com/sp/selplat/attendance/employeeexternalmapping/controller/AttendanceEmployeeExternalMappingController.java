/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.employeeexternalmapping.controller;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceConfigurationReadGateway;
import com.sp.selplat.attendance.employeeexternalmapping.service.AttendanceEmployeeExternalMappingService;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.util.JsonUtils;
import com.sp.selplat.common.web.controller.BaseController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** 本表管理查询和专用写入口，不复制身份或响应协议。 */
@RestController
@RequestMapping("/api/attendance/employeeexternalmapping")
public class AttendanceEmployeeExternalMappingController
    extends BaseController<AttendanceEmployeeExternalMappingService> {

  /**
   * @param input 例如 sourceSystem=CSV_A、externalEmployeeId=X1、employeeId=8801
   * @return 完整 PENDING CommonResult JSON；只登记映射。
   */
  @PostMapping("register.htm")
  public String register(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(getService().register(input));
  }

  /**
   * @param input 例如 id=100001
   * @return 完整 VERIFIED CommonResult JSON；冲突不核准。
   */
  @PostMapping("verify.htm")
  public String verify(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(getService().verify(input));
  }

  /**
   * 撤销冲突映射，保留既有事实和核准审计字段。
   *
   * @param input 例如 id=100001
   * @return 完整 REVOKED CommonResult JSON；异租户拒绝，无账号写入。
   */
  @PostMapping("revoke.htm")
  public String revoke(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(getService().revoke(input));
  }

  private final AttendanceConfigurationReadGateway managementReads;

  /**
   * 方法作用：装配原管理查询，其他原处理器及写保护保留。
   *
   * @param managementReads 原具名管理网关，例如bridge或HTTP；构造不读写业务
   */
  public AttendanceEmployeeExternalMappingController(
      @org.springframework.beans.factory.annotation.Qualifier(
              "attendanceEmployeeExternalMappingReadGateway")
          AttendanceConfigurationReadGateway managementReads) {
    this.managementReads = managementReads;
  }

  /**
   * 方法作用：保留原分页URL和GET/POST，委派固定只读网关。
   *
   * @param input 原CommonPageParam，例如pageNo1/pageSize20
   * @return 原分页JSON，不在Controller改变身份或条件
   */
  @Override
  @RequestMapping(
      value = "getStore.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getStore(CommonPageParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getStore(input));
  }

  /**
   * 方法作用：保留原详情URL和GET/POST，权限与租户判断仍由原配置拥有方完成。
   *
   * @param input 原精确主键，例如id8501
   * @return 原CommonResult JSON，无写入
   */
  @Override
  @RequestMapping(
      value = "getById.htm",
      method = {RequestMethod.GET, RequestMethod.POST},
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getById(CommonParam input) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getById(input));
  }

  /**
   * 方法作用：保留原viewCode表头协议及默认语言。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原列配置JSON，不替换原配置来源
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "!tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumn(
      @RequestParam(name = "viewCode", defaultValue = "default") String viewCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    return JsonUtils.toJsonIgnoreNull(managementReads.getGridColumn(viewCode, locale));
  }

  /**
   * 方法作用：保留原tableCode响应形状，仍由原配置拥有方核实际表名。
   *
   * @param tableCode 原Grid唯一编码，例如table930001
   * @param locale 原语言，例如ja-JP
   * @return 原JSON，data中tableCode替代viewCode，无配置写入
   */
  @Override
  @GetMapping(
      value = "getGridColumn.htm",
      params = "tableCode",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public String getGridColumnByTableCode(
      @RequestParam(name = "tableCode") String tableCode,
      @RequestParam(name = "locale", defaultValue = "zh-CN") String locale) {
    CommonResult result = managementReads.getGridColumn(tableCode, locale);
    if (result.getData() instanceof java.util.Map<?, ?> original) {
      var data = new java.util.LinkedHashMap<String, Object>();
      original.forEach((key, value) -> data.put(String.valueOf(key), value));
      data.remove("viewCode");
      data.put("tableCode", tableCode);
      result.setData(data);
    }
    return JsonUtils.toJsonIgnoreNull(result);
  }

  /**
   * 方法作用：保留原批量POST JSON协议，仅转交同一拥有方固定读取合同
   *
   * @param input 原JSON正文，例如items含62000和62001
   * @return 原完整JSON，例如success为true且data为原批量列表，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @org.springframework.web.bind.annotation.RequestMapping(
      value = "getByIds.htm",
      method = org.springframework.web.bind.annotation.RequestMethod.POST,
      produces = org.springframework.http.MediaType.APPLICATION_JSON_VALUE)
  public String getByIds(
      @org.springframework.web.bind.annotation.RequestBody
          com.sp.selplat.common.util.CommonBatchParam input) {
    return com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(managementReads.getByIds(input));
  }
}
