/* 2026-10-28：身份查询改由Host具名公共接口装配，原考勤资格判断保持。 */
package com.sp.selplat.attendance.capability.sessioncontext.service.impl;

import com.sp.selplat.attendance.capability.sessioncontext.service.AttendanceSessionContextService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.common.util.CommonResult;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import org.springframework.beans.factory.annotation.Qualifier;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

/** 每次请求重新校验真实账号，不缓存登录名或把管理员名称当业务授权。 */
@Service
public class AttendanceSessionContextServiceImpl implements AttendanceSessionContextService {
    private final CurrentSessionAccess sessionService;
    private final AttendanceAuthorizationService authorization;

    /**
     * 装配平台真实会话服务。
     *
     * @param sessionService Host具名attendanceCurrentSessionAccess公共查询，例如原权限桥接；禁止使用请求参数建立主体
     * @param authorization 本域真实配置授权服务，未核验配置默认拒绝，不设置任何授权 执行示例：后续 current 经账号 DAO 检查状态，无数据库写入。
     */
    public AttendanceSessionContextServiceImpl(
            @Qualifier("attendanceCurrentSessionAccess") CurrentSessionAccess sessionService,
            AttendanceAuthorizationService authorization) {
        this.sessionService = sessionService;
        this.authorization = authorization;
    }

    /**
     * 读取服务端 userId 与 tenantId，并在业务映射未核准时关闭考勤操作权限。
     *
     * @return CommonResult，例如 userId=7、tenantId=2、canManage=false、canSubmitCorrection=false
     * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名、账号失效或租户缺失时拒绝
     */
    @Override
    public CommonResult current() {
        // 只允许真实 Session 的账号概要进入归属工具，Header 和请求体均不参与身份选择。
        Map<String, Long> identity =
                AttendanceAccessGuard.requireIdentity(sessionService.current());
        Map<String, Object> data = new LinkedHashMap<>(identity);
        // 已核验配置只能用于同一次服务端身份；会话切换时关闭权限标记。
        Map<?, ?> configuration = (Map<?, ?>) authorization.currentConfiguration().getData();
        boolean sameIdentity =
                identity.get("userId").equals(configuration.get("userId"))
                        && identity.get("tenantId").equals(configuration.get("tenantId"));
        data.put("canManage", sameIdentity && Boolean.TRUE.equals(configuration.get("canManage")));
        data.put("canSubmitCorrection", false);
        CommonResult result = new CommonResult();
        result.setSuccess(true);
        result.setModuleCode("attendance");
        result.setData(data);
        result.setMsg("考勤会话已验证。");
        return result;
    }

    /**
     * 通过真实共享会话辨别匿名，只吞已知身份缺失错误，不读取请求用户或返回账号信息。
     *
     * @return 例如 success=true、data={authenticated:false}；实际有效会话为 true，不包含管理授权 异常或副作用示例：非
     *     UNIAUTH_IDENTITY_REQUIRED 的业务/数据库异常原样抛出；无写入。
     */
    @Override
    public CommonResult status() {
        boolean authenticated;
        try {
            sessionService.current();
            authenticated = true;
        } catch (CommonBusinessException exception) {
            if (!"UNIAUTH_IDENTITY_REQUIRED".equals(exception.getErrorCode())) {
                throw exception;
            }
            authenticated = false;
        }
        CommonResult result = new CommonResult();
        result.setSuccess(true);
        result.setModuleCode("attendance");
        result.setData(Map.of("authenticated", authenticated));
        result.setMsg("登录状态已读取。");
        return result;
    }
}
