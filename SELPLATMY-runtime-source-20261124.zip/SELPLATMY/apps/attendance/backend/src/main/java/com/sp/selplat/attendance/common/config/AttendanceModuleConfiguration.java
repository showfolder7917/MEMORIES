package com.sp.selplat.attendance.common.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/** Host 显式导入考勤组件；真实认证由 Host 同时装配的 Uniauth 提供。 */
@Configuration(proxyBeanMethods = false)
@ComponentScan("com.sp.selplat.attendance")
public class AttendanceModuleConfiguration { }
