/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：审批来源纯读接入，原保存/审批来源保护保持。 */
/* 2026-11-01：保留sortnum降序，同值固定id升序，避免分页依赖物理行次序。 */
/* 2026-11-01：原人员关联与排班纯读，原写/锁/事务算法保留。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.employeeworkrule.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.employeeworkrule.dao.AttendanceEmployeeWorkRuleDao;
import com.sp.selplat.attendance.employeeworkrule.service.AttendanceEmployeeWorkRuleService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceEmployeeWorkRule 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceEmployeeWorkRuleServiceImpl
    extends BaseServiceImpl<AttendanceEmployeeWorkRuleDao>
    implements AttendanceEmployeeWorkRuleService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  @Autowired private com.sp.selplat.attendance.employee.service.AttendanceEmployeeService employees;

  @Autowired private com.sp.selplat.attendance.ruleconfig.service.AttendanceRuleConfigService rules;

  @Autowired
  private com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService monthlyPeriods;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insert(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    var protection = beginProtectedMutation(java.util.List.of(input), false);
    validateReferences(input, false);
    CommonResult result = super.insert(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    var protection = beginProtectedMutation(input.getItems(), false);
    for (CommonParam item : input.getItems()) {
      validateReferences(item, false);
    }
    CommonResult result = super.insertBatch(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    var protection = beginProtectedMutation(java.util.List.of(input), true);
    validateReferences(input, true);
    CommonResult result = super.update(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    var protection = beginProtectedMutation(input.getItems(), true);
    for (CommonParam item : input.getItems()) {
      validateReferences(item, true);
    }
    CommonResult result = super.updateBatch(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    var protection = beginProtectedMutation(java.util.List.of(input), true);
    CommonResult result = super.delete(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    var protection = beginProtectedMutation(input.getItems(), true);
    CommonResult result = super.deleteBatch(input);
    verifyProtectedSelections(protection);
    return result;
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceEmployeeWorkRule 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 规则关联只能指向当前租户真实员工与规则；更新未提交的字段沿用现有行。
   *
   * @param input 共通关联字段，例如 employeeId=8801、ruleId=8501
   * @param update 是否现有记录更新；例如 true 时补齐原 employeeId，无新的工资/分钟判断
   * @throws CommonBusinessException 缺员工或异租户引用时拒绝；仅读取所属表服务，无写入副作用
   */
  private void validateReferences(CommonParam input, boolean update) {
    Map<String, Object> values = new java.util.LinkedHashMap<>();
    if (update) {
      values.putAll(getDao().getById(input));
    }
    values.putAll(input.getParamMap());
    CommonParam employee = new CommonParam();
    employee.putParam("id", values.get("employeeId"));
    employees.getById(employee);
    if (values.get("ruleId") != null) {
      CommonParam rule = new CommonParam();
      rule.putParam("id", values.get("ruleId"));
      validateReferenceRevision(input, "ruleRevision", rules.lockForReference(rule));
    }
    if (values.get("roundingRuleId") != null) {
      CommonParam rounding = new CommonParam();
      rounding.putParam("id", values.get("roundingRuleId"));
      validateReferenceRevision(input, "roundingRuleRevision", rules.lockForReference(rounding));
    }
  }

  /**
   * 页面选择的修订必须与真实锁中规则一致，旧无修订CRUD保留既有行为。
   *
   * @param input 关联请求例如ruleRevision=1；校验后移除技术字段，不进入关联表列
   * @param field 修订字段例如ruleRevision或roundingRuleRevision
   * @param locked 所属规则服务的锁中结果，例如data.revision=1
   *     异常或副作用示例：旧修订0抛ATTENDANCE_ASSIGNMENT_RULE_STALE，外层关联事务回滚永久引用标志。
   * @throws CommonBusinessException 所选规则修订已变化，请重新选择实际规则。
   */
  private void validateReferenceRevision(CommonParam input, String field, CommonResult locked) {
    Object expected = input.getParamMap().remove(field);
    if (expected == null) {
      return;
    }
    Object data = locked.getData();
    Object revision = data instanceof Map<?, ?> row ? row.get("revision") : null;
    try {
      String value = String.valueOf(expected);
      if (!value.matches("0|[1-9][0-9]*")
          || !(revision instanceof Number actual)
          || Long.parseLong(value) != actual.longValue()) {
        throw new NumberFormatException("stale revision");
      }
    } catch (NumberFormatException invalid) {
      throw new CommonBusinessException("ATTENDANCE_ASSIGNMENT_RULE_STALE", "所选规则修订已变化，请重新选择实际规则。");
    }
  }

  /**
   * 仅独立核验的TENANT APPROVER读取计算来源，不提升通用管理权限，也无HTTP直接入口。
   *
   * @param criteria 审批日的规则条件，例如employeeId=8801、effectiveStartDateLe=2026-10-04、pageNo=1
   * @return 真实表数据，例如id=100001、tenantId=81；无匹配为空，不返回其他租户来源 异常或副作用示例：缺审批配置时拒绝；仅查询，无配置、角色或业务记录写入。
   */
  @Override
  public com.sp.selplat.common.util.CommonPageResult getForApproval(
      com.sp.selplat.common.util.CommonPageParam criteria) {
    return loadApprovalSource(criteria, authorization.requireApproval());
  }

  /**
   * 实时核验管理身份并查询本表保留的引用。
   *
   * @param input 所属规则服务传入主键例如 id=8501
   * @return 实际引用数例如1；无数据写入，缺可信许可拒绝
   */
  @Override
  public long countRuleReferences(CommonParam input) {
    // 其他表服务只能经公开契约访问；真实租户覆盖客户端范围。
    input.putParam("tenantId", requireManagement().get("tenantId"));
    return getDao().countRuleReferences(input);
  }

  /**
   * 在真实员工升序锁内保存所有受影响员工的实际关联基线，包含改员工前后的范围。
   *
   * @param items 实际CRUD项例如employeeId=8801或id=8401/employeeId=8803
   * @param existing 例如true需要读取原记录归属，false为新建
   * @return 当前员工到真实启用关联列表的映射，锁保持到CRUD及比较结束 异常或副作用示例：等待中归属变动抛ATTENDANCE_ASSIGNMENT_STALE，要求刷新，无业务提交。
   * @throws CommonBusinessException 员工规则关联必须选择真实员工。；考勤管理授权尚未配置。；员工规则关联归属已变化，请刷新后再修改。
   */
  private Map<Long, java.util.List<Map<String, Object>>> beginProtectedMutation(
      java.util.List<CommonParam> items, boolean existing) {
    Map<String, Long> identity = requireManagement();
    java.util.Set<Long> employeeIds = new java.util.TreeSet<>();
    for (CommonParam item : items) {
      item.putParam("tenantId", identity.get("tenantId"));
      if (existing) {
        requireRecord(item, true);
        employeeIds.add(assignmentEmployee(getDao().getById(item).get("employeeId")));
      }
      if (item.getParamMap().containsKey("employeeId")) {
        employeeIds.add(assignmentEmployee(item.getParam("employeeId")));
      } else if (!existing) {
        throw new CommonBusinessException("ATTENDANCE_ASSIGNMENT_INPUT_INVALID", "员工规则关联必须选择真实员工。");
      }
    }
    for (Long employeeId : employeeIds) {
      CommonParam key = new CommonParam();
      key.putParam("id", employeeId);
      employees.lockForSchedule(key);
    }
    if (!identity.equals(requireManagement())) {
      throw new CommonBusinessException("ATTENDANCE_MANAGEMENT_UNAVAILABLE", "考勤管理授权尚未配置。");
    }
    // 不能在等待后追加更小主键的锁；原归属改变时要求明确刷新重试。
    if (existing) {
      for (CommonParam item : items) {
        requireRecord(item, true);
        if (!employeeIds.contains(assignmentEmployee(getDao().getById(item).get("employeeId")))) {
          throw new CommonBusinessException("ATTENDANCE_ASSIGNMENT_STALE", "员工规则关联归属已变化，请刷新后再修改。");
        }
      }
    }
    Map<Long, java.util.List<Map<String, Object>>> before = new java.util.LinkedHashMap<>();
    for (Long employeeId : employeeIds) {
      CommonParam scope = new CommonParam();
      scope.putParam("employeeId", employeeId);
      scope.putParam("tenantId", identity.get("tenantId"));
      // 先取得本员工全部保留月行锁，缺月行由员工锁覆盖。
      monthlyPeriods.protectedPeriods(scope);
      before.put(employeeId, getDao().currentEmployeeAssignments(scope));
    }
    return before;
  }

  /**
   * 公共CRUD完成后按数据库实际主键和字段比较保护月每日命中，变动整笔回滚。
   *
   * @param before 员工升序锁内的实际基线，例如8801对应id8401，未伪造新主键优先级
   *     异常或副作用示例：新高优先级关联覆盖9月10日抛ATTENDANCE_PERIOD_PROTECTED，关联和引用标志回滚。
   * @throws CommonBusinessException 该月份已结或已有效发布，请先正式重开月份后再修改。
   */
  private void verifyProtectedSelections(Map<Long, java.util.List<Map<String, Object>>> before) {
    Map<String, Long> identity = requireManagement();
    for (var entry : before.entrySet()) {
      CommonParam scope = new CommonParam();
      scope.putParam("employeeId", entry.getKey());
      scope.putParam("tenantId", identity.get("tenantId"));
      java.util.List<Map<String, Object>> after = getDao().currentEmployeeAssignments(scope);
      for (Object value : (java.util.List<?>) monthlyPeriods.protectedPeriods(scope).getData()) {
        java.time.YearMonth month =
            java.time.YearMonth.parse(String.valueOf(((Map<?, ?>) value).get("yearMonth")));
        for (java.time.LocalDate day = month.atDay(1);
            !day.isAfter(month.atEndOfMonth());
            day = day.plusDays(1)) {
          if (!selectedParameters(entry.getValue(), day).equals(selectedParameters(after, day))) {
            throw new CommonBusinessException(
                "ATTENDANCE_PERIOD_PROTECTED", "该月份已结或已有效发布，请先正式重开月份后再修改。");
          }
        }
      }
    }
  }

  /**
   * 沿用旧较晚生效日、再较大主键优先级，比较实际选中关联和工时参数，不另算工资。
   *
   * @param rows 当前真实启用关联，例如id=8401/ruleId=8501
   * @param day 保护月实际日期例如2026-09-10，结束日包含在区间内
   * @return 所选关联参数映射，例如id=8401/standardDailyMinutes=480；无命中为空
   *     异常或副作用示例：只比较值，备注/审计和不影响保护月选择的未来变更不被永久冻结。
   */
  private Map<String, Object> selectedParameters(
      java.util.List<Map<String, Object>> rows, java.time.LocalDate day) {
    Map<String, Object> selected =
        rows.stream()
            .filter(
                row ->
                    !java.time.LocalDate.parse(row.get("effectiveStartDate").toString())
                            .isAfter(day)
                        && (row.get("effectiveEndDate") == null
                            || !java.time.LocalDate.parse(row.get("effectiveEndDate").toString())
                                .isBefore(day)))
            .max(
                java.util.Comparator.<Map<String, Object>, String>comparing(
                        row -> row.get("effectiveStartDate").toString())
                    .thenComparingLong(row -> ((Number) row.get("id")).longValue()))
            .orElse(null);
    Map<String, Object> parameters = new java.util.LinkedHashMap<>();
    if (selected != null) {
      for (String field :
          java.util.List.of(
              "id",
              "ruleId",
              "roundingRuleId",
              "workRuleType",
              "standardDailyMinutes",
              "standardWeeklyMinutes",
              "overtimeEnabled",
              "nightWorkEnabled",
              "holidayWorkEnabled")) {
        parameters.put(field, selected.get(field));
      }
    }
    return parameters;
  }

  /**
   * 精确读取真实员工主键，禁止空值或小数变成默认身份。
   *
   * @param value 例如8801，字符串数值必须可精确转为正Long
   * @return 正员工主键例如8801 异常或副作用示例：NULL或8801.5拒绝，无数据写入。
   * @throws CommonBusinessException 员工规则关联必须选择真实员工。
   */
  private long assignmentEmployee(Object value) {
    try {
      long id = new java.math.BigDecimal(String.valueOf(value)).longValueExact();
      if (id <= 0) {
        throw new ArithmeticException("employee");
      }
      return id;
    } catch (NumberFormatException | ArithmeticException invalid) {
      throw new CommonBusinessException("ATTENDANCE_ASSIGNMENT_INPUT_INVALID", "员工规则关联必须选择真实员工。");
    }
  }

  /**
   * 方法作用：复用原本表COUNT查询，先后核真实只读管理资格，不修改永久引用。
   *
   * @param input 原所属配置编号，例如id8501，tenantId由服务端覆盖
   * @return 原真实保留引用数量，例如1，无数据写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格失效或换身份时拒绝旧计数
   */
  @Override
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public long countRuleReferencesForRead(com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadManagement();
    input.putParam("tenantId", actor.get("tenantId"));
    long result = getDao().countRuleReferences(input);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "引用读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原租户过滤与完整查询，不改变关联或锁定状态。
   *
   * @param input 原查询，例如id8410
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonPageResult，例如原记录或分页
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原租户过滤与完整查询，不改变关联或锁定状态。
   *
   * @param input 原查询，例如id8410
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonResult，例如原记录或分页
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原详情和真实租户校验，不修改或解锁关联记录。
   *
   * @param input 原主键，例如id8410或8210
   * @return 原完整详情，例如data.employeeId7020及原规则或排班字段
   * @throws CommonBusinessException 异校、失效、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：原配置和元数据表头沿系统查看门槛读取，不提升管理权限。
   *
   * @param viewCode 原表头编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns包含配置名称
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无配置写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "配置读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原审批来源完整过滤和返回，不锁定或标记引用。
   *
   * @param criteria 原来源条件，例如employeeId7080
   * @param identity 原已核审批身份，例如userId9102/tenantId9
   * @return 原分页，例如原生效规则或排班
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原记录/来源错误沿原拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonPageResult loadApprovalSource(
      com.sp.selplat.common.util.CommonPageParam criteria, java.util.Map<String, Long> identity) {
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return getDao()
        .getPageList(
            criteria.getParamMap(),
            "sortnum desc id asc",
            criteria.getPageNo(),
            criteria.getPageSize());
  }

  /**
   * 方法作用：HTTP身份原审批来源只读，实际SELECT完成后重核资格。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原完整分页，不改变规则或快照
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原APPROVER失效/撤回或身份变化拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonPageResult readForApproval(
      com.sp.selplat.common.util.CommonPageParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadApprovalSource(input, actor);
    if (!actor.equals(authorization.requireReadApproval())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "审批来源读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
