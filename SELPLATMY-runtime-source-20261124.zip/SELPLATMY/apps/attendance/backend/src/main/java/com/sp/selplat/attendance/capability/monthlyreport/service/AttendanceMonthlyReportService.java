/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
package com.sp.selplat.attendance.capability.monthlyreport.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 月报读取与导出能力不继承 CRUD，不持有 DAO。 */
public interface AttendanceMonthlyReportService {

  /**
   * 从月次表服务读取授权快照并导出。
   *
   * @param input 月次主键参数，例如 id=100001；客户端身份不参与授权
   * @return 共通结果，例如 data={format:CSV,fileName:attendance-monthly.csv,content:...}
   * @throws com.sp.selplat.common.exception.CommonBusinessException 表服务未授权或记录不存在时拒绝
   */
  CommonResult export(CommonParam input);

  /**
   * 方法作用：HTTP管理月报导出，前后核原管理资格，不接受客户端快照替换
   *
   * @param input 原保存月次主键，例如id61000
   * @return 原CSV CommonResult，例如data.format=CSV/原content，无重算
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult readExport(com.sp.selplat.common.util.CommonParam input);
}
