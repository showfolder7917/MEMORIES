/* 2026-10-29：只锁原考勤管理配置行，锁后状态由原策略复核，不跨库。 */
package com.sp.selplat.attendance.accessgrant.dao;

import com.sp.selplat.attendance.common.persistence.AttendanceBaseDao;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.util.CommonParam;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.ConnectionHolder;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/** 管理配置只在原可写业务事务内持锁；纯读不新建事务，不以查询结果发放提交许可。 */
@Repository
public class AttendanceAccessGrantDaoImpl extends AttendanceBaseDao
    implements AttendanceAccessGrantDao {
  /**
   * 方法作用：原MANAGER写入路径按唯一身份范围锁住实际配置，撤销先完成则重读失效事实。
   *
   * @param query 原服务限定查询，例如tenantId9/userId9102/roleCodeMANAGER/scopeCodeTENANT
   * @return 实际本表行例如id8001/status0，交原策略拒绝；无行null，不补建许可
   * @throws CommonBusinessException 本域写连接为自动提交、只读或旧快照时拒绝
   */
  @Override
  public Map<String, Object> findCurrentGrant(CommonParam query) {
    var source = getDataSourceContext().getDataSource();
    var target =
        source instanceof TransactionAwareDataSourceProxy proxy
            ? proxy.getTargetDataSource()
            : source;
    Object resource = TransactionSynchronizationManager.getResource(target);
    // 展示/独立审批读取合同不变；只有当前实际本域写事务承担持锁提交保护。
    if (!"MANAGER".equals(query.getParam("roleCode"))
        || !TransactionSynchronizationManager.isActualTransactionActive()
        || TransactionSynchronizationManager.isCurrentTransactionReadOnly()
        || !(resource instanceof ConnectionHolder holder)) {
      return super.getByQuery(query);
    }
    try {
      var connection = holder.getConnection();
      if (connection.getAutoCommit()
          || connection.isReadOnly()
          || connection.getTransactionIsolation() != Connection.TRANSACTION_READ_COMMITTED) {
        throw new CommonBusinessException(
            "ATTENDANCE_MANAGEMENT_TRANSACTION_INVALID", "考勤管理配置需要原本域可写读已提交事务。");
      }
    } catch (SQLException failure) {
      throw new CommonBusinessException(
          "ATTENDANCE_MANAGEMENT_TRANSACTION_INVALID", "考勤管理配置事务状态无法核验。", failure);
    }
    // 锁定位不以旧status筛掉行；等待撤销完成后取得原行，由服务按最新状态及到期时间拒绝。
    var rows =
        new JdbcTemplate(source)
            .queryForList(
                "SELECT * FROM AttendanceAccessGrant WHERE tenantId=? AND userId=?"
                    + " AND roleCode='MANAGER' AND scopeCode='TENANT' FOR UPDATE",
                query.getParam("tenantId"),
                query.getParam("userId"));
    return rows.isEmpty() ? null : rows.getFirst();
  }
}
