/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：独立月动作读取HTTP接入，原锁顺序与所有写保持。 */
/* 2026-11-01：月报原管理读取与导出HTTP接入，原写保护保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
/* 2026-11-01：本人月报HTTP纯读，原冻结/提交路径保持。 */
package com.sp.selplat.attendance.monthly.service;

import com.sp.selplat.common.service.BaseService;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** AttendanceMonthly 表级服务，缺已核验管理配置时拒绝数据读取和变更。 */
public interface AttendanceMonthlyService
    extends BaseService,
        com.sp.selplat.attendance.capability.accessconfiguration.service
            .AttendanceConfigurationReadAccess {

  /**
   * 内部业务能力按动态字段读取同租户启用记录，不修改配置或事实。
   *
   * @param criteria 受控字段，例如 employeeId=8801、workDate=2026-07-03
   * @return CommonResult.data 为匹配行或 null；缺管理配置时拒绝
   */
  CommonResult findScoped(CommonParam criteria);

  /**
   * 专用业务能力提交服务端校验/计算的快照；没有 HTTP 直接调用入口。
   *
   * @param input 服务端计算/接收字段，例如 employeeId=8801，不能直接转发客户端派生分钟
   * @return 实际号段及持久化结果 CommonResult 异常或副作用示例：拒绝受保护状态；真实本域事务写入该表，不直接访问其他表。
   */
  CommonResult storeCalculated(CommonParam input);

  /**
   * 重开同租户真实月次，保留工时，原因和操作员形成同事务审计。
   *
   * @param input 目标与原因，例如 id=100001、reason=核对补卡；请求操作员不参与授权
   * @return 例如 data.closeStatus=REOPENED、data.reopenedBy=8101；缺管理配置时拒绝
   *     异常或副作用示例：空白原因或目标不可访问时无写入；审计失败回滚状态。
   */
  CommonResult reopen(CommonParam input);

  /**
   * 专用计算能力刷新完日月事实后，整体预检并批量月结该真实范围。
   *
   * @param input 年月与范围，例如 yearMonth=2026-10、scopeType=EMPLOYEE、scopeId=8801
   * @return 例如 data={closedCount:1,blockedCount:0}；整批不存在返回0，不产生空日志
   *     异常或副作用示例：任一状态非CLOSABLE/REOPENED全部拒绝；状态和日志同事务批量保存。
   */
  CommonResult closeScope(CommonParam input);

  /**
   * 读取本人已发布并生效月快照或该快照指标，服务端固定归属和分页上限。
   *
   * @param input 分页筛选，例如 pageNo=1、pageSize=20；指标必须 monthlyId=9301
   * @return 真实 CommonPageResult，例如 records=[{id:9301}]、totalCount=1，无管理字段
   *     异常或副作用示例：缺精确许可或指标目标不归本人时拒绝，只读库。
   */
  com.sp.selplat.common.util.CommonPageResult ownedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 只读取已发布并生效的本人快照详情。
   *
   * @param input 目标主键，例如 id=9301；请求身份无效
   * @return CommonResult.data 例如 id=9301、yearMonth=2026-10、totalWorkMinutes=510
   *     异常或副作用示例：草稿、他人或异租户统一拒绝，无写入。
   */
  CommonResult getOwned(CommonParam input);

  /**
   * 既有日次/审批能力锁真实员工后检查所属月可变性，无HTTP授权扩张。
   *
   * @param input 真实employeeId=8801以及workDate=2026-09-10或yearMonth=2026-09
   *     异常或副作用示例：CLOSED/有效发布抛ATTENDANCE_PERIOD_PROTECTED，要求正式重开；没有改月状态。
   */
  void requireMutablePeriod(CommonParam input);

  /**
   * 管理关联能力取得锁中的保护月份，不授予本人月管理读取。
   *
   * @param input 实际employeeId=8801，租户由管理身份覆盖
   * @return 实际保护月列表例如data=[{yearMonth:2026-09}]，不存在为空 异常或副作用示例：缺管理许可拒绝；持有员工/月行锁直到关联事务结束，无写入。
   */
  CommonResult protectedPeriods(CommonParam input);

  /**
   * 独立月动作所属行锁。
   *
   * @param input 实际id/actionCode例如9301/PUBLISH
   * @return 当前真实月行，等待后角色/归属重验，缺权限拒绝
   */
  CommonResult lockForRelease(CommonParam input);

  /**
   * 同事务维护旧只读投影标识。
   *
   * @param input 内部id/actionCode例如9301/PUBLISH
   * @return 真实更新月行，不改变结果分钟/来源，失败回滚
   */
  CommonResult markRelease(CommonParam input);

  /**
   * 独立月角色列表。
   *
   * @param input 分页及内部actionCode例如PUBLISH
   * @return 所属DAO真实本租户列表，不授予管理权限
   */
  com.sp.selplat.common.util.CommonPageResult releaseStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：原本人月报纯读，交付前重核真实身份与精确许可
   *
   * @param input 原分页或月主键，例如id9601/monthlyId9601
   * @return 原完整CommonPageResult，例如records含本人冻结指标
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  com.sp.selplat.common.util.CommonPageResult readOwnedStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：原本人月报纯读，交付前重核真实身份与精确许可
   *
   * @param input 原分页或月主键，例如id9601/monthlyId9601
   * @return 原CommonResult，例如totalWorkMinutes525
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原归属/精确许可/发布事实失效拒绝，无写入
   */
  com.sp.selplat.common.util.CommonResult readOwned(com.sp.selplat.common.util.CommonParam input);

  /**
   * 方法作用：原独立月动作来源读取，保留原完整范围及分页
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonPageResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonPageResult readReleaseStore(
      com.sp.selplat.common.util.CommonPageParam input);

  /**
   * 方法作用：原独立月动作来源读锁，保留员工与所属月份互斥
   *
   * @param input 内部实际主键/月和动作，例如monthlyId61000/actionCodePREPARE_REVIEW
   * @return 原CommonResult，不授予管理或任何写
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原独立动作/身份/来源失效拒绝，无业务写入
   */
  com.sp.selplat.common.util.CommonResult readLockForRelease(
      com.sp.selplat.common.util.CommonParam input);
}
