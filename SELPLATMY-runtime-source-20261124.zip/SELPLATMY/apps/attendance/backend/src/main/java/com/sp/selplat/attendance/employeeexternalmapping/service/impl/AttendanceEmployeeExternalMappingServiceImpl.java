/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：案件审计及外部映射原管理读取HTTP接入，原写保护保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.employeeexternalmapping.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.common.util.punchimport.AttendanceCsvImportValues;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.employeeexternalmapping.dao.AttendanceEmployeeExternalMappingDao;
import com.sp.selplat.attendance.employeeexternalmapping.service.AttendanceEmployeeExternalMappingService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceEmployeeExternalMapping 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceEmployeeExternalMappingServiceImpl
    extends BaseServiceImpl<AttendanceEmployeeExternalMappingDao>
    implements AttendanceEmployeeExternalMappingService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @return 实际管理身份，例如 userId=8101、tenantId=81；不创建授权
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @param mutation 是否来自专用写入前校验，例如 true；不替代租户条件
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 本表只能通过核准映射、来源登记或 CSV 批次专用流程写入；通用 CRUD 不放行。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用方抛出后无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用对应打卡、计算或审批流程。");
  }

  // 外部员工 ID 只映射考勤员工，不调用登录绑定或授权表。
  @Autowired private AttendanceEmployeeService employees;

  // 同来源行锁与 CSV 导入共用，通过其表 Service 获取，不持有跨表 DAO。
  @Autowired
  private com.sp.selplat.attendance.punchsourceconfig.service.AttendancePunchSourceConfigService
      sources;

  /**
   * 登记待核准的精确来源映射，允许保留冲突供人工核查而不自动取舍。
   *
   * @param input 例如 employeeId=8801、sourceSystem=CSV_A、externalEmployeeId=X1
   * @return 真实新增结果，例如 data.id=100001、configurationStatus=PENDING 异常或副作用示例：异租户员工或空键拒绝；仅写映射表，不绑定账号。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult register(CommonParam input) {
    requireManagement();
    CommonParam row = new CommonParam();
    try {
      long employeeId =
          new BigDecimal(String.valueOf(input.getParam("employeeId"))).longValueExact();
      if (employeeId <= 0) {
        throw new IllegalArgumentException();
      }
      row.putParam("employeeId", employeeId);
      row.putParam(
          "sourceSystem", AttendanceCsvImportValues.key(input.getParam("sourceSystem"), 50));
      row.putParam(
          "externalEmployeeId",
          AttendanceCsvImportValues.key(input.getParam("externalEmployeeId"), 100));
      if (input.getParam("externalEmployeeNo") != null) {
        row.putParam(
            "externalEmployeeNo",
            AttendanceCsvImportValues.key(input.getParam("externalEmployeeNo"), 100));
      }
    } catch (IllegalArgumentException | ArithmeticException invalid) {
      throw new CommonBusinessException("ATTENDANCE_MAPPING_INVALID", "员工或精确来源映射键无效。");
    }
    sources.lockSource(String.valueOf(row.getParam("sourceSystem")));
    CommonParam employee = new CommonParam();
    employee.putParam("id", row.getParam("employeeId"));
    employees.getById(employee);
    row.putParam("configurationStatus", "PENDING");
    row.putParam("mappingStatus", "ACTIVE");
    row.putParam("status", 1);
    return super.insert(row);
  }

  /**
   * 管理人员明确核准唯一来源键；重复键即使员工相同也不自动合并。
   *
   * @param input 真实映射主键，例如 id=100001；tenantId 和核准人只取当前会话
   * @return 实际核准结果，例如 data.configurationStatus=VERIFIED、verifiedBy=8101 异常或副作用示例：同键有两条启用映射抛
   *     ATTENDANCE_MAPPING_CONFLICT；事务不核准任一条。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult verify(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    CommonParam id = new CommonParam();
    id.putParam("id", input.getParam("id"));
    id.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> existing = getDao().getById(id);
    if (existing != null) {
      sources.lockSource(String.valueOf(existing.get("sourceSystem")));
      // READ_COMMITTED 的实际 JDBC 查询在行锁等待后重读，不复用等待前行状态。
      existing = getDao().getById(id);
    }
    if (existing == null || !"ACTIVE".equals(existing.get("mappingStatus"))) {
      throw new CommonBusinessException("ATTENDANCE_MAPPING_INVALID", "映射不存在或未启用。");
    }
    CommonParam key = new CommonParam();
    key.putParam("sourceSystem", existing.get("sourceSystem"));
    key.putParam("externalEmployeeId", existing.get("externalEmployeeId"));
    if (matching(key).getTotalCount() != 1) {
      throw new CommonBusinessException("ATTENDANCE_MAPPING_CONFLICT", "来源映射键存在冲突，请先核查。");
    }
    CommonParam employee = new CommonParam();
    employee.putParam("id", existing.get("employeeId"));
    employees.getById(employee);
    CommonParam update = new CommonParam();
    update.putParam("id", existing.get("id"));
    update.putParam("configurationStatus", "VERIFIED");
    update.putParam("verifiedBy", identity.get("userId"));
    update.putParam("verifiedAt", LocalDateTime.now());
    return super.update(update);
  }

  /**
   * 解析当前租户精确来源的单一核准映射；从不跨来源回退。
   *
   * @param input 例如 sourceSystem=CSV_A、externalEmployeeId=X1；不使用请求租户
   * @return CommonResult.data，例如 {resolution:RESOLVED,employeeId:8801}；冲突返回
   *     {resolution:CONFLICT,matchCount:2} 异常或副作用示例：无匹配/未核准返回 UNMATCHED；只查映射和员工，无账号写入。
   */
  @Override
  public CommonResult resolve(CommonParam input) {
    requireManagement();
    CommonPageResult page = matching(input);
    Map<String, Object> result = new java.util.LinkedHashMap<>();
    result.put("matchCount", page.getTotalCount());
    if (page.getTotalCount() > 1) {
      result.put("resolution", "CONFLICT");
    } else if (page.getTotalCount() == 0
        || !"VERIFIED".equals(page.getRecords().getFirst().get("configurationStatus"))
        || !"ACTIVE".equals(page.getRecords().getFirst().get("mappingStatus"))) {
      result.put("resolution", "UNMATCHED");
    } else {
      Map<String, Object> mapping = page.getRecords().getFirst();
      CommonParam employee = new CommonParam();
      employee.putParam("id", mapping.get("employeeId"));
      // 员工已停用或无权访问时隔离该行，不用其他来源映射代替。
      try {
        employees.getById(employee);
        result.put("resolution", "RESOLVED");
        result.put("employeeId", mapping.get("employeeId"));
      } catch (CommonBusinessException unavailable) {
        result.put("resolution", "UNMATCHED");
      }
    }
    return buildSuccessResult(result, "精确来源映射已核查。");
  }

  /**
   * 按同一租户、来源、外部员工键读取所有启用行计数，避免 getByQuery 任取第一条。
   *
   * @param input 精确来源键，例如 CSV_A/X1
   * @return 真实分页结果，例如 totalCount=2；最多读取两条即可报告冲突 异常或副作用示例：键无效拒绝，仅读本表。
   */
  private CommonPageResult matching(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("status", 1);
    query.put("sourceSystem", AttendanceCsvImportValues.key(input.getParam("sourceSystem"), 50));
    query.put(
        "externalEmployeeId",
        AttendanceCsvImportValues.key(input.getParam("externalEmployeeId"), 100));
    return getDao().getPageList(query, 1, 2);
  }

  /**
   * 明确撤销一条映射，保留原核准信息和撤销人，不调整旧打卡、账号或工时。
   *
   * @param input 真实映射主键，例如 id=100001；身份来自当前管理会话
   * @return 实际结果，例如 configurationStatus=REVOKED、mappingStatus=INACTIVE、status=0
   *     异常或副作用示例：异租户或已撤销记录拒绝；本表更新与审计日志归当前操作员。
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult revoke(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    CommonParam row = new CommonParam();
    row.putParam("id", input.getParam("id"));
    row.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> existing = getDao().getById(row);
    if (existing == null) {
      throw new CommonBusinessException("ATTENDANCE_MAPPING_INVALID", "映射不存在或已撤销。");
    }
    sources.lockSource(String.valueOf(existing.get("sourceSystem")));
    requireRecord(row, true);
    row.putParam("configurationStatus", "REVOKED");
    row.putParam("mappingStatus", "INACTIVE");
    row.putParam("status", 0);
    row.putParam("revokedBy", identity.get("userId"));
    row.putParam("revokedAt", LocalDateTime.now());
    return super.update(row);
  }

  /**
   * 方法作用：共用原外部员工映射完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonPageResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原外部员工映射完整过滤与返回，固定同值分页次序
   *
   * @param input 原分页或主键，例如id61000
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原CommonResult，完整字段/总数保持，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/归属失效沿原拒绝，无写入
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原外部员工映射完整详情和租户过滤，不重算或修改快照。
   *
   * @param input 原主键，例如id61000
   * @return 原CommonResult，例如data.id61000及原完整字段
   * @throws CommonBusinessException 异校、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：按原系统查看门槛读取外部员工映射表头，不授予管理或计算许可。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns原字段配置
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "案件映射读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
