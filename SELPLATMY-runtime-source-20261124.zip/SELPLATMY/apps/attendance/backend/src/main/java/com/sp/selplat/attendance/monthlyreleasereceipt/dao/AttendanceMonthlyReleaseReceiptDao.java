package com.sp.selplat.attendance.monthlyreleasereceipt.dao;

import com.sp.selplat.common.db.dao.BaseDao;

/** AttendanceMonthlyReleaseReceipt仅拥有本表，租户复合关联交由真实约束保证。 */
public interface AttendanceMonthlyReleaseReceiptDao extends BaseDao { }
