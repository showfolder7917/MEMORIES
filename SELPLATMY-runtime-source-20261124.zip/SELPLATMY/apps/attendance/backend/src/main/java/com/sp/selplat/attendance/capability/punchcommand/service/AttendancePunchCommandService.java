package com.sp.selplat.attendance.capability.punchcommand.service;

import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;

/** 管理员补录原始打卡事实；自助异常补卡仍需要独立审批流程。 */
public interface AttendancePunchCommandService {
    /**
     * 管理人员按精确来源和幂等键导入 CSV，不调用外部打卡连接。
     *
     * @param input sourceSystem、importKey、csvText、可选 fileName；不接受租户/员工/处理状态
     * @return 本次真实批次与行结果 JSON；同键同摘要复用持久化结果，异摘要拒绝 异常或副作用示例：系统持久化失败回滚整批；未匹配/冲突不产生可计算员工事实。
     */
    CommonResult importCsv(CommonParam input);

    /**
     * 核验员工归属后补录，只保存事实，不计算工资和日次分钟。
     *
     * @param input employeeId、punchTime、punchType、note；不采纳客户端身份与处理状态
     * @return 实际共享号段主键与保存结果；缺管理配置或类型无效时拒绝，无部分写入
     */
    CommonResult receiveManual(CommonParam input);
}
