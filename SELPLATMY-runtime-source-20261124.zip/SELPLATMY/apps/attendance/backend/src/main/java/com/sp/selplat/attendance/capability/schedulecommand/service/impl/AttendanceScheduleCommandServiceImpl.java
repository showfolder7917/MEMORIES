package com.sp.selplat.attendance.capability.schedulecommand.service.impl;

import com.sp.selplat.attendance.capability.schedulecommand.service.AttendanceScheduleCommandService;
import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.employee.service.AttendanceEmployeeService;
import com.sp.selplat.attendance.shifttemplate.service.AttendanceShiftTemplateService;
import com.sp.selplat.attendance.shiftschedule.service.AttendanceShiftScheduleService;
import com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleRuntime;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 沿用旧单日排班展开规则，只通过所属表服务读写，身份始终来自真实会话。 */
@Service
public class AttendanceScheduleCommandServiceImpl implements AttendanceScheduleCommandService {
    private final AttendanceAuthorizationService authorization;
    private final AttendanceEmployeeService employees;
    private final AttendanceShiftTemplateService templates;
    private final AttendanceShiftScheduleService schedules;
    // 批提交回执只经所属服务保存，能力不跨表DAO。
    private final com.sp.selplat.attendance.schedulebatch.service.AttendanceScheduleBatchService
            batches;

    /**
     * 装配本域服务，不注入其他表 DAO。
     *
     * @param authorization 已核验配置服务，缺配置拒绝
     * @param employees 员工所属服务
     * @param templates 模板所属服务
     * @param batches 成功回执所属服务，例如精确requestKey查询；构造不读库
     * @param schedules 排班所属服务；构造不读写数据库
     */
    public AttendanceScheduleCommandServiceImpl(
            AttendanceAuthorizationService authorization,
            AttendanceEmployeeService employees,
            AttendanceShiftTemplateService templates,
            AttendanceShiftScheduleService schedules,
            com.sp.selplat.attendance.schedulebatch.service.AttendanceScheduleBatchService
                    batches) {
        this.authorization = authorization;
        this.employees = employees;
        this.templates = templates;
        this.schedules = schedules;
        this.batches = batches;
    }

    /**
     * 沿用旧模板展开规则保存同员工同日排班，不接受客户端展开时间。
     *
     * @param input 业务参数，例如 employeeId=8801、shiftTemplateId=8901、workDate=2026-10-03
     * @return 真实 CommonResult，例如 data.id=100001、data.scheduledBreakMinutes=60
     *     异常或副作用示例：例如锁定排班或异租户员工拒绝；由本域事务原位替换已有排班。
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult save(CommonParam input) {
        Map<String, Long> identity = authorization.requireManagement();
        long employeeId = requirePositiveId(input.getParam("employeeId"));
        long templateId = requirePositiveId(input.getParam("shiftTemplateId"));
        LocalDate date;
        try {
            date = LocalDate.parse(String.valueOf(input.getParam("workDate")));
        } catch (RuntimeException invalidDate) {
            throw invalidScheduleInput();
        }
        employees.lockForSchedule(parameterWithField("id", employeeId));
        CommonParam templateLookup = parameterWithField("id", templateId);
        templateLookup.putParam("workDate", date);
        // 锁定真实当前版本与生效边界，引用保护和排班写入同事务，失败一起回滚。
        Map<String, Object> template = readResultRow(templates.lockForSchedule(templateLookup));
        if (!(template.get("isActive") instanceof Number active) || active.intValue() != 1) {
            throw new CommonBusinessException("ATTENDANCE_TEMPLATE_INACTIVE", "班次模板已停用。");
        }
        CommonParam lookup = parameterWithField("employeeId", employeeId);
        lookup.putParam("workDate", date);
        CommonResult existing = schedules.findScoped(lookup);
        CommonParam stored = new CommonParam();
        try {
            stored.setParamMap(
                    AttendanceScheduleRuntime.expand(
                            date,
                            template,
                            input.getParam("remark") == null
                                    ? null
                                    : input.getParam("remark").toString()));
        } catch (RuntimeException invalidTemplate) {
            throw new CommonBusinessException("ATTENDANCE_TEMPLATE_INVALID", "班次模板时间格式无效。");
        }
        if (existing.getData() instanceof Map<?, ?> old) {
            stored.putParam("id", old.get("id"));
        }
        stored.putParam("employeeId", employeeId);
        stored.putParam("shiftTemplateId", templateId);
        stored.putParam("workDate", date);
        stored.putParam("businessStatus", "ACTIVE");
        stored.putParam("updatedBy", identity.get("userId"));
        if (stored.getParam("id") == null) {
            stored.putParam("createdBy", identity.get("userId"));
            stored.putParam("locked", 0);
        }
        schedules.storeScheduled(stored);
        return schedules.findScoped(lookup);
    }

    /**
     * 只读逐行真实计划与冲突，不创建回执、引用标记或授权令牌。
     *
     * @param input 完整批请求例如requestKey=BATCH-001/items含employeeId=8801/workDate=2026-10-10
     * @return
     *     CommonResult.data数组例如[{employeeId:8801,workDate:"2026-10-10",conflictCode:"",scheduledBreakMinutes:60}]；affectedRows=0
     * @throws CommonBusinessException 无管理许可或整体输入重复/非法拒绝；逐行资源错误安全展示，无业务写入
     */
    @Override
    public CommonResult previewBatch(CommonParam input) {
        authorization.requireManagement();
        var items =
                com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues.items(
                        input);
        var plans = new java.util.ArrayList<Map<String, Object>>();
        for (var item : items) {
            var plan = new LinkedHashMap<String, Object>(item);
            plan.put("conflictCode", "");
            plan.put("conflictMessage", "");
            try {
                // 每项真实权限、员工、模板/日期及保留排班冲突重查；不使用客户端展开字段。
                authorization.requireManagement();
                var employee =
                        readResultRow(
                                employees.getById(
                                        parameterWithField("id", item.get("employeeId"))));
                var template =
                        readResultRow(
                                templates.getById(
                                        parameterWithField("id", item.get("shiftTemplateId"))));
                com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                        .validateTemplate(item, template);
                plan.put("employeeName", employee.get("employeeName"));
                plan.put("templateName", template.get("templateName"));
                plan.putAll(
                        AttendanceScheduleRuntime.expand(
                                LocalDate.parse(item.get("workDate").toString()),
                                template,
                                item.get("remark").toString()));
                var criteria = parameterWithField("employeeId", item.get("employeeId"));
                criteria.putParam("workDate", item.get("workDate"));
                criteria.putParam("scheduledStartTime", plan.get("scheduledStartTime"));
                criteria.putParam("scheduledEndTime", plan.get("scheduledEndTime"));
                if (schedules.findRetained(criteria).getData() != null) {
                    throw batchConflict();
                }
            } catch (CommonBusinessException conflict) {
                // 逐行仅返回稳定安全业务错误，无越权员工名或其他租户事实。
                plan.put("conflictCode", conflict.getErrorCode());
                plan.put("conflictMessage", conflict.getMessage());
            }
            plans.add(plan);
        }
        var overlaps =
                com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                        .intervalConflicts(plans);
        for (var plan : plans) {
            if (overlaps.contains(plan.get("employeeId") + "/" + plan.get("workDate"))) {
                plan.put("conflictCode", "ATTENDANCE_BATCH_CONFLICT");
                plan.put("conflictMessage", batchConflict().getMessage());
            }
        }
        return batchResult(plans, 0, "批量排班预览完成，确认时将重新核验。");
    }

    /**
     * 完整重验、真实锁串行及公共JDBC batch，尾回执与计划同事务提交。
     *
     * @param input 完整确认请求例如requestKey=BATCH-001/items含templateRevision=0；预览非凭证
     * @return 实际CommonResult.data持久化行数组/affectedRows=2；同键重试返回原回执且affectedRows=0
     * @throws CommonBusinessException 任一冲突/异负载同键/锁后撤权拒绝整批，末尾SQL失败全部回滚
     */
    @Override
    @OperationLog
    @Transactional(
            transactionManager = "attendanceTransactionManager",
            isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public CommonResult commitBatch(CommonParam input) {
        var identity = authorization.requireManagement();
        var items =
                com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues.items(
                        input);
        var fingerprint =
                com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                        .fingerprint(items);
        // 员工先数值升序锁，覆盖无排班行的日期；同键同负载与重叠不同键必在同员工锁串行。
        var employeeIds = new java.util.TreeSet<Long>();
        var templateIds = new java.util.TreeSet<Long>();
        for (var item : items) {
            employeeIds.add((Long) item.get("employeeId"));
            templateIds.add((Long) item.get("shiftTemplateId"));
        }
        for (long employee : employeeIds) {
            employees.lockForSchedule(parameterWithField("id", employee));
        }
        var currentTemplates = new LinkedHashMap<Long, Map<String, Object>>();
        for (long id : templateIds) {
            var lookup = parameterWithField("id", id);
            var first =
                    items.stream()
                            .filter(item -> item.get("shiftTemplateId").equals(id))
                            .findFirst()
                            .orElseThrow();
            lookup.putParam("workDate", first.get("workDate"));
            currentTemplates.put(id, readResultRow(templates.lockForSchedule(lookup)));
        }
        // 所有等待完成后每人每日期再次重验权限与版本/生效日；管理范围仍为现有TENANT，未增加许可。
        for (var item : items) {
            authorization.requireManagement();
            employees.lockForSchedule(parameterWithField("id", item.get("employeeId")));
            com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                    .validateTemplate(
                            item, currentTemplates.get((Long) item.get("shiftTemplateId")));
        }
        CommonParam key = parameterWithField("requestKey", input.getParam("requestKey"));
        var receipt = batches.findReceipt(key);
        if (receipt.getData() != null) {
            var old =
                    com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                            .row(receipt);
            if (!fingerprint.equals(old.get("fingerprint"))) {
                throw new CommonBusinessException(
                        "ATTENDANCE_BATCH_KEY_REUSED", "请求键已用于不同排班内容，请返回修改并重新预览。");
            }
            var saved =
                    com.sp.selplat.common.util.JsonUtils.fromJson(
                            old.get("resultJson").toString(), java.util.List.class);
            return batchResult(saved, 0, "批量排班已提交，本次返回原成功回执。");
        }
        var batch = new com.sp.selplat.common.util.CommonBatchParam();
        var writes = new java.util.ArrayList<CommonParam>();
        for (var item : items) {
            var row = new CommonParam();
            row.setParamMap(
                    AttendanceScheduleRuntime.expand(
                            LocalDate.parse(item.get("workDate").toString()),
                            currentTemplates.get((Long) item.get("shiftTemplateId")),
                            item.get("remark").toString()));
            for (String field : java.util.List.of("employeeId", "workDate", "shiftTemplateId")) {
                row.putParam(field, item.get(field));
            }
            row.putParam("businessStatus", "ACTIVE");
            row.putParam("locked", 0);
            row.putParam("createdBy", identity.get("userId"));
            row.putParam("updatedBy", identity.get("userId"));
            var query = parameterWithField("employeeId", item.get("employeeId"));
            query.putParam("workDate", item.get("workDate"));
            query.putParam("scheduledStartTime", row.getParam("scheduledStartTime"));
            query.putParam("scheduledEndTime", row.getParam("scheduledEndTime"));
            if (schedules.findRetained(query).getData() != null) {
                throw batchConflict();
            }
            writes.add(row);
        }
        if (!com.sp.selplat.attendance.common.util.schedule.AttendanceScheduleBatchValues
                .intervalConflicts(writes.stream().map(CommonParam::getParamMap).toList())
                .isEmpty()) {
            throw batchConflict();
        }
        batch.setItems(writes);
        CommonResult written = schedules.storeScheduledBatch(batch);
        var audit = parameterWithField("requestKey", input.getParam("requestKey"));
        audit.putParam("fingerprint", fingerprint);
        audit.putParam("rowCount", items.size());
        audit.putParam(
                "resultJson",
                com.sp.selplat.common.util.JsonUtils.toJsonIgnoreNull(written.getData()));
        // 最后一笔成功尾审计也在外层事务；异常传播不得只留下已写排班。
        try {
            batches.storeReceipt(audit);
        } catch (org.springframework.dao.DuplicateKeyException duplicate) {
            throw new CommonBusinessException(
                    "ATTENDANCE_BATCH_KEY_REUSED", "请求键已用于不同排班内容，请返回修改并重新预览。");
        }
        return written;
    }

    /**
     * 服务拥有标准结果，不引入应用私有协议。
     *
     * @param rows 实际预览或回执数组例如employeeId=8801
     * @param affected 本次真实写入数例如0
     * @param message 业务结果例如批量排班预览完成
     * @return CommonResult.data数组/affectedRows=0/success=true，无持久化副作用
     */
    private static CommonResult batchResult(Object rows, int affected, String message) {
        var result = new CommonResult();
        result.setSuccess(true);
        result.setData(rows);
        result.setAffectedRows(affected);
        result.setMsg(message);
        return result;
    }

    /**
     * @return 当前保留排班冲突错误，不泄露其他租户资源，无业务写入。
     */
    private static CommonBusinessException batchConflict() {
        return new CommonBusinessException("ATTENDANCE_BATCH_CONFLICT", "批量排班存在冲突，请重新预览并修改。");
    }

    /**
     * @param value 请求主键例如 8801；
     * @return 正整数；无效值拒绝，无数据副作用。
     */
    private static long requirePositiveId(Object value) {
        try {
            long requirePositiveId = new BigDecimal(String.valueOf(value)).longValueExact();
            if (requirePositiveId > 0) {
                return requirePositiveId;
            }
        } catch (RuntimeException invalidId) {
            /* 统一参数错误，不回落到固定员工。 */
        }
        throw invalidScheduleInput();
    }

    /**
     * @param key 受控字段例如 id；
     * @param value 正主键；
     * @return 新参数容器，不复制请求身份。
     */
    private static CommonParam parameterWithField(String key, Object value) {
        CommonParam input = new CommonParam();
        input.putParam(key, value);
        return input;
    }

    /**
     * @param result 表服务真实结果；
     * @return 字符串字段映射；不存在时拒绝，不产生数据写入。
     */
    private static Map<String, Object> readResultRow(CommonResult result) {
        if (!result.isSuccess() || !(result.getData() instanceof Map<?, ?> source)) {
            throw invalidScheduleInput();
        }
        Map<String, Object> readResultRow = new LinkedHashMap<>();
        source.forEach((key, value) -> readResultRow.put(String.valueOf(key), value));
        return readResultRow;
    }

    /**
     * @return 统一业务参数错误，不携带其他租户信息。
     */
    private static CommonBusinessException invalidScheduleInput() {
        return new CommonBusinessException(
                "ATTENDANCE_SCHEDULE_INPUT_INVALID", "员工、班次模板及工作日期必须有效。");
    }
}
