/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：审批来源纯读接入，原保存/审批来源保护保持。 */
/* 2026-11-01：本人日次纯读前后核原绑定，管理/写与原桥接保持。 */
/* 2026-11-01：原日次结果管理纯读接入，原专用写与本人入口保持。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.daily.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.daily.dao.AttendanceDailyDao;
import com.sp.selplat.attendance.daily.service.AttendanceDailyService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceDaily 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceDailyServiceImpl extends BaseServiceImpl<AttendanceDailyDao>
    implements AttendanceDailyService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  @Autowired
  private com.sp.selplat.attendance.monthly.service.AttendanceMonthlyService monthlyPeriods;

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement());
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult insert(CommonParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insertBatch(CommonBatchParam input) {
    requireManagement();
    throw directMutationRejected();
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, true);
    throw directMutationRejected();
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    throw directMutationRejected();
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 原始卡和派生快照通过本域专用流程写入，不能以通用 CRUD 修改工资/工时事实。
   *
   * @return 固定拒绝异常，例如ATTENDANCE_DEDICATED_WRITE_REQUIRED；调用方抛出后无持久化写入
   */
  private CommonBusinessException directMutationRejected() {
    return new CommonBusinessException("ATTENDANCE_DEDICATED_WRITE_REQUIRED", "请使用对应打卡、计算或审批流程。");
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceDaily 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 从真实算法产物按本表元数据生成初算快照，不写审批 final 字段。
   *
   * @param input 内部计算能力传入的 calculationResult、employeeId=8801、workDate=2026-10-03 与可选 id
   * @return 实际 CommonResult，例如 success=true、data.id=100001、data.tenantId=81；新增主键来自共享号段
   *     异常或副作用示例：缺管理配置或受保护状态时拒绝；例如已锁定记录不更新。本方法写入本域具名事务。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult storeCalculated(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    monthlyPeriods.requireMutablePeriod(input);
    if (!(input.getParam("calculationResult") instanceof Map<?, ?> calculated)) {
      throw new CommonBusinessException("ATTENDANCE_CALCULATION_REQUIRED", "必须由日次算法生成快照。");
    }
    Map<String, Object> result = new java.util.LinkedHashMap<>();
    calculated.forEach((key, value) -> result.put(String.valueOf(key), value));
    Object oldId = input.getParam("id");
    long employeeId =
        new java.math.BigDecimal(String.valueOf(input.getParam("employeeId"))).longValueExact();
    java.time.LocalDate date =
        java.time.LocalDate.parse(String.valueOf(input.getParam("workDate")));
    input.setParamMap(
        com.sp.selplat.attendance.common.util.calculation.AttendanceCalculationSnapshotMapper
            .dailyForStorage(result, date, employeeId, getDao().getDbColumnsMap().keySet()));
    if (oldId != null) {
      input.putParam("id", oldId);
    }
    input.putParam("approvalStatus", "NONE");
    input.putParam(
        "handlingStatus",
        Boolean.TRUE.equals(result.get("exceptionFlag")) ? "UNHANDLED" : "RESOLVED");
    input.putParam("locked", 0);
    input.putParam("calculatedAt", java.time.LocalDateTime.now());
    input.putParam("updatedAt", java.time.LocalDateTime.now());
    input.putParam("calcVersion", "phase7-v1");
    input.putParam("tenantId", identity.get("tenantId"));
    if (input.getParam("id") == null) {
      return super.insert(input);
    }
    requireRecord(input, true);
    Map<String, Object> current = getDao().getById(input);
    if (com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules
        .isDailyRecalculationProtected(current)) {
      throw new CommonBusinessException("ATTENDANCE_DAILY_PROTECTED", "审批中或已锁定日次不能重算。");
    }
    return super.update(input);
  }

  /**
   * 按真实员工映射读取本人资源。
   *
   * @param input 本域能力传入的资源主键，例如 id=100001；请求租户和员工字段不能授予权限
   * @return 真实 CommonResult，例如 success=true、data.id=100001、data.tenantId=81
   *     异常或副作用示例：缺已核验员工映射或异员工时拒绝；不要求或授予审批配置，仅真实本表查询，无写入。
   */
  @Override
  public CommonResult getOwned(CommonParam input) {
    return loadOwned(input, authorization.requireEmployeeBinding());
  }

  /**
   * 按独立已核验 APPROVER/TENANT 配置读取审批范围资源，不提升为管理角色。
   *
   * @param input 本域能力传入的资源主键，例如 id=100001；请求租户和员工字段不能授予权限
   * @return 真实 CommonResult，例如 success=true、data.id=100001、data.tenantId=81
   *     异常或副作用示例：例如缺员工映射、缺审批配置或异员工时拒绝；仅真实本表查询，无写入。
   */
  @Override
  public CommonResult getForApproval(CommonParam input) {
    return loadApprovalSource(input, authorization.requireApproval());
  }

  /**
   * 沿用旧案件提交/退回/驳回状态回写，不改工资、最终时间或锁定事实。
   *
   * @param input 案件所属服务的事实，例如id=100001、action=SUBMIT；不直接转发HTTP字段
   * @return 实际日次结果，例如data.approvalStatus=SUBMITTED、data.handlingStatus=IN_REVIEW
   *     异常或副作用示例：身份、本人绑定或租户不符拒绝；真实本域事务原子更新。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult applyCaseState(CommonParam input) {
    String action = String.valueOf(input.getParam("action"));
    Map<String, Long> identity;
    boolean owned = false;
    if ("SUBMIT".equals(action)) {
      try {
        identity = authorization.requireManagement();
      } catch (CommonBusinessException noManagement) {
        if (!"ATTENDANCE_MANAGEMENT_UNAVAILABLE".equals(noManagement.getErrorCode())) {
          throw noManagement;
        }
        identity = authorization.requireEmployeeBinding();
        owned = true;
      }
    } else {
      identity = authorization.requireApproval();
    }
    Map<String, String> state =
        com.sp.selplat.attendance.common.util.workflow.AttendanceWorkflowRules.caseOutcome(action);
    if (!java.util.Set.of("SUBMIT", "RETURN", "REJECT").contains(action)) {
      throw new CommonBusinessException("ATTENDANCE_CASE_ACTION_INVALID", "此入口不保存审批分钟。");
    }
    CommonParam changed = new CommonParam();
    changed.putParam("id", input.getParam("id"));
    changed.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> row = getDao().getById(changed);
    if (row == null
        || (owned
            && (!(row.get("employeeId") instanceof Number employee)
                || employee.longValue() != identity.get("employeeId")))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    requireMutableDaily(row);
    changed.putParam("approvalStatus", state.get("approvalStatus"));
    changed.putParam("handlingStatus", state.get("handlingStatus"));
    changed.putParam("updatedAt", java.time.LocalDateTime.now());
    super.update(changed);
    return buildSuccessResult(getDao().getById(changed), "日次案件状态已保存。");
  }

  /**
   * 白名单保存审批重算产物，原始卡时间和原始扣休仍作为历史事实保留。
   *
   * @param input 案件服务构造的算法和补丁，例如id=100001、finalStatus=NORMAL、actualWorkMinutes=525
   * @return 真实日次，例如data.actualClockOut保持18:37、data.finalClockOut=18:45、data.actualWorkMinutes=525
   *     异常或副作用示例：缺APPROVER配置、案件主键、实际日次时拒绝；随案件和日志同事务回滚。
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult storeApproved(CommonParam input) {
    Map<String, Long> identity = authorization.requireApproval();
    CommonParam changed = new CommonParam();
    changed.putParam("id", input.getParam("id"));
    changed.putParam("tenantId", identity.get("tenantId"));
    requireRecord(changed, true);
    requireMutableDaily(getDao().getById(changed));
    if (input.getParam("approvedCaseId") == null || input.getParam("actualWorkMinutes") == null) {
      throw new CommonBusinessException("ATTENDANCE_CALCULATION_REQUIRED", "审批必须包含真实案件及重算分钟。");
    }
    for (String field :
        java.util.List.of(
            "finalClockIn",
            "finalClockOut",
            "finalBreakMinutes",
            "finalStatus",
            "finalRemark",
            "approvedCaseId",
            "actualWorkMinutes",
            "lateMinutes",
            "earlyLeaveMinutes",
            "normalWorkMinutes",
            "overtimeMinutes",
            "legalOvertimeMinutes",
            "nightWorkMinutes",
            "holidayWorkMinutes",
            "holidayType",
            "appliedRuleId",
            "exceptionFlag",
            "calcMessage")) {
      changed.putParam(field, input.getParam(field));
    }
    changed.putParam("businessStatus", input.getParam("finalStatus"));
    changed.putParam("approvalStatus", "APPROVED");
    changed.putParam("handlingStatus", "RESOLVED");
    changed.putParam("calcVersion", "phase7-v1");
    changed.putParam("updatedAt", java.time.LocalDateTime.now());
    super.update(changed);
    return buildSuccessResult(getDao().getById(changed), "审批最终日次已保存。");
  }

  /**
   * 本人查询只采用分页和本表业务筛选，重新覆盖会话租户/绑定员工，禁止请求放大范围。
   *
   * @param input 例如pageNo=1、pageSize=20、workDate=2026-10-04
   * @return 真实CommonPageResult，例如records=[{id:100001,employeeId:8801}]、totalCount=1
   *     异常或副作用示例：绑定未核验或过期时拒绝，只读本表，不计算工时或提升权限。
   */
  @Override
  public CommonPageResult ownedStore(CommonPageParam input) {
    return loadOwnedStore(input, authorization.requireEmployeeBinding());
  }

  /**
   * 实时核验管理身份并查询本表保留的引用。
   *
   * @param input 所属规则服务传入主键例如 id=8501
   * @return 实际引用数例如1；无数据写入，缺可信许可拒绝
   */
  @Override
  public long countRuleReferences(CommonParam input) {
    // 其他表服务只能经公开契约访问；真实租户覆盖客户端范围。
    input.putParam("tenantId", requireManagement().get("tenantId"));
    return getDao().countRuleReferences(input);
  }

  /**
   * 所属日次的任何案件状态/最终指标写入都在真实员工/月锁后核保护月。
   *
   * @param row 实际当前日次例如employeeId=8801/workDate=2026-09-10 异常或副作用示例：已结月份拒绝并回滚外层案件/修订/审计，要求先正式重开。
   */
  private void requireMutableDaily(Map<String, Object> row) {
    CommonParam scope = new CommonParam();
    scope.putParam("employeeId", row.get("employeeId"));
    scope.putParam("workDate", row.get("workDate"));
    monthlyPeriods.requireMutablePeriod(scope);
  }

  /**
   * 方法作用：复用原本表COUNT查询，先后核真实只读管理资格，不修改永久引用。
   *
   * @param input 原所属配置编号，例如id8501，tenantId由服务端覆盖
   * @return 原真实保留引用数量，例如1，无数据写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 资格失效或换身份时拒绝旧计数
   */
  @Override
  @org.springframework.transaction.annotation.Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public long countRuleReferencesForRead(com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadManagement();
    input.putParam("tenantId", actor.get("tenantId"));
    long result = getDao().countRuleReferences(input);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "引用读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原日次结果过滤和完整查询，保留锁定及历史字段。
   *
   * @param input 原分页或主键，例如id8320
   * @param identity 原已核身份，例如tenantId9
   * @return 原完整CommonPageResult，例如原记录或总数分页
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原日次结果过滤和完整查询，保留锁定及历史字段。
   *
   * @param input 原分页或主键，例如id8320
   * @param identity 原已核身份，例如tenantId9
   * @return 原完整CommonResult，例如原记录或总数分页
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return super.getById(input);
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原日次结果完整详情和租户过滤，不重算或修改快照。
   *
   * @param input 原主键，例如id8320
   * @return 原CommonResult，例如data.employeeId7050及原计算字段
   * @throws CommonBusinessException 异校、缺失或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：按原系统查看门槛读取日次结果表头，不授予管理或计算许可。
   *
   * @param viewCode 原Grid编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns原字段配置
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "配置读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原本人查询，完整保留白名单/归属/排序和响应。
   *
   * @param input 原主键或分页，例如id8340
   * @param identity 原已核绑定，例如employeeId7060/tenantId9
   * @return 原CommonPageResult，例如本人真实日次，无持久变更
   */
  private CommonPageResult loadOwnedStore(CommonPageParam input, Map<String, Long> identity) {
    Map<String, Object> query = new java.util.LinkedHashMap<>();
    query.put("tenantId", identity.get("tenantId"));
    query.put("employeeId", identity.get("employeeId"));
    query.put("status", 1);
    // 本人筛选按白名单接收；客户端传入身份字段、操作员或状态不能影响范围。
    Object condition = input.getParam("workDate");
    if (condition != null && !condition.toString().isBlank()) {
      query.put("workDate", condition);
    }
    return getDao().getPageList(query, "id desc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原本人查询，完整保留白名单/归属/排序和响应。
   *
   * @param input 原主键或分页，例如id8340
   * @param identity 原已核绑定，例如employeeId7060/tenantId9
   * @return 原CommonResult，例如本人真实日次，无持久变更
   * @throws CommonBusinessException 原记录不存在、失效或异员工拒绝，无写入
   */
  private CommonResult loadOwned(CommonParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    Map<String, Object> row = getDao().getById(input);
    if (row == null
        || !(row.get("employeeId") instanceof Number owner)
        || owner.longValue() != identity.get("employeeId")) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    return buildSuccessResult(row, "本人员工资源已读取。");
  }

  /**
   * 方法作用：只读本人原分页，实际SELECT之后再核同一绑定和源角色。
   *
   * @param input 原分页，例如pageNo1/pageSize1/workDate2026-10-21
   * @return 原分页，例如records含本人8340，保持id倒序，无写入
   * @throws CommonBusinessException 映射撤回或改绑拒绝旧结果，不退回管理查询
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readOwnedStore(CommonPageParam input) {
    var actor = authorization.requireReadEmployeeBinding();
    var result = loadOwnedStore(input, actor);
    confirmOwnedRead(actor);
    return result;
  }

  /**
   * 方法作用：只读本人原详情，不解锁或重算原日次。
   *
   * @param input 原主键，例如id8340
   * @return 原CommonResult，例如data.employeeId7060及原480分钟
   * @throws CommonBusinessException 原异员工/失效拒绝保持；读后角色/映射变化拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readOwned(CommonParam input) {
    var actor = authorization.requireReadEmployeeBinding();
    var result = loadOwned(input, actor);
    confirmOwnedRead(actor);
    return result;
  }

  /**
   * 方法作用：结果交付前核同一真实用户/租户/员工，不能交付改绑前结果。
   *
   * @param actor 进入时原三坐标，例如userId9102/tenantId9/employeeId7060
   * @throws CommonBusinessException 解绑失效沿原映射错误，改绑沿原归属拒绝，无写入
   */
  private void confirmOwnedRead(Map<String, Long> actor) {
    var current = authorization.requireReadEmployeeBinding();
    // 账号或租户变化才是认证上下文变化，继续沿统一401合同拒绝。
    if (!java.util.Objects.equals(actor.get("userId"), current.get("userId"))
        || !java.util.Objects.equals(actor.get("tenantId"), current.get("tenantId"))) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "本人记录读取期间身份已变化。");
    }
    // 同一账号被改绑为另一员工属于原资源归属变化，不把它误报成登录失效。
    if (!java.util.Objects.equals(actor.get("employeeId"), current.get("employeeId"))) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 方法作用：共用原审批来源完整过滤和返回，不锁定或标记引用。
   *
   * @param input 原来源条件，例如employeeId7080
   * @param identity 原已核审批身份，例如userId9102/tenantId9
   * @return 原CommonResult，例如原生效规则或排班
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原记录/来源错误沿原拒绝，无写入
   */
  private com.sp.selplat.common.util.CommonResult loadApprovalSource(
      com.sp.selplat.common.util.CommonParam input, java.util.Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    return buildSuccessResult(getDao().getById(input), "审批归属日次已读取。");
  }

  /**
   * 方法作用：HTTP身份原审批来源只读，实际SELECT完成后重核资格。
   *
   * @param input 原受控来源，例如employeeId7080/workDate2026-10-21
   * @return 原完整来源，不改变规则或快照
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原APPROVER失效/撤回或身份变化拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public com.sp.selplat.common.util.CommonResult readForApproval(
      com.sp.selplat.common.util.CommonParam input) {
    var actor = authorization.requireReadApproval();
    var result = loadApprovalSource(input, actor);
    if (!actor.equals(authorization.requireReadApproval())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "审批来源读取期间身份已变化。");
    }
    return result;
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
