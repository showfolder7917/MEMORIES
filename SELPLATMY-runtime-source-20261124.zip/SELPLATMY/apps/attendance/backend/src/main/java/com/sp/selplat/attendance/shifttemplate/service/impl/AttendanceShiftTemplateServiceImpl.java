/* 2026-11-01：原批量详情HTTP读取，保留本域逐项租户算法及所有写保护。 */
/* 2026-11-01：保留sortnum降序，同值固定id升序，避免分页依赖物理行次序。 */
/* 2026-11-01：原配置只读接入，桥接与全部提交算法保持。 */
/* 2026-10-29：普通身份查询改经Host具名公共桥接，原读取时机及业务方法不变。 */
package com.sp.selplat.attendance.shifttemplate.service.impl;

import com.sp.selplat.attendance.capability.accessconfiguration.service.AttendanceAuthorizationService;
import com.sp.selplat.attendance.common.util.access.AttendanceAccessGuard;
import com.sp.selplat.attendance.shifttemplate.dao.AttendanceShiftTemplateDao;
import com.sp.selplat.attendance.shifttemplate.service.AttendanceShiftTemplateService;
import com.sp.selplat.common.exception.CommonBusinessException;
import com.sp.selplat.common.service.BaseServiceImpl;
import com.sp.selplat.common.service.identity.CurrentSessionAccess;
import com.sp.selplat.common.service.logging.OperationLog;
import com.sp.selplat.common.util.CommonBatchParam;
import com.sp.selplat.common.util.CommonPageParam;
import com.sp.selplat.common.util.CommonPageResult;
import com.sp.selplat.common.util.CommonParam;
import com.sp.selplat.common.util.CommonResult;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * AttendanceShiftTemplate 复用共通 DAO 泛型注入及 CRUD；缺已核验管理配置时拒绝业务数据操作。 不使用基类固定用户/租户或
 * isAdmin=true，不接受客户端角色、审批人、tenantId 作为授权。
 */
@Service
public class AttendanceShiftTemplateServiceImpl extends BaseServiceImpl<AttendanceShiftTemplateDao>
    implements AttendanceShiftTemplateService {

  @Autowired
  @org.springframework.beans.factory.annotation.Qualifier("attendanceCurrentSessionAccess")
  private CurrentSessionAccess sessionService;

  @Autowired private AttendanceAuthorizationService authorization;

  // 引用只经排班所属服务查询，延迟绑定避免未来互依赖循环，不访问跨表DAO。
  @Autowired
  private org.springframework.beans.factory.ObjectProvider<
          com.sp.selplat.attendance.shiftschedule.service.AttendanceShiftScheduleService>
      schedules;

  // 单段模板原有计算字段与显式生效日期；技术字段和身份不可由客户端覆写。
  private static final java.util.List<String> CONFIG_FIELDS =
      java.util.List.of(
          "templateCode",
          "templateName",
          "shiftType",
          "startTime",
          "endTime",
          "crossDay",
          "scheduledBreakMinutes",
          "color",
          "isActive",
          "effectiveFromDate");

  /**
   * 校验真实会话后拒绝尚未配置的管理权限。
   *
   * @throws com.sp.selplat.common.exception.CommonBusinessException 缺失已核验管理配置时拒绝，无持久化副作用
   * @return 真实会话校验后的用户/租户身份Map；管理配置不成立时抛异常，不创建许可。
   */
  private Map<String, Long> requireManagement() {
    return authorization.requireManagement();
  }

  /**
   * @return 真实 Session 用户主键，例如 8101；匿名抛身份错误，不写数据库。
   */
  @Override
  protected Long getCurrentOperatorId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("userId");
  }

  /**
   * @return 真实 Session 租户主键，例如 81；无租户抛身份错误，不回退 1。
   */
  @Override
  protected Long getCurrentTenantId() {
    return AttendanceAccessGuard.requireIdentity(sessionService.current()).get("tenantId");
  }

  /**
   * @return 例如已核验 MANAGER 仍返回 false，不提升平台管理员身份，账号名称不能授予权限。
   */
  @Override
  protected boolean isAdmin() {
    return false;
  }

  /**
   * 在进入共通 getStore 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonPageResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonPageResult getStore(CommonPageParam input) {
    return loadStore(input, requireManagement());
  }

  /**
   * 在进入共通 getById 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getById(CommonParam input) {
    return loadById(input, requireManagement(), false);
  }

  /**
   * 在进入共通 getByIds 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  public CommonResult getByIds(CommonBatchParam input) {
    return loadBatchDetails(input, requireManagement());
  }

  /**
   * 在进入共通 insert 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(transactionManager = "attendanceTransactionManager")
  public CommonResult insert(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    prepareCreate(input);
    return super.insert(input);
  }

  /**
   * 在进入共通 insertBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult insertBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    var codes = new java.util.HashSet<String>();
    for (CommonParam item : input.getItems()) {
      prepareCreate(item);
      if (!codes.add(String.valueOf(item.getParam("templateCode")))) {
        throw new CommonBusinessException("ATTENDANCE_TEMPLATE_CODE_EXISTS", "班次模板编号已存在，请使用独立新编号。");
      }
    }
    return super.insertBatch(input);
  }

  /**
   * 在进入共通 update 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult update(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    prepareMutation(input, true);
    return super.update(input);
  }

  /**
   * 在进入共通 updateBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult updateBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    for (CommonParam item : ordered(input)) {
      prepareMutation(item, true);
    }
    return super.updateBatch(input);
  }

  /**
   * 在进入共通 delete 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult delete(CommonParam input) {
    Map<String, Long> identity = requireManagement();
    input.putParam("tenantId", identity.get("tenantId"));
    prepareMutation(input, false);
    return super.delete(input);
  }

  /**
   * 在进入共通 deleteBatch 前校验真实考勤管理权限。
   *
   * @param input 共通业务参数，例如 id=100001；客户端身份不能放行
   * @return 共通 CommonResult；未核验授权时拒绝，已核验配置按真实数据库结果返回
   * @throws com.sp.selplat.common.exception.CommonBusinessException 匿名或管理授权未配置时拒绝，无数据读写
   */
  @Override
  @OperationLog
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult deleteBatch(CommonBatchParam input) {
    Map<String, Long> identity = requireManagement();
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, true);
    }
    for (CommonParam item : ordered(input)) {
      prepareMutation(item, false);
    }
    return super.deleteBatch(input);
  }

  /**
   * 确认目标在真实租户内启用；客户端 id 不能绕过租户过滤。
   *
   * @param input 服务端覆盖 tenantId 的主键参数，例如 id=100001、tenantId=81
   * @throws CommonBusinessException 缺失、停用、异租户或受保护快照时拒绝，无写入副作用
   * @param mutation 现有通用校验入口预留标志；未使用它的实现不会据此授予写权限。
   */
  private void requireRecord(CommonParam input, boolean mutation) {
    Map<String, Object> row = getDao().getById(input);
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
  }

  /**
   * 通过本表 DAO 查询真实当前租户的启用记录，不替代其他表 Service。
   *
   * @param criteria 服务能力传入的受控查询字段，例如 employeeId=8801、workDate=2026-10-03
   * @return CommonResult.data 为 AttendanceShiftTemplate 真实行，例如 id=100001、tenantId=81；无匹配为 null
   *     异常或副作用示例：缺已核验管理配置时抛 ATTENDANCE_MANAGEMENT_UNAVAILABLE；仅读库，无写入。
   */
  @Override
  public CommonResult findScoped(CommonParam criteria) {
    Map<String, Long> identity = requireManagement();
    criteria.putParam("tenantId", identity.get("tenantId"));
    criteria.putParam("status", 1);
    return buildSuccessResult(getDao().getByQuery(criteria), "考勤记录已查询。");
  }

  /**
   * 排班保存锁定当前模板并核验明确工作日期，保护已引用参数。
   *
   * @param input 专用排班能力范围例如id=8901、workDate=2026-10-03
   * @return 实际模板CommonResult.data例如revision=0、crossDay=1；无历史结果写入
   *     异常或副作用示例：权限撤销、停用、未生效拒绝；曾引用标志随排班同事务回滚。
   */
  @Override
  @Transactional(
      transactionManager = "attendanceTransactionManager",
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult lockForSchedule(CommonParam input) {
    input.putParam("tenantId", requireManagement().get("tenantId"));
    // 与编辑共用真实行锁，等待后重新核验已提交授权和当前模板。
    Map<String, Object> row = getDao().lockTemplate(input);
    requireManagement();
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    if (!(row.get("isActive") instanceof Number active) || active.intValue() != 1) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_INACTIVE", "班次模板已停用。");
    }
    java.time.LocalDate date;
    try {
      date = java.time.LocalDate.parse(String.valueOf(input.getParam("workDate")));
    } catch (java.time.format.DateTimeParseException bad) {
      throw invalid();
    }
    Object from = row.get("effectiveFromDate");
    // 旧模板NULL边界保持未知，不伪造；新模板只能用于明确生效日及之后的手动排班。
    if (from != null && date.isBefore(java.time.LocalDate.parse(from.toString()))) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_NOT_EFFECTIVE", "班次模板在所选工作日期尚未生效。");
    }
    if (getDao().markReferenced(input) != 1) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_STALE", "班次模板已更新，请重新选择后再编辑。");
    }
    row.put("referenceLocked", 1);
    return buildSuccessResult(row, "班次模板引用已保护。");
  }

  /**
   * 读取当前模板是否曾被保留关联或排班引用，不访问其他表DAO。
   *
   * @param input 服务端范围例如id=8901、tenantId=81
   * @param row 实际当前模板例如referenceLocked=0
   * @return 实际任一引用存在true，无引用false；仅读库，缺可信许可拒绝
   */
  private boolean isReferenced(CommonParam input, Map<String, Object> row) {
    return isReferenced(input, row, false);
  }

  /**
   * 全部归属预检后按固定主键顺序取得批量锁，重复主键拒绝。
   *
   * @param input 实际批量例如items=[{id:8902,revision:0},{id:8901,revision:0}]
   * @return 同一参数项按主键排序的副本；无写入，重复主键抛配置参数错误
   */
  private java.util.List<CommonParam> ordered(CommonBatchParam input) {
    var items = new java.util.ArrayList<>(input.getItems());
    items.sort(
        java.util.Comparator.comparingLong(
            item ->
                new java.math.BigDecimal(String.valueOf(item.getParam("id"))).longValueExact()));
    var seen = new java.util.HashSet<String>();
    for (CommonParam item : items) {
      if (!seen.add(
          String.valueOf(
              new java.math.BigDecimal(String.valueOf(item.getParam("id"))).longValueExact()))) {
        throw invalid();
      }
    }
    return items;
  }

  /**
   * 锁内核对修订、永久引用及真实参数，再交公共CRUD写入。
   *
   * @param input 来自管理表单例如id=8902、revision=0、templateName=日班模板
   * @param update true编辑计算配置、false软删除；不修改任何历史结果 副作用示例：成功参数修订变1；过期、被引用、非法参数拒绝整个事务。
   * @throws CommonBusinessException 考勤记录不存在、失效或无权访问。；班次模板已更新，请重新选择后再编辑。；班次模板已被排班引用，请新建模板并明确生效日期。
   */
  private void prepareMutation(CommonParam input, boolean update) {
    rejectUnsupported(input);
    Map<String, Object> row = getDao().lockTemplate(input);
    requireManagement();
    if (row == null) {
      throw new CommonBusinessException("ATTENDANCE_ACCESS_DENIED", "考勤记录不存在、失效或无权访问。");
    }
    long expected;
    try {
      expected =
          new java.math.BigDecimal(String.valueOf(input.getParam("revision"))).longValueExact();
    } catch (NumberFormatException | ArithmeticException bad) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_STALE", "班次模板已更新，请重新选择后再编辑。");
    }
    if (expected < 0 || expected != ((Number) row.get("revision")).longValue()) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_STALE", "班次模板已更新，请重新选择后再编辑。");
    }
    // 任意保留引用（含历史、未来和软删除）禁止原地重写；新版本须新编号并显式设排班生效边界。
    if (isReferenced(input, row)) {
      throw new CommonBusinessException(
          "ATTENDANCE_TEMPLATE_REFERENCED", "班次模板已被排班引用，请新建模板并明确生效日期。");
    }
    Map<String, Object> values = new java.util.LinkedHashMap<>(row);
    input
        .getParamMap()
        .forEach(
            (key, value) -> {
              if (CONFIG_FIELDS.contains(key)) {
                values.put(key, value);
              }
            });
    if (update) {
      validateConfiguration(values, row.get("effectiveFromDate") != null);
      ensureCodeUnique(values, input.getParam("id"));
    }
    Object id = input.getParam("id"), tenant = input.getParam("tenantId");
    input.getParamMap().clear();
    input.putParam("id", id);
    input.putParam("tenantId", tenant);
    input.putParam("revision", Math.addExact(expected, 1));
    if (update) {
      for (String field : CONFIG_FIELDS) {
        input.putParam(field, values.get(field));
      }
    }
  }

  /**
   * 新增规范旧模板缺省值及trim行为，显式记录用户生效日期，不造历史日期。
   *
   * @param input 原模板字段例如templateCode=NIGHT-V2、startTime=22:00、effectiveFromDate=2026-10-10
   *     副作用示例：revision=0、referenceLocked=0；参数/已存在编号拒绝且无业务写入。
   */
  private void prepareCreate(CommonParam input) {
    rejectUnsupported(input);
    Map<String, Object> values = new java.util.LinkedHashMap<>();
    input
        .getParamMap()
        .forEach(
            (key, value) -> {
              if (CONFIG_FIELDS.contains(key)) {
                values.put(key, value);
              }
            });
    values.putIfAbsent("crossDay", 0);
    values.putIfAbsent("scheduledBreakMinutes", 0);
    values.putIfAbsent("isActive", 1);
    if (values.get("color") == null || values.get("color").toString().isBlank()) {
      values.put("color", "BLUE");
    }
    validateConfiguration(values, true);
    ensureCodeUnique(values, null);
    input.setParamMap(values);
    input.putParam("revision", 0);
    input.putParam("referenceLocked", 0);
  }

  /**
   * 旧模型只支持单起止及休息总分钟，禁止偷偷接受分段或时区参数。
   *
   * @param input 实际请求例如timezone=Invalid/Zone或breakSegments=[{startTime:12:00,endTime:13:00}]
   *     副作用示例：无效时区明确拒绝；有效时区/多段明确告知未支持，不推断换算、不写表。
   * @throws CommonBusinessException
   *     班次模板时区无效。；班次模板仅保存本地时间，当前不支持模板时区换算。；班次模板当前只支持单工作时段和休息分钟总量，不支持分段或重叠休息段。
   */
  private void rejectUnsupported(CommonParam input) {
    for (String key : java.util.List.of("timezone", "timeZone", "zoneId")) {
      if (input.getParamMap().containsKey(key)) {
        try {
          java.time.ZoneId.of(String.valueOf(input.getParam(key)));
        } catch (java.time.DateTimeException bad) {
          throw new CommonBusinessException("ATTENDANCE_TEMPLATE_TIMEZONE_INVALID", "班次模板时区无效。");
        }
        throw new CommonBusinessException(
            "ATTENDANCE_TEMPLATE_TIMEZONE_UNSUPPORTED", "班次模板仅保存本地时间，当前不支持模板时区换算。");
      }
    }
    for (String key :
        java.util.List.of(
            "segments", "workSegments", "breakSegments", "breakStartTime", "breakEndTime")) {
      if (input.getParamMap().containsKey(key)) {
        throw new CommonBusinessException(
            "ATTENDANCE_TEMPLATE_SEGMENTS_UNSUPPORTED", "班次模板当前只支持单工作时段和休息分钟总量，不支持分段或重叠休息段。");
      }
    }
  }

  /**
   * 沿用旧编号trim与同租户唯一模板，明确重复编号，包含保留软删除版本。
   *
   * @param values 规范模板字段例如templateCode=NIGHT-V2
   * @param current 编辑实际主键例如8902；新增null 副作用示例：其他行同编号抛明确业务异常；只查所属本表，不写库。
   * @throws CommonBusinessException 班次模板编号已存在，请使用独立新编号。
   */
  private void ensureCodeUnique(Map<String, Object> values, Object current) {
    CommonParam query = new CommonParam();
    query.putParam("tenantId", getCurrentTenantId());
    query.putParam("templateCode", values.get("templateCode"));
    Map<String, Object> existing = getDao().getByQuery(query);
    if (existing != null
        && (current == null
            || ((Number) existing.get("id")).longValue()
                != new java.math.BigDecimal(String.valueOf(current)).longValueExact())) {
      throw new CommonBusinessException("ATTENDANCE_TEMPLATE_CODE_EXISTS", "班次模板编号已存在，请使用独立新编号。");
    }
  }

  /**
   * 校验单段旧模板的日期/时间/休息总量和DDL范围，不计算或改变工资分钟。
   *
   * @param values 实际模板例如22:00→06:00、crossDay=1、休息60分钟
   * @param requireDate 新建或已有明确边界时必须保留日期；旧未知NULL不回填默认值 副作用示例：时间trim、开关/分钟变实际int；倒置时间、负数/溢出或扣休超过时段拒绝。
   * @throws CommonBusinessException 班次结束时间必须晚于开始时间；夜班请明确选择跨日。；休息分钟不能超过班次时段总分钟。；新班次模板必须明确生效日期。
   */
  private void validateConfiguration(Map<String, Object> values, boolean requireDate) {
    if (values.get("color") == null || values.get("color").toString().isBlank()) {
      values.put("color", "BLUE");
    }
    for (String field : java.util.List.of("templateCode", "templateName", "shiftType", "color")) {
      Object value = values.get(field);
      int max = field.equals("templateCode") ? 50 : field.equals("templateName") ? 200 : 30;
      if (!(value instanceof CharSequence)
          || value.toString().trim().isEmpty()
          || value.toString().trim().length() > max) {
        throw invalid();
      }
      values.put(field, value.toString().trim());
    }
    for (String field : java.util.List.of("crossDay", "scheduledBreakMinutes", "isActive")) {
      Object value = values.get(field);
      int number;
      try {
        number =
            value instanceof Boolean flag
                ? (flag ? 1 : 0)
                : new java.math.BigDecimal(String.valueOf(value)).intValueExact();
      } catch (NumberFormatException | ArithmeticException bad) {
        throw invalid();
      }
      if (number < 0 || (!field.equals("scheduledBreakMinutes") && number > 1)) {
        throw invalid();
      }
      values.put(field, number);
    }
    java.time.LocalTime start = null, end = null;
    for (String field : java.util.List.of("startTime", "endTime")) {
      Object raw = values.get(field);
      if (raw != null && !(raw instanceof CharSequence)) {
        throw invalid();
      }
      String time = raw == null ? null : raw.toString().trim();
      if (time != null && time.isEmpty()) {
        time = null;
      }
      try {
        if (time != null) {
          if (time.length() > 20) {
            throw invalid();
          }
          java.time.LocalTime parsed = java.time.LocalTime.parse(time);
          if (field.equals("startTime")) {
            start = parsed;
          } else {
            end = parsed;
          }
        }
      } catch (java.time.format.DateTimeParseException bad) {
        throw invalid();
      }
      values.put(field, time);
    }
    boolean noWork =
        java.util.Set.of("REST", "PAID_LEAVE", "SPECIAL_LEAVE", "ABSENCE")
            .contains(String.valueOf(values.get("shiftType")));
    if ((start == null) != (end == null)) {
      throw invalid();
    }
    if (start == null) {
      if (!noWork
          || (Integer) values.get("scheduledBreakMinutes") != 0
          || (Integer) values.get("crossDay") != 0) {
        throw invalid();
      }
    } else {
      // 跨日严格沿用旧显式+1天，不自动猜测；没有跨日而结束早于开始时明确纠正输入。
      var day = java.time.LocalDate.of(2000, 1, 1);
      var from = day.atTime(start);
      var to = ((Integer) values.get("crossDay") == 1 ? day.plusDays(1) : day).atTime(end);
      if (to.isBefore(from) || (!noWork && to.equals(from))) {
        throw new CommonBusinessException(
            "ATTENDANCE_TEMPLATE_TIME_RANGE_INVALID", "班次结束时间必须晚于开始时间；夜班请明确选择跨日。");
      }
      if ((Integer) values.get("scheduledBreakMinutes")
          > java.time.Duration.between(from, to).toMinutes()) {
        throw new CommonBusinessException("ATTENDANCE_TEMPLATE_BREAK_INVALID", "休息分钟不能超过班次时段总分钟。");
      }
    }
    Object date = values.get("effectiveFromDate");
    if (date == null || date.toString().isBlank()) {
      if (requireDate) {
        throw new CommonBusinessException(
            "ATTENDANCE_TEMPLATE_EFFECTIVE_DATE_REQUIRED", "新班次模板必须明确生效日期。");
      }
      values.put("effectiveFromDate", null);
    } else {
      try {
        values.put("effectiveFromDate", java.time.LocalDate.parse(date.toString()));
      } catch (java.time.format.DateTimeParseException bad) {
        throw invalid();
      }
    }
  }

  /**
   * @return 明确模板参数错误例如ATTENDANCE_TEMPLATE_INPUT_INVALID，不携带原始业务数据，无写入副作用。
   */
  private CommonBusinessException invalid() {
    return new CommonBusinessException(
        "ATTENDANCE_TEMPLATE_INPUT_INVALID", "班次模板参数无效，请检查时间、跨日、休息分钟和生效日期。");
  }

  /**
   * 方法作用：共用原租户范围与查询投影，不新增业务规则。
   *
   * @param input 原查询，例如id8501
   * @param identity 原已核资格，例如tenantId9
   * @return 原完整CommonPageResult，例如原配置行及引用保护
   */
  private CommonPageResult loadStore(CommonPageParam input, Map<String, Long> identity) {
    input.putParam("tenantId", identity.get("tenantId"));
    input.putParam("status", 1);
    return getDao()
        .getPageList(
            input.getParamMap(), "sortnum desc id asc", input.getPageNo(), input.getPageSize());
  }

  /**
   * 方法作用：共用原租户范围与查询投影，不新增业务规则。
   *
   * @param input 原查询，例如id8501
   * @param identity 原已核资格，例如tenantId9
   * @param readOnly 仅新HTTP纯读时true，原桥接false
   * @return 原完整CommonResult，例如原配置行及引用保护
   */
  private CommonResult loadById(CommonParam input, Map<String, Long> identity, boolean readOnly) {
    input.putParam("tenantId", identity.get("tenantId"));
    requireRecord(input, false);
    CommonResult result = super.getById(input);
    // 真正所属服务核对所有保留引用，页面得到保护事实但不获得修改权。
    ((Map<String, Object>) result.getData())
        .put(
            "configurationProtected",
            isReferenced(input, (Map<String, Object>) result.getData(), readOnly));
    return result;
  }

  /**
   * 方法作用：同一永久引用算法仅选择原持锁或纯读资格，保留全部历史行。
   *
   * @param input 原编号，例如id8501
   * @param row 原本表行，例如referenceLocked0
   * @param readOnly 仅纯读路径true
   * @return 原任一保留引用存在true，不生成引用
   */
  private boolean isReferenced(CommonParam input, Map<String, Object> row, boolean readOnly) {
    // 本表永久标记先保护新引用；旧库未记录标记时由实际保留行补足。
    return ((Number) row.get("referenceLocked")).intValue() != 0
        || (readOnly
                ? schedules.getObject().countTemplateReferencesForRead(input)
                : schedules.getObject().countTemplateReferences(input))
            > 0;
  }

  /**
   * 方法作用：纯读复用原分页，输出前重新核同一管理资格，不进入原提交回调。
   *
   * @param input 原分页，例如pageNo1/pageSize20
   * @return 原完整分页，例如records及totalCount4，无持久变更
   * @throws CommonBusinessException 身份或管理资格变化时拒绝旧结果
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonPageResult readStore(CommonPageParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadStore(input, actor);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：纯读复用原详情与全部保留引用检查，不获得修改许可。
   *
   * @param input 原主键，例如id8501
   * @return 原完整详情，例如configurationProtected为true或false
   * @throws CommonBusinessException 异租户、缺记录或资格撤销沿原拒绝，无写入
   */
  @Override
  @OperationLog
  @Transactional(
      value = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readById(CommonParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadById(input, actor, true);
    confirmRead(actor, true);
    return result;
  }

  /**
   * 方法作用：原配置和元数据表头沿系统查看门槛读取，不提升管理权限。
   *
   * @param viewCode 原表头编码，例如default
   * @param locale 原语言，例如zh-CN
   * @return 原CommonResult，例如data.columns包含配置名称
   * @throws CommonBusinessException 原参数无效或角色变化拒绝，无配置写入
   */
  @Override
  public CommonResult readGridColumn(String viewCode, String locale) {
    var actor = authorization.requireReadIdentity();
    var result = super.getGridColumn(viewCode, locale);
    confirmRead(actor, false);
    return result;
  }

  /**
   * 方法作用：实际查询完成后重核同一原角色、身份和可选管理事实。
   *
   * @param actor 本次进入时原坐标，例如userId9101/tenantId9
   * @param management 数据查询true，原表头false
   * @throws CommonBusinessException 换校换号拒绝，撤角色或管理资格沿原错误传播
   */
  private void confirmRead(Map<String, Long> actor, boolean management) {
    var current =
        management ? authorization.requireReadManagement() : authorization.requireReadIdentity();
    if (!actor.equals(current)) {
      throw new CommonBusinessException("UNIAUTH_IDENTITY_REQUIRED", "配置读取期间身份已变化。");
    }
  }

  /**
   * 方法作用：共用原逐项租户核验和本域DAO批量算法，保留顺序、重复项及全批错误
   *
   * @param input 原items，例如同一主键重复两次
   * @param identity 原已核管理身份，例如tenantId9/userId9102
   * @return 原完整CommonResult.data列表，重复及空批保持
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  private CommonResult loadBatchDetails(CommonBatchParam input, Map<String, Long> identity) {
    for (CommonParam item : input.getItems()) {
      item.putParam("tenantId", identity.get("tenantId"));
      requireRecord(item, false);
    }
    return super.getByIds(input);
  }

  /**
   * 方法作用：纯读交付前重核原管理资格及真实源角色，不开放原写保护回调
   *
   * @param input 原JSON items，例如[{id:62000},{id:62001},{id:62000}]
   * @return 原完整批量CommonResult，输入三项可按原算法返回三行，无写入
   * @throws com.sp.selplat.common.exception.CommonBusinessException 原资格/租户/记录失效沿原拒绝，无写入
   */
  @Override
  @com.sp.selplat.common.service.logging.OperationLog
  @org.springframework.transaction.annotation.Transactional(
      transactionManager = "attendanceTransactionManager",
      readOnly = true,
      isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
  public CommonResult readByIds(CommonBatchParam input) {
    var actor = authorization.requireReadManagement();
    var result = loadBatchDetails(input, actor);
    if (!actor.equals(authorization.requireReadManagement())) {
      throw new com.sp.selplat.common.exception.CommonBusinessException(
          "UNIAUTH_IDENTITY_REQUIRED", "批量读取期间身份已变化。");
    }
    return result;
  }
}
