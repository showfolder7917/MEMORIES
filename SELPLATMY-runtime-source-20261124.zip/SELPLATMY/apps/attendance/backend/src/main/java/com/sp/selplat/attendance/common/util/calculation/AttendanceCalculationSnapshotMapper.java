package com.sp.selplat.attendance.common.util.calculation;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** 连接旧计算 Map 与新表字段，不修改公式，也不承担身份、事务或日志/异常持久化。 */
public final class AttendanceCalculationSnapshotMapper {
    /** 仅限制无状态工具类实例化；不访问数据库或授予权限。 */
    private AttendanceCalculationSnapshotMapper() {
        // 静态字段边界工具不保存请求数据。
    }

    /**
     * 将真实排班行的字段投影到原计算器约定，时间值保持 JDBC 原值。
     *
     * @param row 已经表服务校验归属的排班记录，例如 id、scheduledStartTime、scheduledBreakMinutes
     * @return 原约定 Map，例如 shiftScheduleId、startTime、breakMinutes；没有排班传 null 返回 null
     *     副作用示例：不修改原行，不读取模板名或跨表查询，不证明该行的业务访问权限。
     */
    public static Map<String, Object> scheduleForCalculation(Map<String, Object> row) {
        if (row == null) {
            return null;
        }
        Map<String, Object> snapshot = new LinkedHashMap<>();
        snapshot.put("shiftScheduleId", row.get("id"));
        snapshot.put("startTime", row.get("scheduledStartTime"));
        snapshot.put("endTime", row.get("scheduledEndTime"));
        snapshot.put("breakMinutes", row.get("scheduledBreakMinutes"));
        snapshot.put("workDayType", row.get("workDayType"));
        return snapshot;
    }

    /**
     * 将日次算法结果投影到实际 DAO 元数据，并将旧业务状态与共通软删除状态分开。
     *
     * @param result 原计算器结果，例如 status=NORMAL、actualWorkMinutes=510
     * @param workDate 服务端确定的业务日，例如 2026-07-03
     * @param employeeId 已校验同租户的员工主键，例如 8801
     * @param columns 实际 AttendanceDailyDao.getDbColumnsMap().keySet()，禁止请求字段列表
     * @return 日次列 Map，例如 businessStatus=NORMAL、status=1、actualWorkMinutes=510；不含 logs/exceptions
     * @throws IllegalArgumentException 业务状态或身份列缺失时拒绝；不补造租户、操作员或 ID 副作用示例：调用方必须通过真实授权 Service
     *     写入身份、号段及日志/异常所属表，并在同事务处理。
     */
    public static Map<String, Object> dailyForStorage(
            Map<String, Object> result, LocalDate workDate, long employeeId, Set<String> columns) {
        if (result == null
                || !(result.get("status") instanceof String businessStatus)
                || businessStatus.isBlank()
                || workDate == null
                || employeeId <= 0
                || !columns.containsAll(
                        Set.of("businessStatus", "status", "workDate", "employeeId"))) {
            throw new IllegalArgumentException("日次快照状态、归属或实际字段不完整");
        }
        Map<String, Object> row = new LinkedHashMap<>();
        result.forEach(
                (key, value) -> {
                    if (columns.contains(key)
                            && !Set.of(
                                            "status",
                                            "finalStatus",
                                            "finalClockIn",
                                            "finalClockOut",
                                            "finalBreakMinutes",
                                            "finalRemark",
                                            "approvedCaseId")
                                    .contains(key)) {
                        row.put(key, value);
                    }
                });
        // 旧 Service mergeDaily 的 actualBreakMinutes 参数来自算法 finalBreakMinutes；
        // 初算不写审批 final 字段，否则会把未审批时间误当最终快照。
        if (columns.contains("actualBreakMinutes")) {
            row.put("actualBreakMinutes", result.get("finalBreakMinutes"));
        }
        row.put("businessStatus", businessStatus);
        row.put("status", 1);
        row.put("workDate", workDate);
        row.put("employeeId", employeeId);
        return row;
    }

    /**
     * 恢复日次持久化行的原业务状态供月次汇总，禁止把逻辑状态 1 当作 NORMAL。
     *
     * @param row 实际启用日次行，例如 status=1、businessStatus=LATE、finalClockIn 为 JDBC Timestamp
     * @return 原月次计算约定 Map，例如 status=LATE；时间、分钟和审批字段保持原值
     * @throws IllegalArgumentException 行停用或业务状态丢失时拒绝；不重新计算已审批工时
     */
    public static Map<String, Object> dailyForMonthly(Map<String, Object> row) {
        if (row == null
                || !(row.get("status") instanceof Number active)
                || active.intValue() != 1
                || !(row.get("businessStatus") instanceof String businessStatus)
                || businessStatus.isBlank()) {
            throw new IllegalArgumentException("日次快照已停用或缺少业务状态");
        }
        Map<String, Object> snapshot = new LinkedHashMap<>(row);
        snapshot.put("status", businessStatus);
        return snapshot;
    }
}
