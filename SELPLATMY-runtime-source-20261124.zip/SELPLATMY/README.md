# SELPLAT

`SELPLAT` 是多业务应用统一装配与运行的平台工程。

Host 作为统一 JVM 和 HTTP 入口，通过 Gradle 工程登记与显式依赖装配服务端模块。本交付子集不包含独立的 AI Desktop。

## 目录说明

- `apps/`：宿主、业务模块、内部能力和桌面应用目录。
- `shared/`：跨模块复用资产目录。
- `docs/`：平台级文档目录。
- `runtime/`：日志、报告、缓存目录。

## 当前模块

- `host`
- `uniauth`
- `file-service`
- `crm`
- `attendance`
- `finance`

## 统一平台启动

Windows PowerShell:

```powershell
.\启动SELPLAT.ps1
```

Windows CMD:

```bat
启动SELPLAT.bat
```

统一入口会先结束占用 `8080` 的旧进程，再通过 Host 的 Gradle `run` 任务编译并启动全部显式服务端依赖。它不会编译或启动 `apps/ai-desktop`。

全新下载环境需要安装 JDK 21，并在首次启动时允许访问 Gradle 分发站点和 Maven Central。首次启动下载的依赖会保存在工程 `cache/` 中；之后可使用离线模式启动：

```powershell
.\启动SELPLAT.ps1 -Offline
```

只检查启动入口而不启动服务：

```powershell
.\启动SELPLAT.ps1 -ValidateOnly
```

启动前检查：

1. 平台基础目录是否存在。
2. `apps/host/backend` 和其 `build.gradle` 是否存在。
3. 根 `settings.gradle` 和 Gradle Wrapper 是否存在。

真实模块装配以 `settings.gradle` 和 `apps/host/backend/build.gradle` 为准。

## 本地登录

首次启动会在 Uniauth 数据库中补齐以下应用登录账号：

- 用户名：`test`
- 密码：`12345678`

登录地址：`http://localhost:8080/uniauth/login.html`。

数据库 JDBC 连接凭据仍为工程统一配置的 `sa / 123456`；上述 `test` 是网页应用账号，不是 H2 数据库连接账号。
