#!/usr/bin/env bash
# SELPLAT Linux 发布入口；从本机执行，密码由 SSH 交互读取，绝不写入脚本。
set -Eeuo pipefail
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEPLOY_HOST="${DEPLOY_HOST:-203.248.94.43}"
DEPLOY_SSH_PORT="${DEPLOY_SSH_PORT:-53060}"
DEPLOY_USER="${DEPLOY_USER:-root}"
DEPLOY_ROOT="${DEPLOY_ROOT:-/opt/selplat}"
DEPLOY_HTTP_PORT="${DEPLOY_HTTP_PORT:-80}"
ACTION="${1:-help}"
fail() { printf '[错误] %s\n' "$*" >&2; exit 1; }
valid_port() { [[ "$1" =~ ^[0-9]+$ ]] && (( 10#$1 > 0 && 10#$1 < 65536 )); }
validate() {
  [[ "$DEPLOY_HOST" =~ ^[a-zA-Z0-9.-]+$ ]] || fail "非法主机地址"
  [[ "$DEPLOY_USER" =~ ^[a-zA-Z_][a-zA-Z0-9_-]*$ ]] || fail "非法用户名"
  valid_port "$DEPLOY_SSH_PORT" && valid_port "$DEPLOY_HTTP_PORT" || fail "端口应为 1–65535"
  [[ "$DEPLOY_ROOT" =~ ^/opt/[a-zA-Z0-9_-]+$ ]] || fail "安装路径必须是 /opt 下单层目录"
}
ssh_run() {
  ssh -o ConnectTimeout=10 -o ServerAliveInterval=15 -o ServerAliveCountMax=3 \
    -p "$DEPLOY_SSH_PORT" "$DEPLOY_USER@$DEPLOY_HOST" "$@"
}
# 本地仅构建 Host 的显式依赖；不打包数据库、private、桌面应用或本机缓存。
pack() {
  [[ -x "$PROJECT_ROOT/gradlew" ]] || fail "缺少 Gradle Wrapper"
  cd "$PROJECT_ROOT"
  export SELPLAT_PYTHON="${SELPLAT_PYTHON:-$(command -v python3)}"
  if [[ -z "${JAVA_HOME:-}" && -x "$PROJECT_ROOT/cache/jdks/temurin-21.jdk/Contents/Home/bin/java" ]]; then
    export JAVA_HOME="$PROJECT_ROOT/cache/jdks/temurin-21.jdk/Contents/Home"
  fi
  ./gradlew --offline --no-daemon :apps:host:backend:installDist :apps:host:backend:verifyDistributionProjectJars
  local installed="$PROJECT_ROOT/build/apps/host/backend/install/backend"
  [[ -x "$installed/bin/backend" ]] || fail "分发启动入口缺失"
  mkdir -p "$PROJECT_ROOT/build/deploy"
  RELEASE="$(date -u +%Y%m%dT%H%M%SZ)-$$"
  ARCHIVE="$PROJECT_ROOT/build/deploy/selplat-$RELEASE.tar.gz"
  COPYFILE_DISABLE=1 tar --no-xattrs -czf "$ARCHIVE" -C "$installed" .
  DIGEST="$(shasum -a 256 "$ARCHIVE" | awk '{print $1}')"
  printf '%s  %s\n' "$DIGEST" "$(basename "$ARCHIVE")" > "$ARCHIVE.sha256"
  printf '[完成] %s\n' "$ARCHIVE"
}
# 由 deploy 上传本脚本后调用；仅支持带 systemd 的 Linux，新服务器安装 Java 21。
remote_install() {
  [[ "$(uname -s)" == Linux && "$(id -u)" == 0 ]] || fail "服务器需为 Linux，使用 root 发布"
  command -v systemctl >/dev/null || fail "服务器没有 systemd"
  local release="$2" expected="$3"
  DEPLOY_ROOT="$4"; DEPLOY_HTTP_PORT="$5"; validate
  [[ "$release" =~ ^[0-9]{8}T[0-9]{6}Z-[0-9]+$ && "$expected" =~ ^[a-f0-9]{64}$ ]] || fail "发布参数非法"
  local archive="$DEPLOY_ROOT/incoming/selplat-$release.tar.gz"
  [[ -f "$archive" ]] || fail "发布包不存在"
  printf '%s  %s\n' "$expected" "$archive" | sha256sum -c -
  local java_version=""
  if command -v java >/dev/null; then
    java_version="$(java -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -1)"
  fi
  if [[ "$java_version" != 21 ]] || ! command -v curl >/dev/null; then
    if command -v apt-get >/dev/null; then
      apt-get update
      DEBIAN_FRONTEND=noninteractive apt-get install -y openjdk-21-jre-headless curl
    elif command -v dnf >/dev/null; then
      dnf install -y java-21-openjdk-headless curl
    else
      fail "请先安装 Java 21、curl；支持 apt-get/dnf 自动安装"
    fi
  fi
  java_version="$(java -version 2>&1 | sed -n 's/.*version "\([0-9]*\).*/\1/p' | head -1)"
  [[ "$java_version" == 21 ]] || fail "默认 java 不是 Java 21，请调整 alternatives 后重试"
  id selplat >/dev/null 2>&1 || useradd --system --home-dir "$DEPLOY_ROOT/workspace" --shell /usr/sbin/nologin selplat
  mkdir -p "$DEPLOY_ROOT/releases" "$DEPLOY_ROOT/private/backups" "$DEPLOY_ROOT/workspace/apps" "$DEPLOY_ROOT/private"
  # incoming 创建时使用私有 umask；根与程序目录必须允许专用服务账号穿过。
  chmod 755 "$DEPLOY_ROOT" "$DEPLOY_ROOT/releases"
  chmod 700 "$DEPLOY_ROOT/private/backups" "$DEPLOY_ROOT/incoming"
  chmod 700 "$DEPLOY_ROOT/private"
  chown selplat:selplat "$DEPLOY_ROOT/private"
  # 工程标记供模块定位持久数据库根；运行目录独立于版本包，更新不会覆盖用户数据。
  touch "$DEPLOY_ROOT/workspace/settings.gradle"
  for app in uniauth reference-data mda cms ai-factiory japanese plat file-service education crm attendance; do
    mkdir -p "$DEPLOY_ROOT/workspace/apps/$app/db"
  done
  chown -R selplat:selplat "$DEPLOY_ROOT/workspace"
  if [[ ! -f "$DEPLOY_ROOT/private/selplat.env" ]]; then
    printf '%s\n' '# 服务器私有环境；不要上传到 Git。' \
      'JAVA_OPTS="-Xms256m -Xmx1024m -Dfile.encoding=UTF-8 -Dspring.devtools.restart.enabled=false"' \
      'UNIAUTH_LOCAL_BOOTSTRAP_ENABLED=false' > "$DEPLOY_ROOT/private/selplat.env"
    chmod 600 "$DEPLOY_ROOT/private/selplat.env"
    chown selplat:selplat "$DEPLOY_ROOT/private/selplat.env"
  fi
  # 新库首次生成独立秘密，之后保持原值；存在旧库时缺少秘密必须阻断，不能重置。
  local secret_key app db
  for secret_key in ATTENDANCE_DB_PASSWORD CRM_DB_PASSWORD; do
    if ! grep -Eq "^$secret_key=.+" "$DEPLOY_ROOT/private/selplat.env"; then
      app=attendance; [[ "$secret_key" != CRM_DB_PASSWORD ]] || app=crm
      db="$DEPLOY_ROOT/workspace/apps/$app/db/$app.mv.db"
      [[ ! -f "$db" ]] || fail "已有 $app 数据库，请在私有环境中补回 $secret_key，不能自动重置"
      printf '%s=%s\n' "$secret_key" "$(od -An -N32 -tx1 /dev/urandom | tr -d ' \n')" >> "$DEPLOY_ROOT/private/selplat.env"
    fi
  done
  [[ ! -e "$DEPLOY_ROOT/releases/$release" ]] || fail "版本已存在，拒绝覆盖"
  mkdir "$DEPLOY_ROOT/releases/$release"
  tar -xzf "$archive" -C "$DEPLOY_ROOT/releases/$release" --no-same-owner
  [[ -x "$DEPLOY_ROOT/releases/$release/bin/backend" ]] || fail "包中缺少启动入口"
  chmod -R go-w "$DEPLOY_ROOT/releases/$release"
  local previous=""
  [[ ! -L "$DEPLOY_ROOT/current" ]] || previous="$(readlink "$DEPLOY_ROOT/current")"
  # 不结束其他程序；HTTP 端口被非 SELPLAT 服务占用时拒绝部署。
  if ! systemctl is-active --quiet selplat && command -v ss >/dev/null; then
    [[ -z "$(ss -H -ltn "sport = :$DEPLOY_HTTP_PORT")" ]] || fail "HTTP 端口已被其他程序占用"
  fi
  local unit=/etc/systemd/system/selplat.service
  [[ ! -f "$unit" ]] || cp "$unit" "$DEPLOY_ROOT/private/backups/service-$release"
  # 停机后的任意失败都尝试恢复旧程序；恢复数据库必须另行评估。
  remote_rollback() {
    trap - ERR
    set +e
    journalctl -u selplat -n 80 --no-pager >&2
    systemctl stop selplat
    if [[ -n "$previous" ]]; then
      ln -sfn "$previous" "$DEPLOY_ROOT/current.rollback"
      mv -Tf "$DEPLOY_ROOT/current.rollback" "$DEPLOY_ROOT/current"
      if [[ -f "$DEPLOY_ROOT/private/backups/service-$release" ]]; then
        cp "$DEPLOY_ROOT/private/backups/service-$release" "$unit"
      fi
      systemctl daemon-reload
      systemctl start selplat
      printf '[提示] 已尝试恢复旧程序；数据库未自动回滚，请检查服务状态。\n' >&2
    fi
    printf '[错误] 发布失败，数据备份目录：%s/private/backups\n' "$DEPLOY_ROOT" >&2
    exit 1
  }
  systemctl stop selplat 2>/dev/null || {
    [[ ! -e "$unit" ]] || fail "原服务无法停止"
  }
  trap remote_rollback ERR
  # 数据库备份必须在停止服务后生成，不能复制正在写入的 H2 文件。
  tar -czf "$DEPLOY_ROOT/private/backups/data-$release.tar.gz" -C "$DEPLOY_ROOT/workspace" apps
  chmod 600 "$DEPLOY_ROOT/private/backups/data-$release.tar.gz"
  # 新私有环境目录已启用时，同时保留实际正式库；旧 workspace 归档继续兼容历史恢复。
  if [[ -d "$DEPLOY_ROOT/private/production/db" ]]; then
    tar -czf "$DEPLOY_ROOT/private/backups/private-databases-$release.tar.gz" \
      -C "$DEPLOY_ROOT/private" production/db
    chmod 600 "$DEPLOY_ROOT/private/backups/private-databases-$release.tar.gz"
  fi
  cat > "$unit" <<UNIT
[Unit]
Description=SELPLAT platform runtime
After=network.target
[Service]
Type=simple
User=selplat
Group=selplat
WorkingDirectory=$DEPLOY_ROOT/workspace
EnvironmentFile=$DEPLOY_ROOT/private/selplat.env
ExecStart=$DEPLOY_ROOT/current/bin/backend --server.address=0.0.0.0 --server.port=$DEPLOY_HTTP_PORT
Restart=on-failure
RestartSec=5
TimeoutStopSec=60
SuccessExitStatus=143
UMask=0077
NoNewPrivileges=true
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
PrivateTmp=true
[Install]
WantedBy=multi-user.target
UNIT
  ln -s "$DEPLOY_ROOT/releases/$release" "$DEPLOY_ROOT/current.next"
  mv -Tf "$DEPLOY_ROOT/current.next" "$DEPLOY_ROOT/current"
  systemctl daemon-reload
  systemctl enable selplat
  systemctl start selplat
  local healthy=false response=""
  for ((i=0; i<60; i++)); do
    if response="$(curl -fsS --max-time 2 "http://127.0.0.1:$DEPLOY_HTTP_PORT/api/platform/runtime/health")"; then
      if [[ "$response" == *'"success":true'* && "$response" == *'"status":"READY"'* ]]; then
        healthy=true; break
      fi
    fi
    sleep 2
  done
  [[ "$healthy" == true ]] || remote_rollback
  trap - ERR
  # 保留现有防火墙策略；只在已运行的规则管理器中追加指定 HTTP 端口。
  if command -v ufw >/dev/null && ufw status | grep -q '^Status: active'; then
    ufw allow "$DEPLOY_HTTP_PORT/tcp"
  elif command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port="$DEPLOY_HTTP_PORT/tcp"
    firewall-cmd --add-port="$DEPLOY_HTTP_PORT/tcp"
  fi
  printf '[完成] SELPLAT 健康检查通过，监听 %s；云安全组需另行放行该端口。\n' "$DEPLOY_HTTP_PORT"
}
case "$ACTION" in
  help|--help|-h)
    cat <<HELP
用法：bash 发布SELPLAT.sh [pack|check|deploy|status|logs]
  pack    本地离线编译并打包
  check   检查服务器 SSH 和系统信息
  deploy  检查连接、打包、上传、安装 Java 21、配置服务并发布
  status  查看服务器服务和健康状态
  logs    查看服务器最近 100 行日志
默认：$DEPLOY_USER@$DEPLOY_HOST:$DEPLOY_SSH_PORT，HTTP $DEPLOY_HTTP_PORT
可通过 DEPLOY_HOST / DEPLOY_SSH_PORT / DEPLOY_USER / DEPLOY_ROOT / DEPLOY_HTTP_PORT 覆盖。
SSH 密码由终端提示输入；推荐在服务器恢复连通后配置密钥登录。
HELP
    ;;
  pack) pack ;;
  check)
    validate
    ssh_run 'uname -a; cat /etc/os-release; command -v java >/dev/null && java -version; command -v systemctl; command -v ss >/dev/null && ss -ltn'
    ;;
  deploy)
    validate
    [[ "$DEPLOY_USER" == root ]] || fail "首次安装需要 root；当前脚本仅使用 root 配置服务器"
    ssh_run 'test "$(uname -s)" = Linux && test "$(id -u)" = 0 && command -v systemctl >/dev/null'
    pack
    ssh_run "umask 077; mkdir -p '$DEPLOY_ROOT/incoming'"
    scp -o ConnectTimeout=10 -P "$DEPLOY_SSH_PORT" "$ARCHIVE" \
      "$DEPLOY_USER@$DEPLOY_HOST:$DEPLOY_ROOT/incoming/selplat-$RELEASE.tar.gz"
    scp -o ConnectTimeout=10 -P "$DEPLOY_SSH_PORT" "$PROJECT_ROOT/发布SELPLAT.sh" \
      "$DEPLOY_USER@$DEPLOY_HOST:$DEPLOY_ROOT/incoming/install-$RELEASE.sh"
    ssh_run "bash '$DEPLOY_ROOT/incoming/install-$RELEASE.sh' --remote-install '$RELEASE' '$DIGEST' '$DEPLOY_ROOT' '$DEPLOY_HTTP_PORT'"
    curl --fail --silent --show-error --max-time 10 \
      "http://$DEPLOY_HOST:$DEPLOY_HTTP_PORT/api/platform/runtime/health" \
      || fail "服务器内部已启动，但外网 HTTP 不通；请检查安全组 TCP $DEPLOY_HTTP_PORT"
    if [[ "$DEPLOY_HTTP_PORT" == 80 ]]; then
      printf '\n访问：http://%s/desktop/desktop.html\n' "$DEPLOY_HOST"
    else
      printf '\n访问：http://%s:%s/desktop/desktop.html\n' "$DEPLOY_HOST" "$DEPLOY_HTTP_PORT"
    fi
    ;;
  status)
    validate
    ssh_run "systemctl status selplat --no-pager; curl -fsS --max-time 5 'http://127.0.0.1:$DEPLOY_HTTP_PORT/api/platform/runtime/health'"
    ;;
  logs) validate; ssh_run 'journalctl -u selplat -n 100 --no-pager' ;;
  --remote-install) [[ $# == 5 ]] || fail "安装参数数量错误"; remote_install "$@" ;;
  *) fail "未知操作：$ACTION；使用 --help 查看用法" ;;
esac
