param(
    [switch]$ValidateOnly,
    [switch]$Offline
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"

$platformRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:SELPLAT_ROOT = $platformRoot
$requiredDirs = @("apps", "shared")
foreach ($requiredDir in $requiredDirs) {
    $targetPath = Join-Path $platformRoot $requiredDir
    if (-not (Test-Path -LiteralPath $targetPath -PathType Container)) {
        Write-Error ("Missing platform directory: " + $requiredDir)
    }
}
$cacheRoot = Join-Path $platformRoot "cache"
New-Item -ItemType Directory -Force -Path $cacheRoot | Out-Null

$hostBackend = Join-Path $platformRoot "apps\host\backend"
if (-not (Test-Path -LiteralPath $hostBackend -PathType Container)) {
    Write-Error "Missing Host backend directory: apps/host/backend"
}

$hostBuildFile = Join-Path $hostBackend "build.gradle"
if (-not (Test-Path -LiteralPath $hostBuildFile -PathType Leaf)) {
    Write-Error "Missing Host build entry: apps/host/backend/build.gradle"
}

$settingsFile = Join-Path $platformRoot "settings.gradle"
if (-not (Test-Path -LiteralPath $settingsFile -PathType Leaf)) {
    Write-Error "Missing Gradle project registry: settings.gradle"
}

$gradleWrapper = Join-Path $platformRoot "gradlew.bat"
if (-not (Test-Path -LiteralPath $gradleWrapper -PathType Leaf)) {
    Write-Error "Missing Gradle wrapper: gradlew.bat"
}

$javaExecutable = $null
if ($env:JAVA_HOME) {
    $javaHomeExecutable = Join-Path $env:JAVA_HOME "bin\java.exe"
    if (Test-Path -LiteralPath $javaHomeExecutable -PathType Leaf) {
        $javaExecutable = $javaHomeExecutable
    }
}
if (-not $javaExecutable) {
    $javaCommand = Get-Command java -ErrorAction SilentlyContinue
    if ($javaCommand) {
        $javaExecutable = $javaCommand.Source
    }
}
if (-not $javaExecutable) {
    Write-Error "Java is unavailable. Install JDK 21 and configure JAVA_HOME or PATH."
}
$javaVersionOutput = & $javaExecutable -version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Error "Java is unavailable. Install JDK 21 and configure JAVA_HOME or PATH."
}
$javaVersionText = $javaVersionOutput -join "`n"
if ($javaVersionText -notmatch 'version "21(?:\.|\")') {
    Write-Error ("JDK 21 is required. Current Java output:`n" + $javaVersionText)
}

Write-Output "SELPLAT platform startup validation passed."
Write-Output ("Platform root: " + $platformRoot)
Write-Output "Runtime project: apps/host/backend and its explicit Gradle dependencies"
Write-Output "Delivery subset: server modules only; apps/ai-desktop is not included"

if ($ValidateOnly) {
    Write-Output "Validation-only mode completed; SELPLAT was not started."
    exit 0
}

$hostPort = 8080
if (-not $env:SELPLAT_PRIVATE_ROOT) { $env:SELPLAT_PRIVATE_ROOT = Join-Path $platformRoot "private" }
$runtimeEnvironment = if ($env:SELPLAT_ENV -eq "test") { "test" } else { "production" }
if (-not $env:FILE_SERVICE_JDBC_URL) {
    $fileServiceDatabaseDirectory = Join-Path $env:SELPLAT_PRIVATE_ROOT ($runtimeEnvironment + "\db\file-service")
    New-Item -ItemType Directory -Force -Path $fileServiceDatabaseDirectory | Out-Null
    $fileServiceDatabasePath = (Join-Path $fileServiceDatabaseDirectory "file-service").Replace("\", "/")
    $env:FILE_SERVICE_JDBC_URL = "jdbc:h2:file:" + $fileServiceDatabasePath + ";MODE=MySQL;DATABASE_TO_UPPER=false;DB_CLOSE_ON_EXIT=FALSE"
}
if ($env:SELPLAT_ENV -eq "test") {
    $hostPort = if ($env:SELPLAT_TEST_PORT) { [int]$env:SELPLAT_TEST_PORT } else { 8081 }
}
$existingListeners = @(Get-NetTCPConnection -LocalPort $hostPort -State Listen -ErrorAction SilentlyContinue)
$existingProcessIds = @($existingListeners | Select-Object -ExpandProperty OwningProcess -Unique)
foreach ($existingProcessId in $existingProcessIds) {
    Write-Output ("Stopping existing process on SELPLAT port " + $hostPort + ": " + $existingProcessId)
    Stop-Process -Id $existingProcessId -Force
}

Write-Output "Starting the SELPLAT platform runtime."
Write-Output "Gradle will compile the registered Host runtime before startup."
if ($Offline) {
    Write-Output "Offline mode enabled; Gradle and Maven dependencies must already exist in cache."
} else {
    Write-Output "First-run mode enabled; missing declared Gradle and Maven dependencies may be downloaded."
}
Write-Output ("Health: http://localhost:" + $hostPort + "/api/platform/runtime/health")
Set-Location $platformRoot
$gradleArguments = @("--no-daemon")
if ($Offline) {
    $gradleArguments += "--offline"
}
$gradleArguments += ":apps:host:backend:prepareDevRuntimeClasses"
$gradleArguments += ":apps:host:backend:run"
& $gradleWrapper @gradleArguments
exit $LASTEXITCODE
