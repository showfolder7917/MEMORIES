@echo off
setlocal
chcp 65001 >nul
powershell -ExecutionPolicy Bypass -File "%~dp0启动SELPLAT.ps1" %*
exit /b %errorlevel%
