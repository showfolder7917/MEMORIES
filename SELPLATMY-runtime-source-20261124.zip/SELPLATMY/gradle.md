# Gradle 构建与启动

## 环境

- Windows 10/11
- JDK 21
- 工程自带 Gradle Wrapper 8.11，不需要单独安装 Gradle
- 首次运行可访问 `services.gradle.org` 和 Maven Central

## 自动编译并启动

在工程根目录运行：

```powershell
.\启动SELPLAT.bat
```

入口会检查 JDK 21、创建本地缓存目录、结束占用运行端口的旧进程，然后编译 Host 及其显式模块依赖并启动平台。首次运行允许下载已声明的 Gradle 分发和 Maven 依赖，下载内容只进入忽略提交的 `cache/`。

依赖已经缓存后可强制离线启动：

```powershell
.\启动SELPLAT.ps1 -Offline
```

只检查目录、Wrapper 和 JDK：

```powershell
.\启动SELPLAT.ps1 -ValidateOnly
```

## 独立编译

```powershell
.\gradlew.bat --no-daemon :apps:host:backend:prepareDevRuntimeClasses
```

## 运行入口

- 首页：`http://localhost:8080/`
- 健康接口：`http://localhost:8080/api/platform/runtime/health`
- 登录页：`http://localhost:8080/uniauth/login.html`
- 应用账号：`test / 12345678`

数据库连接继续使用模块配置中的 `sa / 123456`，不要把应用账号当成 H2 JDBC 账号。

## 提交边界

`.gitignore` 已排除构建、缓存、私有配置、运行数据库、日志和临时文件；`.gitattributes` 固定 Windows 启动脚本的 CRLF，避免 GitHub ZIP 下载后批处理换行失效。
